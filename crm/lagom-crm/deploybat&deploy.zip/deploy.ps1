# Lagom CRM Deployment Script for Windows
# Run this in PowerShell as Administrator in your lagom-crm folder
# Right-click PowerShell → Run as Administrator → cd C:\Users\titol\OneDrive\Desktop\Lagom Naturals CRM\lagom-crm
# Then: powershell -ExecutionPolicy Bypass -File deploy.ps1

Write-Host "🚀 Lagom CRM Deployment Script" -ForegroundColor Green
Write-Host "================================`n" -ForegroundColor Green

# Step 1: Create directories
Write-Host "Step 1: Creating component directories..." -ForegroundColor Cyan
if (-not (Test-Path "components\crm")) {
    New-Item -ItemType Directory -Path "components\crm" -Force | Out-Null
    Write-Host "✓ Created components/crm directory" -ForegroundColor Green
} else {
    Write-Host "✓ components/crm directory already exists" -ForegroundColor Green
}

if (-not (Test-Path "app\crm")) {
    New-Item -ItemType Directory -Path "app\crm" -Force | Out-Null
    Write-Host "✓ Created app/crm directory" -ForegroundColor Green
} else {
    Write-Host "✓ app/crm directory already exists" -ForegroundColor Green
}

# Step 2: Create the CRM component file
Write-Host "`nStep 2: Creating LagomCRM.jsx component..." -ForegroundColor Cyan

$crmComponent = @'
import React, { useState, useEffect } from 'react';
import { ChevronDown, Plus, Search, Calendar, TrendingUp, Users, AlertCircle, CheckCircle, Clock, MapPin, PhoneIcon, Mail, ArrowUpRight, BarChart3, LineChart, PieChart, Activity, Settings, X } from 'lucide-react';

const LagomCRM = () => {
  const [phase, setPhase] = useState('phase1');
  const [activeTab, setActiveTab] = useState('prospects');
  const [selectedTerritory, setSelectedTerritory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewProspect, setShowNewProspect] = useState(false);
  const [prospects, setProspects] = useState(sampleProspects);
  const [selectedProspect, setSelectedProspect] = useState(null);

  const filteredProspects = prospects.filter(p => {
    const matchTerritory = selectedTerritory === 'all' || p.territory === selectedTerritory;
    const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                       p.company.toLowerCase().includes(searchQuery.toLowerCase());
    return matchTerritory && matchSearch;
  });

  return (
    <div className="crm-container">
      <style>{crmStyles}</style>
      
      <div className="crm-header">
        <div className="header-left">
          <div className="logo-section">
            <div className="logo-icon">
              <svg width="32" height="32" viewBox="0 0 40 40" fill="none">
                <circle cx="20" cy="20" r="19" stroke="#1a472a" strokeWidth="2"/>
                <path d="M12 20C12 15.6 15.6 12 20 12C24.4 12 28 15.6 28 20" stroke="#1a472a" strokeWidth="2" strokeLinecap="round"/>
                <circle cx="20" cy="28" r="2" fill="#1a472a"/>
              </svg>
            </div>
            <div>
              <h1 className="logo-text">Lagom Naturals</h1>
              <p className="logo-subtitle">SALES CRM</p>
            </div>
          </div>
          <div className="phase-selector">
            <button 
              className={`phase-btn ${phase === 'phase1' ? 'active' : ''}`}
              onClick={() => setPhase('phase1')}
            >
              Phase 1
            </button>
            <button 
              className={`phase-btn ${phase === 'phase2' ? 'active' : ''}`}
              onClick={() => setPhase('phase2')}
            >
              Phase 2
            </button>
          </div>
        </div>
        <div className="header-right">
          <div className="user-badge">
            <Users size={16} />
            <span>Tito</span>
          </div>
        </div>
      </div>

      <div className="crm-main">
        {phase === 'phase1' ? (
          <Phase1 
            prospects={filteredProspects}
            selectedTerritory={selectedTerritory}
            setSelectedTerritory={setSelectedTerritory}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            showNewProspect={showNewProspect}
            setShowNewProspect={setShowNewProspect}
            selectedProspect={selectedProspect}
            setSelectedProspect={setSelectedProspect}
            allProspects={prospects}
          />
        ) : (
          <Phase2 
            prospects={filteredProspects}
            selectedTerritory={selectedTerritory}
            setSelectedTerritory={setSelectedTerritory}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            allProspects={prospects}
          />
        )}
      </div>
    </div>
  );
};

const Phase1 = ({ prospects, selectedTerritory, setSelectedTerritory, searchQuery, setSearchQuery, showNewProspect, setShowNewProspect, selectedProspect, setSelectedProspect, allProspects }) => {
  const territories = ['all', 'North Loop/Downtown', 'Uptown/South Minneapolis', 'Northeast Minneapolis', 'St. Paul', 'Hopkins/West Suburbs'];
  const statuses = ['Active', 'Contacted', 'Follow-up', 'Closed'];

  const statusCounts = {
    'Active': allProspects.filter(p => p.status === 'Active').length,
    'Contacted': allProspects.filter(p => p.status === 'Contacted').length,
    'Follow-up': allProspects.filter(p => p.status === 'Follow-up').length,
    'Closed': allProspects.filter(p => p.status === 'Closed').length,
  };

  return (
    <div className="phase1-container">
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-label">Total Prospects</div>
          <div className="stat-value">{allProspects.length}</div>
          <div className="stat-trend success">
            <TrendingUp size={14} />
            <span>+12 this month</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Active Accounts</div>
          <div className="stat-value">{statusCounts['Active']}</div>
          <div className="stat-trend success">
            <CheckCircle size={14} />
            <span>In pipeline</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Follow-ups Due</div>
          <div className="stat-value">{statusCounts['Follow-up']}</div>
          <div className="stat-trend warning">
            <AlertCircle size={14} />
            <span>Next 7 days</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">This Month Closed</div>
          <div className="stat-value">{statusCounts['Closed']}</div>
          <div className="stat-trend success">
            <CheckCircle size={14} />
            <span>$45K projected</span>
          </div>
        </div>
      </div>

      <div className="phase1-controls">
        <div className="control-row">
          <div className="search-box">
            <Search size={18} />
            <input 
              type="text" 
              placeholder="Search by name or company..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <button className="btn-primary" onClick={() => setShowNewProspect(!showNewProspect)}>
            <Plus size={18} />
            New Prospect
          </button>
        </div>

        <div className="territory-tabs">
          {territories.map(territory => (
            <button
              key={territory}
              className={`territory-tab ${selectedTerritory === territory ? 'active' : ''}`}
              onClick={() => setSelectedTerritory(territory)}
            >
              <MapPin size={14} />
              {territory === 'all' ? 'All Territories' : territory}
            </button>
          ))}
        </div>
      </div>

      {showNewProspect && <NewProspectForm onClose={() => setShowNewProspect(false)} />}

      <div className="prospects-section">
        <div className="section-header">
          <h2>Prospect Pipeline</h2>
          <div className="status-badge-group">
            {statuses.map(status => (
              <span key={status} className={`status-badge status-${status.toLowerCase()}`}>
                {status} ({statusCounts[status]})
              </span>
            ))}
          </div>
        </div>

        <div className="prospects-table">
          <div className="table-header">
            <div className="col col-name">Company</div>
            <div className="col col-contact">Contact</div>
            <div className="col col-territory">Territory</div>
            <div className="col col-status">Status</div>
            <div className="col col-lastcontact">Last Contact</div>
            <div className="col col-actions">Actions</div>
          </div>

          <div className="table-body">
            {prospects.length > 0 ? (
              prospects.map((prospect, idx) => (
                <div 
                  key={idx} 
                  className={`table-row ${selectedProspect?.id === prospect.id ? 'selected' : ''}`}
                  onClick={() => setSelectedProspect(prospect)}
                >
                  <div className="col col-name">
                    <div className="prospect-name">{prospect.company}</div>
                    <div className="prospect-type">{prospect.type}</div>
                  </div>
                  <div className="col col-contact">
                    <div className="contact-item">
                      <Mail size={14} />
                      {prospect.contact}
                    </div>
                  </div>
                  <div className="col col-territory">
                    <span className="territory-badge">{prospect.territory.split('/')[0]}</span>
                  </div>
                  <div className="col col-status">
                    <span className={`status-badge status-${prospect.status.toLowerCase()}`}>
                      {prospect.status}
                    </span>
                  </div>
                  <div className="col col-lastcontact">
                    {prospect.lastContact}
                  </div>
                  <div className="col col-actions">
                    <button className="action-btn" title="Call">
                      <PhoneIcon size={16} />
                    </button>
                    <button className="action-btn" title="Email">
                      <Mail size={16} />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="table-empty">
                <AlertCircle size={32} />
                <p>No prospects found</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {selectedProspect && (
        <div className="detail-panel">
          <button className="close-btn" onClick={() => setSelectedProspect(null)}>
            <X size={20} />
          </button>
          <div className="detail-header">
            <h3>{selectedProspect.company}</h3>
            <span className={`status-badge status-${selectedProspect.status.toLowerCase()}`}>
              {selectedProspect.status}
            </span>
          </div>
          <div className="detail-body">
            <div className="detail-field">
              <label>Contact</label>
              <p>{selectedProspect.contact}</p>
            </div>
            <div className="detail-field">
              <label>Territory</label>
              <p>{selectedProspect.territory}</p>
            </div>
            <div className="detail-field">
              <label>Type</label>
              <p>{selectedProspect.type}</p>
            </div>
            <div className="detail-field">
              <label>Last Contact</label>
              <p>{selectedProspect.lastContact}</p>
            </div>
            <div className="detail-field">
              <label>Est. Annual Value</label>
              <p className="value-highlight">${selectedProspect.estValue}</p>
            </div>
          </div>
          <button className="btn-primary full">Log Activity</button>
        </div>
      )}
    </div>
  );
};

const Phase2 = ({ prospects, selectedTerritory, setSelectedTerritory, searchQuery, setSearchQuery, allProspects }) => {
  const territories = ['all', 'North Loop/Downtown', 'Uptown/South Minneapolis', 'Northeast Minneapolis', 'St. Paul', 'Hopkins/West Suburbs'];
  
  const conversionRate = ((allProspects.filter(p => p.status === 'Closed').length / allProspects.length) * 100).toFixed(1);
  const avgValue = (allProspects.reduce((sum, p) => sum + parseInt(p.estValue), 0) / allProspects.length).toFixed(0);
  const pipelineValue = allProspects.reduce((sum, p) => sum + parseInt(p.estValue), 0);

  return (
    <div className="phase2-container">
      <div className="analytics-header">
        <h2>Sales Analytics & Pipeline</h2>
        <div className="analytics-toolbar">
          <button className="toolbar-btn">
            <Calendar size={16} />
            Date Range
          </button>
          <button className="toolbar-btn">
            <Settings size={16} />
            Customize
          </button>
        </div>
      </div>

      <div className="metrics-grid">
        <div className="metric-card">
          <div className="metric-icon success-bg">
            <TrendingUp size={24} color="#1a7731" />
          </div>
          <div className="metric-content">
            <div className="metric-label">Pipeline Value</div>
            <div className="metric-number">${(pipelineValue / 1000).toFixed(0)}K</div>
            <div className="metric-change positive">↑ 18% vs last month</div>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon warning-bg">
            <Activity size={24} color="#d97706" />
          </div>
          <div className="metric-content">
            <div className="metric-label">Conversion Rate</div>
            <div className="metric-number">{conversionRate}%</div>
            <div className="metric-change positive">+2.3% from Q1</div>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon info-bg">
            <Users size={24} color="#1e40af" />
          </div>
          <div className="metric-content">
            <div className="metric-label">Active Prospects</div>
            <div className="metric-number">{allProspects.filter(p => p.status === 'Active').length}</div>
            <div className="metric-change neutral">In current pipeline</div>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon neutral-bg">
            <BarChart3 size={24} color="#6b7280" />
          </div>
          <div className="metric-content">
            <div className="metric-label">Avg Deal Size</div>
            <div className="metric-number">${avgValue}</div>
            <div className="metric-change neutral">Per prospect</div>
          </div>
        </div>
      </div>

      <div className="charts-row">
        <div className="chart-card">
          <div className="chart-header">
            <h3>Status Distribution</h3>
            <span className="chart-meta">102 prospects</span>
          </div>
          <div className="status-distribution">
            {['Active', 'Contacted', 'Follow-up', 'Closed'].map((status, idx) => {
              const count = allProspects.filter(p => p.status === status).length;
              const percent = ((count / allProspects.length) * 100).toFixed(0);
              return (
                <div key={status} className="distribution-bar">
                  <div className="bar-label">{status}</div>
                  <div className="bar-container">
                    <div 
                      className={`bar-fill status-${status.toLowerCase()}`}
                      style={{width: `${percent}%`}}
                    ></div>
                  </div>
                  <div className="bar-value">{count}</div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="chart-card">
          <div className="chart-header">
            <h3>Territory Performance</h3>
            <span className="chart-meta">Revenue by region</span>
          </div>
          <div className="territory-performance">
            {['North Loop/Downtown', 'Uptown/South Minneapolis', 'Northeast Minneapolis', 'St. Paul', 'Hopkins/West Suburbs'].map((territory, idx) => {
              const terrProspects = allProspects.filter(p => p.territory === territory);
              const revenue = terrProspects.reduce((sum, p) => sum + parseInt(p.estValue), 0);
              const maxRevenue = 15000;
              const percent = (revenue / maxRevenue) * 100;
              return (
                <div key={territory} className="performance-item">
                  <div className="perf-label">{territory.split('/')[0]}</div>
                  <div className="perf-bar">
                    <div 
                      className="perf-fill"
                      style={{width: `${Math.min(percent, 100)}%`}}
                    ></div>
                  </div>
                  <div className="perf-value">${(revenue / 1000).toFixed(0)}K</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="phase2-controls">
        <div className="territory-tabs">
          {territories.map(territory => (
            <button
              key={territory}
              className={`territory-tab ${selectedTerritory === territory ? 'active' : ''}`}
              onClick={() => setSelectedTerritory(territory)}
            >
              <MapPin size={14} />
              {territory === 'all' ? 'All Territories' : territory}
            </button>
          ))}
        </div>
      </div>

      <div className="advanced-prospects">
        <div className="section-header">
          <h2>Opportunity Pipeline</h2>
          <div className="search-box compact">
            <Search size={16} />
            <input 
              type="text" 
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="opportunity-cards">
          {prospects.slice(0, 6).map((prospect, idx) => (
            <div key={idx} className="opportunity-card">
              <div className="opp-header">
                <h4>{prospect.company}</h4>
                <span className={`status-badge status-${prospect.status.toLowerCase()}`}>
                  {prospect.status}
                </span>
              </div>
              <div className="opp-body">
                <div className="opp-field">
                  <span className="label">Contact:</span>
                  <span className="value">{prospect.contact}</span>
                </div>
                <div className="opp-field">
                  <span className="label">Territory:</span>
                  <span className="value">{prospect.territory}</span>
                </div>
                <div className="opp-field">
                  <span className="label">Est. Value:</span>
                  <span className="value highlight">${prospect.estValue}</span>
                </div>
              </div>
              <div className="opp-actions">
                <button className="mini-btn">Update</button>
                <button className="mini-btn">Log Call</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const NewProspectForm = ({ onClose }) => {
  const [formData, setFormData] = useState({
    company: '',
    contact: '',
    territory: 'North Loop/Downtown',
    type: 'Bar',
    estValue: '5000'
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>Add New Prospect</h3>
          <button className="close-btn" onClick={onClose}>
            <X size={20} />
          </button>
        </div>
        <form className="prospect-form">
          <div className="form-group">
            <label>Company Name</label>
            <input 
              type="text" 
              name="company"
              value={formData.company}
              onChange={handleChange}
              placeholder="e.g., The Bar at 5th & Main"
            />
          </div>
          <div className="form-group">
            <label>Contact Name</label>
            <input 
              type="text" 
              name="contact"
              value={formData.contact}
              onChange={handleChange}
              placeholder="Primary contact"
            />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Territory</label>
              <select name="territory" value={formData.territory} onChange={handleChange}>
                <option>North Loop/Downtown</option>
                <option>Uptown/South Minneapolis</option>
                <option>Northeast Minneapolis</option>
                <option>St. Paul</option>
                <option>Hopkins/West Suburbs</option>
              </select>
            </div>
            <div className="form-group">
              <label>Type</label>
              <select name="type" value={formData.type} onChange={handleChange}>
                <option>Bar</option>
                <option>Restaurant</option>
                <option>Retail</option>
                <option>Gym</option>
                <option>Other</option>
              </select>
            </div>
          </div>
          <div className="form-group">
            <label>Est. Annual Value</label>
            <input 
              type="number" 
              name="estValue"
              value={formData.estValue}
              onChange={handleChange}
              placeholder="$5000"
            />
          </div>
          <div className="form-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary">Create Prospect</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const sampleProspects = [
  { id: 1, company: 'The Bar at 5th', contact: 'Sarah M.', territory: 'North Loop/Downtown', type: 'Bar', status: 'Active', lastContact: '2 days ago', estValue: '8500' },
  { id: 2, company: 'Twin Cities Wellness', contact: 'Mike P.', territory: 'Uptown/South Minneapolis', type: 'Gym', status: 'Follow-up', lastContact: '5 days ago', estValue: '6200' },
  { id: 3, company: 'The Depot Market', contact: 'Jennifer L.', territory: 'Northeast Minneapolis', type: 'Retail', status: 'Contacted', lastContact: '1 week ago', estValue: '4500' },
  { id: 4, company: 'Strive Coffee House', contact: 'Alex T.', territory: 'St. Paul', type: 'Cafe', status: 'Active', lastContact: '3 days ago', estValue: '5800' },
  { id: 5, company: 'Westside Liquor', contact: 'Robert K.', territory: 'Hopkins/West Suburbs', type: 'Retail', status: 'Closed', lastContact: '10 days ago', estValue: '7200' },
  { id: 6, company: 'River North Tavern', contact: 'David S.', territory: 'North Loop/Downtown', type: 'Bar', status: 'Active', lastContact: '1 day ago', estValue: '9100' },
  { id: 7, company: 'Zenith Sports Bar', contact: 'Lisa W.', territory: 'Uptown/South Minneapolis', type: 'Bar', status: 'Follow-up', lastContact: '4 days ago', estValue: '6700' },
  { id: 8, company: 'Park Wellness Center', contact: 'Tom R.', territory: 'Northeast Minneapolis', type: 'Gym', status: 'Contacted', lastContact: '6 days ago', estValue: '5400' },
  { id: 9, company: 'St. Paul Dispensary Co.', contact: 'Nina H.', territory: 'St. Paul', type: 'Retail', status: 'Active', lastContact: '2 days ago', estValue: '7900' },
  { id: 10, company: 'Hopkins Market Hall', contact: 'Chris B.', territory: 'Hopkins/West Suburbs', type: 'Retail', status: 'Active', lastContact: '5 days ago', estValue: '5600' },
  { id: 11, company: 'The Rooftop Club', contact: 'Emma G.', territory: 'North Loop/Downtown', type: 'Bar', status: 'Follow-up', lastContact: '3 days ago', estValue: '8800' },
  { id: 12, company: 'Blend & Mingle', contact: 'Marcus J.', territory: 'Uptown/South Minneapolis', type: 'Cafe', status: 'Contacted', lastContact: '1 week ago', estValue: '4200' },
];

const crmStyles = `
  * { margin: 0; padding: 0; box-sizing: border-box; }
  .crm-container { width: 100%; min-height: 100vh; background: #f8f9fa; color: #212529; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Helvetica Neue', sans-serif; }
  .crm-header { display: flex; justify-content: space-between; align-items: center; padding: 18px 32px; background: white; border-bottom: 1px solid #e9ecef; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05); }
  .header-left { display: flex; align-items: center; gap: 40px; }
  .logo-section { display: flex; align-items: center; gap: 12px; }
  .logo-icon { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; }
  .logo-text { font-size: 18px; font-weight: 700; color: #1a472a; margin: 0; }
  .logo-subtitle { font-size: 11px; color: #6c757d; letter-spacing: 1px; margin: 0; font-weight: 600; }
  .phase-selector { display: flex; gap: 8px; background: #f0f2f5; padding: 4px; border-radius: 6px; }
  .phase-btn { padding: 6px 14px; background: transparent; border: none; color: #6c757d; font-weight: 600; font-size: 13px; cursor: pointer; border-radius: 5px; transition: all 0.2s ease; }
  .phase-btn.active { background: #1a7731; color: white; }
  .header-right { display: flex; align-items: center; gap: 16px; }
  .user-badge { display: flex; align-items: center; gap: 8px; padding: 8px 14px; background: #f0f2f5; border-radius: 6px; color: #1a472a; font-weight: 600; font-size: 13px; }
  .crm-main { padding: 32px; max-width: 1600px; margin: 0 auto; }
  .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 16px; margin-bottom: 32px; }
  .stat-card { background: white; border: 1px solid #e9ecef; padding: 20px; border-radius: 8px; transition: all 0.2s ease; }
  .stat-card:hover { border-color: #1a7731; box-shadow: 0 4px 12px rgba(26, 119, 49, 0.08); }
  .stat-label { font-size: 11px; color: #6c757d; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; font-weight: 600; }
  .stat-value { font-size: 32px; font-weight: 700; color: #212529; margin-bottom: 8px; }
  .stat-trend { display: flex; align-items: center; gap: 6px; font-size: 12px; }
  .stat-trend.success { color: #1a7731; }
  .stat-trend.warning { color: #d97706; }
  .phase1-controls { margin-bottom: 32px; }
  .control-row { display: flex; gap: 16px; margin-bottom: 16px; }
  .search-box { flex: 1; display: flex; align-items: center; gap: 12px; padding: 0 16px; background: white; border: 1px solid #e9ecef; border-radius: 8px; color: #6c757d; }
  .search-box input { flex: 1; background: transparent; border: none; color: #212529; font-size: 14px; outline: none; }
  .search-box input::placeholder { color: #adb5bd; }
  .search-box.compact { max-width: 280px; }
  .btn-primary { display: flex; align-items: center; gap: 8px; padding: 10px 16px; background: #1a7731; border: none; color: white; font-weight: 600; border-radius: 6px; cursor: pointer; font-size: 13px; transition: all 0.2s ease; }
  .btn-primary:hover { background: #155a28; box-shadow: 0 4px 12px rgba(26, 119, 49, 0.2); }
  .btn-primary.full { width: 100%; justify-content: center; }
  .btn-secondary { padding: 10px 16px; background: #f0f2f5; border: 1px solid #dee2e6; color: #212529; font-weight: 600; border-radius: 6px; cursor: pointer; font-size: 13px; }
  .territory-tabs { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 8px; }
  .territory-tab { display: flex; align-items: center; gap: 6px; padding: 8px 14px; background: white; border: 1px solid #e9ecef; color: #6c757d; border-radius: 6px; cursor: pointer; white-space: nowrap; font-size: 13px; font-weight: 500; transition: all 0.2s ease; }
  .territory-tab:hover { border-color: #1a7731; color: #1a7731; }
  .territory-tab.active { background: #1a7731; color: white; border-color: #1a7731; }
  .prospects-section { margin-top: 32px; }
  .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
  .section-header h2 { font-size: 18px; font-weight: 600; color: #212529; }
  .status-badge-group { display: flex; gap: 8px; }
  .status-badge { padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; }
  .status-badge.status-active { background: #d1f2d6; color: #1a7731; }
  .status-badge.status-contacted { background: #dbeafe; color: #1e40af; }
  .status-badge.status-follow-up { background: #fed7aa; color: #7c2d12; }
  .status-badge.status-closed { background: #e9d5ff; color: #6b21a8; }
  .prospects-table { background: white; border: 1px solid #e9ecef; border-radius: 8px; overflow: hidden; }
  .table-header { display: grid; grid-template-columns: 2fr 1.5fr 1fr 1fr 1fr 0.8fr; gap: 16px; padding: 16px 20px; background: #f8f9fa; border-bottom: 1px solid #e9ecef; font-weight: 600; font-size: 12px; color: #6c757d; text-transform: uppercase; letter-spacing: 0.5px; }
  .table-body { max-height: 500px; overflow-y: auto; }
  .table-row { display: grid; grid-template-columns: 2fr 1.5fr 1fr 1fr 1fr 0.8fr; gap: 16px; padding: 14px 20px; border-bottom: 1px solid #e9ecef; align-items: center; cursor: pointer; transition: all 0.2s ease; }
  .table-row:hover { background: #f8f9fa; }
  .table-row.selected { background: #f0fdf4; }
  .col { display: flex; align-items: center; gap: 8px; font-size: 13px; color: #212529; }
  .prospect-name { font-weight: 600; }
  .prospect-type { font-size: 12px; color: #6c757d; }
  .contact-item { display: flex; align-items: center; gap: 6px; color: #495057; }
  .territory-badge { padding: 4px 10px; background: #f0f2f5; border-radius: 4px; font-size: 12px; color: #495057; }
  .table-empty { padding: 60px 20px; text-align: center; color: #adb5bd; }
  .table-empty svg { margin-bottom: 16px; opacity: 0.5; }
  .action-btn { padding: 6px; background: transparent; border: none; color: #adb5bd; cursor: pointer; border-radius: 4px; transition: all 0.2s ease; display: flex; align-items: center; justify-content: center; }
  .action-btn:hover { background: #f0f2f5; color: #1a7731; }
  .detail-panel { position: fixed; right: 32px; top: 120px; width: 320px; background: white; border: 1px solid #e9ecef; border-radius: 8px; padding: 20px; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08); animation: slideIn 0.3s ease; z-index: 50; }
  @keyframes slideIn { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: translateX(0); } }
  .detail-header { display: flex; justify-content: space-between; align-items: start; gap: 12px; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #e9ecef; }
  .detail-header h3 { font-size: 15px; font-weight: 600; color: #212529; }
  .detail-body { margin-bottom: 16px; }
  .detail-field { margin-bottom: 12px; }
  .detail-field label { display: block; font-size: 11px; color: #6c757d; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; font-weight: 600; }
  .detail-field p { font-size: 13px; color: #495057; }
  .value-highlight { color: #1a7731; font-weight: 600; }
  .close-btn { width: 28px; height: 28px; padding: 0; background: transparent; border: none; color: #adb5bd; cursor: pointer; border-radius: 4px; transition: all 0.2s ease; display: flex; align-items: center; justify-content: center; }
  .close-btn:hover { background: #f0f2f5; color: #212529; }
  .modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0, 0, 0, 0.3); display: flex; align-items: center; justify-content: center; z-index: 1000; }
  .modal-content { background: white; border: 1px solid #e9ecef; border-radius: 8px; padding: 24px; width: 90%; max-width: 500px; box-shadow: 0 20px 50px rgba(0, 0, 0, 0.15); }
  .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid #e9ecef; }
  .modal-header h3 { font-size: 16px; font-weight: 600; color: #212529; }
  .prospect-form { display: flex; flex-direction: column; gap: 16px; }
  .form-group { display: flex; flex-direction: column; gap: 6px; }
  .form-group label { font-size: 12px; color: #6c757d; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
  .form-group input, .form-group select { padding: 10px 12px; background: white; border: 1px solid #dee2e6; border-radius: 6px; color: #212529; font-size: 13px; }
  .form-group input:focus, .form-group select:focus { outline: none; border-color: #1a7731; box-shadow: 0 0 0 3px rgba(26, 119, 49, 0.1); }
  .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 8px; }
  .form-actions button { padding: 10px 16px; font-size: 13px; font-weight: 600; border-radius: 6px; cursor: pointer; border: none; }
  .phase2-container { padding: 0; }
  .analytics-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
  .analytics-header h2 { font-size: 20px; font-weight: 600; color: #212529; }
  .analytics-toolbar { display: flex; gap: 8px; }
  .toolbar-btn { display: flex; align-items: center; gap: 6px; padding: 8px 12px; background: white; border: 1px solid #e9ecef; color: #6c757d; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 500; transition: all 0.2s ease; }
  .toolbar-btn:hover { border-color: #1a7731; color: #1a7731; }
  .metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; margin-bottom: 32px; }
  .metric-card { display: flex; gap: 16px; background: white; border: 1px solid #e9ecef; padding: 20px; border-radius: 8px; transition: all 0.2s ease; }
  .metric-card:hover { border-color: #1a7731; box-shadow: 0 4px 12px rgba(26, 119, 49, 0.08); }
  .metric-icon { width: 56px; height: 56px; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .success-bg { background: #d1f2d6; }
  .warning-bg { background: #fed7aa; }
  .info-bg { background: #dbeafe; }
  .neutral-bg { background: #f0f2f5; }
  .metric-content { flex: 1; }
  .metric-label { font-size: 12px; color: #6c757d; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; font-weight: 600; }
  .metric-number { font-size: 28px; font-weight: 700; color: #212529; margin-bottom: 4px; }
  .metric-change { font-size: 12px; color: #6c757d; }
  .metric-change.positive { color: #1a7731; }
  .metric-change.neutral { color: #6c757d; }
  .charts-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(360px, 1fr)); gap: 16px; margin-bottom: 32px; }
  .chart-card { background: white; border: 1px solid #e9ecef; padding: 20px; border-radius: 8px; }
  .chart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #e9ecef; }
  .chart-header h3 { font-size: 14px; font-weight: 600; color: #212529; }
  .chart-meta { font-size: 12px; color: #6c757d; }
  .status-distribution { display: flex; flex-direction: column; gap: 12px; }
  .distribution-bar { display: flex; align-items: center; gap: 12px; }
  .bar-label { width: 80px; font-size: 13px; color: #495057; font-weight: 500; }
  .bar-container { flex: 1; height: 24px; background: #f0f2f5; border-radius: 4px; overflow: hidden; }
  .bar-fill { height: 100%; border-radius: 4px; }
  .bar-fill.status-active { background: #1a7731; }
  .bar-fill.status-contacted { background: #1e40af; }
  .bar-fill.status-follow-up { background: #d97706; }
  .bar-fill.status-closed { background: #6b21a8; }
  .bar-value { width: 40px; text-align: right; font-size: 13px; font-weight: 600; color: #495057; }
  .territory-performance { display: flex; flex-direction: column; gap: 16px; }
  .performance-item { display: flex; align-items: center; gap: 12px; }
  .perf-label { width: 80px; font-size: 13px; color: #495057; font-weight: 500; }
  .perf-bar { flex: 1; height: 28px; background: #f0f2f5; border-radius: 4px; overflow: hidden; }
  .perf-fill { height: 100%; background: #1a7731; border-radius: 4px; transition: width 0.3s ease; }
  .perf-value { width: 50px; text-align: right; font-size: 13px; font-weight: 600; color: #495057; }
  .phase2-controls { margin: 24px 0; }
  .advanced-prospects { margin-top: 32px; }
  .opportunity-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 16px; }
  .opportunity-card { background: white; border: 1px solid #e9ecef; border-radius: 8px; padding: 16px; transition: all 0.2s ease; }
  .opportunity-card:hover { border-color: #1a7731; box-shadow: 0 4px 12px rgba(26, 119, 49, 0.08); }
  .opp-header { display: flex; justify-content: space-between; align-items: start; gap: 8px; margin-bottom: 12px; padding-bottom: 12px; border-bottom: 1px solid #e9ecef; }
  .opp-header h4 { font-size: 14px; font-weight: 600; color: #212529; }
  .opp-body { margin-bottom: 12px; }
  .opp-field { display: flex; justify-content: space-between; align-items: center; font-size: 13px; margin-bottom: 8px; }
  .opp-field .label { color: #6c757d; font-weight: 500; }
  .opp-field .value { color: #495057; }
  .opp-field .highlight { color: #1a7731; font-weight: 600; }
  .opp-actions { display: flex; gap: 8px; }
  .mini-btn { flex: 1; padding: 8px; background: #f0fdf4; border: 1px solid #d1f2d6; color: #1a7731; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 600; transition: all 0.2s ease; }
  .mini-btn:hover { background: #d1f2d6; }
  .table-body::-webkit-scrollbar { width: 6px; }
  .table-body::-webkit-scrollbar-track { background: transparent; }
  .table-body::-webkit-scrollbar-thumb { background: #dee2e6; border-radius: 3px; }
  .table-body::-webkit-scrollbar-thumb:hover { background: #adb5bd; }
  @media (max-width: 1200px) { .table-header, .table-row { grid-template-columns: 1.5fr 1fr 1fr 1fr 0.8fr !important; } }
  @media (max-width: 768px) { .detail-panel { position: relative; right: auto; top: auto; width: 100%; margin-top: 20px; } .table-header, .table-row { grid-template-columns: 1.5fr 1fr 1fr !important; } .col-lastcontact, .col-actions { display: none; } }
`;

export default LagomCRM;
'@

# Write the component file
$crmComponent | Out-File -FilePath "components\crm\LagomCRM.jsx" -Encoding UTF8
Write-Host "✓ Created LagomCRM.jsx component" -ForegroundColor Green

# Step 3: Create the CRM page wrapper
Write-Host "`nStep 3: Creating CRM page route..." -ForegroundColor Cyan

$pageContent = @"
'use client';

import LagomCRM from '@/components/crm/LagomCRM';

export default function CRMPage() {
  return <LagomCRM />;
}
"@

$pageContent | Out-File -FilePath "app\crm\page.js" -Encoding UTF8
Write-Host "✓ Created app/crm/page.js" -ForegroundColor Green

# Step 4: Check if lucide-react is installed
Write-Host "`nStep 4: Checking dependencies..." -ForegroundColor Cyan

if (Test-Path "node_modules\lucide-react") {
    Write-Host "✓ lucide-react is already installed" -ForegroundColor Green
} else {
    Write-Host "Installing lucide-react..." -ForegroundColor Yellow
    npm install lucide-react
    Write-Host "✓ lucide-react installed" -ForegroundColor Green
}

# Step 5: Test locally
Write-Host "`nStep 5: Starting local development server..." -ForegroundColor Cyan
Write-Host "Opening http://localhost:3000/crm in 3 seconds..." -ForegroundColor Cyan
Start-Sleep -Seconds 2

npm run dev

Write-Host "`n" -ForegroundColor Green
Write-Host "✅ CRM is running locally!" -ForegroundColor Green
Write-Host "Visit: http://localhost:3000/crm" -ForegroundColor Cyan
Write-Host "`nPress Ctrl+C to stop the server when ready to deploy." -ForegroundColor Yellow
