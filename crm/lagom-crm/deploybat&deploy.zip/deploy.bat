@echo off
REM Lagom CRM Deployment Script for Windows
REM Right-click this file and "Run as Administrator" OR
REM Open Command Prompt/PowerShell in this folder and run: deploy.bat

echo.
echo ========================================
echo Lagom CRM Deployment Script
echo ========================================
echo.

REM Navigate to project directory
cd /d "%~dp0"

echo Step 1: Creating component directories...
if not exist "components\crm" mkdir components\crm
if not exist "app\crm" mkdir app\crm
echo [OK] Directories created

echo.
echo Step 2: Installing lucide-react (if needed)...
call npm install lucide-react

echo.
echo Step 3: Starting development server...
echo.
echo Your CRM will be available at: http://localhost:3000/crm
echo.
echo Press Ctrl+C to stop the server.
echo.

call npm run dev

pause
