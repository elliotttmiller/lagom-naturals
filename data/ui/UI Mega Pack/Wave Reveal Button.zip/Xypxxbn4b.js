var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/c6i8ZKJzfubn6pusEUa1/fuWldc87dwJ27x3jDkBQ/XyPxxbn4B.js
import { jsx as _jsx3, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx as cx3, getFonts, Link, patchBorderRadiusScaleCorrector, RichText, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS3 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion3, MotionConfigContext } from "framer-motion";
import * as React3 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/IkZwzw4oFB1gApg5em8O/rXhS9QgdbWWflI7mGVWt/dK6JXX8w_.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 15 14" xmlns="http://www.w3.org/2000/svg"><g d="M 14.817 7.496 L 9.192 13.796 C 8.948 14.069 8.552 14.069 8.308 13.796 C 8.064 13.522 8.064 13.079 8.308 12.805 L 12.866 7.7 L 0.625 7.7 C 0.28 7.7 0 7.387 0 7 C 0 6.614 0.28 6.3 0.625 6.3 L 12.866 6.3 L 8.308 1.196 C 8.064 0.922 8.064 0.479 8.308 0.205 C 8.552 -0.068 8.948 -0.068 9.192 0.205 L 14.817 6.505 C 14.935 6.636 15 6.815 15 7 C 15 7.186 14.935 7.364 14.817 7.496 Z" fill="transparent" height="14.000778533530571px" id="hPPhR3YyE" width="15.00049166025974px"><path d="M 14.817 7.496 L 9.192 13.796 C 8.948 14.069 8.552 14.069 8.308 13.796 C 8.064 13.522 8.064 13.079 8.308 12.805 L 12.866 7.7 L 0.625 7.7 C 0.28 7.7 0 7.387 0 7 C 0 6.614 0.28 6.3 0.625 6.3 L 12.866 6.3 L 8.308 1.196 C 8.064 0.922 8.064 0.479 8.308 0.205 C 8.552 -0.068 8.948 -0.068 9.192 0.205 L 14.817 6.505 C 14.935 6.636 15 6.815 15 7 C 15 7.186 14.935 7.364 14.817 7.496 Z" fill="var(--p7hvpk, rgb(0,0,0))" height="14.000778533530628px" id="KnhvatF2l" transform="translate(0 0)" width="15.00049166025974px"/></g></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(motion.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx("div", { ...rest, ref });
});
var getProps = ({ colorIcon, colorWave, height, id, width, ...props }) => {
  return { ...props, ARO3rlLA5: colorIcon ?? props.ARO3rlLA5 ?? "rgb(0, 0, 0)", UCpyMMmro: colorWave ?? props.UCpyMMmro ?? "rgb(4, 0, 255)" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, ARO3rlLA5, UCpyMMmro, ...restProps } = getProps(props);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-ZPNUI", className), layoutId, ref, style: { "--p7hvpk": ARO3rlLA5, ...style } });
});
var css = [`.framer-ZPNUI { -webkit-mask: ${mask}; aspect-ratio: 1.0714285714285714; background-color: var(--p7hvpk); mask: ${mask}; width: 15px; }`];
var Icon = withCSS(Component, css, "framer-ZPNUI");
Icon.displayName = "Arrow";
var dK6JXX8w_default = Icon;
addPropertyControls(Icon, { ARO3rlLA5: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color - Icon", type: ControlType.Color }, UCpyMMmro: { defaultValue: "rgb(4, 0, 255)", hidden: true, title: "Color - Wave", type: ControlType.Color } });

// http-url:https://framerusercontent.com/modules/efO3VZEwp6uvZwpkbPy1/Ev27FHH1E5JfccV7mZz6/mzBpRU2t3.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, motion as motion2, withCSS as withCSS2 } from "./_framer-runtime.js";
import * as React2 from "react";
import { forwardRef as forwardRef4 } from "react";
var mask2 = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 15 14" xmlns="http://www.w3.org/2000/svg"><path d="M 5 3.523 C 5.078 3.523 5.155 3.525 5.233 3.528 C 5.873 1.483 7.765 0 10 0 C 12.761 0 15 2.264 15 5.057 C 15 7.85 12.761 10.114 10 10.114 C 9.922 10.114 9.845 10.112 9.767 10.108 C 9.127 12.154 7.235 13.636 5 13.636 C 2.239 13.636 0 11.372 0 8.58 C 0 5.787 2.239 3.523 5 3.523 Z" fill="var(--3zz8ee, rgb(4, 0, 255))" height="13.63636361468922px" id="HkLdRMDWZ" transform="translate(0 0.18)" width="15px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG2 = /* @__PURE__ */ forwardRef4((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx2(motion2.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx2("div", { ...rest, ref });
});
var getProps2 = ({ colorIcon, colorWave, height, id, width, ...props }) => {
  return { ...props, ARO3rlLA5: colorIcon ?? props.ARO3rlLA5 ?? "rgb(0, 0, 0)", UCpyMMmro: colorWave ?? props.UCpyMMmro ?? "rgb(4, 0, 255)" };
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, ARO3rlLA5, UCpyMMmro, ...restProps } = getProps2(props);
  return /* @__PURE__ */ _jsx2(SVG2, { ...restProps, className: cx2("framer-5wOxp", className), layoutId, ref, style: { "--3zz8ee": UCpyMMmro, ...style } });
});
var css2 = [`.framer-5wOxp { -webkit-mask: ${mask2}; aspect-ratio: 1.0714285714285714; background-color: var(--3zz8ee); mask: ${mask2}; width: 15px; }`];
var Icon2 = withCSS2(Component2, css2, "framer-5wOxp");
Icon2.displayName = "Wave Fill";
var mzBpRU2t3_default = Icon2;
addPropertyControls2(Icon2, { ARO3rlLA5: { defaultValue: "rgb(0, 0, 0)", hidden: true, title: "Color - Icon", type: ControlType2.Color }, UCpyMMmro: { defaultValue: "rgb(4, 0, 255)", hidden: false, title: "Color - Wave", type: ControlType2.Color } });

// http-url:https://framerusercontent.com/modules/c6i8ZKJzfubn6pusEUa1/fuWldc87dwJ27x3jDkBQ/XyPxxbn4B.js
var ArrowFonts = getFonts(dK6JXX8w_default);
var WaveFillFonts = getFonts(mzBpRU2t3_default);
var enabledGestures = { yEZohBhL9: { hover: true, pressed: true }, zikQepDnb: { pressed: true } };
var cycleOrder = ["yEZohBhL9", "zikQepDnb"];
var serializationHash = "framer-tXnXW";
var variantClassNames = { yEZohBhL9: "framer-v-5z4zng", zikQepDnb: "framer-v-xap9vz" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var patchBorderRadiusScaleCorrector1 = patchBorderRadiusScaleCorrector();
var transition1 = { bounce: 0, delay: 0, duration: 1, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "Tab / Phone": "zikQepDnb", Desktop: "yEZohBhL9" };
var Variants = motion3.create(React3.Fragment);
var getProps3 = ({ colorButton, colorIconDefault, colorIconHover, colorLabel, colorWave, height, id, link, textLabel, width, ...props }) => {
  return { ...props, dQrnsU3gY: colorWave ?? props.dQrnsU3gY ?? "rgb(4, 0, 255)", o8MIfb9cZ: textLabel ?? props.o8MIfb9cZ ?? "View Projects", ocJwACMd0: link ?? props.ocJwACMd0, OUsGU0dDF: colorIconDefault ?? props.OUsGU0dDF ?? "rgb(0, 0, 0)", sIQh4qaqL: colorButton ?? props.sIQh4qaqL ?? "rgb(255, 255, 255)", taMLznUai: colorLabel ?? props.taMLznUai ?? "rgb(0, 0, 0)", uq4RDJDxs: colorIconHover ?? props.uq4RDJDxs ?? "rgb(255, 255, 255)", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "yEZohBhL9" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, sIQh4qaqL, o8MIfb9cZ, taMLznUai, OUsGU0dDF, uq4RDJDxs, dQrnsU3gY, ocJwACMd0, ...restProps } = getProps3(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "yEZohBhL9", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx3(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx3(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition, { value: transition1, children: /* @__PURE__ */ _jsx3(Link, { href: ocJwACMd0, motionChild: true, nodeId: "yEZohBhL9", openInNewTab: true, scopeId: "XyPxxbn4B", children: /* @__PURE__ */ _jsxs(motion3.a, { ...restProps, ...gestureHandlers, className: `${cx3(scopingClassNames, "framer-5z4zng", className, classNames)} framer-vr5tr`, "data-framer-name": "Desktop", layoutDependency, layoutId: "XyPxxbn4B__yEZohBhL9", ref: refBinding, style: { "--corner-shape-fallback": 0.752, backgroundColor: sIQh4qaqL, borderBottomLeftRadius: "calc(24px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(24px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(24px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(24px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", cornerShape: "superellipse(1.5)", ...style }, ...addPropertyOverrides({ "yEZohBhL9-hover": { "data-framer-name": void 0 }, "yEZohBhL9-pressed": { "data-framer-name": void 0 }, "zikQepDnb-pressed": { "data-framer-name": void 0 }, zikQepDnb: { "data-framer-name": "Tab / Phone" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-open-type-features": "'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on", "--framer-font-size": "18px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.02em", "--framer-line-height": "1.6em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-taMLznUai-XyPxxbn4B))" }, children: "View Projects" }) }), className: "framer-1lvietp", "data-framer-name": "Label", fonts: ["Inter-Medium"], layoutDependency, layoutId: "XyPxxbn4B__cFdPG2ppF", style: { "--extracted-r6o4lv": "var(--variable-reference-taMLznUai-XyPxxbn4B)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline", "--variable-reference-taMLznUai-XyPxxbn4B": taMLznUai, scale: 1 }, text: o8MIfb9cZ, variants: { "yEZohBhL9-hover": { "--extracted-r6o4lv": "rgb(255, 255, 255)" }, "yEZohBhL9-pressed": { "--extracted-r6o4lv": "rgb(255, 255, 255)", scale: 0.95 }, "zikQepDnb-pressed": { scale: 0.95 } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ "yEZohBhL9-hover": { children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-open-type-features": "'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on", "--framer-font-size": "18px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.02em", "--framer-line-height": "1.6em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(255, 255, 255))" }, children: "View Projects" }) }) }, "yEZohBhL9-pressed": { children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-open-type-features": "'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on", "--framer-font-size": "18px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.02em", "--framer-line-height": "1.6em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(255, 255, 255))" }, children: "View Projects" }) }) } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsxs(motion3.div, { className: "framer-en7xyp", "data-framer-name": "Icon Wrapper", layoutDependency, layoutId: "XyPxxbn4B__Ku9hhrQeT", style: { scale: 1 }, variants: { "yEZohBhL9-pressed": { scale: 0.95 }, "zikQepDnb-pressed": { scale: 0.95 } }, children: [/* @__PURE__ */ _jsx3(dK6JXX8w_default, { animated: true, className: "framer-1jcifp4", "data-framer-name": "Arrow Hover", layoutDependency, layoutId: "XyPxxbn4B__oSavp4ugU", style: { "--3zz8ee": "rgb(4, 0, 255)", "--p7hvpk": uq4RDJDxs } }), /* @__PURE__ */ _jsx3(dK6JXX8w_default, { animated: true, className: "framer-ze844o", "data-framer-name": "Arrow Default", layoutDependency, layoutId: "XyPxxbn4B__X5bOG6s96", style: { "--3zz8ee": "rgb(4, 0, 255)", "--p7hvpk": OUsGU0dDF } })] }), /* @__PURE__ */ _jsx3(mzBpRU2t3_default, { animated: true, className: "framer-u496xs", "data-framer-name": "Wave Fill", layoutDependency, layoutId: "XyPxxbn4B__x8moqXgM2", style: { "--3zz8ee": dQrnsU3gY, "--p7hvpk": "rgb(0, 0, 0)" } })] }) }) }) }) });
});
var css3 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-tXnXW.framer-vr5tr, .framer-tXnXW .framer-vr5tr { display: block; }", ".framer-tXnXW.framer-5z4zng { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 12px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 8px 22px 8px 22px; position: relative; text-decoration: none; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-tXnXW .framer-1lvietp { -webkit-user-select: none; flex: none; height: auto; position: relative; user-select: none; white-space: pre; width: auto; z-index: 2; }", ".framer-tXnXW .framer-en7xyp { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: flex-end; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 15px; z-index: 2; }", ".framer-tXnXW .framer-1jcifp4, .framer-tXnXW .framer-ze844o { aspect-ratio: 1.0714285714285714 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 14px); position: relative; width: 15px; z-index: 1; }", ".framer-tXnXW .framer-u496xs { aspect-ratio: 1.0731707317073171 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 123px); left: -84px; position: absolute; top: -100px; width: 132px; z-index: 1; }", ".framer-tXnXW.framer-v-5z4zng.hover .framer-en7xyp, .framer-tXnXW.framer-v-5z4zng.pressed .framer-en7xyp { justify-content: flex-start; }", ".framer-tXnXW.framer-v-5z4zng.hover .framer-u496xs, .framer-tXnXW.framer-v-5z4zng.pressed .framer-u496xs { aspect-ratio: 1.0474631751227497 / 1; bottom: -153px; height: var(--framer-aspect-ratio-supported, 307px); right: -53px; top: unset; width: calc(100% - -137px); }"];
var FramerXyPxxbn4B = withCSS3(Component3, css3, "framer-tXnXW");
var XyPxxbn4B_default = FramerXyPxxbn4B;
FramerXyPxxbn4B.displayName = "Wave Reveal Button";
FramerXyPxxbn4B.defaultProps = { height: 45, width: 184 };
addPropertyControls3(FramerXyPxxbn4B, { variant: { options: ["yEZohBhL9", "zikQepDnb"], optionTitles: ["Desktop", "Tab / Phone"], title: "Variant", type: ControlType3.Enum }, sIQh4qaqL: { defaultValue: "rgb(255, 255, 255)", title: "Color - Button", type: ControlType3.Color }, o8MIfb9cZ: { defaultValue: "View Projects", displayTextArea: false, title: "Text - Label", type: ControlType3.String }, ono8MIfb9cZChange: { changes: "o8MIfb9cZ", type: ControlType3.ChangeHandler }, taMLznUai: { defaultValue: "rgb(0, 0, 0)", title: "Color - Label", type: ControlType3.Color }, OUsGU0dDF: { defaultValue: "rgb(0, 0, 0)", title: "Color - Icon Default", type: ControlType3.Color }, uq4RDJDxs: { defaultValue: "rgb(255, 255, 255)", title: "Color - Icon Hover", type: ControlType3.Color }, dQrnsU3gY: { defaultValue: "rgb(4, 0, 255)", title: "Color - Wave", type: ControlType3.Color }, ocJwACMd0: { title: "Link", type: ControlType3.Link } });
addFonts(FramerXyPxxbn4B, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5A3Ce6C9YYmCjpQx9M4inSaKU.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/Qx95Xyt0Ka3SGhinnbXIGpEIyP4.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/6mJuEAguuIuMog10gGvH5d3cl8.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/xYYWaj7wCU5zSQH0eXvSaS19wo.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/otTaNuNpVK4RbdlT7zDDdKvQBA.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/UjlFhCnUjxhNfep4oYBPqnEssyo.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/DolVirEGb34pEXEp8t8FQBSK4.woff2", weight: "500" }] }, ...ArrowFonts, ...WaveFillFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerXyPxxbn4B", "slots": [], "annotations": { "framerImmutableVariables": "true", "framerVariables": '{"sIQh4qaqL":"colorButton","o8MIfb9cZ":"textLabel","taMLznUai":"colorLabel","OUsGU0dDF":"colorIconDefault","uq4RDJDxs":"colorIconHover","dQrnsU3gY":"colorWave","ocJwACMd0":"link"}', "framerAutoSizeImages": "true", "framerIntrinsicHeight": "45", "framerIntrinsicWidth": "184", "framerContractVersion": "1", "framerDisplayContentsDiv": "false", "framerColorSyntax": "true", "framerComponentViewportWidth": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"zikQepDnb":{"layout":["auto","auto"]},"npQsXKQFM":{"layout":["auto","auto"]},"o8_eEORR4":{"layout":["auto","auto"]},"xicYm6ozh":{"layout":["auto","auto"]}}}' } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  XyPxxbn4B_default as default
};
