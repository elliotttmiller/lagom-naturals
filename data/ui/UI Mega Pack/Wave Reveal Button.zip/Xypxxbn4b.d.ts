export interface Xypxxbn4bProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Tab / Phone" → zikQepDnb
   *   "Desktop" → yEZohBhL9
   */
  variant?: 'Tab / Phone' | 'Desktop' | 'yEZohBhL9' | 'zikQepDnb';
  /**
   * Color - Button — pass as `sIQh4qaqL` not `colorButton`.
   * @default "rgb(255, 255, 255)"
   */
  sIQh4qaqL?: string;
  /**
   * Text - Label — pass as `o8MIfb9cZ` not `textLabel`.
   * @default "View Projects"
   */
  o8MIfb9cZ?: string;
  ono8MIfb9cZChange?: string;
  /**
   * Color - Label — pass as `taMLznUai` not `colorLabel`.
   * @default "rgb(0, 0, 0)"
   */
  taMLznUai?: string;
  /**
   * Color - Icon Default — pass as `OUsGU0dDF` not `colorIconDefault`.
   * @default "rgb(0, 0, 0)"
   */
  OUsGU0dDF?: string;
  /**
   * Color - Icon Hover — pass as `uq4RDJDxs` not `colorIconHover`.
   * @default "rgb(255, 255, 255)"
   */
  uq4RDJDxs?: string;
  /**
   * Color - Wave — pass as `dQrnsU3gY` not `colorWave`.
   * @default "rgb(4, 0, 255)"
   */
  dQrnsU3gY?: string;
  /**
   * Link — pass as `ocJwACMd0` not `link`.
   */
  ocJwACMd0?: string;
  /** Additional properties */
  [key: string]: unknown;
}
