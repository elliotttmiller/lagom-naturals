export interface LogoscrollProps {
  /**
   * Logos
   */
  logos?: unknown[];
  /**
   * Axis
   * Options: "horizontal" | "vertical"
   * @default "horizontal"
   */
  axis?: 'horizontal' | 'vertical';
  /**
   * Motion — pass as `variant` not `motion`.
   * Options: "marquee" | "spotlight" | "depth" | "swap" | "wave"
   * @default "spotlight"
   */
  variant?: 'marquee' | 'spotlight' | 'depth' | 'swap' | 'wave';
  /**
   * Narrow — pass as `mobileVariant` not `narrow`.
   * Options: "inherit" | "marquee" | "spotlight" | "depth" | "swap" | "wave"
   * @default "swap"
   */
  mobileVariant?: 'inherit' | 'marquee' | 'spotlight' | 'depth' | 'swap' | 'wave';
  /**
   * Breakpoint
   * Range: min: 0, max: 1400
   * @default 810
   */
  breakpoint?: number;
  /**
   * Direction
   * Options: "left" | "right"
   * @default "left"
   */
  direction?: 'left' | 'right';
  /**
   * Speed
   * Range: min: 0, max: 220
   * @default 52
   */
  speed?: number;
  /**
   * Drag — pass as `draggable` not `drag`.
   * @default true
   */
  draggable?: boolean;
  /**
   * Scroll push — pass as `scrollBoost` not `scrollPush`.
   * Range: min: 0, max: 3, step: 0.1
   * @default 0
   */
  scrollBoost?: number;
  /**
   * Pause hover — pass as `pauseOnHover` not `pauseHover`.
   * @default false
   */
  pauseOnHover?: boolean;
  /**
   * Logo H — pass as `logoHeight` not `logoH`.
   * Range: min: 10, max: 80
   * @default 26
   */
  logoHeight?: number;
  /**
   * Narrow H — pass as `mobileLogoHeight` not `narrowH`.
   * Range: min: 0, max: 80
   * @default 0
   */
  mobileLogoHeight?: number;
  /**
   * Gap
   * Range: min: 0, max: 240
   * @default 64
   */
  gap?: number;
  /**
   * Slots — pass as `slotCount` not `slots`.
   * Range: min: 0, max: 6, step: 1
   * @default 0
   */
  slotCount?: number;
  /**
   * Focus — pass as `focusWidth` not `focus`.
   * Range: min: 0.1, max: 1, step: 0.02
   * @default 0.34
   */
  focusWidth?: number;
  /**
   * Rest opacity
   * Range: min: 0, max: 1, step: 0.02
   * @default 0.55
   */
  restOpacity?: number;
  /**
   * Dim opacity
   * Range: min: 0, max: 1, step: 0.02
   * @default 0.22
   */
  dimOpacity?: number;
  /**
   * Colour — pass as `colorMode` not `colour`.
   * Options: "none" | "grayscale" | "tint"
   * @default "grayscale"
   */
  colorMode?: 'none' | 'grayscale' | 'tint';
  /**
   * Tint — pass as `tintColor` not `tint`.
   * @default "#514A49"
   */
  tintColor?: string;
  /**
   * Amount — pass as `treatAmount` not `amount`.
   * Range: min: 0, max: 1, step: 0.05
   * @default 1
   */
  treatAmount?: number;
  /**
   * Reveal hover — pass as `hoverReveal` not `revealHover`.
   * @default true
   */
  hoverReveal?: boolean;
  /**
   * Item — pass as `itemStyle` not `item`.
   * Options: "bare" | "chip" | "card"
   * @default "bare"
   */
  itemStyle?: 'bare' | 'chip' | 'card';
  /**
   * Item fill
   * @default "#FFFCFA"
   */
  itemFill?: string;
  /**
   * Item border — pass as `itemBorderColor` not `itemBorder`.
   * @default "#D5CBCA"
   */
  itemBorderColor?: string;
  /**
   * Item radius
   * Range: min: 0, max: 40
   * @default 16
   */
  itemRadius?: number;
  /**
   * Item pad X
   * Range: min: 0, max: 60
   * @default 22
   */
  itemPadX?: number;
  /**
   * Item pad Y
   * Range: min: 0, max: 40
   * @default 12
   */
  itemPadY?: number;
  /**
   * Highlight — pass as `useHot` not `highlight`.
   * @default true
   */
  useHot?: boolean;
  /**
   * Highlight fill — pass as `hotFill` not `highlightFill`.
   * @default "#EFFF63"
   */
  hotFill?: string;
  /**
   * Text — pass as `labelColor` not `text`.
   * @default "#1A1F18"
   */
  labelColor?: string;
  /**
   * Background — pass as `bg` not `background`.
   * @default "rgba(0,0,0,0)"
   */
  bg?: string;
  /**
   * Radius
   * Range: min: 0, max: 80
   * @default 24
   */
  radius?: number;
  /**
   * Border — pass as `borderWidth` not `border`.
   * Range: min: 0, max: 6
   * @default 0
   */
  borderWidth?: number;
  /**
   * Border color
   * @default "#D5CBCA"
   */
  borderColor?: string;
  /**
   * Edge fade — pass as `fade` not `edgeFade`.
   * @default true
   */
  fade?: boolean;
  /**
   * Fade — pass as `fadeAmount` not `fade`.
   * Range: min: 0, max: 30
   * @default 10
   */
  fadeAmount?: number;
  /** Additional properties */
  [key: string]: unknown;
}
