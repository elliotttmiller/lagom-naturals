/**
 * Props for Rayo02hero component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Rayo02heroProps {
  [key: string]: unknown;
}
