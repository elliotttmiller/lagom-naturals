var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/ken04bkaZXr26wbHjki9/uOuT3u8DtB4Et9QePHKr/ImageHotspot.js
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState, useRef, useCallback, useEffect, startTransition } from "react";
import { addPropertyControls, ControlType } from "./_framer-runtime.js";
import { motion, AnimatePresence } from "framer-motion";
var DEFAULT_COLOR = "#111111";
var CARD_W = 196;
var CARD_H = 190;
function hotspotIsVisible(h) {
  return !!(h.title?.trim() || h.description?.trim() || h.price?.trim());
}
function computeCardPosition(x, y, containerWidth, containerHeight) {
  const GAP = 10;
  const pxX = x / 100 * containerWidth;
  const pxY = y / 100 * containerHeight;
  const pos = {};
  if (containerWidth - pxX >= CARD_W + GAP) {
    pos.left = `calc(${x}% + ${GAP}px)`;
  } else if (pxX >= CARD_W + GAP) {
    pos.right = `calc(${100 - x}% + ${GAP}px)`;
  } else {
    const clamped = Math.max(GAP, Math.min(pxX - CARD_W / 2, containerWidth - CARD_W - GAP));
    pos.left = `${clamped}px`;
  }
  if (containerHeight - pxY >= CARD_H + GAP) {
    pos.top = `calc(${y}% + ${GAP}px)`;
  } else if (pxY >= CARD_H + GAP) {
    pos.bottom = `calc(${100 - y}% + ${GAP}px)`;
  } else {
    const clamped = Math.max(GAP, Math.min(pxY - CARD_H / 2, containerHeight - CARD_H - GAP));
    pos.top = `${clamped}px`;
  }
  return pos;
}
function pulseRingStyle(color, size, delay) {
  return { position: "absolute", top: "50%", left: "50%", width: size, height: size, borderRadius: "50%", background: color, opacity: 0, transform: "translate(-50%, -50%)", animation: `hs-pulse 2.6s ease-out ${delay}s infinite`, pointerEvents: "none" };
}
function HotspotMarker({ hotspot, index, isOpen, markerSize, pulseAnimation, onClick }) {
  const borderWidth = Math.max(1, markerSize * 0.08);
  const iconSize = markerSize * 0.38;
  const strokeW = Math.max(1, markerSize * 0.09);
  const shadowSpread = Math.max(1, Math.round(markerSize * 0.1));
  const handleKeyDown = (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      onClick(index);
    }
  };
  return /* @__PURE__ */ _jsxs("div", { style: { position: "absolute", left: `${hotspot.x}%`, top: `${hotspot.y}%`, transform: "translate(-50%, -50%)", zIndex: isOpen ? 30 : 20, pointerEvents: "none" }, children: [pulseAnimation && !isOpen && /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsx("span", { style: pulseRingStyle(hotspot.markerColor, markerSize, 0) }), /* @__PURE__ */ _jsx("span", { style: pulseRingStyle(hotspot.markerColor, markerSize, 0.5) })] }), /* @__PURE__ */ _jsx(motion.button, { "aria-label": `Hotspot: ${hotspot.title || "Unnamed"}`, "aria-expanded": isOpen, onClick: () => onClick(index), onKeyDown: handleKeyDown, whileHover: { scale: 1.18 }, whileTap: { scale: 0.88 }, animate: isOpen ? { scale: 1.15, rotate: 45 } : { scale: 1, rotate: 0 }, transition: { type: "spring", stiffness: 420, damping: 24 }, style: { position: "relative", width: markerSize, height: markerSize, borderRadius: "50%", background: hotspot.markerColor, border: `${borderWidth}px solid rgba(255,255,255,0.88)`, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 0 ${shadowSpread}px rgba(0,0,0,0.10), 0 ${shadowSpread}px ${shadowSpread * 3}px rgba(0,0,0,0.22)`, pointerEvents: "auto", outline: "none", flexShrink: 0, padding: 0 }, children: /* @__PURE__ */ _jsxs("svg", { width: iconSize, height: iconSize, viewBox: "0 0 12 12", fill: "none", "aria-hidden": "true", style: { display: "block", flexShrink: 0 }, children: [/* @__PURE__ */ _jsx("line", { x1: "6", y1: "1", x2: "6", y2: "11", stroke: "white", strokeWidth: strokeW, strokeLinecap: "round" }), /* @__PURE__ */ _jsx("line", { x1: "1", y1: "6", x2: "11", y2: "6", stroke: "white", strokeWidth: strokeW, strokeLinecap: "round" })] }) })] });
}
function InfoCard({ hotspot, position, onClose }) {
  const handleKeyDown = (e) => {
    if (e.key === "Escape")
      onClose();
  };
  return /* @__PURE__ */ _jsxs(motion.div, { role: "dialog", "aria-label": hotspot.title || "Hotspot info", "aria-modal": "false", onKeyDown: handleKeyDown, initial: { opacity: 0, scale: 0.9, y: 4 }, animate: { opacity: 1, scale: 1, y: 0 }, exit: { opacity: 0, scale: 0.9, y: 4 }, transition: { type: "spring", stiffness: 420, damping: 28 }, style: { position: "absolute", ...position, zIndex: 40, width: CARD_W, background: "rgba(255,255,255,0.96)", backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", borderRadius: 10, boxShadow: "0 6px 24px rgba(0,0,0,0.14), 0 1px 4px rgba(0,0,0,0.08)", overflow: "hidden", fontFamily: "inherit", pointerEvents: "auto" }, children: [/* @__PURE__ */ _jsx("div", { style: { height: 2.5, background: hotspot.markerColor } }), /* @__PURE__ */ _jsxs("div", { style: { padding: "11px 13px 13px" }, children: [/* @__PURE__ */ _jsxs("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 6, marginBottom: 5 }, children: [hotspot.title?.trim() && /* @__PURE__ */ _jsx("span", { style: { fontSize: 13, fontWeight: 700, color: "#111", lineHeight: 1.3, flex: 1 }, children: hotspot.title }), /* @__PURE__ */ _jsx("button", { onClick: onClose, "aria-label": "Close", style: { width: 18, height: 18, borderRadius: "50%", border: "none", background: "#ebebeb", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, padding: 0 }, children: /* @__PURE__ */ _jsxs("svg", { width: "8", height: "8", viewBox: "0 0 10 10", fill: "none", "aria-hidden": "true", children: [/* @__PURE__ */ _jsx("line", { x1: "1", y1: "1", x2: "9", y2: "9", stroke: "#555", strokeWidth: "1.8", strokeLinecap: "round" }), /* @__PURE__ */ _jsx("line", { x1: "9", y1: "1", x2: "1", y2: "9", stroke: "#555", strokeWidth: "1.8", strokeLinecap: "round" })] }) })] }), hotspot.price?.trim() && /* @__PURE__ */ _jsx("div", { style: { fontSize: 14, fontWeight: 700, color: hotspot.markerColor, marginBottom: 6, letterSpacing: "-0.01em" }, children: hotspot.price }), hotspot.description?.trim() && /* @__PURE__ */ _jsx("p", { style: { fontSize: 11.5, color: "#555", lineHeight: 1.55, margin: "0 0 10px" }, children: hotspot.description }), hotspot.ctaText?.trim() && /* @__PURE__ */ _jsx("a", { href: hotspot.ctaLink || "#", target: "_blank", rel: "noopener noreferrer", style: { display: "block", textAlign: "center", padding: "6.5px 10px", borderRadius: 6, background: hotspot.markerColor, color: "#fff", fontSize: 11.5, fontWeight: 600, textDecoration: "none", letterSpacing: "0.01em", transition: "opacity 0.15s ease" }, onMouseEnter: (e) => e.currentTarget.style.opacity = "0.8", onMouseLeave: (e) => e.currentTarget.style.opacity = "1", children: hotspot.ctaText })] })] });
}
function ImageHotspot(props) {
  const { image, imageAlt, imageLoading, hotspots = [], markerSize, pulseAnimation, style } = props;
  const [openIndex, setOpenIndex] = useState(null);
  const containerRef = useRef(null);
  const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
  const visibleHotspots = hotspots.map((hotspot, originalIndex) => ({ hotspot, originalIndex })).filter(({ hotspot }) => hotspotIsVisible(hotspot));
  useEffect(() => {
    const el = containerRef.current;
    if (!el)
      return;
    const update = () => startTransition(() => setContainerSize({ width: el.offsetWidth, height: el.offsetHeight }));
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const handleContainerClick = useCallback((e) => {
    const target = e.target;
    if (!target.closest("[data-hotspot-marker]") && !target.closest("[data-hotspot-card]")) {
      startTransition(() => setOpenIndex(null));
    }
  }, []);
  const handleMarkerClick = useCallback((index) => {
    startTransition(() => setOpenIndex((prev) => prev === index ? null : index));
  }, []);
  const handleClose = useCallback(() => {
    startTransition(() => setOpenIndex(null));
  }, []);
  const handleKeyDown = useCallback((e) => {
    if (e.key === "Escape")
      startTransition(() => setOpenIndex(null));
  }, []);
  const activeEntry = openIndex !== null ? visibleHotspots.find((v) => v.originalIndex === openIndex) : null;
  return /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsx("style", { children: `
                @keyframes hs-pulse {
                    0%   { transform: translate(-50%,-50%) scale(1);   opacity: 0.5; }
                    80%  { transform: translate(-50%,-50%) scale(2.8); opacity: 0;   }
                    100% { transform: translate(-50%,-50%) scale(2.8); opacity: 0;   }
                }
            ` }), /* @__PURE__ */ _jsxs("div", { ref: containerRef, onClick: handleContainerClick, onKeyDown: handleKeyDown, role: "region", "aria-label": "Interactive image with hotspots", style: { position: "relative", width: "100%", height: "100%", overflow: "hidden", borderRadius: style?.borderRadius ?? 0, ...style, cursor: "default", userSelect: "none" }, children: [image ? /* @__PURE__ */ _jsx("img", { src: image, alt: imageAlt || "", loading: imageLoading, style: { display: "block", width: "100%", height: "100%", objectFit: "cover", pointerEvents: "none", userSelect: "none" }, draggable: false }) : /* @__PURE__ */ _jsxs("div", { style: { width: "100%", height: "100%", background: "linear-gradient(135deg, #e8eaed 0%, #d1d5db 100%)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, color: "#9ca3af" }, children: [/* @__PURE__ */ _jsxs("svg", { width: "36", height: "36", viewBox: "0 0 40 40", fill: "none", "aria-hidden": "true", children: [/* @__PURE__ */ _jsx("rect", { x: "4", y: "4", width: "32", height: "32", rx: "4", stroke: "currentColor", strokeWidth: "1.5" }), /* @__PURE__ */ _jsx("circle", { cx: "15", cy: "15", r: "3", fill: "currentColor" }), /* @__PURE__ */ _jsx("path", { d: "M4 28l9-9 6 6 5-5 12 8", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" })] }), /* @__PURE__ */ _jsx("span", { style: { fontSize: 12, fontWeight: 500 }, children: "Upload an image" })] }), visibleHotspots.map(({ hotspot, originalIndex }) => /* @__PURE__ */ _jsx("div", { "data-hotspot-marker": "true", children: /* @__PURE__ */ _jsx(HotspotMarker, { hotspot, index: originalIndex, isOpen: openIndex === originalIndex, markerSize, pulseAnimation, onClick: handleMarkerClick }) }, originalIndex)), /* @__PURE__ */ _jsx(AnimatePresence, { children: activeEntry && /* @__PURE__ */ _jsx("div", { "data-hotspot-card": "true", children: /* @__PURE__ */ _jsx(InfoCard, { hotspot: activeEntry.hotspot, position: computeCardPosition(activeEntry.hotspot.x, activeEntry.hotspot.y, containerSize.width, containerSize.height), onClose: handleClose }) }, activeEntry.originalIndex) })] })] });
}
ImageHotspot.defaultProps = { image: "", imageAlt: "", imageLoading: "lazy", markerSize: 18, pulseAnimation: true, hotspots: [{ title: "Product Name", description: "A short description of this item.", price: "$99", ctaText: "Shop Now", ctaLink: "https://example.com", x: 30, y: 40, markerColor: DEFAULT_COLOR }, { title: "Another Item", description: "Describe what makes this special.", price: "$149", ctaText: "Learn More", ctaLink: "https://example.com", x: 65, y: 60, markerColor: DEFAULT_COLOR }] };
addPropertyControls(ImageHotspot, {
  // Image
  image: { type: ControlType.Image, title: "Image" },
  imageAlt: { type: ControlType.String, title: "Alt Text", placeholder: "Describe the image\u2026", defaultValue: "" },
  imageLoading: { type: ControlType.Enum, title: "Loading", options: ["lazy", "eager"], optionTitles: ["Lazy", "Eager"], defaultValue: "lazy" },
  // Marker
  markerSize: { type: ControlType.Number, title: "Marker Size", min: 12, max: 48, step: 1, defaultValue: 18 },
  pulseAnimation: { type: ControlType.Boolean, title: "Pulse", defaultValue: true, enabledTitle: "On", disabledTitle: "Off" },
  // Hotspots
  hotspots: { type: ControlType.Array, title: "Hotspots", control: { type: ControlType.Object, controls: { title: { type: ControlType.String, title: "Title", defaultValue: "Product Name" }, price: { type: ControlType.String, title: "Price", defaultValue: "$99", placeholder: "$0.00" }, description: { type: ControlType.String, title: "Description", displayTextArea: true, defaultValue: "A short description of this item." }, ctaText: { type: ControlType.String, title: "CTA Text", defaultValue: "Shop Now", placeholder: "Shop Now" }, ctaLink: { type: ControlType.Link, title: "CTA Link" }, x: { type: ControlType.Number, title: "X (%)", min: 0, max: 100, step: 0.5, defaultValue: 30, description: "Horizontal position (% of image width)" }, y: { type: ControlType.Number, title: "Y (%)", min: 0, max: 100, step: 0.5, defaultValue: 40, description: "Vertical position (% of image height)" }, markerColor: { type: ControlType.Color, title: "Color", defaultValue: "#111111" } } }, defaultValue: [{ title: "Product Name", description: "A short description of this item.", price: "$99", ctaText: "Shop Now", ctaLink: "https://example.com", x: 30, y: 40, markerColor: "#111111" }, { title: "Another Item", description: "Describe what makes this special.", price: "$149", ctaText: "Learn More", ctaLink: "https://example.com", x: 65, y: 60, markerColor: "#111111" }] }
});
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "ImageHotspot", "slots": [], "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  ImageHotspot as default
};
