export interface ImagehotspotProps {
  /**
   * Image
   */
  image?: string;
  /**
   * Alt Text — pass as `imageAlt` not `altText`.
   * @default ""
   */
  imageAlt?: string;
  /**
   * Loading — pass as `imageLoading` not `loading`.
   * Options: "lazy" | "eager"
   * @default "lazy"
   */
  imageLoading?: 'lazy' | 'eager';
  /**
   * Marker Size
   * Range: min: 12, max: 48, step: 1
   * @default 18
   */
  markerSize?: number;
  /**
   * Pulse — pass as `pulseAnimation` not `pulse`.
   * @default true
   */
  pulseAnimation?: boolean;
  /**
   * Hotspots
   * @default [{"title":"Product Name","description":"A short description of this item.","price":"$99","ctaText":"Shop Now","ctaLink":"https://example.com","x":30,"y":40,"markerColor":"#111111"},{"title":"Another Item","description":"Describe what makes this special.","price":"$149","ctaText":"Learn More","ctaLink":"https://example.com","x":65,"y":60,"markerColor":"#111111"}]
   */
  hotspots?: unknown[];
  /** Additional properties */
  [key: string]: unknown;
}
