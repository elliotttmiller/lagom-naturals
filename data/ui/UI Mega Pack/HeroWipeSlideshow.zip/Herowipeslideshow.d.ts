export interface HerowipeslideshowProps {
  /**
   * Images
   * @default [{},{},{}]
   */
  images?: unknown[];
  /**
   * Brightness — pass as `imageBrightness` not `brightness`.
   * Range: min: 0, max: 2, step: 0.01
   * @default 1
   */
  imageBrightness?: number;
  /**
   * Image Mask — pass as `imageMaskEnabled` not `imageMask`.
   * @default false
   */
  imageMaskEnabled?: boolean;
  /**
   * Mask Type — pass as `imageMaskType` not `maskType`.
   * Options: "none" | "vignette" | "linearLeft" | "linearRight" | "linearTop" | "linearBottom"
   * @default "vignette"
   */
  imageMaskType?: 'none' | 'vignette' | 'linearLeft' | 'linearRight' | 'linearTop' | 'linearBottom';
  /**
   * Mask Edge — pass as `imageMaskEdge` not `maskEdge`.
   * Range: min: 0, max: 100, step: 1
   * @default 20
   */
  imageMaskEdge?: number;
  /**
   * Autoplay
   * @default true
   */
  autoplay?: boolean;
  /**
   * Interval
   * Range: min: 1, max: 20, step: 0.5
   * @default 4
   */
  interval?: number;
  /**
   * Duration
   * Range: min: 0.15, max: 3, step: 0.05
   * @default 0.9
   */
  duration?: number;
  /**
   * Easing
   * Options: "easeInOut" | "easeOut" | "easeIn" | "linear" | "custom"
   * @default "easeInOut"
   */
  easing?: 'easeInOut' | 'easeOut' | 'easeIn' | 'linear' | 'custom';
  /**
   * Custom Bezier
   */
  customBezier?: Record<string, unknown>;
  /**
   * Wipe — pass as `direction` not `wipe`.
   * Options: "leftToRight" | "rightToLeft"
   * @default "leftToRight"
   */
  direction?: 'leftToRight' | 'rightToLeft';
  /**
   * Radius — pass as `borderRadius` not `radius`.
   * @default "16px"
   */
  borderRadius?: string;
  /**
   * Padding
   * @default "0px"
   */
  padding?: string;
  /**
   * Background — pass as `backgroundColor` not `background`.
   * @default "#FFFFFF"
   */
  backgroundColor?: string;
  /**
   * Controls — pass as `showControls` not `controls`.
   * @default true
   */
  showControls?: boolean;
  /**
   * Position — pass as `controlsPosition` not `position`.
   * Options: "bottomLeft" | "bottomCenter" | "bottomRight" | "topLeft" | "topCenter" | "topRight"
   * @default "bottomRight"
   */
  controlsPosition?: 'bottomLeft' | 'bottomCenter' | 'bottomRight' | 'topLeft' | 'topCenter' | 'topRight';
  /**
   * Ctrl Padding — pass as `controlsPadding` not `ctrlPadding`.
   * @default "12px"
   */
  controlsPadding?: string;
  /**
   * Controls — pass as `controlsVisibility` not `controls`.
   * Options: "hover" | "always"
   * @default "hover"
   */
  controlsVisibility?: 'hover' | 'always';
  /**
   * Icon — pass as `controlColor` not `icon`.
   * @default "#000000"
   */
  controlColor?: string;
  /**
   * Button BG — pass as `controlBackground` not `buttonBg`.
   * @default "rgba(255,255,255,0.75)"
   */
  controlBackground?: string;
  /**
   * Btn Radius — pass as `controlRadius` not `btnRadius`.
   * Range: min: 0, max: 999, step: 1
   * @default 999
   */
  controlRadius?: number;
  /**
   * Btn Size — pass as `controlSize` not `btnSize`.
   * Range: min: 28, max: 72, step: 1
   * @default 44
   */
  controlSize?: number;
  /**
   * Hover Scale — pass as `controlHoverScale` not `hoverScale`.
   * Range: min: 0.8, max: 1.2, step: 0.01
   * @default 1.04
   */
  controlHoverScale?: number;
  /**
   * Hover Opacity — pass as `controlHoverOpacity` not `hoverOpacity`.
   * Range: min: 0, max: 1, step: 0.01
   * @default 1
   */
  controlHoverOpacity?: number;
  /** Additional properties */
  [key: string]: unknown;
}
