var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/zxcGfQb3lPhoJOWc1HTU/UHrEi0qhIpd3yrAh6Rk2/ParallaxImage_prod.js
import { jsx as _jsx3, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2, RenderTarget } from "./_framer-runtime.js";
import { useRef as useRef2, useLayoutEffect } from "react";

// http-url:https://framerusercontent.com/modules/aej5zpwxBpkMdzOteBwy/DWeAZ5wauvGM5oFwVdgS/Utils.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { cloneElement } from "react";

// http-url:https://framerusercontent.com/modules/fMDE7Cqb2uOvQFAHEP2m/cRfVFRl0izzBulKFjOAe/W7oLCU4_B.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls, ControlType, cx, RichText, SVG, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React from "react";
var serializationHash = "framer-q8Ttd";
var variantClassNames = { XvqTw0Be9: "framer-v-jjcw9a" };
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value !== null && value !== void 0 ? value : config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion(React.Fragment);
var getProps = ({ height, id, subtitle, title, width, ...props }) => {
  var _ref, _ref1;
  return { ...props, WuF2iG84P: (_ref = subtitle !== null && subtitle !== void 0 ? subtitle : props.WuF2iG84P) !== null && _ref !== void 0 ? _ref : "Set up the component by adding background and bouncer elements to the component properties.", yeAnKbEUZ: (_ref1 = title !== null && title !== void 0 ? title : props.yeAnKbEUZ) !== null && _ref1 !== void 0 ? _ref1 : "Screen Saver" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { activeLocale, setLocale } = useLocaleInfo();
  const { style, className, layoutId, variant, yeAnKbEUZ, WuF2iG84P, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "XvqTw0Be9", variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const ref1 = React.useRef(null);
  const defaultLayoutId = React.useId();
  const sharedStyleClassNames = [];
  const componentViewport = useComponentViewport();
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId !== null && layoutId !== void 0 ? layoutId : defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsx(motion.div, { ...restProps, ...gestureHandlers, className: cx(serializationHash, ...sharedStyleClassNames, "framer-jjcw9a", className, classNames), "data-framer-name": "Default", layoutDependency, layoutId: "ParallaxImageprod__XvqTw0Be9", ref: ref !== null && ref !== void 0 ? ref : ref1, style: { backgroundColor: "rgba(136, 85, 255, 0.1)", ...style }, children: /* @__PURE__ */ _jsxs(motion.div, { className: "framer-uh2i08", layoutDependency, layoutId: "ParallaxImageprod__aM7oiNoFL", children: [/* @__PURE__ */ _jsx(SVG, { className: "framer-flw0dh", "data-framer-name": "Logo", layout: "position", layoutDependency, layoutId: "ParallaxImageprod__GthLmGmBt", opacity: 1, svg: '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 28 28"><g id="ss11036020200_1"><path d="M 0 0 L 28 0 L 28 28 L 0 28 Z" fill="transparent"></path><path d="M 21 7.113 C 21 7.041 21.029 6.971 21.079 6.921 L 27.534 0.465 C 27.613 0.388 27.73 0.365 27.831 0.407 C 27.933 0.449 28 0.548 28 0.658 L 28 13.888 C 28 13.96 27.971 14.028 27.921 14.079 L 21 21 Z M 7 21 L 7 7.658 C 7 7.548 6.933 7.449 6.831 7.407 C 6.73 7.365 6.613 7.388 6.534 7.465 L 0.079 13.921 C 0.028 13.972 0 14.041 0 14.113 L 0 27.728 C 0 27.877 0.122 28 0.273 28 L 13.888 28 C 13.96 28 14.028 27.971 14.079 27.921 L 21 21 Z" fill="rgb(153, 102, 255)"></path></g></svg>', svgContentId: 11036020200, withExternalLayout: true }), /* @__PURE__ */ _jsxs(motion.div, { className: "framer-k3ullq", layoutDependency, layoutId: "ParallaxImageprod__E3DQBYSAf", children: [/* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.p, { style: { "--font-selector": "SW50ZXItQm9sZA==", "--framer-font-family": '"Inter", "Inter Placeholder", sans-serif', "--framer-font-size": "11px", "--framer-font-weight": "700", "--framer-letter-spacing": "-0.02em", "--framer-line-height": "1em", "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, rgb(153, 102, 255))" }, children: "Screen Saver" }) }), className: "framer-q0gs4u", "data-framer-name": "Title", fonts: ["Inter-Bold"], layoutDependency, layoutId: "ParallaxImageprod__UqJwZqJjg", style: { "--extracted-r6o4lv": "rgb(153, 102, 255)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: yeAnKbEUZ, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.p, { style: { "--framer-font-size": "11px", "--framer-letter-spacing": "-0.03em", "--framer-line-height": "1.4em", "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, rgba(153, 102, 255, 0.7))" }, children: "Set up the component by adding background and bouncer elements to the component properties." }) }), className: "framer-g5dqhc", "data-framer-name": "Subtitle", fonts: ["Inter"], layoutDependency, layoutId: "ParallaxImageprod__RJ7UF99m8", style: { "--extracted-r6o4lv": "rgba(153, 102, 255, 0.7)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: WuF2iG84P, verticalAlignment: "top", withExternalLayout: true })] })] }) }) }) }) });
});
var css = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-q8Ttd.framer-qanqo2, .framer-q8Ttd .framer-qanqo2 { display: block; }", ".framer-q8Ttd.framer-jjcw9a { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: auto; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-q8Ttd .framer-uh2i08 { align-content: center; align-items: center; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: center; overflow: hidden; padding: 0px 20px 0px 20px; position: relative; width: 1px; }", ".framer-q8Ttd .framer-flw0dh { flex: none; height: 28px; position: relative; width: 28px; }", ".framer-q8Ttd .framer-k3ullq { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 12px; height: min-content; justify-content: center; max-width: 200px; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-q8Ttd .framer-q0gs4u, .framer-q8Ttd .framer-g5dqhc { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", "@supports (background: -webkit-named-image(i)) and (not (font-palette:dark)) { .framer-q8Ttd.framer-jjcw9a, .framer-q8Ttd .framer-uh2i08, .framer-q8Ttd .framer-k3ullq { gap: 0px; } .framer-q8Ttd.framer-jjcw9a > * { margin: 0px; margin-left: calc(10px / 2); margin-right: calc(10px / 2); } .framer-q8Ttd.framer-jjcw9a > :first-child { margin-left: 0px; } .framer-q8Ttd.framer-jjcw9a > :last-child { margin-right: 0px; } .framer-q8Ttd .framer-uh2i08 > * { margin: 0px; margin-bottom: calc(16px / 2); margin-top: calc(16px / 2); } .framer-q8Ttd .framer-uh2i08 > :first-child, .framer-q8Ttd .framer-k3ullq > :first-child { margin-top: 0px; } .framer-q8Ttd .framer-uh2i08 > :last-child, .framer-q8Ttd .framer-k3ullq > :last-child { margin-bottom: 0px; } .framer-q8Ttd .framer-k3ullq > * { margin: 0px; margin-bottom: calc(12px / 2); margin-top: calc(12px / 2); } }"];
var FramerW7oLCU4_B = withCSS(Component, css, "framer-q8Ttd");
var W7oLCU4_B_default = FramerW7oLCU4_B;
FramerW7oLCU4_B.displayName = "Utils/Component Message";
FramerW7oLCU4_B.defaultProps = { height: 200, width: 400 };
addPropertyControls(FramerW7oLCU4_B, { yeAnKbEUZ: { defaultValue: "Screen Saver", displayTextArea: false, title: "Title", type: ControlType.String }, WuF2iG84P: { defaultValue: "Set up the component by adding background and bouncer elements to the component properties.", displayTextArea: false, title: "Subtitle", type: ControlType.String } });
addFonts(FramerW7oLCU4_B, [{ explicitInter: true, fonts: [{ family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/DpPBYI0sL4fYLgAkX8KXOPVt7c.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/4RAEQdEOrcnDkhHiiCbJOw92Lk.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/1K3W8DizY3v4emK8Mb08YHxTbs.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/tUSCtfYVM1I1IchuyCwz9gDdQ.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/VgYFWiwsAC5OYxAycRXXvhze58.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/DXD0Q7LSl7HEvDzucnyLnGBHM.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/GIryZETIX4IFypco5pYZONKhJIo.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/vQyevYAyHtARFwPqUzQGpnDs.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/aej5zpwxBpkMdzOteBwy/DWeAZ5wauvGM5oFwVdgS/Utils.js
var ComponentMessage = ({ title, subtitle, style }) => {
  return /* @__PURE__ */ _jsx2(W7oLCU4_B_default, { yeAnKbEUZ: title, WuF2iG84P: subtitle, style: { width: "100%", height: "100%", ...style } });
};

// http-url:https://framerusercontent.com/modules/zxcGfQb3lPhoJOWc1HTU/UHrEi0qhIpd3yrAh6Rk2/ParallaxImage_prod.js
function ImageParallax(props) {
  const { verticalParallaxAmount = 50, horizontalParallaxAmount = 0, image, style, borderRadius = 0, border, boxShadow } = props;
  const containerRef = useRef2(null);
  const imageRef = useRef2(null);
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  useLayoutEffect(() => {
    if (isCanvas)
      return;
    if (!containerRef.current || !imageRef.current)
      return;
    const container = containerRef.current;
    const image2 = imageRef.current;
    image2.style.transform = "translate3d(0, 0, 0)";
    image2.style.willChange = "transform";
    let rafId = null;
    let ticking = false;
    let animationFrameId = null;
    const updateParallax = () => {
      if (!container || !image2)
        return;
      const rect = container.getBoundingClientRect();
      const containerHeight = container.offsetHeight;
      const containerWidth = container.offsetWidth;
      if (containerHeight === 0 || containerWidth === 0)
        return;
      const viewportHeight = __dai_window.innerHeight;
      const scrollProgress = Math.max(0, Math.min(1, (viewportHeight - rect.top) / (viewportHeight + containerHeight)));
      const yOffset = (scrollProgress - 0.5) * (verticalParallaxAmount / 100) * containerHeight;
      let xOffset = 0;
      if (horizontalParallaxAmount !== 0) {
        const viewportWidth = __dai_window.innerWidth;
        const viewportCenter = viewportWidth / 2;
        const elementCenter = rect.left + rect.width / 2;
        const horizontalProgress = (elementCenter - viewportCenter) / viewportWidth;
        xOffset = horizontalProgress * (horizontalParallaxAmount / 100) * containerWidth;
      }
      image2.style.transform = `translate3d(${xOffset}px, ${yOffset}px, 0)`;
      ticking = false;
    };
    const requestTick = () => {
      if (!ticking) {
        rafId = requestAnimationFrame(updateParallax);
        ticking = true;
      }
    };
    const startAnimationLoop = () => {
      if (horizontalParallaxAmount !== 0) {
        const animate = () => {
          updateParallax();
          animationFrameId = requestAnimationFrame(animate);
        };
        animationFrameId = requestAnimationFrame(animate);
      }
    };
    const stopAnimationLoop = () => {
      if (animationFrameId !== null) {
        cancelAnimationFrame(animationFrameId);
        animationFrameId = null;
      }
    };
    const handleScroll = () => {
      requestTick();
    };
    const handleResize = () => {
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
      }
      rafId = requestAnimationFrame(updateParallax);
    };
    updateParallax();
    startAnimationLoop();
    __dai_window.addEventListener("scroll", handleScroll, { passive: true });
    __dai_window.addEventListener("resize", handleResize, { passive: true });
    return () => {
      stopAnimationLoop();
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
      }
      __dai_window.removeEventListener("scroll", handleScroll);
      __dai_window.removeEventListener("resize", handleResize);
    };
  }, [verticalParallaxAmount, horizontalParallaxAmount, isCanvas]);
  const imageSrc = image?.src || (typeof image === "string" ? image : null);
  const hasImage = !!imageSrc;
  return /* @__PURE__ */ _jsxs2("div", { ref: containerRef, style: { ...style, position: "relative", overflow: "hidden", width: "100%", height: "100%", borderRadius, boxShadow: boxShadow || void 0 }, children: [hasImage && /* @__PURE__ */ _jsx3("div", { style: { width: "100%", zIndex: 1e3, height: "100%", borderRadius, position: "absolute", top: 0, left: 0, right: 0, bottom: 0, ...border || {} } }), !hasImage ? /* @__PURE__ */ _jsx3(ComponentMessage, { style: { position: "relative", width: "100%", height: "100%", minWidth: 0, minHeight: 0 }, title: "Image Parallax", subtitle: "Add an image to create a parallax effect that moves as you scroll" }) : isCanvas ? (
    // Canvas mode: simple responsive image, no parallax
    /* @__PURE__ */ _jsx3("img", { src: imageSrc, alt: "", style: { width: "100%", height: "100%", objectFit: "cover", borderRadius, userSelect: "none", pointerEvents: "none" } })
  ) : (
    // Preview/Live mode: render parallax effect
    // Extend beyond boundaries to allow room for parallax movement
    /* @__PURE__ */ _jsx3("div", { ref: imageRef, style: {
      position: "absolute",
      // ALWAYS center the image by extending equally on both sides
      // This ensures the image is centered when element is centered, regardless of parallax direction
      // The sign of parallax only affects the direction of movement, not the centering
      top: `-${Math.abs(verticalParallaxAmount) / 2}%`,
      left: `-${Math.abs(horizontalParallaxAmount) / 2}%`,
      right: `-${Math.abs(horizontalParallaxAmount) / 2}%`,
      bottom: `-${Math.abs(verticalParallaxAmount) / 2}%`,
      // Always use Math.abs so the image is larger than container regardless of direction
      width: `calc(100% + ${Math.abs(horizontalParallaxAmount)}%)`,
      height: `calc(100% + ${Math.abs(verticalParallaxAmount)}%)`,
      backgroundImage: imageSrc ? `url(${imageSrc})` : void 0,
      backgroundSize: "cover",
      backgroundPosition: image?.positionX && image?.positionY ? `${image.positionX} ${image.positionY}` : "center",
      borderRadius,
      willChange: "transform",
      backfaceVisibility: "hidden",
      userSelect: "none",
      pointerEvents: "none"
    } })
  )] });
}
ImageParallax.defaultProps = { verticalParallaxAmount: 50, horizontalParallaxAmount: 0 };
addPropertyControls2(ImageParallax, {
  image: { type: ControlType2.ResponsiveImage, title: "Image" },
  // Vertical parallax controls (in percentage)
  verticalParallaxAmount: { type: ControlType2.Number, title: "Parallax Y", defaultValue: 30, step: 5, max: 100, min: -100, unit: "%" },
  horizontalParallaxAmount: { type: ControlType2.Number, title: "Parallax X", defaultValue: 0, step: 5, max: 100, min: -100, unit: "%", description: "Only seen if image moves horizontally." },
  border: {
    // @ts-ignore - ControlType.Border exists but may not be in types
    type: ControlType2.Border,
    title: "Border",
    optional: true
  },
  borderRadius: {
    // @ts-ignore - ControlType.BorderRadius exists but may not be in types
    type: ControlType2.BorderRadius,
    title: "Radius",
    defaultValue: 0,
    min: 0,
    max: 100,
    step: 1,
    unit: "px"
  },
  boxShadow: {
    // @ts-ignore - ControlType.BoxShadow exists but may not be in types
    type: ControlType2.BoxShadow,
    title: "Shadow"
  }
});
ImageParallax.displayName = "Image Parallax";
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "ImageParallax", "slots": [], "annotations": { "framerSupportedLayoutWidth": "any-prefer-fixed", "framerContractVersion": "1", "framerIntrinsicHeight": "400", "framerIntrinsicWidth": "300", "framerSupportedLayoutHeight": "any-prefer-fixed", "framerDisableUnlink": "" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  ImageParallax as default
};
