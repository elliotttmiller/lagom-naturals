var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/E2Zqu8A8tF4ixotl4wn8/ASdZ8TQqwy8hcokUBtIQ/ImageSequence.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState, startTransition } from "react";
import { addPropertyControls, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
import { useScroll, useTransform, useInView } from "framer-motion";
function drawImageToCanvas(ctx, canvas, image, fit, positionX, positionY) {
  const cw = canvas.width;
  const ch = canvas.height;
  const iw = image.naturalWidth || image.width;
  const ih = image.naturalHeight || image.height;
  if (!cw || !ch || !iw || !ih)
    return;
  const scale = fit === "cover" ? Math.max(cw / iw, ch / ih) : Math.min(cw / iw, ch / ih);
  const dw = iw * scale;
  const dh = ih * scale;
  const px = Math.max(0, Math.min(100, positionX)) / 100;
  const py = Math.max(0, Math.min(100, positionY)) / 100;
  const dx = (cw - dw) * px;
  const dy = (ch - dh) * py;
  ctx.clearRect(0, 0, cw, ch);
  ctx.drawImage(image, dx, dy, dw, dh);
}
function ImageSequence(props) {
  const { images = [{ src: "https://framerusercontent.com/images/GfGkADagM4KEibNcIiRUWlfrR0.jpg", alt: "Frame 1" }, { src: "https://framerusercontent.com/images/aNsAT3jCvt4zglbWCUoFe33Q.jpg", alt: "Frame 2" }, { src: "https://framerusercontent.com/images/BYnxEV1zjYb9bhWh1IwBZ1ZoS60.jpg", alt: "Frame 3" }, { src: "https://framerusercontent.com/images/2uTNEj5aTl2K3NJaEFWMbnrA.jpg", alt: "Frame 4" }, { src: "https://framerusercontent.com/images/f9RiWoNpmlCMqVRIHz8l8wYfeI.jpg", alt: "Frame 5" }], scrollBehavior = "viewport", sectionId = "", smoothing = 0.1, preloadImages = true, fit = "cover", positionX = 50, positionY = 50 } = props;
  const containerRef = useRef(null);
  const canvasRef = useRef(null);
  const scrollTargetRef = useRef(null);
  const [loadedImages, setLoadedImages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const isStatic = useIsStaticRenderer();
  const isInView = useInView(containerRef, { amount: 0.1 });
  const lastTargetFrameRef = useRef(0);
  const lastCurrentFrameRef = useRef(0);
  useEffect(() => {
    if (scrollBehavior === "scrollSection" && sectionId && typeof document !== "undefined") {
      const element = document.getElementById(sectionId);
      if (element) {
        scrollTargetRef.current = element;
      }
    }
  }, [scrollBehavior, sectionId]);
  const { scrollYProgress } = useScroll(scrollBehavior === "scrollSection" ? { target: scrollTargetRef, offset: ["start end", "end start"] } : void 0);
  const frameIndex = useTransform(scrollYProgress, [0, 1], [0, Math.max(0, images.length - 1)]);
  useEffect(() => {
    if (isStatic || !preloadImages)
      return;
    const imageElements = new Array(images.length);
    let firstLoaded = false;
    const commitLoaded = () => {
      startTransition(() => {
        setLoadedImages([...imageElements]);
      });
    };
    const markFirstLoaded = () => {
      if (firstLoaded)
        return;
      firstLoaded = true;
      startTransition(() => setIsLoading(false));
    };
    images.forEach((img, index) => {
      const imageElement = new Image();
      imageElement.crossOrigin = "anonymous";
      imageElement.decoding = "async";
      imageElement.loading = "eager";
      imageElement.src = img.src;
      imageElement.alt = img.alt || `Frame ${index + 1}`;
      const handleDone = () => {
        imageElements[index] = imageElement;
        if (index === 0)
          markFirstLoaded();
        commitLoaded();
      };
      imageElement.onload = handleDone;
      imageElement.onerror = () => {
        if (index === 0)
          markFirstLoaded();
        commitLoaded();
      };
      imageElements[index] = imageElement;
    });
    return () => {
      imageElements.forEach((img) => {
        if (!img)
          return;
        img.onload = null;
        img.onerror = null;
      });
    };
  }, [images, preloadImages, isStatic]);
  useEffect(() => {
    if (isStatic) {
      const canvas2 = canvasRef.current;
      if (!canvas2)
        return;
      const ctx2 = canvas2.getContext("2d");
      if (!ctx2)
        return;
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = images[0]?.src || "";
      img.onload = () => {
        const dpr2 = typeof __dai_window !== "undefined" ? __dai_window.devicePixelRatio || 1 : 1;
        const rect = canvas2.getBoundingClientRect();
        canvas2.width = Math.max(1, Math.round(rect.width * dpr2));
        canvas2.height = Math.max(1, Math.round(rect.height * dpr2));
        ctx2.setTransform(1, 0, 0, 1, 0, 0);
        drawImageToCanvas(ctx2, canvas2, img, fit, positionX, positionY);
      };
      return;
    }
    if (!preloadImages || loadedImages.length === 0)
      return;
    const canvas = canvasRef.current;
    if (!canvas)
      return;
    const ctx = canvas.getContext("2d");
    if (!ctx)
      return;
    const dpr = typeof __dai_window !== "undefined" ? __dai_window.devicePixelRatio || 1 : 1;
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const nextW = Math.max(1, Math.round(rect.width * dpr));
      const nextH = Math.max(1, Math.round(rect.height * dpr));
      if (canvas.width !== nextW || canvas.height !== nextH) {
        canvas.width = nextW;
        canvas.height = nextH;
      }
      ctx.setTransform(1, 0, 0, 1, 0, 0);
    };
    resize();
    let ro = null;
    if (typeof ResizeObserver !== "undefined") {
      ro = new ResizeObserver(() => resize());
      ro.observe(canvas);
    } else {
      __dai_window.addEventListener("resize", resize);
    }
    let currentFrame = lastCurrentFrameRef.current;
    let targetFrame = lastTargetFrameRef.current;
    let lastDrawnFrame = -1;
    let rafId = null;
    let running = false;
    const requestRender = () => {
      if (running)
        return;
      running = true;
      rafId = requestAnimationFrame(render);
    };
    const unsubscribe = frameIndex.on("change", (latest) => {
      targetFrame = Math.round(latest);
      lastTargetFrameRef.current = targetFrame;
      if (isInView)
        requestRender();
    });
    targetFrame = Math.round(frameIndex.get());
    lastTargetFrameRef.current = targetFrame;
    currentFrame = targetFrame;
    lastCurrentFrameRef.current = currentFrame;
    const render = () => {
      if (!isInView) {
        running = false;
        rafId = null;
        return;
      }
      currentFrame += (targetFrame - currentFrame) * smoothing;
      lastCurrentFrameRef.current = currentFrame;
      const desired = Math.min(Math.round(currentFrame), loadedImages.length - 1);
      if (desired !== lastDrawnFrame) {
        let image = loadedImages[desired];
        if (!image || !image.complete) {
          for (let i = desired; i >= 0; i--) {
            const candidate = loadedImages[i];
            if (candidate && candidate.complete) {
              image = candidate;
              break;
            }
          }
        }
        if (image && image.complete && ctx && canvas) {
          try {
            drawImageToCanvas(ctx, canvas, image, fit, positionX, positionY);
            lastDrawnFrame = desired;
          } catch (error) {
            console.warn("Failed to draw image:", error);
          }
        }
      }
      const delta = Math.abs(targetFrame - currentFrame);
      if (delta > 1e-3) {
        rafId = requestAnimationFrame(render);
        return;
      }
      running = false;
      rafId = null;
    };
    if (isInView)
      requestRender();
    return () => {
      unsubscribe();
      if (rafId != null)
        cancelAnimationFrame(rafId);
      if (ro)
        ro.disconnect();
      if (!ro && typeof __dai_window !== "undefined")
        __dai_window.removeEventListener("resize", resize);
    };
  }, [loadedImages, frameIndex, smoothing, preloadImages, isStatic, images, fit, positionX, positionY, isInView]);
  if (isStatic) {
    return /* @__PURE__ */ _jsx("div", { ref: containerRef, style: { width: "100%", height: "100%", position: "relative", overflow: "hidden" }, children: /* @__PURE__ */ _jsx("canvas", { ref: canvasRef, style: { width: "100%", height: "100%" } }) });
  }
  return /* @__PURE__ */ _jsx("div", { ref: containerRef, style: { width: "100%", height: "100%", position: "relative" }, children: /* @__PURE__ */ _jsxs("div", { style: { position: scrollBehavior === "scrollSection" ? "sticky" : "relative", top: scrollBehavior === "scrollSection" ? "0" : void 0, width: "100%", height: scrollBehavior === "scrollSection" ? "100vh" : "100%", display: "flex", alignItems: "center", justifyContent: "center" }, children: [isLoading && preloadImages && /* @__PURE__ */ _jsx("div", { style: { position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", fontSize: "14px", color: "#999" }, children: "Loading..." }), /* @__PURE__ */ _jsx("canvas", { ref: canvasRef, style: { width: "100%", height: "100%", opacity: isLoading && preloadImages ? 0 : 1, transition: "opacity 0.3s ease" } })] }) });
}
addPropertyControls(ImageSequence, { images: { type: ControlType.Array, control: { type: ControlType.ResponsiveImage }, defaultValue: [{ src: "https://framerusercontent.com/images/GfGkADagM4KEibNcIiRUWlfrR0.jpg", alt: "Frame 1" }, { src: "https://framerusercontent.com/images/aNsAT3jCvt4zglbWCUoFe33Q.jpg", alt: "Frame 2" }, { src: "https://framerusercontent.com/images/BYnxEV1zjYb9bhWh1IwBZ1ZoS60.jpg", alt: "Frame 3" }, { src: "https://framerusercontent.com/images/2uTNEj5aTl2K3NJaEFWMbnrA.jpg", alt: "Frame 4" }, { src: "https://framerusercontent.com/images/f9RiWoNpmlCMqVRIHz8l8wYfeI.jpg", alt: "Frame 5" }], maxCount: 200 }, fit: { type: ControlType.Enum, title: "Fit", options: ["cover", "contain"], optionTitles: ["Fill", "Fit"], defaultValue: "cover", displaySegmentedControl: true }, positionX: { type: ControlType.Number, title: "Pos X", defaultValue: 50, min: 0, max: 100, step: 1, unit: "%" }, positionY: { type: ControlType.Number, title: "Pos Y", defaultValue: 50, min: 0, max: 100, step: 1, unit: "%" }, scrollBehavior: { type: ControlType.Enum, title: "Scroll Behavior", options: ["viewport", "scrollSection"], optionTitles: ["Viewport", "Scroll Section"], defaultValue: "viewport" }, sectionId: { type: ControlType.String, title: "Section ID", defaultValue: "", placeholder: "Enter section ID...", hidden: ({ scrollBehavior }) => scrollBehavior !== "scrollSection" }, smoothing: { type: ControlType.Number, title: "Smoothing", defaultValue: 0.1, min: 0.01, max: 1, step: 0.01 }, preloadImages: { type: ControlType.Boolean, title: "Preload Images", defaultValue: true, enabledTitle: "On", disabledTitle: "Off" } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "ImageSequence", "slots": [], "annotations": { "framerSupportedLayoutHeight": "fixed", "framerSupportedLayoutWidth": "fixed", "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  ImageSequence as default
};
