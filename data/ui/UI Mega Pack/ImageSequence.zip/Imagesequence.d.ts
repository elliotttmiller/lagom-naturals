export interface ImagesequenceProps {
  /**
   * @default [{"src":"https://framerusercontent.com/images/GfGkADagM4KEibNcIiRUWlfrR0.jpg","alt":"Frame 1"},{"src":"https://framerusercontent.com/images/aNsAT3jCvt4zglbWCUoFe33Q.jpg","alt":"Frame 2"},{"src":"https://framerusercontent.com/images/BYnxEV1zjYb9bhWh1IwBZ1ZoS60.jpg","alt":"Frame 3"},{"src":"https://framerusercontent.com/images/2uTNEj5aTl2K3NJaEFWMbnrA.jpg","alt":"Frame 4"},{"src":"https://framerusercontent.com/images/f9RiWoNpmlCMqVRIHz8l8wYfeI.jpg","alt":"Frame 5"}]
   */
  images?: unknown[];
  /**
   * Fit
   * Options: "cover" | "contain"
   * @default "cover"
   */
  fit?: 'cover' | 'contain';
  /**
   * Pos X — pass as `positionX` not `posX`.
   * Range: min: 0, max: 100, step: 1
   * @default 50
   */
  positionX?: number;
  /**
   * Pos Y — pass as `positionY` not `posY`.
   * Range: min: 0, max: 100, step: 1
   * @default 50
   */
  positionY?: number;
  /**
   * Scroll Behavior
   * Options: "viewport" | "scrollSection"
   * @default "viewport"
   */
  scrollBehavior?: 'viewport' | 'scrollSection';
  /**
   * Section ID
   * @default ""
   */
  sectionId?: string;
  /**
   * Smoothing
   * Range: min: 0.01, max: 1, step: 0.01
   * @default 0.1
   */
  smoothing?: number;
  /**
   * Preload Images
   * @default true
   */
  preloadImages?: boolean;
  /** Additional properties */
  [key: string]: unknown;
}
