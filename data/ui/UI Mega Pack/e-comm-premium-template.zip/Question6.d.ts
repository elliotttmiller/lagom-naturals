export interface Question6Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Closed" → LCVxSuvru
   *   "Open" → HGHfFbGiH
   */
  variant?: 'Closed' | 'Open' | 'HGHfFbGiH' | 'LCVxSuvru';
  /**
   * Question — pass as `cGcteGcSe` not `question`.
   * @default "How long does delivery take?"
   */
  cGcteGcSe?: string;
  oncGcteGcSeChange?: string;
  /**
   * Answer — pass as `M0F6TNI_4` not `answer`.
   * @default "Most pieces ship within 3 to 5 business days."
   */
  M0F6TNI_4?: string;
  onM0F6TNI_4Change?: string;
  /** Additional properties */
  [key: string]: unknown;
}
