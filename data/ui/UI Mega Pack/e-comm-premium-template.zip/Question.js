var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/mBREJFWCUcSH5zyPdanW/FPrEXAOS9InnwxaajJ6T/oH9mREbWb.js
import { jsx as _jsx4, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls4, ComponentViewportProvider, ControlType as ControlType4, cx as cx3, CycleVariantState, getFonts, Instance, RichText, SmartComponentScopedContainer, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS3 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion3, MotionConfigContext } from "framer-motion";
import * as React3 from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/8VFsAOycF4H9jkHuRo2W/u2TXyck5C9PqL2g5ao62/vbTtQKoql.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 0 0 L 14 0" fill="transparent" height="1px" id="For6a1EEX" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(5 12)" width="14px"/><path d="M 0 0 L 0 14" fill="transparent" height="14px" id="TzsgOXd8_" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(12 5)" width="1px"/></svg>';
var getProps = ({ color, height, id, width, width1, ...props }) => {
  return { ...props, JEeZYcamG: width1 ?? props.JEeZYcamG ?? 2, P_DcoRcrY: color ?? props.P_DcoRcrY ?? "rgb(0, 0, 0)" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, P_DcoRcrY, JEeZYcamG, ...restProps } = getProps(props);
  const href = useSVGTemplate("3356954461", svg);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-K11hZ", className), layoutId, ref, role: "presentation", style: { "--1m973uw": P_DcoRcrY, "--js9iwy": JEeZYcamG, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx("use", { href }) });
});
var css = [`.framer-K11hZ { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-K11hZ");
Icon.displayName = "Plus";
var vbTtQKoql_default = Icon;
addPropertyControls(Icon, { P_DcoRcrY: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType.Color }, JEeZYcamG: { defaultValue: 2, displayStepper: true, hidden: false, max: 16, min: 1, title: "Width", type: ControlType.Number } });

// http-url:https://framerusercontent.com/modules/g9WOB0484rKXVaZUAQGF/oBKs1cxScUOJxjWmDrN5/TNS_VU02W.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, motion as motion2, useSVGTemplate as useSVGTemplate2, withCSS as withCSS2 } from "./_framer-runtime.js";
import * as React2 from "react";
import { forwardRef as forwardRef4 } from "react";
var mask2 = "var(--framer-icon-mask)";
var Base2 = /* @__PURE__ */ forwardRef4(function(props, ref) {
  return /* @__PURE__ */ _jsx2("svg", { ...props, ref, children: props.children });
});
var MotionSVG2 = motion2.create(Base2);
var SVG2 = /* @__PURE__ */ forwardRef4((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx2(MotionSVG2, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx2("svg", { ...rest, ref, children });
});
var svg2 = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 0 0 L 14 0" fill="transparent" height="1px" id="kRRp1AyBI" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(5 12)" width="14px"/></svg>';
var getProps2 = ({ color, height, id, width, width1, ...props }) => {
  return { ...props, JEeZYcamG: width1 ?? props.JEeZYcamG ?? 2, P_DcoRcrY: color ?? props.P_DcoRcrY ?? "rgb(0, 0, 0)" };
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, P_DcoRcrY, JEeZYcamG, ...restProps } = getProps2(props);
  const href = useSVGTemplate2("1154518178", svg2);
  return /* @__PURE__ */ _jsx2(SVG2, { ...restProps, className: cx2("framer-7jN2T", className), layoutId, ref, role: "presentation", style: { "--1m973uw": P_DcoRcrY, "--js9iwy": JEeZYcamG, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx2("use", { href }) });
});
var css2 = [`.framer-7jN2T { -webkit-mask: ${mask2}; aspect-ratio: 1; display: block; mask: ${mask2}; width: 24px; }`];
var Icon2 = withCSS2(Component2, css2, "framer-7jN2T");
Icon2.displayName = "Minus";
var TNS_VU02W_default = Icon2;
addPropertyControls2(Icon2, { P_DcoRcrY: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType2.Color }, JEeZYcamG: { defaultValue: 2, displayStepper: true, hidden: false, max: 16, min: 1, title: "Width", type: ControlType2.Number } });

// http-url:https://framerusercontent.com/modules/h8ioHyt4BUxuvVCE1Q10/aTM6mEMGlM19JjX8exDe/AvoidLayoutJumping_Prod.js
import { jsx as _jsx3 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls3, ControlType as ControlType3, RenderTarget } from "./_framer-runtime.js";
import { useEffect, useRef } from "react";
function AvoidLayoutJumping({ direction, style }) {
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  const ref = useRef(null);
  const rafId = useRef();
  const vertical = direction === "vertical" || direction === "both";
  const horizontal = direction === "horizontal" || direction === "both";
  useEffect(() => {
    if (isCanvas)
      return;
    const parent = ref.current?.parentElement?.parentElement;
    if (!parent)
      return;
    const container = parent.parentElement;
    if (!container)
      return;
    const updateSize = () => {
      const rect = parent.getBoundingClientRect();
      if (horizontal) {
        container.style.width = `${rect.width}px`;
      }
      if (vertical) {
        container.style.height = `${rect.height}px`;
      }
      rafId.current = requestAnimationFrame(updateSize);
    };
    rafId.current = requestAnimationFrame(updateSize);
    return () => {
      if (rafId.current) {
        cancelAnimationFrame(rafId.current);
      }
      if (container) {
        if (horizontal) {
          container.style.width = "";
        }
        if (vertical) {
          container.style.height = "";
        }
      }
    };
  }, [direction]);
  return /* @__PURE__ */ _jsx3("div", { ref, style: { ...style } });
}
AvoidLayoutJumping.displayName = "Layout Jump Preventer";
addPropertyControls3(AvoidLayoutJumping, { direction: {
  type: ControlType3.Enum,
  defaultValue: "vertical",
  options: ["vertical", "horizontal", "both"],
  optionTitles: ["Vertical", "Horizontal", "Both"],
  displaySegmentedControl: true,
  segmentedControlDirection: "vertical",
  // @ts-ignore
  optionIcons: ["direction-vertical", "direction-horizontal", "direction-all"],
  description: "More components at [Framer University](https://frameruni.link/cc)."
} });

// http-url:https://framerusercontent.com/modules/mBREJFWCUcSH5zyPdanW/FPrEXAOS9InnwxaajJ6T/oH9mREbWb.js
var LayoutJumpPreventerFonts = getFonts(AvoidLayoutJumping);
var cycleOrder = ["HGHfFbGiH", "LCVxSuvru"];
var serializationHash = "framer-Tll97";
var variantClassNames = { HGHfFbGiH: "framer-v-byt4tp", LCVxSuvru: "framer-v-2q7g9k" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.15, delay: 0, duration: 0.35, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Closed: "LCVxSuvru", Open: "HGHfFbGiH" };
var Variants = motion3.create(React3.Fragment);
var getProps3 = ({ answer, height, id, question, width, ...props }) => {
  return { ...props, cGcteGcSe: question ?? props.cGcteGcSe ?? "How long does delivery take?", M0F6TNI_4: answer ?? props.M0F6TNI_4 ?? "Most pieces ship within 3 to 5 business days.", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "HGHfFbGiH" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, cGcteGcSe, M0F6TNI_4, ...restProps } = getProps3(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "HGHfFbGiH", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTapgnqhaj = activeVariantCallback(async (...args) => {
    setVariant(CycleVariantState);
  });
  const sharedStyleClassNames = [];
  const scopingClassNames = cx3(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "LCVxSuvru")
      return false;
    return true;
  };
  return /* @__PURE__ */ _jsx4(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion3.div, { ...restProps, ...gestureHandlers, className: cx3(scopingClassNames, "framer-byt4tp", className, classNames), "data-border": true, "data-framer-name": "Open", layoutDependency, layoutId: "Question__HGHfFbGiH", ref: refBinding, style: { "--border-bottom-width": "1px", "--border-color": "rgba(0, 0, 0, 0.08)", "--border-left-width": "1px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "1px", backgroundColor: "rgba(255, 255, 255, 0.45)", borderBottomLeftRadius: 12, borderBottomRightRadius: 12, borderTopLeftRadius: 12, borderTopRightRadius: 12, ...style }, ...addPropertyOverrides({ LCVxSuvru: { "data-framer-name": "Closed" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1prnwhb-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "Question__hO7uZ5gXS-container", nodeId: "hO7uZ5gXS", rendersWithMotion: true, scopeId: "oH9mREbWb", children: /* @__PURE__ */ _jsx4(AvoidLayoutJumping, { direction: "vertical", height: "100%", id: "hO7uZ5gXS", layoutId: "Question__hO7uZ5gXS", width: "100%" }) }) }), /* @__PURE__ */ _jsxs(motion3.div, { className: "framer-ohyrr6", "data-highlight": true, layoutDependency, layoutId: "Question__ZpTNND5nW", onTap: onTapgnqhaj, children: [/* @__PURE__ */ _jsx4(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React3.Fragment, { children: /* @__PURE__ */ _jsx4(motion3.h3, { dir: "auto", style: { "--font-selector": "RlM7U3dpdHplci1tZWRpdW0=", "--framer-font-family": '"Switzer", "Switzer Placeholder", sans-serif', "--framer-font-size": "19px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.01em", "--framer-line-height": "1.3em" }, children: "Question" }) }), className: "framer-ry6yd6", "data-framer-name": "Question", fonts: ["FS;Switzer-medium"], layoutDependency, layoutId: "Question__eTYs9foff", text: cGcteGcSe, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx4(Instance, { animated: true, className: "framer-1m1oewg", Component: TNS_VU02W_default, layoutDependency, layoutId: "Question__P6iggaClN", style: { "--1m973uw": "rgb(0, 0, 0)", "--js9iwy": 2 }, ...addPropertyOverrides({ LCVxSuvru: { Component: vbTtQKoql_default } }, baseVariant, gestureVariant) })] }), isDisplayed() && /* @__PURE__ */ _jsx4(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React3.Fragment, { children: /* @__PURE__ */ _jsx4(motion3.p, { dir: "auto", style: { "--framer-font-size": "14px", "--framer-line-height": "1.65em", "--framer-text-color": "var(--extracted-r6o4lv, rgba(0, 0, 0, 0.55))" }, children: "Answer" }) }), className: "framer-rf0bup", "data-framer-name": "Answer", fonts: ["Inter"], layoutDependency, layoutId: "Question__jg4YF85GD", style: { "--extracted-r6o4lv": "rgba(0, 0, 0, 0.55)" }, text: M0F6TNI_4, verticalAlignment: "top", withExternalLayout: true })] }) }) }) });
});
var css3 = [".framer-Tll97.framer-nrgvjo, .framer-Tll97 .framer-nrgvjo { display: block; }", ".framer-Tll97.framer-byt4tp { align-content: flex-start; align-items: flex-start; cursor: pointer; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 14px; height: min-content; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 24px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-Tll97 .framer-1prnwhb-container { flex: none; height: auto; left: 24px; position: absolute; top: 24px; width: auto; z-index: 1; }", ".framer-Tll97 .framer-ohyrr6 { align-content: center; align-items: center; cursor: pointer; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; height: min-content; justify-content: space-between; padding: 0px; position: relative; width: 100%; }", ".framer-Tll97 .framer-ry6yd6 { --framer-text-wrap: balance; -webkit-user-select: none; flex: 1 0 0px; height: auto; position: relative; user-select: none; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; }", ".framer-Tll97 .framer-1m1oewg { flex: none; height: auto; position: relative; width: 18px; }", ".framer-Tll97 .framer-rf0bup { -webkit-user-select: none; flex: none; height: auto; position: relative; user-select: none; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-Tll97.framer-v-2q7g9k.framer-byt4tp { gap: 0px; }", '.framer-Tll97[data-border="true"]::after, .framer-Tll97 [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FrameroH9mREbWb = withCSS3(Component3, css3, "framer-Tll97");
var oH9mREbWb_default = FrameroH9mREbWb;
FrameroH9mREbWb.displayName = "Question";
FrameroH9mREbWb.defaultProps = { height: 110, width: 640 };
addPropertyControls4(FrameroH9mREbWb, { variant: { options: ["HGHfFbGiH", "LCVxSuvru"], optionTitles: ["Open", "Closed"], title: "Variant", type: ControlType4.Enum }, cGcteGcSe: { defaultValue: "How long does delivery take?", title: "Question", type: ControlType4.String }, oncGcteGcSeChange: { changes: "cGcteGcSe", type: ControlType4.ChangeHandler }, M0F6TNI_4: { defaultValue: "Most pieces ship within 3 to 5 business days.", displayTextArea: true, title: "Answer", type: ControlType4.String }, onM0F6TNI_4Change: { changes: "M0F6TNI_4", type: ControlType4.ChangeHandler } });
addFonts(FrameroH9mREbWb, [{ explicitInter: true, fonts: [{ cssFamilyName: "Switzer", source: "fontshare", style: "normal", uiFamilyName: "Switzer", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/OYB4CXKJQXKTNSLJMTDQOIVUL2V5EL7S/WYO2P7DQVV5RNXGMCUO2HL4RJP4VFUAS/6XPIMU23OJVRY676OG5YVJMWEHWICATX.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...LayoutJumpPreventerFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FrameroH9mREbWb", "slots": [], "annotations": { "framerIntrinsicWidth": "640", "framerAutoSizeImages": "true", "framerComponentViewportWidth": "true", "framerDisplayContentsDiv": "false", "framerContractVersion": "1", "framerIntrinsicHeight": "110", "framerColorSyntax": "true", "framerImmutableVariables": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"LCVxSuvru":{"layout":["fixed","auto"]}}}', "framerVariables": '{"cGcteGcSe":"question","M0F6TNI_4":"answer"}' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  oH9mREbWb_default as default
};
