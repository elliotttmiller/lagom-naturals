var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/sGJaTFzKOE6wCy7Um3Xv/ws8vd6OezpONCqONXZLq/Quoteliftpro.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, useMotionValue, animate, useReducedMotion } from "framer-motion";
import { addPropertyControls, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
var EASE_OUT = [0.16, 1, 0.3, 1];
function splitWords(text) {
  return String(text || "").split(/\s+/).filter(Boolean);
}
function parseFigure(raw) {
  const match = String(raw || "").match(/^([^\d]*)([\d.,]+)(.*)$/);
  if (!match)
    return null;
  const prefix = match[1];
  const clean = match[2].replace(/,/g, "");
  const num = parseFloat(clean);
  if (!isFinite(num))
    return null;
  const decimals = (clean.split(".")[1] || "").length;
  return { prefix, num, suffix: match[3], decimals };
}
function Figure({ value, animateIn, style }) {
  const parsed = useMemo(() => parseFigure(value), [value]);
  const [shown, setShown] = useState(value);
  useEffect(() => {
    if (!animateIn || !parsed) {
      setShown(value);
      return;
    }
    const controls = animate(0, parsed.num, { duration: 0.9, ease: "easeOut", onUpdate: (v) => setShown(`${parsed.prefix}${v.toFixed(parsed.decimals)}${parsed.suffix}`), onComplete: () => setShown(value) });
    return () => controls.stop();
  }, [value, animateIn, parsed]);
  return /* @__PURE__ */ _jsx("div", { style: { ...style, fontVariantNumeric: "tabular-nums" }, children: shown });
}
function AscendQuotePro(props) {
  const { items, columnWidth, cardHeight, cardGap, cardRadius, visibleSlots, columnGap, railWidth, showRail, fadeTail, inactiveOpacity, inactiveGrayscale, autoPlay, interval, pauseOnHover, draggable, wheelNavigation, wheelThreshold, quoteFont, nameFont, roleFont, statFont, labelFont, quoteMaxWidth, bylineGap, statsGap, countUp, background, ink, muted, hairline, accent, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft, radius, style } = props;
  const isStatic = useIsStaticRenderer();
  const reduceMotion = useReducedMotion();
  const list = items && items.length ? items : [];
  const count = list.length;
  const slot = cardHeight + cardGap;
  const viewportHeight = Math.max(cardHeight, slot * visibleSlots - cardGap);
  const span = slot * Math.max(count, 1);
  const copies = Math.max(2, Math.ceil(viewportHeight / Math.max(span, 1)) + 2);
  const stripY = useMotionValue(0);
  const stepRef = useRef(0);
  const animRef = useRef(null);
  const [active, setActive] = useState(0);
  const [cycle, setCycle] = useState(0);
  const [hovering, setHovering] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [visible, setVisible] = useState(true);
  const rootRef = useRef(null);
  const viewportRef = useRef(null);
  useEffect(() => {
    if (isStatic || typeof IntersectionObserver === "undefined")
      return;
    const node = rootRef.current;
    if (!node)
      return;
    const io = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting), { threshold: 0.01 });
    io.observe(node);
    return () => io.disconnect();
  }, [isStatic]);
  const normalize = useCallback(() => {
    if (span <= 0)
      return;
    let v = stripY.get() % span;
    if (v > 0)
      v -= span;
    stripY.set(v);
  }, [span, stripY]);
  const go = useCallback((delta) => {
    if (!delta || count < 2)
      return;
    animRef.current?.stop();
    stepRef.current += delta;
    const next = (stepRef.current % count + count) % count;
    setActive(next);
    setCycle((c) => c + 1);
    const target = stripY.get() - delta * slot;
    animRef.current = animate(stripY, target, { duration: reduceMotion ? 0 : 0.95, ease: EASE_OUT, onComplete: normalize });
  }, [count, slot, stripY, normalize, reduceMotion]);
  const jumpTo = useCallback((index) => {
    let d = (index - active + count) % count;
    if (d > count / 2)
      d -= count;
    go(d);
  }, [active, count, go]);
  useEffect(() => {
    if (isStatic || !autoPlay || count < 2)
      return;
    if (!visible || dragging)
      return;
    if (pauseOnHover && hovering)
      return;
    const id = __dai_window.setInterval(() => go(1), Math.max(1200, interval));
    return () => __dai_window.clearInterval(id);
  }, [isStatic, autoPlay, count, visible, dragging, hovering, pauseOnHover, interval, go]);
  useEffect(() => {
    if (isStatic || !wheelNavigation || count < 2)
      return;
    const node = viewportRef.current;
    if (!node)
      return;
    let acc = 0;
    let locked = false;
    let idleId = 0;
    let lockId = 0;
    const threshold = Math.max(10, wheelThreshold);
    const onWheel = (e) => {
      const d = Math.abs(e.deltaY) >= Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
      if (!d)
        return;
      e.preventDefault();
      if (locked)
        return;
      acc += d;
      __dai_window.clearTimeout(idleId);
      idleId = __dai_window.setTimeout(() => {
        acc = 0;
      }, 180);
      if (Math.abs(acc) >= threshold) {
        go(acc > 0 ? 1 : -1);
        acc = 0;
        locked = true;
        lockId = __dai_window.setTimeout(() => {
          locked = false;
        }, 430);
      }
    };
    node.addEventListener("wheel", onWheel, { passive: false });
    return () => {
      node.removeEventListener("wheel", onWheel);
      __dai_window.clearTimeout(idleId);
      __dai_window.clearTimeout(lockId);
    };
  }, [isStatic, wheelNavigation, wheelThreshold, count, go]);
  const dragState = useRef({ y: 0, start: 0, moved: 0 });
  const onPointerDown = (e) => {
    dragState.current.moved = 0;
    if (!draggable || isStatic || count < 2)
      return;
    animRef.current?.stop();
    dragState.current = { y: e.clientY, start: stripY.get(), moved: 0 };
    setDragging(true);
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e) => {
    if (!dragging)
      return;
    const dy = e.clientY - dragState.current.y;
    dragState.current.moved = Math.max(dragState.current.moved, Math.abs(dy));
    stripY.set(dragState.current.start + dy);
  };
  const hitIndex = useCallback((clientY) => {
    const node = viewportRef.current;
    if (!node || count < 1)
      return null;
    const rect = node.getBoundingClientRect();
    const contentY = clientY - rect.top - stripY.get();
    const raw = Math.floor(contentY / slot);
    if (contentY - raw * slot > cardHeight)
      return null;
    return (raw % count + count) % count;
  }, [count, slot, cardHeight, stripY]);
  const onPointerUp = (e) => {
    const tapped = dragState.current.moved <= 6;
    if (dragging) {
      setDragging(false);
      try {
        e.currentTarget.releasePointerCapture(e.pointerId);
      } catch {
      }
      if (!tapped) {
        const travelled = dragState.current.start - stripY.get();
        const steps = Math.round(travelled / slot);
        stepRef.current += steps;
        const next = (stepRef.current % count + count) % count;
        if (next !== active) {
          setActive(next);
          setCycle((c) => c + 1);
        }
        animRef.current = animate(stripY, dragState.current.start - steps * slot, { duration: 0.5, ease: EASE_OUT, onComplete: normalize });
        return;
      }
      stripY.set(dragState.current.start);
    }
    if (isStatic || count < 2)
      return;
    const index = hitIndex(e.clientY);
    if (index !== null)
      jumpTo(index);
  };
  const onPointerCancel = (e) => {
    if (!dragging)
      return;
    setDragging(false);
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
    }
    animRef.current = animate(stripY, dragState.current.start, { duration: 0.4, ease: EASE_OUT, onComplete: normalize });
  };
  const current = list[active];
  const words = useMemo(() => splitWords(current?.quote || ""), [current?.quote]);
  const pad = paddingPerSide ? `${paddingTop}px ${paddingRight}px ${paddingBottom}px ${paddingLeft}px` : `${padding}px`;
  if (!count) {
    return /* @__PURE__ */ _jsx("div", { style: { ...style, display: "flex", alignItems: "center", justifyContent: "center", background, borderRadius: radius, color: muted, fontFamily: "Inter, sans-serif", fontSize: 13 }, children: "Add at least one testimonial" });
  }
  return /* @__PURE__ */ _jsxs("div", { ref: rootRef, style: { ...style, display: "flex", alignItems: "stretch", gap: columnGap, background, borderRadius: radius, padding: pad, overflow: "hidden", boxSizing: "border-box", color: ink }, onMouseEnter: () => setHovering(true), onMouseLeave: () => setHovering(false), children: [/* @__PURE__ */ _jsxs("div", { style: { display: "flex", gap: showRail ? 18 : 0, flex: "none" }, children: [showRail && /* @__PURE__ */ _jsx("div", { style: { position: "relative", width: railWidth, height: viewportHeight, background: hairline, borderRadius: railWidth, flex: "none" }, children: /* @__PURE__ */ _jsx(motion.div, { animate: { y: active * (viewportHeight / count) }, transition: { duration: reduceMotion ? 0 : 0.8, ease: EASE_OUT }, style: { position: "absolute", top: 0, left: 0, width: railWidth, height: Math.max(8, viewportHeight / count - 6), background: accent, borderRadius: railWidth } }) }), /* @__PURE__ */ _jsx("div", { ref: viewportRef, onPointerDown, onPointerMove, onPointerUp, onPointerCancel, style: { position: "relative", width: columnWidth, height: viewportHeight, overflow: "hidden", flex: "none", cursor: draggable && count > 1 ? dragging ? "grabbing" : "grab" : "pointer", touchAction: draggable && count > 1 ? "pan-x" : "auto", WebkitMaskImage: fadeTail ? "linear-gradient(180deg,#000 0%,#000 74%,transparent 100%)" : void 0, maskImage: fadeTail ? "linear-gradient(180deg,#000 0%,#000 74%,transparent 100%)" : void 0 }, children: /* @__PURE__ */ _jsx(motion.div, { style: { position: "absolute", inset: 0, y: isStatic ? 0 : stripY }, children: Array.from({ length: copies }).map((_, c) => list.map((item, i) => {
    const on = i === active;
    return /* @__PURE__ */ _jsx("div", { role: "button", tabIndex: on ? -1 : 0, "aria-label": `Show testimonial from ${item.name || `#${i + 1}`}`, onKeyDown: (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        jumpTo(i);
      }
    }, style: { position: "absolute", top: 0, left: 0, width: columnWidth, height: cardHeight, borderRadius: cardRadius, overflow: "hidden", transform: `translateY(${(c * count + i) * slot}px)`, background: hairline, cursor: "pointer" }, children: item.image?.src ? /* @__PURE__ */ _jsx(motion.img, { src: item.image.src, srcSet: item.image.srcSet, alt: item.image.alt || item.name || "", draggable: false, animate: { opacity: on ? 1 : inactiveOpacity, filter: `grayscale(${on ? 0 : inactiveGrayscale})`, scale: on ? 1 : 1.06 }, transition: { duration: reduceMotion ? 0 : 0.8, ease: EASE_OUT }, style: { width: "100%", height: "100%", objectFit: "cover", display: "block", userSelect: "none" } }) : null }, `${c}-${i}`);
  })) }) })] }), /* @__PURE__ */ _jsxs("div", { style: { flex: 1, minWidth: 0, display: "flex", flexDirection: "column", minHeight: viewportHeight }, children: [/* @__PURE__ */ _jsx("div", { style: { ...quoteFont, color: ink, maxWidth: quoteMaxWidth, margin: 0 }, children: isStatic || reduceMotion ? current.quote : words.map((w, i) => /* @__PURE__ */ _jsxs("span", { style: { display: "inline-block", overflow: "hidden", verticalAlign: "top", paddingBottom: "0.14em", marginBottom: "-0.14em" }, children: [/* @__PURE__ */ _jsx(motion.span, { initial: { y: "108%", opacity: 0 }, animate: { y: "0%", opacity: 1 }, transition: { duration: 0.62, delay: 0.04 + i * 0.022, ease: EASE_OUT }, style: { display: "inline-block" }, children: w }), /* @__PURE__ */ _jsx("span", { children: "\xA0" })] }, `${i}-${w}`)) }, isStatic ? "static" : `quote-${cycle}`), /* @__PURE__ */ _jsxs(motion.div, { initial: isStatic || reduceMotion ? false : { opacity: 0, y: 8 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.55, delay: 0.26, ease: EASE_OUT }, style: { marginTop: bylineGap, display: "flex", alignItems: "baseline", gap: 10, flexWrap: "wrap" }, children: [/* @__PURE__ */ _jsx("span", { style: { ...nameFont, color: ink }, children: current.name }), /* @__PURE__ */ _jsx("span", { style: { ...roleFont, color: muted }, children: current.role })] }, isStatic ? "static-by" : `by-${cycle}`), /* @__PURE__ */ _jsx("div", { style: { marginTop: "auto", paddingTop: statsGap, borderTop: `1px solid ${hairline}`, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40 }, children: [{ v: current.statOneValue, l: current.statOneLabel }, { v: current.statTwoValue, l: current.statTwoLabel }].map((s, i) => s.v || s.l ? /* @__PURE__ */ _jsxs("div", { children: [/* @__PURE__ */ _jsx(Figure, { value: s.v, animateIn: countUp && !isStatic && !reduceMotion, style: { ...statFont, color: ink } }), /* @__PURE__ */ _jsx("div", { style: { ...labelFont, color: muted, marginTop: 4 }, children: s.l })] }, i) : /* @__PURE__ */ _jsx("div", {}, i)) })] })] });
}
var defaultItem = { quote: "Switching to this platform transformed the way our team collaborates. Everything is faster, cleaner, and incredibly intuitive. We saw measurable improvements within the first few weeks.", name: "Sarah Mitchell", role: "Product Director, Nova Labs", statOneValue: "2.8x", statOneLabel: "faster team collaboration", statTwoValue: "42%", statTwoLabel: "increase in productivity" };
AscendQuotePro.defaultProps = { items: [defaultItem, { quote: "Implementation took less than a week, and the results exceeded our expectations. Our workflows became more efficient, and customer satisfaction improved immediately.", name: "David Kim", role: "Operations Manager, BrightFlow", statOneValue: "65%", statOneLabel: "less manual work", statTwoValue: "3 weeks", statTwoLabel: "time to full adoption" }, { quote: "We've tried several solutions over the years, but this is the first one that truly scales with our business. Reliable, flexible, and beautifully designed.", name: "Emily Carter", role: "CEO, Horizon Studio", statOneValue: "4x", statOneLabel: "faster project delivery", statTwoValue: "98%", statTwoLabel: "customer satisfaction" }, { quote: "The user experience is exceptional. Our team required almost no training, and the automation features saved us countless hours every month.", name: "Michael Ross", role: "Head of Digital, Vertex Agency", statOneValue: "120+ hrs", statOneLabel: "saved each month", statTwoValue: "55%", statTwoLabel: "lower operational costs" }, { quote: "From onboarding to daily use, every interaction feels effortless. It's one of the best investments we've made for improving efficiency across the company.", name: "Olivia Bennett", role: "Founder, Atlas Creative", statOneValue: "3.5x", statOneLabel: "workflow efficiency", statTwoValue: "89%", statTwoLabel: "team adoption rate" }], columnWidth: 132, cardHeight: 168, cardGap: 14, cardRadius: 2, visibleSlots: 2.45, columnGap: 56, railWidth: 2, showRail: true, fadeTail: true, inactiveOpacity: 0.42, inactiveGrayscale: 1, autoPlay: true, interval: 4600, pauseOnHover: true, draggable: true, wheelNavigation: true, wheelThreshold: 60, quoteMaxWidth: 560, bylineGap: 30, statsGap: 22, countUp: true, background: "#FFFFFF", ink: "#111112", muted: "#8C8C87", hairline: "#E5E4E0", accent: "#111112", padding: 48, paddingPerSide: false, paddingTop: 48, paddingRight: 48, paddingBottom: 48, paddingLeft: 48, radius: 4 };
addPropertyControls(AscendQuotePro, {
  items: { type: ControlType.Array, title: "Testimonials", control: { type: ControlType.Object, controls: { image: { type: ControlType.ResponsiveImage, title: "Photo" }, quote: { type: ControlType.String, title: "Quote", displayTextArea: true, defaultValue: defaultItem.quote }, name: { type: ControlType.String, title: "Name", defaultValue: defaultItem.name }, role: { type: ControlType.String, title: "Role", defaultValue: defaultItem.role }, statOneValue: { type: ControlType.String, title: "Stat 1", defaultValue: defaultItem.statOneValue }, statOneLabel: { type: ControlType.String, title: "Label 1", defaultValue: defaultItem.statOneLabel }, statTwoValue: { type: ControlType.String, title: "Stat 2", defaultValue: defaultItem.statTwoValue }, statTwoLabel: { type: ControlType.String, title: "Label 2", defaultValue: defaultItem.statTwoLabel } } } },
  /* ---- strip ---- */
  columnWidth: { type: ControlType.Number, title: "Column W", min: 60, max: 400, step: 1, displayStepper: true },
  cardHeight: { type: ControlType.Number, title: "Card H", min: 80, max: 520, step: 1, displayStepper: true },
  cardGap: { type: ControlType.Number, title: "Card Gap", min: 0, max: 80, step: 1 },
  cardRadius: { type: ControlType.Number, title: "Card Radius", min: 0, max: 60, step: 1 },
  visibleSlots: { type: ControlType.Number, title: "Visible", min: 1, max: 6, step: 0.05, description: "Cards in view \u2014 a fraction crops the last one" },
  columnGap: { type: ControlType.Number, title: "Split Gap", min: 0, max: 200, step: 2 },
  showRail: { type: ControlType.Boolean, title: "Rail", enabledTitle: "Show", disabledTitle: "Hide" },
  railWidth: { type: ControlType.Number, title: "Rail W", min: 1, max: 12, step: 1, hidden: (p) => !p.showRail },
  fadeTail: { type: ControlType.Boolean, title: "Fade Tail", enabledTitle: "On", disabledTitle: "Off" },
  inactiveOpacity: { type: ControlType.Number, title: "Idle Fade", min: 0, max: 1, step: 0.01 },
  inactiveGrayscale: { type: ControlType.Number, title: "Idle Mono", min: 0, max: 1, step: 0.01 },
  /* ---- motion ---- */
  autoPlay: { type: ControlType.Boolean, title: "Autoplay", enabledTitle: "On", disabledTitle: "Off" },
  interval: { type: ControlType.Number, title: "Interval", min: 1200, max: 12e3, step: 100, unit: "ms", hidden: (p) => !p.autoPlay },
  pauseOnHover: { type: ControlType.Boolean, title: "Pause Hover", enabledTitle: "Yes", disabledTitle: "No", hidden: (p) => !p.autoPlay },
  draggable: { type: ControlType.Boolean, title: "Drag", enabledTitle: "On", disabledTitle: "Off" },
  wheelNavigation: { type: ControlType.Boolean, title: "Scroll", enabledTitle: "On", disabledTitle: "Off", description: "Wheel over the strip steps through testimonials" },
  wheelThreshold: { type: ControlType.Number, title: "Scroll Force", min: 10, max: 300, step: 5, hidden: (p) => !p.wheelNavigation },
  countUp: { type: ControlType.Boolean, title: "Roll Stats", enabledTitle: "On", disabledTitle: "Off" },
  /* ---- type ---- */
  quoteFont: { type: ControlType.Font, title: "Quote", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: 31, lineHeight: 1.34, letterSpacing: "-0.017em", fontWeight: 400 } },
  nameFont: { type: ControlType.Font, title: "Name", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: 14, fontWeight: 600, lineHeight: 1.3 } },
  roleFont: { type: ControlType.Font, title: "Role", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: 12.5, fontWeight: 400, lineHeight: 1.3 } },
  statFont: { type: ControlType.Font, title: "Stat", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: 26, fontWeight: 500, letterSpacing: "-0.02em", lineHeight: 1.2 } },
  labelFont: { type: ControlType.Font, title: "Stat Label", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: 11, fontWeight: 400, letterSpacing: "0.06em", lineHeight: 1.4, textTransform: "uppercase" } },
  quoteMaxWidth: { type: ControlType.Number, title: "Quote Max", min: 200, max: 1200, step: 10 },
  bylineGap: { type: ControlType.Number, title: "Byline Gap", min: 0, max: 120, step: 2 },
  statsGap: { type: ControlType.Number, title: "Stats Gap", min: 0, max: 120, step: 2 },
  /* ---- colour ---- */
  background: { type: ControlType.Color, title: "Background" },
  ink: { type: ControlType.Color, title: "Ink" },
  muted: { type: ControlType.Color, title: "Muted" },
  hairline: { type: ControlType.Color, title: "Hairline" },
  accent: { type: ControlType.Color, title: "Accent" },
  /* ---- frame ---- */
  radius: { type: ControlType.Number, title: "Radius", min: 0, max: 80, step: 1 },
  padding: { type: ControlType.FusedNumber, title: "Padding", toggleKey: "paddingPerSide", toggleTitles: ["All", "Per side"], valueKeys: ["paddingTop", "paddingRight", "paddingBottom", "paddingLeft"], valueLabels: ["T", "R", "B", "L"], min: 0 }
});
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "AscendQuotePro", "slots": [], "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  AscendQuotePro as default
};
