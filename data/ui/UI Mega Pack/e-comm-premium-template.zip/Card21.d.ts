export interface Card21Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Variant 1" → EZLGG6uxN
   *   "Variant 2" → IAw08W7uu
   */
  variant?: 'Variant 1' | 'Variant 2' | 'EZLGG6uxN' | 'IAw08W7uu';
  /**
   * Icon — pass as `XkXyGD3uU` not `icon`.
   * @default {"identifier":"module:vbS3M5rjCNoWwh9bizWZ/2WBSYh5yU9NmwXGhT0U2/pzqBbCtXv.js:default","moduleId":"vbS3M5rjCNoWwh9bizWZ"}
   */
  XkXyGD3uU?: string;
  /**
   * Title — pass as `lLCnZzaj5` not `title`.
   * @default "Floor"
   */
  lLCnZzaj5?: string;
  onlLCnZzaj5Change?: string;
  /**
   * Text — pass as `H4y5XUyYk` not `text`.
   * @default "Floor lamps for living, study, and bedroom environments. Adjustable height and unique designs."
   */
  H4y5XUyYk?: string;
  onH4y5XUyYkChange?: string;
  /**
   * CTA — pass as `Djz2J5GLT` not `cta`.
   * @default "View Floor"
   */
  Djz2J5GLT?: string;
  onDjz2J5GLTChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
