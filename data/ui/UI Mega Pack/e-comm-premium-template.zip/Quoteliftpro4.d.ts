export interface Quoteliftpro4Props {
  /**
   * Testimonials — pass as `items` not `testimonials`.
   */
  items?: unknown[];
  /**
   * Column W — pass as `columnWidth` not `columnW`.
   * Range: min: 60, max: 400, step: 1
   */
  columnWidth?: number;
  /**
   * Card H — pass as `cardHeight` not `cardH`.
   * Range: min: 80, max: 520, step: 1
   */
  cardHeight?: number;
  /**
   * Card Gap
   * Range: min: 0, max: 80, step: 1
   */
  cardGap?: number;
  /**
   * Card Radius
   * Range: min: 0, max: 60, step: 1
   */
  cardRadius?: number;
  /**
   * Visible — pass as `visibleSlots` not `visible`.
   * Range: min: 1, max: 6, step: 0.05
   */
  visibleSlots?: number;
  /**
   * Split Gap — pass as `columnGap` not `splitGap`.
   * Range: min: 0, max: 200, step: 2
   */
  columnGap?: number;
  /**
   * Rail — pass as `showRail` not `rail`.
   */
  showRail?: boolean;
  /**
   * Rail W — pass as `railWidth` not `railW`.
   * Range: min: 1, max: 12, step: 1
   */
  railWidth?: number;
  /**
   * Fade Tail
   */
  fadeTail?: boolean;
  /**
   * Idle Fade — pass as `inactiveOpacity` not `idleFade`.
   * Range: min: 0, max: 1, step: 0.01
   */
  inactiveOpacity?: number;
  /**
   * Idle Mono — pass as `inactiveGrayscale` not `idleMono`.
   * Range: min: 0, max: 1, step: 0.01
   */
  inactiveGrayscale?: number;
  /**
   * Autoplay — pass as `autoPlay` not `autoplay`.
   */
  autoPlay?: boolean;
  /**
   * Interval
   * Range: min: 1200, max: 12000, step: 100
   */
  interval?: number;
  /**
   * Pause Hover — pass as `pauseOnHover` not `pauseHover`.
   */
  pauseOnHover?: boolean;
  /**
   * Drag — pass as `draggable` not `drag`.
   */
  draggable?: boolean;
  /**
   * Scroll — pass as `wheelNavigation` not `scroll`.
   */
  wheelNavigation?: boolean;
  /**
   * Scroll Force — pass as `wheelThreshold` not `scrollForce`.
   * Range: min: 10, max: 300, step: 5
   */
  wheelThreshold?: number;
  /**
   * Roll Stats — pass as `countUp` not `rollStats`.
   */
  countUp?: boolean;
  /**
   * Quote — pass as `quoteFont` not `quote`.
   * @default {"fontSize":31,"lineHeight":1.34,"letterSpacing":"-0.017em","fontWeight":400}
   */
  quoteFont?: string;
  /**
   * Name — pass as `nameFont` not `name`.
   * @default {"fontSize":14,"fontWeight":600,"lineHeight":1.3}
   */
  nameFont?: string;
  /**
   * Role — pass as `roleFont` not `role`.
   * @default {"fontSize":12.5,"fontWeight":400,"lineHeight":1.3}
   */
  roleFont?: string;
  /**
   * Stat — pass as `statFont` not `stat`.
   * @default {"fontSize":26,"fontWeight":500,"letterSpacing":"-0.02em","lineHeight":1.2}
   */
  statFont?: string;
  /**
   * Stat Label — pass as `labelFont` not `statLabel`.
   * @default {"fontSize":11,"fontWeight":400,"letterSpacing":"0.06em","lineHeight":1.4,"textTransform":"uppercase"}
   */
  labelFont?: string;
  /**
   * Quote Max — pass as `quoteMaxWidth` not `quoteMax`.
   * Range: min: 200, max: 1200, step: 10
   */
  quoteMaxWidth?: number;
  /**
   * Byline Gap
   * Range: min: 0, max: 120, step: 2
   */
  bylineGap?: number;
  /**
   * Stats Gap
   * Range: min: 0, max: 120, step: 2
   */
  statsGap?: number;
  /**
   * Background
   */
  background?: string;
  /**
   * Ink
   */
  ink?: string;
  /**
   * Muted
   */
  muted?: string;
  /**
   * Hairline
   */
  hairline?: string;
  /**
   * Accent
   */
  accent?: string;
  /**
   * Radius
   * Range: min: 0, max: 80, step: 1
   */
  radius?: number;
  /**
   * Padding
   * Range: min: 0
   */
  padding?: string;
  /** Additional properties */
  [key: string]: unknown;
}
