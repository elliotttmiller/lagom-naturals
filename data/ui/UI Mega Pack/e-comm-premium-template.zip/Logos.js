var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/qO9r5JLjZIj8a5saCxvc/3uvrI2IJKJ9LT6aI5jIw/TcH7JkAeA.js
import { jsx as _jsx9 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls9, ComponentViewportProvider, ControlType as ControlType9, cx as cx8, getFonts, SmartComponentScopedContainer, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS8 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion9, MotionConfigContext } from "framer-motion";
import * as React8 from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/2P5aUebkNUG2D4P7hqvi/fd7tyQxdVIbJdVyOfgkh/ycBZ59n4d.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M 10.941 0 L 5.061 0 C 2.268 -0.001 0.001 2.262 0 5.056 C -0.001 7.85 2.262 10.116 5.056 10.117 L 10.941 10.117 C 13.735 10.117 16 7.852 16 5.059 C 16 2.265 13.735 0 10.941 0 M 10.813 8.335 L 5.191 8.335 C 3.407 8.299 1.98 6.843 1.98 5.059 C 1.98 3.275 3.407 1.819 5.191 1.783 L 10.813 1.783 C 12.622 1.783 14.089 3.249 14.089 5.059 C 14.089 6.868 12.622 8.335 10.813 8.335" fill="var(--t829wi, rgb(0,0,0))" height="10.117334011836698px" id="YWTaK24Jo" transform="translate(0 2.941)" width="16.000000718239793px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(motion.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx("div", { ...rest, ref });
});
var getProps = ({ fill, height, id, width, ...props }) => {
  return { ...props, JW2ySfJQW: fill ?? props.JW2ySfJQW ?? "rgb(0, 0, 0)" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, JW2ySfJQW, ...restProps } = getProps(props);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-cjsyT", className), layoutId, ref, style: { "--t829wi": JW2ySfJQW, ...style } });
});
var css = [`.framer-cjsyT { -webkit-mask: ${mask}; aspect-ratio: 1; background-color: var(--t829wi); mask: ${mask}; width: 16px; }`];
var Icon = withCSS(Component, css, "framer-cjsyT");
Icon.displayName = "Oracle";
var ycBZ59n4d_default = Icon;
addPropertyControls(Icon, { JW2ySfJQW: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Fill", type: ControlType.Color } });

// http-url:https://framerusercontent.com/modules/B2xAlJLcN0gOnt11mSPw/plhC5PVnCMllW5QXjFK5/Ticker.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { Children, useLayoutEffect, useEffect, useState, useRef, useMemo, useCallback, cloneElement, startTransition, forwardRef as forwardRef3, useImperativeHandle } from "react";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2, RenderTarget } from "./_framer-runtime.js";
import { useReducedMotion, LayoutGroup, useInView, useMotionValue, useTransform, motion as motion2, frame } from "framer-motion";
import { resize } from "@motionone/dom";
var MAX_DUPLICATED_ITEMS = 100;
var directionTransformers = { left: (offset) => `translateX(-${offset}px)`, right: (offset) => `translateX(${offset}px)`, top: (offset) => `translateY(-${offset}px)`, bottom: (offset) => `translateY(${offset}px)` };
function Ticker(props) {
  let { slots = [], gap, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft, speed, hoverFactor, direction, alignment, sizingOptions, fadeOptions, style } = props;
  const { fadeContent, overflow, fadeWidth, fadeInset, fadeAlpha } = fadeOptions;
  const { widthType, heightType } = sizingOptions;
  const paddingValue = paddingPerSide ? `${paddingTop}px ${paddingRight}px ${paddingBottom}px ${paddingLeft}px` : `${padding}px`;
  const currentTarget = RenderTarget.current();
  const isCanvas = currentTarget === RenderTarget.canvas || currentTarget === RenderTarget.export;
  const writingDirection = useWritingDirection();
  const filteredSlots = slots.filter(Boolean);
  const numChildren = Children.count(filteredSlots);
  const hasChildren = numChildren > 0;
  const offset = useMotionValue(0);
  const resolvedDirection = getTickerResolvedDirection(direction === true ? "left" : direction, writingDirection);
  const isHorizontal = resolvedDirection === "left" || resolvedDirection === "right";
  const transformer = directionTransformers[resolvedDirection];
  const transform = useTransform(offset, transformer);
  const parentRef = useRef(null);
  const childrenRef = useMemo(() => {
    return [{ current: null }, { current: null }];
  }, []);
  const [size, setSize] = useState({ parent: null, children: null });
  let clonedChildren = null;
  let dupedChildren = [];
  let duplicateBy = 0;
  let opacity = 0;
  if (isCanvas) {
    duplicateBy = numChildren ? Math.floor(10 / numChildren) : 0;
    opacity = 1;
  }
  if (!isCanvas && hasChildren && size.parent) {
    duplicateBy = Math.round(size.parent / size.children * 2) + 1;
    duplicateBy = Math.min(duplicateBy, MAX_DUPLICATED_ITEMS);
    opacity = 1;
  }
  const measure = useCallback(() => {
    if (hasChildren && parentRef.current) {
      const parentLength = isHorizontal ? parentRef.current.offsetWidth : parentRef.current.offsetHeight;
      const start = childrenRef[0].current ? isHorizontal ? childrenRef[0].current.offsetLeft : childrenRef[0].current.offsetTop : 0;
      const end = childrenRef[1].current ? isHorizontal ? childrenRef[1].current.offsetLeft + childrenRef[1].current.offsetWidth : childrenRef[1].current.offsetTop + childrenRef[1].current.offsetHeight : 0;
      const childrenLength = end - start + gap;
      startTransition(() => {
        setSize({ parent: parentLength, children: childrenLength });
      });
    }
  }, []);
  const childrenStyles = isCanvas ? { contentVisibility: "auto" } : {};
  if (hasChildren) {
    if (!isCanvas) {
      let initialResize = useRef(true);
      useLayoutEffect(() => {
        frame.read(measure, false, true);
        return resize(parentRef.current, ({ contentSize }) => {
          if (!initialResize.current && (contentSize.width || contentSize.height)) {
            frame.read(measure, false, true);
          }
          initialResize.current = false;
        });
      }, []);
    }
    clonedChildren = Children.map(filteredSlots, (child, index) => {
      let ref;
      if (index === 0) {
        ref = childrenRef[writingDirection === "rtl" && isHorizontal ? 1 : 0];
      }
      if (index === filteredSlots.length - 1) {
        ref = childrenRef[writingDirection === "rtl" && isHorizontal ? 0 : 1];
      }
      const size2 = { width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%" };
      return /* @__PURE__ */ _jsx2(LayoutGroup, { inherit: "id", children: /* @__PURE__ */ _jsx2(Wrapper, { ref, style: size2, children: /* @__PURE__ */ cloneElement(child, { style: { ...child.props?.style, ...size2, flexShrink: 0, ...childrenStyles }, layoutId: child.props.layoutId ? child.props.layoutId + "-original-" + index : void 0 }, child.props?.children) }) });
    });
  }
  const isInView = isCanvas ? true : useInView(parentRef);
  if (!isCanvas) {
    for (let i = 0; i < duplicateBy; i++) {
      dupedChildren = dupedChildren.concat(Children.map(filteredSlots, (child, childIndex) => {
        const size2 = { width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%", willChange: !isInView ? void 0 : "transform" };
        return /* @__PURE__ */ _jsx2(LayoutGroup, { inherit: "id", children: /* @__PURE__ */ _jsx2(Wrapper, { style: size2, children: /* @__PURE__ */ cloneElement(child, { key: i + " " + childIndex, style: { ...child.props?.style, width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%", flexShrink: 0, ...childrenStyles }, layoutId: child.props.layoutId ? child.props.layoutId + "-dupe-" + i : void 0 }, child.props?.children) }, i + "li" + childIndex) }, i + "lg" + childIndex);
      }));
    }
  }
  const animateToValue = size.children + size.children * Math.round(size.parent / size.children);
  const initialTime = useRef(null);
  const prevTime = useRef(null);
  const xOrY = useRef(0);
  const isHover = useRef(false);
  const isReducedMotion = useReducedMotion();
  const listRef = useRef(null);
  const animationRef = useRef(null);
  if (!isCanvas) {
    useEffect(() => {
      if (isReducedMotion || !animateToValue || !speed) {
        return;
      }
      animationRef.current = listRef.current.animate({ transform: [transformer(0), transformer(animateToValue)] }, { duration: Math.abs(animateToValue) / speed * 1e3, iterations: Infinity, iterationStart: writingDirection === "rtl" ? 1 : 0, easing: "linear" });
      return () => animationRef.current.cancel();
    }, [hoverFactor, animateToValue, speed, writingDirection]);
    const playOrPause = useCallback(() => {
      if (!animationRef.current)
        return;
      const hidden = document.hidden;
      if (isInView && !hidden && animationRef.current.playState === "paused") {
        animationRef.current.play();
      } else if ((!isInView || hidden) && animationRef.current.playState === "running") {
        animationRef.current.pause();
      }
    }, [isInView]);
    useEffect(() => {
      playOrPause();
    }, [isInView, hoverFactor, animateToValue, speed]);
    useEffect(() => {
      document.addEventListener("visibilitychange", playOrPause);
      return () => {
        document.removeEventListener("visibilitychange", playOrPause);
      };
    }, [playOrPause]);
  }
  const fadeDirection = isHorizontal ? "to right" : "to bottom";
  const fadeWidthStart = fadeWidth / 2;
  const fadeWidthEnd = 100 - fadeWidth / 2;
  const fadeInsetStart = clamp(fadeInset, 0, fadeWidthStart);
  const fadeInsetEnd = 100 - fadeInset;
  const fadeMask = `linear-gradient(${fadeDirection}, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetStart}%, rgba(0, 0, 0, 1) ${fadeWidthStart}%, rgba(0, 0, 0, 1) ${fadeWidthEnd}%, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetEnd}%)`;
  if (!hasChildren) {
    return /* @__PURE__ */ _jsxs("section", { style: placeholderStyles, children: [/* @__PURE__ */ _jsx2("div", { style: emojiStyles, children: "\u2728" }), /* @__PURE__ */ _jsx2("p", { style: titleStyles, children: "Connect to Content" }), /* @__PURE__ */ _jsx2("p", { style: subtitleStyles, children: "Add layers or components to infinitely loop on your page." })] });
  }
  return /* @__PURE__ */ _jsx2("section", { style: { ...containerStyle, opacity, WebkitMaskImage: fadeContent ? fadeMask : void 0, maskImage: fadeContent ? fadeMask : void 0, overflow: overflow ? "visible" : "hidden", padding: paddingValue }, ref: parentRef, children: /* @__PURE__ */ _jsxs(motion2.ul, { ref: listRef, style: { ...containerStyle, gap, top: direction === "bottom" && isValidNumber(animateToValue) ? -animateToValue : void 0, left: direction === "right" && isValidNumber(animateToValue) ? animateToValue * (writingDirection === "rtl" ? 1 : -1) : void 0, placeItems: alignment, position: "relative", flexDirection: isHorizontal ? "row" : "column", ...style, willChange: isCanvas || !isInView ? "auto" : "transform", transform: transformer(0) }, onMouseEnter: () => {
    isHover.current = true;
    if (animationRef.current) {
      animationRef.current.playbackRate = hoverFactor;
    }
  }, onMouseLeave: () => {
    isHover.current = false;
    if (animationRef.current) {
      animationRef.current.playbackRate = 1;
    }
  }, children: [clonedChildren, dupedChildren] }) });
}
var Wrapper = /* @__PURE__ */ forwardRef3(({ children, ...props }, ref) => {
  const innerRef = useRef();
  const inView = useInView(innerRef);
  useImperativeHandle(ref, () => innerRef.current);
  useEffect(() => {
    const current = innerRef.current;
    if (!current)
      return;
    if (inView) {
      current.querySelectorAll("button,a").forEach((el) => {
        const orig = el.dataset.origTabIndex;
        if (orig)
          el.tabIndex = orig;
        else
          el.removeAttribute("tabIndex");
      });
    } else {
      current.querySelectorAll("button,a").forEach((el) => {
        const orig = el.getAttribute("tabIndex");
        if (orig)
          el.dataset.origTabIndex = orig;
        el.tabIndex = -1;
      });
    }
  }, [inView]);
  return /* @__PURE__ */ _jsx2("li", { ...props, "aria-hidden": !inView, ref: innerRef, children });
});
Ticker.defaultProps = { gap: 10, padding: 10, sizingOptions: { widthType: true, heightType: true }, fadeOptions: { fadeContent: true, overflow: false, fadeWidth: 25, fadeAlpha: 0, fadeInset: 0 }, direction: true };
addPropertyControls2(Ticker, { slots: { type: ControlType2.Array, title: "Children", control: { type: ControlType2.ComponentInstance } }, speed: { type: ControlType2.Number, title: "Speed", min: 0, max: 1e3, defaultValue: 100, unit: "%", displayStepper: true, step: 5 }, direction: { type: ControlType2.Enum, title: "Direction", options: ["left", "right", "top", "bottom"], optionIcons: ["direction-left", "direction-right", "direction-up", "direction-down"], optionTitles: ["Left", "Right", "Top", "Bottom"], defaultValue: "left", displaySegmentedControl: true }, alignment: { type: ControlType2.Enum, title: "Align", options: ["flex-start", "center", "flex-end"], optionIcons: { direction: { right: ["align-top", "align-middle", "align-bottom"], left: ["align-top", "align-middle", "align-bottom"], top: ["align-left", "align-center", "align-right"], bottom: ["align-left", "align-center", "align-right"] } }, defaultValue: "center", displaySegmentedControl: true }, gap: { type: ControlType2.Number, title: "Gap" }, padding: { title: "Padding", type: ControlType2.FusedNumber, toggleKey: "paddingPerSide", toggleTitles: ["Padding", "Padding per side"], valueKeys: ["paddingTop", "paddingRight", "paddingBottom", "paddingLeft"], valueLabels: ["T", "R", "B", "L"], min: 0 }, sizingOptions: { type: ControlType2.Object, title: "Sizing", controls: { widthType: { type: ControlType2.Boolean, title: "Width", enabledTitle: "Auto", disabledTitle: "Stretch", defaultValue: true }, heightType: { type: ControlType2.Boolean, title: "Height", enabledTitle: "Auto", disabledTitle: "Stretch", defaultValue: true } } }, fadeOptions: { type: ControlType2.Object, title: "Clipping", controls: { fadeContent: { type: ControlType2.Boolean, title: "Fade", defaultValue: true }, overflow: { type: ControlType2.Boolean, title: "Overflow", enabledTitle: "Show", disabledTitle: "Hide", defaultValue: false, hidden(props) {
  return props.fadeContent === true;
} }, fadeWidth: { type: ControlType2.Number, title: "Width", defaultValue: 25, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeInset: { type: ControlType2.Number, title: "Inset", defaultValue: 0, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeAlpha: { type: ControlType2.Number, title: "Opacity", defaultValue: 0, min: 0, max: 1, step: 0.05, hidden(props) {
  return props.fadeContent === false;
} } } }, hoverFactor: { type: ControlType2.Number, title: "Hover", min: 0, max: 1, unit: "x", defaultValue: 1, step: 0.1, displayStepper: true, description: "Slows down the speed while you are hovering." } });
var containerStyle = { display: "flex", width: "100%", height: "100%", maxWidth: "100%", maxHeight: "100%", placeItems: "center", margin: 0, padding: 0, listStyleType: "none", textIndent: "none" };
var placeholderStyles = { display: "flex", width: "100%", height: "100%", placeContent: "center", placeItems: "center", flexDirection: "column", color: "#96F", background: "rgba(136, 85, 255, 0.1)", fontSize: 11, overflow: "hidden", padding: "20px 20px 30px 20px" };
var emojiStyles = { fontSize: 32, marginBottom: 10 };
var titleStyles = { margin: 0, marginBottom: 10, fontWeight: 600, textAlign: "center" };
var subtitleStyles = { margin: 0, opacity: 0.7, maxWidth: 150, lineHeight: 1.5, textAlign: "center" };
var clamp = (num, min, max) => Math.min(Math.max(num, min), max);
var isValidNumber = (value) => typeof value === "number" && !isNaN(value);
function useWritingDirection() {
  if (!__dai_window || !__dai_window.document || !__dai_window.document.documentElement)
    return "ltr";
  return __dai_window.document.documentElement.dir === "rtl" ? "rtl" : "ltr";
}
function getTickerResolvedDirection(direction, writingDirection) {
  if (writingDirection !== "rtl")
    return direction;
  if (direction === "left")
    return "right";
  if (direction === "right")
    return "left";
  return direction;
}

// http-url:https://framerusercontent.com/modules/g2NQmnEdTtmlHkkSvaBw/okDNafpTjSkY5jreye9m/XowUhSFsa.js
import { jsx as _jsx3 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx as cx2, motion as motion3, withCSS as withCSS2 } from "./_framer-runtime.js";
import * as React2 from "react";
import { forwardRef as forwardRef5 } from "react";
var mask2 = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M 8 0 C 12.415 0 16 3.585 16 8 C 16 12.415 12.415 16 8 16 C 3.585 16 0 12.415 0 8 C 0 3.585 3.585 0 8 0 M 2.163 11.693 C 3.429 13.694 5.632 14.907 8 14.907 C 10.454 14.907 12.611 13.624 13.837 11.693 L 8 9.469 Z M 9.272 7.265 L 14.117 11.209 C 14.637 10.219 14.908 9.118 14.907 8 C 14.907 4.282 11.962 1.246 8.28 1.099 Z M 7.72 1.099 C 4.038 1.246 1.093 4.282 1.093 8 C 1.093 9.158 1.379 10.249 1.883 11.209 L 6.728 7.265 Z" fill="var(--t829wi, rgb(0,0,0))" height="16px" id="q3rJCRguO" width="16px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG2 = /* @__PURE__ */ forwardRef5((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx3(motion3.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx3("div", { ...rest, ref });
});
var getProps2 = ({ fill, height, id, width, ...props }) => {
  return { ...props, JW2ySfJQW: fill ?? props.JW2ySfJQW ?? "rgb(0, 0, 0)" };
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, JW2ySfJQW, ...restProps } = getProps2(props);
  return /* @__PURE__ */ _jsx3(SVG2, { ...restProps, className: cx2("framer-qNUrd", className), layoutId, ref, style: { "--t829wi": JW2ySfJQW, ...style } });
});
var css2 = [`.framer-qNUrd { -webkit-mask: ${mask2}; aspect-ratio: 1; background-color: var(--t829wi); mask: ${mask2}; width: 16px; }`];
var Icon2 = withCSS2(Component2, css2, "framer-qNUrd");
Icon2.displayName = "Mercedes";
var XowUhSFsa_default = Icon2;
addPropertyControls3(Icon2, { JW2ySfJQW: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Fill", type: ControlType3.Color } });

// http-url:https://framerusercontent.com/modules/ovH8R4dxp7ZdncdgT3kX/hoVJzn496C3Hxne35Wa1/wVlMzX1WC.js
import { jsx as _jsx4 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls4, ControlType as ControlType4, cx as cx3, motion as motion4, withCSS as withCSS3 } from "./_framer-runtime.js";
import * as React3 from "react";
import { forwardRef as forwardRef7 } from "react";
var mask3 = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M 8 3.575 L 9.65 1.557 C 9.65 1.557 12.48 1.617 15.297 2.927 C 14.576 4.017 13.143 4.552 13.143 4.552 C 13.046 3.593 12.374 3.359 10.241 3.359 L 8 16 L 5.746 3.356 C 3.626 3.356 2.954 3.592 2.856 4.551 C 2.856 4.551 1.425 4.021 0.703 2.931 C 3.52 1.621 6.35 1.56 6.35 1.56 Z M 8 3.575 L 7.997 3.576 L 8 3.576 Z M 8 0.975 C 10.277 0.955 12.884 1.327 15.552 2.495 C 15.909 1.85 16 1.565 16 1.565 C 13.083 0.408 10.352 0.01 8 0 C 5.648 0.01 2.917 0.407 0 1.566 C 0 1.566 0.13 1.916 0.448 2.497 C 3.116 1.326 5.723 0.957 8 0.973 Z" fill="var(--t829wi, rgb(0,0,0))" height="16px" id="cIaID0VqM" width="16px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG3 = /* @__PURE__ */ forwardRef7((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx4(motion4.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx4("div", { ...rest, ref });
});
var getProps3 = ({ fill, height, id, width, ...props }) => {
  return { ...props, JW2ySfJQW: fill ?? props.JW2ySfJQW ?? "rgb(0, 0, 0)" };
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, JW2ySfJQW, ...restProps } = getProps3(props);
  return /* @__PURE__ */ _jsx4(SVG3, { ...restProps, className: cx3("framer-DRZvv", className), layoutId, ref, style: { "--t829wi": JW2ySfJQW, ...style } });
});
var css3 = [`.framer-DRZvv { -webkit-mask: ${mask3}; aspect-ratio: 1; background-color: var(--t829wi); mask: ${mask3}; width: 16px; }`];
var Icon3 = withCSS3(Component3, css3, "framer-DRZvv");
Icon3.displayName = "Tesla";
var wVlMzX1WC_default = Icon3;
addPropertyControls4(Icon3, { JW2ySfJQW: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Fill", type: ControlType4.Color } });

// http-url:https://framerusercontent.com/modules/qwAQBdtOYisSuMoOLPzJ/oUg8KKwRxIhlhncdBOh8/mWnYqU4Hh.js
import { jsx as _jsx5 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls5, ControlType as ControlType5, cx as cx4, motion as motion5, withCSS as withCSS4 } from "./_framer-runtime.js";
import * as React4 from "react";
import { forwardRef as forwardRef9 } from "react";
var mask4 = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 14 16" xmlns="http://www.w3.org/2000/svg"><path d="M 6.204 4.31 C 5.612 4.31 4.695 3.636 3.729 3.66 C 2.454 3.677 1.286 4.399 0.629 5.544 C -0.694 7.841 0.288 11.233 1.578 13.1 C 2.211 14.009 2.958 15.031 3.948 14.999 C 4.898 14.959 5.254 14.382 6.407 14.382 C 7.552 14.382 7.876 14.999 8.882 14.975 C 9.906 14.959 10.555 14.05 11.18 13.132 C 11.902 12.077 12.202 11.054 12.219 10.998 C 12.194 10.99 10.23 10.235 10.206 7.962 C 10.19 6.062 11.756 5.154 11.829 5.113 C 10.936 3.807 9.565 3.661 9.086 3.628 C 7.836 3.531 6.789 4.309 6.204 4.309 Z M 8.316 2.394 C 8.842 1.761 9.191 0.877 9.094 0 C 8.339 0.032 7.43 0.503 6.886 1.136 C 6.399 1.696 5.977 2.597 6.091 3.457 C 6.927 3.522 7.787 3.027 8.315 2.394" fill="var(--t829wi, rgb(0,0,0))" height="15.00000014500371px" id="a2i6ubXcs" transform="translate(0.75 0)" width="12.21867510794063px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG4 = /* @__PURE__ */ forwardRef9((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx5(motion5.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx5("div", { ...rest, ref });
});
var getProps4 = ({ fill, height, id, width, ...props }) => {
  return { ...props, JW2ySfJQW: fill ?? props.JW2ySfJQW ?? "rgb(0, 0, 0)" };
};
var Component4 = /* @__PURE__ */ React4.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, JW2ySfJQW, ...restProps } = getProps4(props);
  return /* @__PURE__ */ _jsx5(SVG4, { ...restProps, className: cx4("framer-DzSTT", className), layoutId, ref, style: { "--t829wi": JW2ySfJQW, ...style } });
});
var css4 = [`.framer-DzSTT { -webkit-mask: ${mask4}; aspect-ratio: 0.875; background-color: var(--t829wi); mask: ${mask4}; width: 14px; }`];
var Icon4 = withCSS4(Component4, css4, "framer-DzSTT");
Icon4.displayName = "Apple";
var mWnYqU4Hh_default = Icon4;
addPropertyControls5(Icon4, { JW2ySfJQW: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Fill", type: ControlType5.Color } });

// http-url:https://framerusercontent.com/modules/rppdZCZId58bHZSRM2Kn/LZkDWYE3bWxav2tfqrA4/xIan1DG3f.js
import { jsx as _jsx6 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls6, ControlType as ControlType6, cx as cx5, motion as motion6, withCSS as withCSS5 } from "./_framer-runtime.js";
import * as React5 from "react";
import { forwardRef as forwardRef11 } from "react";
var mask5 = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 25 16" xmlns="http://www.w3.org/2000/svg"><path d="M 23 14.375 L 14.665 0 L 10.2 2.563 L 17.048 14.375 Z M 15.058 14.375 L 9.554 4.889 L 5.089 7.452 L 9.106 14.375 Z M 4.464 9.785 L 7.124 14.375 L 1.172 14.375 L 0 12.348 Z" fill="var(--t829wi, rgb(0,0,0))" height="14.37500010538681px" id="x7wnYmP_Q" transform="translate(1 1)" width="22.99999939863733px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG5 = /* @__PURE__ */ forwardRef11((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx6(motion6.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx6("div", { ...rest, ref });
});
var getProps5 = ({ fill, height, id, width, ...props }) => {
  return { ...props, JW2ySfJQW: fill ?? props.JW2ySfJQW ?? "rgb(0, 0, 0)" };
};
var Component5 = /* @__PURE__ */ React5.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, JW2ySfJQW, ...restProps } = getProps5(props);
  return /* @__PURE__ */ _jsx6(SVG5, { ...restProps, className: cx5("framer-GYEYg", className), layoutId, ref, style: { "--t829wi": JW2ySfJQW, ...style } });
});
var css5 = [`.framer-GYEYg { -webkit-mask: ${mask5}; aspect-ratio: 1.5625; background-color: var(--t829wi); mask: ${mask5}; width: 25px; }`];
var Icon5 = withCSS5(Component5, css5, "framer-GYEYg");
Icon5.displayName = "Adidas";
var xIan1DG3f_default = Icon5;
addPropertyControls6(Icon5, { JW2ySfJQW: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Fill", type: ControlType6.Color } });

// http-url:https://framerusercontent.com/modules/tYyylxITIdXWrbGMAjZU/RknvpJJGItQgrxJdFQDY/RptAVgyMy.js
import { jsx as _jsx7 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls7, ControlType as ControlType7, cx as cx6, motion as motion7, withCSS as withCSS6 } from "./_framer-runtime.js";
import * as React6 from "react";
import { forwardRef as forwardRef13 } from "react";
var mask6 = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M 7.447 12.183 C 6.545 11.052 6.015 10.061 5.839 9.212 C 5.663 8.527 5.732 7.98 6.033 7.569 C 6.351 7.095 6.825 6.865 7.447 6.865 C 8.069 6.865 8.542 7.095 8.86 7.573 C 9.157 7.98 9.232 8.528 9.051 9.217 C 8.857 10.082 8.327 11.073 7.443 12.189 Z M 13.848 12.943 C 13.725 13.774 13.159 14.463 12.381 14.799 C 10.879 15.452 9.393 14.41 8.12 12.996 C 10.225 10.362 10.613 8.311 9.71 6.984 C 9.18 6.224 8.421 5.854 7.447 5.854 C 5.485 5.854 4.405 7.514 4.829 9.442 C 5.076 10.485 5.731 11.671 6.774 12.997 C 6.121 13.72 5.501 14.234 4.953 14.552 C 4.529 14.781 4.123 14.924 3.734 14.958 C 1.948 15.224 0.549 13.491 1.184 11.705 C 1.272 11.475 1.447 11.051 1.747 10.397 L 1.764 10.362 C 2.74 8.243 3.925 5.835 5.287 3.165 L 5.323 3.077 L 5.709 2.333 C 6.009 1.785 6.133 1.54 6.61 1.238 C 6.841 1.098 7.123 1.028 7.441 1.028 C 8.077 1.028 8.573 1.4 8.785 1.699 C 8.89 1.859 9.015 2.071 9.173 2.335 L 9.545 3.061 L 9.598 3.167 C 10.959 5.836 12.145 8.239 13.117 10.363 L 13.135 10.379 L 13.49 11.193 L 13.702 11.702 C 13.864 12.111 13.898 12.517 13.844 12.941 Z M 14.661 11.35 C 14.537 10.961 14.325 10.503 14.061 9.954 L 14.061 9.934 C 12.802 7.263 11.633 4.862 10.523 2.705 L 10.449 2.596 C 9.658 0.974 9.092 0 7.447 0 C 5.821 0 5.13 1.13 4.424 2.599 L 4.37 2.705 C 3.257 4.863 2.089 7.267 0.835 9.937 L 0.835 9.972 L 0.462 10.785 C 0.322 11.121 0.251 11.297 0.232 11.35 C -0.668 13.827 1.187 16 3.433 16 C 3.451 16 3.521 16 3.61 15.982 L 3.858 15.982 C 5.025 15.84 6.227 15.099 7.447 13.771 C 8.667 15.097 9.871 15.84 11.035 15.982 L 11.283 15.982 C 11.372 16 11.443 16 11.46 16 C 13.707 16.002 15.561 13.826 14.661 11.35" fill="var(--t829wi, rgb(0,0,0))" height="16.000001377592294px" id="DeV98CL2S" transform="translate(0.553 0)" width="14.893480096220204px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG6 = /* @__PURE__ */ forwardRef13((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx7(motion7.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx7("div", { ...rest, ref });
});
var getProps6 = ({ fill, height, id, width, ...props }) => {
  return { ...props, JW2ySfJQW: fill ?? props.JW2ySfJQW ?? "rgb(0, 0, 0)" };
};
var Component6 = /* @__PURE__ */ React6.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, JW2ySfJQW, ...restProps } = getProps6(props);
  return /* @__PURE__ */ _jsx7(SVG6, { ...restProps, className: cx6("framer-iVQDP", className), layoutId, ref, style: { "--t829wi": JW2ySfJQW, ...style } });
});
var css6 = [`.framer-iVQDP { -webkit-mask: ${mask6}; aspect-ratio: 1; background-color: var(--t829wi); mask: ${mask6}; width: 16px; }`];
var Icon6 = withCSS6(Component6, css6, "framer-iVQDP");
Icon6.displayName = "Airbnb";
var RptAVgyMy_default = Icon6;
addPropertyControls7(Icon6, { JW2ySfJQW: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Fill", type: ControlType7.Color } });

// http-url:https://framerusercontent.com/modules/XSPxtu40PI5UlvYkSB0l/5zAoGEFB6wMCnSTD9uz7/QgIA1SDpM.js
import { jsx as _jsx8 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls8, ControlType as ControlType8, cx as cx7, motion as motion8, withCSS as withCSS7 } from "./_framer-runtime.js";
import * as React7 from "react";
import { forwardRef as forwardRef15 } from "react";
var mask7 = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 42 16" xmlns="http://www.w3.org/2000/svg"><path d="M 29.889 1.028 C 29.889 1.028 29.089 1.348 28.159 2.372 C 27.228 3.398 26.687 4.55 27.087 4.856 C 27.242 4.973 27.598 4.996 28.243 4.411 C 28.835 3.893 29.301 3.247 29.605 2.521 C 30.021 1.508 29.889 1.041 29.889 1.028 M 34.979 2.873 C 33.946 2.342 33.19 1.693 32.405 1.291 C 31.654 0.907 31.169 0.745 30.563 0.827 C 30.479 0.842 30.395 0.863 30.314 0.889 C 30.314 0.889 30.627 1.956 29.384 3.746 C 28.126 5.563 26.984 5.551 26.659 5.051 C 26.319 4.525 26.758 3.451 27.491 2.497 C 28.259 1.497 29.606 0.669 29.606 0.669 C 29.606 0.669 29.178 0.406 28.122 1.007 C 27.091 1.586 25.318 2.975 23.674 5.314 C 22.028 7.654 21.701 8.941 21.466 9.954 C 21.231 10.968 21.445 12.052 22.568 12.052 C 23.692 12.052 25 10.338 25.37 9.743 C 26.056 8.633 26.502 6.932 25.569 7.165 C 25.109 7.281 24.737 7.789 24.502 8.28 C 24.354 8.595 24.241 8.925 24.165 9.265 C 23.838 9.399 23.531 9.577 23.253 9.794 C 22.944 10.025 22.655 10.281 22.389 10.559 C 22.389 10.559 22.392 9.748 23.038 8.436 C 23.685 7.126 24.869 6.527 25.541 6.47 C 26.145 6.422 26.933 6.936 26.266 8.829 C 25.599 10.722 23.63 13.025 21.562 13.053 C 19.654 13.08 18.405 10.644 21.061 6.395 C 24.001 1.697 27.45 0.257 28.568 0.097 C 29.688 -0.063 30.053 0.429 30.053 0.429 C 30.726 0.152 31.454 0.033 32.181 0.079 C 33.55 0.171 34.606 1.138 36.003 1.819 C 35.638 2.166 35.292 2.53 34.981 2.872 M 41.121 1.289 C 40.174 1.897 38.863 2.449 37.603 2.331 C 37.285 2.66 36.943 3.042 36.602 3.458 C 38.785 3.89 40.7 2.536 41.717 1.384 C 42.088 0.97 42.407 0.513 42.666 0.022 C 42.203 0.504 41.684 0.93 41.121 1.291 M 38.213 7.446 C 38.229 7.417 38.243 7.387 38.254 7.355 C 38.24 7.252 38.157 7.172 38.053 7.163 C 37.845 7.154 37.56 7.193 36.817 8.017 C 36.2 8.697 35.668 9.451 35.235 10.262 C 34.808 11.041 34.636 11.62 34.879 11.769 C 34.959 11.811 35.052 11.82 35.139 11.796 C 35.304 11.757 35.493 11.601 35.779 11.272 C 35.912 11.115 36.06 10.895 36.238 10.651 C 36.73 9.983 37.967 7.873 38.213 7.446 M 30.481 8.342 C 30.606 8.018 30.764 7.38 30.435 7.129 C 30.081 6.863 29.182 7.487 29.176 8.127 C 29.171 8.783 29.811 9.078 29.964 9.121 C 30.053 9.144 30.081 9.138 30.124 9.069 C 30.261 8.836 30.381 8.593 30.481 8.342 M 29.8 9.533 C 29.577 9.431 29.369 9.298 29.182 9.138 C 28.994 8.981 28.837 8.79 28.719 8.575 C 28.705 8.553 28.693 8.569 28.678 8.589 C 28.666 8.607 28.609 8.658 28.129 9.361 C 27.649 10.065 26.913 11.522 27.578 11.769 C 28.006 11.929 28.718 11.181 29.107 10.685 C 29.372 10.339 29.61 9.974 29.822 9.593 C 29.843 9.553 29.822 9.542 29.8 9.533 M 37.37 11.217 C 37.189 11.506 36.982 12.063 37.578 11.716 C 38.307 11.297 39.345 9.72 39.345 9.72 L 39.816 9.72 C 39.387 10.378 38.91 11.005 38.389 11.593 C 37.651 12.411 36.75 13.156 36.113 13.081 C 35.374 12.996 35.605 12.022 35.605 12.022 C 35.605 12.022 34.545 13.151 33.809 13.071 C 32.819 12.961 33.121 11.736 33.121 11.736 C 33.121 11.736 32.001 13.112 31.237 13.069 C 30.04 12.998 30.341 11.542 30.675 10.516 C 30.853 9.969 31.018 9.538 31.018 9.538 C 31.018 9.538 30.899 9.569 30.645 9.606 C 30.51 9.625 30.268 9.64 30.268 9.64 C 30.268 9.64 29.77 10.52 29.37 11.048 C 28.97 11.576 27.276 13.398 26.277 13.033 C 25.356 12.696 25.662 11.284 26.198 10.162 C 26.981 8.527 29.185 6.175 30.458 6.486 C 31.775 6.806 30.488 9.209 30.488 9.209 C 30.488 9.209 30.488 9.218 30.501 9.225 C 30.527 9.234 30.597 9.243 30.755 9.211 C 30.919 9.178 31.081 9.13 31.237 9.069 C 31.237 9.069 32.563 6.294 34.026 4.477 C 35.489 2.664 38.408 -0.465 39.555 0.292 C 39.832 0.479 39.708 1.119 39.331 1.896 C 39.161 1.95 38.988 1.997 38.814 2.034 C 39.066 1.576 39.233 1.19 39.283 0.92 C 39.455 -0.019 37.265 1.96 35.701 4.084 C 34.758 5.365 33.92 6.721 33.196 8.137 C 33.478 7.964 33.748 7.772 34.003 7.561 C 34.701 6.983 35.365 6.364 35.99 5.707 C 36.593 5.091 37.157 4.439 37.681 3.755 C 37.848 3.746 38.014 3.729 38.179 3.704 C 37.607 4.48 36.984 5.216 36.312 5.908 C 35.69 6.539 35.014 7.218 34.426 7.713 C 33.901 8.157 33.348 8.567 32.771 8.941 C 32.771 8.941 31.402 11.702 32.147 11.878 C 32.584 11.985 33.448 10.651 33.448 10.651 C 33.448 10.651 34.577 8.932 35.256 8.155 C 36.184 7.101 36.981 6.491 37.781 6.481 C 38.245 6.472 38.518 6.966 38.518 6.966 L 38.737 6.628 L 40.083 6.628 C 40.083 6.628 37.569 10.891 37.368 11.213 M 41.121 1.293 C 40.174 1.899 38.863 2.45 37.603 2.333 C 37.283 2.662 36.943 3.044 36.6 3.46 C 38.785 3.892 40.698 2.539 41.717 1.385 C 42.088 0.972 42.407 0.514 42.666 0.022 C 42.203 0.504 41.684 0.93 41.121 1.291 M 22.223 3.384 L 20.943 3.384 L 20.22 4.553 L 21.5 4.553 Z M 16.161 7.432 C 16.707 6.685 18.209 4.07 18.209 4.07 C 18.196 3.967 18.113 3.887 18.01 3.878 C 17.802 3.867 17.455 3.938 16.766 4.801 C 16.076 5.663 15.542 6.347 15.153 7.062 C 14.726 7.841 14.538 8.39 14.785 8.539 C 14.864 8.58 14.955 8.589 15.041 8.566 C 15.201 8.527 15.411 8.365 15.697 8.036 C 15.86 7.84 16.015 7.639 16.163 7.432 M 9.295 3.894 C 8.942 3.627 8.042 4.251 8.037 4.889 C 8.031 5.545 8.847 5.746 8.952 5.75 C 8.983 5.752 9.014 5.746 9.041 5.732 C 9.06 5.721 9.075 5.704 9.084 5.684 C 9.179 5.495 9.265 5.303 9.343 5.106 C 9.468 4.781 9.624 4.145 9.295 3.894 M 8.762 6.152 C 8.518 6.075 8.285 5.967 8.069 5.832 C 7.858 5.696 7.687 5.506 7.573 5.282 C 7.56 5.261 7.546 5.277 7.534 5.297 C 7.521 5.316 7.45 5.405 6.968 6.111 C 6.488 6.818 5.774 8.262 6.442 8.511 C 6.869 8.671 7.587 7.917 7.978 7.423 C 8.271 7.035 8.541 6.631 8.787 6.212 C 8.803 6.169 8.787 6.159 8.762 6.152 M 19.215 6.585 L 19.683 6.585 C 19.683 6.585 17.334 9.985 16.006 9.826 C 15.267 9.739 15.486 8.825 15.486 8.825 C 15.486 8.825 14.446 10.043 13.489 9.796 C 12.623 9.574 13.183 8.132 13.183 8.132 C 13.084 8.171 11.208 10.285 9.889 9.778 C 8.51 9.245 9.226 7.474 9.489 6.943 C 9.711 6.493 9.957 6.056 9.957 6.056 C 9.957 6.056 9.745 6.116 9.61 6.146 L 9.279 6.217 C 9.279 6.217 8.627 7.277 8.229 7.807 C 7.829 8.335 6.134 10.153 5.135 9.793 C 4.136 9.432 4.383 8.033 4.945 6.921 C 5.855 5.122 8.014 2.911 9.315 3.245 C 10.629 3.581 9.541 5.713 9.541 5.713 C 9.541 5.713 9.802 5.746 10.43 5.318 C 11.331 4.703 12.52 3.048 13.809 3.243 C 14.417 3.334 14.982 3.954 14.209 5.135 C 13.962 5.513 13.548 5.851 13.231 5.517 C 13.034 5.307 13.206 4.93 13.414 4.669 C 13.579 4.455 13.838 4.336 14.108 4.351 C 14.108 4.351 14.321 3.865 13.779 3.873 C 13.34 3.881 12.23 4.904 11.605 5.935 C 11.03 6.882 10.159 8.497 11.032 8.849 C 11.834 9.172 13.359 7.362 14.065 6.413 C 14.771 5.465 16.38 3.316 17.731 3.231 C 18.195 3.201 18.472 3.624 18.472 3.624 L 18.629 3.377 L 19.978 3.377 C 19.978 3.377 17.436 7.62 17.237 7.94 C 17.08 8.191 16.874 8.758 17.445 8.44 C 18.017 8.123 19.215 6.585 19.215 6.585 M 18.479 13.384 C 17.486 12.695 16.295 12.347 15.087 12.393 C 14.425 12.412 13.811 12.744 13.434 13.289 C 12.918 12.392 11.902 11.841 10.328 11.853 C 7.786 11.881 5.263 13.055 3.267 13.053 C 1.352 13.053 -0.045 11.849 0.001 9.711 C 0.085 5.961 3.254 2.584 5.619 1.064 C 6.982 0.193 8.124 -0.069 8.869 0.015 C 9.413 0.075 10.067 0.705 9.654 1.631 C 9.048 2.984 8.211 2.873 8.241 2.226 C 8.259 1.805 8.54 1.54 8.75 1.393 C 8.902 1.313 9.072 1.271 9.244 1.272 C 9.365 1.17 9.452 0.429 8.481 0.673 C 7.51 0.916 6.33 1.874 5.21 3.11 C 4.09 4.347 2.348 6.685 1.918 9.14 C 1.717 10.278 1.848 12.354 4.549 12.331 C 6.837 12.313 10.211 10.804 13.311 10.836 C 14.391 10.832 15.451 11.122 16.378 11.675 C 17.18 12.169 18.142 12.891 18.483 13.384" fill="var(--t829wi, rgb(0,0,0))" height="13.383630258115721px" id="iWzuF7Ol_" transform="translate(0.001 1.308)" width="42.66600513373487px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG7 = /* @__PURE__ */ forwardRef15((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx8(motion8.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx8("div", { ...rest, ref });
});
var getProps7 = ({ fill, height, id, width, ...props }) => {
  return { ...props, JW2ySfJQW: fill ?? props.JW2ySfJQW ?? "rgb(0, 0, 0)" };
};
var Component7 = /* @__PURE__ */ React7.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, JW2ySfJQW, ...restProps } = getProps7(props);
  return /* @__PURE__ */ _jsx8(SVG7, { ...restProps, className: cx7("framer-UQEgk", className), layoutId, ref, style: { "--t829wi": JW2ySfJQW, ...style } });
});
var css7 = [`.framer-UQEgk { -webkit-mask: ${mask7}; aspect-ratio: 2.625; background-color: var(--t829wi); mask: ${mask7}; width: 42px; }`];
var Icon7 = withCSS7(Component7, css7, "framer-UQEgk");
Icon7.displayName = "Coca Cola";
var QgIA1SDpM_default = Icon7;
addPropertyControls8(Icon7, { JW2ySfJQW: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Fill", type: ControlType8.Color } });

// http-url:https://framerusercontent.com/modules/qO9r5JLjZIj8a5saCxvc/3uvrI2IJKJ9LT6aI5jIw/TcH7JkAeA.js
var AdidasFonts = getFonts(xIan1DG3f_default);
var OracleFonts = getFonts(ycBZ59n4d_default);
var CocaColaFonts = getFonts(QgIA1SDpM_default);
var MercedesFonts = getFonts(XowUhSFsa_default);
var TeslaFonts = getFonts(wVlMzX1WC_default);
var AirbnbFonts = getFonts(RptAVgyMy_default);
var AppleFonts = getFonts(mWnYqU4Hh_default);
var TickerFonts = getFonts(Ticker);
var cycleOrder = ["xlDHYFhXd", "rHrV3_pXN"];
var serializationHash = "framer-Dlbvm";
var variantClassNames = { rHrV3_pXN: "framer-v-1a6y9gq", xlDHYFhXd: "framer-v-1jb66ec" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var animation = { opacity: 1, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, transition: transition1 };
var Transition = ({ value, children }) => {
  const config = React8.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React8.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx9(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Default: "xlDHYFhXd", Phone: "rHrV3_pXN" };
var Variants = motion9.create(React8.Fragment);
var getProps8 = ({ height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "xlDHYFhXd" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component8 = /* @__PURE__ */ React8.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React8.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, ...restProps } = getProps8(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "xlDHYFhXd", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx8(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx9(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx9(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx9(Transition, { value: transition1, children: /* @__PURE__ */ _jsx9(motion9.div, { ...restProps, ...gestureHandlers, className: cx8(scopingClassNames, "framer-1jb66ec", className, classNames), "data-framer-name": "Default", layoutDependency, layoutId: "Logosticker__xlDHYFhXd", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ rHrV3_pXN: { "data-framer-name": "Phone" } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx9(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx9(SmartComponentScopedContainer, { className: "framer-e9lz5l-container", isModuleExternal: true, layoutDependency, layoutId: "Logosticker__W_LE33e56-container", nodeId: "W_LE33e56", rendersWithMotion: true, scopeId: "TcH7JkAeA", children: /* @__PURE__ */ _jsx9(Ticker, { alignment: "center", direction: "left", fadeOptions: { fadeAlpha: 0, fadeContent: true, fadeInset: 0, fadeWidth: 25, overflow: false }, gap: 59, height: "100%", hoverFactor: 0.6, id: "W_LE33e56", layoutId: "Logosticker__W_LE33e56", padding: 0, paddingBottom: 0, paddingLeft: 0, paddingPerSide: false, paddingRight: 0, paddingTop: 0, sizingOptions: { heightType: true, widthType: true }, slots: [/* @__PURE__ */ _jsx9(motion9.div, { className: "framer-ef94fp", "data-framer-name": "Logo", layoutDependency, layoutId: "Logosticker__En_1q8O5E", whileHover: animation, children: /* @__PURE__ */ _jsx9(xIan1DG3f_default, { animated: true, className: "framer-1ecn7hy", layoutDependency, layoutId: "Logosticker__PQr1CPmPk", style: { "--t829wi": "rgba(255, 255, 255, 0.78)" } }) }), /* @__PURE__ */ _jsx9(motion9.div, { className: "framer-c47yaq", "data-framer-name": "Logo", layoutDependency, layoutId: "Logosticker__GVPM4EtF5", whileHover: animation, children: /* @__PURE__ */ _jsx9(ycBZ59n4d_default, { animated: true, className: "framer-1w8oos6", layoutDependency, layoutId: "Logosticker__kBdW2Xtkp", style: { "--t829wi": "rgba(255, 255, 255, 0.78)" } }) }), /* @__PURE__ */ _jsx9(motion9.div, { className: "framer-1bhcbzj", "data-framer-name": "Logo", layoutDependency, layoutId: "Logosticker__n67r1m7mF", whileHover: animation, children: /* @__PURE__ */ _jsx9(QgIA1SDpM_default, { animated: true, className: "framer-pjwkxl", layoutDependency, layoutId: "Logosticker__I1Zxl08mx", style: { "--t829wi": "rgba(255, 255, 255, 0.78)" } }) }), /* @__PURE__ */ _jsx9(motion9.div, { className: "framer-9a8t8k", "data-framer-name": "Logo", layoutDependency, layoutId: "Logosticker__ciSlomB79", whileHover: animation, children: /* @__PURE__ */ _jsx9(XowUhSFsa_default, { animated: true, className: "framer-1n7i2ge", layoutDependency, layoutId: "Logosticker__BNWHCfzMT", style: { "--t829wi": "rgba(255, 255, 255, 0.78)" } }) }), /* @__PURE__ */ _jsx9(motion9.div, { className: "framer-iqqk4n", "data-framer-name": "Logo", layoutDependency, layoutId: "Logosticker__ZIDyIZfYp", whileHover: animation, children: /* @__PURE__ */ _jsx9(wVlMzX1WC_default, { animated: true, className: "framer-n2c072", layoutDependency, layoutId: "Logosticker__Z5z68O79S", style: { "--t829wi": "rgba(255, 255, 255, 0.78)" } }) }), /* @__PURE__ */ _jsx9(motion9.div, { className: "framer-1i87evl", "data-framer-name": "Logo", layoutDependency, layoutId: "Logosticker__sUMqkUzLE", whileHover: animation, children: /* @__PURE__ */ _jsx9(RptAVgyMy_default, { animated: true, className: "framer-xuyhh4", layoutDependency, layoutId: "Logosticker__Ced1ao5M9", style: { "--t829wi": "rgba(255, 255, 255, 0.78)" } }) }), /* @__PURE__ */ _jsx9(motion9.div, { className: "framer-1czi3ej", "data-framer-name": "Logo", layoutDependency, layoutId: "Logosticker__WzxqrrQcG", whileHover: animation, children: /* @__PURE__ */ _jsx9(mWnYqU4Hh_default, { animated: true, className: "framer-2eewuf", layoutDependency, layoutId: "Logosticker__X7YBwNVhh", style: { "--t829wi": "rgba(255, 255, 255, 0.78)" } }) })], speed: 30, style: { height: "100%", width: "100%" }, width: "100%", ...addPropertyOverrides({ rHrV3_pXN: { gap: 5 } }, baseVariant, gestureVariant) }) }) }) }) }) }) });
});
var css8 = [".framer-Dlbvm.framer-dn9q0, .framer-Dlbvm .framer-dn9q0 { display: block; }", ".framer-Dlbvm.framer-1jb66ec { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-Dlbvm .framer-e9lz5l-container { flex: 1 0 0px; height: 112px; position: relative; width: 1px; }", ".framer-Dlbvm .framer-ef94fp, .framer-Dlbvm .framer-c47yaq, .framer-Dlbvm .framer-1bhcbzj, .framer-Dlbvm .framer-9a8t8k, .framer-Dlbvm .framer-iqqk4n, .framer-Dlbvm .framer-1i87evl, .framer-Dlbvm .framer-1czi3ej { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: 90px; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 90px; will-change: var(--framer-will-change-effect-override, transform); }", ".framer-Dlbvm .framer-1ecn7hy, .framer-Dlbvm .framer-1w8oos6, .framer-Dlbvm .framer-1n7i2ge, .framer-Dlbvm .framer-n2c072, .framer-Dlbvm .framer-xuyhh4, .framer-Dlbvm .framer-2eewuf { flex: none; height: auto; position: relative; width: 34px; }", ".framer-Dlbvm .framer-pjwkxl { flex: none; height: auto; position: relative; width: 50px; }", ".framer-Dlbvm.framer-v-1a6y9gq.framer-1jb66ec { width: 100%; }"];
var FramerTcH7JkAeA = withCSS8(Component8, css8, "framer-Dlbvm");
var TcH7JkAeA_default = FramerTcH7JkAeA;
FramerTcH7JkAeA.displayName = "Logos ticker";
FramerTcH7JkAeA.defaultProps = { height: 112, width: 1080 };
addPropertyControls9(FramerTcH7JkAeA, { variant: { options: ["xlDHYFhXd", "rHrV3_pXN"], optionTitles: ["Default", "Phone"], title: "Variant", type: ControlType9.Enum } });
addFonts(FramerTcH7JkAeA, [{ explicitInter: true, fonts: [] }, ...AdidasFonts, ...OracleFonts, ...CocaColaFonts, ...MercedesFonts, ...TeslaFonts, ...AirbnbFonts, ...AppleFonts, ...TickerFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerTcH7JkAeA", "slots": [], "annotations": { "framerContractVersion": "1", "framerIntrinsicWidth": "1080", "framerAutoSizeImages": "true", "framerDisplayContentsDiv": "false", "framerImmutableVariables": "true", "framerComponentViewportWidth": "true", "framerIntrinsicHeight": "112", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"rHrV3_pXN":{"layout":["fixed","auto"]}}}', "framerColorSyntax": "true" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  TcH7JkAeA_default as default
};
