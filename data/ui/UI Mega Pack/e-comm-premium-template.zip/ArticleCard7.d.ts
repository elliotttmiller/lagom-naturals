export interface Articlecard7Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default" → ni4mQovhk
   *   "Featured" → N8qYxKQ6y
   */
  variant?: 'Default' | 'Featured' | 'ni4mQovhk' | 'N8qYxKQ6y';
  /**
   * Category — pass as `PfMYNJBNw` not `category`.
   * @default "Design"
   */
  PfMYNJBNw?: string;
  onPfMYNJBNwChange?: string;
  /**
   * Title — pass as `L9mw9ZOxZ` not `title`.
   * @default "Where Form Meets Light"
   */
  L9mw9ZOxZ?: string;
  onL9mw9ZOxZChange?: string;
  /**
   * Excerpt — pass as `cY8goLuDU` not `excerpt`.
   * @default "A closer look at how sculptural form and generative design shape the way a room feels."
   */
  cY8goLuDU?: string;
  oncY8goLuDUChange?: string;
  /**
   * Date — pass as `JopOQ9ZFx` not `date`.
   * @default "Jan 2026"
   */
  JopOQ9ZFx?: string;
  onJopOQ9ZFxChange?: string;
  /**
   * CTA Label — pass as `gHAE4AmGZ` not `ctaLabel`.
   * @default "Read Article"
   */
  gHAE4AmGZ?: string;
  ongHAE4AmGZChange?: string;
  /**
   * Link — pass as `RJs5x2xvh` not `link`.
   */
  RJs5x2xvh?: string;
  /**
   * Image — pass as `Yr2zrSOfo` not `image`.
   */
  Yr2zrSOfo?: string;
  /** Additional properties */
  [key: string]: unknown;
}
