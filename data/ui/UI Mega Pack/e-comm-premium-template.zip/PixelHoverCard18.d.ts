export interface Pixelhovercard18Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Variant 2" → IAhN44CCY
   *   "Default" → rLvyKHUUa
   */
  variant?: 'Variant 2' | 'Default' | 'rLvyKHUUa' | 'IAhN44CCY';
  /**
   * Image A — pass as `vPrylSrON` not `imageA`.
   */
  vPrylSrON?: string;
  /**
   * Image B — pass as `YDd3MOwFB` not `imageB`.
   */
  YDd3MOwFB?: string;
  /**
   * Price — pass as `RvKuTJjVK` not `price`.
   * @default "€89"
   */
  RvKuTJjVK?: string;
  onRvKuTJjVKChange?: string;
  /**
   * Title — pass as `ZNKcIp9OT` not `title`.
   * @default "Rosewood Silk Shirt Template"
   */
  ZNKcIp9OT?: string;
  onZNKcIp9OTChange?: string;
  /**
   * Subtitle — pass as `gJVTA1FBb` not `subtitle`.
   * @default "Fluid silk in dusty rose with a relaxed collar and soft matte sheen."
   */
  gJVTA1FBb?: string;
  ongJVTA1FBbChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
