# Video

Exported from Framer using Design to AI.

## Components

- `Video`
- `Dfxq4dxbw`
- `Logos`
- `Video2`
- `Video3`
- `Video4`
- `PixelHoverCard`
- `PixelHoverCard2`
- `PixelHoverCard3`
- `PixelHoverCard4`
- `Card`
- `Card2`
- `Card3`
- `Quoteliftpro`
- `ArticleCard`
- `Hlgmh5xpi`
- `Question`
- `Question2`
- `Question3`
- `Question4`
- `Question5`
- `Question6`
- `Zajzqjjcf`
- `Zajzqjjcf2`
- `Zajzqjjcf3`
- `Hlgmh5xpi2`
- `Wb04fbjym`
- `SendContact`
- `Video5`
- `Dfxq4dxbw2`
- `Logos2`
- `Video6`
- `Dfxq4dxbw3`
- `Logos3`
- `Video7`
- `Video8`
- `Video9`
- `PixelHoverCard5`
- `PixelHoverCard6`
- `PixelHoverCard7`
- `PixelHoverCard8`
- `Card4`
- `Card5`
- `Card6`
- `Quoteliftpro2`
- `ArticleCard2`
- `Hlgmh5xpi3`
- `Question7`
- `Question8`
- `Question9`
- `Question10`
- `Question11`
- `Question12`
- `Zajzqjjcf4`
- `Zajzqjjcf5`
- `Zajzqjjcf6`
- `Hlgmh5xpi4`
- `Wb04fbjym2`
- `SendContact2`
- `Video10`
- `Video11`
- `Video12`
- `PixelHoverCard9`
- `PixelHoverCard10`
- `PixelHoverCard11`
- `PixelHoverCard12`
- `Card7`
- `Card8`
- `Card9`
- `Quoteliftpro3`
- `ArticleCard3`
- `Hlgmh5xpi5`
- `Question13`
- `Question14`
- `Question15`
- `Question16`
- `Question17`
- `Question18`
- `Zajzqjjcf7`
- `Zajzqjjcf8`
- `Zajzqjjcf9`
- `Hlgmh5xpi6`
- `Wb04fbjym3`
- `SendContact3`
- `Video13`
- `Dfxq4dxbw4`
- `Logos4`
- `Video14`
- `Video15`
- `Video16`
- `PixelHoverCard13`
- `PixelHoverCard14`
- `PixelHoverCard15`
- `PixelHoverCard16`
- `Card10`
- `Card11`
- `Card12`
- `Quoteliftpro4`
- `ArticleCard4`
- `Hlgmh5xpi7`
- `Question19`
- `Question20`
- `Question21`
- `Question22`
- `Question23`
- `Question24`
- `Zajzqjjcf10`
- `Zajzqjjcf11`
- `Zajzqjjcf12`
- `Hlgmh5xpi8`
- `Wb04fbjym4`
- `SendContact4`
- `Video17`
- `Dfxq4dxbw5`
- `Logos5`
- `Video18`
- `Video19`
- `Video20`
- `PixelHoverCard17`
- `PixelHoverCard18`
- `PixelHoverCard19`
- `PixelHoverCard20`
- `Card13`
- `Card14`
- `Card15`
- `Quoteliftpro5`
- `ArticleCard5`
- `Hlgmh5xpi9`
- `Question25`
- `Question26`
- `Question27`
- `Question28`
- `Question29`
- `Question30`
- `Zajzqjjcf13`
- `Zajzqjjcf14`
- `Zajzqjjcf15`
- `Hlgmh5xpi10`
- `Wb04fbjym5`
- `SendContact5`
- `Video21`
- `Dfxq4dxbw6`
- `Logos6`
- `Video22`
- `Video23`
- `Video24`
- `PixelHoverCard21`
- `PixelHoverCard22`
- `PixelHoverCard23`
- `PixelHoverCard24`
- `Card16`
- `Card17`
- `Card18`
- `Quoteliftpro6`
- `ArticleCard6`
- `Hlgmh5xpi11`
- `Question31`
- `Question32`
- `Question33`
- `Question34`
- `Question35`
- `Question36`
- `Zajzqjjcf16`
- `Zajzqjjcf17`
- `Zajzqjjcf18`
- `Hlgmh5xpi12`
- `Wb04fbjym6`
- `SendContact6`
- `Video25`
- `Dfxq4dxbw7`
- `Logos7`
- `Video26`
- `Video27`
- `Video28`
- `PixelHoverCard25`
- `PixelHoverCard26`
- `PixelHoverCard27`
- `PixelHoverCard28`
- `Card19`
- `Card20`
- `Card21`
- `Quoteliftpro7`
- `ArticleCard7`
- `Hlgmh5xpi13`
- `Question37`
- `Question38`
- `Question39`
- `Question40`
- `Question41`
- `Question42`
- `Zajzqjjcf19`
- `Zajzqjjcf20`
- `Zajzqjjcf21`
- `Hlgmh5xpi14`
- `Wb04fbjym7`
- `SendContact7`

## Installation

```bash
# Copy this folder to your project, then install dependencies:
npm install react react-dom framer-motion @motionone/dom@10.13.1
```

## Usage

```tsx
import { Video } from './Video';

function App() {
  return <Video />;
}
```

## Responsive Components

For components with responsive variants, use the responsive runtime:

```tsx
// Import the CSS for responsive breakpoints
import './Video/_responsive-runtime.css';

// Option 1: Use the useBreakpoint hook
import { useBreakpoint } from './Video/_responsive-runtime';

function App() {
  const breakpoint = useBreakpoint(); // 'base' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

  return <Video variant={breakpoint === 'base' ? 'mobile' : 'desktop'} />;
}

// Option 2: Use the WithBreakpoints HOC
import { WithBreakpoints } from './Video/_responsive-runtime';

function App() {
  return (
    <WithBreakpoints
      Component={Video}
      variants={{
        base: 'mobile',    // 0px+
        md: 'tablet',      // 768px+
        lg: 'desktop'      // 1024px+
      }}
    />
  );
}
```

### Breakpoints

| Name | Min Width | Typical Use |
|------|-----------|-------------|
| base | 0px | Mobile |
| sm | 390px | Large mobile |
| md | 768px | Tablet |
| lg | 1024px | Laptop |
| xl | 1280px | Desktop |
| 2xl | 1536px | Large desktop |

## Peer Dependencies

These components require the following packages in your project:

- `react` >= 18.0.0
- `react-dom` >= 18.0.0
- `framer-motion` >= 10.0.0

## Note

The Framer runtime is bundled as `_framer-runtime.js` - no external Framer dependency needed.
These exports are self-contained and work out of the box.

## Generated

Created with [Design to AI](https://designtoai.com)
