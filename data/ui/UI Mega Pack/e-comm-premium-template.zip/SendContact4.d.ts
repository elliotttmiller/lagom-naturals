export interface Sendcontact4Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default" → kwUuiKZ50
   *   "Loading" → CG49oylzr
   *   "Success" → zA6Vw8W0d
   */
  variant?: 'Default' | 'Loading' | 'Success' | 'kwUuiKZ50' | 'CG49oylzr' | 'zA6Vw8W0d';
  /**
   * Label — pass as `kzPvUBrSt` not `label`.
   * @default "Enviar Mensaje"
   */
  kzPvUBrSt?: string;
  onkzPvUBrStChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
