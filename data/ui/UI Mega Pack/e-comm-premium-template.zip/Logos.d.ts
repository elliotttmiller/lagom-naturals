export interface LogosProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default" → xlDHYFhXd
   *   "Phone" → rHrV3_pXN
   */
  variant?: 'Default' | 'Phone' | 'xlDHYFhXd' | 'rHrV3_pXN';
  /** Additional properties */
  [key: string]: unknown;
}
