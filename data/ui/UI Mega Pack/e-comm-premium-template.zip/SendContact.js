var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/NA51Csrvkeu4xUNjOiKw/zf0FAFJAdzD2oTrRShlm/WnU2werlw.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addFonts, addPropertyControls, ControlType, cx, RichText, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef } from "react";
var cycleOrder = ["kwUuiKZ50", "CG49oylzr", "zA6Vw8W0d"];
var serializationHash = "framer-vg7Sr";
var variantClassNames = { CG49oylzr: "framer-v-1mjiy7e", kwUuiKZ50: "framer-v-d6g4h3", zA6Vw8W0d: "framer-v-19vc8xs" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { delay: 0, duration: 0.2, ease: [0.44, 0, 0.56, 1], type: "tween" };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Default: "kwUuiKZ50", Loading: "CG49oylzr", Success: "zA6Vw8W0d" };
var Variants = motion.create(React.Fragment);
var getProps = ({ height, id, label, width, ...props }) => {
  return { ...props, kzPvUBrSt: label ?? props.kzPvUBrSt ?? "Enviar Mensaje", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "kwUuiKZ50" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, kzPvUBrSt, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "kwUuiKZ50", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsx(motion.button, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-d6g4h3", className, classNames), "data-framer-name": "Default", "data-reset": "button", layoutDependency, layoutId: "SendContactButton__kwUuiKZ50", ref: refBinding, style: { backgroundColor: "rgb(10, 10, 10)", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100, opacity: 1, ...style }, variants: { CG49oylzr: { backgroundColor: "rgb(255, 107, 0)", opacity: 0.7 }, zA6Vw8W0d: { backgroundColor: "rgb(34, 197, 94)", opacity: 1 } }, ...addPropertyOverrides({ CG49oylzr: { "data-framer-name": "Loading" }, zA6Vw8W0d: { "data-framer-name": "Success" } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.p, { dir: "auto", style: { "--font-selector": "SW50ZXItU2VtaUJvbGQ=", "--framer-font-size": "15px", "--framer-font-weight": "600", "--framer-letter-spacing": "0.02em", "--framer-text-color": "var(--extracted-r6o4lv, #ffffff)" }, children: "Label" }) }), className: "framer-4stso7", fonts: ["Inter-SemiBold"], layoutDependency, layoutId: "SendContactButton__nJsRmTeAi", style: { "--extracted-r6o4lv": "#ffffff" }, text: kzPvUBrSt, verticalAlignment: "top", withExternalLayout: true }) }) }) }) });
});
var css = [".framer-vg7Sr.framer-lnsmxj, .framer-vg7Sr .framer-lnsmxj { display: block; }", ".framer-vg7Sr.framer-d6g4h3 { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 8px; height: auto; justify-content: center; padding: 0px; position: relative; width: 100%; }", ".framer-vg7Sr .framer-4stso7 { flex: none; height: auto; position: relative; white-space: pre; width: auto; }"];
var FramerWnU2werlw = withCSS(Component, css, "framer-vg7Sr");
var WnU2werlw_default = FramerWnU2werlw;
FramerWnU2werlw.displayName = "Send Contact Button";
FramerWnU2werlw.defaultProps = { height: 52, width: 280 };
addPropertyControls(FramerWnU2werlw, { variant: { options: ["kwUuiKZ50", "CG49oylzr", "zA6Vw8W0d"], optionTitles: ["Default", "Loading", "Success"], title: "Variant", type: ControlType.Enum }, kzPvUBrSt: { defaultValue: "Enviar Mensaje", title: "Label", type: ControlType.String }, onkzPvUBrStChange: { changes: "kzPvUBrSt", type: ControlType.ChangeHandler } });
addFonts(FramerWnU2werlw, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/hyOgCu0Xnghbimh0pE8QTvtt2AU.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/NeGmSOXrPBfEFIy5YZeHq17LEDA.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/oYaAX5himiTPYuN8vLWnqBbfD2s.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/lEJLP4R0yuCaMCjSXYHtJw72M.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/cRJyLNuTJR5jbyKzGi33wU9cqIQ.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/yDtI2UI8XcEg1W2je9XPN3Noo.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/A0Wcc7NgXMjUuFdquHDrIZpzZw0.woff2", weight: "600" }] }], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerWnU2werlw", "slots": [], "annotations": { "framerIntrinsicHeight": "52", "framerContractVersion": "1", "framerComponentViewportWidth": "true", "framerIntrinsicWidth": "280", "framerColorSyntax": "true", "framerImmutableVariables": "true", "framerDisplayContentsDiv": "false", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","fixed"]},"CG49oylzr":{"layout":["fixed","fixed"]},"zA6Vw8W0d":{"layout":["fixed","fixed"]}}}', "framerAutoSizeImages": "true", "framerVariables": '{"kzPvUBrSt":"label"}' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  WnU2werlw_default as default
};
