export interface J3psnh8hvProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → PAdYraqu8
   *   "Phone" → VObO3bd4a
   *   "Tablet" → o7OEbZHJX
   */
  variant?: 'Desktop' | 'Phone' | 'Tablet' | 'PAdYraqu8' | 'o7OEbZHJX' | 'VObO3bd4a';
  /** Additional properties */
  [key: string]: unknown;
}
