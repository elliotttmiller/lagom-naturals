export interface Splashscreen1Props {
  /**
   * Logo
   */
  logo?: string;
  /**
   * Background — pass as `backgroundColor` not `background`.
   * @default "#000000"
   */
  backgroundColor?: string;
  /**
   * Logo Size Type
   * Options: "auto" | "fixed" | "percentage"
   * @default "auto"
   */
  logoSizeType?: 'auto' | 'fixed' | 'percentage';
  /**
   * Logo Width
   * Range: min: 10, max: 2000, step: 10
   * @default 300
   */
  logoWidth?: number;
  /**
   * Logo Height
   * Range: min: 10, max: 2000, step: 10
   * @default 300
   */
  logoHeight?: number;
  /**
   * Animation Duration — pass as `duration` not `animationDuration`.
   * Range: min: 0.5, max: 5, step: 0.1
   * @default 2
   */
  duration?: number;
  /**
   * Fade Out Duration
   * Range: min: 0.3, max: 3, step: 0.1
   * @default 1
   */
  fadeOutDuration?: number;
  /**
   * Auto Hide
   * @default true
   */
  autoHide?: boolean;
  /**
   * Logo Easing
   * Options: "elegantEntry" | "elegantExit" | "smooth" | "snappy" | "bouncy" | "linear" | "easeIn" | "easeOut" | "easeInOut"
   * @default "elegantEntry"
   */
  logoEasing?: 'elegantEntry' | 'elegantExit' | 'smooth' | 'snappy' | 'bouncy' | 'linear' | 'easeIn' | 'easeOut' | 'easeInOut';
  /**
   * Curtain Easing
   * Options: "elegantEntry" | "elegantExit" | "smooth" | "snappy" | "bouncy" | "linear" | "easeIn" | "easeOut" | "easeInOut"
   * @default "elegantExit"
   */
  curtainEasing?: 'elegantEntry' | 'elegantExit' | 'smooth' | 'snappy' | 'bouncy' | 'linear' | 'easeIn' | 'easeOut' | 'easeInOut';
  /** Additional properties */
  [key: string]: unknown;
}
