var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/RX31DzT9Jjpcv4xJnA50/egvRgLibbPgqQhR733H0/Splash_Screen_1.js
import { jsx as _jsx } from "react/jsx-runtime";
import { motion, useAnimation } from "framer-motion";
import { useEffect, useState, startTransition, useRef } from "react";
import { addPropertyControls, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
var easingFunctions = { elegantEntry: [0.22, 1, 0.36, 1], elegantExit: [0.64, 0, 0.78, 0], smooth: [0.4, 0, 0.2, 1], snappy: [0.8, 0, 0.2, 1], bouncy: [0.68, -0.55, 0.265, 1.55], linear: [0, 0, 1, 1], easeIn: [0.42, 0, 1, 1], easeOut: [0, 0, 0.58, 1], easeInOut: [0.42, 0, 0.58, 1] };
function splash_screen(props) {
  const { logo = { src: "https://framerusercontent.com/images/GfGkADagM4KEibNcIiRUWlfrR0.jpg", alt: "Logo" }, backgroundColor = "#000000", logoSizeType = "auto", logoWidth = 300, logoHeight = 300, duration = 2, fadeOutDuration = 1, autoHide = true, logoEasing = "elegantEntry", curtainEasing = "elegantExit", style } = props;
  const [isVisible, setIsVisible] = useState(true);
  const controls = useAnimation();
  const curtainControls = useAnimation();
  const isStatic = useIsStaticRenderer();
  const isMountedRef = useRef(true);
  const [logoSize, setLogoSize] = useState({ width: 300, height: 300 });
  const containerRef = useRef(null);
  useEffect(() => {
    if (typeof __dai_window === "undefined" || !containerRef.current)
      return;
    const updateLogoSize = () => {
      if (!containerRef.current)
        return;
      const rect = containerRef.current.getBoundingClientRect();
      let width;
      let height;
      if (logoSizeType === "auto") {
        const minDimension = Math.min(rect.width, rect.height);
        const baseSize = Math.max(150, Math.min(500, minDimension * 0.4));
        width = baseSize;
        height = baseSize;
      } else if (logoSizeType === "percentage") {
        width = rect.width * logoWidth / 100;
        height = rect.height * logoHeight / 100;
      } else {
        width = logoWidth;
        height = logoHeight;
      }
      startTransition(() => setLogoSize({ width, height }));
    };
    updateLogoSize();
    __dai_window.addEventListener("resize", updateLogoSize);
    return () => {
      __dai_window.removeEventListener("resize", updateLogoSize);
    };
  }, [logoSizeType, logoWidth, logoHeight]);
  useEffect(() => {
    if (isStatic || !autoHide)
      return;
    isMountedRef.current = true;
    let timeoutId = null;
    const animateSequence = async () => {
      try {
        await controls.start({ y: [100, 0], opacity: [0, 1], scale: [0.95, 1], transition: { duration, ease: easingFunctions[logoEasing] || easingFunctions.elegantEntry } });
        if (!isMountedRef.current)
          return;
        await new Promise((resolve) => {
          timeoutId = __dai_window.setTimeout(resolve, 800);
        });
        if (!isMountedRef.current)
          return;
        await Promise.all([controls.start({ opacity: 0, transition: { duration: fadeOutDuration * 0.6, ease: easingFunctions[curtainEasing] || easingFunctions.elegantExit } }), curtainControls.start({ y: "-100%", transition: { duration: fadeOutDuration, ease: easingFunctions[curtainEasing] || easingFunctions.elegantExit } })]);
        if (!isMountedRef.current)
          return;
        startTransition(() => setIsVisible(false));
      } catch (error) {
      }
    };
    animateSequence();
    return () => {
      isMountedRef.current = false;
      if (timeoutId !== null) {
        clearTimeout(timeoutId);
      }
      controls.stop();
      curtainControls.stop();
    };
  }, [controls, curtainControls, duration, fadeOutDuration, autoHide, isStatic, logoEasing, curtainEasing]);
  if (!isVisible && !isStatic)
    return null;
  return /* @__PURE__ */ _jsx(motion.div, { ref: containerRef, animate: isStatic ? void 0 : curtainControls, initial: isStatic ? void 0 : { y: 0 }, style: { ...style, position: "relative", width: "100%", height: "100%", backgroundColor, display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }, children: /* @__PURE__ */ _jsx(motion.div, { animate: isStatic ? void 0 : controls, initial: isStatic ? void 0 : { y: 100, opacity: 0 }, style: { display: "flex", alignItems: "center", justifyContent: "center", width: "100%", height: "100%", maxWidth: `${logoSize.width}px`, maxHeight: `${logoSize.height}px`, padding: "20px" }, children: /* @__PURE__ */ _jsx("img", { src: logo.src, alt: logo.alt, style: { width: "100%", height: "100%", objectFit: "contain" } }) }) });
}
addPropertyControls(splash_screen, { logo: { type: ControlType.ResponsiveImage, title: "Logo" }, backgroundColor: { type: ControlType.Color, title: "Background", defaultValue: "#000000" }, logoSizeType: { type: ControlType.Enum, title: "Logo Size Type", defaultValue: "auto", options: ["auto", "fixed", "percentage"], optionTitles: ["Auto", "Fixed (px)", "Percentage (%)"], displaySegmentedControl: true }, logoWidth: { type: ControlType.Number, title: "Logo Width", defaultValue: 300, min: 10, max: 2e3, step: 10, unit: "px", hidden: ({ logoSizeType }) => logoSizeType === "auto" }, logoHeight: { type: ControlType.Number, title: "Logo Height", defaultValue: 300, min: 10, max: 2e3, step: 10, unit: "px", hidden: ({ logoSizeType }) => logoSizeType === "auto" }, duration: { type: ControlType.Number, title: "Animation Duration", defaultValue: 2, min: 0.5, max: 5, step: 0.1, unit: "s" }, fadeOutDuration: { type: ControlType.Number, title: "Fade Out Duration", defaultValue: 1, min: 0.3, max: 3, step: 0.1, unit: "s" }, autoHide: { type: ControlType.Boolean, title: "Auto Hide", defaultValue: true, enabledTitle: "Yes", disabledTitle: "No" }, logoEasing: { type: ControlType.Enum, title: "Logo Easing", defaultValue: "elegantEntry", options: ["elegantEntry", "elegantExit", "smooth", "snappy", "bouncy", "linear", "easeIn", "easeOut", "easeInOut"], optionTitles: ["Elegant Entry", "Elegant Exit", "Smooth", "Snappy", "Bouncy", "Linear", "Ease In", "Ease Out", "Ease In Out"] }, curtainEasing: { type: ControlType.Enum, title: "Curtain Easing", defaultValue: "elegantExit", options: ["elegantEntry", "elegantExit", "smooth", "snappy", "bouncy", "linear", "easeIn", "easeOut", "easeInOut"], optionTitles: ["Elegant Entry", "Elegant Exit", "Smooth", "Snappy", "Bouncy", "Linear", "Ease In", "Ease Out", "Ease In Out"] } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "splash_screen", "slots": [], "annotations": { "framerSupportedLayoutWidth": "fixed", "framerSupportedLayoutHeight": "fixed", "framerContractVersion": "1", "framerIntrinsicWidth": "1200", "framerIntrinsicHeight": "800" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  splash_screen as default
};
