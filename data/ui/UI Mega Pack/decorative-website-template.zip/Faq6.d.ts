/**
 * Props for Faq6 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Faq6Props {
  [key: string]: unknown;
}
