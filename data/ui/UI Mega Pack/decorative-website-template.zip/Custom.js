
// ─────────────────────────────────────────────────────────────
// CMS Data Stub (Framer plugin v15)
//
// This component was bound to a Framer Collection. The runtime CMS
// machinery has been stripped — wire up your own data source by
// populating this object. Keys are the query aliases used internally
// by the design; values are arrays of items.
//
// AI INTEGRATION NOTE: identify the .map(item => ...) call(s) in
// the component below to learn what fields each item needs. Then
// replace the empty arrays here with your data (fetched from your
// CMS, an API, a JSON file, props, etc.).
// ─────────────────────────────────────────────────────────────
const __FRAMER_CMS_DATA__ = {
  // alias: [ { /* item fields */ } ],
};
const __framer_useQueryData = (query) => {
  const alias = query && query.from && query.from.alias;
  return (alias && __FRAMER_CMS_DATA__[alias]) || [];
};

var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/pzyFa36AOoYxt2EiYg3j/npw4HcOfkzWCHBehpci4/HUxtiZv8t.js
import { jsx as _jsx4, jsxs as _jsxs2, Fragment as _Fragment } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls4, ChildrenCanSuspend, ComponentViewportProvider, ControlType as ControlType4, cx as cx4, getFonts, PathVariablesContext, ResolveLinks, SmartComponentScopedContainer, useActiveVariantCallback, useComponentViewport as useComponentViewport2, useLocaleCode, useLocaleInfo as useLocaleInfo2, useQueryData, useRouter, useVariantState as useVariantState2, withCSS as withCSS4, withFX } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion4, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React4 from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/4qDZ5fpnSDcCuTUmDDUQ/6AKBRx6fqd6kzKm1GtUg/zUKqqFh0Q.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 4 8 L 0 4 M 0 4 L 4 0 M 0 4 L 12 4" fill="transparent" height="8px" id="EDcCyncRm" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--b8xnka, 2)" stroke="var(--4i27ky, rgb(0, 0, 0))" transform="translate(6 8)" width="12px"/></svg>';
var getProps = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, akr7Ge2dd: width1 ?? props.akr7Ge2dd ?? 2, PF8qIBMI7: alpha ?? props.PF8qIBMI7 ?? 0.16, rm13cFo5g: color ?? props.rm13cFo5g ?? "rgb(0, 0, 0)" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className: className4, layoutId, variant, rm13cFo5g, akr7Ge2dd, PF8qIBMI7, ...restProps } = getProps(props);
  const href = useSVGTemplate("2587803250", svg);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-TCVwT", className4), layoutId, ref, role: "presentation", style: { "--4i27ky": rm13cFo5g, "--b8xnka": akr7Ge2dd, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx("use", { href }) });
});
var css = [`.framer-TCVwT { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-TCVwT");
Icon.displayName = "Arrow Left";
var zUKqqFh0Q_default = Icon;
addPropertyControls(Icon, { rm13cFo5g: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType.Color }, akr7Ge2dd: { defaultValue: 2, displayStepper: true, hidden: false, max: 4, min: 1, title: "Width", type: ControlType.Number }, PF8qIBMI7: { defaultValue: 0.16, displayStepper: true, hidden: true, max: 1, min: 0, step: 0.01, title: "Alpha", type: ControlType.Number } });

// http-url:https://framerusercontent.com/modules/icNmModWONtmIk86QfN3/3OgILX1zHXmV4TyCJSLz/rQDpQQ4Qi.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, motion as motion2, useSVGTemplate as useSVGTemplate2, withCSS as withCSS2 } from "./_framer-runtime.js";
import * as React2 from "react";
import { forwardRef as forwardRef4 } from "react";
var mask2 = "var(--framer-icon-mask)";
var Base2 = /* @__PURE__ */ forwardRef4(function(props, ref) {
  return /* @__PURE__ */ _jsx2("svg", { ...props, ref, children: props.children });
});
var MotionSVG2 = motion2.create(Base2);
var SVG2 = /* @__PURE__ */ forwardRef4((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx2(MotionSVG2, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx2("svg", { ...rest, ref, children });
});
var svg2 = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 8 8 L 12 4 M 12 4 L 8 0 M 12 4 L 0 4" fill="transparent" height="8px" id="JgTGlz8TK" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--b8xnka, 2)" stroke="var(--4i27ky, rgb(0, 0, 0))" transform="translate(6 8)" width="12px"/></svg>';
var getProps2 = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, akr7Ge2dd: width1 ?? props.akr7Ge2dd ?? 2, PF8qIBMI7: alpha ?? props.PF8qIBMI7 ?? 0.16, rm13cFo5g: color ?? props.rm13cFo5g ?? "rgb(0, 0, 0)" };
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const { style, className: className4, layoutId, variant, rm13cFo5g, akr7Ge2dd, PF8qIBMI7, ...restProps } = getProps2(props);
  const href = useSVGTemplate2("1235104226", svg2);
  return /* @__PURE__ */ _jsx2(SVG2, { ...restProps, className: cx2("framer-QYMJl", className4), layoutId, ref, role: "presentation", style: { "--4i27ky": rm13cFo5g, "--b8xnka": akr7Ge2dd, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx2("use", { href }) });
});
var css2 = [`.framer-QYMJl { -webkit-mask: ${mask2}; aspect-ratio: 1; display: block; mask: ${mask2}; width: 24px; }`];
var Icon2 = withCSS2(Component2, css2, "framer-QYMJl");
Icon2.displayName = "Arrow Right";
var rQDpQQ4Qi_default = Icon2;
addPropertyControls2(Icon2, { rm13cFo5g: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType2.Color }, akr7Ge2dd: { defaultValue: 2, displayStepper: true, hidden: false, max: 4, min: 1, title: "Width", type: ControlType2.Number }, PF8qIBMI7: { defaultValue: 0.16, displayStepper: true, hidden: true, max: 1, min: 0, step: 0.01, title: "Alpha", type: ControlType2.Number } });

// http-url:https://framerusercontent.com/modules/548mUIgjuXCaDGGLvJLm/Cwjqmy8zrJwI74L4Wtrx/eXcwekmvS.js
import { addPropertyControls as e5, ControlType as t4, QueryCache as l3, QueryEngine as a3 } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/548mUIgjuXCaDGGLvJLm/Cwjqmy8zrJwI74L4Wtrx/eXcwekmvS-0.js
import { ControlType as v } from "./_framer-runtime.js";
import { ControlType as P } from "./_framer-runtime.js";
var t;
var e = Object.create;
var r = Object.defineProperty;
var n = Object.getOwnPropertyDescriptor;
var i = Object.getOwnPropertyNames;
var s = Object.getPrototypeOf;
var a = Object.prototype.hasOwnProperty;
var o = (t5, e6, n4) => e6 in t5 ? r(t5, e6, { enumerable: true, configurable: true, writable: true, value: n4 }) : t5[e6] = n4;
var u = (t5, e6) => function() {
  return e6 || (0, t5[i(t5)[0]])((e6 = { exports: {} }).exports, e6), e6.exports;
};
var l = (t5, e6, s4, o4) => {
  if (e6 && "object" == typeof e6 || "function" == typeof e6)
    for (let u4 of i(e6))
      a.call(t5, u4) || u4 === s4 || r(t5, u4, { get: () => e6[u4], enumerable: !(o4 = n(e6, u4)) || o4.enumerable });
  return t5;
};
var h = (t5, n4, i3) => (i3 = null != t5 ? e(s(t5)) : {}, l(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  !n4 && t5 && t5.__esModule ? i3 : r(i3, "default", { value: t5, enumerable: true }),
  t5
));
var c = (t5, e6, r3) => o(t5, "symbol" != typeof e6 ? e6 + "" : e6, r3);
var f = u({ "../../../node_modules/dataloader/index.js"(t5, e6) {
  var r3, n4 = /* @__PURE__ */ function() {
    function t6(t7, e8) {
      if ("function" != typeof t7)
        throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but got: " + t7 + ".");
      this._batchLoadFn = t7, this._maxBatchSize = function(t8) {
        if (!(!t8 || false !== t8.batch))
          return 1;
        var e9 = t8 && t8.maxBatchSize;
        if (void 0 === e9)
          return 1 / 0;
        if ("number" != typeof e9 || e9 < 1)
          throw TypeError("maxBatchSize must be a positive number: " + e9);
        return e9;
      }(e8), this._batchScheduleFn = function(t8) {
        var e9 = t8 && t8.batchScheduleFn;
        if (void 0 === e9)
          return i3;
        if ("function" != typeof e9)
          throw TypeError("batchScheduleFn must be a function: " + e9);
        return e9;
      }(e8), this._cacheKeyFn = function(t8) {
        var e9 = t8 && t8.cacheKeyFn;
        if (void 0 === e9)
          return function(t9) {
            return t9;
          };
        if ("function" != typeof e9)
          throw TypeError("cacheKeyFn must be a function: " + e9);
        return e9;
      }(e8), this._cacheMap = function(t8) {
        if (!(!t8 || false !== t8.cache))
          return null;
        var e9 = t8 && t8.cacheMap;
        if (void 0 === e9)
          return /* @__PURE__ */ new Map();
        if (null !== e9) {
          var r4 = ["get", "set", "delete", "clear"].filter(function(t9) {
            return e9 && "function" != typeof e9[t9];
          });
          if (0 !== r4.length)
            throw TypeError("Custom cacheMap missing methods: " + r4.join(", "));
        }
        return e9;
      }(e8), this._batch = null, this.name = e8 && e8.name ? e8.name : null;
    }
    var e7 = t6.prototype;
    return e7.load = function(t7) {
      if (null == t7)
        throw TypeError("The loader.load() function must be called with a value, but got: " + String(t7) + ".");
      var e8 = function(t8) {
        var e9 = t8._batch;
        if (null !== e9 && !e9.hasDispatched && e9.keys.length < t8._maxBatchSize)
          return e9;
        var r5 = { hasDispatched: false, keys: [], callbacks: [] };
        return t8._batch = r5, t8._batchScheduleFn(function() {
          (function(t9, e10) {
            var r6;
            if (e10.hasDispatched = true, 0 === e10.keys.length) {
              a4(e10);
              return;
            }
            try {
              r6 = t9._batchLoadFn(e10.keys);
            } catch (r7) {
              return s4(t9, e10, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function errored synchronously: " + String(r7) + "."));
            }
            if (!r6 || "function" != typeof r6.then)
              return s4(t9, e10, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise: " + String(r6) + "."));
            r6.then(function(t10) {
              if (!o4(t10))
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array: " + String(t10) + ".");
              if (t10.length !== e10.keys.length)
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array of the same length as the Array of keys.\n\nKeys:\n" + String(e10.keys) + "\n\nValues:\n" + String(t10));
              a4(e10);
              for (var r7 = 0; r7 < e10.callbacks.length; r7++) {
                var n6 = t10[r7];
                n6 instanceof Error ? e10.callbacks[r7].reject(n6) : e10.callbacks[r7].resolve(n6);
              }
            }).catch(function(r7) {
              s4(t9, e10, r7);
            });
          })(t8, r5);
        }), r5;
      }(this), r4 = this._cacheMap, n5 = this._cacheKeyFn(t7);
      if (r4) {
        var i4 = r4.get(n5);
        if (i4) {
          var u4 = e8.cacheHits || (e8.cacheHits = []);
          return new Promise(function(t8) {
            u4.push(function() {
              t8(i4);
            });
          });
        }
      }
      e8.keys.push(t7);
      var l4 = new Promise(function(t8, r5) {
        e8.callbacks.push({ resolve: t8, reject: r5 });
      });
      return r4 && r4.set(n5, l4), l4;
    }, e7.loadMany = function(t7) {
      if (!o4(t7))
        throw TypeError("The loader.loadMany() function must be called with Array<key> but got: " + t7 + ".");
      for (var e8 = [], r4 = 0; r4 < t7.length; r4++)
        e8.push(this.load(t7[r4]).catch(function(t8) {
          return t8;
        }));
      return Promise.all(e8);
    }, e7.clear = function(t7) {
      var e8 = this._cacheMap;
      if (e8) {
        var r4 = this._cacheKeyFn(t7);
        e8.delete(r4);
      }
      return this;
    }, e7.clearAll = function() {
      var t7 = this._cacheMap;
      return t7 && t7.clear(), this;
    }, e7.prime = function(t7, e8) {
      var r4 = this._cacheMap;
      if (r4) {
        var n5, i4 = this._cacheKeyFn(t7);
        void 0 === r4.get(i4) && (e8 instanceof Error ? (n5 = Promise.reject(e8)).catch(function() {
        }) : n5 = Promise.resolve(e8), r4.set(i4, n5));
      }
      return this;
    }, t6;
  }(), i3 = "object" == typeof process && "function" == typeof process.nextTick ? function(t6) {
    r3 || (r3 = Promise.resolve()), r3.then(function() {
      process.nextTick(t6);
    });
  } : "function" == typeof setImmediate ? function(t6) {
    setImmediate(t6);
  } : function(t6) {
    setTimeout(t6);
  };
  function s4(t6, e7, r4) {
    a4(e7);
    for (var n5 = 0; n5 < e7.keys.length; n5++)
      t6.clear(e7.keys[n5]), e7.callbacks[n5].reject(r4);
  }
  function a4(t6) {
    if (t6.cacheHits)
      for (var e7 = 0; e7 < t6.cacheHits.length; e7++)
        t6.cacheHits[e7]();
  }
  function o4(t6) {
    return "object" == typeof t6 && null !== t6 && "number" == typeof t6.length && (0 === t6.length || t6.length > 0 && Object.prototype.hasOwnProperty.call(t6, t6.length - 1));
  }
  e6.exports = n4;
} });
var d = h(f());
var g = { Uint8: 1, Uint16: 2, Uint32: 4, BigUint64: 8, Int8: 1, Int16: 2, Int32: 4, BigInt64: 8, Float32: 4, Float64: 8 };
var y = class {
  getOffset() {
    return this.offset;
  }
  ensureLength(t5) {
    let e6 = this.bytes.length;
    if (!(this.offset + t5 <= e6))
      throw Error("Reading out of bounds");
  }
  readUint8() {
    let t5 = g.Uint8;
    this.ensureLength(t5);
    let e6 = this.view.getUint8(this.offset);
    return this.offset += t5, e6;
  }
  readUint16() {
    let t5 = g.Uint16;
    this.ensureLength(t5);
    let e6 = this.view.getUint16(this.offset);
    return this.offset += t5, e6;
  }
  readUint32() {
    let t5 = g.Uint32;
    this.ensureLength(t5);
    let e6 = this.view.getUint32(this.offset);
    return this.offset += t5, e6;
  }
  readUint64() {
    let t5 = this.readBigUint64();
    return Number(t5);
  }
  readBigUint64() {
    let t5 = g.BigUint64;
    this.ensureLength(t5);
    let e6 = this.view.getBigUint64(this.offset);
    return this.offset += t5, e6;
  }
  readInt8() {
    let t5 = g.Int8;
    this.ensureLength(t5);
    let e6 = this.view.getInt8(this.offset);
    return this.offset += t5, e6;
  }
  readInt16() {
    let t5 = g.Int16;
    this.ensureLength(t5);
    let e6 = this.view.getInt16(this.offset);
    return this.offset += t5, e6;
  }
  readInt32() {
    let t5 = g.Int32;
    this.ensureLength(t5);
    let e6 = this.view.getInt32(this.offset);
    return this.offset += t5, e6;
  }
  readInt64() {
    let t5 = this.readBigInt64();
    return Number(t5);
  }
  readBigInt64() {
    let t5 = g.BigInt64;
    this.ensureLength(t5);
    let e6 = this.view.getBigInt64(this.offset);
    return this.offset += t5, e6;
  }
  readFloat32() {
    let t5 = g.Float32;
    this.ensureLength(t5);
    let e6 = this.view.getFloat32(this.offset);
    return this.offset += t5, e6;
  }
  readFloat64() {
    let t5 = g.Float64;
    this.ensureLength(t5);
    let e6 = this.view.getFloat64(this.offset);
    return this.offset += t5, e6;
  }
  readBytes(t5) {
    let e6 = this.offset, r3 = e6 + t5, n4 = this.bytes.subarray(e6, r3);
    return this.offset = r3, n4;
  }
  readString() {
    let t5 = this.readUint32(), e6 = this.readBytes(t5);
    return this.decoder.decode(e6);
  }
  readJson() {
    let t5 = this.readString();
    return JSON.parse(t5);
  }
  constructor(t5) {
    this.bytes = t5, c(this, "offset", 0), c(this, "view"), c(this, "decoder", new TextDecoder()), this.view = p(this.bytes);
  }
};
function p(t5) {
  return new DataView(t5.buffer, t5.byteOffset, t5.byteLength);
}
var m = "undefined" != typeof __dai_window;
var w = m && "function" == typeof __dai_window.requestIdleCallback;
function I(t5, ...e6) {
  if (!t5)
    throw Error("Assertion Error" + (e6.length > 0 ? ": " + e6.join(" ") : ""));
}
function b(t5) {
  throw Error(`Unexpected value: ${t5}`);
}
var U = 1024;
var S = 1.5;
var k = (t5) => 2 ** t5 - 1;
var L = (t5) => -(2 ** (t5 - 1));
var B = (t5) => 2 ** (t5 - 1) - 1;
var E = { Uint8: 0, Uint16: 0, Uint32: 0, Uint64: 0, BigUint64: 0, Int8: L(8), Int16: L(16), Int32: L(32), Int64: Number.MIN_SAFE_INTEGER, BigInt64: -(BigInt(2) ** BigInt(63)) };
var M = { Uint8: k(8), Uint16: k(16), Uint32: k(32), Uint64: Number.MAX_SAFE_INTEGER, BigUint64: BigInt(2) ** BigInt(64) - BigInt(1), Int8: B(8), Int16: B(16), Int32: B(32), Int64: Number.MAX_SAFE_INTEGER, BigInt64: BigInt(2) ** BigInt(63) - BigInt(1) };
function T(t5, e6, r3, n4) {
  I(t5 >= e6, t5, "outside lower bound for", n4), I(t5 <= r3, t5, "outside upper bound for", n4);
}
var F = class {
  getOffset() {
    return this.offset;
  }
  slice(t5 = 0, e6 = this.offset) {
    return this.bytes.slice(t5, e6);
  }
  subarray(t5 = 0, e6 = this.offset) {
    return this.bytes.subarray(t5, e6);
  }
  ensureLength(t5) {
    let e6 = this.bytes.length;
    if (this.offset + t5 <= e6)
      return;
    let r3 = new Uint8Array(Math.ceil(e6 * S) + t5);
    r3.set(this.bytes), this.bytes = r3, this.view = p(r3);
  }
  writeUint8(t5) {
    T(t5, E.Uint8, M.Uint8, "Uint8");
    let e6 = g.Uint8;
    this.ensureLength(e6), this.view.setUint8(this.offset, t5), this.offset += e6;
  }
  writeUint16(t5) {
    T(t5, E.Uint16, M.Uint16, "Uint16");
    let e6 = g.Uint16;
    this.ensureLength(e6), this.view.setUint16(this.offset, t5), this.offset += e6;
  }
  writeUint32(t5) {
    T(t5, E.Uint32, M.Uint32, "Uint32");
    let e6 = g.Uint32;
    this.ensureLength(e6), this.view.setUint32(this.offset, t5), this.offset += e6;
  }
  writeUint64(t5) {
    T(t5, E.Uint64, M.Uint64, "Uint64");
    let e6 = BigInt(t5);
    this.writeBigUint64(e6);
  }
  writeBigUint64(t5) {
    T(t5, E.BigUint64, M.BigUint64, "BigUint64");
    let e6 = g.BigUint64;
    this.ensureLength(e6), this.view.setBigUint64(this.offset, t5), this.offset += e6;
  }
  writeInt8(t5) {
    T(t5, E.Int8, M.Int8, "Int8");
    let e6 = g.Int8;
    this.ensureLength(e6), this.view.setInt8(this.offset, t5), this.offset += e6;
  }
  writeInt16(t5) {
    T(t5, E.Int16, M.Int16, "Int16");
    let e6 = g.Int16;
    this.ensureLength(e6), this.view.setInt16(this.offset, t5), this.offset += e6;
  }
  writeInt32(t5) {
    T(t5, E.Int32, M.Int32, "Int32");
    let e6 = g.Int32;
    this.ensureLength(e6), this.view.setInt32(this.offset, t5), this.offset += e6;
  }
  writeInt64(t5) {
    T(t5, E.Int64, M.Int64, "Int64");
    let e6 = BigInt(t5);
    this.writeBigInt64(e6);
  }
  writeBigInt64(t5) {
    T(t5, E.BigInt64, M.BigInt64, "BigInt64");
    let e6 = g.BigInt64;
    this.ensureLength(e6), this.view.setBigInt64(this.offset, t5), this.offset += e6;
  }
  writeFloat32(t5) {
    let e6 = g.Float32;
    this.ensureLength(e6), this.view.setFloat32(this.offset, t5), this.offset += e6;
  }
  writeFloat64(t5) {
    let e6 = g.Float64;
    this.ensureLength(e6), this.view.setFloat64(this.offset, t5), this.offset += e6;
  }
  writeBytes(t5) {
    let e6 = t5.length;
    this.ensureLength(e6), this.bytes.set(t5, this.offset), this.offset += e6;
  }
  encodeString(t5) {
    let e6 = this.encodedStrings.get(t5);
    if (e6)
      return e6;
    let r3 = this.encoder.encode(t5);
    return this.encodedStrings.set(t5, r3), r3;
  }
  writeString(t5) {
    let e6 = this.encodeString(t5), r3 = e6.length;
    this.writeUint32(r3), this.writeBytes(e6);
  }
  writeJson(t5) {
    let e6 = JSON.stringify(t5);
    this.writeString(e6);
  }
  constructor() {
    c(this, "offset", 0), c(this, "bytes", new Uint8Array(U)), c(this, "view", p(this.bytes)), c(this, "encoder", new TextEncoder()), c(this, "encodedStrings", /* @__PURE__ */ new Map());
  }
};
function x(t5) {
  return "string" == typeof t5;
}
function N(t5) {
  return Number.isFinite(t5);
}
function A(t5) {
  return null === t5;
}
var O = class t2 {
  static fromString(e6) {
    let [r3, n4, i3] = e6.split("/").map(Number);
    return I(N(r3), "Invalid chunkId"), I(N(n4), "Invalid offset"), I(N(i3), "Invalid length"), new t2(r3, n4, i3);
  }
  toString() {
    return `${this.chunkId}/${this.offset}/${this.length}`;
  }
  static read(e6) {
    let r3 = e6.readUint16(), n4 = e6.readUint32(), i3 = e6.readUint32();
    return new t2(r3, n4, i3);
  }
  write(t5) {
    t5.writeUint16(this.chunkId), t5.writeUint32(this.offset), t5.writeUint32(this.length);
  }
  compare(t5) {
    return this.chunkId < t5.chunkId ? -1 : this.chunkId > t5.chunkId ? 1 : this.offset < t5.offset ? -1 : this.offset > t5.offset ? 1 : (I(this.length === t5.length), 0);
  }
  constructor(t5, e6, r3) {
    this.chunkId = t5, this.offset = e6, this.length = r3;
  }
};
function R(t5) {
  if (A(t5))
    return 0;
  switch (t5.type) {
    case P.Array:
      return 1;
    case P.Boolean:
      return 2;
    case P.Color:
      return 3;
    case P.Date:
      return 4;
    case P.Enum:
      return 5;
    case P.File:
      return 6;
    case P.ResponsiveImage:
      return 10;
    case P.Link:
      return 7;
    case P.Number:
      return 8;
    case P.Object:
      return 9;
    case P.RichText:
      return 11;
    case P.String:
      return 12;
    case P.VectorSetItem:
      return 13;
    default:
      b(t5);
  }
}
function q(e6) {
  let r3 = e6.readUint16(), n4 = [];
  for (let i3 = 0; i3 < r3; i3++) {
    let r4 = t.read(e6);
    n4.push(r4);
  }
  return { type: P.Array, value: n4 };
}
function _(e6, r3) {
  for (let n4 of (e6.writeUint16(r3.value.length), r3.value))
    t.write(e6, n4);
}
function D(e6, r3, n4) {
  let i3 = e6.value.length, s4 = r3.value.length;
  if (i3 < s4)
    return -1;
  if (i3 > s4)
    return 1;
  for (let s5 = 0; s5 < i3; s5++) {
    let i4 = e6.value[s5], a4 = r3.value[s5], o4 = t.compare(i4, a4, n4);
    if (0 !== o4)
      return o4;
  }
  return 0;
}
function j(t5) {
  return { type: P.Boolean, value: 0 !== t5.readUint8() };
}
function C(t5, e6) {
  t5.writeUint8(e6.value ? 1 : 0);
}
function J(t5, e6) {
  return t5.value < e6.value ? -1 : t5.value > e6.value ? 1 : 0;
}
function V(t5) {
  return { type: P.Color, value: t5.readString() };
}
function W(t5, e6) {
  t5.writeString(e6.value);
}
function $(t5, e6) {
  return t5.value < e6.value ? -1 : t5.value > e6.value ? 1 : 0;
}
function z(t5) {
  let e6 = t5.readInt64(), r3 = new Date(e6);
  return { type: P.Date, value: r3.toISOString() };
}
function G(t5, e6) {
  let r3 = new Date(e6.value), n4 = r3.getTime();
  t5.writeInt64(n4);
}
function K(t5, e6) {
  let r3 = new Date(t5.value), n4 = new Date(e6.value);
  return r3 < n4 ? -1 : r3 > n4 ? 1 : 0;
}
function H(t5) {
  return { type: P.Enum, value: t5.readString() };
}
function X(t5, e6) {
  t5.writeString(e6.value);
}
function Q(t5, e6) {
  return t5.value < e6.value ? -1 : t5.value > e6.value ? 1 : 0;
}
function Y(t5) {
  return { type: P.File, value: t5.readString() };
}
function Z(t5, e6) {
  t5.writeString(e6.value);
}
function tt(t5, e6) {
  return t5.value < e6.value ? -1 : t5.value > e6.value ? 1 : 0;
}
function te(t5) {
  return { type: P.Link, value: t5.readJson() };
}
function tr(t5, e6) {
  t5.writeJson(e6.value);
}
function tn(t5, e6) {
  let r3 = JSON.stringify(t5.value), n4 = JSON.stringify(e6.value);
  return r3 < n4 ? -1 : r3 > n4 ? 1 : 0;
}
function ti(t5) {
  return { type: P.Number, value: t5.readFloat64() };
}
function ts(t5, e6) {
  t5.writeFloat64(e6.value);
}
function ta(t5, e6) {
  return t5.value < e6.value ? -1 : t5.value > e6.value ? 1 : 0;
}
function to(e6) {
  let r3 = e6.readUint16(), n4 = {};
  for (let i3 = 0; i3 < r3; i3++) {
    let r4 = e6.readString();
    n4[r4] = t.read(e6);
  }
  return { type: P.Object, value: n4 };
}
function tu(e6, r3) {
  let n4 = Object.entries(r3.value);
  for (let [r4, i3] of (e6.writeUint16(n4.length), n4))
    e6.writeString(r4), t.write(e6, i3);
}
function tl(e6, r3, n4) {
  let i3 = Object.keys(e6.value).sort(), s4 = Object.keys(r3.value).sort();
  if (i3.length < s4.length)
    return -1;
  if (i3.length > s4.length)
    return 1;
  for (let a4 = 0; a4 < i3.length; a4++) {
    let o4 = i3[a4], u4 = s4[a4];
    if (o4 < u4)
      return -1;
    if (o4 > u4)
      return 1;
    let l4 = e6.value[o4] ?? null, h3 = r3.value[u4] ?? null, c4 = t.compare(l4, h3, n4);
    if (0 !== c4)
      return c4;
  }
  return 0;
}
function th(t5) {
  return { type: P.ResponsiveImage, value: t5.readJson() };
}
function tc(t5, e6) {
  t5.writeJson(e6.value);
}
function tf(t5, e6) {
  let r3 = JSON.stringify(t5.value), n4 = JSON.stringify(e6.value);
  return r3 < n4 ? -1 : r3 > n4 ? 1 : 0;
}
function td(t5) {
  let e6 = t5.readInt8();
  if (0 === e6)
    return { type: P.RichText, value: t5.readUint32() };
  if (1 === e6)
    return { type: P.RichText, value: t5.readString() };
  throw Error("Invalid rich text pointer");
}
function tg(t5, e6) {
  if (N(e6.value)) {
    t5.writeInt8(0), t5.writeUint32(e6.value);
    return;
  }
  if (x(e6.value)) {
    t5.writeInt8(1), t5.writeString(e6.value);
    return;
  }
  throw Error("Invalid rich text pointer");
}
function ty(t5, e6) {
  let r3 = t5.value, n4 = e6.value;
  if (N(r3) && N(n4) || x(r3) && x(n4))
    return r3 < n4 ? -1 : r3 > n4 ? 1 : 0;
  throw Error("Invalid rich text pointer");
}
function tp(t5) {
  return { type: P.String, value: t5.readString() };
}
function tv(t5, e6) {
  t5.writeString(e6.value);
}
function tm(t5, e6, r3) {
  let n4 = t5.value, i3 = e6.value;
  return (0 === r3.type && (n4 = t5.value.toLowerCase(), i3 = e6.value.toLowerCase()), n4 < i3) ? -1 : n4 > i3 ? 1 : 0;
}
function tw(t5) {
  return { type: P.VectorSetItem, value: t5.readUint32() };
}
function tI(t5, e6) {
  t5.writeUint32(e6.value);
}
function tb(t5, e6) {
  let r3 = t5.value, n4 = e6.value;
  return r3 < n4 ? -1 : r3 > n4 ? 1 : 0;
}
((t5) => {
  t5.read = function(t6) {
    let e6 = t6.readUint8();
    switch (e6) {
      case 0:
        return null;
      case 1:
        return q(t6);
      case 2:
        return j(t6);
      case 3:
        return V(t6);
      case 4:
        return z(t6);
      case 5:
        return H(t6);
      case 6:
        return Y(t6);
      case 7:
        return te(t6);
      case 8:
        return ti(t6);
      case 9:
        return to(t6);
      case 10:
        return th(t6);
      case 11:
        return td(t6);
      case 12:
        return tp(t6);
      case 13:
        return tw(t6);
      default:
        b(e6);
    }
  }, t5.write = function(t6, e6) {
    let r3 = R(e6);
    if (t6.writeUint8(r3), !A(e6))
      switch (e6.type) {
        case P.Array:
          return _(t6, e6);
        case P.Boolean:
          return C(t6, e6);
        case P.Color:
          return W(t6, e6);
        case P.Date:
          return G(t6, e6);
        case P.Enum:
          return X(t6, e6);
        case P.File:
          return Z(t6, e6);
        case P.Link:
          return tr(t6, e6);
        case P.Number:
          return ts(t6, e6);
        case P.Object:
          return tu(t6, e6);
        case P.ResponsiveImage:
          return tc(t6, e6);
        case P.RichText:
          return tg(t6, e6);
        case P.VectorSetItem:
          return tI(t6, e6);
        case P.String:
          return tv(t6, e6);
        default:
          b(e6);
      }
  }, t5.compare = function(t6, e6, r3) {
    let n4 = R(t6), i3 = R(e6);
    if (n4 < i3)
      return -1;
    if (n4 > i3)
      return 1;
    if (A(t6) || A(e6))
      return 0;
    switch (t6.type) {
      case P.Array:
        return I(e6.type === P.Array), D(t6, e6, r3);
      case P.Boolean:
        return I(e6.type === P.Boolean), J(t6, e6);
      case P.Color:
        return I(e6.type === P.Color), $(t6, e6);
      case P.Date:
        return I(e6.type === P.Date), K(t6, e6);
      case P.Enum:
        return I(e6.type === P.Enum), Q(t6, e6);
      case P.File:
        return I(e6.type === P.File), tt(t6, e6);
      case P.Link:
        return I(e6.type === P.Link), tn(t6, e6);
      case P.Number:
        return I(e6.type === P.Number), ta(t6, e6);
      case P.Object:
        return I(e6.type === P.Object), tl(t6, e6, r3);
      case P.ResponsiveImage:
        return I(e6.type === P.ResponsiveImage), tf(t6, e6);
      case P.RichText:
        return I(e6.type === P.RichText), ty(t6, e6);
      case P.VectorSetItem:
        return I(e6.type === P.VectorSetItem), tb(t6, e6);
      case P.String:
        return I(e6.type === P.String), tm(t6, e6, r3);
      default:
        b(t6);
    }
  };
})(t || (t = {}));
var tU = class e2 {
  sortEntries() {
    this.entries.sort((e6, r3) => {
      for (let n4 = 0; n4 < this.fieldNames.length; n4++) {
        let i3 = e6.values[n4], s4 = r3.values[n4], a4 = t.compare(i3, s4, this.options.collation);
        if (0 !== a4)
          return a4;
      }
      return e6.pointer.compare(r3.pointer);
    });
  }
  static deserialize(r3) {
    let n4 = new y(r3), i3 = n4.readJson(), s4 = n4.readUint8(), a4 = [];
    for (let t5 = 0; t5 < s4; t5++) {
      let t6 = n4.readString();
      a4.push(t6);
    }
    let o4 = new e2(a4, { collation: i3 }), u4 = n4.readUint32();
    for (let e6 = 0; e6 < u4; e6++) {
      let e7 = [];
      for (let r5 = 0; r5 < s4; r5++) {
        let r6 = t.read(n4);
        e7.push(r6);
      }
      let r4 = O.read(n4);
      o4.entries.push({ values: e7, pointer: r4 });
    }
    return o4;
  }
  serialize() {
    let e6 = new F();
    for (let t5 of (e6.writeJson(this.options.collation), e6.writeUint8(this.fieldNames.length), this.fieldNames))
      e6.writeString(t5);
    for (let r3 of (this.sortEntries(), e6.writeUint32(this.entries.length), this.entries)) {
      let { values: n4, pointer: i3 } = r3;
      for (let r4 of n4)
        t.write(e6, r4);
      i3.write(e6);
    }
    return e6.subarray();
  }
  addItem(t5, e6) {
    let r3 = this.fieldNames.map((e7) => t5.getField(e7) ?? null);
    this.entries.push({ values: r3, pointer: e6 });
  }
  constructor(t5, e6) {
    this.fieldNames = t5, this.options = e6, c(this, "entries", []);
  }
};
var tS = 3;
var tk = 250;
var tL = [
  408,
  // Request Timeout
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
];
var tB = async (t5, e6) => {
  let r3 = 0;
  for (; ; ) {
    try {
      let n4 = await fetch(t5, e6);
      if (!tL.includes(n4.status) || ++r3 > tS)
        return n4;
    } catch (t6) {
      if (e6?.signal?.aborted || ++r3 > tS)
        throw t6;
    }
    await tE(r3);
  }
};
async function tE(t5) {
  let e6 = Math.floor(tk * (Math.random() + 1) * 2 ** (t5 - 1));
  await new Promise((t6) => {
    setTimeout(t6, e6);
  });
}
async function tM(t5, e6) {
  let r3 = tx(e6), n4 = [], i3 = 0;
  for (let t6 of r3)
    n4.push(`${t6.from}-${t6.to - 1}`), i3 += t6.to - t6.from;
  let s4 = new URL(t5), a4 = n4.join(",");
  s4.searchParams.set("range", a4);
  let o4 = await tB(s4);
  if (200 !== o4.status)
    throw Error(`Request failed: ${o4.status} ${o4.statusText}`);
  let u4 = await o4.arrayBuffer(), l4 = new Uint8Array(u4);
  if (l4.length !== i3)
    throw Error("Request failed: Unexpected response length");
  let h3 = new tT(), c4 = 0;
  for (let t6 of r3) {
    let e7 = t6.to - t6.from, r4 = c4 + e7, n5 = l4.subarray(c4, r4);
    h3.write(t6.from, n5), c4 = r4;
  }
  return e6.map((t6) => h3.read(t6.from, t6.to - t6.from));
}
var tT = class {
  read(t5, e6) {
    for (let r3 of this.chunks) {
      if (t5 < r3.start)
        break;
      if (t5 > r3.end)
        continue;
      if (t5 + e6 > r3.end)
        break;
      let n4 = t5 - r3.start, i3 = n4 + e6;
      return r3.data.slice(n4, i3);
    }
    throw Error("Missing data");
  }
  write(t5, e6) {
    let r3 = t5, n4 = r3 + e6.length, i3 = 0, s4 = this.chunks.length;
    for (; i3 < s4; i3++) {
      let t6 = this.chunks[i3];
      if (I(t6, "Missing chunk"), !(r3 > t6.end)) {
        if (r3 > t6.start) {
          let n5 = r3 - t6.start, i4 = t6.data.subarray(0, n5);
          e6 = tF(i4, e6), r3 = t6.start;
        }
        break;
      }
    }
    for (; s4 > i3; s4--) {
      let t6 = this.chunks[s4 - 1];
      if (I(t6, "Missing chunk"), !(n4 < t6.start)) {
        if (n4 < t6.end) {
          let r4 = n4 - t6.start, i4 = t6.data.subarray(r4);
          e6 = tF(e6, i4), n4 = t6.end;
        }
        break;
      }
    }
    let a4 = { start: r3, end: n4, data: e6 }, o4 = s4 - i3;
    this.chunks.splice(i3, o4, a4);
  }
  constructor() {
    c(this, "chunks", []);
  }
};
function tF(t5, e6) {
  let r3 = t5.length + e6.length, n4 = new Uint8Array(r3);
  return n4.set(t5, 0), n4.set(e6, t5.length), n4;
}
function tx(t5) {
  I(t5.length > 0, "Must have at least one range");
  let e6 = [...t5].sort((t6, e7) => t6.from - e7.from), r3 = [];
  for (let t6 of e6) {
    let e7 = r3.length - 1, n4 = r3[e7];
    n4 && t6.from <= n4.to ? r3[e7] = { from: n4.from, to: Math.max(n4.to, t6.to) } : r3.push(t6);
  }
  return r3;
}
var tN = class {
  async loadModel() {
    let [t5] = await tM(this.options.url, [this.options.range]);
    return I(t5, "Failed to load model"), tU.deserialize(t5);
  }
  async getModel() {
    return this.modelPromise ?? (this.modelPromise = this.loadModel()), this.model ?? (this.model = await this.modelPromise), this.model;
  }
  async lookupItems(t5) {
    I(t5.length === this.fields.length, "Invalid query length");
    let e6 = await this.getModel(), r3 = t5.reduce((t6, e7, r4) => t6.flatMap((t7) => {
      switch (e7.type) {
        case "All":
          return [t7];
        case "Equals":
          return this.queryEquals(t7, e7, r4);
        case "NotEquals":
          return this.queryNotEquals(t7, e7, r4);
        case "LessThan":
          return this.queryLessThan(t7, e7, r4);
        case "GreaterThan":
          return this.queryGreaterThan(t7, e7, r4);
        case "Contains":
          return this.queryContains(t7, e7, r4);
        case "StartsWith":
          return this.queryStartsWith(t7, e7, r4);
        case "EndsWith":
          return this.queryEndsWith(t7, e7, r4);
        default:
          b(e7);
      }
    }), [e6.entries]), n4 = [];
    for (let t6 of r3)
      for (let e7 of t6) {
        let t7 = {};
        for (let r4 = 0; r4 < this.options.fieldNames.length; r4++) {
          let n5 = this.options.fieldNames[r4], i3 = e7.values[r4];
          t7[n5] = i3;
        }
        n4.push({ pointer: e7.pointer.toString(), data: t7 });
      }
    return n4;
  }
  queryEquals(t5, e6, r3) {
    let n4 = this.getLeftMost(t5, r3, e6.value), i3 = this.getRightMost(t5, r3, e6.value), s4 = t5.slice(n4, i3 + 1);
    return s4.length > 0 ? [s4] : [];
  }
  queryNotEquals(t5, e6, r3) {
    let n4 = this.getLeftMost(t5, r3, e6.value), i3 = this.getRightMost(t5, r3, e6.value), s4 = [], a4 = t5.slice(0, n4);
    a4.length > 0 && s4.push(a4);
    let o4 = t5.slice(i3 + 1);
    return o4.length > 0 && s4.push(o4), s4;
  }
  queryLessThan(t5, e6, r3) {
    let n4 = this.getRightMost(t5, r3, null);
    if (t5 = t5.slice(n4 + 1), e6.inclusive) {
      let n5 = this.getRightMost(t5, r3, e6.value), i4 = t5.slice(0, n5 + 1);
      return i4.length > 0 ? [i4] : [];
    }
    let i3 = this.getLeftMost(t5, r3, e6.value), s4 = t5.slice(0, i3);
    return s4.length > 0 ? [s4] : [];
  }
  queryGreaterThan(t5, e6, r3) {
    let n4 = this.getRightMost(t5, r3, null);
    if (t5 = t5.slice(n4 + 1), e6.inclusive) {
      let n5 = this.getLeftMost(t5, r3, e6.value), i4 = t5.slice(n5);
      return i4.length > 0 ? [i4] : [];
    }
    let i3 = this.getRightMost(t5, r3, e6.value), s4 = t5.slice(i3 + 1);
    return s4.length > 0 ? [s4] : [];
  }
  queryContains(t5, e6, r3) {
    return this.findItems(t5, r3, (t6) => {
      if (t6?.type !== v.String || e6.value?.type !== v.String)
        return false;
      let r4 = t6.value, n4 = e6.value.value;
      return 0 === this.collation.type && (r4 = r4.toLowerCase(), n4 = n4.toLowerCase()), r4.includes(n4);
    });
  }
  queryStartsWith(t5, e6, r3) {
    return this.findItems(t5, r3, (t6) => {
      if (t6?.type !== v.String || e6.value?.type !== v.String)
        return false;
      let r4 = t6.value, n4 = e6.value.value;
      return 0 === this.collation.type && (r4 = r4.toLowerCase(), n4 = n4.toLowerCase()), r4.startsWith(n4);
    });
  }
  queryEndsWith(t5, e6, r3) {
    return this.findItems(t5, r3, (t6) => {
      if (t6?.type !== v.String || e6.value?.type !== v.String)
        return false;
      let r4 = t6.value, n4 = e6.value.value;
      return 0 === this.collation.type && (r4 = r4.toLowerCase(), n4 = n4.toLowerCase()), r4.endsWith(n4);
    });
  }
  /**
  * Returns the index of the left most entry that is equal to the target.
  *
  * ```text
  *   Left most
  *       ↓
  * ┌───┬───┬───┬───┬───┬───┐
  * │ 1 │ 2 │ 2 │ 2 │ 2 │ 3 │
  * └───┴───┴───┴───┴───┴───┘
  * ```
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param target The target value to search for.
  * @returns The index of the left most entry that is equal to the target.
  */
  getLeftMost(e6, r3, n4) {
    let i3 = 0, s4 = e6.length;
    for (; i3 < s4; ) {
      let a4 = i3 + s4 >> 1, o4 = e6[a4], u4 = o4.values[r3];
      0 > t.compare(u4, n4, this.collation) ? i3 = a4 + 1 : s4 = a4;
    }
    return i3;
  }
  /**
  * Returns the index of the right most entry that is equal to the target.
  *
  * ```text
  *              Right most
  *                   ↓
  * ┌───┬───┬───┬───┬───┬───┐
  * │ 1 │ 2 │ 2 │ 2 │ 2 │ 3 │
  * └───┴───┴───┴───┴───┴───┘
  * ```
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param target The target value to search for.
  * @returns The index of the right most entry that is equal to the target.
  */
  getRightMost(e6, r3, n4) {
    let i3 = 0, s4 = e6.length;
    for (; i3 < s4; ) {
      let a4 = i3 + s4 >> 1, o4 = e6[a4], u4 = o4.values[r3];
      t.compare(u4, n4, this.collation) > 0 ? s4 = a4 : i3 = a4 + 1;
    }
    return s4 - 1;
  }
  /**
  * Finds all items that are matching the predicate and groups adjacent items together.
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param predicate The predicate to match the values against.
  * @returns An array of chunks that match the predicate.
  */
  findItems(t5, e6, r3) {
    let n4 = [], i3 = 0;
    for (let s4 = 0; s4 < t5.length; s4++) {
      let a4 = t5[s4], o4 = a4.values[e6], u4 = r3(o4);
      if (!u4) {
        if (i3 < s4) {
          let e7 = t5.slice(i3, s4);
          n4.push(e7);
        }
        i3 = s4 + 1;
      }
    }
    if (i3 < t5.length) {
      let e7 = t5.slice(i3);
      n4.push(e7);
    }
    return n4;
  }
  constructor(t5) {
    this.options = t5, c(this, "schema"), c(this, "fields"), c(this, "supportedLookupTypes", [
      "All",
      "Equals",
      "NotEquals",
      "LessThan",
      "GreaterThan",
      "Contains",
      "StartsWith",
      "EndsWith"
      /* EndsWith */
    ]), c(this, "modelPromise"), c(this, "model"), c(this, "collation");
    let e6 = {}, r3 = [];
    for (let t6 of this.options.fieldNames) {
      let n4 = this.options.collectionSchema[t6];
      I(n4, "Missing definition for field", t6), e6[t6] = n4, r3.push({ type: "Identifier", name: t6 });
    }
    this.schema = e6, this.fields = r3, this.collation = this.options.collation;
  }
};
var tA = class e3 {
  static read(r3) {
    let n4 = new e3(), i3 = r3.readUint16();
    for (let e6 = 0; e6 < i3; e6++) {
      let e7 = r3.readString(), i4 = t.read(r3);
      n4.setField(e7, i4);
    }
    return n4;
  }
  write(e6) {
    for (let [r3, n4] of (e6.writeUint16(this.fields.size), this.fields))
      e6.writeString(r3), t.write(e6, n4);
  }
  getData() {
    let t5 = {};
    for (let [e6, r3] of this.fields)
      t5[e6] = r3;
    return t5;
  }
  setField(t5, e6) {
    this.fields.set(t5, e6);
  }
  getField(t5) {
    return this.fields.get(t5);
  }
  constructor() {
    c(this, "fields", /* @__PURE__ */ new Map());
  }
};
var tO = class {
  scanItems() {
    return this.itemsPromise ?? (this.itemsPromise = tB(this.url).then(async (t5) => {
      if (!t5.ok)
        throw Error(`Request failed: ${t5.status} ${t5.statusText}`);
      let e6 = await t5.arrayBuffer(), r3 = new Uint8Array(e6), n4 = new y(r3), i3 = [], s4 = n4.readUint32();
      for (let t6 = 0; t6 < s4; t6++) {
        let t7 = n4.getOffset(), e7 = tA.read(n4), r4 = n4.getOffset() - t7, s5 = new O(this.id, t7, r4), a4 = s5.toString(), o4 = { pointer: a4, data: e7.getData() };
        this.itemLoader.prime(a4, o4), i3.push(o4);
      }
      return i3;
    })), this.itemsPromise;
  }
  resolveItem(t5) {
    return this.itemLoader.load(t5);
  }
  constructor(t5, e6) {
    this.id = t5, this.url = e6, c(this, "itemsPromise"), c(this, "itemLoader", new d.default(async (t6) => {
      let e7 = t6.map((t7) => {
        let e8 = O.fromString(t7);
        return { from: e8.offset, to: e8.offset + e8.length };
      }), r3 = await tM(this.url, e7);
      return r3.map((e8, r4) => {
        let n4 = new y(e8), i3 = tA.read(n4), s4 = t6[r4];
        return I(s4, "Missing pointer"), { pointer: s4, data: i3.getData() };
      });
    }));
  }
};
var tP = class {
  async scanItems() {
    let t5 = await Promise.all(this.chunks.map(async (t6) => t6.scanItems()));
    return t5.flat();
  }
  async resolveItems(t5) {
    return Promise.all(t5.map((t6) => {
      let e6 = O.fromString(t6), r3 = this.chunks[e6.chunkId];
      return I(r3, "Missing chunk"), r3.resolveItem(t6);
    }));
  }
  compareItems(t5, e6) {
    let r3 = O.fromString(t5.pointer), n4 = O.fromString(e6.pointer);
    return r3.compare(n4);
  }
  compareValues(e6, r3, n4) {
    return t.compare(e6, r3, n4);
  }
  constructor(t5) {
    this.options = t5, c(this, "schema"), c(this, "indexes"), c(this, "resolveRichText"), c(this, "resolveVectorSetItem"), c(this, "chunks"), this.chunks = this.options.chunks.map((t6, e6) => new tO(e6, t6)), this.schema = t5.schema, this.indexes = t5.indexes, this.resolveRichText = t5.resolveRichText, this.resolveVectorSetItem = t5.resolveVectorSetItem;
  }
};

// http-url:https://framerusercontent.com/modules/548mUIgjuXCaDGGLvJLm/Cwjqmy8zrJwI74L4Wtrx/eXcwekmvS-1.js
import { jsx as e4 } from "react/jsx-runtime";
import { ComponentPresetsConsumer as r2, Link as t3, motion as n2 } from "./_framer-runtime.js";
import { isValidElement as o2 } from "react";
import { Fragment as c2, createElement as l2 } from "react";
var a2;
var i2 = "preload";
function u2(e6) {
  return "object" == typeof e6 && null !== e6 && !/* @__PURE__ */ o2(e6) && i2 in e6;
}
function m2(e6, ...r3) {
  if (!e6)
    throw Error("Assertion Error" + (r3.length > 0 ? ": " + r3.join(" ") : ""));
}
var s2 = ((a2 = s2 || {})[a2.Fragment = 1] = "Fragment", a2[a2.Link = 2] = "Link", a2[a2.Module = 3] = "Module", a2[a2.Tag = 4] = "Tag", a2[a2.Text = 5] = "Text", a2);
function f2(o4) {
  let a4 = /* @__PURE__ */ new Map();
  return (i3) => {
    let s4 = a4.get(i3);
    if (s4)
      return s4;
    let f4 = JSON.parse(i3), p3 = function a5(i4) {
      switch (i4[0]) {
        case 1: {
          let [, ...e6] = i4, r3 = e6.map(a5);
          return /* @__PURE__ */ l2(c2, void 0, ...r3);
        }
        case 2: {
          let [, e6, ...r3] = i4, n4 = r3.map(a5);
          return /* @__PURE__ */ l2(t3, e6, ...n4);
        }
        case 3: {
          let [, t5, n4] = i4, a6 = o4[t5];
          return m2(a6, "Module not found"), u2(a6) && a6.preload(), /* @__PURE__ */ e4(r2, { componentIdentifier: t5, children: (r3) => /* @__PURE__ */ e4(a6, { ...r3, ...n4 }) });
        }
        case 4: {
          let [, e6, r3, ...t5] = i4, o5 = t5.map(a5);
          if ("a" === e6)
            return /* @__PURE__ */ l2(n2.a, r3, ...o5);
          return /* @__PURE__ */ l2(e6, r3, ...o5);
        }
        case 5: {
          let [, e6] = i4;
          return e6;
        }
      }
    }(f4);
    return a4.set(i3, p3), p3;
  };
}

// http-url:https://framerusercontent.com/modules/548mUIgjuXCaDGGLvJLm/Cwjqmy8zrJwI74L4Wtrx/eXcwekmvS.js
var o3 = { BmVTaic1j: { isNullable: true, type: t4.String }, createdAt: { isNullable: true, type: t4.Date }, E_mwtx0QZ: { isNullable: true, type: t4.String }, id: { isNullable: false, type: t4.String }, nextItemId: { isNullable: true, type: t4.String }, PQdbWYFp9: { isNullable: true, type: t4.ResponsiveImage }, previousItemId: { isNullable: true, type: t4.String }, Qb4OL5EkO: { isNullable: true, type: t4.String }, Tp7BTfyI9: { definition: { definitions: { id: { isNullable: false, type: t4.String }, nMafZS3eQ: { isNullable: true, type: t4.ResponsiveImage } }, isNullable: true, type: t4.Object }, isNullable: true, type: t4.Array }, UmWRfDH5q: { isNullable: true, type: t4.Enum }, updatedAt: { isNullable: true, type: t4.Date }, vbLlZfmsq: { isNullable: true, type: t4.String }, wszBnNiRM: { isNullable: true, type: t4.Date }, XgQvgNH3C: { isNullable: true, type: t4.String } };
var n3 = ["id"];
var c3 = { type: 1 };
var s3 = ["previousItemId"];
var f3 = ["nextItemId"];
var u3 = ["id", "vbLlZfmsq"];
var d2 = ["vbLlZfmsq", "id"];
var p2 = ["BmVTaic1j"];
var y2 = { type: 0 };
var w2 = ["vbLlZfmsq"];
var g2 = ["XgQvgNH3C"];
var S2 = ["UmWRfDH5q"];
var v2 = ["wszBnNiRM"];
var h2 = ["PQdbWYFp9"];
var N2 = ["E_mwtx0QZ"];
var b2 = ["Qb4OL5EkO"];
var L2 = ["Tp7BTfyI9"];
var R2 = [];
var I2 = (e6) => {
  let t5 = R2[e6];
  if (t5)
    return t5().then((e7) => e7.default);
};
var k2 = {};
var x2 = f2(k2);
var U2 = new a3();
var X2 = new l3(U2);
var D2 = { collectionByLocaleId: { default: new tP({ chunks: [""], indexes: [new tN({ collation: c3, collectionSchema: o3, fieldNames: n3, range: { from: 0, to: 361 }, url: "" }), new tN({ collation: c3, collectionSchema: o3, fieldNames: s3, range: { from: 361, to: 721 }, url: "" }), new tN({ collation: c3, collectionSchema: o3, fieldNames: f3, range: { from: 721, to: 1077 }, url: "" }), new tN({ collation: c3, collectionSchema: o3, fieldNames: u3, range: { from: 1077, to: 1827 }, url: "" }), new tN({ collation: c3, collectionSchema: o3, fieldNames: d2, range: { from: 1827, to: 2577 }, url: "" }), new tN({ collation: y2, collectionSchema: o3, fieldNames: p2, range: { from: 2577, to: 3126 }, url: "" }), new tN({ collation: y2, collectionSchema: o3, fieldNames: w2, range: { from: 3126, to: 3674 }, url: "" }), new tN({ collation: y2, collectionSchema: o3, fieldNames: g2, range: { from: 3674, to: 6614 }, url: "" }), new tN({ collation: y2, collectionSchema: o3, fieldNames: S2, range: { from: 6614, to: 6982 }, url: "" }), new tN({ collation: y2, collectionSchema: o3, fieldNames: v2, range: { from: 6982, to: 7280 }, url: "" }), new tN({ collation: y2, collectionSchema: o3, fieldNames: h2, range: { from: 7280, to: 16259 }, url: "" }), new tN({ collation: y2, collectionSchema: o3, fieldNames: N2, range: { from: 16259, to: 16813 }, url: "" }), new tN({ collation: y2, collectionSchema: o3, fieldNames: b2, range: { from: 16813, to: 17274 }, url: "" }), new tN({ collation: y2, collectionSchema: o3, fieldNames: L2, range: { from: 17274, to: 52282 }, url: "" })], resolveRichText: x2, resolveVectorSetItem: I2, schema: o3 }) }, displayName: "Projects" };
var eXcwekmvS_default = D2;
e5(D2, { BmVTaic1j: { defaultValue: "", title: "Title", type: t4.String }, vbLlZfmsq: { title: "Slug", type: t4.String }, XgQvgNH3C: { defaultValue: "", title: "Description", type: t4.String }, UmWRfDH5q: { defaultValue: "F9kLDhCfC", options: ["F9kLDhCfC", "Ihgg0jjfd", "YQUtCAvXT", "BY9ec0BPz"], optionTitles: ["Residences", "Hospitality", "Offices", "Private homes"], title: "Category of project", type: t4.Enum }, wszBnNiRM: { title: "Date", type: t4.Date }, PQdbWYFp9: { title: "Image", type: t4.ResponsiveImage }, E_mwtx0QZ: { defaultValue: "", title: "Client name", type: t4.String }, Qb4OL5EkO: { defaultValue: "", title: "Client location", type: t4.String }, Tp7BTfyI9: { __vekterDefault: [], control: { controls: { nMafZS3eQ: { title: "Image", type: "responsiveimage" } }, type: "object" }, title: "Image gallery", type: t4.Array }, createdAt: { title: "Created", type: t4.Date }, updatedAt: { title: "Updated", type: t4.Date }, previousItemId: { dataIdentifier: "local-module:collection/eXcwekmvS:default", title: "Previous", type: t4.CollectionReference }, nextItemId: { dataIdentifier: "local-module:collection/eXcwekmvS:default", title: "Next", type: t4.CollectionReference } });
var UmWRfDH5qToDisplayName = (e6, t5) => {
  switch (t5?.fallback, e6) {
    case "F9kLDhCfC":
      return "Residences";
    case "Ihgg0jjfd":
      return "Hospitality";
    case "YQUtCAvXT":
      return "Offices";
    case "BY9ec0BPz":
      return "Private homes";
    default:
      return "";
  }
};
var enumToDisplayNameFunctions = { UmWRfDH5q: UmWRfDH5qToDisplayName };

// http-url:https://framerusercontent.com/modules/tzVJsaaItCltUFGTxc9U/wD6ctyQw1c4fPAiXjqcd/PypTXPJre.js
import { jsx as _jsx3, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx as cx3, getFontsFromSharedStyle, getLoadingLazyAtYPosition, Image, Link, RichText, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS3 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion3, MotionConfigContext } from "framer-motion";
import * as React3 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/wl4Z6flLnnzAefs6bzcs/qFQwnqAlnExrZz8t7P9Z/aXRHiY1jV.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["Inter-Light", "Inter", "Inter-Italic", "Inter-LightItalic"]);
var fonts = [{ explicitInter: true, fonts: [{ family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/BkDpl4ghaqvMi1btKFyG2tdbec.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/zAMK70AQRFSShJgUiaR5IiIhgzk.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/IETjvc5qzUaRoaruDpPSwCUM8.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/oLCoaT3ioA0fHdJnWR9W6k7NY.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/Sj0PCHQSBjFmEp6NBWg6FNaKc.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/aqiiD4LUKkKzXdjGL5UzHq8bo5w.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/H4TfENUY1rh8R9UaSD6vngjJP3M.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/CfMzU8w2e7tHgF4T4rATMPuWosA.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/867QObYax8ANsfX4TGEVU9YiCM.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Oyn2ZbENFdnW7mt2Lzjk1h9Zb9k.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/cdAe8hgZ1cMyLu9g005pAW3xMo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/DOfvtmE1UplCq161m6Hj8CSQYg.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/pKRFNWFoZl77qYCAIp84lN1h944.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/tKtBcDnBMevsEEJKdNGhhkLzYo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/YYB6GZmCWnZq3RWZOghuZIOxQY.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/miJTzODdiyIr3tRo9KEoqXXk2PM.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/6ZMhcggRFfEfbf7lncCpaUbA.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/8sCN6PGUr4I8q5hC5twAXfcwqV0.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/aUYDUTztS7anQw5JuwCncXeLOBY.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/8mwKwShtYEXIZ5diRBT74yn9jdQ.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/yDiPvYxioBHsicnYxpPW35WQmx8.woff2", weight: "300" }] }];
var css3 = [`.framer-GSjnh .framer-styles-preset-7fnut7:not(.rich-text-wrapper), .framer-GSjnh .framer-styles-preset-7fnut7.rich-text-wrapper p { --framer-font-family: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-bold: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv09' on, 'cv03' on, 'cv04' on, 'cv11' on; --framer-font-size: 12px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 300; --framer-font-weight-bold: 400; --framer-font-weight-bold-italic: 400; --framer-font-weight-italic: 300; --framer-letter-spacing: 0.02em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-d94cf02f-21bb-4a36-99ba-213bb4d1f375, #3a3938); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: uppercase; }`, `@media (max-width: 1199px) and (min-width: 810px) { .framer-GSjnh .framer-styles-preset-7fnut7:not(.rich-text-wrapper), .framer-GSjnh .framer-styles-preset-7fnut7.rich-text-wrapper p { --framer-font-family: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-bold: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv09' on, 'cv03' on, 'cv04' on, 'cv11' on; --framer-font-size: 11px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 300; --framer-font-weight-bold: 400; --framer-font-weight-bold-italic: 400; --framer-font-weight-italic: 300; --framer-letter-spacing: 0.02em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-d94cf02f-21bb-4a36-99ba-213bb4d1f375, #3a3938); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: uppercase; } }`, `@media (max-width: 809px) and (min-width: 0px) { .framer-GSjnh .framer-styles-preset-7fnut7:not(.rich-text-wrapper), .framer-GSjnh .framer-styles-preset-7fnut7.rich-text-wrapper p { --framer-font-family: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-bold: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv09' on, 'cv03' on, 'cv04' on, 'cv11' on; --framer-font-size: 11px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 300; --framer-font-weight-bold: 400; --framer-font-weight-bold-italic: 400; --framer-font-weight-italic: 300; --framer-letter-spacing: 0.01em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-d94cf02f-21bb-4a36-99ba-213bb4d1f375, #3a3938); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: uppercase; } }`];
var className = "framer-GSjnh";

// http-url:https://framerusercontent.com/modules/O9McSDmG0LeYiKRYBpQB/mngGwle9AkdWST5y3fzZ/RTNbCl6_B.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["FR;InterDisplay-Medium", "FR;InterDisplay-Bold", "FR;InterDisplay-BoldItalic", "FR;InterDisplay-MediumItalic"]);
var fonts2 = [{ explicitInter: true, fonts: [{ family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/ePuN3mCjzajIHnyCdvKBFiZkyY0.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/V3j1L0o5vPFKe26Sw4HcpXCfHo.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/F3kdpd2N0cToWV5huaZjjgM.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/0iDmxkizU9goZoclqIqsV5rvETU.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/r0mv3NegmA0akcQsNFotG32Las.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/iwWTDc49ENF2tCHbqlNARXw6Ug.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/Ii21jnSJkulBKsHHXKlapi7fv9w.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/I11LrmuBDQZweplJ62KkVsklU5Y.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/UjFZPDy3qGuDktQM4q9CxhKfIa8.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/8exwVHJy2DhJ4N5prYlVMrEKmQ.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/UTeedEK21hO5jDxEUldzdScUqpg.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/Ig8B8nzy11hzIWEIYnkg91sofjo.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/qITWJ2WdG0wrgQPDb8lvnYnTXDg.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/qctQFoJqJ9aIbRSIp0AhCQpFxn8.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/fXvVh2JeZlehNcEhKHpHH0frSl0.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/7pScaNeb6M7n2HF2jKemDqzCIr4.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/qS4UjQYyATcVV9rODk0Zx9KhkY8.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/VfD2n20yM7v0hrUEBHEyafsmMBY.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/4oIO9fB59bn3cKFWz7piCj28z9s.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/MzumQQZJQBC6KM1omtmwOtsogtI.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/F5Lmfd3fCAu7TwiYbI4DLWw4ks.woff2", weight: "700" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/A5P4nkYCJlLQxGxaS1lzG8PNSc.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/vuPfygr1n1zYxscvWgGI8hRf3LE.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/jplzYzqFHXreyADwk9yrkQlWQ.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/sSIKP2TfVPvfK7YVENPE5H87A.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/gawbeo7iEJSRZ4kcrh6YRrU8o.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/RkMAGv2iAm3rw7tZzs7FaZf0rM.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "italic", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/8E92vrr3j1gDqzepmeSbD2u0JxA.woff2", weight: "500" }] }];
var css4 = ['.framer-o5Osb .framer-styles-preset-1iswiwn:not(.rich-text-wrapper), .framer-o5Osb .framer-styles-preset-1iswiwn.rich-text-wrapper h3 { --framer-font-family: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-bold: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-italic: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 20px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 500; --framer-letter-spacing: -0.005em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-7b69926a-2698-4b88-8b05-ce64c178e9f3, #4d3b26); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }', '@media (max-width: 1199px) and (min-width: 810px) { .framer-o5Osb .framer-styles-preset-1iswiwn:not(.rich-text-wrapper), .framer-o5Osb .framer-styles-preset-1iswiwn.rich-text-wrapper h3 { --framer-font-family: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-bold: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-italic: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 500; --framer-letter-spacing: -0.005em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-7b69926a-2698-4b88-8b05-ce64c178e9f3, #4d3b26); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }', '@media (max-width: 809px) and (min-width: 0px) { .framer-o5Osb .framer-styles-preset-1iswiwn:not(.rich-text-wrapper), .framer-o5Osb .framer-styles-preset-1iswiwn.rich-text-wrapper h3 { --framer-font-family: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-bold: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-italic: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 24px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 500; --framer-letter-spacing: -0.005em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-7b69926a-2698-4b88-8b05-ce64c178e9f3, #4d3b26); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }'];
var className2 = "framer-o5Osb";

// http-url:https://framerusercontent.com/modules/wug64vCr9OPDP9vs60wu/rA3MTOzX3l8zLwPGZzlm/UmqT2pb04.js
import { fontStore as fontStore3 } from "./_framer-runtime.js";
fontStore3.loadFonts(["FR;InterDisplay-Medium", "Inter-Black", "Inter-BlackItalic", "Inter-BoldItalic"]);
var fonts3 = [{ explicitInter: true, fonts: [{ family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/ePuN3mCjzajIHnyCdvKBFiZkyY0.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/V3j1L0o5vPFKe26Sw4HcpXCfHo.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/F3kdpd2N0cToWV5huaZjjgM.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/0iDmxkizU9goZoclqIqsV5rvETU.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/r0mv3NegmA0akcQsNFotG32Las.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/iwWTDc49ENF2tCHbqlNARXw6Ug.woff2", weight: "500" }, { family: "Inter Display", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/Ii21jnSJkulBKsHHXKlapi7fv9w.woff2", weight: "500" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/mkY5Sgyq51ik0AMrSBwhm9DJg.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/X5hj6qzcHUYv7h1390c8Rhm6550.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/gQhNpS3tN86g8RcVKYUUaKt2oMQ.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/cugnVhSraaRyANCaUtI5FV17wk.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/5HcVoGak8k5agFJSaKa4floXVu0.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/rZ5DdENNqIdFTIyQQiP5isO7M.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/P2Bw01CtL0b9wqygO0sSVogWbo.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/05KsVHGDmqXSBXM4yRZ65P8i0s.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/ky8ovPukK4dJ1Pxq74qGhOqCYI.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/vvNSqIj42qeQ2bvCRBIWKHscrc.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/3ZmXbBKToJifDV9gwcifVd1tEY.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/FNfhX3dt4ChuLJq2PwdlxHO7PU.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/gcnfba68tfm7qAyrWRCf9r34jg.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/efTfQcBJ53kM2pB1hezSZ3RDUFs.woff2", weight: "900" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/H89BbHkbHDzlxZzxi8uPzTsp90.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/u6gJwDuwB143kpNK1T1MDKDWkMc.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/43sJ6MfOPh1LCJt46OvyDuSbA6o.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/wccHG0r4gBDAIRhfHiOlq6oEkqw.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/WZ367JPwf9bRW6LdTHN8rXgSjw.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/ia3uin3hQWqDrVloC1zEtYHWw.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "italic", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/2A4Xx7CngadFGlVV4xrO06OBHY.woff2", weight: "700" }] }];
var css5 = ['.framer-TCMD1 .framer-styles-preset-1nxp5a:not(.rich-text-wrapper), .framer-TCMD1 .framer-styles-preset-1nxp5a.rich-text-wrapper h3 { --framer-font-family: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-bold: "Inter", sans-serif; --framer-font-family-bold-italic: "Inter", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 16px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 900; --framer-font-weight-bold-italic: 900; --framer-font-weight-italic: 700; --framer-letter-spacing: -0.005em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-7b69926a-2698-4b88-8b05-ce64c178e9f3, #4d3b26); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }', '@media (max-width: 1199px) and (min-width: 810px) { .framer-TCMD1 .framer-styles-preset-1nxp5a:not(.rich-text-wrapper), .framer-TCMD1 .framer-styles-preset-1nxp5a.rich-text-wrapper h3 { --framer-font-family: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-bold: "Inter", sans-serif; --framer-font-family-bold-italic: "Inter", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 900; --framer-font-weight-bold-italic: 900; --framer-font-weight-italic: 700; --framer-letter-spacing: -0.005em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-7b69926a-2698-4b88-8b05-ce64c178e9f3, #4d3b26); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }', '@media (max-width: 809px) and (min-width: 0px) { .framer-TCMD1 .framer-styles-preset-1nxp5a:not(.rich-text-wrapper), .framer-TCMD1 .framer-styles-preset-1nxp5a.rich-text-wrapper h3 { --framer-font-family: "Inter Display", "Inter Display Placeholder", sans-serif; --framer-font-family-bold: "Inter", sans-serif; --framer-font-family-bold-italic: "Inter", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 900; --framer-font-weight-bold-italic: 900; --framer-font-weight-italic: 700; --framer-letter-spacing: -0.005em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-7b69926a-2698-4b88-8b05-ce64c178e9f3, #4d3b26); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }'];
var className3 = "framer-TCMD1";

// http-url:https://framerusercontent.com/modules/tzVJsaaItCltUFGTxc9U/wD6ctyQw1c4fPAiXjqcd/PypTXPJre.js
var enabledGestures = { Enq05tzLz: { hover: true }, Oe7D1_JCq: { hover: true }, RG9SNM1q1: { hover: true } };
var cycleOrder = ["Enq05tzLz", "RG9SNM1q1", "Oe7D1_JCq", "r34zsw11S", "acPCMiWfO"];
var serializationHash = "framer-VcFlv";
var variantClassNames = { acPCMiWfO: "framer-v-1m3pn5q", Enq05tzLz: "framer-v-y9sff5", Oe7D1_JCq: "framer-v-78g2dh", r34zsw11S: "framer-v-1f4e4t6", RG9SNM1q1: "framer-v-kzsc6m" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { delay: 0, duration: 0.2, ease: [0.44, 0, 0.56, 1], type: "tween" };
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var transition2 = { delay: 0, duration: 0.4, ease: [0.44, 0, 0.56, 1], type: "tween" };
var Transition = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext.Provider, { value: contextValue, children });
};
var transformTemplate1 = (_2, t5) => `translate(-50%, -50%) ${t5}`;
var Variants = motion3.create(React3.Fragment);
var humanReadableVariantMap = { "Desktop - Project card small version": "RG9SNM1q1", "Desktop - Project card": "Enq05tzLz", "Desktop- Furniture card": "Oe7D1_JCq", "Tablet & mobile - Furniture card": "r34zsw11S", "Tablet & Mobile - Project card small version": "acPCMiWfO" };
var getProps3 = ({ category, date, height, id, image, link, title, width, ...props }) => {
  return { ...props, LEYCzF3qG: title ?? props.LEYCzF3qG ?? "Guest House No. 16", LrprNhWNv: category ?? props.LrprNhWNv ?? "Category", qi7hnLCuE: date ?? props.qi7hnLCuE ?? "2025", uayW7rO1R: link ?? props.uayW7rO1R, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "Enq05tzLz", YxFNG7d6H: image ?? props.YxFNG7d6H };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className4, layoutId, variant, YxFNG7d6H, LEYCzF3qG, LrprNhWNv, qi7hnLCuE, uayW7rO1R, ...restProps } = getProps3(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "Enq05tzLz", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [className2, className, className3];
  const scopingClassNames = cx3(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (["Enq05tzLz-hover", "Oe7D1_JCq-hover", "RG9SNM1q1-hover"].includes(gestureVariant))
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx3(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion3.div, { ...restProps, ...gestureHandlers, className: cx3(scopingClassNames, "framer-y9sff5", className4, classNames), "data-framer-name": "Desktop - Project card", layoutDependency, layoutId: "Customcarousel__Enq05tzLz", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ "Enq05tzLz-hover": { "data-framer-name": void 0 }, "Oe7D1_JCq-hover": { "data-framer-name": void 0 }, "RG9SNM1q1-hover": { "data-framer-name": void 0 }, acPCMiWfO: { "data-framer-name": "Tablet & Mobile - Project card small version" }, Oe7D1_JCq: { "data-framer-name": "Desktop- Furniture card" }, r34zsw11S: { "data-framer-name": "Tablet & mobile - Furniture card" }, RG9SNM1q1: { "data-framer-name": "Desktop - Project card small version" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx3(Link, { href: uayW7rO1R, motionChild: true, nodeId: "V3405QgaM", openInNewTab: false, scopeId: "PypTXPJre", smoothScroll: true, ...addPropertyOverrides({ acPCMiWfO: { smoothScroll: false }, RG9SNM1q1: { smoothScroll: false } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx3(motion3.a, { className: "framer-1htkkmp framer-3chgdt", "data-framer-name": "Trigger link frame", layoutDependency, layoutId: "Customcarousel__V3405QgaM" }) }), /* @__PURE__ */ _jsxs(motion3.div, { className: "framer-q2x26j", "data-framer-name": "Image holder", layoutDependency, layoutId: "Customcarousel__RL2oNLKER", style: { borderBottomLeftRadius: 4, borderBottomRightRadius: 4, borderTopLeftRadius: 4, borderTopRightRadius: 4 }, children: [/* @__PURE__ */ _jsx3(Image, { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 0 + (((componentViewport?.height || 537.5) - 0 - 537.4) / 2 + 0 + 0) + 0), sizes: `max(${componentViewport?.width || "100vw"}, 1px)`, ...toResponsiveImage(YxFNG7d6H) }, className: "framer-zytrj7", "data-framer-name": "image", layoutDependency, layoutId: "Customcarousel__G6QWkyzWD", style: { borderBottomLeftRadius: 4, borderBottomRightRadius: 4, borderTopLeftRadius: 4, borderTopRightRadius: 4 }, ...addPropertyOverrides({ acPCMiWfO: { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 0 + (((componentViewport?.height || 312.5) - 0 - 312.4) / 2 + 0 + 0) + 0), sizes: `max(${componentViewport?.width || "100vw"}, 1px)`, ...toResponsiveImage(YxFNG7d6H) } }, Oe7D1_JCq: { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 0 + (((componentViewport?.height || 370.5) - 0 - 370.4) / 2 + 0 + 0) + 0), sizes: `max(${componentViewport?.width || "100vw"}, 1px)`, ...toResponsiveImage(YxFNG7d6H) } }, r34zsw11S: { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 0 + (((componentViewport?.height || 370.5) - 0 - 370.4) / 2 + 0 + 0) + 0), sizes: `max(${componentViewport?.width || "100vw"}, 1px)`, ...toResponsiveImage(YxFNG7d6H) } }, RG9SNM1q1: { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 0 + (((componentViewport?.height || 312.5) - 0 - 312.4) / 2 + 0 + 0) + 0), sizes: `max(${componentViewport?.width || "100vw"}, 1px)`, ...toResponsiveImage(YxFNG7d6H) } } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx3(Transition, { value: transition2, children: /* @__PURE__ */ _jsx3(motion3.div, { className: "framer-x81keg", "data-framer-name": "Overlay frame", layoutDependency, layoutId: "Customcarousel__I7wefDHGz", style: { backgroundColor: "var(--token-57a21128-a907-45be-b2a2-a0b1e9228351, rgb(0, 0, 0))", opacity: 0 }, variants: { "Enq05tzLz-hover": { opacity: 0.5 }, "Oe7D1_JCq-hover": { opacity: 0.5 }, "RG9SNM1q1-hover": { opacity: 0.5 } } }) }), isDisplayed() && /* @__PURE__ */ _jsx3(motion3.div, { className: "framer-10s66w", "data-framer-name": "Text holder ", layoutDependency, layoutId: "Customcarousel__vjpISlNjX", transformTemplate: transformTemplate1, children: isDisplayed() && /* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.h3, { className: "framer-styles-preset-1iswiwn", "data-styles-preset": "RTNbCl6_B", style: { "--framer-text-color": "var(--extracted-a0htzi, var(--token-aca059a2-1a99-4358-9d02-0a778aaef927, rgb(255, 255, 255)))" }, children: "View more" }) }), className: "framer-vn46db", fonts: ["Inter"], layoutDependency, layoutId: "Customcarousel__GSDzi7CRt", style: { "--extracted-a0htzi": "var(--token-aca059a2-1a99-4358-9d02-0a778aaef927, rgb(255, 255, 255))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true }) })] }), /* @__PURE__ */ _jsxs(motion3.div, { className: "framer-r76vi5", "data-framer-name": "Project details", layoutDependency, layoutId: "Customcarousel__fIxd62B23", children: [/* @__PURE__ */ _jsxs(motion3.div, { className: "framer-1fid27z", "data-framer-name": "Meta data", layoutDependency, layoutId: "Customcarousel__qEZ0udEmY", children: [/* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.p, { className: "framer-styles-preset-7fnut7", "data-styles-preset": "aXRHiY1jV", children: "Category" }) }), className: "framer-1recupm", "data-framer-name": "Category", fonts: ["Inter"], layoutDependency, layoutId: "Customcarousel__eZiLVnoHR", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: LrprNhWNv, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.p, { className: "framer-styles-preset-7fnut7", "data-styles-preset": "aXRHiY1jV", children: "/" }) }), className: "framer-10mkrhb", "data-framer-name": "Spacer", fonts: ["Inter"], layoutDependency, layoutId: "Customcarousel__iXrxAKp0T", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.p, { className: "framer-styles-preset-7fnut7", "data-styles-preset": "aXRHiY1jV", children: "2025" }) }), className: "framer-ljhi9", "data-framer-name": "Year", fonts: ["Inter"], layoutDependency, layoutId: "Customcarousel__VOHK_sOHN", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: qi7hnLCuE, verticalAlignment: "top", withExternalLayout: true })] }), /* @__PURE__ */ _jsx3(motion3.div, { className: "framer-1ib00np", "data-framer-name": "Content", layoutDependency, layoutId: "Customcarousel__tuNCVpz3J", children: /* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.h3, { className: "framer-styles-preset-1nxp5a", "data-styles-preset": "UmqT2pb04", children: "Guest House No. 16" }) }), className: "framer-1lzlpp6", "data-framer-name": "TItle", fonts: ["Inter"], layoutDependency, layoutId: "Customcarousel__h6bUeAwRp", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: LEYCzF3qG, verticalAlignment: "top", withExternalLayout: true }) })] })] }) }) }) });
});
var css6 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-VcFlv.framer-3chgdt, .framer-VcFlv .framer-3chgdt { display: block; }", ".framer-VcFlv.framer-y9sff5 { align-content: flex-start; align-items: flex-start; cursor: pointer; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-VcFlv .framer-1htkkmp { bottom: 0px; flex: none; left: 0px; overflow: var(--overflow-clip-fallback, clip); position: absolute; right: 0px; text-decoration: none; top: 0px; z-index: 2; }", ".framer-VcFlv .framer-q2x26j { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: 473px; justify-content: center; overflow: visible; padding: 0px; pointer-events: none; position: relative; width: 100%; }", ".framer-VcFlv .framer-zytrj7 { flex: 1 0 0px; height: 100%; overflow: var(--overflow-clip-fallback, clip); position: relative; width: 1px; will-change: var(--framer-will-change-override, transform); }", ".framer-VcFlv .framer-x81keg { bottom: 0px; flex: none; left: 0px; overflow: visible; position: absolute; right: 0px; top: 0px; z-index: 1; }", ".framer-VcFlv .framer-10s66w { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; left: 50%; min-height: 29px; min-width: 107px; overflow: visible; padding: 0px; position: absolute; top: 50%; width: min-content; z-index: 3; }", ".framer-VcFlv .framer-vn46db, .framer-VcFlv .framer-1lzlpp6 { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-VcFlv .framer-r76vi5 { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 12px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px 16px 0px 0px; position: relative; width: 100%; }", ".framer-VcFlv .framer-1fid27z { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 4px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: 100%; }", '.framer-VcFlv .framer-1recupm, .framer-VcFlv .framer-10mkrhb, .framer-VcFlv .framer-ljhi9 { --text-truncation-display-inline-for-safari-16: inline; --text-truncation-display-none-for-safari-16: none; --text-truncation-line-break-for-safari-16: "\\A"; -webkit-box-orient: vertical; -webkit-line-clamp: 2; display: -webkit-box; flex: none; height: auto; overflow: var(--overflow-clip-fallback, clip); position: relative; white-space: pre; width: auto; }', ".framer-VcFlv .framer-1ib00np { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 12px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-VcFlv.framer-v-kzsc6m.framer-y9sff5, .framer-VcFlv.framer-v-78g2dh.framer-y9sff5 { width: 100%; }", ".framer-VcFlv.framer-v-kzsc6m .framer-q2x26j, .framer-VcFlv.framer-v-1m3pn5q .framer-q2x26j { height: 248px; }", ".framer-VcFlv.framer-v-kzsc6m .framer-1fid27z, .framer-VcFlv.framer-v-78g2dh .framer-1fid27z, .framer-VcFlv.framer-v-1f4e4t6 .framer-1fid27z, .framer-VcFlv.framer-v-1m3pn5q .framer-1fid27z { order: 0; }", ".framer-VcFlv.framer-v-kzsc6m .framer-1ib00np, .framer-VcFlv.framer-v-78g2dh .framer-1ib00np, .framer-VcFlv.framer-v-1f4e4t6 .framer-1ib00np, .framer-VcFlv.framer-v-1m3pn5q .framer-1ib00np { order: 1; }", ".framer-VcFlv.framer-v-78g2dh .framer-q2x26j, .framer-VcFlv.framer-v-1f4e4t6 .framer-q2x26j { height: 306px; }", ".framer-VcFlv.framer-v-1f4e4t6.framer-y9sff5, .framer-VcFlv.framer-v-1m3pn5q.framer-y9sff5 { cursor: unset; width: 100%; }", ".framer-VcFlv.framer-v-y9sff5.hover .framer-10s66w, .framer-VcFlv.framer-v-78g2dh.hover .framer-10s66w, .framer-VcFlv.framer-v-kzsc6m.hover .framer-10s66w { min-height: unset; min-width: unset; }", ...css4, ...css3, ...css5];
var FramerPypTXPJre = withCSS3(Component3, css6, "framer-VcFlv");
var PypTXPJre_default = FramerPypTXPJre;
FramerPypTXPJre.displayName = "Project & furniture card";
FramerPypTXPJre.defaultProps = { height: 537.5, width: 488 };
addPropertyControls3(FramerPypTXPJre, { variant: { options: ["Enq05tzLz", "RG9SNM1q1", "Oe7D1_JCq", "r34zsw11S", "acPCMiWfO"], optionTitles: ["Desktop - Project card", "Desktop - Project card small version", "Desktop- Furniture card", "Tablet & mobile - Furniture card", "Tablet & Mobile - Project card small version"], title: "Variant", type: ControlType3.Enum }, YxFNG7d6H: { title: "Image", type: ControlType3.ResponsiveImage }, LEYCzF3qG: { defaultValue: "Guest House No. 16", displayTextArea: false, title: "Title", type: ControlType3.String }, LrprNhWNv: { defaultValue: "Category", displayTextArea: false, title: "Category", type: ControlType3.String }, qi7hnLCuE: { defaultValue: "2025", displayTextArea: false, title: "Date", type: ControlType3.String }, uayW7rO1R: { title: "Link", type: ControlType3.Link } });
addFonts(FramerPypTXPJre, [{ explicitInter: true, fonts: [{ family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle(fonts2), ...getFontsFromSharedStyle(fonts), ...getFontsFromSharedStyle(fonts3)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/pzyFa36AOoYxt2EiYg3j/npw4HcOfkzWCHBehpci4/HUxtiZv8t.js
var ProjectFurnitureCardFonts = getFonts(PypTXPJre_default);
var SmartComponentScopedContainerWithFX = withFX(SmartComponentScopedContainer);
var ArrowLeftFonts = getFonts(zUKqqFh0Q_default);
var ArrowRightFonts = getFonts(rQDpQQ4Qi_default);
var cycleOrder2 = ["gcUnBc_vE", "qWlvidiUn", "H9Es9M3CC", "aFSYJNxeP", "m1NHG5xSr", "Y5gJ0zwLZ"];
var serializationHash2 = "framer-1rLEp";
var variantClassNames2 = { aFSYJNxeP: "framer-v-dsg9w7", gcUnBc_vE: "framer-v-ojpbze", H9Es9M3CC: "framer-v-1oniqj8", m1NHG5xSr: "framer-v-1q34dts", qWlvidiUn: "framer-v-jd552f", Y5gJ0zwLZ: "framer-v-k5oat0" };
function addPropertyOverrides2(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var toOverflowWithClipFallback = (value) => {
  if (value === "clip")
    return "var(--overflow-clip-fallback, clip)";
  return value;
};
var transition12 = { delay: 0, duration: 0.4, ease: [0.44, 0, 0.56, 1], type: "tween" };
var animation = { opacity: 0, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, x: 100, y: 0 };
var transition22 = { delay: 0, duration: 0.5, ease: [0, 0, 0.2, 1], type: "tween" };
var stagger = (transition, value) => ({ ...transition, delay: (transition.delay ?? 0) + value });
var toResponsiveImage2 = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var sharedDateFormatter = (value, formatOptions, locale) => {
  if (typeof value !== "string")
    return "";
  const date = new Date(value);
  if (isNaN(date.getTime()))
    return "";
  const fallbackLocale = "en-US";
  try {
    return date.toLocaleString(locale || fallbackLocale, formatOptions);
  } catch {
    return date.toLocaleString(fallbackLocale, formatOptions);
  }
};
var dateOptions = { timeZone: "UTC", year: "numeric" };
var toDateString = (value, activeLocale) => {
  return sharedDateFormatter(value, dateOptions, activeLocale);
};
var QueryData = ({ query, pageSize, children }) => {
  const data = __framer_useQueryData(query);
  return children(data);
};
var Transition2 = ({ value, children }) => {
  const config = React4.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React4.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext2.Provider, { value: contextValue, children });
};
var Variants2 = motion4.create(React4.Fragment);
var humanReadableEnumMap = { Clip: "clip", Hidden: "hidden", Scroll: "auto", Visible: "visible" };
var humanReadableVariantMap2 = { "Desktop 1": "gcUnBc_vE", "Desktop 2": "qWlvidiUn", "Desktop 3": "H9Es9M3CC", "Tablet 1": "aFSYJNxeP", "Tablet 2": "m1NHG5xSr", "Tablet 3": "Y5gJ0zwLZ" };
var getProps4 = ({ height, id, overflow, scrollSection, visible, width, ...props }) => {
  return { ...props, Bny4_YtGq: visible ?? props.Bny4_YtGq ?? true, JaWFBl0r6: scrollSection ?? props.JaWFBl0r6, lvRd6TQNA: humanReadableEnumMap[overflow] ?? overflow ?? props.lvRd6TQNA ?? "visible", variant: humanReadableVariantMap2[props.variant] ?? props.variant ?? "gcUnBc_vE" };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component4 = /* @__PURE__ */ React4.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React4.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className: className4, layoutId, variant, lvRd6TQNA, Bny4_YtGq, JaWFBl0r6, PQdbWYFp9ctcoMet8P, BmVTaic1jctcoMet8P, UmWRfDH5qctcoMet8P, wszBnNiRMctcoMet8P, vbLlZfmsqctcoMet8P, idctcoMet8P, ...restProps } = getProps4(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder: cycleOrder2, defaultVariant: "gcUnBc_vE", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTap7w50mv = activeVariantCallback(async (...args) => {
    setVariant("gcUnBc_vE");
  });
  const onTap17mlxv6 = activeVariantCallback(async (...args) => {
    setVariant("qWlvidiUn");
  });
  const onTap156oexg = activeVariantCallback(async (...args) => {
    setVariant("aFSYJNxeP");
  });
  const onTap1tpyddt = activeVariantCallback(async (...args) => {
    setVariant("m1NHG5xSr");
  });
  const onTapxu82p4 = activeVariantCallback(async (...args) => {
    setVariant("H9Es9M3CC");
  });
  const onTapgy5zlt = activeVariantCallback(async (...args) => {
    setVariant("Y5gJ0zwLZ");
  });
  const sharedStyleClassNames = [];
  const scopingClassNames = cx4(serializationHash2, ...sharedStyleClassNames);
  const activeLocaleCode = useLocaleCode();
  const router = useRouter();
  return /* @__PURE__ */ _jsx4(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition2, { value: transition12, children: /* @__PURE__ */ _jsxs2(motion4.div, { ...restProps, ...gestureHandlers, className: cx4(scopingClassNames, "framer-ojpbze", className4, classNames), "data-framer-name": "Desktop 1", layoutDependency, layoutId: "Customcarousel__gcUnBc_vE", ref: refBinding, style: { "--cprx4l": toOverflowWithClipFallback(lvRd6TQNA), ...style }, ...addPropertyOverrides2({ aFSYJNxeP: { "data-framer-name": "Tablet 1" }, H9Es9M3CC: { "data-framer-name": "Desktop 3" }, m1NHG5xSr: { "data-framer-name": "Tablet 2" }, qWlvidiUn: { "data-framer-name": "Desktop 2" }, Y5gJ0zwLZ: { "data-framer-name": "Tablet 3" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx4(motion4.div, { className: "framer-1skbipr", layoutDependency, layoutId: "Customcarousel__ctcoMet8P", children: /* @__PURE__ */ _jsx4(ChildrenCanSuspend, { children: /* @__PURE__ */ _jsx4(QueryData, { query: { from: { alias: "ctcoMet8P", data: eXcwekmvS_default, type: "Collection" }, limit: { type: "LiteralValue", value: 6 }, select: [{ collection: "ctcoMet8P", name: "PQdbWYFp9", type: "Identifier" }, { collection: "ctcoMet8P", name: "BmVTaic1j", type: "Identifier" }, { collection: "ctcoMet8P", name: "UmWRfDH5q", type: "Identifier" }, { collection: "ctcoMet8P", name: "wszBnNiRM", type: "Identifier" }, { collection: "ctcoMet8P", name: "vbLlZfmsq", type: "Identifier" }, { collection: "ctcoMet8P", name: "id", type: "Identifier" }], where: { operator: "not", type: "UnaryOperation", value: { left: { collection: "ctcoMet8P", name: "UmWRfDH5q", type: "Identifier" }, operator: "==", right: { type: "LiteralValue", value: "F9kLDhCfC" }, type: "BinaryOperation" } } }, children: (collection, paginationInfo, loadMore) => /* @__PURE__ */ _jsx4(_Fragment, { children: collection?.map(({ BmVTaic1j: BmVTaic1jctcoMet8P2, id: idctcoMet8P2, PQdbWYFp9: PQdbWYFp9ctcoMet8P2, UmWRfDH5q: UmWRfDH5qctcoMet8P2, vbLlZfmsq: vbLlZfmsqctcoMet8P2, wszBnNiRM: wszBnNiRMctcoMet8P2 }, index) => {
    BmVTaic1jctcoMet8P2 ?? (BmVTaic1jctcoMet8P2 = "");
    vbLlZfmsqctcoMet8P2 ?? (vbLlZfmsqctcoMet8P2 = "");
    return /* @__PURE__ */ _jsx4(LayoutGroup2, { id: `ctcoMet8P-${idctcoMet8P2}`, children: /* @__PURE__ */ _jsx4(PathVariablesContext.Provider, { value: { vbLlZfmsq: vbLlZfmsqctcoMet8P2 }, children: /* @__PURE__ */ _jsx4(ResolveLinks, { links: [{ href: { pathVariables: { vbLlZfmsq: vbLlZfmsqctcoMet8P2 }, webPageId: "Rj_Ok9lwN" }, implicitPathVariables: void 0 }, { href: { pathVariables: { vbLlZfmsq: vbLlZfmsqctcoMet8P2 }, webPageId: "Rj_Ok9lwN" }, implicitPathVariables: void 0 }, { href: { pathVariables: { vbLlZfmsq: vbLlZfmsqctcoMet8P2 }, webPageId: "Rj_Ok9lwN" }, implicitPathVariables: void 0 }, { href: { pathVariables: { vbLlZfmsq: vbLlZfmsqctcoMet8P2 }, webPageId: "Rj_Ok9lwN" }, implicitPathVariables: void 0 }, { href: { pathVariables: { vbLlZfmsq: vbLlZfmsqctcoMet8P2 }, webPageId: "Rj_Ok9lwN" }, implicitPathVariables: void 0 }, { href: { pathVariables: { vbLlZfmsq: vbLlZfmsqctcoMet8P2 }, webPageId: "Rj_Ok9lwN" }, implicitPathVariables: void 0 }], children: (resolvedLinks) => /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 537, y: (componentViewport?.y || 0) + 0 + 0, children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainerWithFX, { __framer__animate: { transition: stagger(transition22, index * 0.1) }, __framer__animateOnce: true, __framer__enter: animation, __framer__styleAppearEffectEnabled: true, __framer__targets: [{ ref: JaWFBl0r6, target: "animate" }], __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: "framer-1q6t0c1-container", layoutDependency, layoutId: "Customcarousel__sKltStPvx-container", nodeId: "sKltStPvx", rendersWithMotion: true, scopeId: "HUxtiZv8t", children: /* @__PURE__ */ _jsx4(PypTXPJre_default, { height: "100%", id: "sKltStPvx", layoutId: "Customcarousel__sKltStPvx", LEYCzF3qG: BmVTaic1jctcoMet8P2, LrprNhWNv: enumToDisplayNameFunctions["UmWRfDH5q"]?.(UmWRfDH5qctcoMet8P2, activeLocale), qi7hnLCuE: toDateString(wszBnNiRMctcoMet8P2, activeLocaleCode), uayW7rO1R: resolvedLinks[0], variant: "RG9SNM1q1", width: "100%", YxFNG7d6H: toResponsiveImage2(PQdbWYFp9ctcoMet8P2), ...addPropertyOverrides2({ aFSYJNxeP: { uayW7rO1R: resolvedLinks[3], variant: "acPCMiWfO" }, H9Es9M3CC: { uayW7rO1R: resolvedLinks[2] }, m1NHG5xSr: { uayW7rO1R: resolvedLinks[4], variant: "acPCMiWfO" }, qWlvidiUn: { uayW7rO1R: resolvedLinks[1] }, Y5gJ0zwLZ: { uayW7rO1R: resolvedLinks[5], variant: "acPCMiWfO" } }, baseVariant, gestureVariant) }) }) }) }) }) }, idctcoMet8P2);
  }) }) }) }) }), Bny4_YtGq && /* @__PURE__ */ _jsxs2(motion4.div, { className: "framer-18wmucg", "data-framer-name": "Control container", layoutDependency, layoutId: "Customcarousel__TCnXLCwkU", children: [/* @__PURE__ */ _jsx4(motion4.div, { className: "framer-zalvu", "data-framer-name": "Icon container", layoutDependency, layoutId: "Customcarousel__F46rN3sdF", style: { backgroundColor: "var(--token-d94cf02f-21bb-4a36-99ba-213bb4d1f375, rgba(77, 59, 38, 0.7))", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100, opacity: 0.3 }, variants: { H9Es9M3CC: { opacity: 1 }, m1NHG5xSr: { opacity: 1 }, qWlvidiUn: { opacity: 1 }, Y5gJ0zwLZ: { opacity: 1 } }, ...addPropertyOverrides2({ H9Es9M3CC: { "data-highlight": true, onTap: onTap17mlxv6 }, m1NHG5xSr: { "data-highlight": true, onTap: onTap156oexg }, qWlvidiUn: { "data-highlight": true, onTap: onTap7w50mv }, Y5gJ0zwLZ: { "data-highlight": true, onTap: onTap1tpyddt } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(zUKqqFh0Q_default, { animated: true, className: "framer-1sx1j6b", "data-framer-name": "Icon", layoutDependency, layoutId: "Customcarousel__VU0QJ332u", style: { "--42b6oa": 0.16, "--4i27ky": "var(--token-aca059a2-1a99-4358-9d02-0a778aaef927, rgb(255, 255, 255))", "--b8xnka": 1 } }) }), /* @__PURE__ */ _jsx4(motion4.div, { className: "framer-ckp24", "data-framer-name": "Icon container", "data-highlight": true, layoutDependency, layoutId: "Customcarousel__KYoCPlNbA", onTap: onTap17mlxv6, style: { backgroundColor: "var(--token-d94cf02f-21bb-4a36-99ba-213bb4d1f375, rgba(77, 59, 38, 0.7))", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100, opacity: 1 }, variants: { aFSYJNxeP: { opacity: 1 }, H9Es9M3CC: { opacity: 0.3 }, m1NHG5xSr: { opacity: 1 }, Y5gJ0zwLZ: { opacity: 0.3 } }, ...addPropertyOverrides2({ aFSYJNxeP: { onTap: onTap1tpyddt }, H9Es9M3CC: { "data-highlight": void 0, onTap: void 0 }, m1NHG5xSr: { onTap: onTapgy5zlt }, qWlvidiUn: { onTap: onTapxu82p4 }, Y5gJ0zwLZ: { "data-highlight": void 0, onTap: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(rQDpQQ4Qi_default, { animated: true, className: "framer-kh8zgt", "data-framer-name": "Icon", layoutDependency, layoutId: "Customcarousel__blWsLeQGG", style: { "--42b6oa": 0.16, "--4i27ky": "var(--token-aca059a2-1a99-4358-9d02-0a778aaef927, rgb(255, 255, 255))", "--b8xnka": 1 } }) })] })] }) }) }) });
});
var css7 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-1rLEp.framer-e2ezgm, .framer-1rLEp .framer-e2ezgm { display: block; }", ".framer-1rLEp.framer-ojpbze { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 32px; height: auto; justify-content: flex-start; overflow: var(--cprx4l); padding: 0px; position: relative; width: 100%; }", ".framer-1rLEp .framer-1skbipr { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 24px; height: min-content; justify-content: flex-start; left: 0px; padding: 0px; position: absolute; top: 0px; width: min-content; z-index: 1; }", ".framer-1rLEp .framer-1q6t0c1-container { flex: none; height: auto; position: relative; width: auto; }", ".framer-1rLEp .framer-18wmucg { align-content: center; align-items: center; bottom: 0px; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: flex-end; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: absolute; right: 0px; width: min-content; z-index: 1; }", ".framer-1rLEp .framer-zalvu { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-1rLEp .framer-1sx1j6b, .framer-1rLEp .framer-kh8zgt { -webkit-user-select: none; flex: none; height: var(--framer-aspect-ratio-supported, 32px); position: relative; user-select: none; width: 32px; }", ".framer-1rLEp .framer-ckp24 { align-content: center; align-items: center; cursor: pointer; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-1rLEp.framer-v-jd552f .framer-1skbipr, .framer-1rLEp.framer-v-1q34dts .framer-1skbipr { left: -293px; }", ".framer-1rLEp.framer-v-jd552f .framer-zalvu, .framer-1rLEp.framer-v-1oniqj8 .framer-zalvu, .framer-1rLEp.framer-v-1q34dts .framer-zalvu, .framer-1rLEp.framer-v-k5oat0 .framer-zalvu { cursor: pointer; }", ".framer-1rLEp.framer-v-1oniqj8 .framer-1skbipr, .framer-1rLEp.framer-v-k5oat0 .framer-1skbipr { left: unset; right: 0px; }", ".framer-1rLEp.framer-v-1oniqj8 .framer-1sx1j6b, .framer-1rLEp.framer-v-1oniqj8 .framer-kh8zgt, .framer-1rLEp.framer-v-dsg9w7 .framer-1sx1j6b, .framer-1rLEp.framer-v-dsg9w7 .framer-kh8zgt, .framer-1rLEp.framer-v-1q34dts .framer-1sx1j6b, .framer-1rLEp.framer-v-1q34dts .framer-kh8zgt, .framer-1rLEp.framer-v-k5oat0 .framer-1sx1j6b, .framer-1rLEp.framer-v-k5oat0 .framer-kh8zgt { height: var(--framer-aspect-ratio-supported, 24px); }", ".framer-1rLEp.framer-v-1oniqj8 .framer-ckp24, .framer-1rLEp.framer-v-k5oat0 .framer-ckp24 { cursor: unset; }"];
var FramerHUxtiZv8t = withCSS4(Component4, css7, "framer-1rLEp");
var HUxtiZv8t_default = FramerHUxtiZv8t;
FramerHUxtiZv8t.displayName = "Custom carousel";
FramerHUxtiZv8t.defaultProps = { height: 390, width: 790 };
addPropertyControls4(FramerHUxtiZv8t, { variant: { options: ["gcUnBc_vE", "qWlvidiUn", "H9Es9M3CC", "aFSYJNxeP", "m1NHG5xSr", "Y5gJ0zwLZ"], optionTitles: ["Desktop 1", "Desktop 2", "Desktop 3", "Tablet 1", "Tablet 2", "Tablet 3"], title: "Variant", type: ControlType4.Enum }, lvRd6TQNA: { defaultValue: "visible", options: ["clip", "visible", "hidden", "auto"], optionTitles: ["Clip", "Visible", "Hidden", "Scroll"], title: "Overflow", type: ControlType4.Enum }, Bny4_YtGq: { defaultValue: true, title: "Visible", type: ControlType4.Boolean }, JaWFBl0r6: { title: "Scroll Section", type: ControlType4.ScrollSectionRef } });
addFonts2(FramerHUxtiZv8t, [{ explicitInter: true, fonts: [] }, ...ProjectFurnitureCardFonts, ...ArrowLeftFonts, ...ArrowRightFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerHUxtiZv8t", "slots": [], "annotations": { "framerComponentViewportWidth": "true", "framerColorSyntax": "true", "framerIntrinsicWidth": "790", "framerAutoSizeImages": "true", "framerImmutableVariables": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","fixed"]},"qWlvidiUn":{"layout":["fixed","fixed"]},"H9Es9M3CC":{"layout":["fixed","fixed"]},"aFSYJNxeP":{"layout":["fixed","fixed"]},"m1NHG5xSr":{"layout":["fixed","fixed"]},"Y5gJ0zwLZ":{"layout":["fixed","fixed"]}}}', "framerIntrinsicHeight": "390", "framerDisplayContentsDiv": "false", "framerVariables": '{"lvRd6TQNA":"overflow","Bny4_YtGq":"visible","JaWFBl0r6":"scrollSection"}', "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  HUxtiZv8t_default as default
};
