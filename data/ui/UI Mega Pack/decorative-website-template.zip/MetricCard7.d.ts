export interface Metriccard7Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop & tablet Metric card" → YNKus20kj
   *   "Mobile - Metric card" → tnrIjeU7L
   */
  variant?: 'Desktop & tablet Metric card' | 'Mobile - Metric card' | 'YNKus20kj' | 'tnrIjeU7L';
  /**
   * Scroll Section — pass as `k5_0Vif0T` not `scrollSection`.
   */
  k5_0Vif0T?: string;
  /**
   * Metric name — pass as `nvwESscfH` not `metricName`.
   * @default "Years of experience"
   */
  nvwESscfH?: string;
  /**
   * Number — pass as `ff2RGLYj8` not `number`.
   * @default "+10"
   */
  ff2RGLYj8?: string;
  /** Additional properties */
  [key: string]: unknown;
}
