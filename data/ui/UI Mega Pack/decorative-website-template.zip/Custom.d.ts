export interface CustomProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop 1" → gcUnBc_vE
   *   "Desktop 2" → qWlvidiUn
   *   "Desktop 3" → H9Es9M3CC
   *   "Tablet 1" → aFSYJNxeP
   *   "Tablet 2" → m1NHG5xSr
   *   "Tablet 3" → Y5gJ0zwLZ
   */
  variant?: 'Desktop 1' | 'Desktop 2' | 'Desktop 3' | 'Tablet 1' | 'Tablet 2' | 'Tablet 3' | 'gcUnBc_vE' | 'qWlvidiUn' | 'H9Es9M3CC' | 'aFSYJNxeP' | 'm1NHG5xSr' | 'Y5gJ0zwLZ';
  /**
   * Overflow — pass as `lvRd6TQNA` not `overflow`.
   * Options: "clip" | "visible" | "hidden" | "auto"
   * @default "visible"
   */
  lvRd6TQNA?: 'clip' | 'visible' | 'hidden' | 'auto';
  /**
   * Visible — pass as `Bny4_YtGq` not `visible`.
   * @default true
   */
  Bny4_YtGq?: boolean;
  /**
   * Scroll Section — pass as `JaWFBl0r6` not `scrollSection`.
   */
  JaWFBl0r6?: string;
  /** Additional properties */
  [key: string]: unknown;
}
