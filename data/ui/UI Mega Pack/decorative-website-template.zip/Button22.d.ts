export interface Button22Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Primary button" → f7J4qB6yY
   *   "Secondary button" → PPMcU8IJf
   */
  variant?: 'Primary button' | 'Secondary button' | 'f7J4qB6yY' | 'PPMcU8IJf';
  /**
   * Link — pass as `j2NxrfVVH` not `link`.
   */
  j2NxrfVVH?: string;
  /**
   * New Tab — pass as `GGxujnHQZ` not `newTab`.
   * @default false
   */
  GGxujnHQZ?: boolean;
  /**
   * Title — pass as `zhvDi8ka3` not `title`.
   * @default "View more"
   */
  zhvDi8ka3?: string;
  /**
   * Icon — pass as `fyEx_kDma` not `icon`.
   * @default {"identifier":"module:icNmModWONtmIk86QfN3/3OgILX1zHXmV4TyCJSLz/rQDpQQ4Qi.js:default","moduleId":"icNmModWONtmIk86QfN3"}
   */
  fyEx_kDma?: string;
  /**
   * Visible — pass as `zvI3UYbXC` not `visible`.
   * @default true
   */
  zvI3UYbXC?: boolean;
  /**
   * Color — pass as `z9AvAKgWv` not `color`.
   * @default "var(--token-aca059a2-1a99-4358-9d02-0a778aaef927, rgb(255, 255, 255))"
   */
  z9AvAKgWv?: string;
  /** Additional properties */
  [key: string]: unknown;
}
