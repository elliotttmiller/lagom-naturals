# Button

Exported from Framer using Design to AI.

## Components

- `Button`
- `MetricCard`
- `MetricCard2`
- `MetricCard3`
- `MetricCard4`
- `MetricCard5`
- `Button2`
- `ProjectFurnitureCard`
- `Button3`
- `Custom`
- `ProjectFurnitureCard2`
- `Button4`
- `ProjectFurnitureCard3`
- `Faq`
- `SmoothscrollProd`
- `Button5`
- `MetricCard6`
- `MetricCard7`
- `MetricCard8`
- `MetricCard9`
- `MetricCard10`
- `Button6`
- `ProjectFurnitureCard4`
- `Button7`
- `Custom2`
- `ProjectFurnitureCard5`
- `Button8`
- `ProjectFurnitureCard6`
- `Faq2`
- `SmoothscrollProd2`
- `Button9`
- `MetricCard11`
- `MetricCard12`
- `MetricCard13`
- `MetricCard14`
- `MetricCard15`
- `Button10`
- `ProjectFurnitureCard7`
- `Button11`
- `Custom3`
- `ProjectFurnitureCard8`
- `Button12`
- `ProjectFurnitureCard9`
- `Faq3`
- `SmoothscrollProd3`
- `Button13`
- `MetricCard16`
- `MetricCard17`
- `MetricCard18`
- `MetricCard19`
- `MetricCard20`
- `Button14`
- `ProjectFurnitureCard10`
- `Button15`
- `Custom4`
- `ProjectFurnitureCard11`
- `Button16`
- `ProjectFurnitureCard12`
- `Faq4`
- `SmoothscrollProd4`
- `Button17`
- `MetricCard21`
- `MetricCard22`
- `MetricCard23`
- `MetricCard24`
- `MetricCard25`
- `Button18`
- `ProjectFurnitureCard13`
- `Button19`
- `Custom5`
- `ProjectFurnitureCard14`
- `Button20`
- `ProjectFurnitureCard15`
- `Faq5`
- `SmoothscrollProd5`
- `Button21`
- `MetricCard26`
- `MetricCard27`
- `MetricCard28`
- `MetricCard29`
- `MetricCard30`
- `Button22`
- `ProjectFurnitureCard16`
- `Button23`
- `Custom6`
- `ProjectFurnitureCard17`
- `Button24`
- `ProjectFurnitureCard18`
- `Faq6`
- `SmoothscrollProd6`

## Installation

```bash
# Copy this folder to your project, then install dependencies:
npm install react react-dom framer-motion lenis@1.1.2
```

## Usage

```tsx
import { Button } from './Button';

function App() {
  return <Button />;
}
```

## Responsive Components

For components with responsive variants, use the responsive runtime:

```tsx
// Import the CSS for responsive breakpoints
import './Button/_responsive-runtime.css';

// Option 1: Use the useBreakpoint hook
import { useBreakpoint } from './Button/_responsive-runtime';

function App() {
  const breakpoint = useBreakpoint(); // 'base' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

  return <Button variant={breakpoint === 'base' ? 'mobile' : 'desktop'} />;
}

// Option 2: Use the WithBreakpoints HOC
import { WithBreakpoints } from './Button/_responsive-runtime';

function App() {
  return (
    <WithBreakpoints
      Component={Button}
      variants={{
        base: 'mobile',    // 0px+
        md: 'tablet',      // 768px+
        lg: 'desktop'      // 1024px+
      }}
    />
  );
}
```

### Breakpoints

| Name | Min Width | Typical Use |
|------|-----------|-------------|
| base | 0px | Mobile |
| sm | 390px | Large mobile |
| md | 768px | Tablet |
| lg | 1024px | Laptop |
| xl | 1280px | Desktop |
| 2xl | 1536px | Large desktop |

## Peer Dependencies

These components require the following packages in your project:

- `react` >= 18.0.0
- `react-dom` >= 18.0.0
- `framer-motion` >= 10.0.0

## Note

The Framer runtime is bundled as `_framer-runtime.js` - no external Framer dependency needed.
These exports are self-contained and work out of the box.

## Generated

Created with [Design to AI](https://designtoai.com)
