export interface Projectfurniturecard18Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop - Project card small version" → RG9SNM1q1
   *   "Desktop - Project card" → Enq05tzLz
   *   "Desktop- Furniture card" → Oe7D1_JCq
   *   "Tablet & mobile - Furniture card" → r34zsw11S
   *   "Tablet & Mobile - Project card small version" → acPCMiWfO
   */
  variant?: 'Desktop - Project card small version' | 'Desktop - Project card' | 'Desktop- Furniture card' | 'Tablet & mobile - Furniture card' | 'Tablet & Mobile - Project card small version' | 'Enq05tzLz' | 'RG9SNM1q1' | 'Oe7D1_JCq' | 'r34zsw11S' | 'acPCMiWfO';
  /**
   * Image — pass as `YxFNG7d6H` not `image`.
   */
  YxFNG7d6H?: string;
  /**
   * Title — pass as `LEYCzF3qG` not `title`.
   * @default "Guest House No. 16"
   */
  LEYCzF3qG?: string;
  /**
   * Category — pass as `LrprNhWNv` not `category`.
   * @default "Category"
   */
  LrprNhWNv?: string;
  /**
   * Date — pass as `qi7hnLCuE` not `date`.
   * @default "2025"
   */
  qi7hnLCuE?: string;
  /**
   * Link — pass as `uayW7rO1R` not `link`.
   */
  uayW7rO1R?: string;
  /** Additional properties */
  [key: string]: unknown;
}
