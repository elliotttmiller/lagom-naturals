export interface Pricing3Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "monthly" → ZBSj20PBb
   *   "yearly" → qCd_xcUw7
   */
  variant?: 'monthly' | 'yearly' | 'ZBSj20PBb' | 'qCd_xcUw7';
  /** Additional properties */
  [key: string]: unknown;
}
