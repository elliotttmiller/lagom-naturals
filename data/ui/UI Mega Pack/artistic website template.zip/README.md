# Buttons

Exported from Framer using Design to AI.

## Components

- `Primary`
- `Primary2`
- `Logoslideshow`
- `Logoslideshow2`
- `Logoslideshow3`
- `Badge`
- `Badge2`
- `FeaturesCard`
- `FeaturesCard2`
- `FeaturesCard3`
- `Badge3`
- `HowItWorks`
- `Badge4`
- `Slideshow`
- `UseCases`
- `Badge5`
- `Statcard`
- `Statcard2`
- `Statcard3`
- `Statcard4`
- `Badge6`
- `TestimonialCard`
- `TestimonialCard2`
- `TestimonialCard3`
- `TestimonialCard4`
- `Badge7`
- `Pricing`
- `Badge8`
- `FaqList`
- `Primary3`
- `Primary4`
- `Logoslideshow4`
- `Logoslideshow5`
- `Logoslideshow6`
- `Badge9`
- `Badge10`
- `FeaturesCard4`
- `FeaturesCard5`
- `FeaturesCard6`
- `Badge11`
- `HowItWorks2`
- `Badge12`
- `Slideshow2`
- `UseCases2`
- `Badge13`
- `Statcard5`
- `Statcard6`
- `Statcard7`
- `Statcard8`
- `Badge14`
- `TestimonialCard5`
- `TestimonialCard6`
- `TestimonialCard7`
- `TestimonialCard8`
- `Badge15`
- `Pricing2`
- `Badge16`
- `FaqList2`
- `Primary5`
- `Primary6`
- `Logoslideshow7`
- `Logoslideshow8`
- `Logoslideshow9`
- `Badge17`
- `Badge18`
- `FeaturesCard7`
- `FeaturesCard8`
- `FeaturesCard9`
- `Badge19`
- `HowItWorks3`
- `Badge20`
- `Slideshow3`
- `UseCases3`
- `Badge21`
- `Statcard9`
- `Statcard10`
- `Statcard11`
- `Statcard12`
- `Badge22`
- `TestimonialCard9`
- `TestimonialCard10`
- `TestimonialCard11`
- `TestimonialCard12`
- `Badge23`
- `Pricing3`
- `Badge24`
- `FaqList3`
- `Primary7`
- `Primary8`
- `Logoslideshow10`
- `Logoslideshow11`
- `Logoslideshow12`
- `Badge25`
- `Badge26`
- `Badge27`
- `FeaturesCard10`
- `FeaturesCard11`
- `FeaturesCard12`
- `Badge28`
- `HowItWorks4`
- `Badge29`
- `Slideshow4`
- `UseCases4`
- `Badge30`
- `Statcard13`
- `Statcard14`
- `Statcard15`
- `Statcard16`
- `Badge31`
- `TestimonialCard13`
- `TestimonialCard14`
- `TestimonialCard15`
- `TestimonialCard16`
- `Badge32`
- `Pricing4`
- `Badge33`
- `FaqList4`
- `Primary9`
- `Primary10`
- `Logoslideshow13`
- `Logoslideshow14`
- `Logoslideshow15`
- `Badge34`
- `Badge35`
- `FeaturesCard13`
- `FeaturesCard14`
- `FeaturesCard15`
- `Badge36`
- `HowItWorks5`
- `Badge37`
- `Slideshow5`
- `UseCases5`
- `Badge38`
- `Statcard17`
- `Statcard18`
- `Statcard19`
- `Statcard20`
- `Badge39`
- `TestimonialCard17`
- `TestimonialCard18`
- `TestimonialCard19`
- `TestimonialCard20`
- `Badge40`
- `Pricing5`
- `Badge41`
- `FaqList5`
- `Primary11`
- `Primary12`
- `Logoslideshow16`
- `Logoslideshow17`
- `Logoslideshow18`
- `Badge42`
- `Badge43`
- `FeaturesCard16`
- `FeaturesCard17`
- `FeaturesCard18`
- `Badge44`
- `HowItWorks6`
- `Badge45`
- `Slideshow6`
- `UseCases6`
- `Badge46`
- `Statcard21`
- `Statcard22`
- `Statcard23`
- `Statcard24`
- `Badge47`
- `TestimonialCard21`
- `TestimonialCard22`
- `TestimonialCard23`
- `TestimonialCard24`
- `Badge48`
- `Pricing6`
- `Badge49`
- `FaqList6`

## Installation

```bash
# Copy this folder to your project, then install dependencies:
npm install react react-dom framer-motion @motionone/dom@10.13.1
```

## Usage

```tsx
import { Primary } from './Buttons';

function App() {
  return <Primary />;
}
```

## Responsive Components

For components with responsive variants, use the responsive runtime:

```tsx
// Import the CSS for responsive breakpoints
import './Buttons/_responsive-runtime.css';

// Option 1: Use the useBreakpoint hook
import { useBreakpoint } from './Buttons/_responsive-runtime';

function App() {
  const breakpoint = useBreakpoint(); // 'base' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

  return <Primary variant={breakpoint === 'base' ? 'mobile' : 'desktop'} />;
}

// Option 2: Use the WithBreakpoints HOC
import { WithBreakpoints } from './Buttons/_responsive-runtime';

function App() {
  return (
    <WithBreakpoints
      Component={Primary}
      variants={{
        base: 'mobile',    // 0px+
        md: 'tablet',      // 768px+
        lg: 'desktop'      // 1024px+
      }}
    />
  );
}
```

### Breakpoints

| Name | Min Width | Typical Use |
|------|-----------|-------------|
| base | 0px | Mobile |
| sm | 390px | Large mobile |
| md | 768px | Tablet |
| lg | 1024px | Laptop |
| xl | 1280px | Desktop |
| 2xl | 1536px | Large desktop |

## Peer Dependencies

These components require the following packages in your project:

- `react` >= 18.0.0
- `react-dom` >= 18.0.0
- `framer-motion` >= 10.0.0

## Note

The Framer runtime is bundled as `_framer-runtime.js` - no external Framer dependency needed.
These exports are self-contained and work out of the box.

## Generated

Created with [Design to AI](https://designtoai.com)
