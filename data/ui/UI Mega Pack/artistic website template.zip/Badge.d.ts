export interface BadgeProps {
  /**
   * Badge text — pass as `zFXiwr5HG` not `badgeText`.
   * @default "Text"
   */
  zFXiwr5HG?: string;
  onzFXiwr5HGChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
