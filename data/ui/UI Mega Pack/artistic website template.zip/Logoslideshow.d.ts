export interface LogoslideshowProps {
  /**
   * Mode
   * Options: "images" | "slots"
   * @default "images"
   */
  mode?: 'images' | 'slots';
  /**
   * Logos
   * @default [{"src":"https://framerusercontent.com/images/GfGkADagM4KEibNcIiRUWlfrR0.jpg","alt":"Logo 1"},{"src":"https://framerusercontent.com/images/aNsAT3jCvt4zglbWCUoFe33Q.jpg","alt":"Logo 2"},{"src":"https://framerusercontent.com/images/BYnxEV1zjYb9bhWh1IwBZ1ZoS60.jpg","alt":"Logo 3"}]
   */
  logos?: unknown[];
  /**
   * Frames — pass as `children` not `frames`.
   */
  children?: unknown[];
  /**
   * Interval (s) — pass as `interval` not `interval(s)`.
   * Range: min: 1, max: 10, step: 0.5
   * @default 3
   */
  interval?: number;
  /**
   * Transition (s) — pass as `transitionDuration` not `transition(s)`.
   * Range: min: 0.1, max: 2, step: 0.1
   * @default 0.6
   */
  transitionDuration?: number;
  /**
   * Width — pass as `logoWidth` not `width`.
   * Range: min: 40, max: 300, step: 4
   * @default 120
   */
  logoWidth?: number;
  /**
   * Height — pass as `logoHeight` not `height`.
   * Range: min: 20, max: 120, step: 4
   * @default 40
   */
  logoHeight?: number;
  /** Additional properties */
  [key: string]: unknown;
}
