export interface Statcard4Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Accent" → TitFAm97U
   *   "Default" → Dt4eh50Ap
   */
  variant?: 'Accent' | 'Default' | 'TitFAm97U' | 'Dt4eh50Ap';
  /**
   * Amount — pass as `H0T5ZBDli` not `amount`.
   * @default "Amount"
   */
  H0T5ZBDli?: string;
  onH0T5ZBDliChange?: string;
  /**
   * Text — pass as `JRFRXQFxk` not `text`.
   * @default "Text"
   */
  JRFRXQFxk?: string;
  onJRFRXQFxkChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
