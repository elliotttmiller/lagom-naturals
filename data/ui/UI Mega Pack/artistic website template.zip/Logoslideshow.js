var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/d3WPWn3Xa2v7Qh91SZ1D/jmnu3VXyHecdaaGKBmvS/LogoSlideshow.js
import { jsx as _jsx } from "react/jsx-runtime";
import { useState, useEffect, Children, startTransition } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { addPropertyControls, ControlType, useIsOnFramerCanvas } from "./_framer-runtime.js";
function LogoSlideshow(props) {
  const { mode = "images", logos = [{ src: "https://framerusercontent.com/images/GfGkADagM4KEibNcIiRUWlfrR0.jpg", alt: "Logo 1" }], children, interval = 3, transitionDuration = 0.6, logoWidth = 120, logoHeight = 40 } = props;
  const [currentIndex, setCurrentIndex] = useState(0);
  const isInCanvas = useIsOnFramerCanvas();
  const items = mode === "images" ? logos : Children.toArray(children);
  const itemCount = items.length;
  useEffect(() => {
    if (itemCount === 0 || isInCanvas)
      return;
    const timer = setInterval(() => {
      startTransition(() => {
        setCurrentIndex((prev) => (prev + 1) % itemCount);
      });
    }, interval * 1e3);
    return () => clearInterval(timer);
  }, [interval, itemCount, isInCanvas]);
  if (mode === "slots" && itemCount === 0) {
    return /* @__PURE__ */ _jsx("div", { style: { width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "#999", fontSize: 14, fontFamily: "Inter, sans-serif" }, children: "Connect frames in slots" });
  }
  if (mode === "images" && itemCount === 0) {
    return /* @__PURE__ */ _jsx("div", { style: { width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "#999", fontSize: 14, fontFamily: "Inter, sans-serif" }, children: "Add logo images" });
  }
  return /* @__PURE__ */ _jsx("div", { style: { position: "relative", width: "100%", height: "100%", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }, children: isInCanvas ? (
    // Canvas mode: render first item only, no animation
    mode === "images" ? /* @__PURE__ */ _jsx("img", { src: items[0].src, alt: items[0].alt || "Logo 1", style: { position: "absolute", width: logoWidth, height: logoHeight, objectFit: "contain", opacity: 1 } }) : /* @__PURE__ */ _jsx("div", { style: { position: "absolute", width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", opacity: 1 }, children: items[0] })
  ) : (
    // Preview/published mode: full animation behavior
    /* @__PURE__ */ _jsx(AnimatePresence, { mode: "wait", children: mode === "images" ? /* @__PURE__ */ _jsx(motion.img, { src: items[currentIndex].src, alt: items[currentIndex].alt || `Logo ${currentIndex + 1}`, initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: transitionDuration }, style: { position: "absolute", width: logoWidth, height: logoHeight, objectFit: "contain" } }, currentIndex) : /* @__PURE__ */ _jsx(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: transitionDuration }, style: { position: "absolute", width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center" }, children: items[currentIndex] }, currentIndex) })
  ) });
}
addPropertyControls(LogoSlideshow, { mode: { type: ControlType.Enum, title: "Mode", options: ["images", "slots"], optionTitles: ["Images", "Frames / Components"], defaultValue: "images" }, logos: { type: ControlType.Array, title: "Logos", control: { type: ControlType.ResponsiveImage }, maxCount: 10, defaultValue: [{ src: "https://framerusercontent.com/images/GfGkADagM4KEibNcIiRUWlfrR0.jpg", alt: "Logo 1" }, { src: "https://framerusercontent.com/images/aNsAT3jCvt4zglbWCUoFe33Q.jpg", alt: "Logo 2" }, { src: "https://framerusercontent.com/images/BYnxEV1zjYb9bhWh1IwBZ1ZoS60.jpg", alt: "Logo 3" }], hidden: ({ mode }) => mode === "slots" }, children: { type: ControlType.Array, title: "Frames", control: { type: ControlType.ComponentInstance }, maxCount: 10, hidden: ({ mode }) => mode === "images" }, interval: { type: ControlType.Number, title: "Interval (s)", defaultValue: 3, min: 1, max: 10, step: 0.5, displayStepper: true }, transitionDuration: { type: ControlType.Number, title: "Transition (s)", defaultValue: 0.6, min: 0.1, max: 2, step: 0.1, displayStepper: true }, logoWidth: { type: ControlType.Number, title: "Width", defaultValue: 120, min: 40, max: 300, step: 4, displayStepper: true, hidden: ({ mode }) => mode === "slots" }, logoHeight: { type: ControlType.Number, title: "Height", defaultValue: 40, min: 20, max: 120, step: 4, displayStepper: true, hidden: ({ mode }) => mode === "slots" } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "LogoSlideshow", "slots": ["children"], "annotations": { "framerContractVersion": "1", "framerSupportedLayoutWidth": "fixed", "framerSupportedLayoutHeight": "fixed" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  LogoSlideshow as default
};
