var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/EA6WMgIHS9pC8Op4K0LB/HIAOKbkT0fDVI7FKIEsc/coagbK6a1.js
import { jsx as _jsx3, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls3, ComponentViewportProvider, ControlType as ControlType3, cx as cx3, forwardLoader, getFonts as getFonts2, SmartComponentScopedContainer, useActiveVariantCallback as useActiveVariantCallback2, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS3, withFX as withFX2 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion3, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React3 from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/GJNshOhEY1m7ovfNtawV/qDjAhXXf77D6yXGRFZpD/fGu8I9sFZ.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, getFonts, getFontsFromSharedStyle, RichText, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2, withFX } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/8VFsAOycF4H9jkHuRo2W/u2TXyck5C9PqL2g5ao62/vbTtQKoql.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 0 0 L 14 0" fill="transparent" height="1px" id="For6a1EEX" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(5 12)" width="14px"/><path d="M 0 0 L 0 14" fill="transparent" height="14px" id="TzsgOXd8_" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(12 5)" width="1px"/></svg>';
var getProps = ({ color, height, id, width, width1, ...props }) => {
  return { ...props, JEeZYcamG: width1 ?? props.JEeZYcamG ?? 2, P_DcoRcrY: color ?? props.P_DcoRcrY ?? "rgb(0, 0, 0)" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, P_DcoRcrY, JEeZYcamG, ...restProps } = getProps(props);
  const href = useSVGTemplate("3356954461", svg);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-K11hZ", className3), layoutId, ref, role: "presentation", style: { "--1m973uw": P_DcoRcrY, "--js9iwy": JEeZYcamG, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx("use", { href }) });
});
var css = [`.framer-K11hZ { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-K11hZ");
Icon.displayName = "Plus";
var vbTtQKoql_default = Icon;
addPropertyControls(Icon, { P_DcoRcrY: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType.Color }, JEeZYcamG: { defaultValue: 2, displayStepper: true, hidden: false, max: 16, min: 1, title: "Width", type: ControlType.Number } });

// http-url:https://framerusercontent.com/modules/6KxKZoTg3exQMkMLg7PN/CzVB8fH632Pv4SSzW0KT/b69XIX_OP.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["GF;Geist-500", "GF;Geist-700"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v4/gyBhhwUxId8gMGYQMKR3pzfaWI_RruM4mJPby1QNtA.woff2", weight: "500" }, { cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v4/gyBhhwUxId8gMGYQMKR3pzfaWI_Re-Q4mJPby1QNtA.woff2", weight: "700" }] }];
var css2 = ['.framer-qF2SU .framer-styles-preset-1b2oqe0:not(.rich-text-wrapper), .framer-qF2SU .framer-styles-preset-1b2oqe0.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 20px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-2c50f5be-01b1-4e9a-bdbd-a86173538af0, #f0efe9); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; }', '@media (max-width: 1199px) and (min-width: 810px) { .framer-qF2SU .framer-styles-preset-1b2oqe0:not(.rich-text-wrapper), .framer-qF2SU .framer-styles-preset-1b2oqe0.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-2c50f5be-01b1-4e9a-bdbd-a86173538af0, #f0efe9); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; } }', '@media (max-width: 809px) and (min-width: 0px) { .framer-qF2SU .framer-styles-preset-1b2oqe0:not(.rich-text-wrapper), .framer-qF2SU .framer-styles-preset-1b2oqe0.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-2c50f5be-01b1-4e9a-bdbd-a86173538af0, #f0efe9); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; } }'];
var className = "framer-qF2SU";

// http-url:https://framerusercontent.com/modules/eLcNcS2sfDLnGit2bmLd/xFKjpmdavFXciHrYLCwG/fbfr1rN1Z.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["GF;Geist-regular", "GF;Geist-700"]);
var fonts2 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v4/gyBhhwUxId8gMGYQMKR3pzfaWI_RnOM4mJPby1QNtA.woff2", weight: "400" }, { cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v4/gyBhhwUxId8gMGYQMKR3pzfaWI_Re-Q4mJPby1QNtA.woff2", weight: "700" }] }];
var css3 = ['.framer-PDeFw .framer-styles-preset-1v58k6b:not(.rich-text-wrapper), .framer-PDeFw .framer-styles-preset-1v58k6b.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 16px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-e49112b3-ec71-4a13-943b-6d29a56126bf, #333333); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; }', '@media (max-width: 1199px) and (min-width: 810px) { .framer-PDeFw .framer-styles-preset-1v58k6b:not(.rich-text-wrapper), .framer-PDeFw .framer-styles-preset-1v58k6b.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 13px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-e49112b3-ec71-4a13-943b-6d29a56126bf, #333333); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; } }', '@media (max-width: 809px) and (min-width: 0px) { .framer-PDeFw .framer-styles-preset-1v58k6b:not(.rich-text-wrapper), .framer-PDeFw .framer-styles-preset-1v58k6b.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 14px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-e49112b3-ec71-4a13-943b-6d29a56126bf, #333333); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; } }'];
var className2 = "framer-PDeFw";

// http-url:https://framerusercontent.com/modules/GJNshOhEY1m7ovfNtawV/qDjAhXXf77D6yXGRFZpD/fGu8I9sFZ.js
var PlusFonts = getFonts(vbTtQKoql_default);
var RichTextWithFX = withFX(RichText);
var cycleOrder = ["D3_VNZOgJ", "O2F76U4sA"];
var serializationHash = "framer-uz1fC";
var variantClassNames = { D3_VNZOgJ: "framer-v-md4k4v", O2F76U4sA: "framer-v-w0069s" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { damping: 35, delay: 0, mass: 1, stiffness: 500, type: "spring" };
var animation = { opacity: 0, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 24 };
var transition2 = { delay: 0, duration: 0.8, ease: [0.12, 0.23, 0.27, 1], type: "tween" };
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Close: "D3_VNZOgJ", Open: "O2F76U4sA" };
var Variants = motion2.create(React2.Fragment);
var getProps2 = ({ click, description, height, id, title, width, ...props }) => {
  return { ...props, Ib4EbqAWT: description ?? props.Ib4EbqAWT ?? "Bullets, commits or stream-of-consciousness \u2014 drop it in and Plume takes it from there.", O_cY5kNE0: title ?? props.O_cY5kNE0 ?? "01 \u2014 Paste your raw notes", s4TEqw8_N: click ?? props.s4TEqw8_N, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "D3_VNZOgJ" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className3, layoutId, variant, O_cY5kNE0, Ib4EbqAWT, s4TEqw8_N, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "D3_VNZOgJ", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTapgzn7bs = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    if (s4TEqw8_N) {
      const res = await s4TEqw8_N(...args);
      if (res === false)
        return false;
    }
  });
  const sharedStyleClassNames = [className, className2];
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "O2F76U4sA")
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion2.div, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-md4k4v", className3, classNames), "data-framer-name": "Close", "data-highlight": true, layoutDependency, layoutId: "HowItWorksSection__D3_VNZOgJ", onTap: onTapgzn7bs, ref: refBinding, style: { backgroundColor: "var(--token-bc0ebf3c-6044-41fd-9464-bb3c4c3d49b0, rgb(253, 251, 247))", borderBottomLeftRadius: 4, borderBottomRightRadius: 4, borderTopLeftRadius: 4, borderTopRightRadius: 4, ...style }, ...addPropertyOverrides({ O2F76U4sA: { "data-framer-name": "Open" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs(motion2.div, { className: "framer-1sfodqc", layoutDependency, layoutId: "HowItWorksSection__Ijdyv_R4W", children: [/* @__PURE__ */ _jsx2(motion2.div, { className: "framer-1l3izjt", layoutDependency, layoutId: "HowItWorksSection__vJmZxw4_Y", style: { backgroundColor: "var(--token-eca8c72d-732b-4686-ae8a-22be831f2697, rgb(255, 107, 53))", borderBottomLeftRadius: 4, borderBottomRightRadius: 4, borderTopLeftRadius: 4, borderTopRightRadius: 4 }, children: /* @__PURE__ */ _jsx2(vbTtQKoql_default, { animated: true, className: "framer-2ff9lk", layoutDependency, layoutId: "HowItWorksSection__Jxns1vv1F", style: { "--1m973uw": "var(--token-b38779af-7bf4-4a0e-a2df-0af9e2ec9674, rgb(245, 245, 245))", "--js9iwy": 2, rotate: 0 }, variants: { O2F76U4sA: { rotate: 45 } } }) }), /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { className: "framer-styles-preset-1b2oqe0", "data-styles-preset": "b69XIX_OP", dir: "auto", children: "01 \u2014 Paste your raw notes" }) }), className: "framer-1zzaw8", fonts: ["Inter"], layoutDependency, layoutId: "HowItWorksSection__cFXTs8bv7", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: O_cY5kNE0, verticalAlignment: "top", withExternalLayout: true })] }), isDisplayed() && /* @__PURE__ */ _jsx2(RichTextWithFX, { __framer__animate: { transition: transition2 }, __framer__animateOnce: true, __framer__enter: animation, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0, __fromCanvasComponent: true, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { className: "framer-styles-preset-1v58k6b", "data-styles-preset": "fbfr1rN1Z", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-e49112b3-ec71-4a13-943b-6d29a56126bf, rgb(92, 92, 92)))" }, children: "Bullets, commits or stream-of-consciousness \u2014 drop it in and Plume takes it from there." }) }), className: "framer-ldoqnf", fonts: ["Inter"], layoutDependency, layoutId: "HowItWorksSection__Lrw_oqa7f", style: { "--extracted-r6o4lv": "var(--token-e49112b3-ec71-4a13-943b-6d29a56126bf, rgb(92, 92, 92))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: Ib4EbqAWT, verticalAlignment: "top", withExternalLayout: true })] }) }) }) });
});
var css4 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-uz1fC.framer-12msfbp, .framer-uz1fC .framer-12msfbp { display: block; }", ".framer-uz1fC.framer-md4k4v { align-content: flex-start; align-items: flex-start; cursor: pointer; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 24px; height: min-content; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 24px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-uz1fC .framer-1sfodqc { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-uz1fC .framer-1l3izjt { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 4px; position: relative; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-uz1fC .framer-2ff9lk { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 24px); position: relative; width: 24px; }", ".framer-uz1fC .framer-1zzaw8 { flex: 1 0 0px; height: auto; position: relative; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; }", ".framer-uz1fC .framer-ldoqnf { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ...css2, ...css3];
var FramerfGu8I9sFZ = withCSS2(Component2, css4, "framer-uz1fC");
var fGu8I9sFZ_default = FramerfGu8I9sFZ;
FramerfGu8I9sFZ.displayName = "HowItWorks Card";
FramerfGu8I9sFZ.defaultProps = { height: 80, width: 544 };
addPropertyControls2(FramerfGu8I9sFZ, { variant: { options: ["D3_VNZOgJ", "O2F76U4sA"], optionTitles: ["Close", "Open"], title: "Variant", type: ControlType2.Enum }, O_cY5kNE0: { defaultValue: "01 \u2014 Paste your raw notes", displayTextArea: false, title: "Title", type: ControlType2.String }, onO_cY5kNE0Change: { changes: "O_cY5kNE0", type: ControlType2.ChangeHandler }, Ib4EbqAWT: { defaultValue: "Bullets, commits or stream-of-consciousness \u2014 drop it in and Plume takes it from there.", displayTextArea: false, title: "Description", type: ControlType2.String }, onIb4EbqAWTChange: { changes: "Ib4EbqAWT", type: ControlType2.ChangeHandler }, s4TEqw8_N: { title: "Click", type: ControlType2.EventHandler } });
addFonts(FramerfGu8I9sFZ, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...PlusFonts, ...getFontsFromSharedStyle(fonts), ...getFontsFromSharedStyle(fonts2)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/EA6WMgIHS9pC8Op4K0LB/HIAOKbkT0fDVI7FKIEsc/coagbK6a1.js
var HowItWorksCardFonts = getFonts2(fGu8I9sFZ_default);
var SmartComponentScopedContainerWithFX = withFX2(SmartComponentScopedContainer);
var cycleOrder2 = ["jtCn78V0a", "Jma_Hfwf5", "hTu3mtmIg"];
var serializationHash2 = "framer-wEd8N";
var variantClassNames2 = { hTu3mtmIg: "framer-v-1jlrprb", Jma_Hfwf5: "framer-v-p1sfhv", jtCn78V0a: "framer-v-1v5obrq" };
function addPropertyOverrides2(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition12 = { bounce: 0.2, delay: 0, duration: 0.5, type: "spring" };
var animation2 = { opacity: 0, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 40 };
var transition22 = { delay: 0, duration: 0.8, ease: [0.12, 0.23, 0.27, 1], type: "tween" };
var matchVariant = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var Transition2 = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext2.Provider, { value: contextValue, children });
};
var humanReadableVariantMap2 = { "1": "jtCn78V0a", "2": "Jma_Hfwf5", "3": "hTu3mtmIg" };
var Variants2 = motion3.create(React3.Fragment);
var useStateVariable = (externalState, setExternalState) => {
  const [internalState, setInternalState] = React3.useState(externalState);
  const [previousExternalState, setPreviousExternalState] = React3.useState(externalState);
  if (setExternalState) {
    return [externalState, setExternalState];
  }
  if (externalState !== previousExternalState) {
    setInternalState(externalState);
    setPreviousExternalState(externalState);
  }
  return [internalState, setInternalState];
};
var getProps3 = ({ description1, description2, description3, height, id, title1, title2, title3, width, ...props }) => {
  return { ...props, fhAXGEWUs: description3 ?? props.fhAXGEWUs ?? "Description 3", GYNpinwL0: title1 ?? props.GYNpinwL0 ?? "Title 1", I41PK0snF: title3 ?? props.I41PK0snF ?? "Title 3", KKICTvpuZ: description1 ?? props.KKICTvpuZ ?? "Description 1", NDZWhKLxq: title2 ?? props.NDZWhKLxq ?? "Title 2", variant: humanReadableVariantMap2[props.variant] ?? props.variant ?? "jtCn78V0a", yG_2DEovx: description2 ?? props.yG_2DEovx ?? "Description 2" };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className: className3, layoutId, variant, "GYNpinwL0": externalGYNpinwL0, "onGYNpinwL0Change": setExternalGYNpinwL0, "KKICTvpuZ": externalKKICTvpuZ, "onKKICTvpuZChange": setExternalKKICTvpuZ, "NDZWhKLxq": externalNDZWhKLxq, "onNDZWhKLxqChange": setExternalNDZWhKLxq, "yG_2DEovx": externalyG_2DEovx, "onyG_2DEovxChange": setExternalyG_2DEovx, "I41PK0snF": externalI41PK0snF, "onI41PK0snFChange": setExternalI41PK0snF, "fhAXGEWUs": externalfhAXGEWUs, "onfhAXGEWUsChange": setExternalfhAXGEWUs, ...restProps } = getProps3(props);
  const [GYNpinwL0, setGYNpinwL0] = useStateVariable(externalGYNpinwL0, setExternalGYNpinwL0);
  const [KKICTvpuZ, setKKICTvpuZ] = useStateVariable(externalKKICTvpuZ, setExternalKKICTvpuZ);
  const [NDZWhKLxq, setNDZWhKLxq] = useStateVariable(externalNDZWhKLxq, setExternalNDZWhKLxq);
  const [yG_2DEovx, setyG_2DEovx] = useStateVariable(externalyG_2DEovx, setExternalyG_2DEovx);
  const [I41PK0snF, setI41PK0snF] = useStateVariable(externalI41PK0snF, setExternalI41PK0snF);
  const [fhAXGEWUs, setfhAXGEWUs] = useStateVariable(externalfhAXGEWUs, setExternalfhAXGEWUs);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder: cycleOrder2, defaultVariant: "jtCn78V0a", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback2(baseVariant);
  const s4TEqw8_N1i5tybg = activeVariantCallback(async (...args) => {
    setVariant("jtCn78V0a");
  });
  const s4TEqw8_Nc2f0mq = activeVariantCallback(async (...args) => {
    setVariant("Jma_Hfwf5");
  });
  const s4TEqw8_Nroy4da = activeVariantCallback(async (...args) => {
    setVariant("hTu3mtmIg");
  });
  const sharedStyleClassNames = [];
  const scopingClassNames = cx3(serializationHash2, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx3(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition2, { value: transition12, children: /* @__PURE__ */ _jsxs2(motion3.div, { ...restProps, ...gestureHandlers, className: cx3(scopingClassNames, "framer-1v5obrq", className3, classNames), "data-framer-name": "1", layoutDependency, layoutId: "HowItWorksSection__jtCn78V0a", ref: refBinding, style: { ...style }, ...addPropertyOverrides2({ hTu3mtmIg: { "data-framer-name": "3" }, Jma_Hfwf5: { "data-framer-name": "2" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 80, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 299) - 0 - 256) / 2 + 0 + 0), children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainerWithFX, { __framer__animate: { transition: transition22 }, __framer__animateOnce: true, __framer__enter: animation2, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: "framer-1yt3r0o-container", layoutDependency, layoutId: "HowItWorksSection__f6_o6DbGm-container", nodeId: "f6_o6DbGm", rendersWithMotion: true, scopeId: "coagbK6a1", children: /* @__PURE__ */ _jsx3(fGu8I9sFZ_default, { height: "100%", Ib4EbqAWT: KKICTvpuZ, id: "f6_o6DbGm", layoutId: "HowItWorksSection__f6_o6DbGm", O_cY5kNE0: GYNpinwL0, onIb4EbqAWTChange: setKKICTvpuZ, onO_cY5kNE0Change: setGYNpinwL0, s4TEqw8_N: s4TEqw8_N1i5tybg, style: { width: "100%" }, variant: matchVariant("O2F76U4sA"), width: "100%", ...addPropertyOverrides2({ hTu3mtmIg: { variant: matchVariant("D3_VNZOgJ") }, Jma_Hfwf5: { variant: matchVariant("D3_VNZOgJ") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 80, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 299) - 0 - 256) / 2 + 80 + 8), children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainerWithFX, { __framer__animate: { transition: transition22 }, __framer__animateOnce: true, __framer__enter: animation2, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: "framer-tbdf5u-container", layoutDependency, layoutId: "HowItWorksSection__Smrug2CWd-container", nodeId: "Smrug2CWd", rendersWithMotion: true, scopeId: "coagbK6a1", children: /* @__PURE__ */ _jsx3(fGu8I9sFZ_default, { height: "100%", Ib4EbqAWT: yG_2DEovx, id: "Smrug2CWd", layoutId: "HowItWorksSection__Smrug2CWd", O_cY5kNE0: NDZWhKLxq, onIb4EbqAWTChange: setyG_2DEovx, onO_cY5kNE0Change: setNDZWhKLxq, s4TEqw8_N: s4TEqw8_Nc2f0mq, style: { width: "100%" }, variant: matchVariant("D3_VNZOgJ"), width: "100%", ...addPropertyOverrides2({ Jma_Hfwf5: { variant: matchVariant("O2F76U4sA") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 80, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 299) - 0 - 256) / 2 + 160 + 16), children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainerWithFX, { __framer__animate: { transition: transition22 }, __framer__animateOnce: true, __framer__enter: animation2, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: "framer-7a0kmo-container", layoutDependency, layoutId: "HowItWorksSection__myOjjhWcQ-container", nodeId: "myOjjhWcQ", rendersWithMotion: true, scopeId: "coagbK6a1", children: /* @__PURE__ */ _jsx3(fGu8I9sFZ_default, { height: "100%", Ib4EbqAWT: fhAXGEWUs, id: "myOjjhWcQ", layoutId: "HowItWorksSection__myOjjhWcQ", O_cY5kNE0: I41PK0snF, onIb4EbqAWTChange: setfhAXGEWUs, onO_cY5kNE0Change: setI41PK0snF, s4TEqw8_N: s4TEqw8_Nroy4da, style: { width: "100%" }, variant: matchVariant("D3_VNZOgJ"), width: "100%", ...addPropertyOverrides2({ hTu3mtmIg: { variant: matchVariant("O2F76U4sA") } }, baseVariant, gestureVariant) }) }) })] }) }) }) });
});
var css5 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-wEd8N.framer-1bg40o, .framer-wEd8N .framer-1bg40o { display: block; }", ".framer-wEd8N.framer-1v5obrq { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-wEd8N .framer-1yt3r0o-container, .framer-wEd8N .framer-tbdf5u-container, .framer-wEd8N .framer-7a0kmo-container { flex: none; height: auto; position: relative; width: 100%; }"];
var FramercoagbK6a1 = withCSS3(Component3, css5, "framer-wEd8N");
var coagbK6a1_default = FramercoagbK6a1;
FramercoagbK6a1.displayName = "How It Works Section";
FramercoagbK6a1.defaultProps = { height: 299, width: 544 };
addPropertyControls3(FramercoagbK6a1, { variant: { options: ["jtCn78V0a", "Jma_Hfwf5", "hTu3mtmIg"], optionTitles: ["1", "2", "3"], title: "Variant", type: ControlType3.Enum }, GYNpinwL0: { defaultValue: "Title 1", displayTextArea: false, title: "Title 1", type: ControlType3.String }, onGYNpinwL0Change: { changes: "GYNpinwL0", type: ControlType3.ChangeHandler }, KKICTvpuZ: { defaultValue: "Description 1", displayTextArea: false, title: "Description 1", type: ControlType3.String }, onKKICTvpuZChange: { changes: "KKICTvpuZ", type: ControlType3.ChangeHandler }, NDZWhKLxq: { defaultValue: "Title 2", displayTextArea: false, title: "Title 2", type: ControlType3.String }, onNDZWhKLxqChange: { changes: "NDZWhKLxq", type: ControlType3.ChangeHandler }, yG_2DEovx: { defaultValue: "Description 2", displayTextArea: false, title: "Description 2", type: ControlType3.String }, onyG_2DEovxChange: { changes: "yG_2DEovx", type: ControlType3.ChangeHandler }, I41PK0snF: { defaultValue: "Title 3", displayTextArea: false, title: "Title 3", type: ControlType3.String }, onI41PK0snFChange: { changes: "I41PK0snF", type: ControlType3.ChangeHandler }, fhAXGEWUs: { defaultValue: "Description 3", displayTextArea: false, title: "Description 3", type: ControlType3.String }, onfhAXGEWUsChange: { changes: "fhAXGEWUs", type: ControlType3.ChangeHandler } });
addFonts2(FramercoagbK6a1, [{ explicitInter: true, fonts: [] }, ...HowItWorksCardFonts], { supportsExplicitInterCodegen: true });
FramercoagbK6a1.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader(fGu8I9sFZ_default, {}, context)]);
} };
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramercoagbK6a1", "slots": [], "annotations": { "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"Jma_Hfwf5":{"layout":["fixed","auto"]},"hTu3mtmIg":{"layout":["fixed","auto"]}}}', "framerComponentViewportWidth": "true", "framerColorSyntax": "true", "framerDisplayContentsDiv": "false", "framerIntrinsicWidth": "544", "framerAutoSizeImages": "true", "framerVariables": '{"GYNpinwL0":"title1","KKICTvpuZ":"description1","NDZWhKLxq":"title2","yG_2DEovx":"description2","I41PK0snF":"title3","fhAXGEWUs":"description3"}', "framerImmutableVariables": "true", "framerContractVersion": "1", "framerIntrinsicHeight": "299" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  coagbK6a1_default as default
};
