export interface Featurescard17Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default" → UNYYlwUc6
   *   "Invert" → MnPepgb4S
   *   "Phone" → qJQPxS4N2
   */
  variant?: 'Default' | 'Invert' | 'Phone' | 'UNYYlwUc6' | 'MnPepgb4S' | 'qJQPxS4N2';
  /**
   * Title — pass as `PEdtUzsiL` not `title`.
   * @default "Your writing command center"
   */
  PEdtUzsiL?: string;
  onPEdtUzsiLChange?: string;
  /**
   * Description — pass as `Lm5QV3O72` not `description`.
   * @default "See everything at a glance — documents created, words generated, and time saved this month. Your workspace, always ready."
   */
  Lm5QV3O72?: string;
  onLm5QV3O72Change?: string;
  /**
   * Button Name — pass as `CX2VCDGhv` not `buttonName`.
   * @default "Start for free"
   */
  CX2VCDGhv?: string;
  onCX2VCDGhvChange?: string;
  onyh3Wd_ej5Change?: string;
  /**
   * Image — pass as `AlyM9O2u_` not `image`.
   */
  AlyM9O2u_?: string;
  /**
   * Image bg — pass as `sfUmoDqba` not `imageBg`.
   */
  sfUmoDqba?: string;
  /**
   * Link — pass as `hVcBugFoq` not `link`.
   */
  hVcBugFoq?: string;
  /**
   * Click — pass as `ti6knPBet` not `click`.
   */
  ti6knPBet?: () => void;
  /** Additional properties */
  [key: string]: unknown;
}
