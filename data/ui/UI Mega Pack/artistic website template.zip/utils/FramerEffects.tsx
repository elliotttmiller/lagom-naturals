/**
 * FramerEffects — auto-populated by the exporter
 *
 * The bundled Framer runtime's withFX HOC does NOT execute the
 * `__framer__*` animation props it receives. This file
 * reimplements those animations via WAAPI so the rendered
 * components actually animate.
 *
 *
 * Pre-populated targets:
 *
 * REVEALS (15):
 *   - .framer-styles-preset-msdwdk (600ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-styles-preset-1v58k6b (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-1xui32u-container (1500ms cubic-bezier(0.12, 0.23, 0.17, 0.99))
 *   - .framer-1yt3r0o-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-tbdf5u-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-7a0kmo-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-1beafgj (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-1v7l16z-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-ppm692-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-aln2yz-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-1tc595d-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-1wr9wmh-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-17zfqkw-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-122ksx3-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *   - .framer-qwoeuo-container (800ms cubic-bezier(0.12, 0.23, 0.27, 1))
 *
 * NOTE: 24 effect targets were detected but not auto-populated below.
 * You'll need to populate them manually following the discovery loop:
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-1wcw0mq (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-1wcw0mq (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-1wcw0mq (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-1wcw0mq (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-1wcw0mq (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-uetdfa (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)
 *   - .framer-1wcw0mq (__framer__styleAppearEffectEnabled): transition is a spring — pre-sampling not auto-extracted (see Discovery Loop)

 * Mount this component once at the page root.
 */
"use client";
import { useEffect } from "react";

interface RevealSpec {
  selector: string;
  keyframes: Keyframe[];
  duration: number;
  easing?: string;
  threshold?: number;
  once?: boolean;
}

interface LoopSpec {
  selector: string;
  keyframes: Keyframe[];
  duration: number;
  easing?: string;
  pauseOffscreen?: boolean;
}

const REVEAL_SPECS: RevealSpec[] = [
  {
    "selector": ".framer-styles-preset-msdwdk",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(24px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 600,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-styles-preset-1v58k6b",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(24px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-1xui32u-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(24px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 1500,
    "easing": "cubic-bezier(0.12, 0.23, 0.17, 0.99)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-1yt3r0o-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-tbdf5u-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-7a0kmo-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-1beafgj",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-1v7l16z-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-ppm692-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-aln2yz-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-1tc595d-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-1wr9wmh-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-17zfqkw-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-122ksx3-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  },
  {
    "selector": ".framer-qwoeuo-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(40px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.12, 0.23, 0.27, 1)",
    "threshold": 0.5,
    "once": true
  }
];

const LOOP_SPECS: LoopSpec[] = [];

export default function FramerEffects() {
  useEffect(() => {
    const cleanups: Array<() => void> = [];
    const fired = new Set<Element>();

    for (const spec of REVEAL_SPECS) {
      const targets = document.querySelectorAll<HTMLElement>(spec.selector);
      if (targets.length === 0) continue;
      targets.forEach((el) => {
        const initial = el.animate(spec.keyframes.slice(0, 1) as Keyframe[], { duration: 1, fill: "forwards" });
        initial.pause();
      });
      const io = new IntersectionObserver((entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          if (spec.once !== false && fired.has(e.target)) continue;
          (e.target as HTMLElement).animate(spec.keyframes, {
            duration: spec.duration,
            easing: spec.easing,
            fill: "forwards",
          });
          if (spec.once !== false) fired.add(e.target);
        }
      }, { threshold: spec.threshold ?? 0, rootMargin: "0px" });
      targets.forEach((el) => io.observe(el));
      cleanups.push(() => io.disconnect());
    }

    for (const spec of LOOP_SPECS) {
      const targets = document.querySelectorAll<HTMLElement>(spec.selector);
      const anims: Animation[] = [];
      targets.forEach((el) => {
        const anim = el.animate(spec.keyframes, {
          duration: spec.duration,
          easing: spec.easing,
          iterations: Infinity,
        });
        anims.push(anim);
      });
      if (spec.pauseOffscreen) {
        const io = new IntersectionObserver((entries) => {
          for (const e of entries) {
            const i = Array.from(targets).indexOf(e.target as HTMLElement);
            if (i < 0) continue;
            if (e.isIntersecting) anims[i]?.play();
            else anims[i]?.pause();
          }
        }, { threshold: 0 });
        targets.forEach((el) => io.observe(el));
        cleanups.push(() => io.disconnect());
      }
      cleanups.push(() => anims.forEach((a) => a.cancel()));
    }

    return () => cleanups.forEach((fn) => fn());
  }, []);

  return null;
}
