export interface Primary10Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Btn dark" → S9TUG7vSA
   *   "Btn ghost dark" → jm5F_02Fs
   *   "Btn ghost light" → yFBapcXac
   *   "Btn light" → mjxko43KH
   *   "Btn orange" → lw0OAF2kl
   *   "Phone" → E8Q5Fs0zX
   */
  variant?: 'Btn dark' | 'Btn ghost dark' | 'Btn ghost light' | 'Btn light' | 'Btn orange' | 'Phone' | 'S9TUG7vSA' | 'mjxko43KH' | 'lw0OAF2kl' | 'jm5F_02Fs' | 'yFBapcXac' | 'E8Q5Fs0zX';
  /**
   * Button Name — pass as `NAPk0wdPj` not `buttonName`.
   * @default "Button"
   */
  NAPk0wdPj?: string;
  onNAPk0wdPjChange?: string;
  /**
   * Link — pass as `G8RmeHeUC` not `link`.
   */
  G8RmeHeUC?: string;
  /**
   * Row visible — pass as `dPU43baEi` not `rowVisible`.
   * @default true
   */
  dPU43baEi?: boolean;
  ondPU43baEiChange?: string;
  /**
   * New Tab — pass as `xH4CF0e5x` not `newTab`.
   * @default false
   */
  xH4CF0e5x?: boolean;
  onxH4CF0e5xChange?: string;
  /**
   * Smooth Scroll — pass as `yfRCkAL7G` not `smoothScroll`.
   * @default false
   */
  yfRCkAL7G?: boolean;
  onyfRCkAL7GChange?: string;
  /**
   * Click — pass as `pZTwUTKug` not `click`.
   */
  pZTwUTKug?: () => void;
  /** Additional properties */
  [key: string]: unknown;
}
