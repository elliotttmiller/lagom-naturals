export interface Howitworks5Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "1" → jtCn78V0a
   *   "2" → Jma_Hfwf5
   *   "3" → hTu3mtmIg
   */
  variant?: '1' | '2' | '3' | 'jtCn78V0a' | 'Jma_Hfwf5' | 'hTu3mtmIg';
  /**
   * Title 1 — pass as `GYNpinwL0` not `title1`.
   * @default "Title 1"
   */
  GYNpinwL0?: string;
  onGYNpinwL0Change?: string;
  /**
   * Description 1 — pass as `KKICTvpuZ` not `description1`.
   * @default "Description 1"
   */
  KKICTvpuZ?: string;
  onKKICTvpuZChange?: string;
  /**
   * Title 2 — pass as `NDZWhKLxq` not `title2`.
   * @default "Title 2"
   */
  NDZWhKLxq?: string;
  onNDZWhKLxqChange?: string;
  /**
   * Description 2 — pass as `yG_2DEovx` not `description2`.
   * @default "Description 2"
   */
  yG_2DEovx?: string;
  onyG_2DEovxChange?: string;
  /**
   * Title 3 — pass as `I41PK0snF` not `title3`.
   * @default "Title 3"
   */
  I41PK0snF?: string;
  onI41PK0snFChange?: string;
  /**
   * Description 3 — pass as `fhAXGEWUs` not `description3`.
   * @default "Description 3"
   */
  fhAXGEWUs?: string;
  onfhAXGEWUsChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
