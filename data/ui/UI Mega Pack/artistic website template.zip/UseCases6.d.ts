export interface Usecases6Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "1" → X1mGM6PSJ
   *   "2" → onRaj_gNi
   *   "3" → Ck_52XJ4I
   *   "[INTERNAL EDIT HERE]" → KYV0uOkZy
   */
  variant?: '1' | '2' | '3' | '[INTERNAL EDIT HERE]' | 'KYV0uOkZy' | 'X1mGM6PSJ' | 'onRaj_gNi' | 'Ck_52XJ4I';
  /**
   * Padding — pass as `PUR7ysENa` not `padding`.
   * @default "120px"
   */
  PUR7ysENa?: string;
  /** Additional properties */
  [key: string]: unknown;
}
