export interface Faqlist5Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → TogEJtXpN
   *   "Phone" → ypKxHTExb
   */
  variant?: 'Desktop' | 'Phone' | 'TogEJtXpN' | 'ypKxHTExb';
  /**
   * Question 1 — pass as `kOMDiODUf` not `question1`.
   * @default "Question 1"
   */
  kOMDiODUf?: string;
  onkOMDiODUfChange?: string;
  /**
   * Answer 1 — pass as `dhblmLlur` not `answer1`.
   * @default "Answer 1"
   */
  dhblmLlur?: string;
  ondhblmLlurChange?: string;
  /**
   * Question 2 — pass as `DWJQePX3E` not `question2`.
   * @default "Question 2"
   */
  DWJQePX3E?: string;
  onDWJQePX3EChange?: string;
  /**
   * Answer 2 — pass as `H6qU7fYtt` not `answer2`.
   * @default "Answer 2"
   */
  H6qU7fYtt?: string;
  onH6qU7fYttChange?: string;
  /**
   * Question 3 — pass as `hegL9MeA9` not `question3`.
   * @default "Question 3"
   */
  hegL9MeA9?: string;
  onhegL9MeA9Change?: string;
  /**
   * Answer 3 — pass as `FS4HlPcm4` not `answer3`.
   * @default "Answer 3"
   */
  FS4HlPcm4?: string;
  onFS4HlPcm4Change?: string;
  /**
   * Question 4 — pass as `pLHEZynxn` not `question4`.
   * @default "Question 4"
   */
  pLHEZynxn?: string;
  onpLHEZynxnChange?: string;
  /**
   * Answer 4 — pass as `Le9r5ZM2m` not `answer4`.
   * @default "Answer 4"
   */
  Le9r5ZM2m?: string;
  onLe9r5ZM2mChange?: string;
  /**
   * Question 5 — pass as `Vj1r1aGUC` not `question5`.
   * @default "Question 5"
   */
  Vj1r1aGUC?: string;
  onVj1r1aGUCChange?: string;
  /**
   * Answer 5 — pass as `L0CmBmNSc` not `answer5`.
   * @default "Answer 5"
   */
  L0CmBmNSc?: string;
  onL0CmBmNScChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
