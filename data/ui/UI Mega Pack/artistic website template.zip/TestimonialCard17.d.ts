export interface Testimonialcard17Props {
  /**
   * Text — pass as `Nln38V6vu` not `text`.
   * @default "Text"
   */
  Nln38V6vu?: string;
  onNln38V6vuChange?: string;
  /**
   * Name — pass as `V9A0FyxKW` not `name`.
   * @default "Name"
   */
  V9A0FyxKW?: string;
  onV9A0FyxKWChange?: string;
  /**
   * Role — pass as `u0JIEigio` not `role`.
   * @default "Role"
   */
  u0JIEigio?: string;
  onu0JIEigioChange?: string;
  /**
   * Image — pass as `kJz5XX980` not `image`.
   */
  kJz5XX980?: string;
  /** Additional properties */
  [key: string]: unknown;
}
