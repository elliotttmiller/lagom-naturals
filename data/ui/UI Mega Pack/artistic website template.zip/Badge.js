var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/rTly7XsaZDUm4fQCMvH1/Cqjgoy4GiCqtEuXSdOSz/weB4IXCj6.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls, ControlType, cx, getFontsFromSharedStyle, RichText, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/gJERsjnZ496Luxi7F2rI/jPndjnD3y7u0CqNSIm3r/Kh_cD8ZcR.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["GF;Space Mono-700", "GF;Space Mono-700italic"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Space Mono", source: "google", style: "normal", uiFamilyName: "Space Mono", url: "https://fonts.gstatic.com/s/spacemono/v17/i7dMIFZifjKcF5UAWdDRaPpZYFeQHwyVd3U.woff2", weight: "700" }, { cssFamilyName: "Space Mono", source: "google", style: "italic", uiFamilyName: "Space Mono", url: "https://fonts.gstatic.com/s/spacemono/v17/i7dSIFZifjKcF5UAWdDRYERE_FeaHi6QZ3WfYg.woff2", weight: "700" }] }];
var css = ['.framer-txfh0 .framer-styles-preset-1who00q:not(.rich-text-wrapper), .framer-txfh0 .framer-styles-preset-1who00q.rich-text-wrapper p { --framer-font-family: "Space Mono", monospace; --framer-font-family-italic: "Space Mono", monospace; --framer-font-open-type-features: normal; --framer-font-size: 12px; --framer-font-style: normal; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 700; --framer-font-weight-italic: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-2c50f5be-01b1-4e9a-bdbd-a86173538af0, #0d0d0d); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className = "framer-txfh0";

// http-url:https://framerusercontent.com/modules/rTly7XsaZDUm4fQCMvH1/Cqjgoy4GiCqtEuXSdOSz/weB4IXCj6.js
var serializationHash = "framer-c3BrQ";
var variantClassNames = { gWbzQCyfO: "framer-v-y7k631" };
var transition1 = { delay: 0, duration: 1.4, ease: [0.12, 0.23, 0.17, 0.99], type: "tween" };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion.create(React.Fragment);
var getProps = ({ badgeText, height, id, width, ...props }) => {
  return { ...props, zFXiwr5HG: badgeText ?? props.zFXiwr5HG ?? "Text" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className2, layoutId, variant, zFXiwr5HG, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "gWbzQCyfO", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [className];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-y7k631", className2, classNames), "data-framer-name": "Idle", layoutDependency, layoutId: "Badge__gWbzQCyfO", ref: refBinding, style: { ...style }, children: [/* @__PURE__ */ _jsx(motion.div, { className: "framer-19d9p1c", layoutDependency, layoutId: "Badge__b7Aio10MT", style: { backgroundColor: "var(--token-eca8c72d-732b-4686-ae8a-22be831f2697, rgb(255, 107, 53))" } }), /* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.p, { className: "framer-styles-preset-1who00q", "data-styles-preset": "Kh_cD8ZcR", dir: "auto", children: "Text" }) }), className: "framer-d88ge7", "data-framer-name": "Text", fonts: ["Inter"], layoutDependency, layoutId: "Badge__GbLTNYNfo", style: { "--framer-paragraph-spacing": "0px" }, text: zFXiwr5HG, verticalAlignment: "top", withExternalLayout: true })] }) }) }) });
});
var css2 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-c3BrQ.framer-1t00vh8, .framer-c3BrQ .framer-1t00vh8 { display: block; }", ".framer-c3BrQ.framer-y7k631 { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 6px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: min-content; }", ".framer-c3BrQ .framer-19d9p1c { flex: none; height: 14px; overflow: visible; position: relative; width: 2px; z-index: 1; }", ".framer-c3BrQ .framer-d88ge7 { -webkit-user-select: none; flex: none; height: auto; pointer-events: none; position: relative; user-select: none; white-space: pre; width: auto; }", ...css];
var FramerweB4IXCj6 = withCSS(Component, css2, "framer-c3BrQ");
var weB4IXCj6_default = FramerweB4IXCj6;
FramerweB4IXCj6.displayName = "Badge";
FramerweB4IXCj6.defaultProps = { height: 14, width: 37 };
addPropertyControls(FramerweB4IXCj6, { zFXiwr5HG: { defaultValue: "Text", displayTextArea: false, title: "Badge text", type: ControlType.String }, onzFXiwr5HGChange: { changes: "zFXiwr5HG", type: ControlType.ChangeHandler } });
addFonts(FramerweB4IXCj6, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerweB4IXCj6", "slots": [], "annotations": { "framerContractVersion": "1", "framerIntrinsicHeight": "14", "framerIntrinsicWidth": "37", "framerColorSyntax": "true", "framerDisplayContentsDiv": "false", "framerAutoSizeImages": "true", "framerImmutableVariables": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]}}}', "framerComponentViewportWidth": "true", "framerVariables": '{"zFXiwr5HG":"badgeText"}' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  weB4IXCj6_default as default
};
