var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/nFf3BwDCieEsd5bwFPE2/mojMiQSvY5ZDJEyu9PaJ/Y31vmVe0p.js
import { jsx as _jsx4, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls4, ComponentViewportProvider, ControlType as ControlType4, cx as cx3, forwardLoader, getFonts as getFonts2, SmartComponentScopedContainer, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS3, withFX } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion3, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React3 from "react";
import { useRef as useRef3 } from "react";

// http-url:https://framerusercontent.com/modules/h8ioHyt4BUxuvVCE1Q10/aTM6mEMGlM19JjX8exDe/AvoidLayoutJumping_Prod.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, RenderTarget } from "./_framer-runtime.js";
import { useEffect, useRef } from "react";
function AvoidLayoutJumping({ direction, style }) {
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  const ref = useRef(null);
  const rafId = useRef();
  const vertical = direction === "vertical" || direction === "both";
  const horizontal = direction === "horizontal" || direction === "both";
  useEffect(() => {
    if (isCanvas)
      return;
    const parent = ref.current?.parentElement?.parentElement;
    if (!parent)
      return;
    const container = parent.parentElement;
    if (!container)
      return;
    const updateSize = () => {
      const rect = parent.getBoundingClientRect();
      if (horizontal) {
        container.style.width = `${rect.width}px`;
      }
      if (vertical) {
        container.style.height = `${rect.height}px`;
      }
      rafId.current = requestAnimationFrame(updateSize);
    };
    rafId.current = requestAnimationFrame(updateSize);
    return () => {
      if (rafId.current) {
        cancelAnimationFrame(rafId.current);
      }
      if (container) {
        if (horizontal) {
          container.style.width = "";
        }
        if (vertical) {
          container.style.height = "";
        }
      }
    };
  }, [direction]);
  return /* @__PURE__ */ _jsx("div", { ref, style: { ...style } });
}
AvoidLayoutJumping.displayName = "Layout Jump Preventer";
addPropertyControls(AvoidLayoutJumping, { direction: {
  type: ControlType.Enum,
  defaultValue: "vertical",
  options: ["vertical", "horizontal", "both"],
  optionTitles: ["Vertical", "Horizontal", "Both"],
  displaySegmentedControl: true,
  segmentedControlDirection: "vertical",
  // @ts-ignore
  optionIcons: ["direction-vertical", "direction-horizontal", "direction-all"],
  description: "More components at [Framer University](https://frameruni.link/cc)."
} });

// http-url:https://framerusercontent.com/modules/iA6kyccoWLJ53U0rv47J/9Fel8EfEN1nTV7xN0yuT/LzYiE7rGz.js
import { jsx as _jsx3, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx as cx2, getFonts, getFontsFromSharedStyle, RichText, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/8VFsAOycF4H9jkHuRo2W/u2TXyck5C9PqL2g5ao62/vbTtQKoql.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx2("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx2(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx2("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 0 0 L 14 0" fill="transparent" height="1px" id="For6a1EEX" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(5 12)" width="14px"/><path d="M 0 0 L 0 14" fill="transparent" height="14px" id="TzsgOXd8_" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(12 5)" width="1px"/></svg>';
var getProps = ({ color, height, id, width, width1, ...props }) => {
  return { ...props, JEeZYcamG: width1 ?? props.JEeZYcamG ?? 2, P_DcoRcrY: color ?? props.P_DcoRcrY ?? "rgb(0, 0, 0)" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, P_DcoRcrY, JEeZYcamG, ...restProps } = getProps(props);
  const href = useSVGTemplate("3356954461", svg);
  return /* @__PURE__ */ _jsx2(SVG, { ...restProps, className: cx("framer-K11hZ", className3), layoutId, ref, role: "presentation", style: { "--1m973uw": P_DcoRcrY, "--js9iwy": JEeZYcamG, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx2("use", { href }) });
});
var css = [`.framer-K11hZ { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-K11hZ");
Icon.displayName = "Plus";
var vbTtQKoql_default = Icon;
addPropertyControls2(Icon, { P_DcoRcrY: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType2.Color }, JEeZYcamG: { defaultValue: 2, displayStepper: true, hidden: false, max: 16, min: 1, title: "Width", type: ControlType2.Number } });

// http-url:https://framerusercontent.com/modules/6KxKZoTg3exQMkMLg7PN/CzVB8fH632Pv4SSzW0KT/b69XIX_OP.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["GF;Geist-500", "GF;Geist-700"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v4/gyBhhwUxId8gMGYQMKR3pzfaWI_RruM4mJPby1QNtA.woff2", weight: "500" }, { cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v4/gyBhhwUxId8gMGYQMKR3pzfaWI_Re-Q4mJPby1QNtA.woff2", weight: "700" }] }];
var css2 = ['.framer-qF2SU .framer-styles-preset-1b2oqe0:not(.rich-text-wrapper), .framer-qF2SU .framer-styles-preset-1b2oqe0.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 20px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-2c50f5be-01b1-4e9a-bdbd-a86173538af0, #f0efe9); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; }', '@media (max-width: 1199px) and (min-width: 810px) { .framer-qF2SU .framer-styles-preset-1b2oqe0:not(.rich-text-wrapper), .framer-qF2SU .framer-styles-preset-1b2oqe0.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-2c50f5be-01b1-4e9a-bdbd-a86173538af0, #f0efe9); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; } }', '@media (max-width: 809px) and (min-width: 0px) { .framer-qF2SU .framer-styles-preset-1b2oqe0:not(.rich-text-wrapper), .framer-qF2SU .framer-styles-preset-1b2oqe0.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-2c50f5be-01b1-4e9a-bdbd-a86173538af0, #f0efe9); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; } }'];
var className = "framer-qF2SU";

// http-url:https://framerusercontent.com/modules/eLcNcS2sfDLnGit2bmLd/xFKjpmdavFXciHrYLCwG/fbfr1rN1Z.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["GF;Geist-regular", "GF;Geist-700"]);
var fonts2 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v4/gyBhhwUxId8gMGYQMKR3pzfaWI_RnOM4mJPby1QNtA.woff2", weight: "400" }, { cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v4/gyBhhwUxId8gMGYQMKR3pzfaWI_Re-Q4mJPby1QNtA.woff2", weight: "700" }] }];
var css3 = ['.framer-PDeFw .framer-styles-preset-1v58k6b:not(.rich-text-wrapper), .framer-PDeFw .framer-styles-preset-1v58k6b.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 16px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-e49112b3-ec71-4a13-943b-6d29a56126bf, #333333); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; }', '@media (max-width: 1199px) and (min-width: 810px) { .framer-PDeFw .framer-styles-preset-1v58k6b:not(.rich-text-wrapper), .framer-PDeFw .framer-styles-preset-1v58k6b.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 13px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-e49112b3-ec71-4a13-943b-6d29a56126bf, #333333); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; } }', '@media (max-width: 809px) and (min-width: 0px) { .framer-PDeFw .framer-styles-preset-1v58k6b:not(.rich-text-wrapper), .framer-PDeFw .framer-styles-preset-1v58k6b.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 14px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-e49112b3-ec71-4a13-943b-6d29a56126bf, #333333); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; } }'];
var className2 = "framer-PDeFw";

// http-url:https://framerusercontent.com/modules/iA6kyccoWLJ53U0rv47J/9Fel8EfEN1nTV7xN0yuT/LzYiE7rGz.js
var PlusFonts = getFonts(vbTtQKoql_default);
var enabledGestures = { SL_Xbwqv3: { hover: true } };
var cycleOrder = ["SL_Xbwqv3", "LpnlsvXA_", "JRwM2wGjG", "Ie_Z0hkG2"];
var serializationHash = "framer-kmYht";
var variantClassNames = { Ie_Z0hkG2: "framer-v-41h8z1", JRwM2wGjG: "framer-v-41087v", LpnlsvXA_: "framer-v-1d0i8lh", SL_Xbwqv3: "framer-v-1drsnsr" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "Desktop Primary Closed": "SL_Xbwqv3", "Desktop Primary Opened": "LpnlsvXA_", "Phone Primary Closed": "JRwM2wGjG", "Phone Primary Opened": "Ie_Z0hkG2" };
var Variants = motion2.create(React2.Fragment);
var getProps2 = ({ answer, height, id, question, width, ...props }) => {
  return { ...props, c7YyzttjF: question ?? props.c7YyzttjF ?? "Question", ERIOJYQCt: answer ?? props.ERIOJYQCt ?? "Answer", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "SL_Xbwqv3" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className3, layoutId, variant, c7YyzttjF, ERIOJYQCt, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "SL_Xbwqv3", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTap1l7gamd = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    setVariant("LpnlsvXA_");
  });
  const onTap19kbpjq = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    setVariant("SL_Xbwqv3");
  });
  const onTapu55mba = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    setVariant("Ie_Z0hkG2");
  });
  const onTapt88h1j = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    setVariant("JRwM2wGjG");
  });
  const sharedStyleClassNames = [className, className2];
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (["LpnlsvXA_", "Ie_Z0hkG2"].includes(baseVariant))
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx3(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion2.div, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-1drsnsr", className3, classNames), "data-border": true, "data-framer-name": "Desktop Primary Closed", "data-highlight": true, layoutDependency, layoutId: "FAQList__SL_Xbwqv3", onTap: onTap1l7gamd, ref: refBinding, style: { "--border-bottom-width": "0.5px", "--border-color": "var(--token-173bbc09-7ef2-4dfa-9453-e565870eeb67, rgb(37, 37, 34))", "--border-left-width": "0.5px", "--border-right-width": "0.5px", "--border-style": "solid", "--border-top-width": "0.5px", backgroundColor: "var(--token-bc0ebf3c-6044-41fd-9464-bb3c4c3d49b0, rgb(246, 251, 255))", borderBottomLeftRadius: 8, borderBottomRightRadius: 8, borderTopLeftRadius: 8, borderTopRightRadius: 8, ...style }, variants: { LpnlsvXA_: { backgroundColor: "var(--token-bc0ebf3c-6044-41fd-9464-bb3c4c3d49b0, rgb(20, 20, 18))" } }, ...addPropertyOverrides({ "SL_Xbwqv3-hover": { "data-framer-name": void 0 }, Ie_Z0hkG2: { "data-framer-name": "Phone Primary Opened", onTap: onTapt88h1j }, JRwM2wGjG: { "data-framer-name": "Phone Primary Closed", onTap: onTapu55mba }, LpnlsvXA_: { "data-framer-name": "Desktop Primary Opened", onTap: onTap19kbpjq } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs(motion2.div, { className: "framer-1v13mzs", "data-framer-name": "Question", layoutDependency, layoutId: "FAQList__owIJvWGQ6", children: [/* @__PURE__ */ _jsx3(motion2.div, { className: "framer-umb1d4", "data-framer-name": "Text Content", layoutDependency, layoutId: "FAQList__m4sNJEgAc", children: /* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React2.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { className: "framer-styles-preset-1b2oqe0", "data-styles-preset": "b69XIX_OP", dir: "auto", children: "Question" }) }), className: "framer-6y132l", "data-framer-name": "Question", fonts: ["Inter"], layoutDependency, layoutId: "FAQList__l32U3WMlE", style: { "--framer-paragraph-spacing": "0px" }, text: c7YyzttjF, verticalAlignment: "top", withExternalLayout: true }) }), /* @__PURE__ */ _jsx3(vbTtQKoql_default, { animated: true, className: "framer-ligkhz", layoutDependency, layoutId: "FAQList__mTrElotZG", style: { "--1m973uw": "var(--token-eca8c72d-732b-4686-ae8a-22be831f2697, rgb(255, 107, 53))", "--js9iwy": 2, rotate: 0 }, variants: { "SL_Xbwqv3-hover": { rotate: 15 }, Ie_Z0hkG2: { rotate: 45 }, JRwM2wGjG: { rotate: 0 }, LpnlsvXA_: { rotate: 45 } } })] }), isDisplayed() && /* @__PURE__ */ _jsx3(motion2.div, { className: "framer-1fp027j", "data-framer-name": "Answer", layoutDependency, layoutId: "FAQList__igMTHGl69", children: /* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React2.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { className: "framer-styles-preset-1v58k6b", "data-styles-preset": "fbfr1rN1Z", dir: "auto", children: "Answer" }) }), className: "framer-1ybi6w6", "data-framer-name": "Body Text", fonts: ["Inter"], layoutDependency, layoutId: "FAQList__Ae_Q2sgWv", style: { "--framer-paragraph-spacing": "0px" }, text: ERIOJYQCt, variants: { LpnlsvXA_: { "--extracted-r6o4lv": "var(--token-e49112b3-ec71-4a13-943b-6d29a56126bf, rgb(84, 84, 84))" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ LpnlsvXA_: { children: /* @__PURE__ */ _jsx3(React2.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { className: "framer-styles-preset-1v58k6b", "data-styles-preset": "fbfr1rN1Z", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-e49112b3-ec71-4a13-943b-6d29a56126bf, rgb(84, 84, 84)))" }, children: "Answer" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx3(motion2.div, { className: "framer-oanhvu", "data-framer-name": "Line", layoutDependency, layoutId: "FAQList__ZF914KDp_", style: { backgroundColor: "var(--token-eca8c72d-732b-4686-ae8a-22be831f2697, rgb(255, 107, 53))", opacity: 0 } })] }) }) }) });
});
var css4 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-kmYht.framer-1s27gnj, .framer-kmYht .framer-1s27gnj { display: block; }", ".framer-kmYht.framer-1drsnsr { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 22px; height: min-content; justify-content: center; overflow: hidden; padding: 24px 24px 0px 24px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-kmYht .framer-1v13mzs { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 20px; height: min-content; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: 100%; z-index: 1; }", ".framer-kmYht .framer-umb1d4 { align-content: center; align-items: center; display: flex; flex: 1 0 0px; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 1px; }", ".framer-kmYht .framer-6y132l { --framer-text-wrap-override: balance; flex: 1 0 0px; height: auto; position: relative; width: 1px; }", ".framer-kmYht .framer-ligkhz { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 24px); position: relative; width: 24px; }", ".framer-kmYht .framer-1fp027j { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 200px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-kmYht .framer-1ybi6w6 { flex: 1 0 0px; height: auto; position: relative; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; }", ".framer-kmYht .framer-oanhvu { flex: none; height: 1px; position: relative; width: 100%; }", ".framer-kmYht.framer-v-1d0i8lh .framer-1v13mzs { order: 0; z-index: 2; }", ".framer-kmYht.framer-v-1d0i8lh .framer-umb1d4 { z-index: 1; }", ".framer-kmYht.framer-v-1d0i8lh .framer-1fp027j { justify-content: flex-start; order: 1; z-index: 2; }", ".framer-kmYht.framer-v-1d0i8lh .framer-1ybi6w6, .framer-kmYht.framer-v-41h8z1 .framer-1ybi6w6 { --framer-text-wrap-override: balance; }", ".framer-kmYht.framer-v-1d0i8lh .framer-oanhvu { order: 2; }", ...css2, ...css3, '.framer-kmYht[data-border="true"]::after, .framer-kmYht [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerLzYiE7rGz = withCSS2(Component2, css4, "framer-kmYht");
var LzYiE7rGz_default = FramerLzYiE7rGz;
FramerLzYiE7rGz.displayName = "FAQ Single";
FramerLzYiE7rGz.defaultProps = { height: 71, width: 670 };
addPropertyControls3(FramerLzYiE7rGz, { variant: { options: ["SL_Xbwqv3", "LpnlsvXA_", "JRwM2wGjG", "Ie_Z0hkG2"], optionTitles: ["Desktop Primary Closed", "Desktop Primary Opened", "Phone Primary Closed", "Phone Primary Opened"], title: "Variant", type: ControlType3.Enum }, c7YyzttjF: { defaultValue: "Question", displayTextArea: true, title: "Question", type: ControlType3.String }, onc7YyzttjFChange: { changes: "c7YyzttjF", type: ControlType3.ChangeHandler }, ERIOJYQCt: { defaultValue: "Answer", displayTextArea: true, title: "Answer", type: ControlType3.String }, onERIOJYQCtChange: { changes: "ERIOJYQCt", type: ControlType3.ChangeHandler } });
addFonts(FramerLzYiE7rGz, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...PlusFonts, ...getFontsFromSharedStyle(fonts), ...getFontsFromSharedStyle(fonts2)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/nFf3BwDCieEsd5bwFPE2/mojMiQSvY5ZDJEyu9PaJ/Y31vmVe0p.js
var FAQSingleFonts = getFonts2(LzYiE7rGz_default);
var SmartComponentScopedContainerWithFX = withFX(SmartComponentScopedContainer);
var LayoutJumpPreventerFonts = getFonts2(AvoidLayoutJumping);
var MotionDivWithFX = withFX(motion3.div);
var cycleOrder2 = ["TogEJtXpN", "ypKxHTExb"];
var serializationHash2 = "framer-9unRG";
var variantClassNames2 = { TogEJtXpN: "framer-v-1wcw0mq", ypKxHTExb: "framer-v-1x5pwvw" };
function addPropertyOverrides2(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var animation = { opacity: 0, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 40 };
var transition12 = { damping: 40, delay: 0, mass: 1, stiffness: 200, type: "spring" };
var transition2 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var transition3 = { delay: 0, duration: 0.8, ease: [0.12, 0.23, 0.27, 1], type: "tween" };
var matchVariant = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var transformTemplate1 = (_, t) => `translateX(-50%) ${t}`;
var Transition2 = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext2.Provider, { value: contextValue, children });
};
var humanReadableVariantMap2 = { Desktop: "TogEJtXpN", Phone: "ypKxHTExb" };
var Variants2 = motion3.create(React3.Fragment);
var useStateVariable = (externalState, setExternalState) => {
  const [internalState, setInternalState] = React3.useState(externalState);
  const [previousExternalState, setPreviousExternalState] = React3.useState(externalState);
  if (setExternalState) {
    return [externalState, setExternalState];
  }
  if (externalState !== previousExternalState) {
    setInternalState(externalState);
    setPreviousExternalState(externalState);
  }
  return [internalState, setInternalState];
};
var getProps3 = ({ answer1, answer2, answer3, answer4, answer5, height, id, question1, question2, question3, question4, question5, width, ...props }) => {
  return { ...props, dhblmLlur: answer1 ?? props.dhblmLlur ?? "Answer 1", DWJQePX3E: question2 ?? props.DWJQePX3E ?? "Question 2", FS4HlPcm4: answer3 ?? props.FS4HlPcm4 ?? "Answer 3", H6qU7fYtt: answer2 ?? props.H6qU7fYtt ?? "Answer 2", hegL9MeA9: question3 ?? props.hegL9MeA9 ?? "Question 3", kOMDiODUf: question1 ?? props.kOMDiODUf ?? "Question 1", L0CmBmNSc: answer5 ?? props.L0CmBmNSc ?? "Answer 5", Le9r5ZM2m: answer4 ?? props.Le9r5ZM2m ?? "Answer 4", pLHEZynxn: question4 ?? props.pLHEZynxn ?? "Question 4", variant: humanReadableVariantMap2[props.variant] ?? props.variant ?? "TogEJtXpN", Vj1r1aGUC: question5 ?? props.Vj1r1aGUC ?? "Question 5" };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef3(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className: className3, layoutId, variant, "kOMDiODUf": externalkOMDiODUf, "onkOMDiODUfChange": setExternalkOMDiODUf, "dhblmLlur": externaldhblmLlur, "ondhblmLlurChange": setExternaldhblmLlur, "DWJQePX3E": externalDWJQePX3E, "onDWJQePX3EChange": setExternalDWJQePX3E, "H6qU7fYtt": externalH6qU7fYtt, "onH6qU7fYttChange": setExternalH6qU7fYtt, "hegL9MeA9": externalhegL9MeA9, "onhegL9MeA9Change": setExternalhegL9MeA9, "FS4HlPcm4": externalFS4HlPcm4, "onFS4HlPcm4Change": setExternalFS4HlPcm4, "pLHEZynxn": externalpLHEZynxn, "onpLHEZynxnChange": setExternalpLHEZynxn, "Le9r5ZM2m": externalLe9r5ZM2m, "onLe9r5ZM2mChange": setExternalLe9r5ZM2m, "Vj1r1aGUC": externalVj1r1aGUC, "onVj1r1aGUCChange": setExternalVj1r1aGUC, "L0CmBmNSc": externalL0CmBmNSc, "onL0CmBmNScChange": setExternalL0CmBmNSc, ...restProps } = getProps3(props);
  const [kOMDiODUf, setkOMDiODUf] = useStateVariable(externalkOMDiODUf, setExternalkOMDiODUf);
  const [dhblmLlur, setdhblmLlur] = useStateVariable(externaldhblmLlur, setExternaldhblmLlur);
  const [DWJQePX3E, setDWJQePX3E] = useStateVariable(externalDWJQePX3E, setExternalDWJQePX3E);
  const [H6qU7fYtt, setH6qU7fYtt] = useStateVariable(externalH6qU7fYtt, setExternalH6qU7fYtt);
  const [hegL9MeA9, sethegL9MeA9] = useStateVariable(externalhegL9MeA9, setExternalhegL9MeA9);
  const [FS4HlPcm4, setFS4HlPcm4] = useStateVariable(externalFS4HlPcm4, setExternalFS4HlPcm4);
  const [pLHEZynxn, setpLHEZynxn] = useStateVariable(externalpLHEZynxn, setExternalpLHEZynxn);
  const [Le9r5ZM2m, setLe9r5ZM2m] = useStateVariable(externalLe9r5ZM2m, setExternalLe9r5ZM2m);
  const [Vj1r1aGUC, setVj1r1aGUC] = useStateVariable(externalVj1r1aGUC, setExternalVj1r1aGUC);
  const [L0CmBmNSc, setL0CmBmNSc] = useStateVariable(externalL0CmBmNSc, setExternalL0CmBmNSc);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder: cycleOrder2, defaultVariant: "TogEJtXpN", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx3(serializationHash2, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx4(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition2, { value: transition2, children: /* @__PURE__ */ _jsxs2(MotionDivWithFX, { ...restProps, ...gestureHandlers, __framer__animate: { transition: transition12 }, __framer__animateOnce: true, __framer__enter: animation, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: cx3(scopingClassNames, "framer-1wcw0mq", className3, classNames), "data-framer-name": "Desktop", layoutDependency, layoutId: "FAQList__TogEJtXpN", ref: refBinding, style: { ...style }, ...addPropertyOverrides2({ ypKxHTExb: { "data-framer-name": "Phone" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 71, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 428) - 0 - 387) / 2 + 0 + 0), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainerWithFX, { __framer__animate: { transition: transition3 }, __framer__animateOnce: true, __framer__enter: animation, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: "framer-1tc595d-container", layoutDependency, layoutId: "FAQList__GHKAUMgCx-container", nodeId: "GHKAUMgCx", rendersWithMotion: true, scopeId: "Y31vmVe0p", children: /* @__PURE__ */ _jsx4(LzYiE7rGz_default, { c7YyzttjF: kOMDiODUf, ERIOJYQCt: dhblmLlur, height: "100%", id: "GHKAUMgCx", layoutId: "FAQList__GHKAUMgCx", onc7YyzttjFChange: setkOMDiODUf, onERIOJYQCtChange: setdhblmLlur, style: { width: "100%" }, variant: matchVariant("LpnlsvXA_"), width: "100%", ...addPropertyOverrides2({ ypKxHTExb: { variant: matchVariant("Ie_Z0hkG2") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 71, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 428) - 0 - 387) / 2 + 71 + 8), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainerWithFX, { __framer__animate: { transition: transition3 }, __framer__animateOnce: true, __framer__enter: animation, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: "framer-1wr9wmh-container", layoutDependency, layoutId: "FAQList__zQoBw9114-container", nodeId: "zQoBw9114", rendersWithMotion: true, scopeId: "Y31vmVe0p", children: /* @__PURE__ */ _jsx4(LzYiE7rGz_default, { c7YyzttjF: DWJQePX3E, ERIOJYQCt: H6qU7fYtt, height: "100%", id: "zQoBw9114", layoutId: "FAQList__zQoBw9114", onc7YyzttjFChange: setDWJQePX3E, onERIOJYQCtChange: setH6qU7fYtt, style: { width: "100%" }, variant: matchVariant("SL_Xbwqv3"), width: "100%", ...addPropertyOverrides2({ ypKxHTExb: { variant: matchVariant("JRwM2wGjG") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 71, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 428) - 0 - 387) / 2 + 142 + 16), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainerWithFX, { __framer__animate: { transition: transition3 }, __framer__animateOnce: true, __framer__enter: animation, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: "framer-17zfqkw-container", layoutDependency, layoutId: "FAQList__udkQcF6Te-container", nodeId: "udkQcF6Te", rendersWithMotion: true, scopeId: "Y31vmVe0p", children: /* @__PURE__ */ _jsx4(LzYiE7rGz_default, { c7YyzttjF: hegL9MeA9, ERIOJYQCt: FS4HlPcm4, height: "100%", id: "udkQcF6Te", layoutId: "FAQList__udkQcF6Te", onc7YyzttjFChange: sethegL9MeA9, onERIOJYQCtChange: setFS4HlPcm4, style: { width: "100%" }, variant: matchVariant("SL_Xbwqv3"), width: "100%", ...addPropertyOverrides2({ ypKxHTExb: { variant: matchVariant("JRwM2wGjG") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 71, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 428) - 0 - 387) / 2 + 213 + 24), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainerWithFX, { __framer__animate: { transition: transition3 }, __framer__animateOnce: true, __framer__enter: animation, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: "framer-122ksx3-container", layoutDependency, layoutId: "FAQList__Cg8zJar0G-container", nodeId: "Cg8zJar0G", rendersWithMotion: true, scopeId: "Y31vmVe0p", children: /* @__PURE__ */ _jsx4(LzYiE7rGz_default, { c7YyzttjF: pLHEZynxn, ERIOJYQCt: Le9r5ZM2m, height: "100%", id: "Cg8zJar0G", layoutId: "FAQList__Cg8zJar0G", onc7YyzttjFChange: setpLHEZynxn, onERIOJYQCtChange: setLe9r5ZM2m, style: { width: "100%" }, variant: matchVariant("SL_Xbwqv3"), width: "100%", ...addPropertyOverrides2({ ypKxHTExb: { variant: matchVariant("JRwM2wGjG") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 71, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 428) - 0 - 387) / 2 + 284 + 32), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainerWithFX, { __framer__animate: { transition: transition3 }, __framer__animateOnce: true, __framer__enter: animation, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: "framer-qwoeuo-container", layoutDependency, layoutId: "FAQList__aLiZWbIcN-container", nodeId: "aLiZWbIcN", rendersWithMotion: true, scopeId: "Y31vmVe0p", children: /* @__PURE__ */ _jsx4(LzYiE7rGz_default, { c7YyzttjF: Vj1r1aGUC, ERIOJYQCt: L0CmBmNSc, height: "100%", id: "aLiZWbIcN", layoutId: "FAQList__aLiZWbIcN", onc7YyzttjFChange: setVj1r1aGUC, onERIOJYQCtChange: setL0CmBmNSc, style: { width: "100%" }, variant: matchVariant("SL_Xbwqv3"), width: "100%", ...addPropertyOverrides2({ ypKxHTExb: { variant: matchVariant("JRwM2wGjG") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1iqxf4d-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "FAQList__BgSP5hB6Q-container", nodeId: "BgSP5hB6Q", rendersWithMotion: true, scopeId: "Y31vmVe0p", transformTemplate: transformTemplate1, children: /* @__PURE__ */ _jsx4(AvoidLayoutJumping, { direction: "vertical", height: "100%", id: "BgSP5hB6Q", layoutId: "FAQList__BgSP5hB6Q", width: "100%" }) }) })] }) }) }) });
});
var css5 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-9unRG.framer-15t8kzm, .framer-9unRG .framer-15t8kzm { display: block; }", ".framer-9unRG.framer-1wcw0mq { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-9unRG .framer-1tc595d-container, .framer-9unRG .framer-1wr9wmh-container, .framer-9unRG .framer-17zfqkw-container, .framer-9unRG .framer-122ksx3-container, .framer-9unRG .framer-qwoeuo-container { flex: none; height: auto; position: relative; width: 100%; }", ".framer-9unRG .framer-1iqxf4d-container { flex: none; height: auto; left: 50%; position: absolute; top: 0px; width: auto; z-index: 1; }", ".framer-9unRG.framer-v-1x5pwvw.framer-1wcw0mq { width: 100%; }"];
var FramerY31vmVe0p = withCSS3(Component3, css5, "framer-9unRG");
var Y31vmVe0p_default = FramerY31vmVe0p;
FramerY31vmVe0p.displayName = "FAQ List";
FramerY31vmVe0p.defaultProps = { height: 428, width: 882 };
addPropertyControls4(FramerY31vmVe0p, { variant: { options: ["TogEJtXpN", "ypKxHTExb"], optionTitles: ["Desktop", "Phone"], title: "Variant", type: ControlType4.Enum }, kOMDiODUf: { defaultValue: "Question 1", displayTextArea: true, title: "Question 1", type: ControlType4.String }, onkOMDiODUfChange: { changes: "kOMDiODUf", type: ControlType4.ChangeHandler }, dhblmLlur: { defaultValue: "Answer 1", displayTextArea: true, title: "Answer 1", type: ControlType4.String }, ondhblmLlurChange: { changes: "dhblmLlur", type: ControlType4.ChangeHandler }, DWJQePX3E: { defaultValue: "Question 2", displayTextArea: true, title: "Question 2", type: ControlType4.String }, onDWJQePX3EChange: { changes: "DWJQePX3E", type: ControlType4.ChangeHandler }, H6qU7fYtt: { defaultValue: "Answer 2", displayTextArea: true, title: "Answer 2", type: ControlType4.String }, onH6qU7fYttChange: { changes: "H6qU7fYtt", type: ControlType4.ChangeHandler }, hegL9MeA9: { defaultValue: "Question 3", displayTextArea: true, title: "Question 3", type: ControlType4.String }, onhegL9MeA9Change: { changes: "hegL9MeA9", type: ControlType4.ChangeHandler }, FS4HlPcm4: { defaultValue: "Answer 3", displayTextArea: true, title: "Answer 3", type: ControlType4.String }, onFS4HlPcm4Change: { changes: "FS4HlPcm4", type: ControlType4.ChangeHandler }, pLHEZynxn: { defaultValue: "Question 4", displayTextArea: true, title: "Question 4", type: ControlType4.String }, onpLHEZynxnChange: { changes: "pLHEZynxn", type: ControlType4.ChangeHandler }, Le9r5ZM2m: { defaultValue: "Answer 4", displayTextArea: true, title: "Answer 4", type: ControlType4.String }, onLe9r5ZM2mChange: { changes: "Le9r5ZM2m", type: ControlType4.ChangeHandler }, Vj1r1aGUC: { defaultValue: "Question 5", displayTextArea: true, title: "Question 5", type: ControlType4.String }, onVj1r1aGUCChange: { changes: "Vj1r1aGUC", type: ControlType4.ChangeHandler }, L0CmBmNSc: { defaultValue: "Answer 5", displayTextArea: true, title: "Answer 5", type: ControlType4.String }, onL0CmBmNScChange: { changes: "L0CmBmNSc", type: ControlType4.ChangeHandler } });
addFonts2(FramerY31vmVe0p, [{ explicitInter: true, fonts: [] }, ...FAQSingleFonts, ...LayoutJumpPreventerFonts], { supportsExplicitInterCodegen: true });
FramerY31vmVe0p.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader(LzYiE7rGz_default, {}, context)]);
} };
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerY31vmVe0p", "slots": [], "annotations": { "framerContractVersion": "1", "framerDisplayContentsDiv": "false", "framerComponentViewportWidth": "true", "framerImmutableVariables": "true", "framerIntrinsicWidth": "882", "framerIntrinsicHeight": "428", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"ypKxHTExb":{"layout":["fixed","auto"]}}}', "framerVariables": '{"kOMDiODUf":"question1","dhblmLlur":"answer1","DWJQePX3E":"question2","H6qU7fYtt":"answer2","hegL9MeA9":"question3","FS4HlPcm4":"answer3","pLHEZynxn":"question4","Le9r5ZM2m":"answer4","Vj1r1aGUC":"question5","L0CmBmNSc":"answer5"}', "framerAutoSizeImages": "true", "framerColorSyntax": "true" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  Y31vmVe0p_default as default
};
