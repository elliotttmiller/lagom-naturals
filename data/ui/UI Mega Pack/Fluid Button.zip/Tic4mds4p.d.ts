export interface Tic4mds4pProps {
  /**
   * Text — pass as `Tj1PdQbrm` not `text`.
   * @default "Get in touch"
   */
  Tj1PdQbrm?: string;
  onTj1PdQbrmChange?: string;
  /**
   * Link — pass as `pS9NEGgja` not `link`.
   */
  pS9NEGgja?: string;
  /**
   * Border — pass as `CJTiYz7AO` not `border`.
   * @default {"borderColor":"rgb(250, 250, 250)","borderStyle":"solid","borderWidth":2}
   */
  CJTiYz7AO?: string;
  /**
   * First Text Color — pass as `KKSPC5vo3` not `firstTextColor`.
   * @default "rgb(250, 250, 250)"
   */
  KKSPC5vo3?: string;
  /**
   * Second Text Color — pass as `UWiIjh_q1` not `secondTextColor`.
   * @default "rgb(1, 1, 1)"
   */
  UWiIjh_q1?: string;
  /**
   * Overlay Color — pass as `DP6Hb08Ak` not `overlayColor`.
   * @default "rgb(250, 250, 250)"
   */
  DP6Hb08Ak?: string;
  /**
   * New Tab? — pass as `NE1RWjDX1` not `newTab?`.
   * @default false
   */
  NE1RWjDX1?: boolean;
  onNE1RWjDX1Change?: string;
  /**
   * Transition — pass as `BAhZtzRuD` not `transition`.
   * @default {"delay":0,"duration":0.5,"ease":[0.4,0,0,1],"type":"tween"}
   */
  BAhZtzRuD?: object;
  /**
   * Scale On Hover — pass as `BBPmKfh2C` not `scaleOnHover`.
   * @default true
   */
  BBPmKfh2C?: boolean;
  onBBPmKfh2CChange?: string;
  /**
   * Scale — pass as `pBwTBQSR9` not `scale`.
   * Range: min: 1, max: 1.3, step: 0.01
   * @default 1.05
   */
  pBwTBQSR9?: number;
  onpBwTBQSR9Change?: string;
  /**
   * Pulse Effect — pass as `KwUfuvGvs` not `pulseEffect`.
   * @default true
   */
  KwUfuvGvs?: boolean;
  onKwUfuvGvsChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
