var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/SJpWHsiYfjxeurw9jWCy/Zhk4D4902uwzpqUJQTaH/TIc4Mds4p.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ComponentViewportProvider, ControlType as ControlType2, cx, getFonts, Link, RichText, SmartComponentScopedContainer, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/cP7Qb6Ml2D5ndWnIf836/MLYyrqDgHbhtGpvMNsQH/ScaleEffect.js
import { jsx as _jsx } from "react/jsx-runtime";
import { useEffect, useRef } from "react";
import { addPropertyControls, ControlType, RenderTarget } from "./_framer-runtime.js";
function PulseEffect({ scale, transition, slideChildName, enableScale, enablePulse, style }) {
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  const ref = useRef(null);
  useEffect(() => {
    if (isCanvas)
      return;
    const el = ref.current;
    if (!el)
      return;
    let target = null;
    let cursor = el.parentElement;
    while (cursor) {
      const parent = cursor.parentElement;
      if (!parent)
        break;
      if (parent.children.length > 1) {
        target = parent;
        break;
      }
      cursor = parent;
    }
    if (!target)
      return;
    const slideEl = slideChildName ? target.querySelector(`[data-framer-name="${slideChildName}"]`) : null;
    const getAnimOptions = () => {
      if (!transition)
        return { duration: 500, easing: "cubic-bezier(0.4, 0, 0, 1)" };
      if (transition.type === "tween" || transition.type === "ease") {
        const duration = (transition.duration ?? 0.5) * 1e3;
        const ease = transition.ease;
        let easing = "ease";
        if (Array.isArray(ease)) {
          easing = `cubic-bezier(${ease.join(", ")})`;
        } else if (typeof ease === "string") {
          easing = ease;
        }
        return { duration, easing };
      }
      return { duration: 500, easing: "cubic-bezier(0.4, 0, 0, 1)" };
    };
    const handleEnter = () => {
      const opts = getAnimOptions();
      target.getAnimations().forEach((a) => a.cancel());
      slideEl?.getAnimations().forEach((a) => a.cancel());
      if (enableScale) {
        if (enablePulse) {
          target.animate([{ transform: "scale(1)" }, { transform: `scale(${scale})`, offset: 0.65 }, { transform: "scale(1)" }], { ...opts, fill: "none" });
        } else {
          target.animate([{ transform: "scale(1)" }, { transform: `scale(${scale})` }], { ...opts, fill: "forwards" });
        }
      }
      if (slideEl) {
        slideEl.animate([{ transform: "translateY(0%)" }, { transform: "translateY(-100%)" }], { ...opts, fill: "forwards" });
      }
    };
    const handleLeave = () => {
      const opts = getAnimOptions();
      if (enableScale && !enablePulse) {
        target.getAnimations().forEach((a) => a.cancel());
        target.animate([{ transform: `scale(${scale})` }, { transform: "scale(1)" }], { ...opts, fill: "forwards" });
      }
      if (!slideEl)
        return;
      slideEl.getAnimations().forEach((a) => a.cancel());
      slideEl.animate([{ transform: "translateY(-100%)" }, { transform: "translateY(0%)" }], { ...opts, fill: "forwards" });
    };
    target.addEventListener("mouseenter", handleEnter);
    target.addEventListener("mouseleave", handleLeave);
    return () => {
      target.removeEventListener("mouseenter", handleEnter);
      target.removeEventListener("mouseleave", handleLeave);
    };
  }, [isCanvas, scale, transition, slideChildName, enableScale, enablePulse]);
  return /* @__PURE__ */ _jsx("div", { ref, style: { display: "none", ...style } });
}
PulseEffect.displayName = "Pulse Effect";
PulseEffect.defaultProps = { enableScale: true, enablePulse: true, scale: 1.05, slideChildName: "Label Stack", transition: { type: "tween", duration: 0.5, ease: [0.4, 0, 0, 1] } };
addPropertyControls(PulseEffect, { enableScale: { type: ControlType.Boolean, title: "Scale on Hover", defaultValue: true }, scale: { type: ControlType.Number, title: "Scale", defaultValue: 1.05, min: 1, max: 1.3, step: 0.01, displayStepper: true, hidden: (props) => !props.enableScale }, enablePulse: { type: ControlType.Boolean, title: "Pulse Effect", defaultValue: true, hidden: (props) => !props.enableScale }, transition: { type: ControlType.Transition, title: "Transition" }, slideChildName: { type: ControlType.String, title: "Slide Target", defaultValue: "Label Stack", description: "The data-framer-name of the child to slide on hover" } });

// http-url:https://framerusercontent.com/modules/SJpWHsiYfjxeurw9jWCy/Zhk4D4902uwzpqUJQTaH/TIc4Mds4p.js
var PulseEffectFonts = getFonts(PulseEffect);
var enabledGestures = { BoqGNGlNw: { hover: true } };
var serializationHash = "framer-2Djyo";
var variantClassNames = { BoqGNGlNw: "framer-v-1bi5adt" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transformTemplate1 = (_, t) => `translateY(-50%) ${t}`;
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion.create(React.Fragment);
var getProps = ({ border, firstTextColor, height, id, link, newTab, overlayColor, pulseEffect, scale, scaleOnHover, secondTextColor, text, transition, width, ...props }) => {
  return { ...props, BAhZtzRuD: transition ?? props.BAhZtzRuD ?? { delay: 0, duration: 0.5, ease: [0.4, 0, 0, 1], type: "tween" }, BBPmKfh2C: scaleOnHover ?? props.BBPmKfh2C ?? true, CJTiYz7AO: border ?? props.CJTiYz7AO ?? { borderColor: "rgb(250, 250, 250)", borderStyle: "solid", borderWidth: 2 }, DP6Hb08Ak: overlayColor ?? props.DP6Hb08Ak ?? "rgb(250, 250, 250)", KKSPC5vo3: firstTextColor ?? props.KKSPC5vo3 ?? "rgb(250, 250, 250)", KwUfuvGvs: pulseEffect ?? props.KwUfuvGvs ?? true, NE1RWjDX1: newTab ?? props.NE1RWjDX1, pBwTBQSR9: scale ?? props.pBwTBQSR9 ?? 1.05, pS9NEGgja: link ?? props.pS9NEGgja, Tj1PdQbrm: text ?? props.Tj1PdQbrm ?? "Get in touch", UWiIjh_q1: secondTextColor ?? props.UWiIjh_q1 ?? "rgb(1, 1, 1)" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, Tj1PdQbrm, pS9NEGgja, CJTiYz7AO, KKSPC5vo3, UWiIjh_q1, DP6Hb08Ak, NE1RWjDX1, BAhZtzRuD, BBPmKfh2C, pBwTBQSR9, KwUfuvGvs, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "BoqGNGlNw", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: BAhZtzRuD, children: /* @__PURE__ */ _jsx2(Link, { href: pS9NEGgja, motionChild: true, nodeId: "BoqGNGlNw", openInNewTab: NE1RWjDX1, scopeId: "TIc4Mds4p", children: /* @__PURE__ */ _jsxs(motion.a, { ...restProps, ...gestureHandlers, className: `${cx(scopingClassNames, "framer-1bi5adt", className, classNames)} framer-1g966d`, "data-border": true, "data-framer-name": "Scaling Button", "data-reset": "button", layoutDependency, layoutId: "TIc4Mds4p__BoqGNGlNw", ref: refBinding, style: { "--border-bottom-width": (CJTiYz7AO?.borderBottomWidth ?? CJTiYz7AO?.borderWidth) + "px", "--border-color": CJTiYz7AO?.borderColor, "--border-left-width": (CJTiYz7AO?.borderLeftWidth ?? CJTiYz7AO?.borderWidth) + "px", "--border-right-width": (CJTiYz7AO?.borderRightWidth ?? CJTiYz7AO?.borderWidth) + "px", "--border-style": CJTiYz7AO?.borderStyle, "--border-top-width": (CJTiYz7AO?.borderTopWidth ?? CJTiYz7AO?.borderWidth) + "px", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100, ...style }, ...addPropertyOverrides({ "BoqGNGlNw-hover": { "data-framer-name": void 0 } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx2(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx2(SmartComponentScopedContainer, { className: "framer-gpooct-container", isAuthoredByUser: true, layoutDependency, layoutId: "TIc4Mds4p__rfxXyF3DI-container", nodeId: "rfxXyF3DI", rendersWithMotion: true, scopeId: "TIc4Mds4p", transformTemplate: transformTemplate1, children: /* @__PURE__ */ _jsx2(PulseEffect, { enablePulse: KwUfuvGvs, enableScale: BBPmKfh2C, height: "100%", id: "rfxXyF3DI", layoutId: "TIc4Mds4p__rfxXyF3DI", scale: pBwTBQSR9, slideChildName: "Label Stack", transition: BAhZtzRuD, width: "100%" }) }) }), /* @__PURE__ */ _jsx2(motion.div, { className: "framer-ysmrcv", "data-framer-name": "Button Container", layoutDependency, layoutId: "TIc4Mds4p__ePmjPhNuB", children: /* @__PURE__ */ _jsxs(motion.div, { className: "framer-13nbf6g", "data-framer-name": "Label Stack", layoutDependency, layoutId: "TIc4Mds4p__PzszWh1ZT", children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React.Fragment, { children: /* @__PURE__ */ _jsx2(motion.div, { style: { "--font-selector": "RlM7TW9udHNlcnJhdC1tZWRpdW0=", "--framer-font-family": '"Montserrat", "Montserrat Placeholder", sans-serif', "--framer-font-size": "calc(var(--framer-root-font-size, 1rem) * 1.1)", "--framer-font-weight": "500", "--framer-line-height": "1em", "--framer-text-color": "var(--extracted-tcooor, var(--variable-reference-KKSPC5vo3-TIc4Mds4p))" }, children: "Get in touch" }) }), className: "framer-4ozzbb", "data-framer-name": "Upper Text", fonts: ["FS;Montserrat-medium"], layoutDependency, layoutId: "TIc4Mds4p__Mw_XToQpy", style: { "--extracted-tcooor": "var(--variable-reference-KKSPC5vo3-TIc4Mds4p)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline", "--variable-reference-KKSPC5vo3-TIc4Mds4p": KKSPC5vo3 }, text: Tj1PdQbrm, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React.Fragment, { children: /* @__PURE__ */ _jsx2(motion.div, { style: { "--font-selector": "RlM7TW9udHNlcnJhdC1tZWRpdW0=", "--framer-font-family": '"Montserrat", "Montserrat Placeholder", sans-serif', "--framer-font-size": "calc(var(--framer-root-font-size, 1rem) * 1.1)", "--framer-font-weight": "500", "--framer-line-height": "1em", "--framer-text-color": "var(--extracted-tcooor, var(--variable-reference-UWiIjh_q1-TIc4Mds4p))" }, children: "Get in touch" }) }), className: "framer-apy746", "data-framer-name": "Lower Text", fonts: ["FS;Montserrat-medium"], layoutDependency, layoutId: "TIc4Mds4p__rrD3iz92A", style: { "--extracted-tcooor": "var(--variable-reference-UWiIjh_q1-TIc4Mds4p)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline", "--variable-reference-UWiIjh_q1-TIc4Mds4p": UWiIjh_q1 }, text: Tj1PdQbrm, verticalAlignment: "top", withExternalLayout: true })] }) }), /* @__PURE__ */ _jsx2(motion.div, { className: "framer-1o7uugh", "data-framer-name": "Overlay", layoutDependency, layoutId: "TIc4Mds4p__rVxsw6UZX", style: { backgroundColor: DP6Hb08Ak, borderBottomLeftRadius: "50%", borderBottomRightRadius: "50%", borderTopLeftRadius: "50%", borderTopRightRadius: "50%" }, variants: { "BoqGNGlNw-hover": { borderBottomLeftRadius: 0, borderBottomRightRadius: 0, borderTopLeftRadius: 0, borderTopRightRadius: 0 } } })] }) }) }) }) });
});
var css = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-2Djyo.framer-1g966d, .framer-2Djyo .framer-1g966d { display: block; }", ".framer-2Djyo.framer-1bi5adt { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; overflow: hidden; padding: 25px 50px 25px 50px; position: relative; text-decoration: none; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-2Djyo .framer-gpooct-container { flex: none; height: auto; left: 50px; position: absolute; top: 51%; width: auto; z-index: 1; }", ".framer-2Djyo .framer-ysmrcv { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: 19px; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: min-content; }", ".framer-2Djyo .framer-13nbf6g { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: 19px; justify-content: center; overflow: visible; padding: 0px; position: relative; width: min-content; z-index: 1; }", ".framer-2Djyo .framer-4ozzbb { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-2Djyo .framer-apy746 { bottom: -19px; flex: none; height: auto; left: 0px; position: absolute; white-space: pre; width: auto; z-index: 1; }", ".framer-2Djyo .framer-1o7uugh { align-content: center; align-items: center; bottom: -75px; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: 110%; justify-content: center; left: 0px; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: absolute; right: 0px; will-change: var(--framer-will-change-override, transform); z-index: 0; }", ".framer-2Djyo.framer-v-1bi5adt.hover .framer-1o7uugh { bottom: unset; height: 76px; top: 0px; will-change: unset; }", '.framer-2Djyo[data-border="true"]::after, .framer-2Djyo [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerTIc4Mds4p = withCSS(Component, css, "framer-2Djyo");
var TIc4Mds4p_default = FramerTIc4Mds4p;
FramerTIc4Mds4p.displayName = "Fluid Button";
FramerTIc4Mds4p.defaultProps = { height: 69, width: 210 };
addPropertyControls2(FramerTIc4Mds4p, { Tj1PdQbrm: { defaultValue: "Get in touch", displayTextArea: false, title: "Text", type: ControlType2.String }, onTj1PdQbrmChange: { changes: "Tj1PdQbrm", type: ControlType2.ChangeHandler }, pS9NEGgja: { title: "Link", type: ControlType2.Link }, CJTiYz7AO: { defaultValue: { borderColor: "rgb(250, 250, 250)", borderStyle: "solid", borderWidth: 2 }, description: "", title: "Border", type: ControlType2.Border }, KKSPC5vo3: { defaultValue: "rgb(250, 250, 250)", title: "First Text Color", type: ControlType2.Color }, UWiIjh_q1: { defaultValue: "rgb(1, 1, 1)", title: "Second Text Color", type: ControlType2.Color }, DP6Hb08Ak: { defaultValue: "rgb(250, 250, 250)", title: "Overlay Color", type: ControlType2.Color }, NE1RWjDX1: { defaultValue: false, title: "New Tab?", type: ControlType2.Boolean }, onNE1RWjDX1Change: { changes: "NE1RWjDX1", type: ControlType2.ChangeHandler }, BAhZtzRuD: { defaultValue: { delay: 0, duration: 0.5, ease: [0.4, 0, 0, 1], type: "tween" }, title: "Transition", type: ControlType2.Transition }, BBPmKfh2C: { defaultValue: true, title: "Scale On Hover", type: ControlType2.Boolean }, onBBPmKfh2CChange: { changes: "BBPmKfh2C", type: ControlType2.ChangeHandler }, pBwTBQSR9: { defaultValue: 1.05, displayStepper: true, max: 1.3, min: 1, step: 0.01, title: "Scale", type: ControlType2.Number }, onpBwTBQSR9Change: { changes: "pBwTBQSR9", type: ControlType2.ChangeHandler }, KwUfuvGvs: { defaultValue: true, description: "Explore [more components](https://dub.sh/daniyal-framer)\nMade by [Daniyal](https://dub.sh/daniyal-threads)", title: "Pulse Effect", type: ControlType2.Boolean }, onKwUfuvGvsChange: { changes: "KwUfuvGvs", type: ControlType2.ChangeHandler } });
addFonts(FramerTIc4Mds4p, [{ explicitInter: true, fonts: [{ cssFamilyName: "Montserrat", source: "fontshare", style: "normal", uiFamilyName: "Montserrat", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/G3U4AIP7I5YYMBY4PZ5BNYEWWVH7G7QB/WED2HATCWTE6B4XVIFFTI3EALCE4D6PD/GDZ4LVIJF6WODYKVZK6E2737DCDQPEMZ.woff2", weight: "500" }] }, ...PulseEffectFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerTIc4Mds4p", "slots": [], "annotations": { "framerImmutableVariables": "true", "framerColorSyntax": "true", "framerAutoSizeImages": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"VpixHz1nI":{"layout":["auto","auto"]}}}', "framerComponentViewportWidth": "true", "framerIntrinsicHeight": "69", "framerIntrinsicWidth": "210", "framerContractVersion": "1", "framerVariables": '{"Tj1PdQbrm":"text","pS9NEGgja":"link","CJTiYz7AO":"border","KKSPC5vo3":"firstTextColor","UWiIjh_q1":"secondTextColor","DP6Hb08Ak":"overlayColor","NE1RWjDX1":"newTab","BAhZtzRuD":"transition","BBPmKfh2C":"scaleOnHover","pBwTBQSR9":"scale","KwUfuvGvs":"pulseEffect"}', "framerDisplayContentsDiv": "false" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  TIc4Mds4p_default as default
};
