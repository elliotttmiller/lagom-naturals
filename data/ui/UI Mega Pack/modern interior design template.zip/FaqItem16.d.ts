export interface Faqitem16Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "FAQ item close" → tYDh4rGrx
   *   "FAQ item open" → aUb7f9ZcB
   */
  variant?: 'FAQ item close' | 'FAQ item open' | 'tYDh4rGrx' | 'aUb7f9ZcB';
  /**
   * Question — pass as `aLFzlf88S` not `question`.
   * @default "What's your process for designing and developing a new website?"
   */
  aLFzlf88S?: string;
  onaLFzlf88SChange?: string;
  /**
   * Answer — pass as `AIcO2zgf_` not `answer`.
   * @default "I start by understanding your brand and goals, then create a tailored design that reflects your vision. "
   */
  AIcO2zgf_?: string;
  onAIcO2zgf_Change?: string;
  /** Additional properties */
  [key: string]: unknown;
}
