export interface Button8Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Primary" → JIlu585Fe
   *   "Secondary" → TFBNujZQF
   */
  variant?: 'Primary' | 'Secondary' | 'JIlu585Fe' | 'TFBNujZQF';
  /**
   * Title — pass as `CQKB8I0kR` not `title`.
   * @default "Get a free estimate"
   */
  CQKB8I0kR?: string;
  onCQKB8I0kRChange?: string;
  /**
   * Link — pass as `Hg0W0XBBe` not `link`.
   */
  Hg0W0XBBe?: string;
  /** Additional properties */
  [key: string]: unknown;
}
