export interface Howitworkscard18Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Alternative" → d9tgoTXwu
   *   "Main" → gTJZO0_2p
   */
  variant?: 'Alternative' | 'Main' | 'gTJZO0_2p' | 'd9tgoTXwu';
  /**
   * Number — pass as `H1kCSulsY` not `number`.
   * @default "01"
   */
  H1kCSulsY?: string;
  onH1kCSulsYChange?: string;
  /**
   * Heading — pass as `i_eE625bf` not `heading`.
   * @default "Heading"
   */
  i_eE625bf?: string;
  oni_eE625bfChange?: string;
  /**
   * Description — pass as `OjxVC4yk4` not `description`.
   * @default "Perfect for early-stage brands who need a strategic launch."
   */
  OjxVC4yk4?: string;
  onOjxVC4yk4Change?: string;
  /**
   * Cover image — pass as `bBsUUKPpo` not `coverImage`.
   */
  bBsUUKPpo?: string;
  /** Additional properties */
  [key: string]: unknown;
}
