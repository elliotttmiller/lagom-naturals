# Button

Exported from Framer using Design to AI.

## Components

- `Button`
- `Button2`
- `Dzkd7bshy`
- `Dzkd7bshy2`
- `Dzkd7bshy3`
- `Dzkd7bshy4`
- `Dzkd7bshy5`
- `F40onlxdn`
- `Animatedcounter`
- `Animatedcounter2`
- `Animatedcounter3`
- `ServiceCard`
- `ServiceCard2`
- `ServiceCard3`
- `ServiceCard4`
- `ProjectCard`
- `HowItWorksCard`
- `HowItWorksCard2`
- `HowItWorksCard3`
- `HowItWorksCard4`
- `Dzkd7bshy6`
- `Dzkd7bshy7`
- `Dzkd7bshy8`
- `Dzkd7bshy9`
- `Dzkd7bshy10`
- `TestimonialCard`
- `FaqItem`
- `FaqItem2`
- `FaqItem3`
- `FaqItem4`
- `FaqItem5`
- `FaqItem6`
- `Button3`
- `Button4`
- `Button5`
- `Button6`
- `Dzkd7bshy11`
- `Dzkd7bshy12`
- `Dzkd7bshy13`
- `Dzkd7bshy14`
- `Dzkd7bshy15`
- `F40onlxdn2`
- `Animatedcounter4`
- `Animatedcounter5`
- `Animatedcounter6`
- `ServiceCard5`
- `ServiceCard6`
- `ServiceCard7`
- `ServiceCard8`
- `ProjectCard2`
- `HowItWorksCard5`
- `HowItWorksCard6`
- `HowItWorksCard7`
- `HowItWorksCard8`
- `Dzkd7bshy16`
- `Dzkd7bshy17`
- `Dzkd7bshy18`
- `Dzkd7bshy19`
- `Dzkd7bshy20`
- `TestimonialCard2`
- `FaqItem7`
- `FaqItem8`
- `FaqItem9`
- `FaqItem10`
- `FaqItem11`
- `FaqItem12`
- `Button7`
- `Button8`
- `Button9`
- `Button10`
- `Dzkd7bshy21`
- `Dzkd7bshy22`
- `Dzkd7bshy23`
- `Dzkd7bshy24`
- `Dzkd7bshy25`
- `F40onlxdn3`
- `Animatedcounter7`
- `Animatedcounter8`
- `Animatedcounter9`
- `ServiceCard9`
- `ServiceCard10`
- `ServiceCard11`
- `ServiceCard12`
- `ProjectCard3`
- `HowItWorksCard9`
- `HowItWorksCard10`
- `HowItWorksCard11`
- `HowItWorksCard12`
- `Dzkd7bshy26`
- `Dzkd7bshy27`
- `Dzkd7bshy28`
- `Dzkd7bshy29`
- `Dzkd7bshy30`
- `TestimonialCard3`
- `FaqItem13`
- `FaqItem14`
- `FaqItem15`
- `FaqItem16`
- `FaqItem17`
- `FaqItem18`
- `Button11`
- `Button12`
- `Button13`
- `Button14`
- `Dzkd7bshy31`
- `Dzkd7bshy32`
- `Dzkd7bshy33`
- `Dzkd7bshy34`
- `Dzkd7bshy35`
- `F40onlxdn4`
- `Animatedcounter10`
- `Animatedcounter11`
- `Animatedcounter12`
- `ServiceCard13`
- `ServiceCard14`
- `ServiceCard15`
- `ServiceCard16`
- `ProjectCard4`
- `HowItWorksCard13`
- `HowItWorksCard14`
- `HowItWorksCard15`
- `HowItWorksCard16`
- `Dzkd7bshy36`
- `Dzkd7bshy37`
- `Dzkd7bshy38`
- `Dzkd7bshy39`
- `Dzkd7bshy40`
- `TestimonialCard4`
- `FaqItem19`
- `FaqItem20`
- `FaqItem21`
- `FaqItem22`
- `FaqItem23`
- `FaqItem24`
- `Button15`
- `Button16`
- `Button17`
- `Button18`
- `Dzkd7bshy41`
- `Dzkd7bshy42`
- `Dzkd7bshy43`
- `Dzkd7bshy44`
- `Dzkd7bshy45`
- `F40onlxdn5`
- `Animatedcounter13`
- `Animatedcounter14`
- `Animatedcounter15`
- `ServiceCard17`
- `ServiceCard18`
- `ServiceCard19`
- `ServiceCard20`
- `ProjectCard5`
- `HowItWorksCard17`
- `HowItWorksCard18`
- `HowItWorksCard19`
- `HowItWorksCard20`
- `Dzkd7bshy46`
- `Dzkd7bshy47`
- `Dzkd7bshy48`
- `Dzkd7bshy49`
- `Dzkd7bshy50`
- `TestimonialCard5`
- `FaqItem25`
- `FaqItem26`
- `FaqItem27`
- `FaqItem28`
- `FaqItem29`
- `FaqItem30`
- `Button19`
- `Button20`
- `Button21`
- `Button22`
- `Dzkd7bshy51`
- `Dzkd7bshy52`
- `Dzkd7bshy53`
- `Dzkd7bshy54`
- `Dzkd7bshy55`
- `F40onlxdn6`
- `Animatedcounter16`
- `Animatedcounter17`
- `Animatedcounter18`
- `ServiceCard21`
- `ServiceCard22`
- `ServiceCard23`
- `ServiceCard24`
- `ProjectCard6`
- `HowItWorksCard21`
- `HowItWorksCard22`
- `HowItWorksCard23`
- `HowItWorksCard24`
- `Dzkd7bshy56`
- `Dzkd7bshy57`
- `Dzkd7bshy58`
- `Dzkd7bshy59`
- `Dzkd7bshy60`
- `TestimonialCard6`
- `FaqItem31`
- `FaqItem32`
- `FaqItem33`
- `FaqItem34`
- `FaqItem35`
- `FaqItem36`
- `Button23`
- `Button24`

## Installation

```bash
# Copy this folder to your project, then install dependencies:
npm install react react-dom framer-motion
```

## Usage

```tsx
import { Button } from './Button';

function App() {
  return <Button />;
}
```

## Responsive Components

For components with responsive variants, use the responsive runtime:

```tsx
// Import the CSS for responsive breakpoints
import './Button/_responsive-runtime.css';

// Option 1: Use the useBreakpoint hook
import { useBreakpoint } from './Button/_responsive-runtime';

function App() {
  const breakpoint = useBreakpoint(); // 'base' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

  return <Button variant={breakpoint === 'base' ? 'mobile' : 'desktop'} />;
}

// Option 2: Use the WithBreakpoints HOC
import { WithBreakpoints } from './Button/_responsive-runtime';

function App() {
  return (
    <WithBreakpoints
      Component={Button}
      variants={{
        base: 'mobile',    // 0px+
        md: 'tablet',      // 768px+
        lg: 'desktop'      // 1024px+
      }}
    />
  );
}
```

### Breakpoints

| Name | Min Width | Typical Use |
|------|-----------|-------------|
| base | 0px | Mobile |
| sm | 390px | Large mobile |
| md | 768px | Tablet |
| lg | 1024px | Laptop |
| xl | 1280px | Desktop |
| 2xl | 1536px | Large desktop |

## Peer Dependencies

These components require the following packages in your project:

- `react` >= 18.0.0
- `react-dom` >= 18.0.0
- `framer-motion` >= 10.0.0

## Note

The Framer runtime is bundled as `_framer-runtime.js` - no external Framer dependency needed.
These exports are self-contained and work out of the box.

## Generated

Created with [Design to AI](https://designtoai.com)
