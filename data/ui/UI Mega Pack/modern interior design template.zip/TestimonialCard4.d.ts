export interface Testimonialcard4Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Review 1 Responsive" → EkCzoCVbp
   *   "Review 1" → JHaoqeIl3
   *   "Review 2 Responsive" → qtOhw3xUb
   *   "Review 2" → WV0sDimdN
   *   "Review 3 Responsive" → hRYVmUS73
   *   "Review 3" → Gad9RvpX_
   */
  variant?: 'Review 1 Responsive' | 'Review 1' | 'Review 2 Responsive' | 'Review 2' | 'Review 3 Responsive' | 'Review 3' | 'JHaoqeIl3' | 'WV0sDimdN' | 'Gad9RvpX_' | 'EkCzoCVbp' | 'qtOhw3xUb' | 'hRYVmUS73';
  /** Additional properties */
  [key: string]: unknown;
}
