var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/k9pfokrM7srqciYptayb/CpM4SzO6xbLEwy5WIuxi/AnimatedCounter.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
import { useEffect, useMemo, useRef, useState, startTransition } from "react";
import { useInView } from "framer-motion";
function AnimatedCounter(props) {
  const { from = 0, to = 100, duration = 1.2, delay = 0, decimals = 0, direction = "up", prefix = "", suffix = "", locale = "en-US", useGrouping = true, font, textColor, align, startOnMount, restartOnTap, style } = props;
  const isStatic = useIsStaticRenderer();
  const rootRef = useRef(null);
  const inView = useInView(rootRef, { amount: 0.2 });
  const [displayValue, setDisplayValue] = useState(() => {
    const start2 = direction === "down" ? to : from;
    return Number.isFinite(start2) ? start2 : 0;
  });
  const rafRef = useRef(null);
  const startedOnceRef = useRef(false);
  const startKeyRef = useRef(0);
  const formatter = useMemo(() => {
    try {
      return new Intl.NumberFormat(locale || "en-US", { minimumFractionDigits: Math.max(0, decimals), maximumFractionDigits: Math.max(0, decimals), useGrouping });
    } catch (e) {
      return new Intl.NumberFormat("en-US", { minimumFractionDigits: Math.max(0, decimals), maximumFractionDigits: Math.max(0, decimals), useGrouping });
    }
  }, [locale, decimals, useGrouping]);
  const clampedDurationMs = useMemo(() => {
    const d = Number(duration);
    if (!Number.isFinite(d) || d <= 0)
      return 0;
    return d * 1e3;
  }, [duration]);
  const clampedDelayMs = useMemo(() => {
    const d = Number(delay);
    if (!Number.isFinite(d) || d <= 0)
      return 0;
    return d * 1e3;
  }, [delay]);
  const startValue = direction === "down" ? to : from;
  const endValue = direction === "down" ? from : to;
  const stop = () => {
    if (typeof __dai_window === "undefined")
      return;
    if (rafRef.current != null) {
      __dai_window.cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
  };
  const start = (key) => {
    if (isStatic) {
      startTransition(() => setDisplayValue(endValue));
      return;
    }
    if (typeof __dai_window === "undefined") {
      startTransition(() => setDisplayValue(endValue));
      return;
    }
    stop();
    const localStartKey = key;
    const startAt = __dai_window.performance.now() + clampedDelayMs;
    const durationMs = clampedDurationMs;
    startTransition(() => setDisplayValue(Number.isFinite(startValue) ? startValue : 0));
    const tick = (now) => {
      if (startKeyRef.current !== localStartKey)
        return;
      if (now < startAt) {
        rafRef.current = __dai_window.requestAnimationFrame(tick);
        return;
      }
      if (durationMs === 0) {
        startTransition(() => setDisplayValue(Number.isFinite(endValue) ? endValue : 0));
        rafRef.current = null;
        return;
      }
      const t = Math.min(1, (now - startAt) / durationMs);
      const eased = 1 - Math.pow(1 - t, 3);
      const next = (Number.isFinite(startValue) ? startValue : 0) + ((Number.isFinite(endValue) ? endValue : 0) - (Number.isFinite(startValue) ? startValue : 0)) * eased;
      startTransition(() => setDisplayValue(next));
      if (t < 1) {
        rafRef.current = __dai_window.requestAnimationFrame(tick);
      } else {
        rafRef.current = null;
      }
    };
    rafRef.current = __dai_window.requestAnimationFrame(tick);
  };
  useEffect(() => {
    return () => stop();
  }, []);
  useEffect(() => {
    if (!startOnMount)
      return;
    if (!inView)
      return;
    if (startedOnceRef.current)
      return;
    startedOnceRef.current = true;
    startKeyRef.current += 1;
    start(startKeyRef.current);
  }, [startOnMount, inView]);
  useEffect(() => {
    if (isStatic) {
      startTransition(() => setDisplayValue(endValue));
      return;
    }
    if (!startOnMount) {
      startTransition(() => setDisplayValue(Number.isFinite(startValue) ? startValue : 0));
    }
  }, [from, to, direction, decimals, locale, useGrouping, isStatic]);
  const formatted = useMemo(() => {
    const safe = Number.isFinite(displayValue) ? displayValue : 0;
    return `${prefix}${formatter.format(safe)}${suffix}`;
  }, [displayValue, formatter, prefix, suffix]);
  const isFixedWidth = !!(style && style.width === "100%");
  return /* @__PURE__ */ _jsx("div", { ref: rootRef, style: { ...style, position: "relative", width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: align === "left" ? "flex-start" : align === "right" ? "flex-end" : "center", color: textColor, overflow: "hidden" }, role: "status", "aria-live": "polite", onPointerDown: () => {
    if (!restartOnTap)
      return;
    if (!inView)
      return;
    startKeyRef.current += 1;
    start(startKeyRef.current);
  }, tabIndex: restartOnTap ? 0 : -1, onKeyDown: (e) => {
    if (!restartOnTap)
      return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      if (!inView)
        return;
      startKeyRef.current += 1;
      start(startKeyRef.current);
    }
  }, "aria-label": formatted, children: /* @__PURE__ */ _jsx("span", { style: { ...font || {}, width: isFixedWidth ? "100%" : "max-content", minWidth: isFixedWidth ? void 0 : "max-content", textAlign: align, color: textColor, userSelect: "none", whiteSpace: "nowrap", fontVariantNumeric: "tabular-nums" }, children: formatted }) });
}
addPropertyControls(AnimatedCounter, { from: { type: ControlType.Number, title: "From", defaultValue: 0, step: 1 }, to: { type: ControlType.Number, title: "To", defaultValue: 100, step: 1 }, direction: { type: ControlType.Enum, title: "Direction", options: ["up", "down"], optionTitles: ["Up", "Down"], defaultValue: "up", displaySegmentedControl: true }, duration: { type: ControlType.Number, title: "Duration", defaultValue: 1.2, min: 0, max: 10, step: 0.05, unit: "s" }, delay: { type: ControlType.Number, title: "Delay", defaultValue: 0, min: 0, max: 10, step: 0.05, unit: "s" }, decimals: { type: ControlType.Number, title: "Decimals", defaultValue: 0, min: 0, max: 6, step: 1 }, prefix: { type: ControlType.String, title: "Prefix", defaultValue: "" }, suffix: { type: ControlType.String, title: "Suffix", defaultValue: "" }, locale: { type: ControlType.String, title: "Locale", defaultValue: "en-US" }, useGrouping: { type: ControlType.Boolean, title: "Grouping", defaultValue: true, enabledTitle: "On", disabledTitle: "Off" }, align: { type: ControlType.Enum, title: "Align", options: ["left", "center", "right"], optionTitles: ["Left", "Center", "Right"], defaultValue: "left", displaySegmentedControl: true }, textColor: { type: ControlType.Color, title: "Text", defaultValue: "#000000" }, font: { type: ControlType.Font, title: "Font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: "40px", variant: "Bold", letterSpacing: "-0.04em", lineHeight: "1em" } }, startOnMount: { type: ControlType.Boolean, title: "Start", defaultValue: true, enabledTitle: "On", disabledTitle: "Off" }, restartOnTap: { type: ControlType.Boolean, title: "Restart Tap", defaultValue: false, enabledTitle: "On", disabledTitle: "Off" } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "AnimatedCounter", "slots": [], "annotations": { "framerIntrinsicWidth": "160", "framerContractVersion": "1", "framerIntrinsicHeight": "48", "framerSupportedLayoutWidth": "any-prefer-fixed", "framerSupportedLayoutHeight": "auto" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  AnimatedCounter as default
};
