export interface Animatedcounter14Props {
  /**
   * From
   * @default 0
   */
  from?: number;
  /**
   * To
   * @default 100
   */
  to?: number;
  /**
   * Direction
   * Options: "up" | "down"
   * @default "up"
   */
  direction?: 'up' | 'down';
  /**
   * Duration
   * Range: min: 0, max: 10, step: 0.05
   * @default 1.2
   */
  duration?: number;
  /**
   * Delay
   * Range: min: 0, max: 10, step: 0.05
   * @default 0
   */
  delay?: number;
  /**
   * Decimals
   * Range: min: 0, max: 6, step: 1
   * @default 0
   */
  decimals?: number;
  /**
   * Prefix
   * @default ""
   */
  prefix?: string;
  /**
   * Suffix
   * @default ""
   */
  suffix?: string;
  /**
   * Locale
   * @default "en-US"
   */
  locale?: string;
  /**
   * Grouping — pass as `useGrouping` not `grouping`.
   * @default true
   */
  useGrouping?: boolean;
  /**
   * Align
   * Options: "left" | "center" | "right"
   * @default "left"
   */
  align?: 'left' | 'center' | 'right';
  /**
   * Text — pass as `textColor` not `text`.
   * @default "#000000"
   */
  textColor?: string;
  /**
   * Font
   * @default {"fontSize":"40px","variant":"Bold","letterSpacing":"-0.04em","lineHeight":"1em"}
   */
  font?: string;
  /**
   * Start — pass as `startOnMount` not `start`.
   * @default true
   */
  startOnMount?: boolean;
  /**
   * Restart Tap — pass as `restartOnTap` not `restartTap`.
   * @default false
   */
  restartOnTap?: boolean;
  /** Additional properties */
  [key: string]: unknown;
}
