export interface Projectcard6Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → j9cYmKrTq
   *   "Responsive" → xAIdvvd6P
   */
  variant?: 'Desktop' | 'Responsive' | 'j9cYmKrTq' | 'xAIdvvd6P';
  /**
   * Image — pass as `KvxmKj9aW` not `image`.
   */
  KvxmKj9aW?: string;
  /**
   * Project Name — pass as `xjoSb0Dp1` not `projectName`.
   * @default "Title"
   */
  xjoSb0Dp1?: string;
  onxjoSb0Dp1Change?: string;
  /**
   * Category — pass as `au6ZOTSDq` not `category`.
   * @default "Bathroom"
   */
  au6ZOTSDq?: string;
  onau6ZOTSDqChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
