var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/VAt0zrWQLneCoefPHX0E/tOTSxix66bSBsGx3271l/NLcB2FrrQ.js
import { jsx as _jsx3, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ComponentViewportProvider, ControlType as ControlType3, cx as cx2, getFonts, getFontsFromSharedStyle, RichText, SmartComponentScopedContainer, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/h8ioHyt4BUxuvVCE1Q10/aTM6mEMGlM19JjX8exDe/AvoidLayoutJumping_Prod.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, RenderTarget } from "./_framer-runtime.js";
import { useEffect, useRef } from "react";
function AvoidLayoutJumping({ direction, style }) {
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  const ref = useRef(null);
  const rafId = useRef();
  const vertical = direction === "vertical" || direction === "both";
  const horizontal = direction === "horizontal" || direction === "both";
  useEffect(() => {
    if (isCanvas)
      return;
    const parent = ref.current?.parentElement?.parentElement;
    if (!parent)
      return;
    const container = parent.parentElement;
    if (!container)
      return;
    const updateSize = () => {
      const rect = parent.getBoundingClientRect();
      if (horizontal) {
        container.style.width = `${rect.width}px`;
      }
      if (vertical) {
        container.style.height = `${rect.height}px`;
      }
      rafId.current = requestAnimationFrame(updateSize);
    };
    rafId.current = requestAnimationFrame(updateSize);
    return () => {
      if (rafId.current) {
        cancelAnimationFrame(rafId.current);
      }
      if (container) {
        if (horizontal) {
          container.style.width = "";
        }
        if (vertical) {
          container.style.height = "";
        }
      }
    };
  }, [direction]);
  return /* @__PURE__ */ _jsx("div", { ref, style: { ...style } });
}
AvoidLayoutJumping.displayName = "Layout Jump Preventer";
addPropertyControls(AvoidLayoutJumping, { direction: {
  type: ControlType.Enum,
  defaultValue: "vertical",
  options: ["vertical", "horizontal", "both"],
  optionTitles: ["Vertical", "Horizontal", "Both"],
  displaySegmentedControl: true,
  segmentedControlDirection: "vertical",
  // @ts-ignore
  optionIcons: ["direction-vertical", "direction-horizontal", "direction-all"],
  description: "More components at [Framer University](https://frameruni.link/cc)."
} });

// http-url:https://framerusercontent.com/modules/sPPEJJGDR4eUvdon1Bel/f3XESni8XlI3ypQ6Exdb/HbzxRJMyi.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx2("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx2(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx2("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 1.5 16.5 C 0.672 16.5 0 15.828 0 15 L 0 1.5 C 0 0.672 0.672 0 1.5 0 L 15 0 C 15.828 0 16.5 0.672 16.5 1.5 L 16.5 15 C 16.5 15.828 15.828 16.5 15 16.5 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="16.5px" id="qUr6K2nJv" transform="translate(3.75 3.75)" width="16.5px"/><path d="M 0 0 L 16.5 0" fill="transparent" height="1px" id="MbfmAbWGf" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(3.75 12)" width="16.5px"/><path d="M 0 0 L 0 16.5" fill="transparent" height="16.5px" id="mcA57vhod" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(12 3.75)" width="1px"/></svg>';
var getProps = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps(props);
  const href = useSVGTemplate("465907804", svg);
  return /* @__PURE__ */ _jsx2(SVG, { ...restProps, className: cx("framer-ohg0r", className3), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx2("use", { href }) });
});
var css = [`.framer-ohg0r { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-ohg0r");
Icon.displayName = "Plus";
var HbzxRJMyi_default = Icon;
addPropertyControls2(Icon, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType2.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType2.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType2.Number } });

// http-url:https://framerusercontent.com/modules/xHs5F1MdxtBAkUuqApBg/gcAiAsClcg17LShxh5cp/TyCLJX4zP.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["GF;Momo Trust Sans-regular", "GF;Momo Trust Sans-700"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Momo Trust Sans", openType: true, source: "google", style: "normal", uiFamilyName: "Momo Trust Sans", url: "https://fonts.gstatic.com/s/momotrustsans/v4/BXR8vFfHh_fFyXlQWZgO0TyUN7Pt3pVCeYWqJnZSW7RpbT8VehmEa4Q.woff2", weight: "400" }, { cssFamilyName: "Momo Trust Sans", openType: true, source: "google", style: "normal", uiFamilyName: "Momo Trust Sans", url: "https://fonts.gstatic.com/s/momotrustsans/v4/BXR8vFfHh_fFyXlQWZgO0TyUN7Pt3pVCeYWqJnZSW1NubT8VehmEa4Q.woff2", weight: "700" }] }];
var css2 = [`.framer-V3NVP .framer-styles-preset-1zsbh4:not(.rich-text-wrapper), .framer-V3NVP .framer-styles-preset-1zsbh4.rich-text-wrapper p { --framer-font-family: "Momo Trust Sans", "Momo Trust Sans Placeholder", sans-serif; --framer-font-family-bold: "Momo Trust Sans", "Momo Trust Sans Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.02em; --framer-line-height: 1.55em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-ecc8d777-2f9e-4348-b025-3c98c3703ed4); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; }`, `@media (max-width: 1199px) and (min-width: 810px) { .framer-V3NVP .framer-styles-preset-1zsbh4:not(.rich-text-wrapper), .framer-V3NVP .framer-styles-preset-1zsbh4.rich-text-wrapper p { --framer-font-family: "Momo Trust Sans", "Momo Trust Sans Placeholder", sans-serif; --framer-font-family-bold: "Momo Trust Sans", "Momo Trust Sans Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 15px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.02em; --framer-line-height: 1.55em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-ecc8d777-2f9e-4348-b025-3c98c3703ed4); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; } }`, `@media (max-width: 809px) and (min-width: 0px) { .framer-V3NVP .framer-styles-preset-1zsbh4:not(.rich-text-wrapper), .framer-V3NVP .framer-styles-preset-1zsbh4.rich-text-wrapper p { --framer-font-family: "Momo Trust Sans", "Momo Trust Sans Placeholder", sans-serif; --framer-font-family-bold: "Momo Trust Sans", "Momo Trust Sans Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 17px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.02em; --framer-line-height: 1.55em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-ecc8d777-2f9e-4348-b025-3c98c3703ed4); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; --framer-text-wrap: balance; } }`];
var className = "framer-V3NVP";

// http-url:https://framerusercontent.com/modules/AZjWbkhCaiCk9Htz6FKN/JhHs6Bm2C1a3Mg82Fbzy/wAHi7KmgM.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["GF;Momo Trust Sans-regular", "GF;Momo Trust Sans-700"]);
var fonts2 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Momo Trust Sans", openType: true, source: "google", style: "normal", uiFamilyName: "Momo Trust Sans", url: "https://fonts.gstatic.com/s/momotrustsans/v4/BXR8vFfHh_fFyXlQWZgO0TyUN7Pt3pVCeYWqJnZSW7RpbT8VehmEa4Q.woff2", weight: "400" }, { cssFamilyName: "Momo Trust Sans", openType: true, source: "google", style: "normal", uiFamilyName: "Momo Trust Sans", url: "https://fonts.gstatic.com/s/momotrustsans/v4/BXR8vFfHh_fFyXlQWZgO0TyUN7Pt3pVCeYWqJnZSW1NubT8VehmEa4Q.woff2", weight: "700" }] }];
var css3 = [`.framer-KrlNI .framer-styles-preset-vrlwwx:not(.rich-text-wrapper), .framer-KrlNI .framer-styles-preset-vrlwwx.rich-text-wrapper p { --framer-font-family: "Momo Trust Sans", "Momo Trust Sans Placeholder", sans-serif; --framer-font-family-bold: "Momo Trust Sans", "Momo Trust Sans Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 14px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.02em; --framer-line-height: 1.6em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-ecc8d777-2f9e-4348-b025-3c98c3703ed4); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }`];
var className2 = "framer-KrlNI";

// http-url:https://framerusercontent.com/modules/VAt0zrWQLneCoefPHX0E/tOTSxix66bSBsGx3271l/NLcB2FrrQ.js
var LayoutJumpPreventerFonts = getFonts(AvoidLayoutJumping);
var PlusFonts = getFonts(HbzxRJMyi_default);
var cycleOrder = ["tYDh4rGrx", "aUb7f9ZcB"];
var serializationHash = "framer-h9U5E";
var variantClassNames = { aUb7f9ZcB: "framer-v-nyq9ur", tYDh4rGrx: "framer-v-rf5ma4" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { damping: 52, delay: 0, mass: 1, stiffness: 320, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "FAQ item close": "tYDh4rGrx", "FAQ item open": "aUb7f9ZcB" };
var Variants = motion2.create(React2.Fragment);
var getProps2 = ({ answer, height, id, question, width, ...props }) => {
  return { ...props, AIcO2zgf_: answer ?? props.AIcO2zgf_ ?? "I start by understanding your brand and goals, then create a tailored design that reflects your vision. ", aLFzlf88S: question ?? props.aLFzlf88S ?? "What's your process for designing and developing a new website?", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "tYDh4rGrx" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className3, layoutId, variant, aLFzlf88S, AIcO2zgf_, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "tYDh4rGrx", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTap1ag24m2 = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    setVariant("aUb7f9ZcB");
  });
  const onTapzca8p2 = activeVariantCallback(async (...args) => {
    setVariant("tYDh4rGrx");
  });
  const sharedStyleClassNames = [className, className2];
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "aUb7f9ZcB")
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx3(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion2.div, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-rf5ma4", className3, classNames), "data-framer-name": "FAQ item close", "data-highlight": true, layoutDependency, layoutId: "FAQitem__tYDh4rGrx", onTap: onTap1ag24m2, ref: refBinding, style: { backgroundColor: "var(--token-8d359522-145f-4c1f-aca7-63f9f9646f8c, rgb(28, 28, 26))", borderBottomLeftRadius: 8, borderBottomRightRadius: 8, borderTopLeftRadius: 8, borderTopRightRadius: 8, ...style }, ...addPropertyOverrides({ aUb7f9ZcB: { "data-framer-name": "FAQ item open", "data-highlight": void 0, onTap: void 0 } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx3(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-x2ppdu-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "FAQitem__TzoPhH3Qi-container", nodeId: "TzoPhH3Qi", rendersWithMotion: true, scopeId: "NLcB2FrrQ", children: /* @__PURE__ */ _jsx3(AvoidLayoutJumping, { direction: "vertical", height: "100%", id: "TzoPhH3Qi", layoutId: "FAQitem__TzoPhH3Qi", width: "100%" }) }) }), /* @__PURE__ */ _jsxs(motion2.div, { className: "framer-1wcn8sa", "data-framer-name": "Wrapper", layoutDependency, layoutId: "FAQitem__LgYtbH2Rl", children: [/* @__PURE__ */ _jsxs(motion2.button, { "aria-label": "Toggle answer", className: "framer-1mphco4", "data-framer-name": "Question wrapper", "data-reset": "button", layoutDependency, layoutId: "FAQitem__RrYanOzf2", ...addPropertyOverrides({ aUb7f9ZcB: { "data-highlight": true, onTap: onTapzca8p2 } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React2.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { className: "framer-styles-preset-1zsbh4", "data-styles-preset": "TyCLJX4zP", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-cc4cc135-ae5b-45f2-a6b2-955b0ecd0f9d, rgb(245, 242, 237)))" }, children: "What's your process for designing and developing a new website?" }) }), className: "framer-2voquv", "data-framer-name": "Question", fonts: ["Inter"], layoutDependency, layoutId: "FAQitem__DPkTlEotF", style: { "--extracted-r6o4lv": "var(--token-cc4cc135-ae5b-45f2-a6b2-955b0ecd0f9d, rgb(245, 242, 237))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: aLFzlf88S, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx3(motion2.div, { className: "framer-1s09uof", "data-framer-name": "Icon wrapper", layoutDependency, layoutId: "FAQitem__RDrFKQU0A", children: /* @__PURE__ */ _jsx3(HbzxRJMyi_default, { animated: true, className: "framer-162xcgc", "data-framer-name": "Icon", layoutDependency, layoutId: "FAQitem__zowOoaIDk", style: { "--1m6trwb": 0, "--21h8s6": "var(--token-af159ae8-6181-402f-a511-82eb35037a58, rgb(122, 79, 45))", "--pgex8v": 2, rotate: 0 }, variants: { aUb7f9ZcB: { rotate: 45 } } }) })] }), isDisplayed() && /* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React2.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { className: "framer-styles-preset-vrlwwx", "data-styles-preset": "wAHi7KmgM", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-640e9e16-4e80-4cf9-a104-b85e77ff9e40, rgb(185, 183, 178)))" }, children: "I start by understanding your brand and goals, then create a tailored design that reflects your vision. " }) }), className: "framer-1cjiigk", "data-framer-name": "Answer", fonts: ["Inter"], layoutDependency, layoutId: "FAQitem__Ofg6BrGvL", style: { "--extracted-r6o4lv": "var(--token-640e9e16-4e80-4cf9-a104-b85e77ff9e40, rgb(185, 183, 178))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: AIcO2zgf_, verticalAlignment: "top", withExternalLayout: true })] })] }) }) }) });
});
var css4 = [".framer-h9U5E.framer-118se5v, .framer-h9U5E .framer-118se5v { display: block; }", ".framer-h9U5E.framer-rf5ma4 { align-content: flex-start; align-items: flex-start; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 24px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-h9U5E .framer-x2ppdu-container { flex: none; height: auto; position: relative; width: auto; }", ".framer-h9U5E .framer-1wcn8sa { align-content: flex-start; align-items: flex-start; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 8px 16px; height: min-content; justify-content: flex-start; overflow: hidden; padding: 0px; position: relative; width: 1px; }", ".framer-h9U5E .framer-1mphco4 { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; height: min-content; justify-content: space-between; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-h9U5E .framer-2voquv { flex: 1 0 0px; height: auto; max-width: 90%; position: relative; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; }", ".framer-h9U5E .framer-1s09uof { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: center; overflow: visible; padding: 8px 0px 0px 0px; position: relative; width: min-content; }", ".framer-h9U5E .framer-162xcgc { flex: none; height: auto; position: relative; width: 16px; }", ".framer-h9U5E .framer-1cjiigk { --framer-text-wrap-override: none; -webkit-user-select: none; flex: none; height: auto; max-width: 90%; pointer-events: none; position: relative; user-select: none; width: 100%; }", ".framer-h9U5E.framer-v-nyq9ur.framer-rf5ma4 { cursor: unset; }", ".framer-h9U5E.framer-v-nyq9ur .framer-1wcn8sa { gap: 12px 16px; }", ".framer-h9U5E.framer-v-nyq9ur .framer-1mphco4 { cursor: pointer; }", ".framer-h9U5E.framer-v-nyq9ur .framer-1cjiigk { -webkit-user-select: unset; pointer-events: unset; user-select: unset; }", ...css2, ...css3];
var FramerNLcB2FrrQ = withCSS2(Component2, css4, "framer-h9U5E");
var NLcB2FrrQ_default = FramerNLcB2FrrQ;
FramerNLcB2FrrQ.displayName = "FAQ item";
FramerNLcB2FrrQ.defaultProps = { height: 76, width: 805 };
addPropertyControls3(FramerNLcB2FrrQ, { variant: { options: ["tYDh4rGrx", "aUb7f9ZcB"], optionTitles: ["FAQ item close", "FAQ item open"], title: "Variant", type: ControlType3.Enum }, aLFzlf88S: { defaultValue: "What's your process for designing and developing a new website?", displayTextArea: false, title: "Question", type: ControlType3.String }, onaLFzlf88SChange: { changes: "aLFzlf88S", type: ControlType3.ChangeHandler }, AIcO2zgf_: { defaultValue: "I start by understanding your brand and goals, then create a tailored design that reflects your vision. ", displayTextArea: false, title: "Answer", type: ControlType3.String }, onAIcO2zgf_Change: { changes: "AIcO2zgf_", type: ControlType3.ChangeHandler } });
addFonts(FramerNLcB2FrrQ, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...LayoutJumpPreventerFonts, ...PlusFonts, ...getFontsFromSharedStyle(fonts), ...getFontsFromSharedStyle(fonts2)], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerNLcB2FrrQ", "slots": [], "annotations": { "framerImmutableVariables": "true", "framerComponentViewportWidth": "true", "framerContractVersion": "1", "framerIntrinsicWidth": "805", "framerDisplayContentsDiv": "false", "framerAutoSizeImages": "true", "framerColorSyntax": "true", "framerVariables": '{"aLFzlf88S":"question","AIcO2zgf_":"answer"}', "framerIntrinsicHeight": "76", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"aUb7f9ZcB":{"layout":["fixed","auto"]}}}' } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  NLcB2FrrQ_default as default
};
