export interface Servicecard20Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → uytuRmfvl
   *   "Phone" → WbInsUpIy
   *   "Tablet" → bG01gEZsQ
   */
  variant?: 'Desktop' | 'Phone' | 'Tablet' | 'uytuRmfvl' | 'bG01gEZsQ' | 'WbInsUpIy';
  /**
   * Title — pass as `OeApKT4m3` not `title`.
   * @default "Bathroom Renovation"
   */
  OeApKT4m3?: string;
  onOeApKT4m3Change?: string;
  /**
   * Description — pass as `F57w7wGU4` not `description`.
   * @default "Spa-inspired bathrooms with quality fixtures, waterproofing done right, and finishes built to last decades, not seasons."
   */
  F57w7wGU4?: string;
  onF57w7wGU4Change?: string;
  /**
   * Icon — pass as `q_tNnjqJP` not `icon`.
   * @default {"identifier":"module:1x79sg8CYYrNmFF5A5gH/wNUdgbPd1JanjmwXw5Mt/nMrctOtsK.js:default","moduleId":"1x79sg8CYYrNmFF5A5gH"}
   */
  q_tNnjqJP?: string;
  /**
   * Image — pass as `EGIjLBH6F` not `image`.
   */
  EGIjLBH6F?: string;
  /**
   * Tag 1 — pass as `HHfxZQsKf` not `tag1`.
   * @default "Scope 1"
   */
  HHfxZQsKf?: string;
  onHHfxZQsKfChange?: string;
  /**
   * Tag 2 — pass as `rcIscJaNM` not `tag2`.
   * @default "Scope 2"
   */
  rcIscJaNM?: string;
  onrcIscJaNMChange?: string;
  /**
   * Tag 3 — pass as `NCHNLKzJx` not `tag3`.
   * @default "Scope 3"
   */
  NCHNLKzJx?: string;
  onNCHNLKzJxChange?: string;
  /**
   * Tag 4 — pass as `TQVJz5v0u` not `tag4`.
   * @default "Scope 4"
   */
  TQVJz5v0u?: string;
  onTQVJz5v0uChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
