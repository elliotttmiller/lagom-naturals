export interface LogoblurProps {
  /**
   * Logos
   */
  logos?: unknown[];
  /**
   * Desktop — pass as `desktopCount` not `desktop`.
   * Range: min: 1, max: 8, step: 1
   * @default 5
   */
  desktopCount?: number;
  /**
   * Mobile — pass as `mobileCount` not `mobile`.
   * Range: min: 1, max: 5, step: 1
   * @default 3
   */
  mobileCount?: number;
  /**
   * Breakpoint
   * Range: min: 320, max: 1200, step: 10
   * @default 640
   */
  breakpoint?: number;
  /**
   * Logo Height
   * Range: min: 12, max: 160, step: 2
   * @default 40
   */
  logoHeight?: number;
  /**
   * Gap
   * Range: min: 0, max: 160, step: 4
   * @default 32
   */
  gap?: number;
  /**
   * Padding — pass as `margin` not `padding`.
   * Range: min: 0, max: 120, step: 4
   * @default 24
   */
  margin?: number;
  /**
   * Max Width
   * Range: min: 0, max: 2000, step: 20
   * @default 0
   */
  maxWidth?: number;
  /**
   * Background
   * @default "transparent"
   */
  background?: string;
  /**
   * Monochrome
   */
  monochrome?: Record<string, unknown>;
  /**
   * Animation
   */
  animation?: Record<string, unknown>;
  /** Additional properties */
  [key: string]: unknown;
}
