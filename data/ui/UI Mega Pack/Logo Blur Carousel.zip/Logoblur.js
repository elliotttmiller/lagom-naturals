var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/l1tQauLvNR2KKFNdOS9j/VcV54qPqdfMNxJPWzmch/LogoBlur.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { addPropertyControls, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
function useContainerWidth(ref) {
  const [width, setWidth] = useState(() => typeof __dai_window !== "undefined" ? __dai_window.innerWidth : 1024);
  useEffect(() => {
    if (typeof ResizeObserver === "undefined")
      return;
    const el = ref.current;
    if (!el)
      return;
    let raf = 0;
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = entry.contentBoxSize?.[0]?.inlineSize ?? entry.contentRect.width;
        if (w > 0) {
          __dai_window.cancelAnimationFrame(raf);
          raf = __dai_window.requestAnimationFrame(() => {
            setWidth((prev) => Math.abs(prev - w) > 0.5 ? w : prev);
          });
        }
      }
    });
    ro.observe(el);
    const rect = el.getBoundingClientRect();
    if (rect.width > 0)
      setWidth(rect.width);
    return () => {
      __dai_window.cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [ref]);
  return width;
}
function BlurFlowLogoCarousel(props) {
  const { logos = [], desktopCount = 5, mobileCount = 3, breakpoint = 640, logoHeight = 40, gap = 32, margin = 24, maxWidth = 0, background = "transparent", monochrome = { enabled: true, grayscale: 100, opacity: 0.6, hoverRestore: true }, animation = { direction: "up", interval: 3, stagger: 150, inDuration: 0.5, outDuration: 0.4, blur: 8, slideDistance: 60 }, style } = props;
  const isStatic = useIsStaticRenderer();
  const containerRef = useRef(null);
  const containerWidth = useContainerWidth(containerRef);
  const [reducedMotion, setReducedMotion] = useState(false);
  useEffect(() => {
    if (typeof __dai_window === "undefined")
      return () => {
      };
    const mq = __dai_window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mq.matches);
    const handler = (e) => setReducedMotion(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);
  const [paused, setPaused] = useState(false);
  const [inView, setInView] = useState(true);
  const [pageVisible, setPageVisible] = useState(true);
  useEffect(() => {
    if (typeof __dai_window === "undefined")
      return () => {
      };
    const el = containerRef.current;
    let io;
    if (el && typeof IntersectionObserver !== "undefined") {
      io = new IntersectionObserver(([entry]) => setInView(entry.isIntersecting), { rootMargin: "100px" });
      io.observe(el);
    }
    const onVisibility = () => setPageVisible(document.visibilityState !== "hidden");
    onVisibility();
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      io?.disconnect();
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, []);
  const normalizedLogos = logos.map((l) => typeof l?.image === "string" ? { ...l, image: { src: l.image } } : l);
  const pool = normalizedLogos.filter((l) => l?.image?.src);
  const poolLength = pool.length;
  const isMobile = containerWidth < breakpoint;
  const visibleCount = Math.max(1, Math.min(isMobile ? mobileCount : desktopCount, poolLength || 1));
  const [slotIndices, setSlotIndices] = useState(() => Array.from({ length: visibleCount }, (_, i) => i));
  const poolKey = pool.map((l) => l.image?.src).join("|");
  const prevInit = useRef({ visibleCount, poolKey });
  useEffect(() => {
    if (prevInit.current.visibleCount !== visibleCount || prevInit.current.poolKey !== poolKey) {
      prevInit.current = { visibleCount, poolKey };
      setSlotIndices(Array.from({ length: visibleCount }, (_, i) => i));
    }
  }, [visibleCount, poolKey]);
  const canCycle = !isStatic && !reducedMotion && poolLength > visibleCount && inView && pageVisible && !paused;
  const timeoutsRef = useRef([]);
  useEffect(() => {
    if (!canCycle)
      return;
    const clearTimeouts = () => {
      timeoutsRef.current.forEach((t) => __dai_window.clearTimeout(t));
      timeoutsRef.current = [];
    };
    const id = __dai_window.setInterval(() => {
      clearTimeouts();
      for (let i = 0; i < visibleCount; i++) {
        const t = __dai_window.setTimeout(() => {
          setSlotIndices((prev) => {
            const next = prev.slice();
            next[i] = (next[i] + visibleCount) % poolLength;
            return next;
          });
        }, i * animation.stagger);
        timeoutsRef.current.push(t);
      }
    }, Math.max(0.5, animation.interval) * 1e3);
    return () => {
      __dai_window.clearInterval(id);
      clearTimeouts();
    };
  }, [canCycle, visibleCount, poolLength, animation.interval, animation.stagger]);
  if (poolLength === 0) {
    return /* @__PURE__ */ _jsxs("div", { ref: containerRef, style: { width: "100%", maxWidth: maxWidth > 0 ? maxWidth : void 0, marginInline: "auto", minHeight: logoHeight + margin * 2, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, border: "1px dashed rgba(0,0,0,0.2)", borderRadius: 12, color: "rgba(0,0,0,0.4)", fontSize: 14, fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif", userSelect: "none", ...style }, children: [/* @__PURE__ */ _jsxs("svg", { width: "28", height: "28", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round", style: { opacity: 0.5 }, children: [/* @__PURE__ */ _jsx("rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", ry: "2" }), /* @__PURE__ */ _jsx("circle", { cx: "8.5", cy: "8.5", r: "1.5" }), /* @__PURE__ */ _jsx("polyline", { points: "21 15 16 10 5 21" })] }), /* @__PURE__ */ _jsx("span", { children: "Add logos" })] });
  }
  const slotCount = Math.min(visibleCount, slotIndices.length);
  const grayscaleBase = monochrome.enabled ? `grayscale(${monochrome.grayscale}%)` : "none";
  const opacityBase = monochrome.enabled ? monochrome.opacity : 1;
  const useHover = monochrome.enabled && monochrome.hoverRestore;
  const dirSign = animation.direction === "down" ? -1 : 1;
  const enterY = `${dirSign * animation.slideDistance}%`;
  const exitY = `${-dirSign * animation.slideDistance}%`;
  const enterTransition = reducedMotion ? { duration: 0 } : { duration: animation.inDuration, ease: "easeInOut" };
  const exitTransition = reducedMotion ? { duration: 0 } : { duration: animation.outDuration, ease: "easeInOut" };
  return /* @__PURE__ */ _jsx("div", { ref: containerRef, onPointerEnter: () => setPaused(true), onPointerLeave: () => setPaused(false), style: { width: "100%", maxWidth: maxWidth > 0 ? maxWidth : void 0, marginInline: "auto", display: "flex", alignItems: "center", justifyContent: "space-between", gap, padding: margin, background, boxSizing: "border-box", ...style }, children: Array.from({ length: slotCount }, (_, i) => {
    const item = pool[slotIndices[i] % poolLength];
    const logo = item?.image;
    if (!logo?.src)
      return null;
    const slot = /* @__PURE__ */ _jsx(motion.div, { initial: false, animate: { filter: grayscaleBase, opacity: opacityBase }, whileHover: useHover ? { filter: "grayscale(0%)", opacity: 1 } : void 0, transition: { duration: 0.3, ease: "easeInOut" }, style: {
      position: "relative",
      flex: 1,
      minWidth: 0,
      height: logoHeight,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      // Visible (not clipped) so logos fade-slide softly
      // instead of being cut at the slot edge.
      overflow: "visible"
    }, children: /* @__PURE__ */ _jsx(AnimatePresence, { mode: "popLayout", initial: false, children: /* @__PURE__ */ _jsx(motion.img, { src: logo.src, srcSet: logo.srcSet, alt: item?.name || logo.alt || "", loading: "lazy", decoding: "async", draggable: false, initial: isStatic || reducedMotion ? false : { y: enterY, opacity: 0, filter: `blur(${animation.blur}px)` }, animate: { y: "0%", opacity: 1, filter: "blur(0px)" }, exit: isStatic || reducedMotion ? { opacity: 0 } : { y: exitY, opacity: 0, filter: `blur(${animation.blur}px)`, transition: exitTransition }, transition: enterTransition, style: { maxWidth: "100%", maxHeight: "100%", objectFit: "contain", display: "block", willChange: "transform, opacity, filter" } }, logo.src) }) });
    if (item?.link) {
      const accessibleName = item?.name || logo.alt;
      return /* @__PURE__ */ _jsx("a", { href: item.link, target: "_blank", rel: "noopener noreferrer", "aria-label": accessibleName || void 0, style: { flex: 1, minWidth: 0, display: "flex", textDecoration: "none" }, children: slot }, i);
    }
    return /* @__PURE__ */ _jsx("div", { style: { flex: 1, minWidth: 0, display: "flex" }, children: slot }, i);
  }) });
}
BlurFlowLogoCarousel.displayName = "Logo Blur Carousel";
addPropertyControls(BlurFlowLogoCarousel, { logos: { type: ControlType.Array, title: "Logos", control: { type: ControlType.Object, controls: { image: {
  // ponytail: ControlType.Image, not ResponsiveImage — the
  // responsive-crop pipeline can't rasterize SVGs and drops
  // the upload; plain Image supports every format and a
  // 24-160px logo gets no real benefit from srcSet anyway.
  type: ControlType.Image,
  title: "Logo",
  description: "Any format \u2014 SVG, PNG, JPG, WebP."
}, name: { type: ControlType.String, title: "Name", placeholder: "Brand name" }, link: { type: ControlType.Link, title: "Link" } } }, maxCount: 60, description: "Add more than Desktop/Mobile count below to see them rotate \u2014 equal or fewer just displays statically." }, desktopCount: { type: ControlType.Number, title: "Desktop", defaultValue: 5, min: 1, max: 8, step: 1, displayStepper: true, description: "How many show at once on wide screens." }, mobileCount: { type: ControlType.Number, title: "Mobile", defaultValue: 3, min: 1, max: 5, step: 1, displayStepper: true, description: "How many show at once on narrow screens." }, breakpoint: { type: ControlType.Number, title: "Breakpoint", defaultValue: 640, min: 320, max: 1200, step: 10, unit: "px", description: "Below this width the Mobile count is used; above it, Desktop." }, logoHeight: { type: ControlType.Number, title: "Logo Height", defaultValue: 40, min: 12, max: 160, step: 2, unit: "px" }, gap: { type: ControlType.Number, title: "Gap", defaultValue: 32, min: 0, max: 160, step: 4, unit: "px" }, margin: { type: ControlType.Number, title: "Padding", defaultValue: 24, min: 0, max: 120, step: 4, unit: "px", description: "Inner padding around the logo row." }, maxWidth: { type: ControlType.Number, title: "Max Width", defaultValue: 0, min: 0, max: 2e3, step: 20, unit: "px", description: "0 = no limit. Above 0, the row caps here and centers." }, background: { type: ControlType.Color, title: "Background", defaultValue: "transparent" }, monochrome: { type: ControlType.Object, title: "Monochrome", description: "Mute logos to grayscale; restore color on hover.", controls: { enabled: { type: ControlType.Boolean, title: "Enabled", defaultValue: true, enabledTitle: "On", disabledTitle: "Off" }, grayscale: { type: ControlType.Number, title: "Grayscale", defaultValue: 100, min: 0, max: 100, step: 5, unit: "%", hidden: (value) => !value.enabled }, opacity: { type: ControlType.Number, title: "Opacity", defaultValue: 0.6, min: 0, max: 1, step: 0.05, hidden: (value) => !value.enabled }, hoverRestore: { type: ControlType.Boolean, title: "Hover Color", defaultValue: true, enabledTitle: "On", disabledTitle: "Off", hidden: (value) => !value.enabled } } }, animation: { type: ControlType.Object, title: "Animation", description: "Timing and motion of the logo swap.", controls: { direction: { type: ControlType.Enum, title: "Direction", defaultValue: "up", options: ["up", "down"], optionTitles: ["Up", "Down"], displaySegmentedControl: true }, interval: { type: ControlType.Number, title: "Interval", defaultValue: 3, min: 0.5, max: 15, step: 0.5, unit: "s" }, stagger: { type: ControlType.Number, title: "Stagger", defaultValue: 150, min: 0, max: 600, step: 10, unit: "ms", description: "Delay between each slot's swap, rippling the row." }, inDuration: { type: ControlType.Number, title: "In", defaultValue: 0.5, min: 0.1, max: 2, step: 0.1, unit: "s" }, outDuration: { type: ControlType.Number, title: "Out", defaultValue: 0.4, min: 0.1, max: 2, step: 0.1, unit: "s" }, blur: { type: ControlType.Number, title: "Blur", defaultValue: 8, min: 0, max: 30, step: 1, unit: "px" }, slideDistance: { type: ControlType.Number, title: "Slide", defaultValue: 60, min: 10, max: 150, step: 5, unit: "%", description: "How far a logo travels as it rolls in and out." } } } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "BlurFlowLogoCarousel", "slots": [], "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  BlurFlowLogoCarousel as default
};
