export interface FullscreenProps {
  /**
   * Slides
   * @default [{"image":"https://picsum.photos/seed/fsslide1/1600/1000","title":"Replace this caption with your own story for slide one."},{"image":"https://picsum.photos/seed/fsslide2/1600/1000","title":"Every slide pairs one image with one short line of text."},{"image":"https://picsum.photos/seed/fsslide3/1600/1000","title":"Add, remove, or reorder slides from the property panel."},{"image":"https://picsum.photos/seed/fsslide4/1600/1000","title":"Drop in your own photography to replace these placeholders."},{"image":"https://picsum.photos/seed/fsslide5/1600/1000","title":"Scrolling advances the story one frame at a time."}]
   */
  slides?: unknown[];
  /**
   * Intro / Outro — pass as `showIntroOutro` not `intro/Outro`.
   * @default true
   */
  showIntroOutro?: boolean;
  /**
   * Intro Text
   * @default "Scroll to explore the rhythm of still images that move quietly between story and sensation."
   */
  introText?: string;
  /**
   * Outro Text
   * @default "As the sequence slows the silence takes over, holding the last traces of motion in the air."
   */
  outroText?: string;
  /**
   * Nav Label
   * @default "[ Scroll Motion Slider ]"
   */
  navLabel?: string;
  /**
   * Show Indices
   * @default true
   */
  showIndices?: boolean;
  /**
   * Scroll Length — pass as `vhPerSlide` not `scrollLength`.
   * Range: min: 40, max: 200, step: 10
   * @default 100
   */
  vhPerSlide?: number;
  /**
   * Image Overlay — pass as `overlayOpacity` not `imageOverlay`.
   * Range: min: 0, max: 0.8, step: 0.05
   * @default 0.35
   */
  overlayOpacity?: number;
  /**
   * Accent — pass as `accentColor` not `accent`.
   * @default "#ffffff"
   */
  accentColor?: string;
  /**
   * Intro/Outro BG — pass as `backgroundColor` not `intro/outroBg`.
   * @default "#0f0f0f"
   */
  backgroundColor?: string;
  /**
   * Text Color
   * @default "#ffffff"
   */
  textColor?: string;
  /**
   * Title Font
   * @default {"fontFamily":"Inter"}
   */
  titleFont?: string;
  /**
   * Caption Font
   * @default {"fontFamily":"Inter"}
   */
  captionFont?: string;
  /**
   * Smooth Scroll (Lenis) — pass as `enableSmoothScroll` not `smoothScroll(lenis)`.
   * @default false
   */
  enableSmoothScroll?: boolean;
  /** Additional properties */
  [key: string]: unknown;
}
