export interface Logo8Props {
  /**
   * Image — pass as `v5CpztJyG` not `image`.
   */
  v5CpztJyG?: string;
  /** Additional properties */
  [key: string]: unknown;
}
