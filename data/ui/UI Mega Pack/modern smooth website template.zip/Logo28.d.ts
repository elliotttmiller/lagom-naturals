export interface Logo28Props {
  /**
   * Image — pass as `v5CpztJyG` not `image`.
   */
  v5CpztJyG?: string;
  /** Additional properties */
  [key: string]: unknown;
}
