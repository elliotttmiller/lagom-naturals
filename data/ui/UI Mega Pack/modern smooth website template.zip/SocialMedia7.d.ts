export interface Socialmedia7Props {
  /**
   * Icon — pass as `fwFvL5mmT` not `icon`.
   * @default {"identifier":"local-module:vector/Obs6t6_Jg:default","moduleId":"Uy8xaXHAOlCiLqUzfcNP"}
   */
  fwFvL5mmT?: string;
  /**
   * Link — pass as `dvSAunmDQ` not `link`.
   */
  dvSAunmDQ?: string;
  /** Additional properties */
  [key: string]: unknown;
}
