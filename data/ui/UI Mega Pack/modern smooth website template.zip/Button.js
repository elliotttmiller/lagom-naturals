var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/CiO7snzDn7LGLw1ZQqTo/IOcTFj0DvUwY3s9PkIm9/V9KupnB6h.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, getFonts, Link, RichText, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/B0pmnclMo56as2Cr9EWv/ATjIPJfCLDF1lzNZSGbc/CSLyxpoHo.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 5 0 L 5 2 L 11.59 2 L 0 13.59 L 1.41 15 L 13 3.41 L 13 10 L 15 10 L 15 0 Z" fill="var(--esondr, rgb(0,0,0))" height="15px" id="hf7exHPxl" transform="translate(4.5 4.5)" width="15px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(motion.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx("div", { ...rest, ref });
});
var getProps = ({ fill, height, id, width, ...props }) => {
  return { ...props, K5AAorpEW: fill ?? props.K5AAorpEW ?? "rgb(0, 0, 0)" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, K5AAorpEW, ...restProps } = getProps(props);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-2PvPF", className), layoutId, ref, style: { "--esondr": K5AAorpEW, ...style } });
});
var css = [`.framer-2PvPF { -webkit-mask: ${mask}; aspect-ratio: 1; background-color: var(--esondr); mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-2PvPF");
Icon.displayName = "North East";
var CSLyxpoHo_default = Icon;
addPropertyControls(Icon, { K5AAorpEW: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Fill", type: ControlType.Color } });

// http-url:https://framerusercontent.com/modules/CiO7snzDn7LGLw1ZQqTo/IOcTFj0DvUwY3s9PkIm9/V9KupnB6h.js
var NorthEastFonts = getFonts(CSLyxpoHo_default);
var enabledGestures = { AxstZYGe6: { hover: true }, WD7J6dj74: { hover: true } };
var cycleOrder = ["WD7J6dj74", "AxstZYGe6"];
var serializationHash = "framer-MIgbP";
var variantClassNames = { AxstZYGe6: "framer-v-y6xa09", WD7J6dj74: "framer-v-floajb" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { delay: 0, duration: 0.35, ease: [0.44, 0, 0.56, 1], type: "tween" };
var transformTemplate1 = (_, t) => `translate(-50%, -50%) ${t}`;
var transformTemplate2 = (_, t) => `translateX(-50%) ${t}`;
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Fill: "AxstZYGe6", Fit: "WD7J6dj74" };
var Variants = motion2.create(React2.Fragment);
var getProps2 = ({ click, fontSize, height, id, link, newTab, width, yourText, ...props }) => {
  return { ...props, dTT6eYk4c: yourText ?? props.dTT6eYk4c ?? "GET A QUOTE", IxHpKWC2r: newTab ?? props.IxHpKWC2r ?? false, k0wXd7e5A: link ?? props.k0wXd7e5A, mnTrAObYv: fontSize ?? props.mnTrAObYv ?? 16, mUbvdm8pr: click ?? props.mUbvdm8pr, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "WD7J6dj74" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, dTT6eYk4c, mnTrAObYv, k0wXd7e5A, IxHpKWC2r, mUbvdm8pr, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "WD7J6dj74", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTapmc4rks = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    if (mUbvdm8pr) {
      const res = await mUbvdm8pr(...args);
      if (res === false)
        return false;
    }
  });
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsx2(Link, { href: k0wXd7e5A, motionChild: true, nodeId: "WD7J6dj74", openInNewTab: IxHpKWC2r, scopeId: "V9KupnB6h", children: /* @__PURE__ */ _jsx2(motion2.a, { ...restProps, ...gestureHandlers, className: `${cx2(scopingClassNames, "framer-floajb", className, classNames)} framer-13gyagn`, "data-framer-name": "Fit", "data-highlight": true, layoutDependency, layoutId: "Button__WD7J6dj74", onTap: onTapmc4rks, ref: refBinding, style: { backgroundColor: "var(--token-0efee84f-93f5-4319-8403-083820f5781d, rgb(31, 31, 31))", ...style }, ...addPropertyOverrides({ AxstZYGe6: { "data-framer-name": "Fill" } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-i6b1cp", "data-framer-name": "Container", layoutDependency, layoutId: "Button__hQcCuHWKn", style: { background: "linear-gradient(0deg, rgba(31, 31, 31, 0) 0%, rgba(96, 96, 96, 0.1) 31.46551724137931%, var(--token-ce4de1d4-cf85-41ac-b248-e4610c66cfb4, rgb(165, 165, 165)) 100%)" }, variants: { "AxstZYGe6-hover": { background: "linear-gradient(180deg, rgba(31, 31, 31, 0) 0%, var(--token-ce4de1d4-cf85-41ac-b248-e4610c66cfb4, rgb(165, 165, 165)) 100%)" }, "WD7J6dj74-hover": { background: "linear-gradient(180deg, rgba(31, 31, 31, 0) 0%, var(--token-ce4de1d4-cf85-41ac-b248-e4610c66cfb4, rgb(165, 165, 165)) 100%)" } }, children: /* @__PURE__ */ _jsxs(motion2.div, { className: "framer-krcr3o", "data-framer-name": "Container", layoutDependency, layoutId: "Button__oTka86wYt", style: { backgroundColor: "var(--token-6bb22b70-3679-463f-ba26-3b7de67c02d4, rgb(0, 0, 0))" }, children: [/* @__PURE__ */ _jsxs(motion2.div, { className: "framer-1ifnwhc", "data-framer-name": "Arrow", layoutDependency, layoutId: "Button__uClp2LqhJ", style: { backgroundColor: "var(--token-705b37ff-a4db-4197-9da6-b67d05a88ac8, rgb(229, 30, 49))" }, children: [/* @__PURE__ */ _jsx2(CSLyxpoHo_default, { animated: true, className: "framer-se7764", layoutDependency, layoutId: "Button__mas_Cr_D4", style: { "--esondr": "var(--token-6bb22b70-3679-463f-ba26-3b7de67c02d4, rgb(0, 0, 0))" }, variants: { "AxstZYGe6-hover": { "--esondr": "var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255))" }, "WD7J6dj74-hover": { "--esondr": "var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255))" } }, ...addPropertyOverrides({ "AxstZYGe6-hover": { transformTemplate: transformTemplate1 }, "WD7J6dj74-hover": { transformTemplate: transformTemplate1 } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx2(CSLyxpoHo_default, { animated: true, className: "framer-9yc79z", layoutDependency, layoutId: "Button__fnxgT93Wq", style: { "--esondr": "var(--token-6bb22b70-3679-463f-ba26-3b7de67c02d4, rgb(0, 0, 0))" }, transformTemplate: transformTemplate1, ...addPropertyOverrides({ "AxstZYGe6-hover": { transformTemplate: void 0 }, "WD7J6dj74-hover": { transformTemplate: void 0 } }, baseVariant, gestureVariant) })] }), /* @__PURE__ */ _jsxs(motion2.div, { className: "framer-1ydhszh", "data-framer-name": "Text Box", layoutDependency, layoutId: "Button__O85QTiPym", children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { dir: "auto", style: { "--font-selector": "R0Y7U3RhY2sgU2FucyBUZXh0LTYwMA==", "--framer-font-family": '"Stack Sans Text", "Stack Sans Text Placeholder", sans-serif', "--framer-font-size": "calc(var(--variable-reference-mnTrAObYv-V9KupnB6h) * 1px)", "--framer-font-weight": "600", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255)))" }, children: "GET A QUOTE" }) }), className: "framer-oq235v", "data-framer-name": "GET A QUOTE", fonts: ["GF;Stack Sans Text-600"], layoutDependency, layoutId: "Button__EG9A08uXY", style: { "--extracted-r6o4lv": "var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255))", "--framer-paragraph-spacing": "0px", "--variable-reference-mnTrAObYv-V9KupnB6h": mnTrAObYv }, text: dTT6eYk4c, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ "WD7J6dj74-hover": { transformTemplate: transformTemplate2 } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { dir: "auto", style: { "--font-selector": "R0Y7U3RhY2sgU2FucyBUZXh0LTYwMA==", "--framer-font-family": '"Stack Sans Text", "Stack Sans Text Placeholder", sans-serif', "--framer-font-size": "calc(var(--variable-reference-mnTrAObYv-V9KupnB6h) * 1px)", "--framer-font-weight": "600", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255)))" }, children: "GET A QUOTE" }) }), className: "framer-1kyrp2s", "data-framer-name": "GET A QUOTE", fonts: ["GF;Stack Sans Text-600"], layoutDependency, layoutId: "Button__ycE4ZtXYv", style: { "--extracted-r6o4lv": "var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255))", "--framer-paragraph-spacing": "0px", "--variable-reference-mnTrAObYv-V9KupnB6h": mnTrAObYv }, text: dTT6eYk4c, transformTemplate: transformTemplate2, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ "WD7J6dj74-hover": { transformTemplate: void 0 } }, baseVariant, gestureVariant) })] })] }) }) }) }) }) }) });
});
var css2 = [".framer-MIgbP.framer-13gyagn, .framer-MIgbP .framer-13gyagn { display: block; }", ".framer-MIgbP.framer-floajb { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; text-decoration: none; width: min-content; }", ".framer-MIgbP .framer-i6b1cp { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 1px; position: relative; width: min-content; }", ".framer-MIgbP .framer-krcr3o { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 6px 16px 6px 6px; position: relative; width: min-content; }", ".framer-MIgbP .framer-1ifnwhc { aspect-ratio: 1 / 1; flex: none; height: auto; overflow: var(--overflow-clip-fallback, clip); position: relative; width: 36px; }", ".framer-MIgbP .framer-se7764 { aspect-ratio: 1 / 1; bottom: -20px; flex: none; height: auto; left: -20px; position: absolute; width: 24px; }", ".framer-MIgbP .framer-9yc79z { aspect-ratio: 1 / 1; flex: none; height: auto; left: 50%; position: absolute; top: 50%; width: 24px; }", ".framer-MIgbP .framer-1ydhszh { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px 0px 0px 10px; position: relative; width: min-content; }", ".framer-MIgbP .framer-oq235v { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-MIgbP .framer-1kyrp2s { bottom: -27px; flex: none; height: auto; left: 50%; position: absolute; white-space: pre; width: auto; z-index: 1; }", ".framer-MIgbP.framer-v-y6xa09.framer-floajb { width: 177px; }", ".framer-MIgbP.framer-v-y6xa09 .framer-i6b1cp { width: 100%; }", ".framer-MIgbP.framer-v-y6xa09 .framer-krcr3o { flex: 1 0 0px; gap: unset; justify-content: space-between; width: 1px; }", ".framer-MIgbP.framer-v-y6xa09 .framer-1ydhszh { flex: 1 0 0px; padding: 0px 0px 0px 10px; width: 1px; }", ".framer-MIgbP.framer-v-floajb.hover .framer-se7764 { bottom: unset; left: 50%; top: 50%; width: 26px; }", ".framer-MIgbP.framer-v-floajb.hover .framer-9yc79z { left: unset; right: -27px; top: -26px; }", ".framer-MIgbP.framer-v-floajb.hover .framer-oq235v { left: 50%; position: absolute; top: -23px; z-index: 1; }", ".framer-MIgbP.framer-v-floajb.hover .framer-1kyrp2s { bottom: unset; left: unset; position: relative; }", ".framer-MIgbP.framer-v-y6xa09.hover .framer-krcr3o { gap: unset; }", ".framer-MIgbP.framer-v-y6xa09.hover .framer-se7764 { bottom: unset; left: 50%; top: 50%; }", ".framer-MIgbP.framer-v-y6xa09.hover .framer-9yc79z { left: unset; right: -21px; top: -19px; }"];
var FramerV9KupnB6h = withCSS2(Component2, css2, "framer-MIgbP");
var V9KupnB6h_default = FramerV9KupnB6h;
FramerV9KupnB6h.displayName = "Button";
FramerV9KupnB6h.defaultProps = { height: 50, width: 177 };
addPropertyControls2(FramerV9KupnB6h, { variant: { options: ["WD7J6dj74", "AxstZYGe6"], optionTitles: ["Fit", "Fill"], title: "Variant", type: ControlType2.Enum }, dTT6eYk4c: { defaultValue: "GET A QUOTE", displayTextArea: false, title: "Your Text", type: ControlType2.String }, ondTT6eYk4cChange: { changes: "dTT6eYk4c", type: ControlType2.ChangeHandler }, mnTrAObYv: { defaultValue: 16, title: "Font Size", type: ControlType2.Number }, onmnTrAObYvChange: { changes: "mnTrAObYv", type: ControlType2.ChangeHandler }, k0wXd7e5A: { title: "Link", type: ControlType2.Link }, IxHpKWC2r: { defaultValue: false, title: "New Tab", type: ControlType2.Boolean }, onIxHpKWC2rChange: { changes: "IxHpKWC2r", type: ControlType2.ChangeHandler }, mUbvdm8pr: { title: "Click", type: ControlType2.EventHandler } });
addFonts(FramerV9KupnB6h, [{ explicitInter: true, fonts: [{ cssFamilyName: "Stack Sans Text", source: "google", style: "normal", uiFamilyName: "Stack Sans Text", url: "https://fonts.gstatic.com/s/stacksanstext/v1/kJEkBuAJ-Q0hiGPmzHEu345X1JJNBpRJ3RPan47MNtGNJOhyGgKF1a0.woff2", weight: "600" }] }, ...NorthEastFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerV9KupnB6h", "slots": [], "annotations": { "framerColorSyntax": "true", "framerComponentViewportWidth": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"AxstZYGe6":{"layout":["fixed","auto"]},"Mg8j5m2nV":{"layout":["auto","auto"]},"V3UsB8bM0":{"layout":["fixed","auto"]}}}', "framerDisplayContentsDiv": "false", "framerVariables": '{"dTT6eYk4c":"yourText","mnTrAObYv":"fontSize","k0wXd7e5A":"link","IxHpKWC2r":"newTab","mUbvdm8pr":"click"}', "framerIntrinsicWidth": "177", "framerAutoSizeImages": "true", "framerIntrinsicHeight": "50", "framerImmutableVariables": "true", "framerContractVersion": "1" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  V9KupnB6h_default as default
};
