export interface Button23Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Fill" → AxstZYGe6
   *   "Fit" → WD7J6dj74
   */
  variant?: 'Fill' | 'Fit' | 'WD7J6dj74' | 'AxstZYGe6';
  /**
   * Your Text — pass as `dTT6eYk4c` not `yourText`.
   * @default "GET A QUOTE"
   */
  dTT6eYk4c?: string;
  ondTT6eYk4cChange?: string;
  /**
   * Font Size — pass as `mnTrAObYv` not `fontSize`.
   * @default 16
   */
  mnTrAObYv?: number;
  onmnTrAObYvChange?: string;
  /**
   * Link — pass as `k0wXd7e5A` not `link`.
   */
  k0wXd7e5A?: string;
  /**
   * New Tab — pass as `IxHpKWC2r` not `newTab`.
   * @default false
   */
  IxHpKWC2r?: boolean;
  onIxHpKWC2rChange?: string;
  /**
   * Click — pass as `mUbvdm8pr` not `click`.
   */
  mUbvdm8pr?: () => void;
  /** Additional properties */
  [key: string]: unknown;
}
