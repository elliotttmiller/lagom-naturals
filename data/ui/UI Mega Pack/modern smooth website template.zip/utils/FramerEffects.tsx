/**
 * FramerEffects — auto-populated by the exporter
 *
 * The bundled Framer runtime's withFX HOC does NOT execute the
 * `__framer__*` animation props it receives. This file
 * reimplements those animations via WAAPI so the rendered
 * components actually animate.
 *
 *
 * Pre-populated targets:
 *
 * REVEALS (16):
 *   - .framer-1gf270e (800ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-styles-preset-168g7h2 (600ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-s4kkwp (800ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-rh404n (800ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-w0icoi (600ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-g19fh2 (600ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-i22x0k (600ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-1488qa7 (600ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-1ga2x9r (600ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-w7uzqz-container (600ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-gt9189-container (600ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-fh4v50-container (800ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-1okmi1g-container (800ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-1oah699-container (800ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-ttqoza-container (800ms cubic-bezier(0.44, 0, 0.56, 1))
 *   - .framer-1q62zy9-container (800ms cubic-bezier(0.44, 0, 0.56, 1))
 *
 * LOOPS (1):
 *   - .framer-1wml5bx (1800ms cubic-bezier(0, 0, 1, 1), pauses offscreen)
 *
 * Mount this component once at the page root.
 */
"use client";
import { useEffect } from "react";

interface RevealSpec {
  selector: string;
  keyframes: Keyframe[];
  duration: number;
  easing?: string;
  threshold?: number;
  once?: boolean;
}

interface LoopSpec {
  selector: string;
  keyframes: Keyframe[];
  duration: number;
  easing?: string;
  pauseOffscreen?: boolean;
}

const REVEAL_SPECS: RevealSpec[] = [
  {
    "selector": ".framer-1gf270e",
    "keyframes": [
      {
        "opacity": 0
      },
      {
        "opacity": 1
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-styles-preset-168g7h2",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(100px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 600,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-s4kkwp",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateX(-150px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-rh404n",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateX(-150px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-w0icoi",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateX(-150px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 600,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-g19fh2",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateX(-150px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 600,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-i22x0k",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateX(-150px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 600,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-1488qa7",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateX(-150px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 600,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-1ga2x9r",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(60px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 600,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-w7uzqz-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(60px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 600,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-gt9189-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(60px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 600,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-fh4v50-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(100px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-1okmi1g-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(100px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-1oah699-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(100px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-ttqoza-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(100px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  },
  {
    "selector": ".framer-1q62zy9-container",
    "keyframes": [
      {
        "opacity": 0,
        "transform": "translateY(100px)"
      },
      {
        "opacity": 1,
        "transform": "none"
      }
    ],
    "duration": 800,
    "easing": "cubic-bezier(0.44, 0, 0.56, 1)",
    "threshold": 0,
    "once": true
  }
];

const LOOP_SPECS: LoopSpec[] = [
  {
    "selector": ".framer-1wml5bx",
    "keyframes": [
      {
        "transform": "rotate(0deg)"
      },
      {
        "transform": "rotate(360deg)"
      }
    ],
    "duration": 1800,
    "easing": "cubic-bezier(0, 0, 1, 1)",
    "pauseOffscreen": true
  }
];

export default function FramerEffects() {
  useEffect(() => {
    const cleanups: Array<() => void> = [];
    const fired = new Set<Element>();

    for (const spec of REVEAL_SPECS) {
      const targets = document.querySelectorAll<HTMLElement>(spec.selector);
      if (targets.length === 0) continue;
      targets.forEach((el) => {
        const initial = el.animate(spec.keyframes.slice(0, 1) as Keyframe[], { duration: 1, fill: "forwards" });
        initial.pause();
      });
      const io = new IntersectionObserver((entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          if (spec.once !== false && fired.has(e.target)) continue;
          (e.target as HTMLElement).animate(spec.keyframes, {
            duration: spec.duration,
            easing: spec.easing,
            fill: "forwards",
          });
          if (spec.once !== false) fired.add(e.target);
        }
      }, { threshold: spec.threshold ?? 0, rootMargin: "0px" });
      targets.forEach((el) => io.observe(el));
      cleanups.push(() => io.disconnect());
    }

    for (const spec of LOOP_SPECS) {
      const targets = document.querySelectorAll<HTMLElement>(spec.selector);
      const anims: Animation[] = [];
      targets.forEach((el) => {
        const anim = el.animate(spec.keyframes, {
          duration: spec.duration,
          easing: spec.easing,
          iterations: Infinity,
        });
        anims.push(anim);
      });
      if (spec.pauseOffscreen) {
        const io = new IntersectionObserver((entries) => {
          for (const e of entries) {
            const i = Array.from(targets).indexOf(e.target as HTMLElement);
            if (i < 0) continue;
            if (e.isIntersecting) anims[i]?.play();
            else anims[i]?.pause();
          }
        }, { threshold: 0 });
        targets.forEach((el) => io.observe(el));
        cleanups.push(() => io.disconnect());
      }
      cleanups.push(() => anims.forEach((a) => a.cancel()));
    }

    return () => cleanups.forEach((fn) => fn());
  }, []);

  return null;
}
