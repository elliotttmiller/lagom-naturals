var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/vRkTOdjfWcmDzyyw2SqM/GJaSUyj4sGNOMrj4o8zR/zMJYnTH3P.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, Instance, Link, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/Uy8xaXHAOlCiLqUzfcNP/G5YTNcoLTdZBDPDrM5bc/Obs6t6_Jg.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = `url('data:image/svg+xml,<svg display="block" id="1974291360" role="presentation" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M 10.244 0 C 10.778 0.003 12.114 0.016 13.534 0.073 L 14.037 0.095 C 15.467 0.162 16.895 0.278 17.604 0.475 C 18.549 0.741 19.291 1.516 19.542 2.497 C 19.942 4.056 19.992 7.099 19.998 7.836 L 19.999 7.988 L 19.999 7.999 C 19.999 7.999 19.999 8.003 19.999 8.01 L 19.998 8.162 C 19.992 8.899 19.942 11.942 19.542 13.501 C 19.288 14.486 18.545 15.261 17.604 15.523 C 16.895 15.72 15.467 15.836 14.037 15.904 L 13.534 15.925 C 12.114 15.982 10.778 15.995 10.244 15.998 L 10.009 15.999 L 9.999 15.999 C 9.999 15.999 9.996 15.999 9.989 15.999 L 9.755 15.998 C 8.624 15.992 3.898 15.941 2.395 15.523 C 1.45 15.257 0.707 14.483 0.456 13.501 C 0.056 11.942 0.006 8.899 0 8.162 L 0 7.836 C 0.006 7.099 0.056 4.056 0.456 2.497 C 0.71 1.512 1.453 0.737 2.395 0.475 C 3.898 0.057 8.624 0.006 9.755 0 Z M 7.999 4.499 L 7.999 11.499 L 13.999 7.999 Z" fill="var(--zfqboc, var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255)))" height="15.9991px" id="GZk5uv9Jq" transform="translate(0 2)" width="19.9991px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(motion.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx("div", { ...rest, ref });
});
var getProps = ({ fill, height, id, width, ...props }) => {
  return { ...props, gf3La1pOL: fill ?? props.gf3La1pOL ?? "var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255))" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, gf3La1pOL, ...restProps } = getProps(props);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-vwE5j", className), layoutId, ref, style: { "--zfqboc": gf3La1pOL, ...style } });
});
var css = [`.framer-vwE5j { -webkit-mask: ${mask}; aspect-ratio: 1; background-color: var(--zfqboc); mask: ${mask}; width: 20px; }`];
var Icon = withCSS(Component, css, "framer-vwE5j");
Icon.displayName = "Youtube";
var Obs6t6_Jg_default = Icon;
addPropertyControls(Icon, { gf3La1pOL: { defaultValue: 'var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255)) /* {"name":"White"} */', hidden: false, title: "Fill", type: ControlType.Color } });

// http-url:https://framerusercontent.com/modules/vRkTOdjfWcmDzyyw2SqM/GJaSUyj4sGNOMrj4o8zR/zMJYnTH3P.js
var enabledGestures = { ydGgGn3tq: { hover: true } };
var serializationHash = "framer-UIRV7";
var variantClassNames = { ydGgGn3tq: "framer-v-1mtd75y" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion2.create(React2.Fragment);
var getProps2 = ({ height, icon, id, link, width, ...props }) => {
  return { ...props, dvSAunmDQ: link ?? props.dvSAunmDQ, fwFvL5mmT: icon ?? props.fwFvL5mmT ?? Obs6t6_Jg_default };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, fwFvL5mmT, dvSAunmDQ, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "ydGgGn3tq", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsx2(Link, { href: dvSAunmDQ, motionChild: true, nodeId: "ydGgGn3tq", openInNewTab: true, scopeId: "zMJYnTH3P", children: /* @__PURE__ */ _jsx2(motion2.a, { ...restProps, ...gestureHandlers, className: `${cx2(scopingClassNames, "framer-1mtd75y", className, classNames)} framer-j446cz`, "data-framer-name": "Variant 1", layoutDependency, layoutId: "Socialmediabutton__ydGgGn3tq", ref: refBinding, style: { background: "linear-gradient(180deg, var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255)) 0%, rgba(0, 0, 0, 0) 100%)", ...style }, variants: { "ydGgGn3tq-hover": { background: "linear-gradient(0deg, var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255)) 0%, rgba(0, 0, 0, 0) 100%)" } }, ...addPropertyOverrides({ "ydGgGn3tq-hover": { "data-framer-name": void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-1wgdz7n", "data-framer-name": "Box", layoutDependency, layoutId: "Socialmediabutton__DPv18PTUH", style: { backgroundColor: "var(--token-0efee84f-93f5-4319-8403-083820f5781d, rgb(31, 31, 31))" }, children: /* @__PURE__ */ _jsx2(Instance, { animated: true, className: "framer-1mvqgc0", Component: fwFvL5mmT, layoutDependency, layoutId: "Socialmediabutton__D8t2Uivu7", style: { "--zfqboc": "var(--token-125e3e87-caa9-4ed6-947c-99e1ece72c54, rgb(255, 255, 255))" }, variants: { "ydGgGn3tq-hover": { "--zfqboc": "var(--token-705b37ff-a4db-4197-9da6-b67d05a88ac8, rgb(229, 30, 49))" } } }) }) }) }) }) }) });
});
var css2 = [".framer-UIRV7.framer-j446cz, .framer-UIRV7 .framer-j446cz { display: block; }", ".framer-UIRV7.framer-1mtd75y { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: 50px; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 1px; position: relative; text-decoration: none; width: 50px; }", ".framer-UIRV7 .framer-1wgdz7n { align-content: center; align-items: center; display: flex; flex: 1 0 0px; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: 100%; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 1px; }", ".framer-UIRV7 .framer-1mvqgc0 { flex: none; height: auto; position: relative; }"];
var FramerzMJYnTH3P = withCSS2(Component2, css2, "framer-UIRV7");
var zMJYnTH3P_default = FramerzMJYnTH3P;
FramerzMJYnTH3P.displayName = "Social media button";
FramerzMJYnTH3P.defaultProps = { height: 50, width: 50 };
addPropertyControls2(FramerzMJYnTH3P, { fwFvL5mmT: { defaultValue: { identifier: "local-module:vector/Obs6t6_Jg:default", moduleId: "Uy8xaXHAOlCiLqUzfcNP" }, setModuleId: "ekGFbzqtEWZtUC1ZEL0s", title: "Icon", type: ControlType2.VectorSetItem }, dvSAunmDQ: { title: "Link", type: ControlType2.Link } });
addFonts(FramerzMJYnTH3P, [{ explicitInter: true, fonts: [] }], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerzMJYnTH3P", "slots": [], "annotations": { "framerIntrinsicWidth": "50", "framerAutoSizeImages": "true", "framerImmutableVariables": "true", "framerIntrinsicHeight": "50", "framerContractVersion": "1", "framerColorSyntax": "true", "framerVectorSets": '["ekGFbzqtEWZtUC1ZEL0s"]', "framerVariables": '{"fwFvL5mmT":"icon","dvSAunmDQ":"link"}', "framerDisplayContentsDiv": "false", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","fixed"]},"QFSYcFoev":{"layout":["fixed","fixed"]}}}', "framerComponentViewportWidth": "true" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  zMJYnTH3P_default as default
};
