export interface Servicecard2Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop Open" → U4Z_Mk1DJ
   *   "Open Phone" → DJAWIWUYQ
   *   "Tab Open" → OZgUR0Vrx
   *   "Desktop" → TVccgRbI_
   *   "Phone" → xkef_ZqAO
   *   "Tab" → tykOG4t19
   */
  variant?: 'Desktop Open' | 'Open Phone' | 'Tab Open' | 'Desktop' | 'Phone' | 'Tab' | 'TVccgRbI_' | 'U4Z_Mk1DJ' | 'tykOG4t19' | 'OZgUR0Vrx' | 'xkef_ZqAO' | 'DJAWIWUYQ';
  /**
   * Amount — pass as `YRFW3FTxG` not `amount`.
   * @default "01"
   */
  YRFW3FTxG?: string;
  onYRFW3FTxGChange?: string;
  /**
   * Title — pass as `KCruJrmn5` not `title`.
   * @default "HEAVY CARGO"
   */
  KCruJrmn5?: string;
  onKCruJrmn5Change?: string;
  /**
   * Badge 1 — pass as `NaPzjPB68` not `badge1`.
   * @default "(01) Oversized cargo transport"
   */
  NaPzjPB68?: string;
  onNaPzjPB68Change?: string;
  /**
   * Badge 2 — pass as `MrUYeiHwI` not `badge2`.
   * @default "(02) Heavy equipment movement"
   */
  MrUYeiHwI?: string;
  onMrUYeiHwIChange?: string;
  /**
   * Badge 3 — pass as `nvlmNa_PZ` not `badge3`.
   * @default "(03) Route optimization planning"
   */
  nvlmNa_PZ?: string;
  onnvlmNa_PZChange?: string;
  /**
   * Badge 4 — pass as `U2IzAMp9B` not `badge4`.
   * @default "(04) Industrial freight coordination"
   */
  U2IzAMp9B?: string;
  onU2IzAMp9BChange?: string;
  /**
   * Link — pass as `UUHvP6AsA` not `link`.
   */
  UUHvP6AsA?: string;
  /**
   * Image — pass as `UkXS3Fwbj` not `image`.
   */
  UkXS3Fwbj?: string;
  /**
   * New Tab — pass as `kVnDNovmG` not `newTab`.
   * @default false
   */
  kVnDNovmG?: boolean;
  onkVnDNovmGChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
