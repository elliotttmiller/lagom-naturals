export interface Logo3Props {
  /**
   * Image — pass as `v5CpztJyG` not `image`.
   */
  v5CpztJyG?: string;
  /** Additional properties */
  [key: string]: unknown;
}
