export interface Homefaq6Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "1 Open" → cxdlOnmsu
   *   "2 Open" → h4wvc4rR3
   *   "3 Open" → n6fZv_VmS
   *   "4 Open" → mviuR_HhK
   *   "5 Open" → MWkoEVmTf
   *   "All Closed" → mHQvWuEDW
   */
  variant?: '1 Open' | '2 Open' | '3 Open' | '4 Open' | '5 Open' | 'All Closed' | 'mHQvWuEDW' | 'cxdlOnmsu' | 'h4wvc4rR3' | 'n6fZv_VmS' | 'mviuR_HhK' | 'MWkoEVmTf';
  /** Additional properties */
  [key: string]: unknown;
}
