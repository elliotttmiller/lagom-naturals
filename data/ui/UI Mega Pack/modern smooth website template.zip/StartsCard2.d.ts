export interface Startscard2Props {
  /**
   * Title — pass as `PXXSYPKQM` not `title`.
   * @default "Lower Delays"
   */
  PXXSYPKQM?: string;
  onPXXSYPKQMChange?: string;
  /**
   * Amount — pass as `nKcTyw7zD` not `amount`.
   * @default "47%"
   */
  nKcTyw7zD?: string;
  onnKcTyw7zDChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
