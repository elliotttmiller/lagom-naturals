export interface Testimonialcard9Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → qHfmfy_QX
   *   "Phone" → M0wH6EDAP
   *   "Tab" → h4MJqtmuW
   */
  variant?: 'Desktop' | 'Phone' | 'Tab' | 'qHfmfy_QX' | 'h4MJqtmuW' | 'M0wH6EDAP';
  /**
   * Image — pass as `DyBfxTYxv` not `image`.
   */
  DyBfxTYxv?: string;
  /**
   * Name — pass as `TPTlSJw5r` not `name`.
   * @default "MICHAEL ANDERSON"
   */
  TPTlSJw5r?: string;
  onTPTlSJw5rChange?: string;
  /**
   * Position — pass as `z_i129R3l` not `position`.
   * @default "HEAD OF OPERATIONS"
   */
  z_i129R3l?: string;
  onz_i129R3lChange?: string;
  /**
   * Testimonial — pass as `DxFO24C8h` not `testimonial`.
   * @default "“OUR LOGISTICS OPERATION IMPROVED SIGNIFICANTLY AFTER WORKING WITH THE TEAM. THEIR EXPERTISE IN INDUSTRIAL TRANSPORTATION HELPED US REDUCE DELAYS, IMPROVE DELIVERY COORDINATION, AND MAINTAIN BETTER VISIBILITY ACROSS COMPLEX CARGO MOVEMENTS.”"
   */
  DxFO24C8h?: string;
  onDxFO24C8hChange?: string;
  /**
   * Card Title 1 — pass as `OBQK4O9QC` not `cardTitle1`.
   * @default "Lower Delays"
   */
  OBQK4O9QC?: string;
  onOBQK4O9QCChange?: string;
  /**
   * Amount 1 — pass as `ylPYhKZDP` not `amount1`.
   * @default "47%"
   */
  ylPYhKZDP?: string;
  onylPYhKZDPChange?: string;
  /**
   * Card Title 2 — pass as `Bo8aYapfi` not `cardTitle2`.
   * @default "Faster Delivery"
   */
  Bo8aYapfi?: string;
  onBo8aYapfiChange?: string;
  /**
   * Amount 2 — pass as `H5aU3ZeLV` not `amount2`.
   * @default "2.8x"
   */
  H5aU3ZeLV?: string;
  onH5aU3ZeLVChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
