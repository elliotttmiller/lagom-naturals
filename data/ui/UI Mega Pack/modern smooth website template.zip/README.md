# Button

Exported from Framer using Design to AI.

## Components

- `Button`
- `SocialMedia`
- `SocialMedia2`
- `SocialMedia3`
- `SocialMedia4`
- `Logo`
- `Logo2`
- `Logo3`
- `Logo4`
- `Logo5`
- `Badge`
- `Button2`
- `Badge2`
- `ServiceCard`
- `ServiceCard2`
- `ServiceCard3`
- `ServiceCard4`
- `Badge3`
- `StartsCard`
- `StartsCard2`
- `StartsCard3`
- `StartsCard4`
- `Badge4`
- `ProcessCard`
- `ProcessCard2`
- `ProcessCard3`
- `Badge5`
- `TestimonialCard`
- `TestimonialCard2`
- `Badge6`
- `HomeFaq`
- `Button3`
- `Badge7`
- `Button4`
- `BlogCard`
- `Button5`
- `SocialMedia5`
- `SocialMedia6`
- `SocialMedia7`
- `SocialMedia8`
- `Logo6`
- `Logo7`
- `Logo8`
- `Logo9`
- `Logo10`
- `Badge8`
- `Button6`
- `Badge9`
- `ServiceCard5`
- `ServiceCard6`
- `ServiceCard7`
- `ServiceCard8`
- `Badge10`
- `StartsCard5`
- `StartsCard6`
- `StartsCard7`
- `StartsCard8`
- `Badge11`
- `ProcessCard4`
- `ProcessCard5`
- `ProcessCard6`
- `Badge12`
- `TestimonialCard3`
- `TestimonialCard4`
- `Badge13`
- `HomeFaq2`
- `Button7`
- `Badge14`
- `Button8`
- `BlogCard2`
- `Button9`
- `SocialMedia9`
- `SocialMedia10`
- `SocialMedia11`
- `SocialMedia12`
- `Logo11`
- `Logo12`
- `Logo13`
- `Logo14`
- `Logo15`
- `Badge15`
- `Button10`
- `Badge16`
- `ServiceCard9`
- `ServiceCard10`
- `ServiceCard11`
- `ServiceCard12`
- `Badge17`
- `StartsCard9`
- `StartsCard10`
- `StartsCard11`
- `StartsCard12`
- `Badge18`
- `ProcessCard7`
- `ProcessCard8`
- `ProcessCard9`
- `Badge19`
- `TestimonialCard5`
- `TestimonialCard6`
- `Badge20`
- `HomeFaq3`
- `Button11`
- `Badge21`
- `Button12`
- `BlogCard3`
- `Button13`
- `SocialMedia13`
- `SocialMedia14`
- `SocialMedia15`
- `SocialMedia16`
- `Logo16`
- `Logo17`
- `Logo18`
- `Logo19`
- `Logo20`
- `Badge22`
- `Button14`
- `Badge23`
- `ServiceCard13`
- `ServiceCard14`
- `ServiceCard15`
- `ServiceCard16`
- `Badge24`
- `StartsCard13`
- `StartsCard14`
- `StartsCard15`
- `StartsCard16`
- `Badge25`
- `ProcessCard10`
- `ProcessCard11`
- `ProcessCard12`
- `Badge26`
- `TestimonialCard7`
- `TestimonialCard8`
- `Badge27`
- `HomeFaq4`
- `Button15`
- `Badge28`
- `Button16`
- `BlogCard4`
- `Button17`
- `SocialMedia17`
- `SocialMedia18`
- `SocialMedia19`
- `SocialMedia20`
- `Logo21`
- `Logo22`
- `Logo23`
- `Logo24`
- `Logo25`
- `Badge29`
- `Button18`
- `Badge30`
- `ServiceCard17`
- `ServiceCard18`
- `ServiceCard19`
- `ServiceCard20`
- `Badge31`
- `StartsCard17`
- `StartsCard18`
- `StartsCard19`
- `StartsCard20`
- `Badge32`
- `ProcessCard13`
- `ProcessCard14`
- `ProcessCard15`
- `Badge33`
- `TestimonialCard9`
- `TestimonialCard10`
- `Badge34`
- `HomeFaq5`
- `Button19`
- `Badge35`
- `Button20`
- `BlogCard5`
- `Button21`
- `SocialMedia21`
- `SocialMedia22`
- `SocialMedia23`
- `SocialMedia24`
- `Logo26`
- `Logo27`
- `Logo28`
- `Logo29`
- `Logo30`
- `Badge36`
- `Button22`
- `Badge37`
- `ServiceCard21`
- `ServiceCard22`
- `ServiceCard23`
- `ServiceCard24`
- `Badge38`
- `StartsCard21`
- `StartsCard22`
- `StartsCard23`
- `StartsCard24`
- `Badge39`
- `ProcessCard16`
- `ProcessCard17`
- `ProcessCard18`
- `Badge40`
- `TestimonialCard11`
- `TestimonialCard12`
- `Badge41`
- `HomeFaq6`
- `Button23`
- `Badge42`
- `Button24`
- `BlogCard6`
- `Button25`
- `Button26`
- `SocialMedia25`
- `SocialMedia26`
- `SocialMedia27`
- `SocialMedia28`
- `Button27`
- `Button28`
- `SocialMedia29`
- `SocialMedia30`
- `SocialMedia31`
- `SocialMedia32`

## Installation

```bash
# Copy this folder to your project, then install dependencies:
npm install react react-dom framer-motion
```

## Usage

```tsx
import { Button } from './Button';

function App() {
  return <Button />;
}
```

## Responsive Components

For components with responsive variants, use the responsive runtime:

```tsx
// Import the CSS for responsive breakpoints
import './Button/_responsive-runtime.css';

// Option 1: Use the useBreakpoint hook
import { useBreakpoint } from './Button/_responsive-runtime';

function App() {
  const breakpoint = useBreakpoint(); // 'base' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

  return <Button variant={breakpoint === 'base' ? 'mobile' : 'desktop'} />;
}

// Option 2: Use the WithBreakpoints HOC
import { WithBreakpoints } from './Button/_responsive-runtime';

function App() {
  return (
    <WithBreakpoints
      Component={Button}
      variants={{
        base: 'mobile',    // 0px+
        md: 'tablet',      // 768px+
        lg: 'desktop'      // 1024px+
      }}
    />
  );
}
```

### Breakpoints

| Name | Min Width | Typical Use |
|------|-----------|-------------|
| base | 0px | Mobile |
| sm | 390px | Large mobile |
| md | 768px | Tablet |
| lg | 1024px | Laptop |
| xl | 1280px | Desktop |
| 2xl | 1536px | Large desktop |

## Peer Dependencies

These components require the following packages in your project:

- `react` >= 18.0.0
- `react-dom` >= 18.0.0
- `framer-motion` >= 10.0.0

## Note

The Framer runtime is bundled as `_framer-runtime.js` - no external Framer dependency needed.
These exports are self-contained and work out of the box.

## Generated

Created with [Design to AI](https://designtoai.com)
