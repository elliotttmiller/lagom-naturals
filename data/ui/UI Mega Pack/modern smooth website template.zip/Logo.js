var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/w3i04Mpn5lr24fpV5A5a/cQ0UoZ7EmkLQhSOus8UZ/HFlsB4qU5.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addFonts, addPropertyControls, ControlType, cx, getLoadingLazyAtYPosition, Image as Image1, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef } from "react";
var serializationHash = "framer-1uHdN";
var variantClassNames = { QhFuXGzMx: "framer-v-1gw41vs" };
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion.create(React.Fragment);
var getProps = ({ height, id, image, width, ...props }) => {
  return { ...props, v5CpztJyG: image ?? props.v5CpztJyG ?? { alt: "", pixelHeight: 99, pixelWidth: 335, src: "https://framerusercontent.com/images/fwNGxJ4Z3p3ye56pNxlLfo4AQ.png?width=335&height=99" } };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, v5CpztJyG, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "QhFuXGzMx", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsx(motion.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-1gw41vs", className, classNames), "data-framer-name": "Variant 1", layoutDependency, layoutId: "Logocompany__QhFuXGzMx", ref: refBinding, style: { background: "linear-gradient(180deg, rgb(255, 255, 255) 0%, rgba(31, 31, 31, 0) 100%)", ...style }, children: /* @__PURE__ */ _jsx(motion.div, { className: "framer-1egpstg", "data-framer-name": "Container", layoutDependency, layoutId: "Logocompany__LtFsoGLdn", style: { backgroundColor: "var(--token-0efee84f-93f5-4319-8403-083820f5781d, rgb(31, 31, 31))" }, children: /* @__PURE__ */ _jsx(Image1, { background: { alt: "", fit: "fit", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 1 + (((componentViewport?.height || 160) - 2 - (((componentViewport?.height || 160) - 2) * 1 + 0)) / 2 + 0 + 0) + (0 + (((componentViewport?.height || 160) - 2) * 1 - 0 - 42) / 2)), pixelHeight: 99, pixelWidth: 335, sizes: "140px", ...toResponsiveImage(v5CpztJyG), ...{ positionX: "center", positionY: "center" } }, className: "framer-vire58", "data-framer-name": "Fictional company logo (9) 1", layoutDependency, layoutId: "Logocompany__tOiSN8sXL" }) }) }) }) }) });
});
var css = [".framer-1uHdN.framer-h0wbau, .framer-1uHdN .framer-h0wbau { display: block; }", ".framer-1uHdN.framer-1gw41vs { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: auto; justify-content: center; overflow: visible; padding: 1px; position: relative; width: 100%; }", ".framer-1uHdN .framer-1egpstg { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: 100%; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-1uHdN .framer-vire58 { aspect-ratio: 3.38 / 1; flex: none; height: auto; position: relative; width: 140px; }"];
var FramerHFlsB4qU5 = withCSS(Component, css, "framer-1uHdN");
var HFlsB4qU5_default = FramerHFlsB4qU5;
FramerHFlsB4qU5.displayName = "Logo company";
FramerHFlsB4qU5.defaultProps = { height: 160, width: 350 };
addPropertyControls(FramerHFlsB4qU5, { v5CpztJyG: { __defaultAssetReference: "data:framer/asset-reference,fwNGxJ4Z3p3ye56pNxlLfo4AQ.png?width=335&height=99", __vekterDefault: { alt: "", assetReference: "data:framer/asset-reference,fwNGxJ4Z3p3ye56pNxlLfo4AQ.png?width=335&height=99" }, title: "Image", type: ControlType.ResponsiveImage } });
addFonts(FramerHFlsB4qU5, [{ explicitInter: true, fonts: [] }], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerHFlsB4qU5", "slots": [], "annotations": { "framerDisplayContentsDiv": "false", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","fixed"]}}}', "framerIntrinsicHeight": "160", "framerColorSyntax": "true", "framerVariables": '{"v5CpztJyG":"image"}', "framerIntrinsicWidth": "350", "framerImmutableVariables": "true", "framerContractVersion": "1", "framerComponentViewportWidth": "true", "framerAutoSizeImages": "true" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  HFlsB4qU5_default as default
};
