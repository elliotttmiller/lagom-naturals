export interface Badge32Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Primary" → H3PaMCFcy
   *   "White" → Ez7HDSCwt
   */
  variant?: 'Primary' | 'White' | 'H3PaMCFcy' | 'Ez7HDSCwt';
  /**
   * Title — pass as `qvTvx1Zdg` not `title`.
   * @default "ABOUT US"
   */
  qvTvx1Zdg?: string;
  onqvTvx1ZdgChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
