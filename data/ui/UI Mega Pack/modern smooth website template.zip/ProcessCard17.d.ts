export interface Processcard17Props {
  /**
   * Image — pass as `JI4yk5zJZ` not `image`.
   */
  JI4yk5zJZ?: string;
  /**
   * Number — pass as `ikMblLJmt` not `number`.
   * @default "01"
   */
  ikMblLJmt?: string;
  onikMblLJmtChange?: string;
  /**
   * Title — pass as `H0SWk4x9G` not `title`.
   * @default "INDUSTRIAL ASSESSMENT"
   */
  H0SWk4x9G?: string;
  onH0SWk4x9GChange?: string;
  /**
   * Text — pass as `jjyhGtMHU` not `text`.
   * @default "Cargo requirement analysis and assessment."
   */
  jjyhGtMHU?: string;
  onjjyhGtMHUChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
