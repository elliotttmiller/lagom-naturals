export interface Blogcard3Props {
  /**
   * Titel — pass as `OYgzbz3Ce` not `titel`.
   * @default "How Heavy Cargo Transportation Drives Industrial Project Success"
   */
  OYgzbz3Ce?: string;
  onOYgzbz3CeChange?: string;
  /**
   * Date — pass as `G4OBA_Bf0` not `date`.
   * @default "May 18, 2026"
   */
  G4OBA_Bf0?: string;
  onG4OBA_Bf0Change?: string;
  /**
   * Category — pass as `VayEGkPpx` not `category`.
   * @default "LOGISTICS INSIGHTS"
   */
  VayEGkPpx?: string;
  onVayEGkPpxChange?: string;
  /**
   * Image — pass as `cSUQpVSyv` not `image`.
   */
  cSUQpVSyv?: string;
  /** Additional properties */
  [key: string]: unknown;
}
