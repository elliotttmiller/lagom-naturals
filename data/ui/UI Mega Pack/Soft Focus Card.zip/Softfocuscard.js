var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/XTMG5HzNVjPep4bmYrKf/BV6zAwqQ7QKZ4rO7Dxej/SoftFocusCard.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { addPropertyControls, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
var DEFAULT_IMAGE = { src: "https://framerusercontent.com/images/aNsAT3jCvt4zglbWCUoFe33Q.jpg", alt: "" };
var DEFAULT_VIDEO = "https://framerusercontent.com/assets/MLWPbW1dUQawJLhhun3dBwpgJak.mp4";
var DEFAULT_BORDER = { borderColor: "#F7F2EA", borderStyle: "solid", borderWidth: 8 };
var DEFAULT_OVERLAY = { enabled: true, color: "rgba(0, 0, 0, 0.12)" };
var DEFAULT_MASK = { shape: "bottom", blur: 12, blurHeight: 45, size: 40 };
var DEFAULT_PLAYBACK = { autoplay: true, pauseHover: false, playHover: true, muted: true, unmuteHover: false };
var DEFAULT_HOVER = { blur: 8, mediaZoom: 1.05, logoZoom: 0.8 };
var DEFAULT_TRANSITION = { type: "tween", duration: 0.7, ease: [0.58, 0.07, 0.15, 0.72] };
function SoftFocusCard(props) {
  const { link, newTab = false, mediaType = "image", source = "upload", imageFile = DEFAULT_IMAGE, imageUrl = "", videoFile = DEFAULT_VIDEO, videoPosterFile, videoUrl = "", videoPosterUrl = "", focalX = 50, focalY = 50, logoSource = "upload", logo, logoUrl = "", logoWidth = 160, overlay = DEFAULT_OVERLAY, border, radius = "16px", mask = DEFAULT_MASK, playback = DEFAULT_PLAYBACK, hover = DEFAULT_HOVER, transition = DEFAULT_TRANSITION, style } = props;
  const { enabled: overlayEnabled = DEFAULT_OVERLAY.enabled, color: overlayColor = DEFAULT_OVERLAY.color } = overlay || DEFAULT_OVERLAY;
  const { shape: maskShape = DEFAULT_MASK.shape, blur: maskBlur = DEFAULT_MASK.blur, blurHeight: maskBlurHeight = DEFAULT_MASK.blurHeight, size: maskSize = DEFAULT_MASK.size } = mask || DEFAULT_MASK;
  const { autoplay = DEFAULT_PLAYBACK.autoplay, pauseHover = DEFAULT_PLAYBACK.pauseHover, playHover = DEFAULT_PLAYBACK.playHover, muted: videoMuted = DEFAULT_PLAYBACK.muted, unmuteHover = DEFAULT_PLAYBACK.unmuteHover } = playback || DEFAULT_PLAYBACK;
  const { blur: hoverBlur = DEFAULT_HOVER.blur, mediaZoom = DEFAULT_HOVER.mediaZoom, logoZoom = DEFAULT_HOVER.logoZoom } = hover || DEFAULT_HOVER;
  const bw = border?.borderWidth;
  const frameTop = border?.borderTopWidth ?? bw ?? 0;
  const frameRight = border?.borderRightWidth ?? bw ?? 0;
  const frameBottom = border?.borderBottomWidth ?? bw ?? 0;
  const frameLeft = border?.borderLeftWidth ?? bw ?? 0;
  const frameColor = border?.borderColor;
  const hasFrame = Math.max(frameTop, frameRight, frameBottom, frameLeft) > 0 && !!frameColor;
  const mediaElStyle = { width: "100%", height: "100%", objectFit: "cover", objectPosition: `${focalX}% ${focalY}%`, display: "block" };
  const isStatic = useIsStaticRenderer();
  const containerRef = useRef(null);
  const videoRef = useRef(null);
  const [hovered, setHovered] = useState(false);
  const inView = useInView(containerRef, { margin: "256px" });
  const active = isStatic || inView;
  const isVideo = mediaType === "video";
  const isUpload = source === "upload";
  const imageSrc = isUpload ? imageFile?.src : imageUrl;
  const imageSrcSet = isUpload ? imageFile?.srcSet : void 0;
  const imageAlt = isUpload ? imageFile?.alt ?? "" : "";
  const videoSrc = (isUpload ? videoFile : videoUrl) || DEFAULT_VIDEO;
  const posterSrc = isUpload ? videoPosterFile?.src : videoPosterUrl;
  const logoSrc = logoSource === "upload" ? logo?.src : logoUrl;
  const videoPlaying = !isStatic && isVideo && inView && (autoplay ? !(pauseHover && hovered) : playHover && hovered);
  useEffect(() => {
    if (!isVideo)
      return;
    if (!isStatic && autoplay)
      return;
    const v = videoRef.current;
    if (!v)
      return;
    const showFirstFrame = () => {
      try {
        if (v.paused && v.currentTime < 0.01)
          v.currentTime = 0.05;
      } catch (e) {
      }
    };
    if (v.readyState >= 1)
      showFirstFrame();
    v.addEventListener("loadedmetadata", showFirstFrame);
    return () => v.removeEventListener("loadedmetadata", showFirstFrame);
  }, [isVideo, videoSrc, isStatic, autoplay]);
  useEffect(() => {
    if (isStatic || !isVideo)
      return;
    const v = videoRef.current;
    if (!v)
      return;
    if (videoPlaying) {
      const p = v.play();
      if (p && typeof p.catch === "function")
        p.catch(() => {
        });
    } else {
      v.pause();
    }
  }, [isStatic, isVideo, videoPlaying, videoSrc]);
  useEffect(() => {
    if (!isVideo)
      return;
    const v = videoRef.current;
    if (!v)
      return;
    v.muted = videoMuted ? !(unmuteHover && hovered) : false;
  }, [isVideo, videoMuted, unmuteHover, hovered, videoSrc]);
  const mediaEl = isVideo ? isStatic && posterSrc ? /* @__PURE__ */ _jsx("img", { src: posterSrc, alt: "", draggable: false, style: mediaElStyle }) : /* @__PURE__ */ _jsx("video", { ref: videoRef, src: active ? videoSrc : void 0, poster: posterSrc || void 0, muted: videoMuted, loop: true, playsInline: true, preload: isStatic ? "metadata" : !active ? "none" : autoplay ? "auto" : "metadata", style: mediaElStyle }) : /* @__PURE__ */ _jsx("img", { src: imageSrc || void 0, srcSet: imageSrcSet, alt: imageAlt, draggable: false, style: mediaElStyle });
  const rootStyle = { position: "relative", width: "100%", height: "100%", ...style };
  const cardStyle = { position: "absolute", inset: 0, overflow: "hidden", boxSizing: "border-box", borderRadius: radius, borderStyle: hasFrame ? border?.borderStyle ?? "solid" : void 0, borderColor: hasFrame ? frameColor : void 0, borderTopWidth: hasFrame ? frameTop : void 0, borderRightWidth: hasFrame ? frameRight : void 0, borderBottomWidth: hasFrame ? frameBottom : void 0, borderLeftWidth: hasFrame ? frameLeft : void 0 };
  const mediaLayerStyle = { position: "absolute", inset: 0 };
  const logoImgStyle = { display: "block", width: logoWidth, maxWidth: "100%", maxHeight: "100%", height: "auto", objectFit: "contain", userSelect: "none" };
  const Root = link ? "a" : "div";
  return /* @__PURE__ */ _jsx(Root, { ref: containerRef, style: link ? { ...rootStyle, display: "block", textDecoration: "none", color: "inherit" } : rootStyle, ...link ? { href: link, target: newTab ? "_blank" : void 0, rel: newTab ? "noopener noreferrer" : void 0 } : { role: "img" }, "aria-label": logo?.alt || imageAlt || "Media card", onMouseEnter: isStatic ? void 0 : () => setHovered(true), onMouseLeave: isStatic ? void 0 : () => setHovered(false), children: /* @__PURE__ */ _jsxs("div", { style: cardStyle, children: [isStatic ? /* @__PURE__ */ _jsx("div", { style: mediaLayerStyle, children: mediaEl }) : /* @__PURE__ */ _jsx(motion.div, { style: { ...mediaLayerStyle, willChange: "transform, filter" }, animate: { scale: hovered ? mediaZoom : 1, filter: `blur(${hovered ? hoverBlur : 0}px)` }, transition: transition ?? void 0, children: mediaEl }), maskBlur > 0 && maskShape === "bottom" && maskBlurHeight > 0 && /* @__PURE__ */ _jsx("div", { style: { position: "absolute", left: 0, right: 0, bottom: 0, height: `${maskBlurHeight}%`, backdropFilter: `blur(${maskBlur}px)`, WebkitBackdropFilter: `blur(${maskBlur}px)`, WebkitMaskImage: "linear-gradient(to top, rgba(0,0,0,1) 0%, rgba(0,0,0,1) 22%, rgba(0,0,0,0) 100%)", maskImage: "linear-gradient(to top, rgba(0,0,0,1) 0%, rgba(0,0,0,1) 22%, rgba(0,0,0,0) 100%)", pointerEvents: "none" } }), maskBlur > 0 && maskShape === "vignette" && maskSize > 0 && (() => {
    const inner = Math.max(0, 100 - maskSize);
    const gradient = `radial-gradient(ellipse closest-side at center, rgba(0,0,0,0) ${inner}%, rgba(0,0,0,1) ${inner + 35}%)`;
    return /* @__PURE__ */ _jsx("div", { style: { position: "absolute", inset: 0, backdropFilter: `blur(${maskBlur}px)`, WebkitBackdropFilter: `blur(${maskBlur}px)`, WebkitMaskImage: gradient, maskImage: gradient, pointerEvents: "none" } });
  })(), overlayEnabled && overlayColor && /* @__PURE__ */ _jsx("div", { style: { position: "absolute", inset: 0, background: overlayColor, pointerEvents: "none" } }), logoSrc && /* @__PURE__ */ _jsx("div", { style: { position: "absolute", left: "10%", right: "10%", top: "10%", bottom: "10%", display: "flex", alignItems: "center", justifyContent: "center", pointerEvents: "none" }, children: isStatic ? /* @__PURE__ */ _jsx("img", { src: logoSrc, srcSet: logoSource === "upload" ? logo?.srcSet : void 0, alt: logoSource === "upload" ? logo?.alt ?? "" : "", draggable: false, style: logoImgStyle }) : /* @__PURE__ */ _jsx(motion.img, { src: logoSrc, srcSet: logoSource === "upload" ? logo?.srcSet : void 0, alt: logoSource === "upload" ? logo?.alt ?? "" : "", draggable: false, style: logoImgStyle, animate: { scale: hovered ? logoZoom : 1 }, transition: transition ?? void 0 }) })] }) });
}
SoftFocusCard.displayName = "Soft Focus Card";
addPropertyControls(SoftFocusCard, { link: { type: ControlType.Link, title: "Link" }, newTab: { type: ControlType.Boolean, title: "New Tab", defaultValue: false, enabledTitle: "Yes", disabledTitle: "No", hidden: (p) => !p.link }, mediaType: { type: ControlType.Enum, title: "Media", options: ["image", "video"], optionTitles: ["Image", "Video"], defaultValue: "image", displaySegmentedControl: true }, source: { type: ControlType.Enum, title: "Source Media", options: ["upload", "url"], optionTitles: ["Upload", "URL"], defaultValue: "upload", displaySegmentedControl: true }, imageFile: { type: ControlType.ResponsiveImage, title: "Image", hidden: (p) => p.mediaType !== "image" || p.source !== "upload" }, imageUrl: { type: ControlType.String, title: "Image URL", placeholder: "https://\u2026", defaultValue: "", hidden: (p) => p.mediaType !== "image" || p.source !== "url" }, videoFile: { type: ControlType.File, title: "Video", allowedFileTypes: ["mp4", "webm", "mov"], hidden: (p) => p.mediaType !== "video" || p.source !== "upload" }, videoPosterFile: { type: ControlType.ResponsiveImage, title: "Poster", hidden: (p) => p.mediaType !== "video" || p.source !== "upload" }, videoUrl: { type: ControlType.String, title: "Video URL", placeholder: "https://\u2026.mp4", defaultValue: "", hidden: (p) => p.mediaType !== "video" || p.source !== "url" }, videoPosterUrl: { type: ControlType.String, title: "Poster URL", placeholder: "https://\u2026", defaultValue: "", hidden: (p) => p.mediaType !== "video" || p.source !== "url" }, playback: { type: ControlType.Object, title: "Playback", icon: "interaction", defaultValue: DEFAULT_PLAYBACK, hidden: (p) => p.mediaType !== "video", controls: { autoplay: { type: ControlType.Boolean, title: "Autoplay", defaultValue: true, enabledTitle: "Yes", disabledTitle: "No" }, pauseHover: { type: ControlType.Boolean, title: "Pause Hover", defaultValue: false, enabledTitle: "Yes", disabledTitle: "No", hidden: (p) => !p.autoplay }, playHover: { type: ControlType.Boolean, title: "Play Hover", defaultValue: true, enabledTitle: "Yes", disabledTitle: "No", hidden: (p) => p.autoplay }, muted: { type: ControlType.Boolean, title: "Muted", defaultValue: true, enabledTitle: "Yes", disabledTitle: "No" }, unmuteHover: { type: ControlType.Boolean, title: "Unmute Hover", defaultValue: false, enabledTitle: "Yes", disabledTitle: "No", hidden: (p) => !p.muted } } }, focalX: { type: ControlType.Number, title: "Focal X", defaultValue: 50, min: 0, max: 100, step: 1, unit: "%" }, focalY: { type: ControlType.Number, title: "Focal Y", defaultValue: 50, min: 0, max: 100, step: 1, unit: "%" }, logoSource: { type: ControlType.Enum, title: "Source Logo", options: ["upload", "url"], optionTitles: ["Upload", "URL"], defaultValue: "upload", displaySegmentedControl: true }, logo: { type: ControlType.ResponsiveImage, title: "Logo", hidden: (p) => p.logoSource !== "upload" }, logoUrl: { type: ControlType.String, title: "Logo URL", placeholder: "https://\u2026", defaultValue: "", hidden: (p) => p.logoSource !== "url" }, logoWidth: { type: ControlType.Number, title: "Logo Width", defaultValue: 160, min: 20, max: 600, step: 1, unit: "px", hidden: (p) => p.logoSource === "url" ? !p.logoUrl : !p.logo?.src }, overlay: { type: ControlType.Object, title: "Overlay", icon: "color", defaultValue: DEFAULT_OVERLAY, controls: { enabled: { type: ControlType.Boolean, title: "Overlay", defaultValue: true, enabledTitle: "On", disabledTitle: "Off" }, color: { type: ControlType.Color, title: "Color", defaultValue: "rgba(0, 0, 0, 0.12)", hidden: (p) => !p.enabled } } }, border: { type: ControlType.Border, title: "Border", optional: true, defaultValue: DEFAULT_BORDER }, radius: { type: ControlType.BorderRadius, title: "Radius", defaultValue: "16px" }, mask: { type: ControlType.Object, title: "Mask", icon: "effect", defaultValue: DEFAULT_MASK, controls: { shape: { type: ControlType.Enum, title: "Shape", options: ["bottom", "vignette"], optionTitles: ["Bottom", "Vignette"], defaultValue: "bottom", displaySegmentedControl: true }, blur: { type: ControlType.Number, title: "Blur", defaultValue: 12, min: 0, max: 40, step: 1, unit: "px" }, blurHeight: { type: ControlType.Number, title: "Blur Height", defaultValue: 45, min: 0, max: 100, step: 1, unit: "%", hidden: (p) => p.shape !== "bottom" }, size: { type: ControlType.Number, title: "Size", defaultValue: 40, min: 0, max: 100, step: 1, unit: "%", hidden: (p) => p.shape !== "vignette" } } }, hover: { type: ControlType.Object, title: "Hover", icon: "interaction", defaultValue: DEFAULT_HOVER, controls: { blur: { type: ControlType.Number, title: "Blur", defaultValue: 8, min: 0, max: 60, step: 1, unit: "px" }, mediaZoom: { type: ControlType.Number, title: "Media Zoom", defaultValue: 1.05, min: 1, max: 1.6, step: 0.01 }, logoZoom: { type: ControlType.Number, title: "Logo Zoom", defaultValue: 0.8, min: 0.2, max: 2, step: 0.01 } } }, transition: { type: ControlType.Transition, title: "Transition", defaultValue: DEFAULT_TRANSITION } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "SoftFocusCard", "slots": [], "annotations": { "framerIntrinsicWidth": "520", "framerSupportedLayoutWidth": "any-prefer-fixed", "framerSupportedLayoutHeight": "any-prefer-fixed", "framerContractVersion": "1", "framerIntrinsicHeight": "390" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  SoftFocusCard as default
};
