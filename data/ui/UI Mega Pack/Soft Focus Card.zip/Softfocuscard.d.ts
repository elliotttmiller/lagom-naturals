export interface SoftfocuscardProps {
  /**
   * Link
   */
  link?: string;
  /**
   * New Tab
   * @default false
   */
  newTab?: boolean;
  /**
   * Media — pass as `mediaType` not `media`.
   * Options: "image" | "video"
   * @default "image"
   */
  mediaType?: 'image' | 'video';
  /**
   * Source Media — pass as `source` not `sourceMedia`.
   * Options: "upload" | "url"
   * @default "upload"
   */
  source?: 'upload' | 'url';
  /**
   * Image — pass as `imageFile` not `image`.
   */
  imageFile?: string;
  /**
   * Image URL
   * @default ""
   */
  imageUrl?: string;
  /**
   * Video — pass as `videoFile` not `video`.
   */
  videoFile?: string;
  /**
   * Poster — pass as `videoPosterFile` not `poster`.
   */
  videoPosterFile?: string;
  /**
   * Video URL
   * @default ""
   */
  videoUrl?: string;
  /**
   * Poster URL — pass as `videoPosterUrl` not `posterUrl`.
   * @default ""
   */
  videoPosterUrl?: string;
  /**
   * Playback
   */
  playback?: Record<string, unknown>;
  /**
   * Focal X
   * Range: min: 0, max: 100, step: 1
   * @default 50
   */
  focalX?: number;
  /**
   * Focal Y
   * Range: min: 0, max: 100, step: 1
   * @default 50
   */
  focalY?: number;
  /**
   * Source Logo — pass as `logoSource` not `sourceLogo`.
   * Options: "upload" | "url"
   * @default "upload"
   */
  logoSource?: 'upload' | 'url';
  /**
   * Logo
   */
  logo?: string;
  /**
   * Logo URL
   * @default ""
   */
  logoUrl?: string;
  /**
   * Logo Width
   * Range: min: 20, max: 600, step: 1
   * @default 160
   */
  logoWidth?: number;
  /**
   * Overlay
   */
  overlay?: Record<string, unknown>;
  /**
   * Border
   */
  border?: string;
  /**
   * Radius
   * @default "16px"
   */
  radius?: string;
  /**
   * Mask
   */
  mask?: Record<string, unknown>;
  /**
   * Hover
   */
  hover?: Record<string, unknown>;
  /**
   * Transition
   */
  transition?: object;
  /** Additional properties */
  [key: string]: unknown;
}
