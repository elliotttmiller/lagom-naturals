export interface Sxg2in1y3Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Slide 1" → JYoNfk6qd
   *   "Slide 2" → UOW_tT3PL
   *   "Slide 3" → Wjq9afLiN
   */
  variant?: 'Slide 1' | 'Slide 2' | 'Slide 3' | 'JYoNfk6qd' | 'UOW_tT3PL' | 'Wjq9afLiN';
  /**
   * Background 1 — pass as `ecD131Nfv` not `background1`.
   */
  ecD131Nfv?: string;
  /**
   * Background 2 — pass as `IkbLTQin0` not `background2`.
   */
  IkbLTQin0?: string;
  /**
   * Background 3 — pass as `IB9DUoGes` not `background3`.
   */
  IB9DUoGes?: string;
  /**
   * Title Slide 1 — pass as `Gm81fDCRm` not `titleSlide1`.
   * @default "Title Slide 1"
   */
  Gm81fDCRm?: string;
  onGm81fDCRmChange?: string;
  /**
   * Title Slide 2 — pass as `kzaIfOcBM` not `titleSlide2`.
   * @default "Title Slide 2"
   */
  kzaIfOcBM?: string;
  onkzaIfOcBMChange?: string;
  /**
   * Title Slide 3 — pass as `KmdTWIXFX` not `titleSlide3`.
   * @default "Title Slide 3"
   */
  KmdTWIXFX?: string;
  onKmdTWIXFXChange?: string;
  /**
   * Description Slide 1 — pass as `hU90FWJ5q` not `descriptionSlide1`.
   * @default "Description Slide 1"
   */
  hU90FWJ5q?: string;
  onhU90FWJ5qChange?: string;
  /**
   * Description Slide 2 — pass as `dcvcwv8MZ` not `descriptionSlide2`.
   * @default "Description Slide 2"
   */
  dcvcwv8MZ?: string;
  ondcvcwv8MZChange?: string;
  /**
   * Description Slide 3 — pass as `gwTst_XcC` not `descriptionSlide3`.
   * @default "Description Slide 3"
   */
  gwTst_XcC?: string;
  ongwTst_XcCChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
