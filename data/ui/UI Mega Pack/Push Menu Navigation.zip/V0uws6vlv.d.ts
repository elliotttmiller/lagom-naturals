export interface V0uws6vlvProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop Closed" → pacHJjAuP
   *   "Desktop Open" → I8cBi4te1
   *   "Desktop Solid Open" → TNMcwaCL_
   *   "Desktop Solid" → Ry7KWPvyQ
   *   "Phone Closed" → tq0rchyuZ
   *   "Phone Open" → xT8hy8uQv
   *   "Phone Solid Open" → ydHkuWIoC
   *   "Phone Solid" → wbD_oSudy
   */
  variant?: 'Desktop Closed' | 'Desktop Open' | 'Desktop Solid Open' | 'Desktop Solid' | 'Phone Closed' | 'Phone Open' | 'Phone Solid Open' | 'Phone Solid' | 'pacHJjAuP' | 'tq0rchyuZ' | 'I8cBi4te1' | 'xT8hy8uQv' | 'Ry7KWPvyQ' | 'wbD_oSudy' | 'TNMcwaCL_' | 'ydHkuWIoC';
  /**
   * Header Theme — pass as `P0YdDc906` not `headerTheme`.
   * Options: "onom_gs0Q" | "snjxaIzGr"
   * @default "snjxaIzGr"
   */
  P0YdDc906?: 'onom_gs0Q' | 'snjxaIzGr';
  onP0YdDc906Change?: string;
  /**
   * Corner Radius — pass as `Au4NRzSO1` not `cornerRadius`.
   * @default 0
   */
  Au4NRzSO1?: number;
  onAu4NRzSO1Change?: string;
  /**
   * Override Code — pass as `KkRri24Ud` not `overrideCode`.
   * @default "// Installation:
// 1) Group all page sections in one native stack named "Page Content".
// 2) Keep the native nav outside that stack.
// 3) Apply PushContent → withShiftContent to the Page Content stack once.
// 4) Preview.
import { RenderTarget, useIsStaticRenderer } from "framer"
import { animate, useReducedMotion } from "framer-motion"
import {
    ComponentType,
    forwardRef,
    startTransition,
    useCallback,
    useEffect,
    useId,
    useRef,
    useState,
} from "react"

type ShiftEventDetail = {
    ownerId: string
    open: boolean
    width: number
    radius: number
    openDuration: number
    closeDuration: number
    openTransition?: TransitionPayload
    closeTransition?: TransitionPayload
    reducedMotion: boolean
    reset: boolean
}

type TransitionType = "tween" | "spring"
type EaseName =
    | "linear"
    | "easeIn"
    | "easeOut"
    | "easeInOut"
    | "circIn"
    | "circOut"
    | "circInOut"
    | "backIn"
    | "backOut"
    | "backInOut"
    | "anticipate"

type TransitionPayload = {
    type?: TransitionType
    duration?: number
    delay?: number
    ease?: EaseName | [number, number, number, number]
    stiffness?: number
    damping?: number
    mass?: number
    bounce?: number
    restSpeed?: number
    restDelta?: number
    velocity?: number
}

type ShiftRequestDetail = {
    targetId: string
}

const SHIFT_STATE_EVENT = "spm:state"
const SHIFT_REQUEST_EVENT = "spm:request"

function toFinite(value: any): number | undefined {
    return typeof value === "number" && Number.isFinite(value) ? value : undefined
}

function clamp(value: number, min: number, max: number) {
    return Math.min(max, Math.max(min, value))
}

function isValidEaseArray(value: any): value is [number, number, number, number] {
    if (!Array.isArray(value) || value.length !== 4) return false
    const [x1, y1, x2, y2] = value
    if (![x1, y1, x2, y2].every((v) => typeof v === "number" && Number.isFinite(v))) return false
    return x1 >= 0 && x1 <= 1 && x2 >= 0 && x2 <= 1
}

function isValidEaseName(value: any): value is EaseName {
    return (
        value === "linear" ||
        value === "easeIn" ||
        value === "easeOut" ||
        value === "easeInOut" ||
        value === "circIn" ||
        value === "circOut" ||
        value === "circInOut" ||
        value === "backIn" ||
        value === "backOut" ||
        value === "backInOut" ||
        value === "anticipate"
    )
}

function sanitizeTransition(
    transition: TransitionPayload | undefined,
    fallback: { type: "tween"; duration: number; delay: number; ease: [number, number, number, number] }
) {
    const source = transition && typeof transition === "object" ? transition : {}
    const type = source.type === "spring" ? "spring" : "tween"
    const duration = Math.max(0, toFinite(source.duration) ?? fallback.duration)
    const delay = Math.max(0, toFinite(source.delay) ?? fallback.delay)
    const ease = isValidEaseArray(source.ease)
        ? source.ease
        : isValidEaseName(source.ease)
          ? source.ease
          : fallback.ease
    const result: Record<string, any> = { type, duration, delay }
    if (type === "tween") {
        result.ease = ease
    } else {
        const stiffness = toFinite(source.stiffness)
        const damping = toFinite(source.damping)
        const mass = toFinite(source.mass)
        const bounce = toFinite(source.bounce)
        const restSpeed = toFinite(source.restSpeed)
        const restDelta = toFinite(source.restDelta)
        const velocity = toFinite(source.velocity)
        if (stiffness !== undefined) result.stiffness = clamp(stiffness, 1, 2000)
        if (damping !== undefined) result.damping = clamp(damping, 0.01, 500)
        if (mass !== undefined) result.mass = clamp(mass, 0.01, 100)
        if (bounce !== undefined) result.bounce = clamp(bounce, 0, 1)
        if (restSpeed !== undefined) result.restSpeed = clamp(restSpeed, 0.01, 200)
        if (restDelta !== undefined) result.restDelta = clamp(restDelta, 0.00001, 1)
        if (velocity !== undefined) result.velocity = velocity
    }
    return result
}

function stableStringify(value: any): string {
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`
    if (!value || typeof value !== "object") return JSON.stringify(value)
    const keys = Object.keys(value).sort()
    return `{${keys.map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(",")}}`
}

export function withShiftContent(Component: ComponentType): ComponentType {
    return forwardRef(function ShiftContentOverride(props: any, ref) {
            const localId = useId().replace(/:/g, "")
            const rootRef = useRef<HTMLElement | null>(null)
            const ownerRef = useRef<string>("")
            const [openState, setOpenState] = useState(false)
            const [activeState, setActiveState] = useState(false)
            const openRef = useRef(false)
            const activeRef = useRef(false)
            const xAnimRef = useRef<{ stop?: () => void } | null>(null)
            const radiusAnimRef = useRef<{ stop?: () => void } | null>(null)
            const currentXRef = useRef(0)
            const currentRadiusRef = useRef(0)
            const lastSignatureRef = useRef("")
            const generationRef = useRef(0)
            const isStaticRenderer = useIsStaticRenderer()
            const isCanvas = RenderTarget.current() === RenderTarget.canvas
            const isStatic = isStaticRenderer || isCanvas
            const reducedMotion = useReducedMotion()
            const prevVarRef = useRef("")
            const prevRadiusRef = useRef("")
            const prevVarPriorityRef = useRef("")
            const prevRadiusPriorityRef = useRef("")

            const mergedRef = useCallback(
                (node: any) => {
                    rootRef.current = node as HTMLElement | null
                    if (typeof ref === "function") ref(node)
                    else if (ref && typeof ref === "object") (ref as any).current = node
                },
                [ref]
            )

            useEffect(() => {
                if (isStatic) return
                const el = rootRef.current
                if (!el) return
                prevVarRef.current = el.style.getPropertyValue("--shift-push-x")
                prevRadiusRef.current = el.style.getPropertyValue("--shift-push-radius")
                prevVarPriorityRef.current = el.style.getPropertyPriority("--shift-push-x")
                prevRadiusPriorityRef.current = el.style.getPropertyPriority("--shift-push-radius")
                if (!el.style.getPropertyValue("--shift-push-x")) el.style.setProperty("--shift-push-x", "0px")
                if (!el.style.getPropertyValue("--shift-push-radius")) el.style.setProperty("--shift-push-radius", "0px")
                return () => {
                    xAnimRef.current?.stop?.()
                    radiusAnimRef.current?.stop?.()
                    if (prevVarRef.current) el.style.setProperty("--shift-push-x", prevVarRef.current, prevVarPriorityRef.current)
                    else el.style.removeProperty("--shift-push-x")
                    if (prevRadiusRef.current) {
                        el.style.setProperty("--shift-push-radius", prevRadiusRef.current, prevRadiusPriorityRef.current)
                    } else el.style.removeProperty("--shift-push-radius")
                }
            }, [isStatic])

            useEffect(() => {
                if (isStatic || typeof window === "undefined") return
                const host = window.location?.hostname ?? ""
                const isCanvasHost = host === "framercanvas.com" || host.endsWith(".framercanvas.com")

                const onState = (event: Event) => {
                    const detail = (event as CustomEvent<ShiftEventDetail>).detail
                    if (!detail) return
                    if (detail.reset) {
                        if (!ownerRef.current || ownerRef.current !== detail.ownerId) return
                        const target = rootRef.current
                        if (!target) return
                        xAnimRef.current?.stop?.()
                        radiusAnimRef.current?.stop?.()
                        generationRef.current += 1
                        target.style.setProperty("--shift-push-x", "0px")
                        target.style.setProperty("--shift-push-radius", "0px")
                        currentXRef.current = 0
                        currentRadiusRef.current = 0
                        lastSignatureRef.current = ""
                        ownerRef.current = ""
                        openRef.current = false
                        activeRef.current = false
                        startTransition(() => {
                            setOpenState(false)
                            setActiveState(false)
                        })
                        return
                    }
                    if (ownerRef.current && ownerRef.current !== detail.ownerId) return
                    if (!Number.isFinite(detail.width) || !Number.isFinite(detail.radius)) return
                    if (!Number.isFinite(detail.openDuration) || !Number.isFinite(detail.closeDuration)) return

                    const nextX = detail.open ? -Math.max(0, detail.width) : 0
                    const fallbackTransition = detail.open
                        ? { type: "tween" as const, duration: detail.openDuration, delay: 0, ease: [0.32, 0.72, 0, 1] as [number, number, number, number] }
                        : { type: "tween" as const, duration: detail.closeDuration, delay: 0, ease: [0.82, -0.01, 0.88, 0.77] as [number, number, number, number] }
                    const transitionConfig = sanitizeTransition(
                        detail.open ? detail.openTransition : detail.closeTransition,
                        fallbackTransition
                    )
                    const motionReduced = reducedMotion || detail.reducedMotion
                    const duration = motionReduced ? 0 : transitionConfig.duration
                    const target = rootRef.current
                    if (!target) return
                    if (!detail.open && !activeRef.current && nextX === 0) return
                    const nextRadius = detail.open ? Math.max(0, detail.radius) : 0
                    const signature = stableStringify({
                        open: detail.open,
                        x: nextX,
                        radius: nextRadius,
                        reduced: motionReduced,
                        transition: transitionConfig,
                    })
                    if (signature === lastSignatureRef.current) return
                    lastSignatureRef.current = signature

                    ownerRef.current = detail.ownerId
                    const nextActive = detail.open || activeRef.current
                    openRef.current = detail.open
                    activeRef.current = nextActive
                    startTransition(() => {
                        setOpenState(detail.open)
                        setActiveState(nextActive)
                    })

                    xAnimRef.current?.stop?.()
                    radiusAnimRef.current?.stop?.()
                    generationRef.current += 1
                    const gen = generationRef.current

                    if (motionReduced) {
                        currentXRef.current = nextX
                        currentRadiusRef.current = nextRadius
                        target.style.setProperty("--shift-push-x", `${nextX}px`)
                        target.style.setProperty("--shift-push-radius", `${nextRadius}px`)
                        openRef.current = detail.open
                        activeRef.current = detail.open
                        startTransition(() => {
                            setOpenState(detail.open)
                            setActiveState(detail.open)
                        })
                        return
                    }

                    const baseOptions: Record<string, any> =
                        transitionConfig.type === "spring"
                            ? {
                                  type: "spring",
                                  duration: transitionConfig.duration,
                                  delay: transitionConfig.delay,
                                  stiffness: transitionConfig.stiffness,
                                  damping: transitionConfig.damping,
                                  mass: transitionConfig.mass,
                                  bounce: transitionConfig.bounce,
                                  restSpeed: transitionConfig.restSpeed,
                                  restDelta: transitionConfig.restDelta,
                                  velocity: transitionConfig.velocity,
                              }
                            : {
                                  type: "tween",
                                  duration,
                                  delay: transitionConfig.delay,
                                  ease:
                                      transitionConfig.ease ??
                                      (detail.open ? ([0.32, 0.72, 0, 1] as [number, number, number, number]) : ([0.82, -0.01, 0.88, 0.77] as [number, number, number, number])),
                              }

                    radiusAnimRef.current = animate(currentRadiusRef.current, nextRadius, {
                        ...baseOptions,
                        onUpdate: (value) => {
                            currentRadiusRef.current = value
                            target.style.setProperty("--shift-push-radius", `${value}px`)
                        },
                    })

                    xAnimRef.current = animate(currentXRef.current, nextX, {
                        ...baseOptions,
                        onUpdate: (value) => {
                            currentXRef.current = value
                            target.style.setProperty("--shift-push-x", `${value}px`)
                        },
                        onComplete: () => {
                            if (gen !== generationRef.current) return
                            openRef.current = detail.open
                            activeRef.current = detail.open
                            startTransition(() => {
                                setOpenState(detail.open)
                                setActiveState(detail.open)
                            })
                        },
                    })
                }

                window.addEventListener(SHIFT_STATE_EVENT, onState as EventListener)
                const onUnload = () => {
                    window.removeEventListener(SHIFT_STATE_EVENT, onState as EventListener)
                    xAnimRef.current?.stop?.()
                    radiusAnimRef.current?.stop?.()
                    generationRef.current += 1
                    lastSignatureRef.current = ""
                }
                if (isCanvasHost) window.addEventListener("unload", onUnload)
                window.dispatchEvent(
                    new CustomEvent<ShiftRequestDetail>(SHIFT_REQUEST_EVENT, { detail: { targetId: localId } })
                )
                return () => {
                    window.removeEventListener(SHIFT_STATE_EVENT, onState as EventListener)
                    if (isCanvasHost) window.removeEventListener("unload", onUnload)
                    xAnimRef.current?.stop?.()
                    radiusAnimRef.current?.stop?.()
                    generationRef.current += 1
                    lastSignatureRef.current = ""
                }
            }, [isStatic, localId, reducedMotion])

            if (isStatic) return <Component {...props} ref={mergedRef} />

            return (
                <Component
                    {...props}
                    ref={mergedRef}
                    inert={props.inert}
                    aria-hidden={props["aria-hidden"]}
                    style={{
                        ...props.style,
                        ...(activeState
                            ? {
                                  translate: "var(--shift-push-x, 0px) 0px",
                                  borderRadius: "var(--shift-push-radius, 0px)",
                              }
                            : null),
                    }}
                />
            )
        }) as unknown as ComponentType
}
"
   */
  KkRri24Ud?: string;
  onKkRri24UdChange?: string;
  /**
   * Home Link — pass as `VwPP62wTS` not `homeLink`.
   */
  VwPP62wTS?: string;
  /**
   * Work Link — pass as `ccCtHUoTt` not `workLink`.
   */
  ccCtHUoTt?: string;
  /**
   * Studio Link — pass as `lZmYQ3Ub3` not `studioLink`.
   */
  lZmYQ3Ub3?: string;
  /**
   * Contact Link — pass as `xWs6oo6du` not `contactLink`.
   */
  xWs6oo6du?: string;
  /**
   * Email Link — pass as `pZHWm1u71` not `emailLink`.
   */
  pZHWm1u71?: string;
  /**
   * Instagram Link — pass as `rcF4lpp9o` not `instagramLink`.
   */
  rcF4lpp9o?: string;
  /**
   * Linked In Link — pass as `fs8tCF0ox` not `linkedInLink`.
   */
  fs8tCF0ox?: string;
  /**
   * Twitter Link — pass as `EGkYzYKqt` not `twitterLink`.
   */
  EGkYzYKqt?: string;
  /**
   * Phone Link — pass as `p_GZ0pSYg` not `phoneLink`.
   */
  p_GZ0pSYg?: string;
  /**
   * Hover Fill — pass as `HsJUYW36o` not `hoverFill`.
   * @default "rgb(238, 239, 120)"
   */
  HsJUYW36o?: string;
  /**
   * Open Transition — pass as `axnAWdIZu` not `openTransition`.
   * @default {"delay":0,"duration":0.7,"ease":[0.32,0.72,0,1],"type":"tween"}
   */
  axnAWdIZu?: object;
  /**
   * Close Transition — pass as `tKrYkJa5D` not `closeTransition`.
   * @default {"delay":0,"duration":0.6,"ease":[0.46,0.03,0.52,0.95],"type":"tween"}
   */
  tKrYkJa5D?: object;
  /**
   * Page Dim — pass as `e0NBq8DJx` not `pageDim`.
   * @default "rgba(0, 0, 0, 0.3)"
   */
  e0NBq8DJx?: string;
  /** Additional properties */
  [key: string]: unknown;
}
