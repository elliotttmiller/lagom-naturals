export interface Cgrqol12uProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → fF4rnF_5F
   *   "Phone" → ZnNguSUFC
   *   "Tablet" → ucNKVkjeq
   */
  variant?: 'Desktop' | 'Phone' | 'Tablet' | 'fF4rnF_5F' | 'ucNKVkjeq' | 'ZnNguSUFC';
  /** Additional properties */
  [key: string]: unknown;
}
