var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/S03Nh8wyaE8izo4NFNX4/Xdh61iejhXygbDOshhgG/Tabulapro.js
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState, useEffect, useMemo, useRef, useId } from "react";
import { addPropertyControls, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
var FEATURES = { search: true, filters: true, tabs: true, sort: true, resize: true, selection: true, bulkActions: true, inlineEdit: true, drawer: true, columnMenu: true, exportData: true, importData: true, pagination: true };
var TABLE = { pageSize: 10, density: "default", summary: true, dataBars: true, pinFirst: true, striped: false, tabsColumn: "", exportName: "table-export" };
var LOOK = { theme: "light", accent: "#5B5BD6", radius: 14, border: true };
function fill(base, over) {
  const out = { ...base };
  if (over) {
    for (const k in over)
      if (over[k] !== void 0 && over[k] !== null)
        out[k] = over[k];
  }
  return out;
}
function resolve(p) {
  return { source: p.source ?? "sample", csvFile: p.csvFile ?? "", csvUrl: (p.csvUrl ?? "").trim(), csvText: p.csvText ?? "", overrides: p.columns ?? [], title: p.title ?? "Customers", subtitle: p.subtitle ?? "", f: fill(FEATURES, p.features), opt: fill(TABLE, p.table), look: fill(LOOK, p.appearance), font: p.font || {}, style: p.style || {} };
}
function sniff(line) {
  let best = ",", top = 0;
  for (const d of [",", ";", "	", "|"]) {
    let n = 0, q = false;
    for (const ch of line) {
      if (ch === '"')
        q = !q;
      else if (!q && ch === d)
        n++;
    }
    if (n > top) {
      top = n;
      best = d;
    }
  }
  return best;
}
function readGrid(text) {
  const src = (text || "").replace(/^\uFEFF/, "");
  if (!src.trim())
    return [];
  const delim = sniff(src.split(/\r?\n/, 1)[0] || "");
  const out = [];
  let line = [], cell = "", quoted = false;
  const flush = () => {
    line.push(cell);
    cell = "";
    if (line.some((c) => c.trim() !== ""))
      out.push(line);
    line = [];
  };
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          cell += '"';
          i++;
        } else
          quoted = false;
      } else
        cell += ch;
    } else if (ch === '"' && cell.trim() === "") {
      quoted = true;
      cell = "";
    } else if (ch === delim) {
      line.push(cell);
      cell = "";
    } else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && src[i + 1] === "\n")
        i++;
      flush();
    } else
      cell += ch;
  }
  flush();
  return out;
}
function quoteCell(v) {
  const s = v == null ? "" : String(v);
  return /[",;\t\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
var NUM = new Intl.NumberFormat(void 0, { maximumFractionDigits: 2 });
var DAY = new Intl.DateTimeFormat(void 0, { year: "numeric", month: "short", day: "numeric" });
var ORDER = new Intl.Collator(void 0, { numeric: true, sensitivity: "base" });
var pad2 = (n) => String(n).padStart(2, "0");
function toNum(v) {
  let s = (v ?? "").trim();
  if (!s)
    return NaN;
  let mult = 1;
  const suf = s.match(/(\d)\s*([kmb])$/i);
  if (suf) {
    mult = { k: 1e3, m: 1e6, b: 1e9 }[suf[2].toLowerCase()];
    s = s.slice(0, -1);
  }
  const neg = /^\(.*\)$/.test(s) || /^[^\d]*-/.test(s);
  s = s.replace(/[^0-9.eE]/g, "");
  if (!s)
    return NaN;
  const n = parseFloat(s);
  return isNaN(n) ? NaN : (neg ? -n : n) * mult;
}
function toTime(v) {
  const s = (v ?? "").trim();
  const iso = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (iso)
    return new Date(+iso[1], +iso[2] - 1, +iso[3]).getTime();
  const t = Date.parse(s);
  return isNaN(t) ? NaN : t;
}
var truthy = (v) => /^(true|yes|y|1)$/i.test((v || "").trim());
var numeric = (k) => k === "number" || k === "currency" || k === "percent";
function guessKind(label, values) {
  const vals = values.filter((v) => v !== "").slice(0, 400);
  if (!vals.length)
    return "text";
  const all = (re) => vals.every((v) => re.test(v));
  const L = label.toLowerCase();
  if (all(/^https?:\/\/\S+$/i)) {
    if (/avatar|photo|image|picture|logo|thumb|headshot/.test(L) || all(/\.(png|jpe?g|webp|gif|avif|svg)(\?\S*)?$/i))
      return "image";
    return "url";
  }
  if (all(/^[^\s@]+@[^\s@]+\.[^\s@]+$/))
    return "email";
  if (all(/^(true|false|yes|no)$/i))
    return "boolean";
  if (all(/^-?[\d,]*\.?\d+\s?%$/))
    return "percent";
  if (all(/^(-?\s?[$€£¥₹]\s?-?[\d,]*\.?\d+[kmb]?|-?[\d,]*\.?\d+\s?[$€£¥₹])$/i))
    return "currency";
  if (all(/^-?[\d,]*\.?\d+(e[+-]?\d+)?$/i))
    return "number";
  if (vals.every((v) => /\d/.test(v) && /[-/]|[a-z]{3}/i.test(v) && !isNaN(toTime(v))))
    return "date";
  const distinct = new Set(vals.map((v) => v.toLowerCase())).size;
  const hinted = /status|stage|state|priority|tier|plan|category|role|level|segment|type|health/.test(L);
  if (hinted && distinct <= 8 && (vals.length < 4 || distinct <= vals.length / 1.5))
    return "status";
  if (!hinted && distinct <= 5 && vals.length >= 10)
    return "status";
  return "text";
}
var KINDS = ["text", "number", "currency", "percent", "date", "boolean", "status", "email", "url", "image"];
var NAMEY = /(^|\b)(name|full name|customer|client|user|member|employee|contact|owner|person|account|lead|assignee|company|title|product)(\b|$)/i;
function buildSheet(text, overrides, facetName) {
  const grid = readGrid(text);
  if (!grid.length)
    return { columns: [], rows: [], identity: null, avatar: null, facet: null };
  const head = grid[0];
  const span = grid.reduce((m, r) => Math.max(m, r.length), 0);
  const used = /* @__PURE__ */ new Set();
  const columns = [];
  for (let i = 0; i < span; i++) {
    const label = (head[i] || "").trim() || `Column ${i + 1}`;
    const stem = label.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || `col_${i + 1}`;
    let key = stem, n = 2;
    while (used.has(key) || key === "__id")
      key = `${stem}_${n++}`;
    used.add(key);
    columns.push({ key, label, type: "text", index: i, width: 0, visible: true, unit: "", avgLen: 8 });
  }
  const rows = grid.slice(1).map((line, i) => {
    const o = { __id: `r${i}` };
    for (const c of columns)
      o[c.key] = (line[c.index] ?? "").trim();
    return o;
  });
  for (const c of columns) {
    const vals = rows.map((r) => r[c.key]);
    c.type = guessKind(c.label, vals);
    const sample = vals.filter(Boolean).slice(0, 200);
    c.avgLen = sample.length ? sample.reduce((s, v) => s + v.length, 0) / sample.length : 6;
    if (c.type === "currency")
      c.unit = (sample.find((v) => /[$€£¥₹]/.test(v)) || "").match(/[$€£¥₹]/)?.[0] || "";
  }
  const touched = /* @__PURE__ */ new Set();
  for (const ov of overrides || []) {
    const m = (ov?.match || "").trim().toLowerCase();
    if (!m)
      continue;
    const c = columns.find((x) => x.label.toLowerCase() === m || x.key === m);
    if (!c)
      continue;
    touched.add(c.key);
    if (ov.label)
      c.label = ov.label;
    if (ov.type && ov.type !== "auto" && KINDS.includes(ov.type))
      c.type = ov.type;
    if (ov.visible === false)
      c.visible = false;
    if (ov.width && ov.width > 0)
      c.width = ov.width;
  }
  const identity = columns.find((c) => c.type === "text" && NAMEY.test(c.label)) || null;
  const avatar = columns.find((c) => c.type === "image") || null;
  if (identity && avatar && !touched.has(avatar.key))
    avatar.visible = false;
  const wanted = (facetName || "").trim().toLowerCase();
  const facet = wanted && columns.find((c) => c.label.toLowerCase() === wanted || c.key === wanted) || columns.find((c) => c.type === "status" && /status|stage|state/i.test(c.label)) || columns.find((c) => c.type === "status") || null;
  return { columns, rows, identity: identity?.key ?? null, avatar: avatar?.key ?? null, facet: facet?.key ?? null };
}
function show(c, raw) {
  if (raw == null || raw === "")
    return "";
  switch (c.type) {
    case "number": {
      const n = toNum(raw);
      return isNaN(n) ? raw : NUM.format(n);
    }
    case "currency": {
      const n = toNum(raw);
      if (isNaN(n))
        return raw;
      const sym = raw.match(/[$€£¥₹]/)?.[0] ?? c.unit;
      return (n < 0 ? "\u2212" : "") + sym + NUM.format(Math.abs(n));
    }
    case "percent": {
      const n = toNum(raw);
      return isNaN(n) ? raw : NUM.format(n) + "%";
    }
    case "date": {
      const t = toTime(raw);
      return isNaN(t) ? raw : DAY.format(t);
    }
    case "boolean":
      return truthy(raw) ? "Yes" : "No";
    case "url":
      return raw.replace(/^https?:\/\/(www\.)?/i, "").replace(/\/$/, "");
    default:
      return raw;
  }
}
function showTotal(c, n) {
  if (!isFinite(n))
    return "\u2014";
  if (c.type === "currency")
    return (n < 0 ? "\u2212" : "") + c.unit + NUM.format(Math.abs(n));
  if (c.type === "percent")
    return NUM.format(n) + "%";
  return NUM.format(n);
}
function compareRaw(c, a, b) {
  if (numeric(c.type))
    return toNum(a) - toNum(b);
  if (c.type === "date")
    return toTime(a) - toTime(b);
  if (c.type === "boolean")
    return Number(truthy(a)) - Number(truthy(b));
  return ORDER.compare(a, b);
}
function tallies(cols, rows) {
  const out = {};
  for (const c of cols) {
    if (!numeric(c.type))
      continue;
    const t = { min: Infinity, max: -Infinity, sum: 0, count: 0 };
    for (const r of rows) {
      const n = toNum(r[c.key]);
      if (isNaN(n))
        continue;
      t.sum += n;
      t.count++;
      if (n < t.min)
        t.min = n;
      if (n > t.max)
        t.max = n;
    }
    out[c.key] = t;
  }
  return out;
}
function share(c, raw, t) {
  const n = toNum(raw);
  if (isNaN(n) || !t || !t.count)
    return 0;
  if (c.type === "percent" && t.max <= 100 && t.min >= 0)
    return Math.max(0, Math.min(1, n / 100));
  if (t.min >= 0)
    return t.max > 0 ? Math.max(0, Math.min(1, n / t.max)) : 0;
  return t.max > t.min ? (n - t.min) / (t.max - t.min) : 0;
}
function colWidth(c, isId, bars, set) {
  if (set)
    return set;
  if (c.width > 0)
    return c.width;
  if (isId)
    return 240;
  switch (c.type) {
    case "email":
      return 230;
    case "url":
      return 190;
    case "status":
      return 140;
    case "date":
      return 136;
    case "boolean":
      return 104;
    case "image":
      return 84;
    case "number":
    case "currency":
    case "percent":
      return bars ? 176 : 124;
    default:
      return Math.round(Math.max(120, Math.min(300, c.avgLen * 7.4 + 40)));
  }
}
var TONES = { green: ["#15803d", "#4ade80"], amber: ["#b45309", "#fbbf24"], red: ["#b91c1c", "#f87171"], gray: ["#52525b", "#a1a1aa"], blue: ["#1d4ed8", "#60a5fa"], violet: ["#6d28d9", "#a78bfa"], teal: ["#0f766e", "#2dd4bf"], pink: ["#be185d", "#f472b6"] };
function toneName(value) {
  const v = (value || "").toLowerCase().trim();
  if (/(inactive|fail|overdue|past due|cancel|reject|churn|block|error|declin|lost|suspend|expired|out of stock|critical|urgent|^high$)/.test(v))
    return "red";
  if (/(draft|archiv|paused|disabled|closed|offline|unknown|^none$|^no$|^low$|n\/a)/.test(v))
    return "gray";
  if (/(pending|trial|review|progress|processing|await|hold|scheduled|low stock|warning|onboard|invited|^medium$|on leave)/.test(v))
    return "amber";
  if (/(active|paid|done|complet|success|online|approv|live|healthy|won|resolv|shipped|deliver|enabled|publish|verified|in stock|^yes$)/.test(v))
    return "green";
  const keys = ["blue", "violet", "teal", "pink", "gray"];
  let h = 0;
  for (let i = 0; i < v.length; i++)
    h = h * 31 + v.charCodeAt(i) >>> 0;
  return keys[h % keys.length];
}
var tone = (name, dark) => TONES[name][dark ? 1 : 0];
function pillStyle(value, dark) {
  const t = tone(toneName(value), dark);
  return { display: "inline-flex", alignItems: "center", gap: 6, height: 22, padding: "0 9px 0 8px", borderRadius: 999, fontSize: "0.86em", fontWeight: 500, color: t, background: `color-mix(in srgb, ${t} ${dark ? 16 : 11}%, transparent)`, maxWidth: "100%", overflow: "hidden", whiteSpace: "nowrap", verticalAlign: "middle" };
}
function dotStyle(value, dark) {
  return { width: 6, height: 6, borderRadius: 3, flex: "none", background: tone(toneName(value), dark) };
}
function initials(s) {
  const parts = (s || "?").trim().split(/\s+/).filter(Boolean);
  return ((parts[0]?.[0] || "?") + (parts.length > 1 ? parts[parts.length - 1][0] : "")).toUpperCase();
}
function badgeStyle(name, dark, size) {
  const t = tone(toneName(name + "\xB7"), dark);
  return { width: size, height: size, borderRadius: "50%", flex: "none", display: "grid", placeItems: "center", fontSize: size * 0.38, fontWeight: 600, letterSpacing: "0.02em", color: t, background: `color-mix(in srgb, ${t} ${dark ? 20 : 13}%, transparent)`, overflow: "hidden" };
}
var LIGHT = { bg: "#ffffff", panel: "#ffffff", head: "#fafafb", stripe: "#fbfbfc", hover: "#f5f5f7", line: "#e8e8ec", edge: "#c9c9d2", text: "#16161a", muted: "#686874", subtle: "#9d9da8", shadow: "0 18px 44px -16px rgba(20,20,30,.24), 0 2px 6px rgba(20,20,30,.05)", scrim: "rgba(18,18,24,.16)" };
var DARK = { bg: "#0f0f12", panel: "#16161b", head: "#131317", stripe: "#121216", hover: "#1a1a20", line: "#26262d", edge: "#3b3b45", text: "#ececf1", muted: "#9c9ca8", subtle: "#6d6d79", shadow: "0 18px 44px -14px rgba(0,0,0,.7)", scrim: "rgba(0,0,0,.45)" };
function paint(dark, accent, radius) {
  const t = dark ? DARK : LIGHT;
  return { "--bg": t.bg, "--panel": t.panel, "--head": t.head, "--row": t.bg, "--stripe": t.stripe, "--hover": t.hover, "--line": t.line, "--edge": t.edge, "--text": t.text, "--muted": t.muted, "--subtle": t.subtle, "--shadow": t.shadow, "--scrim": t.scrim, "--ac": accent, "--danger": TONES.red[dark ? 1 : 0], "--ac-soft": `color-mix(in srgb, ${accent} 13%, transparent)`, "--sel": `color-mix(in srgb, ${accent} 7%, ${t.bg})`, "--selh": `color-mix(in srgb, ${accent} 11%, ${t.bg})`, "--r": `${radius}px`, "--r2": `${Math.max(6, Math.min(radius, 12) - 2)}px`, colorScheme: dark ? "dark" : "light" };
}
var SAMPLE_CSV = (() => {
  const first = ["Ava", "Liam", "Maya", "Noah", "Iris", "Omar", "Zoe", "Kai", "Lena", "Arjun", "Nora", "Theo", "Priya", "Felix", "Mila", "Ezra", "Sara", "Hugo", "Anika", "Leo"];
  const last = ["Hart", "Okafor", "Lindqvist", "Rivera", "Moreau", "Tanaka", "Shah", "Novak", "Brooks", "Castillo", "Weber", "Aydin", "Mehta", "Quinn"];
  const orgs = ["Bluepeak Labs", "Harbor Works", "Northline Studio", "Quarry Digital", "Solace Health", "Tidewell", "Copperfield", "Brightloom", "Fernway Freight", "Juniper Analytics", "Oakridge Legal", "Lumen Retail"];
  const plans = [["Starter", 49], ["Growth", 149], ["Scale", 449], ["Enterprise", 1290]];
  const states = ["Active", "Active", "Active", "Active", "Trial", "Past due", "Churned"];
  const lands = ["India", "United States", "Germany", "Japan", "Brazil", "Canada", "France", "Australia"];
  let seed = 20261;
  const rnd = () => (seed = seed * 16807 % 2147483647) / 2147483647;
  const pick = (a) => a[Math.floor(rnd() * a.length)];
  const out = ["Customer,Email,Company,Plan,Status,MRR,Seats,Health,Joined,Country"];
  for (let i = 0; i < 64; i++) {
    const f = pick(first), l = pick(last), org = pick(orgs);
    const [plan, price] = pick(plans);
    const big = plan === "Enterprise";
    const seats = big ? 40 + Math.floor(rnd() * 180) : 2 + Math.floor(rnd() * 30);
    const mrr = price + (big ? Math.floor(rnd() * 8) * 250 : Math.floor(rnd() * 5) * 10);
    const status = pick(states);
    const health = status === "Churned" ? 4 + Math.floor(rnd() * 22) : status === "Past due" ? 30 + Math.floor(rnd() * 30) : 55 + Math.floor(rnd() * 45);
    const d = new Date(2024, Math.floor(rnd() * 26), 1 + Math.floor(rnd() * 27));
    const mail = `${f}.${l}@${org.replace(/[^a-z]/gi, "")}.com`.toLowerCase();
    out.push([`${f} ${l}`, mail, org, plan, status, `$${mrr.toLocaleString("en-US")}`, seats, `${health}%`, `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`, pick(lands)].map(quoteCell).join(","));
  }
  return out.join("\n");
})();
function useSheet(r) {
  const target = r.source === "file" ? r.csvFile : r.source === "url" ? r.csvUrl : "";
  const [remote, setRemote] = useState({ url: "", text: "", error: "", busy: false });
  useEffect(() => {
    if (!target)
      return;
    let alive = true;
    setRemote({ url: target, text: "", error: "", busy: true });
    fetch(target).then((res) => {
      if (!res.ok)
        throw new Error(String(res.status));
      return res.text();
    }).then((text2) => {
      if (alive)
        setRemote({ url: target, text: text2, error: "", busy: false });
    }).catch(() => {
      if (alive)
        setRemote({ url: target, text: "", error: "The CSV couldn't be loaded. Check the link is public.", busy: false });
    });
    return () => {
      alive = false;
    };
  }, [target]);
  const text = r.source === "text" ? r.csvText : target ? remote.url === target ? remote.text : "" : SAMPLE_CSV;
  const ovKey = JSON.stringify(r.overrides || []);
  const sheet = useMemo(() => buildSheet(text, r.overrides, r.opt.tabsColumn), [text, ovKey, r.opt.tabsColumn]);
  const loading = !!target && (remote.url !== target || remote.busy);
  const error = target && remote.url === target ? remote.error : "";
  return { sheet, loading, error };
}
function StillTable(props) {
  const r = resolve(props);
  const { f, opt, look } = r;
  const { sheet, loading } = useSheet(r);
  const dark = look.theme === "dark";
  const cols = sheet.columns.filter((c) => c.visible);
  const shown = sheet.rows.slice(0, f.pagination ? Math.max(1, opt.pageSize) : 40);
  const stats = tallies(cols, sheet.rows);
  const facet = f.tabs && sheet.facet ? sheet.columns.find((c) => c.key === sheet.facet) : null;
  const facetVals = [];
  if (facet) {
    const m = /* @__PURE__ */ new Map();
    for (const row of sheet.rows) {
      const v = row[facet.key];
      if (!v)
        continue;
      const e = m.get(v.toLowerCase());
      if (e)
        e.n++;
      else
        m.set(v.toLowerCase(), { label: v, n: 1 });
    }
    facetVals.push(...Array.from(m.values()).slice(0, 6));
  }
  const rowH = opt.density === "compact" ? 38 : opt.density === "comfortable" ? 60 : 48;
  const padX = opt.density === "compact" ? 12 : opt.density === "comfortable" ? 16 : 14;
  const pin = opt.pinFirst;
  const selW = f.selection ? 44 : 0;
  const widths = cols.map((c) => colWidth(c, c.key === sheet.identity, opt.dataBars));
  const total = selW + widths.reduce((a, b) => a + b, 0) + (f.drawer ? 48 : 0);
  const btn = { height: 34, display: "inline-flex", alignItems: "center", gap: 7, padding: "0 12px", borderRadius: "var(--r2)", border: "1px solid var(--line)", background: "var(--panel)", fontSize: "0.93em", fontWeight: 500, whiteSpace: "nowrap" };
  const box = { width: 16, height: 16, borderRadius: 5, border: "1.5px solid var(--edge)", display: "inline-block", verticalAlign: "middle" };
  const cellBase = (w, i, c) => ({ width: w, height: rowH, padding: `0 ${padX}px`, borderBottom: "1px solid var(--line)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", background: opt.striped && i % 2 ? "var(--stripe)" : "var(--bg)", textAlign: c && numeric(c.type) ? "right" : "left" });
  const StillIcon = ({ d }) => /* @__PURE__ */ _jsx("svg", { width: 15, height: 15, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round", strokeLinejoin: "round", style: { flex: "none" }, children: /* @__PURE__ */ _jsx("path", { d }) });
  return /* @__PURE__ */ _jsxs("div", { style: { ...r.style, ...paint(dark, look.accent, look.radius), position: "relative", width: "100%", height: "100%", display: "flex", flexDirection: "column", overflow: "hidden", background: "var(--bg)", color: "var(--text)", border: look.border ? "1px solid var(--line)" : "none", borderRadius: "var(--r)", fontSize: 13, lineHeight: 1.45, boxSizing: "border-box", ...r.font }, children: [/* @__PURE__ */ _jsxs("div", { style: { padding: "18px 20px 14px", display: "flex", flexDirection: "column", gap: 14, borderBottom: "1px solid var(--line)" }, children: [/* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }, children: [/* @__PURE__ */ _jsxs("div", { style: { minWidth: 0 }, children: [/* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", gap: 8 }, children: [r.title ? /* @__PURE__ */ _jsx("div", { style: { fontSize: "1.25em", fontWeight: 600, letterSpacing: "-0.015em" }, children: r.title }) : null, /* @__PURE__ */ _jsxs("span", { style: { fontSize: "0.82em", color: "var(--muted)", border: "1px solid var(--line)", borderRadius: 999, padding: "1px 8px", fontVariantNumeric: "tabular-nums" }, children: [sheet.rows.length.toLocaleString(), " records"] })] }), r.subtitle ? /* @__PURE__ */ _jsx("div", { style: { color: "var(--muted)", marginTop: 4, fontSize: "0.93em" }, children: r.subtitle }) : null] }), /* @__PURE__ */ _jsxs("div", { style: { display: "flex", gap: 8 }, children: [f.importData ? /* @__PURE__ */ _jsxs("div", { style: btn, children: [/* @__PURE__ */ _jsx(StillIcon, { d: ICON.upload }), "Import"] }) : null, f.exportData ? /* @__PURE__ */ _jsxs("div", { style: { ...btn, background: "var(--ac)", borderColor: "var(--ac)", color: "#fff" }, children: [/* @__PURE__ */ _jsx(StillIcon, { d: ICON.download }), "Export"] }) : null] })] }), facetVals.length > 1 ? /* @__PURE__ */ _jsx("div", { style: { display: "flex", gap: 4, overflow: "hidden" }, children: [{ label: "All", n: sheet.rows.length }, ...facetVals].map((t, i) => /* @__PURE__ */ _jsxs("div", { style: { height: 30, display: "inline-flex", alignItems: "center", gap: 7, padding: "0 11px", borderRadius: 999, background: i === 0 ? "var(--hover)" : "transparent", color: i === 0 ? "var(--text)" : "var(--muted)", fontWeight: 500, whiteSpace: "nowrap" }, children: [i > 0 ? /* @__PURE__ */ _jsx("span", { style: dotStyle(t.label, dark) }) : null, t.label, /* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)", fontVariantNumeric: "tabular-nums" }, children: t.n })] }, t.label + i)) }) : null, /* @__PURE__ */ _jsxs("div", { style: { display: "flex", gap: 8, alignItems: "center" }, children: [f.search ? /* @__PURE__ */ _jsxs("div", { style: { height: 34, flex: "1 1 240px", maxWidth: 380, display: "flex", alignItems: "center", gap: 8, padding: "0 10px", border: "1px solid var(--line)", borderRadius: "var(--r2)", color: "var(--subtle)" }, children: [/* @__PURE__ */ _jsx(StillIcon, { d: ICON.search }), /* @__PURE__ */ _jsx("span", { style: { flex: 1 }, children: "Search\u2026" })] }) : null, /* @__PURE__ */ _jsx("div", { style: { flex: 1 } }), f.filters ? /* @__PURE__ */ _jsxs("div", { style: btn, children: [/* @__PURE__ */ _jsx(StillIcon, { d: ICON.filter }), "Filter"] }) : null, f.columnMenu ? /* @__PURE__ */ _jsxs("div", { style: btn, children: [/* @__PURE__ */ _jsx(StillIcon, { d: ICON.view }), "View"] }) : null] })] }), /* @__PURE__ */ _jsx("div", { style: { flex: 1, minHeight: 0, overflow: "hidden" }, children: /* @__PURE__ */ _jsxs("table", { style: { width: total, minWidth: "100%", tableLayout: "fixed", borderCollapse: "separate", borderSpacing: 0 }, children: [/* @__PURE__ */ _jsxs("colgroup", { children: [f.selection ? /* @__PURE__ */ _jsx("col", { style: { width: selW } }) : null, widths.map((w, i) => /* @__PURE__ */ _jsx("col", { style: { width: w } }, i)), f.drawer ? /* @__PURE__ */ _jsx("col", { style: { width: 48 } }) : null] }), /* @__PURE__ */ _jsx("thead", { children: /* @__PURE__ */ _jsxs("tr", { children: [f.selection ? /* @__PURE__ */ _jsx("th", { style: { height: 40, background: "var(--head)", borderBottom: "1px solid var(--line)", textAlign: "center" }, children: /* @__PURE__ */ _jsx("span", { style: box }) }) : null, cols.map((c, i) => /* @__PURE__ */ _jsx("th", { style: { height: 40, padding: `0 ${padX}px`, background: "var(--head)", borderBottom: "1px solid var(--line)", textAlign: numeric(c.type) ? "right" : "left", fontWeight: 500, fontSize: "0.86em", color: "var(--muted)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", borderRight: pin && i === 0 ? "1px solid var(--line)" : void 0 }, children: c.label }, c.key)), f.drawer ? /* @__PURE__ */ _jsx("th", { style: { background: "var(--head)", borderBottom: "1px solid var(--line)" } }) : null] }) }), /* @__PURE__ */ _jsx("tbody", { children: loading ? Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ _jsx("tr", { children: /* @__PURE__ */ _jsx("td", { colSpan: cols.length + (f.selection ? 1 : 0) + (f.drawer ? 1 : 0) || 1, style: { height: rowH, padding: `0 ${padX}px`, borderBottom: "1px solid var(--line)" }, children: /* @__PURE__ */ _jsx("div", { style: { height: 10, width: `${40 + i * 17 % 45}%`, borderRadius: 6, background: "var(--hover)" } }) }) }, i)) : shown.map((row, ri) => /* @__PURE__ */ _jsxs("tr", { children: [f.selection ? /* @__PURE__ */ _jsx("td", { style: { ...cellBase(selW, ri), padding: 0, textAlign: "center" }, children: /* @__PURE__ */ _jsx("span", { style: box }) }) : null, cols.map((c, ci) => {
    const raw = row[c.key] ?? "";
    const isId = c.key === sheet.identity;
    let body = raw ? show(c, raw) : /* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)" }, children: "\u2014" });
    if (isId) {
      const pic = sheet.avatar ? row[sheet.avatar] : "";
      body = /* @__PURE__ */ _jsxs("span", { style: { display: "inline-flex", alignItems: "center", gap: 10, maxWidth: "100%", verticalAlign: "middle" }, children: [pic ? /* @__PURE__ */ _jsx("img", { src: pic, alt: "", style: { width: 26, height: 26, borderRadius: "50%", objectFit: "cover", flex: "none" } }) : /* @__PURE__ */ _jsx("span", { style: badgeStyle(raw, dark, 26), children: initials(raw) }), /* @__PURE__ */ _jsx("span", { style: { fontWeight: 550, overflow: "hidden", textOverflow: "ellipsis" }, children: raw || "Untitled" })] });
    } else if (raw && c.type === "status") {
      body = /* @__PURE__ */ _jsxs("span", { style: pillStyle(raw, dark), children: [/* @__PURE__ */ _jsx("span", { style: dotStyle(raw, dark) }), raw] });
    } else if (raw && c.type === "image") {
      body = /* @__PURE__ */ _jsx("img", { src: raw, alt: "", style: { width: 28, height: 28, borderRadius: 7, objectFit: "cover", verticalAlign: "middle" } });
    } else if (raw && (c.type === "email" || c.type === "url")) {
      body = /* @__PURE__ */ _jsx("span", { style: { color: c.type === "url" ? "var(--ac)" : "var(--muted)" }, children: show(c, raw) });
    } else if (raw && numeric(c.type)) {
      const txt = /* @__PURE__ */ _jsx("span", { style: { fontVariantNumeric: "tabular-nums" }, children: show(c, raw) });
      body = opt.dataBars ? /* @__PURE__ */ _jsxs("span", { style: { display: "flex", alignItems: "center", gap: 10, justifyContent: "flex-end" }, children: [/* @__PURE__ */ _jsx("span", { style: { flex: "1 1 auto", maxWidth: 64, height: 4, borderRadius: 4, background: "var(--line)", overflow: "hidden" }, children: /* @__PURE__ */ _jsx("span", { style: { display: "block", height: "100%", width: `${share(c, raw, stats[c.key]) * 100}%`, background: "var(--ac)", opacity: 0.8, borderRadius: 4 } }) }), txt] }) : txt;
    }
    return /* @__PURE__ */ _jsx("td", { style: { ...cellBase(widths[ci], ri, c), borderRight: pin && ci === 0 ? "1px solid var(--line)" : void 0 }, children: body }, c.key);
  }), f.drawer ? /* @__PURE__ */ _jsx("td", { style: cellBase(48, ri) }) : null] }, row.__id)) })] }) }), f.pagination ? /* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 20px", borderTop: "1px solid var(--line)", color: "var(--muted)", fontSize: "0.92em" }, children: [/* @__PURE__ */ _jsx("span", { style: { fontVariantNumeric: "tabular-nums" }, children: sheet.rows.length ? `1\u2013${shown.length} of ${sheet.rows.length.toLocaleString()}` : "0 results" }), /* @__PURE__ */ _jsxs("span", { style: { fontVariantNumeric: "tabular-nums" }, children: ["Page 1 of", " ", Math.max(1, Math.ceil(sheet.rows.length / Math.max(1, opt.pageSize)))] })] }) : null] });
}
var ICON = { search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-3.6-3.6", filter: "M4 6h16M7 12h10M10 18h4", view: "M4 7h9M17 7h3M4 17h3M11 17h9M15 5v4M9 15v4", download: "M12 4v11M7 10l5 5 5-5M5 20h14", upload: "M12 16V5M7 10l5-5 5 5M5 20h14", x: "M6 6l12 12M18 6L6 18", left: "M15 6l-6 6 6 6", right: "M9 6l6 6-6 6", down: "M6 9l6 6 6-6", asc: "M12 19V5M6 11l6-6 6 6", desc: "M12 5v14M6 13l6 6 6-6", both: "M8 9l4-4 4 4M8 15l4 4 4-4", open: "M14 4h6v6M20 4l-7 7M10 20H4v-6M4 20l7-7", copy: "M9 9h11v11H9zM5 15H4V4h11v1", trash: "M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13", check: "M5 12.5l4.5 4.5L19 7.5", minus: "M6 12h12", table: "M4 5h16v14H4zM4 10h16M10 10v9", reset: "M4 12a8 8 0 1 0 2.4-5.7M4 4v4h4", columns: "M4 5h16v14H4zM9.5 5v14M14.5 5v14" };
var KIND_MARK = { text: "Aa", number: "#", currency: "\xA4", percent: "%", date: "\u25F7", boolean: "\u2713", status: "\u25C9", email: "@", url: "\u2197", image: "\u25A3" };
var AGG = ["Sum", "Avg", "Min", "Max"];
function Glyph({ d, size = 16, w = 1.8 }) {
  return /* @__PURE__ */ _jsx("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: w, strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", style: { flex: "none", display: "block" }, children: /* @__PURE__ */ _jsx("path", { d }) });
}
function useMediaFlag(q) {
  const [on, setOn] = useState(false);
  useEffect(() => {
    if (typeof __dai_window === "undefined" || !__dai_window.matchMedia)
      return;
    const m = __dai_window.matchMedia(q);
    const sync = () => setOn(m.matches);
    sync();
    if (m.addEventListener)
      m.addEventListener("change", sync);
    else
      m.addListener(sync);
    return () => {
      if (m.removeEventListener)
        m.removeEventListener("change", sync);
      else
        m.removeListener(sync);
    };
  }, [q]);
  return on;
}
function styleSheet(sc, reduced) {
  const S = "." + sc;
  return `
${S}{container-type:inline-size}
${S} *,${S} *::before,${S} *::after{box-sizing:border-box}
${S} button,${S} input,${S} select{font:inherit;color:inherit}
${S} button{-webkit-tap-highlight-color:transparent}
${S} :focus{outline:none}
${S} :focus-visible{outline:2px solid var(--ac);outline-offset:1px}
${S} input::placeholder{color:var(--subtle)}
${S} .tb{height:34px;display:inline-flex;align-items:center;gap:7px;padding:0 12px;border-radius:var(--r2);border:1px solid var(--line);background:var(--panel);color:var(--text);font-size:.93em;font-weight:500;cursor:pointer;white-space:nowrap;transition:background .15s,border-color .15s}
${S} .tb:hover,${S} .tb[data-on="1"]{background:var(--hover);border-color:var(--edge)}
${S} .tb.pr{background:var(--ac);border-color:var(--ac);color:#fff}
${S} .tb.pr:hover,${S} .tb.pr[data-on="1"]{background:color-mix(in srgb,var(--ac) 88%,#000)}
${S} .tb.dg{color:var(--danger)}
${S} .ib{width:30px;height:30px;display:inline-grid;place-items:center;border:0;border-radius:8px;background:transparent;color:var(--muted);cursor:pointer;padding:0;transition:background .15s,color .15s}
${S} .ib:hover{background:var(--hover);color:var(--text)}
${S} .ib:disabled{opacity:.35;cursor:default;background:transparent}
${S} .mi{width:100%;display:flex;align-items:center;gap:10px;min-height:34px;padding:6px 10px;border:0;border-radius:8px;background:transparent;text-align:left;cursor:pointer;color:var(--text)}
${S} .mi:hover{background:var(--hover)}
${S} .seg{flex:1;height:30px;border:0;border-radius:7px;background:transparent;color:var(--muted);cursor:pointer;font-size:.9em;font-weight:500;transition:background .15s,color .15s}
${S} .seg:hover{color:var(--text)}
${S} .seg[data-on="1"]{background:var(--panel);color:var(--text);box-shadow:0 1px 2px rgba(0,0,0,.08),0 0 0 1px var(--line)}
${S} tbody td{background:var(--row);transition:background .12s}
${S} tbody tr[data-alt="1"]>td{background:var(--stripe)}
${S} tbody tr:hover>td{background:var(--hover)}
${S} tbody tr[data-sel="1"]>td{background:var(--sel)}
${S} tbody tr[data-sel="1"]:hover>td{background:var(--selh)}
${S} .hb{display:inline-flex;align-items:center;gap:6px;border:0;background:transparent;padding:4px 6px;margin:0 -6px;border-radius:6px;color:inherit;max-width:calc(100% + 12px);transition:color .15s,background .15s}
${S} .hb.cl{cursor:pointer}
${S} .hb.cl:hover{color:var(--text);background:var(--hover)}
${S} .si{opacity:0;transition:opacity .15s}
${S} th:hover .si{opacity:.6}
${S} .rz{position:absolute;top:0;bottom:0;right:-4px;width:9px;cursor:col-resize;z-index:3;touch-action:none}
${S} .rz::after{content:"";position:absolute;left:4px;top:12px;bottom:12px;width:1px;background:var(--line);transition:background .15s}
${S} .rz:hover::after{background:var(--ac);top:6px;bottom:6px;width:2px;left:3.5px}
${S} .act{opacity:0;transition:opacity .15s}
${S} tbody tr:hover .act,${S} .act:focus-visible{opacity:1}
${S} .nm{border:0;background:transparent;padding:0;cursor:pointer;font-weight:550;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;color:var(--text);border-bottom:1px solid transparent;transition:border-color .15s}
${S} .nm:hover{border-color:currentColor}
${S} .lnk{color:inherit;text-decoration:none;border-bottom:1px solid transparent;transition:border-color .15s}
${S} .lnk:hover{border-color:currentColor}
${S} .tab{height:30px;display:inline-flex;align-items:center;gap:7px;padding:0 11px;border:0;border-radius:999px;background:transparent;color:var(--muted);font-weight:500;cursor:pointer;white-space:nowrap;transition:background .15s,color .15s}
${S} .tab:hover{color:var(--text)}
${S} .tab[data-on="1"]{background:var(--hover);color:var(--text)}
${S} .chip{height:28px;display:inline-flex;align-items:center;gap:6px;padding:0 4px 0 10px;border:1px solid var(--line);border-radius:999px;background:var(--panel);font-size:.9em;cursor:pointer;white-space:nowrap;max-width:100%;transition:border-color .15s}
${S} .chip:hover{border-color:var(--edge)}
${S} .chip .cx{width:20px;height:20px;border-radius:50%;display:inline-grid;place-items:center;color:var(--subtle)}
${S} .chip .cx:hover{background:var(--hover);color:var(--text)}
${S} .txt{border:0;background:transparent;padding:0;color:var(--ac);cursor:pointer;font-weight:500}
${S} .txt:hover{text-decoration:underline}
${S} .pg{min-width:30px;height:30px;padding:0 8px;border-radius:8px;border:0;background:transparent;color:var(--muted);cursor:pointer;font-variant-numeric:tabular-nums}
${S} .pg:hover{background:var(--hover);color:var(--text)}
${S} .pg[data-on="1"]{background:var(--ac-soft);color:var(--ac);font-weight:600}
${S} .fv{border:0;background:transparent;color:inherit;transition:background .15s}
${S} .fv:hover{background:var(--hover)}
${S} .bb{height:30px;display:inline-flex;align-items:center;gap:6px;padding:0 10px;border:0;border-radius:999px;background:transparent;color:inherit;cursor:pointer;font-weight:500;transition:background .15s}
${S} .bb:hover{background:rgba(128,128,140,.2)}
${S} .sc::-webkit-scrollbar{width:10px;height:10px}
${S} .sc::-webkit-scrollbar-thumb{background:var(--line);border-radius:10px;border:2px solid var(--bg)}
${S} .sc::-webkit-scrollbar-corner{background:transparent}
${S} .nb{scrollbar-width:none}
${S} .nb::-webkit-scrollbar{display:none}
${S} .pop{animation:${sc}-pop .16s ease-out}
${S} .drw{animation:${sc}-drw .24s cubic-bezier(.2,.8,.2,1)}
${S} .scr{animation:${sc}-fade .2s ease-out}
${S} .rise{animation:${sc}-rise .2s ease-out}
@keyframes ${sc}-pop{from{opacity:0;transform:translateY(-4px) scale(.985)}to{opacity:1;transform:none}}
@keyframes ${sc}-drw{from{opacity:0;transform:translateX(28px)}to{opacity:1;transform:none}}
@keyframes ${sc}-fade{from{opacity:0}to{opacity:1}}
@keyframes ${sc}-rise{from{opacity:0;transform:translate(-50%,8px)}to{opacity:1;transform:translate(-50%,0)}}
@container (max-width:720px){${S} .lb{display:none}${S} .hs{display:none}}
${reduced ? `${S} *{animation:none!important;transition:none!important}` : ""}
`;
}
function Tick({ state, onToggle, label, decor }) {
  const on = state > 0;
  if (decor)
    return /* @__PURE__ */ _jsx("span", { "aria-hidden": "true", style: { width: 16, height: 16, borderRadius: 5, flex: "none", border: on ? "1px solid var(--ac)" : "1.5px solid var(--edge)", background: on ? "var(--ac)" : "transparent", color: "#fff", display: "inline-grid", placeItems: "center", transition: "background .12s,border-color .12s" }, children: on ? /* @__PURE__ */ _jsx(Glyph, { d: ICON.check, size: 12, w: 3 }) : null });
  return /* @__PURE__ */ _jsx("button", { type: "button", role: "checkbox", "aria-checked": state === 2 ? "mixed" : state === 1, "aria-label": label, onClick: (e) => {
    e.stopPropagation();
    onToggle && onToggle(e);
  }, style: { width: 16, height: 16, borderRadius: 5, padding: 0, border: on ? "1px solid var(--ac)" : "1.5px solid var(--edge)", background: on ? "var(--ac)" : "transparent", color: "#fff", display: "inline-grid", placeItems: "center", cursor: "pointer", verticalAlign: "middle", transition: "background .12s,border-color .12s" }, children: state === 1 ? /* @__PURE__ */ _jsx(Glyph, { d: ICON.check, size: 12, w: 3 }) : state === 2 ? /* @__PURE__ */ _jsx(Glyph, { d: ICON.minus, size: 12, w: 3 }) : null });
}
function Switch({ on, onChange, label }) {
  return /* @__PURE__ */ _jsxs("button", { type: "button", className: "mi", role: "switch", "aria-checked": on, onClick: () => onChange(!on), children: [/* @__PURE__ */ _jsx("span", { style: { flex: 1 }, children: label }), /* @__PURE__ */ _jsx("span", { style: { width: 30, height: 18, borderRadius: 999, padding: 2, background: on ? "var(--ac)" : "var(--edge)", transition: "background .15s", flex: "none" }, children: /* @__PURE__ */ _jsx("span", { style: { display: "block", width: 14, height: 14, borderRadius: "50%", background: "#fff", transform: on ? "translateX(12px)" : "none", transition: "transform .18s", boxShadow: "0 1px 2px rgba(0,0,0,.25)" } }) })] });
}
function Pop({ align = "right", width, onClose, children }) {
  return /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsx("div", { onClick: onClose, style: { position: "fixed", inset: 0, zIndex: 50 } }), /* @__PURE__ */ _jsx("div", { className: "pop sc", role: "dialog", style: { position: "absolute", top: "calc(100% + 6px)", [align]: 0, zIndex: 51, width, maxWidth: "min(92vw, 360px)", maxHeight: 380, overflowY: "auto", background: "var(--panel)", border: "1px solid var(--line)", borderRadius: "var(--r2)", boxShadow: "var(--shadow)", padding: 6 }, children })] });
}
var eyebrow = { padding: "8px 10px 6px", fontSize: "0.76em", color: "var(--subtle)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.07em" };
var rule = { height: 1, background: "var(--line)", margin: "6px 4px" };
var field = { width: "100%", height: 32, padding: "0 10px", border: "1px solid var(--line)", borderRadius: 8, background: "var(--bg)", color: "var(--text)" };
function Editor({ initial, list, onCommit, onCancel, align }) {
  const done = useRef(false);
  return /* @__PURE__ */ _jsx("input", { autoFocus: true, defaultValue: initial, list, onFocus: (e) => e.currentTarget.select(), onClick: (e) => e.stopPropagation(), onKeyDown: (e) => {
    e.stopPropagation();
    if (e.key === "Enter") {
      done.current = true;
      onCommit(e.currentTarget.value);
    } else if (e.key === "Escape") {
      done.current = true;
      onCancel();
    }
  }, onBlur: (e) => {
    if (!done.current) {
      done.current = true;
      onCommit(e.currentTarget.value);
    }
  }, style: { width: "100%", height: 30, padding: "0 8px", border: "1px solid var(--ac)", borderRadius: 7, background: "var(--bg)", color: "var(--text)", boxShadow: "0 0 0 3px var(--ac-soft)", textAlign: align } });
}
function ruleKind(c, distinct) {
  if (c.type === "status" || c.type === "boolean")
    return "set";
  if (numeric(c.type) || c.type === "date")
    return "range";
  return distinct <= 12 ? "set" : "text";
}
function ruleOn(r) {
  if (!r)
    return false;
  if (r.kind === "set")
    return r.values.length > 0;
  if (r.kind === "range")
    return r.min !== "" || r.max !== "";
  return r.q.trim() !== "";
}
function ruleLabel(c, r) {
  if (r.kind === "set")
    return `${c.label}: ${r.values.slice(0, 2).join(", ")}${r.values.length > 2 ? ` +${r.values.length - 2}` : ""}`;
  if (r.kind === "text")
    return `${c.label} contains \u201C${r.q}\u201D`;
  const f = (v) => c.type === "date" ? show(c, v) : v;
  if (r.min !== "" && r.max !== "")
    return `${c.label}: ${f(r.min)} \u2013 ${f(r.max)}`;
  return r.min !== "" ? `${c.label} \u2265 ${f(r.min)}` : `${c.label} \u2264 ${f(r.max)}`;
}
function RuleEditor({ col, rows, value, dark, onChange, onBack }) {
  const [q, setQ] = useState("");
  const options = useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    for (const r of rows) {
      let v = r[col.key] ?? "";
      if (!v)
        continue;
      if (col.type === "boolean")
        v = truthy(v) ? "Yes" : "No";
      const k = v.toLowerCase();
      const e = m.get(k);
      if (e)
        e.n++;
      else
        m.set(k, { label: v, n: 1 });
    }
    return Array.from(m.values()).sort((a, b) => b.n - a.n);
  }, [rows, col]);
  const tally = useMemo(() => tallies([col], rows)[col.key], [rows, col]);
  const kind = ruleKind(col, options.length);
  const isDate = col.type === "date";
  const dates = useMemo(() => {
    if (!isDate)
      return { lo: "", hi: "" };
    let lo = Infinity, hi = -Infinity;
    for (const r of rows) {
      const t = toTime(r[col.key]);
      if (!isNaN(t)) {
        lo = Math.min(lo, t);
        hi = Math.max(hi, t);
      }
    }
    const iso = (t) => {
      if (!isFinite(t))
        return "";
      const d = new Date(t);
      return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
    };
    return { lo: iso(lo), hi: iso(hi) };
  }, [rows, col, isDate]);
  const set = value?.kind === "set" ? value.values : [];
  const range = value?.kind === "range" ? value : { kind: "range", min: "", max: "" };
  const text = value?.kind === "text" ? value.q : "";
  const lower = new Set(set.map((s) => s.toLowerCase()));
  const shown = q ? options.filter((o) => o.label.toLowerCase().includes(q.toLowerCase())) : options;
  return /* @__PURE__ */ _jsxs("div", { children: [/* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", gap: 4, padding: "2px 2px 6px" }, children: [/* @__PURE__ */ _jsx("button", { type: "button", className: "ib", "aria-label": "Back to columns", onClick: onBack, children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.left }) }), /* @__PURE__ */ _jsx("span", { style: { fontWeight: 600, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: col.label }), ruleOn(value) ? /* @__PURE__ */ _jsx("button", { type: "button", className: "txt", style: { padding: "0 8px", fontSize: "0.9em" }, onClick: () => onChange(null), children: "Clear" }) : null] }), kind === "set" ? /* @__PURE__ */ _jsxs(_Fragment, { children: [options.length > 8 ? /* @__PURE__ */ _jsx("div", { style: { padding: "0 4px 6px" }, children: /* @__PURE__ */ _jsx("input", { autoFocus: true, placeholder: "Find a value\u2026", value: q, onChange: (e) => setQ(e.target.value), style: field }) }) : null, shown.map((o) => {
    const on = lower.has(o.label.toLowerCase());
    const toggle = () => {
      const next = on ? set.filter((s) => s.toLowerCase() !== o.label.toLowerCase()) : [...set, o.label];
      onChange(next.length ? { kind: "set", values: next } : null);
    };
    return /* @__PURE__ */ _jsxs("button", { type: "button", className: "mi", onClick: toggle, children: [/* @__PURE__ */ _jsx(Tick, { decor: true, state: on ? 1 : 0, label: o.label }), col.type === "status" ? /* @__PURE__ */ _jsx("span", { style: dotStyle(o.label, dark) }) : null, /* @__PURE__ */ _jsx("span", { style: { flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: o.label }), /* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)", fontVariantNumeric: "tabular-nums", fontSize: "0.9em" }, children: o.n })] }, o.label);
  }), !shown.length ? /* @__PURE__ */ _jsx("div", { style: { padding: "10px", color: "var(--subtle)" }, children: "No values match." }) : null] }) : kind === "range" ? /* @__PURE__ */ _jsx("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, padding: "2px 4px 6px" }, children: ["min", "max"].map((side) => /* @__PURE__ */ _jsxs("label", { style: { display: "flex", flexDirection: "column", gap: 5, fontSize: "0.86em", color: "var(--muted)" }, children: [isDate ? side === "min" ? "From" : "To" : side === "min" ? "Min" : "Max", /* @__PURE__ */ _jsx("input", { type: isDate ? "date" : "number", value: range[side], placeholder: !isDate && tally && tally.count ? NUM.format(side === "min" ? tally.min : tally.max) : "", min: isDate ? dates.lo : void 0, max: isDate ? dates.hi : void 0, onChange: (e) => {
    const next = { ...range, [side]: e.target.value };
    onChange(next.min === "" && next.max === "" ? null : next);
  }, style: { ...field, fontSize: "1.08em" } })] }, side)) }) : /* @__PURE__ */ _jsx("div", { style: { padding: "2px 4px 6px" }, children: /* @__PURE__ */ _jsx("input", { autoFocus: true, placeholder: "Contains\u2026", value: text, onChange: (e) => onChange(e.target.value ? { kind: "text", q: e.target.value } : null), style: field }) })] });
}
function DrawerField({ col, raw, editable, list, dark, onCommit }) {
  const [edit, setEdit] = useState(false);
  const canEdit = editable && col.type !== "image";
  let body;
  if (!raw)
    body = /* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)" }, children: "Empty" });
  else if (col.type === "status")
    body = /* @__PURE__ */ _jsxs("span", { style: pillStyle(raw, dark), children: [/* @__PURE__ */ _jsx("span", { style: dotStyle(raw, dark) }), raw] });
  else if (col.type === "image")
    body = /* @__PURE__ */ _jsx("img", { src: raw, alt: "", style: { width: 48, height: 48, borderRadius: 10, objectFit: "cover" } });
  else
    body = /* @__PURE__ */ _jsx("span", { style: { whiteSpace: "normal", wordBreak: "break-word", fontVariantNumeric: numeric(col.type) ? "tabular-nums" : void 0, color: col.type === "url" ? "var(--ac)" : void 0 }, children: show(col, raw) });
  return /* @__PURE__ */ _jsxs("div", { style: { display: "grid", gridTemplateColumns: "minmax(92px, 36%) 1fr", gap: 12, alignItems: "center", padding: "3px 8px", minHeight: 38 }, children: [/* @__PURE__ */ _jsxs("div", { style: { color: "var(--muted)", fontSize: "0.9em", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 8 }, children: [/* @__PURE__ */ _jsx("span", { style: { width: 18, textAlign: "center", color: "var(--subtle)", fontSize: "0.85em", flex: "none" }, children: KIND_MARK[col.type] }), col.label] }), /* @__PURE__ */ _jsx("div", { style: { minWidth: 0 }, children: edit ? /* @__PURE__ */ _jsx(Editor, { initial: raw, list, onCommit: (v) => {
    setEdit(false);
    onCommit(v);
  }, onCancel: () => setEdit(false) }) : /* @__PURE__ */ _jsx("button", { type: "button", className: canEdit ? "fv" : void 0, disabled: !canEdit, onClick: () => canEdit && setEdit(true), title: canEdit ? "Click to edit" : void 0, style: { width: "calc(100% + 16px)", minHeight: 30, margin: "0 -8px", padding: "4px 8px", borderRadius: 7, border: 0, background: "transparent", textAlign: "left", cursor: canEdit ? "text" : "default", display: "flex", alignItems: "center", color: "var(--text)", opacity: 1 }, children: body }) })] });
}
function pageList(pg, pages) {
  if (pages <= 7)
    return Array.from({ length: pages }, (_, i) => i);
  const out = [0];
  const s = Math.max(1, pg - 1), e = Math.min(pages - 2, pg + 1);
  if (s > 1)
    out.push("\u2026");
  for (let i = s; i <= e; i++)
    out.push(i);
  if (e < pages - 2)
    out.push("\u2026");
  out.push(pages - 1);
  return out;
}
function scopeQuery(q, cols) {
  const tokens = q.match(/[^\s"]+:"[^"]*"|"[^"]*"|\S+/g) || [];
  const scoped = [];
  const free = [];
  for (const t of tokens) {
    const i = t.indexOf(":");
    if (i > 0) {
      const name = t.slice(0, i).toLowerCase().replace(/[\s_-]/g, "");
      const col = cols.find((c) => c.key.replace(/_/g, "") === name || c.label.toLowerCase().replace(/[\s_-]/g, "") === name);
      if (col) {
        scoped.push({ col, term: t.slice(i + 1).replace(/^"|"$/g, "") });
        continue;
      }
    }
    const clean = t.replace(/^"|"$/g, "").toLowerCase();
    if (clean)
      free.push(clean);
  }
  return { scoped, free };
}
function scopedHit(c, raw, term) {
  const m = term.match(/^(>=|<=|>|<|=)(.+)$/);
  if (m && (numeric(c.type) || c.type === "date")) {
    const a = c.type === "date" ? toTime(raw) : toNum(raw);
    const b = c.type === "date" ? toTime(m[2]) : toNum(m[2]);
    if (isNaN(a) || isNaN(b))
      return false;
    return m[1] === ">" ? a > b : m[1] === "<" ? a < b : m[1] === ">=" ? a >= b : m[1] === "<=" ? a <= b : a === b;
  }
  const t = term.toLowerCase();
  if (!t)
    return true;
  return (raw || "").toLowerCase().includes(t) || show(c, raw).toLowerCase().includes(t);
}
function LiveTable(props) {
  const r = resolve(props);
  const { f, opt, look } = r;
  const rawId = useId();
  const sc = "tp" + rawId.replace(/[^a-zA-Z0-9]/g, "");
  const reduced = useMediaFlag("(prefers-reduced-motion: reduce)");
  const sysDark = useMediaFlag("(prefers-color-scheme: dark)");
  const dark = look.theme === "dark" || look.theme === "auto" && sysDark;
  const { sheet: sourceSheet, loading, error } = useSheet(r);
  const [imported, setImported] = useState(null);
  const base = imported || sourceSheet;
  const cols = base.columns;
  const hiddenFrom = (s) => Object.fromEntries(s.columns.filter((c) => !c.visible).map((c) => [c.key, true]));
  const [rows, setRows] = useState(base.rows);
  const [hidden, setHidden] = useState(() => hiddenFrom(base));
  const [widths, setWidths] = useState({});
  const [query, setQuery] = useState("");
  const [rules, setRules] = useState({});
  const [tab, setTab] = useState(null);
  const [sorts, setSorts] = useState([]);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(Math.max(1, opt.pageSize));
  const [density, setDensity] = useState(opt.density);
  const [footer, setFooter] = useState(opt.summary);
  const [bars, setBars] = useState(opt.dataBars);
  const [picked, setPicked] = useState(() => /* @__PURE__ */ new Set());
  const [aggs, setAggs] = useState({});
  const [menu, setMenu] = useState(null);
  const [focusCol, setFocusCol] = useState(null);
  const [openId, setOpenId] = useState(null);
  const [editing, setEditing] = useState(null);
  const [toast, setToast] = useState(null);
  const [dropping, setDropping] = useState(false);
  const [slid, setSlid] = useState(false);
  const searchRef = useRef(null);
  const fileRef = useRef(null);
  const anchor = useRef(-1);
  const toastTimer = useRef(0);
  const timers = useRef(/* @__PURE__ */ new Set());
  useEffect(() => {
    setRows(base.rows);
    setHidden(hiddenFrom(base));
    setWidths({});
    setPicked(/* @__PURE__ */ new Set());
    setRules({});
    setTab(null);
    setSorts([]);
    setPage(0);
    setOpenId(null);
    setEditing(null);
  }, [base]);
  useEffect(() => setPageSize(Math.max(1, opt.pageSize)), [opt.pageSize]);
  useEffect(() => setDensity(opt.density), [opt.density]);
  useEffect(() => setFooter(opt.summary), [opt.summary]);
  useEffect(() => setBars(opt.dataBars), [opt.dataBars]);
  useEffect(() => () => {
    clearTimeout(toastTimer.current);
    timers.current.forEach(clearTimeout);
    timers.current.clear();
  }, []);
  useEffect(() => setPage(0), [query, rules, tab, sorts, pageSize]);
  const say = (msg, undo) => {
    clearTimeout(toastTimer.current);
    setToast({ msg, undo, n: Date.now() });
    toastTimer.current = setTimeout(() => setToast(null), undo ? 6e3 : 2800);
  };
  const later = (fn, ms) => {
    const id = setTimeout(() => {
      timers.current.delete(id);
      fn();
    }, ms);
    timers.current.add(id);
  };
  const visible = useMemo(() => cols.filter((c) => !hidden[c.key]), [cols, hidden]);
  const hay = useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    for (const row of rows)
      m.set(row.__id, cols.map((c) => {
        const v = row[c.key] ?? "";
        return c.type === "date" || c.type === "boolean" || numeric(c.type) ? v + " " + show(c, v) : v;
      }).join("  ").toLowerCase());
    return m;
  }, [rows, cols]);
  const parsedQ = useMemo(() => scopeQuery(query, cols), [query, cols]);
  const liveRules = useMemo(() => Object.entries(rules).filter(([, v]) => ruleOn(v)).map(([k, v]) => ({ col: cols.find((c) => c.key === k), rule: v, want: v.kind === "set" ? new Set(v.values.map((s) => s.toLowerCase())) : null })).filter((x) => x.col), [rules, cols]);
  const matched = useMemo(() => rows.filter((row) => {
    const h = hay.get(row.__id) || "";
    for (const t of parsedQ.free)
      if (!h.includes(t))
        return false;
    for (const s of parsedQ.scoped)
      if (!scopedHit(s.col, row[s.col.key] ?? "", s.term))
        return false;
    for (const { col, rule: rule2, want } of liveRules) {
      const raw = row[col.key] ?? "";
      if (rule2.kind === "set") {
        const v = col.type === "boolean" ? truthy(raw) ? "yes" : "no" : raw.toLowerCase();
        if (!want.has(v))
          return false;
      } else if (rule2.kind === "text") {
        if (!raw.toLowerCase().includes(rule2.q.toLowerCase()))
          return false;
      } else {
        const isDate = col.type === "date";
        const v = isDate ? toTime(raw) : toNum(raw);
        if (rule2.min !== "") {
          const lo = isDate ? toTime(rule2.min) : toNum(rule2.min);
          if (!isNaN(lo) && (isNaN(v) || v < lo))
            return false;
        }
        if (rule2.max !== "") {
          const hi = isDate ? toTime(rule2.max) + 86399999 : toNum(rule2.max);
          if (!isNaN(hi) && (isNaN(v) || v > hi))
            return false;
        }
      }
    }
    return true;
  }), [rows, hay, parsedQ, liveRules]);
  const facet = f.tabs && base.facet ? cols.find((c) => c.key === base.facet) || null : null;
  const tabs = useMemo(() => {
    if (!facet)
      return [];
    const order = /* @__PURE__ */ new Map();
    for (const row of rows) {
      const v = row[facet.key];
      if (v && !order.has(v.toLowerCase()))
        order.set(v.toLowerCase(), { label: v, n: 0 });
    }
    for (const row of matched) {
      const e = order.get((row[facet.key] || "").toLowerCase());
      if (e)
        e.n++;
    }
    return Array.from(order.entries()).slice(0, 7).map(([k, v]) => ({ key: k, ...v }));
  }, [facet, rows, matched]);
  const tabbed = useMemo(() => tab && facet ? matched.filter((row) => (row[facet.key] || "").toLowerCase() === tab) : matched, [matched, tab, facet]);
  const sorted = useMemo(() => {
    if (!sorts.length)
      return tabbed;
    const specs = sorts.map((s) => ({ col: cols.find((c) => c.key === s.key), dir: s.dir })).filter((s) => s.col);
    return [...tabbed].sort((a, b) => {
      for (const { col, dir } of specs) {
        const va = a[col.key] ?? "", vb = b[col.key] ?? "";
        if (va === vb)
          continue;
        if (va === "")
          return 1;
        if (vb === "")
          return -1;
        const d = compareRaw(col, va, vb);
        if (d)
          return d * dir;
      }
      return 0;
    });
  }, [tabbed, sorts, cols]);
  const size = f.pagination ? pageSize : Math.max(1, sorted.length);
  const pages = Math.max(1, Math.ceil(sorted.length / size));
  const pg = Math.min(page, pages - 1);
  const pageRows = sorted.slice(pg * size, pg * size + size);
  const stats = useMemo(() => tallies(visible, sorted), [visible, sorted]);
  const lists = useMemo(() => {
    const out = {};
    for (const c of cols)
      if (c.type === "status")
        out[c.key] = Array.from(new Set(rows.map((x) => x[c.key]).filter(Boolean)));
    return out;
  }, [cols, rows]);
  const listId = (c) => lists[c.key] ? `${sc}-${c.key}` : void 0;
  const sortBy = (key, add) => setSorts((prev) => {
    const cur = prev.find((s) => s.key === key);
    const next = !cur ? 1 : cur.dir === 1 ? -1 : 0;
    if (!add)
      return next ? [{ key, dir: next }] : [];
    if (!cur)
      return [...prev, { key, dir: 1 }];
    return next ? prev.map((s) => s.key === key ? { key, dir: next } : s) : prev.filter((s) => s.key !== key);
  });
  const setRule = (key, rule2) => setRules((prev) => {
    const n = { ...prev };
    if (rule2)
      n[key] = rule2;
    else
      delete n[key];
    return n;
  });
  const edit = (id, key, value) => {
    setRows((rs) => rs.map((x) => x.__id === id && x[key] !== value ? { ...x, [key]: value } : x));
    setEditing(null);
  };
  const pickRow = (id, idx, shift) => {
    const from = anchor.current;
    setPicked((prev) => {
      const next = new Set(prev);
      if (shift && from >= 0) {
        const on = !prev.has(id);
        for (let i = Math.min(from, idx); i <= Math.max(from, idx); i++) {
          const rid = pageRows[i]?.__id;
          if (rid)
            on ? next.add(rid) : next.delete(rid);
        }
      } else
        next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
    anchor.current = idx;
  };
  const onPage = pageRows.filter((x) => picked.has(x.__id)).length;
  const headState = onPage === 0 ? 0 : onPage === pageRows.length ? 1 : 2;
  const togglePage = () => setPicked((prev) => {
    const next = new Set(prev);
    if (headState === 1)
      pageRows.forEach((x) => next.delete(x.__id));
    else
      pageRows.forEach((x) => next.add(x.__id));
    return next;
  });
  const allMatching = sorted.length > 0 && sorted.every((x) => picked.has(x.__id));
  const asText = (list, columns, sep) => [columns.map((c) => sep === "," ? quoteCell(c.label) : c.label).join(sep), ...list.map((x) => columns.map((c) => sep === "," ? quoteCell(x[c.key] ?? "") : (x[c.key] ?? "").replace(/[\t\n]/g, " ")).join(sep))].join("\n");
  const exportCols = () => {
    const out = [...visible];
    if (base.avatar && hidden[base.avatar]) {
      const a = cols.find((c) => c.key === base.avatar);
      if (a)
        out.push(a);
    }
    return out;
  };
  const download = (list, columns, suffix = "") => {
    if (typeof document === "undefined")
      return;
    const blob = new Blob(["\uFEFF" + asText(list, columns, ",")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(opt.exportName || "table-export").replace(/\.csv$/i, "")}${suffix}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    later(() => URL.revokeObjectURL(url), 1500);
    say(`Exported ${list.length.toLocaleString()} ${list.length === 1 ? "row" : "rows"}`);
  };
  const copy = (text, msg) => {
    const fallback = () => {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
        say(msg);
      } catch {
        say("Copy isn't available here");
      }
      ta.remove();
    };
    if (__dai_navigator.clipboard?.writeText)
      __dai_navigator.clipboard.writeText(text).then(() => say(msg), fallback);
    else
      fallback();
  };
  const removeRows = (ids) => {
    const snap = rows;
    setRows((rs) => rs.filter((x) => !ids.has(x.__id)));
    setPicked(/* @__PURE__ */ new Set());
    if (openId && ids.has(openId))
      setOpenId(null);
    say(`Deleted ${ids.size} ${ids.size === 1 ? "row" : "rows"}`, snap);
  };
  const importFile = (file) => {
    if (!file)
      return;
    file.text().then((txt) => {
      const s = buildSheet(txt, r.overrides, r.opt.tabsColumn);
      if (!s.columns.length || !s.rows.length) {
        say("That file has no rows to import");
        return;
      }
      setImported(s);
      say(`Imported ${s.rows.length.toLocaleString()} rows from ${file.name}`);
    }).catch(() => say("That file couldn't be read"));
  };
  const startResize = (e, key, startW) => {
    e.preventDefault();
    e.stopPropagation();
    const el = e.currentTarget;
    const x0 = e.clientX;
    try {
      el.setPointerCapture(e.pointerId);
    } catch {
    }
    const move = (ev) => setWidths((w) => ({ ...w, [key]: Math.max(72, Math.round(startW + ev.clientX - x0)) }));
    const up = () => {
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
    };
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
  };
  const onKey = (e) => {
    const tag = e.target.tagName;
    const typing = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";
    if (e.key === "/" && !typing && f.search) {
      e.preventDefault();
      searchRef.current?.focus();
    } else if (e.key === "Escape") {
      if (menu)
        setMenu(null);
      else if (openId)
        setOpenId(null);
      else if (e.target === searchRef.current && query)
        setQuery("");
      else if (picked.size && !typing)
        setPicked(/* @__PURE__ */ new Set());
    }
  };
  const rowH = density === "compact" ? 38 : density === "comfortable" ? 60 : 48;
  const padX = density === "compact" ? 12 : density === "comfortable" ? 16 : 14;
  const selW = f.selection ? 44 : 0;
  const actW = f.drawer ? 48 : 0;
  const colW = visible.map((c) => colWidth(c, c.key === base.identity, bars, widths[c.key]));
  const totalW = selW + colW.reduce((a, b) => a + b, 0) + actW;
  const pinKey = opt.pinFirst && visible[0] ? visible[0].key : null;
  const edge = slid ? "inset -1px 0 0 var(--line), 10px 0 12px -10px rgba(0,0,0,.22)" : "inset -1px 0 0 var(--line)";
  const numericShown = visible.some((c) => numeric(c.type));
  const activeRules = liveRules.length;
  const openRow = openId ? rows.find((x) => x.__id === openId) || null : null;
  const openPos = openRow ? sorted.findIndex((x) => x.__id === openRow.__id) : -1;
  const bottomGap = (f.pagination ? 54 : 0) + 14;
  const cellStyle = (c, ci, extra) => ({ height: rowH, padding: `0 ${padX}px`, borderBottom: "1px solid var(--line)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", textAlign: c && numeric(c.type) ? "right" : "left", ...c && c.key === pinKey ? { position: "sticky", left: selW, zIndex: 1, boxShadow: edge } : null, ...extra });
  const body = (c, row) => {
    const raw = row[c.key] ?? "";
    if (editing && editing.id === row.__id && editing.key === c.key)
      return /* @__PURE__ */ _jsx(Editor, { initial: raw, list: listId(c), align: numeric(c.type) ? "right" : "left", onCommit: (v) => edit(row.__id, c.key, v), onCancel: () => setEditing(null) });
    if (c.key === base.identity) {
      const pic = base.avatar ? row[base.avatar] : "";
      return /* @__PURE__ */ _jsxs("span", { style: { display: "inline-flex", alignItems: "center", gap: 10, maxWidth: "100%", verticalAlign: "middle" }, children: [pic ? /* @__PURE__ */ _jsx("img", { src: pic, alt: "", loading: "lazy", style: { width: 26, height: 26, borderRadius: "50%", objectFit: "cover", flex: "none", background: "var(--hover)" } }) : /* @__PURE__ */ _jsx("span", { style: badgeStyle(raw, dark, 26), children: initials(raw) }), f.drawer ? /* @__PURE__ */ _jsx("button", { type: "button", className: "nm", onClick: () => setOpenId(row.__id), children: raw || "Untitled" }) : /* @__PURE__ */ _jsx("span", { style: { fontWeight: 550, overflow: "hidden", textOverflow: "ellipsis" }, children: raw || "Untitled" })] });
    }
    if (!raw)
      return /* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)" }, children: "\u2014" });
    switch (c.type) {
      case "status":
        return /* @__PURE__ */ _jsxs("span", { style: pillStyle(raw, dark), children: [/* @__PURE__ */ _jsx("span", { style: dotStyle(raw, dark) }), raw] });
      case "boolean": {
        const on = truthy(raw);
        return /* @__PURE__ */ _jsxs("span", { style: { display: "inline-flex", alignItems: "center", gap: 7, color: on ? "var(--text)" : "var(--muted)" }, children: [/* @__PURE__ */ _jsx("span", { style: { width: 6, height: 6, borderRadius: 3, background: on ? tone("green", dark) : "var(--edge)" } }), on ? "Yes" : "No"] });
      }
      case "email":
        return /* @__PURE__ */ _jsx("a", { className: "lnk", href: `mailto:${raw}`, style: { color: "var(--muted)" }, children: raw });
      case "url":
        return /* @__PURE__ */ _jsx("a", { className: "lnk", href: raw, target: "_blank", rel: "noopener noreferrer", style: { color: "var(--ac)" }, children: show(c, raw) });
      case "image":
        return /* @__PURE__ */ _jsx("img", { src: raw, alt: "", loading: "lazy", style: { width: 28, height: 28, borderRadius: 7, objectFit: "cover", verticalAlign: "middle", background: "var(--hover)" } });
      case "number":
      case "currency":
      case "percent": {
        const txt = /* @__PURE__ */ _jsx("span", { style: { fontVariantNumeric: "tabular-nums" }, children: show(c, raw) });
        if (!bars)
          return txt;
        return /* @__PURE__ */ _jsxs("span", { style: { display: "flex", alignItems: "center", gap: 10, justifyContent: "flex-end" }, children: [/* @__PURE__ */ _jsx("span", { style: { flex: "1 1 auto", maxWidth: 64, height: 4, borderRadius: 4, background: "var(--line)", overflow: "hidden" }, children: /* @__PURE__ */ _jsx("span", { style: { display: "block", height: "100%", width: `${share(c, raw, stats[c.key]) * 100}%`, background: "var(--ac)", opacity: 0.8, borderRadius: 4, transition: "width .25s" } }) }), txt] });
      }
      default:
        return show(c, raw);
    }
  };
  const hasData = cols.length > 0;
  return /* @__PURE__ */ _jsxs("div", { className: sc, tabIndex: -1, onKeyDown: onKey, onDragOver: (e) => {
    if (f.importData && Array.from(e.dataTransfer.types || []).includes("Files")) {
      e.preventDefault();
      if (!dropping)
        setDropping(true);
    }
  }, onDragLeave: (e) => {
    if (!e.currentTarget.contains(e.relatedTarget))
      setDropping(false);
  }, onDrop: (e) => {
    if (!f.importData)
      return;
    e.preventDefault();
    setDropping(false);
    importFile(e.dataTransfer.files?.[0]);
  }, style: { ...r.style, ...paint(dark, look.accent, look.radius), position: "relative", width: "100%", height: "100%", display: "flex", flexDirection: "column", overflow: "hidden", background: "var(--bg)", color: "var(--text)", border: look.border ? "1px solid var(--line)" : "none", borderRadius: "var(--r)", fontSize: 13, lineHeight: 1.45, outline: "none", ...r.font }, children: [/* @__PURE__ */ _jsx("style", { children: styleSheet(sc, reduced) }), Object.entries(lists).map(([k, vals]) => /* @__PURE__ */ _jsx("datalist", { id: `${sc}-${k}`, children: vals.map((v) => /* @__PURE__ */ _jsx("option", { value: v }, v)) }, k)), /* @__PURE__ */ _jsxs("div", { style: { padding: "18px 20px 14px", display: "flex", flexDirection: "column", gap: 14, borderBottom: "1px solid var(--line)", position: "relative", zIndex: 20 }, children: [/* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }, children: [/* @__PURE__ */ _jsxs("div", { style: { minWidth: 0, flex: "1 1 200px" }, children: [/* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }, children: [r.title ? /* @__PURE__ */ _jsx("div", { style: { fontSize: "1.25em", fontWeight: 600, letterSpacing: "-0.015em", lineHeight: 1.25 }, children: r.title }) : null, /* @__PURE__ */ _jsxs("span", { style: { fontSize: "0.82em", color: "var(--muted)", border: "1px solid var(--line)", borderRadius: 999, padding: "1px 8px", fontVariantNumeric: "tabular-nums" }, children: [rows.length.toLocaleString(), " ", rows.length === 1 ? "record" : "records"] }), imported ? /* @__PURE__ */ _jsxs("button", { type: "button", className: "chip", onClick: () => {
    setImported(null);
    say("Back to the original data");
  }, title: "Discard the imported file", children: ["Imported file", /* @__PURE__ */ _jsx("span", { className: "cx", children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.reset, size: 12, w: 2.2 }) })] }) : null] }), r.subtitle ? /* @__PURE__ */ _jsx("div", { style: { color: "var(--muted)", marginTop: 4, fontSize: "0.93em" }, children: r.subtitle }) : null] }), /* @__PURE__ */ _jsxs("div", { style: { display: "flex", gap: 8 }, children: [f.importData ? /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsx("input", { ref: fileRef, type: "file", accept: ".csv,.tsv,.txt,text/csv", style: { display: "none" }, onChange: (e) => {
    importFile(e.target.files?.[0]);
    e.target.value = "";
  } }), /* @__PURE__ */ _jsxs("button", { type: "button", className: "tb", onClick: () => fileRef.current?.click(), title: "Import a CSV (or drop one on the table)", children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.upload, size: 15 }), /* @__PURE__ */ _jsx("span", { className: "lb", children: "Import" })] })] }) : null, f.exportData ? /* @__PURE__ */ _jsxs("div", { style: { position: "relative" }, children: [/* @__PURE__ */ _jsxs("button", { type: "button", className: "tb pr", "data-on": menu === "export" ? "1" : "0", "aria-haspopup": "menu", "aria-expanded": menu === "export", onClick: () => setMenu(menu === "export" ? null : "export"), children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.download, size: 15 }), /* @__PURE__ */ _jsx("span", { className: "lb", children: "Export" }), /* @__PURE__ */ _jsx(Glyph, { d: ICON.down, size: 14 })] }), menu === "export" ? /* @__PURE__ */ _jsx(Pop, { width: 250, onClose: () => setMenu(null), children: [{ label: "Export current view", sub: `${sorted.length.toLocaleString()} rows \xB7 ${exportCols().length} columns`, icon: ICON.download, run: () => download(sorted, exportCols()) }, ...picked.size ? [{ label: "Export selected", sub: `${picked.size} rows`, icon: ICON.download, run: () => download(rows.filter((x) => picked.has(x.__id)), exportCols(), "-selected") }] : [], { label: "Export all data", sub: `${rows.length.toLocaleString()} rows \xB7 every column`, icon: ICON.table, run: () => download(rows, cols, "-all") }, { label: "Copy view to clipboard", sub: "Pastes into any spreadsheet", icon: ICON.copy, run: () => copy(asText(sorted, exportCols(), "	"), "Copied to clipboard") }].map((it) => /* @__PURE__ */ _jsxs("button", { type: "button", className: "mi", onClick: () => {
    setMenu(null);
    it.run();
  }, children: [/* @__PURE__ */ _jsx("span", { style: { color: "var(--muted)" }, children: /* @__PURE__ */ _jsx(Glyph, { d: it.icon, size: 15 }) }), /* @__PURE__ */ _jsxs("span", { style: { display: "flex", flexDirection: "column", minWidth: 0 }, children: [/* @__PURE__ */ _jsx("span", { style: { fontWeight: 500 }, children: it.label }), /* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)", fontSize: "0.86em" }, children: it.sub })] })] }, it.label)) }) : null] }) : null] })] }), tabs.length > 1 ? /* @__PURE__ */ _jsxs("div", { className: "nb", role: "tablist", style: { display: "flex", gap: 2, overflowX: "auto", margin: "0 -4px", padding: "0 4px" }, children: [/* @__PURE__ */ _jsxs("button", { type: "button", role: "tab", className: "tab", "data-on": !tab ? "1" : "0", "aria-selected": !tab, onClick: () => setTab(null), children: ["All", /* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)", fontVariantNumeric: "tabular-nums" }, children: matched.length })] }), tabs.map((t) => /* @__PURE__ */ _jsxs("button", { type: "button", role: "tab", className: "tab", "data-on": tab === t.key ? "1" : "0", "aria-selected": tab === t.key, onClick: () => setTab(tab === t.key ? null : t.key), children: [/* @__PURE__ */ _jsx("span", { style: dotStyle(t.label, dark) }), t.label, /* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)", fontVariantNumeric: "tabular-nums" }, children: t.n })] }, t.key))] }) : null, /* @__PURE__ */ _jsxs("div", { style: { display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }, children: [f.search ? /* @__PURE__ */ _jsxs("label", { style: { height: 34, flex: "1 1 220px", maxWidth: 400, display: "flex", alignItems: "center", gap: 8, padding: "0 6px 0 10px", border: "1px solid var(--line)", borderRadius: "var(--r2)", background: "var(--panel)", color: "var(--subtle)", cursor: "text" }, children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.search, size: 15 }), /* @__PURE__ */ _jsx("input", { ref: searchRef, value: query, onChange: (e) => setQuery(e.target.value), placeholder: facet ? `Search\u2026 try ${facet.label.toLowerCase().replace(/\s+/g, "")}:${(tabs[0]?.label || "value").toLowerCase().split(" ")[0]}` : "Search records\u2026", "aria-label": "Search records", style: { flex: 1, minWidth: 0, height: "100%", border: 0, background: "transparent", color: "var(--text)" } }), query ? /* @__PURE__ */ _jsx("button", { type: "button", className: "ib", style: { width: 24, height: 24 }, "aria-label": "Clear search", onClick: () => {
    setQuery("");
    searchRef.current?.focus();
  }, children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.x, size: 14 }) }) : /* @__PURE__ */ _jsx("kbd", { className: "hs", style: { fontFamily: "inherit", fontSize: "0.8em", color: "var(--subtle)", border: "1px solid var(--line)", borderRadius: 5, padding: "0 6px", lineHeight: "18px" }, children: "/" })] }) : null, /* @__PURE__ */ _jsx("div", { style: { flex: 1 } }), f.filters && hasData ? /* @__PURE__ */ _jsxs("div", { style: { position: "relative" }, children: [/* @__PURE__ */ _jsxs("button", { type: "button", className: "tb", "data-on": menu === "filter" || activeRules ? "1" : "0", "aria-haspopup": "dialog", "aria-expanded": menu === "filter", onClick: () => {
    setFocusCol(null);
    setMenu(menu === "filter" ? null : "filter");
  }, children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.filter, size: 15 }), /* @__PURE__ */ _jsx("span", { className: "lb", children: "Filter" }), activeRules ? /* @__PURE__ */ _jsx("span", { style: { minWidth: 18, height: 18, borderRadius: 999, background: "var(--ac)", color: "#fff", fontSize: "0.78em", display: "inline-grid", placeItems: "center", padding: "0 5px", fontWeight: 600 }, children: activeRules }) : null] }), menu === "filter" ? /* @__PURE__ */ _jsx(Pop, { width: 290, onClose: () => setMenu(null), children: focusCol && cols.find((c) => c.key === focusCol) ? /* @__PURE__ */ _jsx(RuleEditor, { col: cols.find((c) => c.key === focusCol), rows, value: rules[focusCol], dark, onChange: (v) => setRule(focusCol, v), onBack: () => setFocusCol(null) }) : /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsx("div", { style: eyebrow, children: "Filter by" }), cols.filter((c) => c.type !== "image").map((c) => /* @__PURE__ */ _jsxs("button", { type: "button", className: "mi", onClick: () => setFocusCol(c.key), children: [/* @__PURE__ */ _jsx("span", { style: { width: 22, height: 22, borderRadius: 6, background: "var(--hover)", color: "var(--muted)", display: "grid", placeItems: "center", fontSize: "0.8em", flex: "none" }, children: KIND_MARK[c.type] }), /* @__PURE__ */ _jsx("span", { style: { flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: c.label }), ruleOn(rules[c.key]) ? /* @__PURE__ */ _jsx("span", { style: { width: 7, height: 7, borderRadius: 4, background: "var(--ac)" } }) : null, /* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)" }, children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.right, size: 14 }) })] }, c.key))] }) }) : null] }) : null, f.columnMenu && hasData ? /* @__PURE__ */ _jsxs("div", { style: { position: "relative" }, children: [/* @__PURE__ */ _jsxs("button", { type: "button", className: "tb", "data-on": menu === "view" ? "1" : "0", "aria-haspopup": "dialog", "aria-expanded": menu === "view", onClick: () => setMenu(menu === "view" ? null : "view"), children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.view, size: 15 }), /* @__PURE__ */ _jsx("span", { className: "lb", children: "View" })] }), menu === "view" ? /* @__PURE__ */ _jsxs(Pop, { width: 270, onClose: () => setMenu(null), children: [/* @__PURE__ */ _jsx("div", { style: eyebrow, children: "Density" }), /* @__PURE__ */ _jsx("div", { style: { display: "flex", gap: 2, padding: 3, margin: "0 4px 4px", background: "var(--hover)", borderRadius: 9 }, children: ["compact", "default", "comfortable"].map((d) => /* @__PURE__ */ _jsx("button", { type: "button", className: "seg", "data-on": density === d ? "1" : "0", onClick: () => setDensity(d), children: d === "compact" ? "Compact" : d === "default" ? "Default" : "Relaxed" }, d)) }), numericShown ? /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsx(Switch, { on: footer, onChange: setFooter, label: "Summary row" }), /* @__PURE__ */ _jsx(Switch, { on: bars, onChange: setBars, label: "Inline data bars" })] }) : null, /* @__PURE__ */ _jsx("div", { style: rule }), /* @__PURE__ */ _jsxs("div", { style: { ...eyebrow, display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [/* @__PURE__ */ _jsxs("span", { children: ["Columns \xB7 ", visible.length, "/", cols.length] }), /* @__PURE__ */ _jsxs("span", { style: { display: "flex", gap: 10, textTransform: "none", letterSpacing: 0 }, children: [Object.keys(widths).length ? /* @__PURE__ */ _jsx("button", { type: "button", className: "txt", style: { fontSize: "1.2em" }, onClick: () => setWidths({}), children: "Reset widths" }) : null, visible.length < cols.length ? /* @__PURE__ */ _jsx("button", { type: "button", className: "txt", style: { fontSize: "1.2em" }, onClick: () => setHidden({}), children: "Show all" }) : null] })] }), cols.map((c) => {
    const on = !hidden[c.key];
    const toggle = () => {
      if (on && visible.length <= 1)
        return;
      setHidden((h) => ({ ...h, [c.key]: on }));
    };
    return /* @__PURE__ */ _jsxs("button", { type: "button", className: "mi", onClick: toggle, children: [/* @__PURE__ */ _jsx(Tick, { decor: true, state: on ? 1 : 0, label: `Show ${c.label}` }), /* @__PURE__ */ _jsx("span", { style: { flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: on ? "var(--text)" : "var(--muted)" }, children: c.label }), /* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)", fontSize: "0.85em" }, children: KIND_MARK[c.type] })] }, c.key);
  })] }) : null] }) : null] }), activeRules || parsedQ.scoped.length ? /* @__PURE__ */ _jsxs("div", { style: { display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", marginTop: -4 }, children: [liveRules.map(({ col, rule: rl }) => /* @__PURE__ */ _jsxs("span", { className: "chip", role: "button", tabIndex: 0, onClick: () => {
    setFocusCol(col.key);
    setMenu("filter");
  }, onKeyDown: (e) => {
    if (e.key === "Enter") {
      setFocusCol(col.key);
      setMenu("filter");
    }
  }, children: [/* @__PURE__ */ _jsx("span", { style: { overflow: "hidden", textOverflow: "ellipsis" }, children: ruleLabel(col, rl) }), /* @__PURE__ */ _jsx("span", { className: "cx", role: "button", "aria-label": `Remove ${col.label} filter`, onClick: (e) => {
    e.stopPropagation();
    setRule(col.key, null);
  }, children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.x, size: 12, w: 2.2 }) })] }, col.key)), parsedQ.scoped.map((s, i) => /* @__PURE__ */ _jsxs("span", { className: "chip", style: { borderStyle: "dashed", cursor: "default", paddingRight: 10 }, children: [s.col.label, " \xB7 ", s.term] }, "q" + i)), /* @__PURE__ */ _jsx("button", { type: "button", className: "txt", style: { marginLeft: 4, fontSize: "0.92em" }, onClick: () => {
    setRules({});
    setQuery("");
  }, children: "Clear all" })] }) : null] }), f.selection && headState === 1 && sorted.length > pageRows.length ? /* @__PURE__ */ _jsx("div", { style: { padding: "7px 20px", fontSize: "0.92em", background: "var(--ac-soft)", display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap", borderBottom: "1px solid var(--line)" }, children: allMatching ? /* @__PURE__ */ _jsxs(_Fragment, { children: ["All ", sorted.length.toLocaleString(), " matching records are selected.", /* @__PURE__ */ _jsx("button", { type: "button", className: "txt", onClick: () => setPicked(/* @__PURE__ */ new Set()), children: "Clear selection" })] }) : /* @__PURE__ */ _jsxs(_Fragment, { children: ["All ", pageRows.length, " on this page are selected.", /* @__PURE__ */ _jsxs("button", { type: "button", className: "txt", onClick: () => setPicked(new Set(sorted.map((x) => x.__id))), children: ["Select all ", sorted.length.toLocaleString(), " ", "matching"] })] }) }) : null, /* @__PURE__ */ _jsxs("div", { className: "sc", onScroll: (e) => setSlid(e.currentTarget.scrollLeft > 2), style: { flex: 1, minHeight: 0, overflow: "auto", position: "relative", zIndex: 1 }, children: [hasData ? /* @__PURE__ */ _jsxs("table", { style: { width: totalW, minWidth: "100%", tableLayout: "fixed", borderCollapse: "separate", borderSpacing: 0 }, children: [/* @__PURE__ */ _jsxs("colgroup", { children: [f.selection ? /* @__PURE__ */ _jsx("col", { style: { width: selW } }) : null, colW.map((w, i) => /* @__PURE__ */ _jsx("col", { style: { width: w } }, visible[i].key)), f.drawer ? /* @__PURE__ */ _jsx("col", { style: { width: actW } }) : null] }), /* @__PURE__ */ _jsx("thead", { children: /* @__PURE__ */ _jsxs("tr", { children: [f.selection ? /* @__PURE__ */ _jsx("th", { style: { position: "sticky", top: 0, left: 0, zIndex: 4, height: 40, background: "var(--head)", borderBottom: "1px solid var(--line)", textAlign: "center" }, children: /* @__PURE__ */ _jsx(Tick, { state: headState, onToggle: togglePage, label: "Select rows on this page" }) }) : null, visible.map((c, ci) => {
    const si = sorts.findIndex((s2) => s2.key === c.key);
    const s = si >= 0 ? sorts[si] : null;
    const pinned = c.key === pinKey;
    return /* @__PURE__ */ _jsxs("th", { "aria-sort": s ? s.dir === 1 ? "ascending" : "descending" : void 0, style: { position: "sticky", top: 0, zIndex: pinned ? 4 : 3, left: pinned ? selW : void 0, boxShadow: pinned ? edge : void 0, height: 40, padding: `0 ${padX}px`, background: "var(--head)", borderBottom: "1px solid var(--line)", textAlign: numeric(c.type) ? "right" : "left", fontWeight: 500, fontSize: "0.86em", color: s ? "var(--text)" : "var(--muted)", whiteSpace: "nowrap", userSelect: "none" }, children: [/* @__PURE__ */ _jsxs("button", { type: "button", className: "hb" + (f.sort ? " cl" : ""), title: f.sort ? "Sort \xB7 Shift-click to add a secondary sort" : void 0, onClick: (e) => f.sort && sortBy(c.key, e.shiftKey), style: { flexDirection: numeric(c.type) ? "row-reverse" : "row", cursor: f.sort ? "pointer" : "default" }, children: [/* @__PURE__ */ _jsx("span", { style: { overflow: "hidden", textOverflow: "ellipsis" }, children: c.label }), f.sort ? s ? /* @__PURE__ */ _jsxs("span", { style: { display: "inline-flex", alignItems: "center", gap: 1, color: "var(--ac)" }, children: [/* @__PURE__ */ _jsx(Glyph, { d: s.dir === 1 ? ICON.asc : ICON.desc, size: 13, w: 2.2 }), sorts.length > 1 ? /* @__PURE__ */ _jsx("span", { style: { fontSize: "0.85em", fontWeight: 600 }, children: si + 1 }) : null] }) : /* @__PURE__ */ _jsx("span", { className: "si", children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.both, size: 13, w: 2 }) }) : null] }), f.resize ? /* @__PURE__ */ _jsx("span", { className: "rz", title: "Drag to resize \xB7 double-click to reset", onPointerDown: (e) => startResize(e, c.key, colW[ci]), onDoubleClick: () => setWidths((w) => {
      const n = { ...w };
      delete n[c.key];
      return n;
    }) }) : null] }, c.key);
  }), f.drawer ? /* @__PURE__ */ _jsx("th", { style: { position: "sticky", top: 0, right: 0, zIndex: 3, background: "var(--head)", borderBottom: "1px solid var(--line)" } }) : null] }) }), /* @__PURE__ */ _jsx("tbody", { children: loading ? Array.from({ length: 7 }).map((_, i) => /* @__PURE__ */ _jsxs("tr", { children: [f.selection ? /* @__PURE__ */ _jsx("td", { style: cellStyle(null, 0) }) : null, visible.map((c, ci) => /* @__PURE__ */ _jsx("td", { style: cellStyle(c, ci), children: /* @__PURE__ */ _jsx("span", { style: { display: "inline-block", height: 9, width: `${35 + (i * 13 + ci * 29) % 50}%`, borderRadius: 6, background: "var(--hover)" } }) }, c.key)), f.drawer ? /* @__PURE__ */ _jsx("td", { style: cellStyle(null, 0) }) : null] }, "sk" + i)) : pageRows.map((row, ri) => {
    const on = picked.has(row.__id);
    return /* @__PURE__ */ _jsxs("tr", { "data-sel": on ? "1" : "0", "data-alt": opt.striped && ri % 2 ? "1" : "0", children: [f.selection ? /* @__PURE__ */ _jsx("td", { style: { ...cellStyle(null, 0), padding: 0, textAlign: "center", position: "sticky", left: 0, zIndex: 1 }, children: /* @__PURE__ */ _jsx(Tick, { state: on ? 1 : 0, onToggle: (e) => pickRow(row.__id, ri, e.shiftKey), label: "Select row" }) }) : null, visible.map((c, ci) => {
      const raw = row[c.key] ?? "";
      const canEdit = f.inlineEdit && c.type !== "image";
      const isEditing = editing && editing.id === row.__id && editing.key === c.key;
      return /* @__PURE__ */ _jsx("td", { title: !isEditing && raw && (c.type === "text" || c.type === "email") ? raw : void 0, onDoubleClick: () => canEdit && setEditing({ id: row.__id, key: c.key }), style: cellStyle(c, ci, isEditing ? { padding: `0 ${Math.max(6, padX - 8)}px`, overflow: "visible" } : void 0), children: body(c, row) }, c.key);
    }), f.drawer ? /* @__PURE__ */ _jsx("td", { style: { ...cellStyle(null, 0), padding: 0, textAlign: "center", position: "sticky", right: 0, zIndex: 1 }, children: /* @__PURE__ */ _jsx("button", { type: "button", className: "ib act", "aria-label": "Open record", title: "Open record", onClick: () => setOpenId(row.__id), style: { margin: "0 auto" }, children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.open, size: 15 }) }) }) : null] }, row.__id);
  }) }), footer && numericShown && !loading && sorted.length > 0 ? /* @__PURE__ */ _jsx("tfoot", { children: /* @__PURE__ */ _jsxs("tr", { children: [f.selection ? /* @__PURE__ */ _jsx("td", { style: { position: "sticky", bottom: 0, left: 0, zIndex: 4, height: 42, background: "var(--head)", borderTop: "1px solid var(--line)" } }) : null, visible.map((c, ci) => {
    const t = stats[c.key];
    const pinned = c.key === pinKey;
    const foot = { position: "sticky", bottom: 0, zIndex: pinned ? 4 : 2, left: pinned ? selW : void 0, boxShadow: pinned ? edge : void 0, height: 42, padding: `0 ${padX}px`, background: "var(--head)", borderTop: "1px solid var(--line)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" };
    if (!t || !t.count)
      return /* @__PURE__ */ _jsx("td", { style: { ...foot, color: "var(--subtle)", fontSize: "0.9em" }, children: ci === 0 ? `${sorted.length.toLocaleString()} rows` : "" }, c.key);
    const mode = aggs[c.key] ?? (c.type === "percent" ? 1 : 0);
    const val = [t.sum, t.sum / t.count, t.min, t.max][mode];
    return /* @__PURE__ */ _jsx("td", { style: { ...foot, textAlign: "right" }, children: /* @__PURE__ */ _jsxs("button", { type: "button", className: "hb cl", title: "Click to switch Sum \xB7 Avg \xB7 Min \xB7 Max", onClick: () => setAggs((a) => ({ ...a, [c.key]: (mode + 1) % 4 })), children: [/* @__PURE__ */ _jsx("span", { style: { color: "var(--subtle)", fontSize: "0.78em", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em" }, children: AGG[mode] }), /* @__PURE__ */ _jsx("span", { style: { fontWeight: 600, color: "var(--text)", fontVariantNumeric: "tabular-nums" }, children: showTotal(c, val) })] }) }, c.key);
  }), f.drawer ? /* @__PURE__ */ _jsx("td", { style: { position: "sticky", bottom: 0, right: 0, zIndex: 2, background: "var(--head)", borderTop: "1px solid var(--line)" } }) : null] }) }) : null] }) : null, !loading && (!hasData || !pageRows.length) ? /* @__PURE__ */ _jsxs("div", { style: { padding: "56px 24px", display: "flex", flexDirection: "column", alignItems: "center", gap: 10, textAlign: "center", position: "sticky", left: 0, width: "100%" }, children: [/* @__PURE__ */ _jsx("span", { style: { width: 44, height: 44, borderRadius: 12, background: "var(--hover)", color: "var(--muted)", display: "grid", placeItems: "center" }, children: /* @__PURE__ */ _jsx(Glyph, { d: hasData ? ICON.search : ICON.table, size: 20 }) }), /* @__PURE__ */ _jsx("div", { style: { fontWeight: 600, fontSize: "1.05em" }, children: error ? "Data unavailable" : !hasData ? "No data yet" : "No matching records" }), /* @__PURE__ */ _jsx("div", { style: { color: "var(--muted)", maxWidth: 320 }, children: error || (!hasData ? "Import a CSV file or drop one here to get started." : "Try a different search or loosen your filters.") }), hasData && (query || activeRules || tab) ? /* @__PURE__ */ _jsx("button", { type: "button", className: "tb", style: { marginTop: 6 }, onClick: () => {
    setQuery("");
    setRules({});
    setTab(null);
  }, children: "Clear search & filters" }) : null, !hasData && f.importData ? /* @__PURE__ */ _jsxs("button", { type: "button", className: "tb pr", style: { marginTop: 6 }, onClick: () => fileRef.current?.click(), children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.upload, size: 15 }), "Import CSV"] }) : null] }) : null] }), f.pagination && hasData ? /* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, padding: "10px 14px 10px 20px", borderTop: "1px solid var(--line)", flexWrap: "wrap", color: "var(--muted)", fontSize: "0.92em", minHeight: 54 }, children: [/* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", gap: 16 }, children: [/* @__PURE__ */ _jsx("span", { style: { fontVariantNumeric: "tabular-nums" }, children: sorted.length ? /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsxs("b", { style: { color: "var(--text)", fontWeight: 600 }, children: [(pg * size + 1).toLocaleString(), "\u2013", Math.min(sorted.length, pg * size + size).toLocaleString()] }), " ", "of ", sorted.length.toLocaleString()] }) : "0 results" }), /* @__PURE__ */ _jsxs("label", { className: "hs", style: { display: "inline-flex", alignItems: "center", gap: 7 }, children: ["Rows", /* @__PURE__ */ _jsx("select", { value: pageSize, onChange: (e) => setPageSize(Number(e.target.value)), style: { height: 28, border: "1px solid var(--line)", borderRadius: 7, background: "var(--panel)", color: "var(--text)", padding: "0 6px", cursor: "pointer" }, children: Array.from(/* @__PURE__ */ new Set([Math.max(1, opt.pageSize), 10, 25, 50, 100])).sort((a, b) => a - b).map((n) => /* @__PURE__ */ _jsx("option", { value: n, children: n }, n)) })] })] }), /* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", gap: 2 }, children: [/* @__PURE__ */ _jsx("button", { type: "button", className: "ib", "aria-label": "Previous page", disabled: pg === 0, onClick: () => setPage(pg - 1), children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.left }) }), /* @__PURE__ */ _jsx("span", { className: "hs", style: { display: "inline-flex", gap: 2 }, children: pageList(pg, pages).map((n, i) => n === "\u2026" ? /* @__PURE__ */ _jsx("span", { style: { width: 22, textAlign: "center", color: "var(--subtle)" }, children: "\u2026" }, "e" + i) : /* @__PURE__ */ _jsx("button", { type: "button", className: "pg", "data-on": n === pg ? "1" : "0", "aria-current": n === pg ? "page" : void 0, onClick: () => setPage(n), children: n + 1 }, n)) }), /* @__PURE__ */ _jsx("button", { type: "button", className: "ib", "aria-label": "Next page", disabled: pg >= pages - 1, onClick: () => setPage(pg + 1), children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.right }) })] })] }) : null, f.selection && f.bulkActions && picked.size > 0 ? /* @__PURE__ */ _jsxs("div", { className: "rise", role: "toolbar", "aria-label": "Bulk actions", style: { position: "absolute", left: "50%", bottom: bottomGap, transform: "translateX(-50%)", zIndex: 30, display: "flex", alignItems: "center", gap: 2, padding: "5px 5px 5px 14px", background: dark ? "#f2f2f5" : "#18181c", color: dark ? "#111114" : "#fafafa", borderRadius: 999, boxShadow: "0 14px 34px -10px rgba(0,0,0,.45)", whiteSpace: "nowrap", maxWidth: "calc(100% - 24px)" }, children: [/* @__PURE__ */ _jsxs("span", { style: { fontWeight: 600, marginRight: 8, fontVariantNumeric: "tabular-nums" }, children: [picked.size, " selected"] }), f.exportData ? /* @__PURE__ */ _jsxs("button", { type: "button", className: "bb", onClick: () => download(rows.filter((x) => picked.has(x.__id)), exportCols(), "-selected"), children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.download, size: 15 }), /* @__PURE__ */ _jsx("span", { className: "lb", children: "Export" })] }) : null, /* @__PURE__ */ _jsxs("button", { type: "button", className: "bb", onClick: () => copy(asText(rows.filter((x) => picked.has(x.__id)), exportCols(), "	"), `Copied ${picked.size} rows`), children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.copy, size: 15 }), /* @__PURE__ */ _jsx("span", { className: "lb", children: "Copy" })] }), /* @__PURE__ */ _jsxs("button", { type: "button", className: "bb", style: { color: tone("red", !dark) }, onClick: () => removeRows(new Set(picked)), children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.trash, size: 15 }), /* @__PURE__ */ _jsx("span", { className: "lb", children: "Delete" })] }), /* @__PURE__ */ _jsx("span", { style: { width: 1, height: 18, background: "rgba(128,128,140,.35)", margin: "0 4px" } }), /* @__PURE__ */ _jsx("button", { type: "button", className: "bb", style: { padding: "0 8px" }, "aria-label": "Clear selection", onClick: () => setPicked(/* @__PURE__ */ new Set()), children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.x, size: 15 }) })] }) : null, toast ? /* @__PURE__ */ _jsxs("div", { className: "rise", role: "status", style: { position: "absolute", left: "50%", bottom: bottomGap + (picked.size && f.bulkActions && f.selection ? 50 : 0), transform: "translateX(-50%)", zIndex: 31, display: "flex", alignItems: "center", gap: 12, padding: "8px 8px 8px 14px", minHeight: 38, background: "var(--panel)", color: "var(--text)", border: "1px solid var(--line)", borderRadius: 10, boxShadow: "var(--shadow)", whiteSpace: "nowrap", maxWidth: "calc(100% - 24px)" }, children: [/* @__PURE__ */ _jsx("span", { style: { overflow: "hidden", textOverflow: "ellipsis" }, children: toast.msg }), toast.undo ? /* @__PURE__ */ _jsx("button", { type: "button", className: "txt", style: { padding: "0 6px" }, onClick: () => {
    setRows(toast.undo);
    setToast(null);
  }, children: "Undo" }) : /* @__PURE__ */ _jsx("span", { style: { width: 4 } })] }, toast.n) : null, f.drawer && openRow ? /* @__PURE__ */ _jsx("div", { className: "scr", onClick: () => setOpenId(null), style: { position: "absolute", inset: 0, zIndex: 40, background: "var(--scrim)" }, children: /* @__PURE__ */ _jsxs("aside", { className: "drw", role: "dialog", "aria-label": "Record details", onClick: (e) => e.stopPropagation(), style: { position: "absolute", top: 0, right: 0, bottom: 0, width: "min(440px, 100%)", background: "var(--panel)", borderLeft: "1px solid var(--line)", boxShadow: "var(--shadow)", display: "flex", flexDirection: "column" }, children: [/* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", gap: 2, padding: "10px 10px 10px 20px", borderBottom: "1px solid var(--line)" }, children: [/* @__PURE__ */ _jsx("span", { style: { flex: 1, color: "var(--muted)", fontSize: "0.9em", fontVariantNumeric: "tabular-nums" }, children: openPos >= 0 ? `${openPos + 1} of ${sorted.length.toLocaleString()}` : "Record" }), /* @__PURE__ */ _jsx("button", { type: "button", className: "ib", "aria-label": "Previous record", disabled: openPos <= 0, onClick: () => setOpenId(sorted[openPos - 1].__id), children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.left }) }), /* @__PURE__ */ _jsx("button", { type: "button", className: "ib", "aria-label": "Next record", disabled: openPos < 0 || openPos >= sorted.length - 1, onClick: () => setOpenId(sorted[openPos + 1].__id), children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.right }) }), /* @__PURE__ */ _jsx("button", { type: "button", className: "ib", "aria-label": "Close", onClick: () => setOpenId(null), children: /* @__PURE__ */ _jsx(Glyph, { d: ICON.x }) })] }), (() => {
    const idCol = base.identity || cols[0]?.key;
    const name = idCol ? openRow[idCol] : "";
    const pic = base.avatar ? openRow[base.avatar] : "";
    const fv = facet ? openRow[facet.key] : "";
    return /* @__PURE__ */ _jsxs("div", { style: { padding: "20px 20px 12px", display: "flex", alignItems: "center", gap: 14 }, children: [pic ? /* @__PURE__ */ _jsx("img", { src: pic, alt: "", style: { width: 46, height: 46, borderRadius: "50%", objectFit: "cover", flex: "none" } }) : /* @__PURE__ */ _jsx("span", { style: badgeStyle(name, dark, 46), children: initials(name) }), /* @__PURE__ */ _jsxs("div", { style: { minWidth: 0, flex: 1 }, children: [/* @__PURE__ */ _jsx("div", { style: { fontSize: "1.2em", fontWeight: 600, letterSpacing: "-0.01em", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: name || "Untitled" }), fv ? /* @__PURE__ */ _jsx("div", { style: { marginTop: 5 }, children: /* @__PURE__ */ _jsxs("span", { style: pillStyle(fv, dark), children: [/* @__PURE__ */ _jsx("span", { style: dotStyle(fv, dark) }), fv] }) }) : null] })] });
  })(), /* @__PURE__ */ _jsxs("div", { className: "sc", style: { flex: 1, overflowY: "auto", padding: "4px 12px 20px" }, children: [f.inlineEdit ? /* @__PURE__ */ _jsx("div", { style: { ...eyebrow, padding: "6px 8px 8px" }, children: "Details \xB7 click a value to edit" }) : /* @__PURE__ */ _jsx("div", { style: { ...eyebrow, padding: "6px 8px 8px" }, children: "Details" }), cols.map((c) => /* @__PURE__ */ _jsx(DrawerField, { col: c, raw: openRow[c.key] ?? "", editable: f.inlineEdit, list: listId(c), dark, onCommit: (v) => edit(openRow.__id, c.key, v) }, openRow.__id + c.key))] }), /* @__PURE__ */ _jsxs("div", { style: { display: "flex", gap: 8, padding: "12px 20px", borderTop: "1px solid var(--line)" }, children: [/* @__PURE__ */ _jsxs("button", { type: "button", className: "tb", onClick: () => copy(JSON.stringify(Object.fromEntries(cols.map((c) => [c.label, openRow[c.key] ?? ""])), null, 2), "Record copied as JSON"), children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.copy, size: 15 }), "Copy JSON"] }), /* @__PURE__ */ _jsx("div", { style: { flex: 1 } }), f.bulkActions ? /* @__PURE__ */ _jsxs("button", { type: "button", className: "tb dg", onClick: () => removeRows(/* @__PURE__ */ new Set([openRow.__id])), children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.trash, size: 15 }), "Delete"] }) : null] })] }) }) : null, dropping ? /* @__PURE__ */ _jsx("div", { style: { position: "absolute", inset: 8, zIndex: 60, border: "2px dashed var(--ac)", borderRadius: "var(--r2)", background: "color-mix(in srgb, var(--bg) 90%, transparent)", display: "grid", placeItems: "center", pointerEvents: "none" }, children: /* @__PURE__ */ _jsxs("div", { style: { display: "flex", flexDirection: "column", alignItems: "center", gap: 8, color: "var(--ac)" }, children: [/* @__PURE__ */ _jsx(Glyph, { d: ICON.upload, size: 28 }), /* @__PURE__ */ _jsx("div", { style: { fontWeight: 600 }, children: "Drop a CSV to import" })] }) }) : null] });
}
function TabulaPro(props) {
  const isStatic = useIsStaticRenderer();
  if (isStatic)
    return /* @__PURE__ */ _jsx(StillTable, { ...props });
  return /* @__PURE__ */ _jsx(LiveTable, { ...props });
}
addPropertyControls(TabulaPro, { source: { type: ControlType.Enum, title: "Data", options: ["sample", "file", "url", "text"], optionTitles: ["Sample", "CSV File", "CSV URL", "Paste CSV"], defaultValue: "sample" }, csvFile: { type: ControlType.File, title: "CSV File", allowedFileTypes: ["csv", "tsv", "txt"], hidden: (p) => p.source !== "file" }, csvUrl: { type: ControlType.String, title: "CSV URL", placeholder: "https://\u2026/data.csv", defaultValue: "", hidden: (p) => p.source !== "url" }, csvText: { type: ControlType.String, title: "CSV", displayTextArea: true, defaultValue: "Name,Role,Status,Salary,Start date\nAva Hart,Designer,Active,$84000,2024-03-11\nLiam Rivera,Engineer,On leave,$112000,2023-09-02\nMaya Shah,Product,Active,$98000,2025-01-20\nNoah Brooks,Support,Pending,$56000,2025-06-02", hidden: (p) => p.source !== "text" }, title: { type: ControlType.String, title: "Title", defaultValue: "Customers" }, subtitle: { type: ControlType.String, title: "Subtitle", defaultValue: "" }, columns: { type: ControlType.Array, title: "Columns", defaultValue: [], control: { type: ControlType.Object, controls: { match: { type: ControlType.String, title: "Header", placeholder: "CSV header", defaultValue: "" }, label: { type: ControlType.String, title: "Label", placeholder: "Same as header", defaultValue: "" }, type: { type: ControlType.Enum, title: "Type", options: ["auto", ...KINDS], optionTitles: ["Auto", "Text", "Number", "Currency", "Percent", "Date", "Yes / No", "Status", "Email", "Link", "Image"], defaultValue: "auto" }, visible: { type: ControlType.Boolean, title: "Visible", defaultValue: true }, width: { type: ControlType.Number, title: "Width", min: 0, max: 600, step: 10, unit: "px", defaultValue: 0 } } } }, features: { type: ControlType.Object, title: "Features", controls: { search: { type: ControlType.Boolean, title: "Search", defaultValue: true }, filters: { type: ControlType.Boolean, title: "Filters", defaultValue: true }, tabs: { type: ControlType.Boolean, title: "Status Tabs", defaultValue: true }, sort: { type: ControlType.Boolean, title: "Sorting", defaultValue: true }, resize: { type: ControlType.Boolean, title: "Resize Cols", defaultValue: true }, selection: { type: ControlType.Boolean, title: "Row Select", defaultValue: true }, bulkActions: { type: ControlType.Boolean, title: "Bulk Actions", defaultValue: true }, inlineEdit: { type: ControlType.Boolean, title: "Inline Edit", defaultValue: true }, drawer: { type: ControlType.Boolean, title: "Detail Drawer", defaultValue: true }, columnMenu: { type: ControlType.Boolean, title: "View Menu", defaultValue: true }, exportData: { type: ControlType.Boolean, title: "Export", defaultValue: true }, importData: { type: ControlType.Boolean, title: "Import", defaultValue: true }, pagination: { type: ControlType.Boolean, title: "Pagination", defaultValue: true } } }, table: { type: ControlType.Object, title: "Table", controls: { pageSize: { type: ControlType.Number, title: "Page Size", min: 5, max: 100, step: 5, displayStepper: true, defaultValue: 10 }, density: { type: ControlType.Enum, title: "Density", options: ["compact", "default", "comfortable"], optionTitles: ["Compact", "Default", "Relaxed"], defaultValue: "default" }, summary: { type: ControlType.Boolean, title: "Summary Row", defaultValue: true }, dataBars: { type: ControlType.Boolean, title: "Data Bars", defaultValue: true }, pinFirst: { type: ControlType.Boolean, title: "Pin First Col", defaultValue: true }, striped: { type: ControlType.Boolean, title: "Striped", defaultValue: false }, tabsColumn: { type: ControlType.String, title: "Tabs Column", placeholder: "Auto", defaultValue: "" }, exportName: { type: ControlType.String, title: "Export Name", defaultValue: "table-export" } } }, appearance: { type: ControlType.Object, title: "Appearance", controls: { theme: { type: ControlType.Enum, title: "Theme", options: ["light", "dark", "auto"], optionTitles: ["Light", "Dark", "Auto"], displaySegmentedControl: true, defaultValue: "light" }, accent: { type: ControlType.Color, title: "Accent", defaultValue: "#5B5BD6" }, radius: { type: ControlType.Number, title: "Radius", min: 0, max: 32, step: 1, unit: "px", defaultValue: 14 }, border: { type: ControlType.Boolean, title: "Border", defaultValue: true } } }, font: { type: ControlType.Font, title: "Font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: 13, lineHeight: 1.45 } } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "TabulaPro", "slots": [], "annotations": { "framerDisableUnlink": "", "framerSupportedLayoutHeight": "any-prefer-fixed", "framerIntrinsicHeight": "680", "framerContractVersion": "1", "framerSupportedLayoutWidth": "any", "framerIntrinsicWidth": "1100" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  TabulaPro as default
};
