export interface TabulaproProps {
  /**
   * Data — pass as `source` not `data`.
   * Options: "sample" | "file" | "url" | "text"
   * @default "sample"
   */
  source?: 'sample' | 'file' | 'url' | 'text';
  /**
   * CSV File
   */
  csvFile?: string;
  /**
   * CSV URL
   * @default ""
   */
  csvUrl?: string;
  /**
   * CSV — pass as `csvText` not `csv`.
   * @default "Name,Role,Status,Salary,Start date
Ava Hart,Designer,Active,$84000,2024-03-11
Liam Rivera,Engineer,On leave,$112000,2023-09-02
Maya Shah,Product,Active,$98000,2025-01-20
Noah Brooks,Support,Pending,$56000,2025-06-02"
   */
  csvText?: string;
  /**
   * Title
   * @default "Customers"
   */
  title?: string;
  /**
   * Subtitle
   * @default ""
   */
  subtitle?: string;
  /**
   * Columns
   * @default []
   */
  columns?: unknown[];
  /**
   * Features
   */
  features?: Record<string, unknown>;
  /**
   * Table
   */
  table?: Record<string, unknown>;
  /**
   * Appearance
   */
  appearance?: Record<string, unknown>;
  /**
   * Font
   * @default {"fontSize":13,"lineHeight":1.45}
   */
  font?: string;
  /** Additional properties */
  [key: string]: unknown;
}
