export interface Card6Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "desktop" → IjmCXrHSn
   *   "tablet" → p9iL84HZ1
   */
  variant?: 'desktop' | 'tablet' | 'IjmCXrHSn' | 'p9iL84HZ1';
  /**
   * Number — pass as `RNzCx5WEA` not `number`.
   * @default "/01"
   */
  RNzCx5WEA?: string;
  onRNzCx5WEAChange?: string;
  /**
   * Title — pass as `eVmht0Y5p` not `title`.
   * @default "Strategy"
   */
  eVmht0Y5p?: string;
  oneVmht0Y5pChange?: string;
  /**
   * Description — pass as `Wq4pHn8td` not `description`.
   * @default "We uncover what makes the brand relevant, distinctive, and worth choosing. Through focused research and collaborative workshops, we define the audience, positioning, messaging, and creative direction that guide every decision that follows"
   */
  Wq4pHn8td?: string;
  onWq4pHn8tdChange?: string;
  /**
   * Tag 1 — pass as `QYgbf3AIl` not `tag1`.
   * @default "Brand positioning"
   */
  QYgbf3AIl?: string;
  onQYgbf3AIlChange?: string;
  /**
   * Tag 2 — pass as `qnSoinE_m` not `tag2`.
   * @default "Audience research"
   */
  qnSoinE_m?: string;
  onqnSoinE_mChange?: string;
  /**
   * Tag 3 — pass as `Q3mD_F8h8` not `tag3`.
   * @default "Creative strategy"
   */
  Q3mD_F8h8?: string;
  onQ3mD_F8h8Change?: string;
  /**
   * Tag 4 — pass as `zH3zHXgU0` not `tag4`.
   * @default "Messaging"
   */
  zH3zHXgU0?: string;
  onzH3zHXgU0Change?: string;
  /**
   * Tag 5 — pass as `khmdLkNuN` not `tag5`.
   * @default "Competitor review"
   */
  khmdLkNuN?: string;
  onkhmdLkNuNChange?: string;
  /**
   * Icon — pass as `TRsaiSSix` not `icon`.
   * @default {"identifier":"module:tHzQguoLnFudxIlr6wYw/IbixbXoxx0IJxuL5neaS/p7FybHNy8.js:default","moduleId":"tHzQguoLnFudxIlr6wYw"}
   */
  TRsaiSSix?: string;
  /** Additional properties */
  [key: string]: unknown;
}
