export interface Project4Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "desktop hover" → H8kHW0qpo
   *   "desktop" → VlABIrpuG
   *   "tablet" → sUvLx2_nI
   */
  variant?: 'desktop hover' | 'desktop' | 'tablet' | 'VlABIrpuG' | 'H8kHW0qpo' | 'sUvLx2_nI';
  /**
   * Image — pass as `gD7anJBt7` not `image`.
   */
  gD7anJBt7?: string;
  /**
   * Background — pass as `rxGTCXjpk` not `background`.
   */
  rxGTCXjpk?: string;
  /**
   * Description — pass as `pkBXZN_og` not `description`.
   * @default "A calm identity and digital experience for a contemporary countryside retreat, designed to express slow living, intentional hospitality, and a more thoughtful way to escape"
   */
  pkBXZN_og?: string;
  onpkBXZN_ogChange?: string;
  /**
   * Tag 1 — pass as `QGDalgak7` not `tag1`.
   * @default "Hospitality"
   */
  QGDalgak7?: string;
  onQGDalgak7Change?: string;
  /**
   * Tag 2 — pass as `d3W7sdU1f` not `tag2`.
   * @default "Website"
   */
  d3W7sdU1f?: string;
  ond3W7sdU1fChange?: string;
  /**
   * Tag 3 — pass as `idIBAmtsL` not `tag3`.
   * @default "Brand Identity"
   */
  idIBAmtsL?: string;
  onidIBAmtsLChange?: string;
  /**
   * Year — pass as `HeaV9LWDv` not `year`.
   * @default "2026"
   */
  HeaV9LWDv?: string;
  onHeaV9LWDvChange?: string;
  /**
   * Title — pass as `z0XMRj0cz` not `title`.
   * @default "Morrow"
   */
  z0XMRj0cz?: string;
  onz0XMRj0czChange?: string;
  /**
   * Cursor — pass as `aUFvJfrk9` not `cursor`.
   */
  aUFvJfrk9?: string;
  /**
   * Link — pass as `uJNES6QQj` not `link`.
   */
  uJNES6QQj?: string;
  /** Additional properties */
  [key: string]: unknown;
}
