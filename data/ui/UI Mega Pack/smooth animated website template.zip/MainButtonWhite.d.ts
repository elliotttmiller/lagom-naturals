export interface MainbuttonwhiteProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "main white - black" → ndKjIABOF
   *   "main white" → asN1v6l0w
   */
  variant?: 'main white - black' | 'main white' | 'asN1v6l0w' | 'ndKjIABOF';
  /**
   * Title — pass as `vmVThPPOW` not `title`.
   * @default "View projects"
   */
  vmVThPPOW?: string;
  onvmVThPPOWChange?: string;
  /**
   * Link — pass as `Q2vi2VjpC` not `link`.
   */
  Q2vi2VjpC?: string;
  /** Additional properties */
  [key: string]: unknown;
}
