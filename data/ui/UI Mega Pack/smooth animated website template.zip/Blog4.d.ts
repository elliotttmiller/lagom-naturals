export interface Blog4Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "descktop - short" → NLPrtSrS9
   *   "desktop - long" → RueVfECiU
   *   "tablet - long" → J6mce5Gq3
   *   "tablet - short" → LU2MnxShB
   */
  variant?: 'descktop - short' | 'desktop - long' | 'tablet - long' | 'tablet - short' | 'RueVfECiU' | 'NLPrtSrS9' | 'J6mce5Gq3' | 'LU2MnxShB';
  /**
   * Enter — pass as `LmhdlfWRR` not `enter`.
   */
  LmhdlfWRR?: () => void;
  /**
   * Tag — pass as `nJ0dYA0if` not `tag`.
   * @default "Brand Identity"
   */
  nJ0dYA0if?: string;
  onnJ0dYA0ifChange?: string;
  /**
   * Title — pass as `L7IX8LKMX` not `title`.
   * @default "How to build a brand that feels clear, not generic"
   */
  L7IX8LKMX?: string;
  onL7IX8LKMXChange?: string;
  /**
   * Date — pass as `WBFfPRS23` not `date`.
   * @default "July 18, 2026"
   */
  WBFfPRS23?: string;
  onWBFfPRS23Change?: string;
  /**
   * Time — pass as `KIMN5yKXI` not `time`.
   * @default "6 min read"
   */
  KIMN5yKXI?: string;
  onKIMN5yKXIChange?: string;
  /**
   * Image — pass as `WxiqDMCLn` not `image`.
   */
  WxiqDMCLn?: string;
  /**
   * Scroll Section — pass as `eQc6gpyp_` not `scrollSection`.
   */
  eQc6gpyp_?: string;
  /** Additional properties */
  [key: string]: unknown;
}
