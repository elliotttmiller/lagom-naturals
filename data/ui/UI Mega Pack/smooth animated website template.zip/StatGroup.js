var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/voMXdHlRoK6DXuPMCx1n/AYj5KkWNyI15nyjcpfCm/jQRptkh2f.js
import { jsx as _jsx, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ComponentViewportProvider, ControlType as ControlType2, cx, getFonts, getFontsFromSharedStyle, getPropertyControls, RichText, SmartComponentScopedContainer, useComponentViewport, useLocaleInfo, useVariantState, withCSS, withFX, withOptimizedAppearEffect } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/qpjhCcDm4G1NbFAlpMKV/OnyZiTlIjOBuSKcKQWFv/AnimatedNumberCounter_Prod.js
import { jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { addPropertyControls, ControlType, RenderTarget } from "./_framer-runtime.js";
import { useEffect, useState, useRef } from "react";
import { motion, useMotionValue, animate, useInView } from "framer-motion";
function AnimatedNumberCounter(props) {
  const { mode, start, end, value, decimals, commas, color, animation: animation2 } = props;
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  const Tag = props.tag;
  const MotionTag = motion[props.tag];
  const isDefault = mode == "default";
  const initialValue = isDefault ? start : value;
  const transition = isDefault ? animation2.transition : props.transition;
  const formatNumber = (number2) => {
    let numberString = number2.toFixed(decimals);
    if (commas) {
      numberString = numberString.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    return numberString;
  };
  const [number, setNumber] = useState(initialValue);
  const [finalValue, setFinalValue] = useState(number);
  const [currentAnimation, setCurrentAnimation] = useState(null);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: !props.animation.replay, amount: "some" });
  const motionValue = useMotionValue(value);
  const runAnimation = (from, to) => {
    if (!isCanvas) {
      if (currentAnimation) {
        currentAnimation.stop();
      }
      setFinalValue(to);
      setCurrentAnimation(animate(from, to, { ...transition, onUpdate: (latest) => {
        setNumber(latest);
      } }));
    }
  };
  useEffect(() => {
    if (isDefault && animation2.trigger == "appear") {
      runAnimation(start, end);
    }
  }, []);
  useEffect(() => {
    if (isDefault && animation2.trigger == "layerInView") {
      if (isInView) {
        runAnimation(start, end);
      } else {
        if (currentAnimation) {
          currentAnimation.stop();
        }
        setNumber(start);
      }
    }
  }, [isInView]);
  useEffect(() => {
    if (!isDefault) {
      runAnimation(number, value);
    }
  }, [value]);
  return /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsxs(Tag, { style: { ...props.style, margin: 0, opacity: 0, pointerEvents: "none", userSelect: "none", textWrap: props.balance ? "balance" : void 0, fontVariantNumeric: props.monospace ? "tabular-nums" : void 0, textAlign: "center", ...props.font }, children: [props.prefix, formatNumber(isCanvas ? initialValue : finalValue), props.suffix] }), /* @__PURE__ */ _jsxs(MotionTag, { ref, style: { position: "absolute", inset: 0, userSelect: props.userSelect ? "auto" : "none", fontVariantNumeric: props.monospace ? "tabular-nums" : void 0, margin: 0, ...color.mode == "solid" ? { color: color.color } : { WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundImage: `linear-gradient(${color.angle}deg, ${color.startColor}, ${color.endColor})` }, textDecoration: props.decoration, textWrap: props.balance ? "balance" : void 0, textAlign: "center", ...props.font, ...props.style }, children: [props.prefix, formatNumber(isCanvas ? initialValue : number), props.suffix] })] });
}
AnimatedNumberCounter.displayName = "Animated Number Counter";
addPropertyControls(AnimatedNumberCounter, { mode: { type: ControlType.Enum, options: ["default", "variants"], optionTitles: ["Default", "Variants"], displaySegmentedControl: true }, value: { type: ControlType.Number, defaultValue: 0, hidden: (props) => props.mode !== "variants" }, start: { type: ControlType.Number, defaultValue: 0, hidden: (props) => props.mode !== "default" }, end: { type: ControlType.Number, defaultValue: 100, hidden: (props) => props.mode !== "default" }, animation: { type: ControlType.Object, icon: "effect", hidden: (props) => props.mode !== "default", controls: { trigger: { type: ControlType.Enum, defaultValue: "layerInView", options: ["appear", "layerInView"], optionTitles: ["Appear", "Layer in View"], displaySegmentedControl: true, segmentedControlDirection: "vertical" }, replay: { type: ControlType.Boolean, defaultValue: true, hidden(props) {
  return props.trigger !== "layerInView";
} }, transition: { type: ControlType.Transition, defaultValue: { type: "spring", duration: 1, bounce: 0 } } } }, transition: { type: ControlType.Transition, defaultValue: { type: "spring", duration: 1, bounce: 0 }, hidden: (props) => props.mode !== "variants" }, decimals: { type: ControlType.Enum, defaultValue: 0, options: [0, 1, 2, 3], optionTitles: ["Off", "1", "2", "3"], displaySegmentedControl: true }, commas: { type: ControlType.Boolean, defaultValue: true }, font: { type: "font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: 16, lineHeight: 1 } }, color: { type: ControlType.Object, controls: { mode: { type: ControlType.Enum, defaultValue: "solid", options: ["solid", "gradient"], optionTitles: ["Solid", "Gradient"], displaySegmentedControl: true }, color: { type: ControlType.Color, defaultValue: "#000", hidden: (props) => props.mode !== "solid" }, startColor: { type: ControlType.Color, defaultValue: "#000", hidden: (props) => props.mode !== "gradient" }, endColor: { type: ControlType.Color, defaultValue: "#FFF", hidden: (props) => props.mode !== "gradient" }, angle: { type: ControlType.Number, defaultValue: 180, min: -360, max: 360, unit: "\xB0", hidden: (props) => props.mode !== "gradient" } } }, prefix: { type: ControlType.String, placeholder: "Prefix" }, suffix: { type: ControlType.String, placeholder: "Suffix" }, decoration: { type: ControlType.Enum, defaultValue: "none", options: ["none", "underline", "line-through"], optionTitles: ["None", "Underline", "Strikethrough"] }, balance: { type: ControlType.Boolean, defaultValue: false }, userSelect: { type: ControlType.Boolean, defaultValue: true }, tag: { type: ControlType.Enum, defaultValue: "p", displaySegmentedControl: true, options: ["h1", "h2", "h3", "p"], optionTitles: ["H1", "H2", "H3", "P"] }, monospace: { type: ControlType.Boolean, defaultValue: false, description: "More components at [Framer University](https://frameruni.link/cc)." } });

// http-url:https://framerusercontent.com/modules/ZiLwJyzmfb5yYsNLqpUJ/BL4yEGOxj5ihKvIyunNa/hP4T9JYKh.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["CUSTOMV2;Satoshi Regular", "CUSTOMV2;Satoshi Bold", "CUSTOMV2;Satoshi Bold Italic", "CUSTOMV2;Satoshi Italic"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Satoshi Regular", source: "custom", style: "normal", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/4DUCFyigHLkZDMSHultGoxWxF6c.woff2", weight: "400" }, { cssFamilyName: "Satoshi Bold", source: "custom", style: "normal", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/49nn5wajwTdLi5telQzvjmGNc.woff2", weight: "700" }, { cssFamilyName: "Satoshi Bold Italic", source: "custom", style: "italic", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/CG6kqUPNTBiTqgSzrGvDdU0g3M.woff2", weight: "700" }, { cssFamilyName: "Satoshi Italic", source: "custom", style: "italic", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/ph4HmTgh5F9Y8JSn9KvsRc89yI0.woff2", weight: "400" }] }];
var css = ['.framer-8YGpi .framer-styles-preset-1vb2uzv:not(.rich-text-wrapper), .framer-8YGpi .framer-styles-preset-1vb2uzv.rich-text-wrapper p { --framer-font-family: "Satoshi Regular", "Satoshi Regular Placeholder", sans-serif; --framer-font-family-bold: "Satoshi Bold", "Satoshi Bold Placeholder", sans-serif; --framer-font-family-bold-italic: "Satoshi Bold Italic", "Satoshi Bold Italic Placeholder", sans-serif; --framer-font-family-italic: "Satoshi Italic", "Satoshi Italic Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 15px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: rgba(0, 0, 0, 0.5); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className = "framer-8YGpi";

// http-url:https://framerusercontent.com/modules/r2induTfoPe0SIo6awlF/3mw0wKbziLfQKnMudeAd/jl62HjkML.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["CUSTOMV2;Satoshi Regular", "CUSTOMV2;Satoshi Bold", "CUSTOMV2;Satoshi Bold Italic", "CUSTOMV2;Satoshi Italic"]);
var fonts2 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Satoshi Regular", source: "custom", style: "normal", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/4DUCFyigHLkZDMSHultGoxWxF6c.woff2", weight: "400" }, { cssFamilyName: "Satoshi Bold", source: "custom", style: "normal", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/49nn5wajwTdLi5telQzvjmGNc.woff2", weight: "700" }, { cssFamilyName: "Satoshi Bold Italic", source: "custom", style: "italic", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/CG6kqUPNTBiTqgSzrGvDdU0g3M.woff2", weight: "700" }, { cssFamilyName: "Satoshi Italic", source: "custom", style: "italic", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/ph4HmTgh5F9Y8JSn9KvsRc89yI0.woff2", weight: "400" }] }];
var css2 = ['.framer-ekLIR .framer-styles-preset-yx9t1q:not(.rich-text-wrapper), .framer-ekLIR .framer-styles-preset-yx9t1q.rich-text-wrapper p { --framer-font-family: "Satoshi Regular", "Satoshi Regular Placeholder", sans-serif; --framer-font-family-bold: "Satoshi Bold", "Satoshi Bold Placeholder", sans-serif; --framer-font-family-bold-italic: "Satoshi Bold Italic", "Satoshi Bold Italic Placeholder", sans-serif; --framer-font-family-italic: "Satoshi Italic", "Satoshi Italic Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 14px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: -0.01em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: rgba(0, 0, 0, 0.5); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className2 = "framer-ekLIR";

// http-url:https://framerusercontent.com/modules/voMXdHlRoK6DXuPMCx1n/AYj5KkWNyI15nyjcpfCm/jQRptkh2f.js
var AnimatedNumberCounterFonts = getFonts(AnimatedNumberCounter);
var RichTextWithFXWithOptimizedAppearEffect = withOptimizedAppearEffect(withFX(RichText));
var AnimatedNumberCounterControls = getPropertyControls(AnimatedNumberCounter);
var cycleOrder = ["sQBy3JJsa", "lFJAGnsrB"];
var serializationHash = "framer-457MU";
var variantClassNames = { lFJAGnsrB: "framer-v-1phna0t", sQBy3JJsa: "framer-v-sz9tqb" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var transition2 = { damping: 60, delay: 0.3, mass: 1, stiffness: 320, type: "spring" };
var animation = { opacity: 1, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, transition: transition2, x: 0, y: 0 };
var animation1 = { opacity: 1e-3, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 40 };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "Variant 1": "sQBy3JJsa", "Variant 2": "lFJAGnsrB" };
var Variants = motion2.create(React.Fragment);
var humanReadableEnumMap = {};
var getProps = ({ decimals, end, height, id, prefix, start, suffix, title, width, ...props }) => {
  return { ...props, G2MMSMUsQ: end ?? props.G2MMSMUsQ ?? 50, hIUtCiZGx: title ?? props.hIUtCiZGx ?? "User Engagement", KLr6fBEML: humanReadableEnumMap[decimals] ?? decimals ?? props.KLr6fBEML ?? 0, PNxd93WHM: suffix ?? props.PNxd93WHM ?? "+", rxktUOGxV: start ?? props.rxktUOGxV ?? 0, T5wwjaNga: prefix ?? props.T5wwjaNga ?? "", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "sQBy3JJsa" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className3, layoutId, variant, G2MMSMUsQ, rxktUOGxV, hIUtCiZGx, PNxd93WHM, T5wwjaNga, KLr6fBEML, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "sQBy3JJsa", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [className2, className];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs2(motion2.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-sz9tqb", className3, classNames), "data-framer-name": "Variant 1", layoutDependency, layoutId: "StatGroup__sQBy3JJsa", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ lFJAGnsrB: { "data-framer-name": "Variant 2" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx(SmartComponentScopedContainer, { className: "framer-q05efx-container", "data-framer-name": "Counter", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "StatGroup__vrZKANJTS-container", name: "Counter", nodeId: "vrZKANJTS", rendersWithMotion: true, scopeId: "jQRptkh2f", children: /* @__PURE__ */ _jsx(AnimatedNumberCounter, { animation: { replay: false, transition: { delay: 0, duration: 2, ease: [0.44, 0, 0.56, 1], type: "tween" }, trigger: "layerInView" }, balance: false, color: { angle: 180, color: "var(--token-9498c07e-7b77-44b6-8e71-03fa38beafc1, rgb(0, 0, 0))", endColor: "rgb(255, 255, 255)", mode: "solid", startColor: "rgb(0, 0, 0)" }, commas: true, decimals: 0, decoration: "none", end: G2MMSMUsQ, font: { fontFamily: '"Geist", "Geist Placeholder", sans-serif', fontFeatureSettings: "'tnum' on", fontSize: "42px", fontStyle: "normal", fontWeight: 400, letterSpacing: "-0.05em", lineHeight: "1.2em", textAlign: "left" }, height: "100%", id: "vrZKANJTS", layoutId: "StatGroup__vrZKANJTS", mode: "default", monospace: false, name: "Counter", prefix: "", start: rxktUOGxV, suffix: PNxd93WHM, tag: "h2", transition: { bounce: 0, delay: 0, duration: 1, type: "spring" }, userSelect: false, value: 48, width: "100%", ...addPropertyOverrides({ lFJAGnsrB: { decimals: KLr6fBEML, font: { fontFamily: '"Geist", "Geist Placeholder", sans-serif', fontFeatureSettings: "'tnum' on", fontSize: "48px", fontStyle: "normal", fontWeight: 400, letterSpacing: "-0.03em", lineHeight: "1.2em", textAlign: "left" }, prefix: T5wwjaNga } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx(RichTextWithFXWithOptimizedAppearEffect, { __fromCanvasComponent: true, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, animate: animation, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion2.p, { className: "framer-styles-preset-yx9t1q", "data-styles-preset": "jl62HjkML", dir: "auto", children: "projects launched" }) }), className: "framer-hprvuq", "data-framer-appear-id": "hprvuq", fonts: ["Inter"], initial: animation1, layoutDependency, layoutId: "StatGroup__oO4LQff3V", optimized: true, style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: hIUtCiZGx, variants: { lFJAGnsrB: { "--extracted-r6o4lv": "var(--token-efaf5a33-59fe-4061-aab9-5ec624375fac, rgba(0, 0, 0, 0.6))" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ lFJAGnsrB: { animate: void 0, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion2.p, { className: "framer-styles-preset-1vb2uzv", "data-styles-preset": "hP4T9JYKh", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-efaf5a33-59fe-4061-aab9-5ec624375fac, rgba(0, 0, 0, 0.6)))" }, children: "User Engagement" }) }), initial: void 0, optimized: void 0 } }, baseVariant, gestureVariant) })] }) }) }) });
});
var css3 = [".framer-457MU.framer-1mfd3su, .framer-457MU .framer-1mfd3su { display: block; }", ".framer-457MU.framer-sz9tqb { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 4px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: min-content; }", ".framer-457MU .framer-q05efx-container { flex: none; height: auto; position: relative; width: auto; }", ".framer-457MU .framer-hprvuq { flex: none; height: auto; position: relative; white-space: pre; width: auto; z-index: 1; }", ".framer-457MU.framer-v-1phna0t.framer-sz9tqb { gap: 24px; }", ".framer-457MU.framer-v-1phna0t .framer-q05efx-container { order: 1; }", ".framer-457MU.framer-v-1phna0t .framer-hprvuq { align-self: stretch; order: 0; white-space: pre-wrap; word-break: break-word; word-wrap: break-word; z-index: unset; }", ...css2, ...css];
var FramerjQRptkh2f = withCSS(Component, css3, "framer-457MU");
var jQRptkh2f_default = FramerjQRptkh2f;
FramerjQRptkh2f.displayName = "Stat Group";
FramerjQRptkh2f.defaultProps = { height: 71, width: 108 };
addPropertyControls2(FramerjQRptkh2f, { variant: { options: ["sQBy3JJsa", "lFJAGnsrB"], optionTitles: ["Variant 1", "Variant 2"], title: "Variant", type: ControlType2.Enum }, G2MMSMUsQ: { defaultValue: 50, title: "End", type: ControlType2.Number }, onG2MMSMUsQChange: { changes: "G2MMSMUsQ", type: ControlType2.ChangeHandler }, rxktUOGxV: { defaultValue: 0, title: "Start", type: ControlType2.Number }, onrxktUOGxVChange: { changes: "rxktUOGxV", type: ControlType2.ChangeHandler }, hIUtCiZGx: { defaultValue: "User Engagement", displayTextArea: false, title: "Title", type: ControlType2.String }, onhIUtCiZGxChange: { changes: "hIUtCiZGx", type: ControlType2.ChangeHandler }, PNxd93WHM: { defaultValue: "+", placeholder: "Suffix", title: "Suffix", type: ControlType2.String }, onPNxd93WHMChange: { changes: "PNxd93WHM", type: ControlType2.ChangeHandler }, T5wwjaNga: { defaultValue: "", placeholder: "Prefix", title: "Prefix", type: ControlType2.String }, onT5wwjaNgaChange: { changes: "T5wwjaNga", type: ControlType2.ChangeHandler }, KLr6fBEML: AnimatedNumberCounterControls?.["decimals"] && { ...AnimatedNumberCounterControls["decimals"], defaultValue: 0, description: void 0, hidden: void 0, optional: void 0, title: "Decimals" }, onKLr6fBEMLChange: { changes: "KLr6fBEML", type: ControlType2.ChangeHandler } });
addFonts(FramerjQRptkh2f, [{ explicitInter: true, fonts: [{ cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v5/gyBhhwUxId8gMGYQMKR3pzfaWI_RnOM4mJPby1QNtA.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...AnimatedNumberCounterFonts, ...getFontsFromSharedStyle(fonts2), ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerjQRptkh2f", "slots": [], "annotations": { "framerImmutableVariables": "true", "framerIntrinsicWidth": "108", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"lFJAGnsrB":{"layout":["auto","auto"]}}}', "framerAutoSizeImages": "true", "framerColorSyntax": "true", "framerContractVersion": "1", "framerIntrinsicHeight": "71", "framerVariables": '{"G2MMSMUsQ":"end","rxktUOGxV":"start","hIUtCiZGx":"title","PNxd93WHM":"suffix","T5wwjaNga":"prefix","KLr6fBEML":"decimals"}', "framerDisplayContentsDiv": "false", "framerComponentViewportWidth": "true" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  jQRptkh2f_default as default
};
