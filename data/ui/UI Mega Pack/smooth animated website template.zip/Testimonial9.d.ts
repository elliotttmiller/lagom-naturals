export interface Testimonial9Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Variant 1" → QVgjCtY5T
   *   "Variant 2" → NDZxfkFgf
   */
  variant?: 'Variant 1' | 'Variant 2' | 'QVgjCtY5T' | 'NDZxfkFgf';
  /**
   * Logo — pass as `HKqf6NAe_` not `logo`.
   */
  HKqf6NAe_?: string;
  /**
   * Text — pass as `Mp9OAi31z` not `text`.
   * @default "They connected strategy and design into one clear system. The process was focused, collaborative, and exceeded our expectations"
   */
  Mp9OAi31z?: string;
  onMp9OAi31zChange?: string;
  /**
   * Client Name — pass as `G2oVfAskX` not `clientName`.
   * @default "Adrian Cole"
   */
  G2oVfAskX?: string;
  onG2oVfAskXChange?: string;
  /**
   * Photo — pass as `f1iBvSGCp` not `photo`.
   */
  f1iBvSGCp?: string;
  /**
   * Client Role — pass as `Oo9bXm_Yh` not `clientRole`.
   * @default "Co-Founder & CEO, Morrow"
   */
  Oo9bXm_Yh?: string;
  onOo9bXm_YhChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
