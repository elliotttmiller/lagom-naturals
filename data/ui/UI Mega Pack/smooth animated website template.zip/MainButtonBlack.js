var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/AR29HV99lKSIjtcTKhvB/38Em4ykIhrlbmJGAJ1EB/n0KwwIbHT.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, getFonts, getFontsFromSharedStyle, Link, RichText, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/f8Q5x3tcvy2sgigvrEse/WjPolkbUODUXgM3l5QnQ/X5rbDZv9v.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 0 10 L 10 0" fill="transparent" height="10px" id="Gm6ErcvSs" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" stroke="var(--43q7um, rgb(0,0,0))" transform="translate(7 7)" width="10px"/><path d="M 0 0 L 10 0 L 10 10" fill="transparent" height="10px" id="TScaaNOIP" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" stroke="var(--43q7um, rgb(0,0,0))" transform="translate(7 7)" width="10px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(motion.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx("div", { ...rest, ref });
});
var getProps = ({ height, id, stroke, width, ...props }) => {
  return { ...props, UO5clYVeQ: stroke ?? props.UO5clYVeQ ?? "rgb(0, 0, 0)" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className: className2, layoutId, variant, UO5clYVeQ, ...restProps } = getProps(props);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-r0AVb", className2), layoutId, ref, style: { "--43q7um": UO5clYVeQ, ...style } });
});
var css = [`.framer-r0AVb { -webkit-mask: ${mask}; aspect-ratio: 1; background-color: var(--43q7um); mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-r0AVb");
Icon.displayName = "Arrow Up Right";
var X5rbDZv9v_default = Icon;
addPropertyControls(Icon, { UO5clYVeQ: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Stroke", type: ControlType.Color } });

// http-url:https://framerusercontent.com/modules/w2K1bjRWtBAYMOr6QaYw/GvRA2RgmmlY2gAYVps3t/jSyDEq05b.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["GF;Geist-regular", "GF;Geist-700", "GF;Geist-700italic", "GF;Geist-italic"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v5/gyBhhwUxId8gMGYQMKR3pzfaWI_RnOM4mJPby1QNtA.woff2", weight: "400" }, { cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v5/gyBhhwUxId8gMGYQMKR3pzfaWI_Re-Q4mJPby1QNtA.woff2", weight: "700" }, { cssFamilyName: "Geist", source: "google", style: "italic", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v5/gyBjhwUxId8gMEwZAluvzlxA9ojEVKA32Zna6VEdtKCL.woff2", weight: "700" }, { cssFamilyName: "Geist", source: "google", style: "italic", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v5/gyBjhwUxId8gMEwZAluvzlxA9ojEVKDQ3pna6VEdtKCL.woff2", weight: "400" }] }];
var css2 = ['.framer-kevhZ .framer-styles-preset-5blr9w:not(.rich-text-wrapper), .framer-kevhZ .framer-styles-preset-5blr9w.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold-italic: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-italic: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: -0.03em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: #000000; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className = "framer-kevhZ";

// http-url:https://framerusercontent.com/modules/AR29HV99lKSIjtcTKhvB/38Em4ykIhrlbmJGAJ1EB/n0KwwIbHT.js
var ArrowUpRightFonts = getFonts(X5rbDZv9v_default);
var cycleOrder = ["L4_MsCa4u", "cXC6SG8hJ"];
var serializationHash = "framer-RX8I8";
var variantClassNames = { cXC6SG8hJ: "framer-v-150upix", L4_MsCa4u: "framer-v-1qehb7q" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { delay: 0, duration: 0.5, ease: [0.44, 0, 0.56, 1], type: "tween" };
var transformTemplate1 = (_, t) => `translate(-50%, -50%) ${t}`;
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "main black - white": "cXC6SG8hJ", "main black": "L4_MsCa4u" };
var Variants = motion2.create(React2.Fragment);
var getProps2 = ({ height, id, link, title, width, ...props }) => {
  return { ...props, rSJAjuN49: title ?? props.rSJAjuN49 ?? "View projects", UQQyPzfcZ: link ?? props.UQQyPzfcZ, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "L4_MsCa4u" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className2, layoutId, variant, rSJAjuN49, UQQyPzfcZ, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "L4_MsCa4u", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onMouseEnterdqm6kb = activeVariantCallback(async (...args) => {
    setGestureState({ isHovered: true });
    setVariant("cXC6SG8hJ");
  });
  const onMouseLeave1hfap1m = activeVariantCallback(async (...args) => {
    setGestureState({ isHovered: false });
    setVariant("L4_MsCa4u");
  });
  const sharedStyleClassNames = [className];
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsx2(Link, { href: UQQyPzfcZ, motionChild: true, nodeId: "L4_MsCa4u", openInNewTab: false, scopeId: "n0KwwIbHT", smoothScroll: true, children: /* @__PURE__ */ _jsxs(motion2.a, { ...restProps, ...gestureHandlers, className: `${cx2(scopingClassNames, "framer-1qehb7q", className2, classNames)} framer-75uxfu`, "data-framer-name": "main black", "data-highlight": true, layoutDependency, layoutId: "Mainbuttonblack__L4_MsCa4u", onMouseEnter: onMouseEnterdqm6kb, ref: refBinding, style: { "--border-bottom-width": "0px", "--border-color": "rgba(0, 0, 0, 0)", "--border-left-width": "0px", "--border-right-width": "0px", "--border-style": "solid", "--border-top-width": "0px", backgroundColor: "rgb(0, 0, 0)", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100, boxShadow: "0.12043746035487857px 0.6021873017743928px 2.0879840657580826px -1.0833333333333333px rgba(0, 2, 28, 0.05), 0.4577066606486914px 2.288533303243457px 7.935107660106832px -2.1666666666666665px rgba(0, 2, 28, 0.05), 2px 10px 34.67333269243093px -3.25px rgba(0, 2, 28, 0.03)", ...style }, variants: { cXC6SG8hJ: { "--border-bottom-width": "1px", "--border-color": "rgba(0, 0, 0, 0.1)", "--border-left-width": "1px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "1px", backgroundColor: "rgb(255, 255, 255)" } }, ...addPropertyOverrides({ cXC6SG8hJ: { "data-border": true, "data-framer-name": "main black - white", onMouseLeave: onMouseLeave1hfap1m } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx2(motion2.div, { className: "framer-1cfpeup", "data-framer-name": "Button Text", layoutDependency, layoutId: "Mainbuttonblack__LS92SBLr6", children: /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { className: "framer-styles-preset-5blr9w", "data-styles-preset": "jSyDEq05b", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(255, 255, 255))" }, children: "View projects" }) }), className: "framer-7s8xtl", fonts: ["Inter"], layoutDependency, layoutId: "Mainbuttonblack__EcWKhfTrl", style: { "--extracted-r6o4lv": "rgb(255, 255, 255)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: rSJAjuN49, variants: { cXC6SG8hJ: { "--extracted-r6o4lv": "rgb(0, 0, 0)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ cXC6SG8hJ: { children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { className: "framer-styles-preset-5blr9w", "data-styles-preset": "jSyDEq05b", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(0, 0, 0))" }, children: "View projects" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-85jyn", "data-framer-name": "Circle", layoutDependency, layoutId: "Mainbuttonblack__nis4nihpF", style: { backgroundColor: "rgb(255, 255, 255)", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100 }, variants: { cXC6SG8hJ: { backgroundColor: "rgb(0, 0, 0)" } }, children: /* @__PURE__ */ _jsx2(X5rbDZv9v_default, { animated: true, className: "framer-13g93w7", layoutDependency, layoutId: "Mainbuttonblack__yAs1oF7ko", style: { "--43q7um": "rgb(0, 0, 0)" }, transformTemplate: transformTemplate1, variants: { cXC6SG8hJ: { "--43q7um": "rgb(255, 255, 255)" } } }) }), /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-1nkjuqs", "data-framer-name": "The Expander", layoutDependency, layoutId: "Mainbuttonblack__GzRs4s2OC", style: { backgroundColor: "rgb(255, 255, 255)", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100, scale: 1 }, variants: { cXC6SG8hJ: { scale: 12 } } })] }) }) }) }) });
});
var css3 = [".framer-RX8I8.framer-75uxfu, .framer-RX8I8 .framer-75uxfu { display: block; }", ".framer-RX8I8.framer-1qehb7q { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: center; overflow: hidden; padding: 10px 10px 10px 20px; position: relative; text-decoration: none; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-RX8I8 .framer-1cfpeup { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 80px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: min-content; }", ".framer-RX8I8 .framer-7s8xtl { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-RX8I8 .framer-85jyn { flex: none; height: 32px; overflow: var(--overflow-clip-fallback, clip); position: relative; width: 32px; will-change: var(--framer-will-change-override, transform); z-index: 2; }", ".framer-RX8I8 .framer-13g93w7 { aspect-ratio: 1 / 1; flex: none; height: auto; left: 50%; position: absolute; top: 50%; width: 26px; }", ".framer-RX8I8 .framer-1nkjuqs { flex: none; height: 32px; overflow: hidden; position: absolute; right: 10px; top: calc(50.00000000000002% - 32px / 2); width: 32px; will-change: var(--framer-will-change-override, transform); z-index: 1; }", ".framer-RX8I8.framer-v-150upix .framer-1cfpeup { z-index: 3; }", ...css2, '.framer-RX8I8[data-border="true"]::after, .framer-RX8I8 [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var Framern0KwwIbHT = withCSS2(Component2, css3, "framer-RX8I8");
var n0KwwIbHT_default = Framern0KwwIbHT;
Framern0KwwIbHT.displayName = "Main button black";
Framern0KwwIbHT.defaultProps = { height: 52, width: 182 };
addPropertyControls2(Framern0KwwIbHT, { variant: { options: ["L4_MsCa4u", "cXC6SG8hJ"], optionTitles: ["main black", "main black - white"], title: "Variant", type: ControlType2.Enum }, rSJAjuN49: { defaultValue: "View projects", displayTextArea: false, title: "Title", type: ControlType2.String }, onrSJAjuN49Change: { changes: "rSJAjuN49", type: ControlType2.ChangeHandler }, UQQyPzfcZ: { title: "Link", type: ControlType2.Link } });
addFonts(Framern0KwwIbHT, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...ArrowUpRightFonts, ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "Framern0KwwIbHT", "slots": [], "annotations": { "framerAutoSizeImages": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"cXC6SG8hJ":{"layout":["auto","auto"]}}}', "framerImmutableVariables": "true", "framerComponentViewportWidth": "true", "framerVariables": '{"rSJAjuN49":"title","UQQyPzfcZ":"link"}', "framerDisplayContentsDiv": "false", "framerContractVersion": "1", "framerColorSyntax": "true", "framerIntrinsicWidth": "182", "framerIntrinsicHeight": "52" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  n0KwwIbHT_default as default
};
