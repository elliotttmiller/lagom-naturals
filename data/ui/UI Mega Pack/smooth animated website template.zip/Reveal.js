var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/9rViPfJ83GR7mTvGlZ8x/8p1mHsT0wI8o3J1xGv06/dWtBjI4KG.js
import { jsx as _jsx2, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ComponentViewportProvider, ControlType as ControlType2, cx, getFonts, RichText, SmartComponentScopedContainer, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useOnVariantChange, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/Jevk4PfCWtseIKq1bucG/JSgTYirCTUVfG3h0E8B4/ProTextType.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { addPropertyControls, ControlType } from "./_framer-runtime.js";
import * as React from "react";
import { motion } from "framer-motion";
function ProTextTypeEffect(props) {
  const { text, as: asTag, typingSpeed, initialDelay, pauseDuration, deletingSpeed, loop, className, showCursor, hideCursorWhileTyping, cursorMode, cursorCharacterPreset, customCursorCharacter, cursorClassName, cursorBlinkDuration, textColors, cursorColorMode, cursorCustomColor, variableSpeed, startOnVisible, reverseMode, sizingMode, minFont, maxFont, fluidVw, style, ...rest } = props;
  const textArray = React.useMemo(() => Array.isArray(text) ? text : [text ?? ""], [text]);
  const cursorChar = cursorMode === "custom" ? customCursorCharacter?.length ? customCursorCharacter : "|" : cursorCharacterPreset;
  const [displayedText, setDisplayedText] = React.useState("");
  const [currentCharIndex, setCurrentCharIndex] = React.useState(0);
  const [isDeleting, setIsDeleting] = React.useState(false);
  const [currentTextIndex, setCurrentTextIndex] = React.useState(0);
  const [isVisible, setIsVisible] = React.useState(!startOnVisible);
  const firstColor = textColors && textColors[0] || "#000000";
  const resolvedCursorColor = cursorColorMode === "custom" && cursorCustomColor ? cursorCustomColor : firstColor;
  const containerRef = React.useRef(null);
  const As = asTag || "div";
  const getRandomSpeed = React.useCallback(() => {
    if (!variableSpeed)
      return typingSpeed;
    const { min, max } = variableSpeed;
    const lo = Math.max(0, Number(min) || 0);
    const hi = Math.max(lo, Number(max) || lo);
    return Math.random() * (hi - lo) + lo;
  }, [variableSpeed, typingSpeed]);
  const getCurrentTextColor = React.useCallback(() => {
    if (!textColors || textColors.length === 0)
      return "#000000";
    return textColors[currentTextIndex % textColors.length];
  }, [textColors, currentTextIndex]);
  React.useEffect(() => {
    if (!startOnVisible || !containerRef.current)
      return;
    const el = containerRef.current;
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting)
          setIsVisible(true);
      });
    }, { threshold: 0.1 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [startOnVisible]);
  React.useEffect(() => {
    if (!isVisible)
      return;
    let timeout;
    const currentText = textArray[currentTextIndex] ?? "";
    const processed = reverseMode ? currentText.split("").reverse().join("") : currentText;
    const run = () => {
      if (isDeleting) {
        if (displayedText.length === 0) {
          setIsDeleting(false);
          if (currentTextIndex === textArray.length - 1 && !loop)
            return;
          setCurrentTextIndex((i) => (i + 1) % textArray.length);
          setCurrentCharIndex(0);
          timeout = setTimeout(() => {
          }, pauseDuration);
        } else {
          timeout = setTimeout(() => {
            setDisplayedText((prev) => prev.slice(0, -1));
          }, deletingSpeed);
        }
      } else {
        if (currentCharIndex < processed.length) {
          timeout = setTimeout(() => {
            setDisplayedText((prev) => prev + processed[currentCharIndex]);
            setCurrentCharIndex((i) => i + 1);
          }, variableSpeed ? getRandomSpeed() : typingSpeed);
        } else {
          if (textArray.length > 1 && (loop || currentTextIndex < textArray.length - 1)) {
            timeout = setTimeout(() => setIsDeleting(true), pauseDuration);
          } else {
          }
        }
      }
    };
    if (currentCharIndex === 0 && !isDeleting && displayedText === "") {
      timeout = setTimeout(run, initialDelay);
    } else {
      run();
    }
    return () => timeout && clearTimeout(timeout);
  }, [isVisible, textArray, currentTextIndex, loop, currentCharIndex, displayedText, isDeleting, typingSpeed, deletingSpeed, pauseDuration, initialDelay, reverseMode, variableSpeed, getRandomSpeed]);
  const fluidStyle = sizingMode === "fluid" ? { fontSize: `clamp(${minFont}px, ${fluidVw}vw, ${maxFont}px)` } : {};
  const { clipOverflow = false } = props;
  const baseStyle = { display: "inline-block", width: "auto", height: "auto", whiteSpace: "nowrap", overflow: clipOverflow ? "hidden" : "visible", textAlign: props.textAlign, WebkitTextSizeAdjust: "none", textSizeAdjust: "none", ...style };
  const shouldHideCursor = hideCursorWhileTyping && (currentCharIndex < (textArray[currentTextIndex] ?? "").length || isDeleting);
  return /* @__PURE__ */ _jsxs(As, { ref: containerRef, className: `text-type ${className || ""}`, style: baseStyle, ...rest, children: [/* @__PURE__ */ _jsx("span", { className: "text-type__content", style: { display: "inline", color: getCurrentTextColor(), ...props.font, ...fluidStyle }, children: displayedText }), showCursor && !shouldHideCursor && /* @__PURE__ */ _jsx(motion.span, { className: `text-type__cursor ${cursorClassName || ""}`, style: { marginLeft: "0.25rem", display: "inline-block", color: resolvedCursorColor, ...props.font, ...fluidStyle }, animate: { opacity: [1, 0] }, transition: { duration: cursorBlinkDuration, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }, children: cursorChar })] });
}
ProTextTypeEffect.displayName = "Pro Text Type Effect";
addPropertyControls(ProTextTypeEffect, { text: { type: ControlType.Array, title: "Text", defaultValue: ["Hello, Framer folks!", "This is the ultimate typing text component", "Checkout what all you can do from the panel on the right \u2192"], control: { type: ControlType.String, displayTextArea: true, defaultValue: "" } }, font: { type: "font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: 16, lineHeight: 1.2 } }, sizingMode: { type: ControlType.Enum, title: "Sizing", options: ["fixed", "fluid"], optionTitles: ["Fixed", "Fluid (clamp)"], defaultValue: "fixed", description: "Choose how the text scales" }, minFont: { type: ControlType.Number, title: "Min px", defaultValue: 18, min: 8, max: 200, hidden: (p) => p.sizingMode !== "fluid", description: "Smallest allowed font size" }, maxFont: { type: ControlType.Number, title: "Max px", defaultValue: 64, min: 8, max: 200, hidden: (p) => p.sizingMode !== "fluid", description: "Largest allowed font size" }, fluidVw: { type: ControlType.Number, title: "Scale (vw)", defaultValue: 6, min: 0.1, max: 20, step: 0.1, hidden: (p) => p.sizingMode !== "fluid", description: "How quickly the font grows as the screen width increases" }, textColors: { type: ControlType.Array, title: "Text Colors", control: { type: ControlType.Color, defaultValue: "#000000" }, defaultValue: ["#000000"], description: "Cycles through colors per sentence" }, textAlign: { type: ControlType.Enum, title: "Text Align", options: ["left", "center", "right", "justify"], optionTitles: ["Left", "Center", "Right", "Justify"], defaultValue: "left" }, as: { type: ControlType.Enum, title: "Tag", options: ["div", "p", "span", "h1", "h2", "h3", "h4", "h5", "h6"], optionTitles: ["div", "p", "span", "H1", "H2", "H3", "H4", "H5", "H6"], defaultValue: "p" }, typingSpeed: { type: ControlType.Number, title: "Type (ms)", min: 1, max: 500, step: 1, defaultValue: 50, description: "Time between charachters" }, deletingSpeed: { type: ControlType.Number, title: "Delete (ms)", min: 1, max: 500, step: 1, defaultValue: 30, description: "Time between deletions" }, initialDelay: { type: ControlType.Number, title: "Delay (ms)", min: 0, max: 5e3, step: 10, defaultValue: 0, description: "Waiting time before starting" }, pauseDuration: { type: ControlType.Number, title: "Pause (ms)", min: 0, max: 1e4, step: 50, defaultValue: 2e3, description: "Waiting time before deleting/next" }, loop: { type: ControlType.Boolean, title: "Loop", defaultValue: true }, reverseMode: { type: ControlType.Boolean, title: "Reverse text", defaultValue: false }, startOnVisible: { type: ControlType.Boolean, title: "Start on visible", defaultValue: false, description: "Begin typing only when in view" }, showCursor: { type: ControlType.Boolean, title: "Show cursor", defaultValue: true }, cursorMode: { type: ControlType.Enum, title: "Cursor", options: ["preset", "custom"], optionTitles: ["Preset", "Custom"], defaultValue: "preset", hidden: (p) => !p.showCursor }, cursorCharacterPreset: { type: ControlType.Enum, title: "Preset", options: ["|", "_", "\u2016", "\u275A", "\u258B", "\u258C", "\u2588"], optionTitles: ["Pipe |", "Underscore _", "Double Bar \u2016", "Block \u275A", "Left Half \u258B", "Right Half \u258C", "Full Block \u2588"], defaultValue: "|", hidden: (p) => !p.showCursor || p.cursorMode !== "preset" }, customCursorCharacter: { type: ControlType.String, title: "Custom char", placeholder: "Any character(s)", defaultValue: "|", hidden: (p) => !p.showCursor || p.cursorMode !== "custom" }, cursorColorMode: { type: ControlType.Enum, title: "Cursor color", options: ["matchFirst", "custom"], optionTitles: ["Match first color", "Custom"], defaultValue: "matchFirst", hidden: (p) => !p.showCursor }, cursorCustomColor: { type: ControlType.Color, title: "Custom color", optional: true, hidden: (p) => !p.showCursor || p.cursorColorMode !== "custom" }, cursorBlinkDuration: { type: ControlType.Number, title: "Blink (s)", min: 0.05, max: 2, step: 0.05, defaultValue: 0.5, hidden: (p) => !p.showCursor }, hideCursorWhileTyping: { type: ControlType.Boolean, title: "Hide while typing", defaultValue: false, hidden: (p) => !p.showCursor }, variableSpeed: { type: ControlType.Object, title: "Variable speed", optional: true, controls: { min: { type: ControlType.Number, title: "Min (ms)", min: 1, max: 500, step: 1, defaultValue: 30 }, max: { type: ControlType.Number, title: "Max (ms)", min: 1, max: 500, step: 1, defaultValue: 80 } }, description: "Random delay between characters\n\nComponent crafted by [Vaibhav](https://contra.com/vaibhav_khulbe)" } });

// http-url:https://framerusercontent.com/modules/9rViPfJ83GR7mTvGlZ8x/8p1mHsT0wI8o3J1xGv06/dWtBjI4KG.js
var ProTextTypeEffectFonts = getFonts(ProTextTypeEffect);
var cycleOrder = ["sv0mwBBnl", "PGrZGIuyr", "DuiC943qG", "rwYGg4xGr"];
var serializationHash = "framer-sVTen";
var variantClassNames = { DuiC943qG: "framer-v-18oda6o", PGrZGIuyr: "framer-v-mj68l3", rwYGg4xGr: "framer-v-sixg8f", sv0mwBBnl: "framer-v-8jxe4b" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { delay: 2, duration: 1.5, ease: [0.96, -0.02, 0.38, 1.01], type: "tween" };
var animation = { opacity: 1e-3, rotate: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 10 };
var transition2 = { bounce: 0, delay: 0.075, duration: 0.4, type: "spring" };
var textEffect = { effect: animation, tokenization: "word", transition: transition2, trigger: "onMount", type: "appear" };
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "desktop finish": "PGrZGIuyr", "desktop start": "sv0mwBBnl", "mobile finish": "rwYGg4xGr", "mobile start": "DuiC943qG" };
var Variants = motion2.create(React2.Fragment);
var getProps = ({ height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "sv0mwBBnl" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "sv0mwBBnl", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onAppear3p02mf = activeVariantCallback(async (...args) => {
    await delay(() => setVariant("PGrZGIuyr"), 1300);
  });
  const onAppearafao2v = activeVariantCallback(async (...args) => {
    await delay(() => setVariant("rwYGg4xGr"), 1300);
  });
  useOnVariantChange(baseVariant, { default: onAppear3p02mf, DuiC943qG: onAppearafao2v, PGrZGIuyr: void 0, rwYGg4xGr: void 0 });
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "DuiC943qG")
      return false;
    return true;
  };
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs2(motion2.section, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-8jxe4b", className, classNames), "data-framer-name": "desktop start", "data-highlight": true, layoutDependency, layoutId: "RevealPreloader__sv0mwBBnl", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ DuiC943qG: { "data-framer-name": "mobile start" }, PGrZGIuyr: { "data-framer-name": "desktop finish", "data-highlight": void 0 }, rwYGg4xGr: { "data-framer-name": "mobile finish", "data-highlight": void 0 } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs2(motion2.div, { className: "framer-e4bfr5", "data-framer-name": "Background", layoutDependency, layoutId: "RevealPreloader__RjW1kBbV2", style: { filter: "blur(0px)", WebkitFilter: "blur(0px)" }, variants: { PGrZGIuyr: { filter: "blur(9px)", WebkitFilter: "blur(9px)" }, rwYGg4xGr: { filter: "blur(9px)", WebkitFilter: "blur(9px)" } }, children: [/* @__PURE__ */ _jsx2(motion2.div, { className: "framer-fur7y2", "data-framer-name": "BG", layoutDependency, layoutId: "RevealPreloader__BA1TGYAs7", style: { backgroundColor: "var(--token-1ac2ba4c-22b7-47aa-9e58-8ba58b451a8f, rgb(255, 255, 255))", borderBottomLeftRadius: 0, borderBottomRightRadius: 0, borderTopLeftRadius: 0, borderTopRightRadius: 0, scale: 1 }, variants: { DuiC943qG: { borderBottomLeftRadius: 0, borderBottomRightRadius: 0, borderTopLeftRadius: 0, borderTopRightRadius: 0, scale: 1 }, PGrZGIuyr: { borderBottomLeftRadius: "100%", borderBottomRightRadius: "100%", borderTopLeftRadius: "100%", borderTopRightRadius: "100%", scale: 1.2 }, rwYGg4xGr: { borderBottomLeftRadius: "50%", borderBottomRightRadius: "50%", borderTopLeftRadius: "50%", borderTopRightRadius: "50%", scale: 1.2 } } }), /* @__PURE__ */ _jsxs2(motion2.div, { className: "framer-13gd2m3", "data-framer-name": "Logo Text", layoutDependency, layoutId: "RevealPreloader__vUC3crHzr", style: { scale: 1 }, variants: { DuiC943qG: { scale: 1 }, PGrZGIuyr: { scale: 2 }, rwYGg4xGr: { scale: 2 } }, children: [/* @__PURE__ */ _jsx2(motion2.div, { className: "framer-y4f0g1", layoutDependency, layoutId: "RevealPreloader__B9_2UdZ6l", children: /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { dir: "auto", style: { "--font-selector": "R0Y7SW5zdHJ1bWVudCBTZXJpZi1yZWd1bGFy", "--framer-font-family": '"Instrument Serif", "Instrument Serif Placeholder", serif', "--framer-font-size": "50px", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-9498c07e-7b77-44b6-8e71-03fa38beafc1, rgb(0, 0, 0)))" }, children: "Shaping your" }) }), className: "framer-1dzpc81", effect: textEffect, fonts: ["GF;Instrument Serif-regular"], layoutDependency, layoutId: "RevealPreloader__IjPLTt0NP", style: { "--extracted-r6o4lv": "var(--token-9498c07e-7b77-44b6-8e71-03fa38beafc1, rgb(0, 0, 0))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ DuiC943qG: { children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { dir: "auto", style: { "--font-selector": "R0Y7SW5zdHJ1bWVudCBTZXJpZi1yZWd1bGFy", "--framer-font-family": '"Instrument Serif", "Instrument Serif Placeholder", serif', "--framer-font-size": "42px", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-9498c07e-7b77-44b6-8e71-03fa38beafc1, rgb(0, 0, 0)))" }, children: "Shaping your" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-p4dckq", layoutDependency, layoutId: "RevealPreloader__XuY1SAP7P", children: /* @__PURE__ */ _jsx2(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx2(SmartComponentScopedContainer, { className: "framer-10xj1nx-container", isAuthoredByUser: true, layoutDependency, layoutId: "RevealPreloader__uvj4LIE_v-container", nodeId: "uvj4LIE_v", rendersWithMotion: true, scopeId: "dWtBjI4KG", children: /* @__PURE__ */ _jsx2(ProTextTypeEffect, { as: "p", cursorBlinkDuration: 0.4, cursorCharacterPreset: "|", cursorColorMode: "custom", cursorCustomColor: "var(--token-9498c07e-7b77-44b6-8e71-03fa38beafc1, rgb(0, 0, 0))", cursorMode: "preset", customCursorCharacter: "|", deletingSpeed: 20, fluidVw: 6, font: { fontFamily: '"Instrument Serif", "Instrument Serif Placeholder", serif', fontSize: "50px", fontStyle: "normal", fontWeight: 400, letterSpacing: "0em", lineHeight: "1.2em" }, height: "100%", hideCursorWhileTyping: false, id: "uvj4LIE_v", initialDelay: 0, layoutId: "RevealPreloader__uvj4LIE_v", loop: false, maxFont: 64, minFont: 18, pauseDuration: 600, reverseMode: false, showCursor: true, sizingMode: "fixed", startOnVisible: false, style: { width: "100%" }, text: ["idea", "vision", "brand", "website"], textAlign: "left", textColors: ["var(--token-62dbc745-9e36-4b0c-ae04-0673cbc97412, rgb(152, 196, 39))"], typingSpeed: 40, width: "100%", ...addPropertyOverrides({ DuiC943qG: { font: { fontFamily: '"Instrument Serif", "Instrument Serif Placeholder", serif', fontSize: "42px", fontStyle: "normal", fontWeight: 400, letterSpacing: "0em", lineHeight: "1.2em" }, style: { height: "100%", width: "100%" } } }, baseVariant, gestureVariant) }) }) }) })] })] }), /* @__PURE__ */ _jsxs2(motion2.div, { className: "framer-gq5urx", layoutDependency, layoutId: "RevealPreloader__d7tsqBo7h", children: [isDisplayed() && /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-kw06c9", "data-border": true, layoutDependency, layoutId: "RevealPreloader__mMPb5qhmn", style: { "--border-bottom-width": "0px", "--border-color": "var(--token-f06d2cac-ae1d-4e60-9032-fec41baa9f8f, rgba(0, 0, 0, 0.05))", "--border-left-width": "1px", "--border-right-width": "0px", "--border-style": "solid", "--border-top-width": "0px" }, variants: { PGrZGIuyr: { "--border-color": "rgba(0, 0, 0, 0)" }, rwYGg4xGr: { "--border-color": "rgba(0, 0, 0, 0)" } } }), /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-154wex5", "data-border": true, layoutDependency, layoutId: "RevealPreloader__V3lgxU07U", style: { "--border-bottom-width": "0px", "--border-color": "var(--token-f06d2cac-ae1d-4e60-9032-fec41baa9f8f, rgba(0, 0, 0, 0.05))", "--border-left-width": "0px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "0px" }, variants: { DuiC943qG: { "--border-left-width": "1px" }, PGrZGIuyr: { "--border-color": "rgba(0, 0, 0, 0)" }, rwYGg4xGr: { "--border-color": "rgba(0, 0, 0, 0)" } } }), /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-1jz66wp", "data-border": true, layoutDependency, layoutId: "RevealPreloader__IcsAcSy35", style: { "--border-bottom-width": "0px", "--border-color": "var(--token-f06d2cac-ae1d-4e60-9032-fec41baa9f8f, rgba(0, 0, 0, 0.05))", "--border-left-width": "0px", "--border-right-width": "0px", "--border-style": "solid", "--border-top-width": "0px" }, variants: { PGrZGIuyr: { "--border-color": "rgba(0, 0, 0, 0)" }, rwYGg4xGr: { "--border-color": "rgba(0, 0, 0, 0)" } } }), /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-3nlt8m", "data-border": true, layoutDependency, layoutId: "RevealPreloader__ak5tWZCdp", style: { "--border-bottom-width": "0px", "--border-color": "var(--token-f06d2cac-ae1d-4e60-9032-fec41baa9f8f, rgba(0, 0, 0, 0.05))", "--border-left-width": "1px", "--border-right-width": "0px", "--border-style": "solid", "--border-top-width": "0px" }, variants: { PGrZGIuyr: { "--border-color": "rgba(0, 0, 0, 0)" }, rwYGg4xGr: { "--border-color": "rgba(0, 0, 0, 0)" } } }), isDisplayed() && /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-9sou3c", "data-border": true, layoutDependency, layoutId: "RevealPreloader__c7J2FmTse", style: { "--border-bottom-width": "0px", "--border-color": "var(--token-f06d2cac-ae1d-4e60-9032-fec41baa9f8f, rgba(0, 0, 0, 0.05))", "--border-left-width": "1px", "--border-right-width": "0px", "--border-style": "solid", "--border-top-width": "0px" }, variants: { PGrZGIuyr: { "--border-color": "rgba(0, 0, 0, 0)" }, rwYGg4xGr: { "--border-color": "rgba(0, 0, 0, 0)" } } }), /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-o6cncy", "data-border": true, layoutDependency, layoutId: "RevealPreloader__G7teY9wli", style: { "--border-bottom-width": "0px", "--border-color": "var(--token-f06d2cac-ae1d-4e60-9032-fec41baa9f8f, rgba(0, 0, 0, 0.05))", "--border-left-width": "0px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "0px" }, variants: { DuiC943qG: { "--border-left-width": "1px" }, PGrZGIuyr: { "--border-color": "rgba(0, 0, 0, 0)" }, rwYGg4xGr: { "--border-color": "rgba(0, 0, 0, 0)" } } })] })] }) }) }) });
});
var css = [".framer-sVTen.framer-292ilm, .framer-sVTen .framer-292ilm { display: block; }", ".framer-sVTen.framer-8jxe4b { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 12px; height: auto; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-sVTen .framer-e4bfr5 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: 100%; justify-content: center; left: calc(50.00000000000002% - 100% / 2); overflow: visible; padding: 0px; position: absolute; top: calc(50.00000000000002% - 100% / 2); width: 100%; }", ".framer-sVTen .framer-fur7y2 { bottom: 0px; flex: none; left: 0px; overflow: visible; position: absolute; right: 0px; top: 0px; }", ".framer-sVTen .framer-13gd2m3 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: center; overflow: visible; padding: 0px 0px 32px 12px; position: relative; width: 374px; z-index: 3; }", ".framer-sVTen .framer-y4f0g1 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: 82px; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 228px; }", ".framer-sVTen .framer-1dzpc81 { -webkit-user-select: none; flex: none; height: auto; position: relative; user-select: none; white-space: pre-wrap; width: 228px; word-break: break-word; word-wrap: break-word; }", ".framer-sVTen .framer-p4dckq { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: min-content; }", ".framer-sVTen .framer-10xj1nx-container { flex: none; height: auto; position: relative; width: 145px; }", ".framer-sVTen .framer-gq5urx { align-content: center; align-items: center; bottom: 0px; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; justify-content: center; left: 40px; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: absolute; right: 40px; top: 0px; z-index: 1; }", ".framer-sVTen .framer-kw06c9, .framer-sVTen .framer-9sou3c { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: 100%; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 10px 0px 10px 0px; position: relative; width: 20px; z-index: 10; }", ".framer-sVTen .framer-154wex5, .framer-sVTen .framer-3nlt8m, .framer-sVTen .framer-o6cncy { align-content: center; align-items: center; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: 100%; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 10px 0px 10px 0px; position: relative; width: 1px; z-index: 10; }", ".framer-sVTen .framer-1jz66wp { align-content: center; align-items: center; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 60px; height: 100%; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 100px 0px 100px 0px; position: relative; width: 1px; }", ".framer-sVTen.framer-v-mj68l3 .framer-e4bfr5, .framer-sVTen.framer-v-sixg8f .framer-e4bfr5 { top: -1400px; }", ".framer-sVTen.framer-v-mj68l3 .framer-gq5urx, .framer-sVTen.framer-v-sixg8f .framer-gq5urx { bottom: unset; height: 834px; top: -1400px; }", ".framer-sVTen.framer-v-18oda6o.framer-8jxe4b, .framer-sVTen.framer-v-sixg8f.framer-8jxe4b { width: 100%; }", ".framer-sVTen.framer-v-18oda6o .framer-y4f0g1, .framer-sVTen.framer-v-18oda6o .framer-1dzpc81 { width: 197px; }", ".framer-sVTen.framer-v-18oda6o .framer-10xj1nx-container { height: 74px; width: 123px; }", ".framer-sVTen.framer-v-18oda6o .framer-gq5urx { left: 10px; right: 10px; }", '.framer-sVTen[data-border="true"]::after, .framer-sVTen [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerdWtBjI4KG = withCSS(Component, css, "framer-sVTen");
var dWtBjI4KG_default = FramerdWtBjI4KG;
FramerdWtBjI4KG.displayName = "Reveal Preloader";
FramerdWtBjI4KG.defaultProps = { height: 834, width: 1440 };
addPropertyControls2(FramerdWtBjI4KG, { variant: { options: ["sv0mwBBnl", "PGrZGIuyr", "DuiC943qG", "rwYGg4xGr"], optionTitles: ["desktop start", "desktop finish", "mobile start", "mobile finish"], title: "Variant", type: ControlType2.Enum } });
addFonts(FramerdWtBjI4KG, [{ explicitInter: true, fonts: [{ cssFamilyName: "Instrument Serif", source: "google", style: "normal", uiFamilyName: "Instrument Serif", url: "https://fonts.gstatic.com/s/instrumentserif/v5/jizBRFtNs2ka5fXjeivQ4LroWlx-2zcZj1bIkNo.woff2", weight: "400" }] }, ...ProTextTypeEffectFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerdWtBjI4KG", "slots": [], "annotations": { "framerAutoSizeImages": "true", "framerDisplayContentsDiv": "false", "framerIntrinsicHeight": "834", "framerContractVersion": "1", "framerColorSyntax": "true", "framerIntrinsicWidth": "1440", "framerImmutableVariables": "true", "framerComponentViewportWidth": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","fixed"]},"PGrZGIuyr":{"layout":["fixed","fixed"]},"DuiC943qG":{"layout":["fixed","fixed"]},"rwYGg4xGr":{"layout":["fixed","fixed"]}}}' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  dWtBjI4KG_default as default
};
