export interface ClientlogosectionProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Logos" → QjuPpK8DZ
   *   "Mobile" → Q8s3jAhtP
   */
  variant?: 'Logos' | 'Mobile' | 'QjuPpK8DZ' | 'Q8s3jAhtP';
  /** Additional properties */
  [key: string]: unknown;
}
