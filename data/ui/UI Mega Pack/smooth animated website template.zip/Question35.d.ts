export interface Question35Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Variant 1" → hJdzL5rWi
   *   "Variant 2" → W5mydbL3o
   */
  variant?: 'Variant 1' | 'Variant 2' | 'hJdzL5rWi' | 'W5mydbL3o';
  /**
   * Questions — pass as `TXXSjhnNn` not `questions`.
   * @default "What kind of projects do you take on?"
   */
  TXXSjhnNn?: string;
  onTXXSjhnNnChange?: string;
  /**
   * Answer — pass as `mMOJuIJUy` not `answer`.
   * @default "We work across brand strategy, visual identity, websites, and digital experiences for ambitious teams and growing businesses"
   */
  mMOJuIJUy?: string;
  onmMOJuIJUyChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
