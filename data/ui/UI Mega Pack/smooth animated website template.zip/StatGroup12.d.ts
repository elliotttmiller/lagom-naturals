export interface Statgroup12Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Variant 1" → sQBy3JJsa
   *   "Variant 2" → lFJAGnsrB
   */
  variant?: 'Variant 1' | 'Variant 2' | 'sQBy3JJsa' | 'lFJAGnsrB';
  /**
   * End — pass as `G2MMSMUsQ` not `end`.
   * @default 50
   */
  G2MMSMUsQ?: number;
  onG2MMSMUsQChange?: string;
  /**
   * Start — pass as `rxktUOGxV` not `start`.
   * @default 0
   */
  rxktUOGxV?: number;
  onrxktUOGxVChange?: string;
  /**
   * Title — pass as `hIUtCiZGx` not `title`.
   * @default "User Engagement"
   */
  hIUtCiZGx?: string;
  onhIUtCiZGxChange?: string;
  /**
   * Suffix — pass as `PNxd93WHM` not `suffix`.
   * @default "+"
   */
  PNxd93WHM?: string;
  onPNxd93WHMChange?: string;
  /**
   * Prefix — pass as `T5wwjaNga` not `prefix`.
   * @default ""
   */
  T5wwjaNga?: string;
  onT5wwjaNgaChange?: string;
  onKLr6fBEMLChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
