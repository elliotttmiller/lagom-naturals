export interface Mainbuttonblack20Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "main black - white" → cXC6SG8hJ
   *   "main black" → L4_MsCa4u
   */
  variant?: 'main black - white' | 'main black' | 'L4_MsCa4u' | 'cXC6SG8hJ';
  /**
   * Title — pass as `rSJAjuN49` not `title`.
   * @default "View projects"
   */
  rSJAjuN49?: string;
  onrSJAjuN49Change?: string;
  /**
   * Link — pass as `UQQyPzfcZ` not `link`.
   */
  UQQyPzfcZ?: string;
  /** Additional properties */
  [key: string]: unknown;
}
