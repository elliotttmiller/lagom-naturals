var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/FkZd5HGV2AKnradbFrFT/0tKlhfGsXzTchyMSE4Ql/rBV10wjU7.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 19.472 0.953 C 19.545 0.692 19.472 0.412 19.28 0.22 C 19.088 0.028 18.808 -0.045 18.546 0.028 L 0.546 5.486 C 0.245 5.571 0.029 5.834 0.003 6.145 C -0.023 6.457 0.147 6.752 0.429 6.886 L 8.626 10.874 L 12.614 19.07 C 12.748 19.352 13.043 19.522 13.354 19.496 C 13.666 19.47 13.929 19.253 14.013 18.953 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="19.498812438350562px" id="VRZKpSmTT" transform="translate(1.499 3.001)" width="19.49974993835056px"/><path d="M 0 4.875 L 4.875 0" fill="transparent" height="4.875px" id="QRgHy819f" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(10.125 9)" width="4.875px"/><path d="M 19.472 0.953 C 19.545 0.692 19.472 0.412 19.28 0.22 C 19.088 0.028 18.808 -0.045 18.546 0.028 L 0.546 5.486 C 0.245 5.571 0.029 5.834 0.003 6.145 C -0.023 6.457 0.147 6.752 0.429 6.886 L 8.626 10.874 L 12.614 19.07 C 12.748 19.352 13.043 19.522 13.354 19.496 C 13.666 19.47 13.929 19.253 14.013 18.953 Z" fill="transparent" height="19.498812438350562px" id="e4MqjlSIZ" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(1.499 3.001)" width="19.49974993835056px"/></svg>';
var getProps = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps(props);
  const href = useSVGTemplate("777087443", svg);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-XkeER", className), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx("use", { href }) });
});
var css = [`.framer-XkeER { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-XkeER");
Icon.displayName = "Paper Plane Tilt";
var rBV10wjU7_default = Icon;
addPropertyControls(Icon, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType.Number } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "Icon", "slots": [], "annotations": { "framerSupportedLayoutWidth": "any-prefer-fixed", "framerIntrinsicHeight": "24", "framerIntrinsicWidth": "24", "framerContractVersion": "1", "framerVariables": '{"ezTt3ayMo":"color","lschgej4H":"width1","qxTvv_EBh":"alpha"}', "framerImmutableVariables": "true", "framerSupportedLayoutHeight": "any-prefer-fixed", "framerDisableUnlink": "true", "framerVector": '{"name":"Paper Plane Tilt","color":{"type":"variable","value":"21h8s6"},"set":{"localId":"vectorSet/NGVKdicsm","id":"NGVKdicsm","moduleId":"omX0gWFPqDwhaiWwf6ab"}}' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  rBV10wjU7_default as default
};
