# Main button black

Exported from Framer using Design to AI.

## Components

- `MainButtonBlack`
- `Question`
- `Question2`
- `Question3`
- `Question4`
- `Question5`
- `Question6`
- `Question7`
- `MainButtonBlack2`
- `Reveal`
- `SmoothscrollProd`
- `Video`
- `MainButtonBlack3`
- `StatGroup`
- `P7fybhny8`
- `StatGroup2`
- `Mnd7tj98o`
- `StatGroup3`
- `Iiwy0ex6n`
- `Project`
- `Card`
- `Card2`
- `Card3`
- `Card4`
- `MainButtonBlack4`
- `Yq18nsohz`
- `Tkteoy8al`
- `Viizshjxy`
- `Rbv10wju7`
- `Clientlogosection`
- `Testimonial`
- `Testimonial2`
- `Testimonial3`
- `Testimonial4`
- `Testimonial5`
- `MainButtonWhite`
- `Blog`
- `MainButtonBlack5`
- `Question8`
- `Question9`
- `Question10`
- `Question11`
- `Question12`
- `Question13`
- `Question14`
- `MainButtonBlack6`
- `Reveal2`
- `SmoothscrollProd2`
- `Video2`
- `MainButtonBlack7`
- `StatGroup4`
- `P7fybhny82`
- `StatGroup5`
- `Mnd7tj98o2`
- `StatGroup6`
- `Iiwy0ex6n2`
- `Project2`
- `Card5`
- `Card6`
- `Card7`
- `Card8`
- `MainButtonBlack8`
- `Yq18nsohz2`
- `Tkteoy8al2`
- `Viizshjxy2`
- `Rbv10wju72`
- `Clientlogosection2`
- `Testimonial6`
- `Testimonial7`
- `Testimonial8`
- `Testimonial9`
- `Testimonial10`
- `MainButtonWhite2`
- `Blog2`
- `MainButtonBlack9`
- `Question15`
- `Question16`
- `Question17`
- `Question18`
- `Question19`
- `Question20`
- `Question21`
- `MainButtonBlack10`
- `Reveal3`
- `SmoothscrollProd3`
- `Video3`
- `MainButtonBlack11`
- `StatGroup7`
- `P7fybhny83`
- `StatGroup8`
- `Mnd7tj98o3`
- `StatGroup9`
- `Iiwy0ex6n3`
- `Project3`
- `Card9`
- `Card10`
- `Card11`
- `Card12`
- `MainButtonBlack12`
- `Yq18nsohz3`
- `Tkteoy8al3`
- `Viizshjxy3`
- `Rbv10wju73`
- `Clientlogosection3`
- `Testimonial11`
- `Testimonial12`
- `Testimonial13`
- `Testimonial14`
- `Testimonial15`
- `MainButtonWhite3`
- `Blog3`
- `MainButtonBlack13`
- `Question22`
- `Question23`
- `Question24`
- `Question25`
- `Question26`
- `Question27`
- `Question28`
- `MainButtonBlack14`
- `Reveal4`
- `SmoothscrollProd4`
- `Video4`
- `MainButtonBlack15`
- `StatGroup10`
- `P7fybhny84`
- `StatGroup11`
- `Mnd7tj98o4`
- `StatGroup12`
- `Iiwy0ex6n4`
- `Project4`
- `Card13`
- `Card14`
- `Card15`
- `Card16`
- `MainButtonBlack16`
- `Yq18nsohz4`
- `Tkteoy8al4`
- `Viizshjxy4`
- `Rbv10wju74`
- `Clientlogosection4`
- `Testimonial16`
- `Testimonial17`
- `Testimonial18`
- `Testimonial19`
- `Testimonial20`
- `MainButtonWhite4`
- `Blog4`
- `MainButtonBlack17`
- `Question29`
- `Question30`
- `Question31`
- `Question32`
- `Question33`
- `Question34`
- `Question35`
- `MainButtonBlack18`
- `Reveal5`
- `SmoothscrollProd5`
- `Video5`
- `MainButtonBlack19`
- `StatGroup13`
- `P7fybhny85`
- `StatGroup14`
- `Mnd7tj98o5`
- `StatGroup15`
- `Iiwy0ex6n5`
- `Project5`
- `Card17`
- `Card18`
- `Card19`
- `Card20`
- `MainButtonBlack20`
- `Yq18nsohz5`
- `Tkteoy8al5`
- `Viizshjxy5`
- `Rbv10wju75`
- `Clientlogosection5`
- `Testimonial21`
- `Testimonial22`
- `Testimonial23`
- `Testimonial24`
- `Testimonial25`
- `MainButtonWhite5`
- `Blog5`
- `MainButtonBlack21`
- `Question36`
- `Question37`
- `Question38`
- `Question39`
- `Question40`
- `Question41`
- `Question42`
- `MainButtonBlack22`
- `Reveal6`
- `SmoothscrollProd6`
- `Video6`
- `MainButtonBlack23`
- `StatGroup16`
- `P7fybhny86`
- `StatGroup17`
- `Mnd7tj98o6`
- `StatGroup18`
- `Iiwy0ex6n6`
- `Project6`
- `Card21`
- `Card22`
- `Card23`
- `Card24`
- `MainButtonBlack24`
- `Yq18nsohz6`
- `Tkteoy8al6`
- `Viizshjxy6`
- `Rbv10wju76`
- `Clientlogosection6`
- `Testimonial26`
- `Testimonial27`
- `Testimonial28`
- `Testimonial29`
- `Testimonial30`
- `MainButtonWhite6`
- `Blog6`

## Installation

```bash
# Copy this folder to your project, then install dependencies:
npm install react react-dom framer-motion lenis@1.1.2 @motionone/dom@10.13.1
```

## Usage

```tsx
import { MainButtonBlack } from './Main button black';

function App() {
  return <MainButtonBlack />;
}
```

## Responsive Components

For components with responsive variants, use the responsive runtime:

```tsx
// Import the CSS for responsive breakpoints
import './Main button black/_responsive-runtime.css';

// Option 1: Use the useBreakpoint hook
import { useBreakpoint } from './Main button black/_responsive-runtime';

function App() {
  const breakpoint = useBreakpoint(); // 'base' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

  return <MainButtonBlack variant={breakpoint === 'base' ? 'mobile' : 'desktop'} />;
}

// Option 2: Use the WithBreakpoints HOC
import { WithBreakpoints } from './Main button black/_responsive-runtime';

function App() {
  return (
    <WithBreakpoints
      Component={MainButtonBlack}
      variants={{
        base: 'mobile',    // 0px+
        md: 'tablet',      // 768px+
        lg: 'desktop'      // 1024px+
      }}
    />
  );
}
```

### Breakpoints

| Name | Min Width | Typical Use |
|------|-----------|-------------|
| base | 0px | Mobile |
| sm | 390px | Large mobile |
| md | 768px | Tablet |
| lg | 1024px | Laptop |
| xl | 1280px | Desktop |
| 2xl | 1536px | Large desktop |

## Peer Dependencies

These components require the following packages in your project:

- `react` >= 18.0.0
- `react-dom` >= 18.0.0
- `framer-motion` >= 10.0.0

## Note

The Framer runtime is bundled as `_framer-runtime.js` - no external Framer dependency needed.
These exports are self-contained and work out of the box.

## Generated

Created with [Design to AI](https://designtoai.com)
