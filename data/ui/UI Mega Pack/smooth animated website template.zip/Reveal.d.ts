export interface RevealProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "desktop finish" → PGrZGIuyr
   *   "desktop start" → sv0mwBBnl
   *   "mobile finish" → rwYGg4xGr
   *   "mobile start" → DuiC943qG
   */
  variant?: 'desktop finish' | 'desktop start' | 'mobile finish' | 'mobile start' | 'sv0mwBBnl' | 'PGrZGIuyr' | 'DuiC943qG' | 'rwYGg4xGr';
  /** Additional properties */
  [key: string]: unknown;
}
