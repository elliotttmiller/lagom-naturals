var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/9020SqwA4X7DchIEa0Aq/YiwuzrFsQFGts6HbKrfJ/ZmbC6kcKD.js
import { jsx as _jsx3 } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls3, ComponentViewportProvider, ControlType as ControlType3, cx as cx2, forwardLoader, getFonts, SmartComponentScopedContainer, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup3, motion as motion3, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React2 from "react";
import { useRef as useRef3 } from "react";

// http-url:https://framerusercontent.com/modules/B2xAlJLcN0gOnt11mSPw/plhC5PVnCMllW5QXjFK5/Ticker.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Children, useLayoutEffect, useEffect, useState, useRef, useMemo, useCallback, cloneElement, startTransition, forwardRef, useImperativeHandle } from "react";
import { addPropertyControls, ControlType, RenderTarget } from "./_framer-runtime.js";
import { useReducedMotion, LayoutGroup, useInView, useMotionValue, useTransform, motion, frame } from "framer-motion";
import { resize } from "@motionone/dom";
var MAX_DUPLICATED_ITEMS = 100;
var directionTransformers = { left: (offset) => `translateX(-${offset}px)`, right: (offset) => `translateX(${offset}px)`, top: (offset) => `translateY(-${offset}px)`, bottom: (offset) => `translateY(${offset}px)` };
function Ticker(props) {
  let { slots = [], gap, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft, speed, hoverFactor, direction, alignment, sizingOptions, fadeOptions, style } = props;
  const { fadeContent, overflow, fadeWidth, fadeInset, fadeAlpha } = fadeOptions;
  const { widthType, heightType } = sizingOptions;
  const paddingValue = paddingPerSide ? `${paddingTop}px ${paddingRight}px ${paddingBottom}px ${paddingLeft}px` : `${padding}px`;
  const currentTarget = RenderTarget.current();
  const isCanvas = currentTarget === RenderTarget.canvas || currentTarget === RenderTarget.export;
  const writingDirection = useWritingDirection();
  const filteredSlots = slots.filter(Boolean);
  const numChildren = Children.count(filteredSlots);
  const hasChildren = numChildren > 0;
  const offset = useMotionValue(0);
  const resolvedDirection = getTickerResolvedDirection(direction === true ? "left" : direction, writingDirection);
  const isHorizontal = resolvedDirection === "left" || resolvedDirection === "right";
  const transformer = directionTransformers[resolvedDirection];
  const transform = useTransform(offset, transformer);
  const parentRef = useRef(null);
  const childrenRef = useMemo(() => {
    return [{ current: null }, { current: null }];
  }, []);
  const [size, setSize] = useState({ parent: null, children: null });
  let clonedChildren = null;
  let dupedChildren = [];
  let duplicateBy = 0;
  let opacity = 0;
  if (isCanvas) {
    duplicateBy = numChildren ? Math.floor(10 / numChildren) : 0;
    opacity = 1;
  }
  if (!isCanvas && hasChildren && size.parent) {
    duplicateBy = Math.round(size.parent / size.children * 2) + 1;
    duplicateBy = Math.min(duplicateBy, MAX_DUPLICATED_ITEMS);
    opacity = 1;
  }
  const measure = useCallback(() => {
    if (hasChildren && parentRef.current) {
      const parentLength = isHorizontal ? parentRef.current.offsetWidth : parentRef.current.offsetHeight;
      const start = childrenRef[0].current ? isHorizontal ? childrenRef[0].current.offsetLeft : childrenRef[0].current.offsetTop : 0;
      const end = childrenRef[1].current ? isHorizontal ? childrenRef[1].current.offsetLeft + childrenRef[1].current.offsetWidth : childrenRef[1].current.offsetTop + childrenRef[1].current.offsetHeight : 0;
      const childrenLength = end - start + gap;
      startTransition(() => {
        setSize({ parent: parentLength, children: childrenLength });
      });
    }
  }, []);
  const childrenStyles = isCanvas ? { contentVisibility: "auto" } : {};
  if (hasChildren) {
    if (!isCanvas) {
      let initialResize = useRef(true);
      useLayoutEffect(() => {
        frame.read(measure, false, true);
        return resize(parentRef.current, ({ contentSize }) => {
          if (!initialResize.current && (contentSize.width || contentSize.height)) {
            frame.read(measure, false, true);
          }
          initialResize.current = false;
        });
      }, []);
    }
    clonedChildren = Children.map(filteredSlots, (child, index) => {
      let ref;
      if (index === 0) {
        ref = childrenRef[writingDirection === "rtl" && isHorizontal ? 1 : 0];
      }
      if (index === filteredSlots.length - 1) {
        ref = childrenRef[writingDirection === "rtl" && isHorizontal ? 0 : 1];
      }
      const size2 = { width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%" };
      return /* @__PURE__ */ _jsx(LayoutGroup, { inherit: "id", children: /* @__PURE__ */ _jsx(Wrapper, { ref, style: size2, children: /* @__PURE__ */ cloneElement(child, { style: { ...child.props?.style, ...size2, flexShrink: 0, ...childrenStyles }, layoutId: child.props.layoutId ? child.props.layoutId + "-original-" + index : void 0 }, child.props?.children) }) });
    });
  }
  const isInView = isCanvas ? true : useInView(parentRef);
  if (!isCanvas) {
    for (let i = 0; i < duplicateBy; i++) {
      dupedChildren = dupedChildren.concat(Children.map(filteredSlots, (child, childIndex) => {
        const size2 = { width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%", willChange: !isInView ? void 0 : "transform" };
        return /* @__PURE__ */ _jsx(LayoutGroup, { inherit: "id", children: /* @__PURE__ */ _jsx(Wrapper, { style: size2, children: /* @__PURE__ */ cloneElement(child, { key: i + " " + childIndex, style: { ...child.props?.style, width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%", flexShrink: 0, ...childrenStyles }, layoutId: child.props.layoutId ? child.props.layoutId + "-dupe-" + i : void 0 }, child.props?.children) }, i + "li" + childIndex) }, i + "lg" + childIndex);
      }));
    }
  }
  const animateToValue = size.children + size.children * Math.round(size.parent / size.children);
  const initialTime = useRef(null);
  const prevTime = useRef(null);
  const xOrY = useRef(0);
  const isHover = useRef(false);
  const isReducedMotion = useReducedMotion();
  const listRef = useRef(null);
  const animationRef = useRef(null);
  if (!isCanvas) {
    useEffect(() => {
      if (isReducedMotion || !animateToValue || !speed) {
        return;
      }
      animationRef.current = listRef.current.animate({ transform: [transformer(0), transformer(animateToValue)] }, { duration: Math.abs(animateToValue) / speed * 1e3, iterations: Infinity, iterationStart: writingDirection === "rtl" ? 1 : 0, easing: "linear" });
      return () => animationRef.current.cancel();
    }, [hoverFactor, animateToValue, speed, writingDirection]);
    const playOrPause = useCallback(() => {
      if (!animationRef.current)
        return;
      const hidden = document.hidden;
      if (isInView && !hidden && animationRef.current.playState === "paused") {
        animationRef.current.play();
      } else if ((!isInView || hidden) && animationRef.current.playState === "running") {
        animationRef.current.pause();
      }
    }, [isInView]);
    useEffect(() => {
      playOrPause();
    }, [isInView, hoverFactor, animateToValue, speed]);
    useEffect(() => {
      document.addEventListener("visibilitychange", playOrPause);
      return () => {
        document.removeEventListener("visibilitychange", playOrPause);
      };
    }, [playOrPause]);
  }
  const fadeDirection = isHorizontal ? "to right" : "to bottom";
  const fadeWidthStart = fadeWidth / 2;
  const fadeWidthEnd = 100 - fadeWidth / 2;
  const fadeInsetStart = clamp(fadeInset, 0, fadeWidthStart);
  const fadeInsetEnd = 100 - fadeInset;
  const fadeMask = `linear-gradient(${fadeDirection}, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetStart}%, rgba(0, 0, 0, 1) ${fadeWidthStart}%, rgba(0, 0, 0, 1) ${fadeWidthEnd}%, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetEnd}%)`;
  if (!hasChildren) {
    return /* @__PURE__ */ _jsxs("section", { style: placeholderStyles, children: [/* @__PURE__ */ _jsx("div", { style: emojiStyles, children: "\u2728" }), /* @__PURE__ */ _jsx("p", { style: titleStyles, children: "Connect to Content" }), /* @__PURE__ */ _jsx("p", { style: subtitleStyles, children: "Add layers or components to infinitely loop on your page." })] });
  }
  return /* @__PURE__ */ _jsx("section", { style: { ...containerStyle, opacity, WebkitMaskImage: fadeContent ? fadeMask : void 0, maskImage: fadeContent ? fadeMask : void 0, overflow: overflow ? "visible" : "hidden", padding: paddingValue }, ref: parentRef, children: /* @__PURE__ */ _jsxs(motion.ul, { ref: listRef, style: { ...containerStyle, gap, top: direction === "bottom" && isValidNumber(animateToValue) ? -animateToValue : void 0, left: direction === "right" && isValidNumber(animateToValue) ? animateToValue * (writingDirection === "rtl" ? 1 : -1) : void 0, placeItems: alignment, position: "relative", flexDirection: isHorizontal ? "row" : "column", ...style, willChange: isCanvas || !isInView ? "auto" : "transform", transform: transformer(0) }, onMouseEnter: () => {
    isHover.current = true;
    if (animationRef.current) {
      animationRef.current.playbackRate = hoverFactor;
    }
  }, onMouseLeave: () => {
    isHover.current = false;
    if (animationRef.current) {
      animationRef.current.playbackRate = 1;
    }
  }, children: [clonedChildren, dupedChildren] }) });
}
var Wrapper = /* @__PURE__ */ forwardRef(({ children, ...props }, ref) => {
  const innerRef = useRef();
  const inView = useInView(innerRef);
  useImperativeHandle(ref, () => innerRef.current);
  useEffect(() => {
    const current = innerRef.current;
    if (!current)
      return;
    if (inView) {
      current.querySelectorAll("button,a").forEach((el) => {
        const orig = el.dataset.origTabIndex;
        if (orig)
          el.tabIndex = orig;
        else
          el.removeAttribute("tabIndex");
      });
    } else {
      current.querySelectorAll("button,a").forEach((el) => {
        const orig = el.getAttribute("tabIndex");
        if (orig)
          el.dataset.origTabIndex = orig;
        el.tabIndex = -1;
      });
    }
  }, [inView]);
  return /* @__PURE__ */ _jsx("li", { ...props, "aria-hidden": !inView, ref: innerRef, children });
});
Ticker.defaultProps = { gap: 10, padding: 10, sizingOptions: { widthType: true, heightType: true }, fadeOptions: { fadeContent: true, overflow: false, fadeWidth: 25, fadeAlpha: 0, fadeInset: 0 }, direction: true };
addPropertyControls(Ticker, { slots: { type: ControlType.Array, title: "Children", control: { type: ControlType.ComponentInstance } }, speed: { type: ControlType.Number, title: "Speed", min: 0, max: 1e3, defaultValue: 100, unit: "%", displayStepper: true, step: 5 }, direction: { type: ControlType.Enum, title: "Direction", options: ["left", "right", "top", "bottom"], optionIcons: ["direction-left", "direction-right", "direction-up", "direction-down"], optionTitles: ["Left", "Right", "Top", "Bottom"], defaultValue: "left", displaySegmentedControl: true }, alignment: { type: ControlType.Enum, title: "Align", options: ["flex-start", "center", "flex-end"], optionIcons: { direction: { right: ["align-top", "align-middle", "align-bottom"], left: ["align-top", "align-middle", "align-bottom"], top: ["align-left", "align-center", "align-right"], bottom: ["align-left", "align-center", "align-right"] } }, defaultValue: "center", displaySegmentedControl: true }, gap: { type: ControlType.Number, title: "Gap" }, padding: { title: "Padding", type: ControlType.FusedNumber, toggleKey: "paddingPerSide", toggleTitles: ["Padding", "Padding per side"], valueKeys: ["paddingTop", "paddingRight", "paddingBottom", "paddingLeft"], valueLabels: ["T", "R", "B", "L"], min: 0 }, sizingOptions: { type: ControlType.Object, title: "Sizing", controls: { widthType: { type: ControlType.Boolean, title: "Width", enabledTitle: "Auto", disabledTitle: "Stretch", defaultValue: true }, heightType: { type: ControlType.Boolean, title: "Height", enabledTitle: "Auto", disabledTitle: "Stretch", defaultValue: true } } }, fadeOptions: { type: ControlType.Object, title: "Clipping", controls: { fadeContent: { type: ControlType.Boolean, title: "Fade", defaultValue: true }, overflow: { type: ControlType.Boolean, title: "Overflow", enabledTitle: "Show", disabledTitle: "Hide", defaultValue: false, hidden(props) {
  return props.fadeContent === true;
} }, fadeWidth: { type: ControlType.Number, title: "Width", defaultValue: 25, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeInset: { type: ControlType.Number, title: "Inset", defaultValue: 0, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeAlpha: { type: ControlType.Number, title: "Opacity", defaultValue: 0, min: 0, max: 1, step: 0.05, hidden(props) {
  return props.fadeContent === false;
} } } }, hoverFactor: { type: ControlType.Number, title: "Hover", min: 0, max: 1, unit: "x", defaultValue: 1, step: 0.1, displayStepper: true, description: "Slows down the speed while you are hovering." } });
var containerStyle = { display: "flex", width: "100%", height: "100%", maxWidth: "100%", maxHeight: "100%", placeItems: "center", margin: 0, padding: 0, listStyleType: "none", textIndent: "none" };
var placeholderStyles = { display: "flex", width: "100%", height: "100%", placeContent: "center", placeItems: "center", flexDirection: "column", color: "#96F", background: "rgba(136, 85, 255, 0.1)", fontSize: 11, overflow: "hidden", padding: "20px 20px 30px 20px" };
var emojiStyles = { fontSize: 32, marginBottom: 10 };
var titleStyles = { margin: 0, marginBottom: 10, fontWeight: 600, textAlign: "center" };
var subtitleStyles = { margin: 0, opacity: 0.7, maxWidth: 150, lineHeight: 1.5, textAlign: "center" };
var clamp = (num, min, max) => Math.min(Math.max(num, min), max);
var isValidNumber = (value) => typeof value === "number" && !isNaN(value);
function useWritingDirection() {
  if (!__dai_window || !__dai_window.document || !__dai_window.document.documentElement)
    return "ltr";
  return __dai_window.document.documentElement.dir === "rtl" ? "rtl" : "ltr";
}
function getTickerResolvedDirection(direction, writingDirection) {
  if (writingDirection !== "rtl")
    return direction;
  if (direction === "left")
    return "right";
  if (direction === "right")
    return "left";
  return direction;
}

// http-url:https://framerusercontent.com/modules/UMqryexdtNrfL08yxLNf/EkK5livqa9BYg9IaaazX/k9I8OGkLF.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx, getLoadingLazyAtYPosition, Image as Image1, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef as useRef2 } from "react";
var serializationHash = "framer-i7N1L";
var variantClassNames = { tpB_XS4XM: "framer-v-viea2f" };
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion2.create(React.Fragment);
var getProps = ({ click, height, id, image, width, ...props }) => {
  return { ...props, n9xon30Rn: image ?? props.n9xon30Rn ?? { pixelHeight: 90, pixelWidth: 235, src: "https://framerusercontent.com/images/tQNWoXJ7qFZO2umavXnEjfEuY3E.png?width=235&height=90" }, s91a20D5c: click ?? props.s91a20D5c };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, n9xon30Rn, s91a20D5c, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "tpB_XS4XM", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTap8fv6yz = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    if (s91a20D5c) {
      const res = await s91a20D5c(...args);
      if (res === false)
        return false;
    }
  });
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx2(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsx2(motion2.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-viea2f", className, classNames), "data-framer-name": "Primary", "data-highlight": true, layoutDependency, layoutId: "ClientLogoSection__tpB_XS4XM", onTap: onTap8fv6yz, ref: refBinding, style: { borderBottomLeftRadius: 10, borderBottomRightRadius: 10, borderTopLeftRadius: 10, borderTopRightRadius: 10, ...style }, children: /* @__PURE__ */ _jsx2(Image1, { background: { alt: "", fit: "fit", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + (0 + ((componentViewport?.height || 45) - 0 - 50) / 2)), pixelHeight: 90, pixelWidth: 235, sizes: "90px", ...toResponsiveImage(n9xon30Rn), ...{ positionX: "center", positionY: "center" } }, className: "framer-qv2j6o", "data-framer-name": "Logo Image", layoutDependency, layoutId: "ClientLogoSection__n5EbZ6kd8" }) }) }) }) });
});
var css = [".framer-i7N1L.framer-12m40u3, .framer-i7N1L .framer-12m40u3 { display: block; }", ".framer-i7N1L.framer-viea2f { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-i7N1L .framer-qv2j6o { aspect-ratio: 2 / 1; flex: none; height: auto; overflow: hidden; position: relative; width: 90px; will-change: var(--framer-will-change-filter-override, filter); }"];
var Framerk9I8OGkLF = withCSS(Component, css, "framer-i7N1L");
var k9I8OGkLF_default = Framerk9I8OGkLF;
Framerk9I8OGkLF.displayName = "LogoCard";
Framerk9I8OGkLF.defaultProps = { height: 45, width: 90 };
addPropertyControls2(Framerk9I8OGkLF, { n9xon30Rn: { __defaultAssetReference: "data:framer/asset-reference,tQNWoXJ7qFZO2umavXnEjfEuY3E.png?originalFilename=teamlogo01.png&width=235&height=90", title: "Image", type: ControlType2.ResponsiveImage }, s91a20D5c: { title: "Click", type: ControlType2.EventHandler } });
addFonts(Framerk9I8OGkLF, [{ explicitInter: true, fonts: [] }], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/9020SqwA4X7DchIEa0Aq/YiwuzrFsQFGts6HbKrfJ/ZmbC6kcKD.js
var LogoCardFonts = getFonts(k9I8OGkLF_default);
var TickerFonts = getFonts(Ticker);
var cycleOrder = ["QjuPpK8DZ", "Q8s3jAhtP"];
var serializationHash2 = "framer-13LMe";
var variantClassNames2 = { Q8s3jAhtP: "framer-v-gy3deg", QjuPpK8DZ: "framer-v-3r02q3" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition12 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var addImageAlt = (image, alt) => {
  if (!image || typeof image !== "object") {
    return;
  }
  return { ...image, alt };
};
var Transition2 = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext2.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Logos: "QjuPpK8DZ", Mobile: "Q8s3jAhtP" };
var Variants2 = motion3.create(React2.Fragment);
var getProps2 = ({ height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "QjuPpK8DZ" };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef3(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className, layoutId, variant, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder, defaultVariant: "QjuPpK8DZ", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash2, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx3(LayoutGroup3, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition2, { value: transition12, children: /* @__PURE__ */ _jsx3(motion3.section, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-3r02q3", className, classNames), "data-framer-name": "Logos", layoutDependency, layoutId: "ClientLogoSection__QjuPpK8DZ", ref: refBinding, style: { opacity: 0.4, ...style }, ...addPropertyOverrides({ Q8s3jAhtP: { "data-framer-name": "Mobile" } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx3(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-hj7l83-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "ClientLogoSection__CbLeCcWyr-container", nodeId: "CbLeCcWyr", rendersWithMotion: true, scopeId: "ZmbC6kcKD", children: /* @__PURE__ */ _jsx3(Ticker, { alignment: "center", direction: "left", fadeOptions: { fadeAlpha: 0, fadeContent: true, fadeInset: 0, fadeWidth: 25, overflow: false }, gap: 52, height: "100%", hoverFactor: 1, id: "CbLeCcWyr", layoutId: "ClientLogoSection__CbLeCcWyr", padding: 10, paddingBottom: 10, paddingLeft: 0, paddingPerSide: true, paddingRight: 0, paddingTop: 10, sizingOptions: { heightType: true, widthType: true }, slots: [/* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 45, width: "100px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-n8rgiv-container", "data-framer-name": "Logo Card 1", inComponentSlot: true, isModuleExternal: true, layoutDependency, layoutId: "ClientLogoSection__MC2dJ4K2e-container", name: "Logo Card 1", nodeId: "MC2dJ4K2e", rendersWithMotion: true, scopeId: "ZmbC6kcKD", children: /* @__PURE__ */ _jsx3(k9I8OGkLF_default, { height: "100%", id: "MC2dJ4K2e", layoutId: "ClientLogoSection__MC2dJ4K2e", n9xon30Rn: addImageAlt({ pixelHeight: 45, pixelWidth: 243, src: "https://framerusercontent.com/images/Et8pY5xirRlA6O29SZnT2aF7Yw.png?width=243&height=45" }, "logo"), name: "Logo Card 1", style: { width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 45, width: "100px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-1mt0kti-container", "data-framer-name": "Logo Card 2", inComponentSlot: true, isModuleExternal: true, layoutDependency, layoutId: "ClientLogoSection__sHDs5qBo2-container", name: "Logo Card 2", nodeId: "sHDs5qBo2", rendersWithMotion: true, scopeId: "ZmbC6kcKD", children: /* @__PURE__ */ _jsx3(k9I8OGkLF_default, { height: "100%", id: "sHDs5qBo2", layoutId: "ClientLogoSection__sHDs5qBo2", n9xon30Rn: addImageAlt({ pixelHeight: 46, pixelWidth: 243, src: "https://framerusercontent.com/images/9z6XUwPT9lpGDl2ZeETTM29JM.png?width=243&height=46" }, ""), name: "Logo Card 2", style: { width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 45, width: "100px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-1jxi2y4-container", "data-framer-name": "Logo Card 3", inComponentSlot: true, isModuleExternal: true, layoutDependency, layoutId: "ClientLogoSection__pRTPcQuh4-container", name: "Logo Card 3", nodeId: "pRTPcQuh4", rendersWithMotion: true, scopeId: "ZmbC6kcKD", children: /* @__PURE__ */ _jsx3(k9I8OGkLF_default, { height: "100%", id: "pRTPcQuh4", layoutId: "ClientLogoSection__pRTPcQuh4", n9xon30Rn: addImageAlt({ pixelHeight: 51, pixelWidth: 131, src: "https://framerusercontent.com/images/gVccg3XRxkU5g3qYelWiarxyk.png?width=131&height=51" }, ""), name: "Logo Card 3", style: { width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 45, width: "100px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-1o9hm40-container", "data-framer-name": "Logo Card 4", inComponentSlot: true, isModuleExternal: true, layoutDependency, layoutId: "ClientLogoSection__aK4YxinAo-container", name: "Logo Card 4", nodeId: "aK4YxinAo", rendersWithMotion: true, scopeId: "ZmbC6kcKD", children: /* @__PURE__ */ _jsx3(k9I8OGkLF_default, { height: "100%", id: "aK4YxinAo", layoutId: "ClientLogoSection__aK4YxinAo", n9xon30Rn: addImageAlt({ pixelHeight: 60, pixelWidth: 243, src: "https://framerusercontent.com/images/vS9bofL1FJms9UViAbYwd5cyO4.png?width=243&height=60" }, ""), name: "Logo Card 4", style: { width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 45, width: "100px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-8jcpnx-container", "data-framer-name": "Logo Card 5", inComponentSlot: true, isModuleExternal: true, layoutDependency, layoutId: "ClientLogoSection__JCjXANTjz-container", name: "Logo Card 5", nodeId: "JCjXANTjz", rendersWithMotion: true, scopeId: "ZmbC6kcKD", children: /* @__PURE__ */ _jsx3(k9I8OGkLF_default, { height: "100%", id: "JCjXANTjz", layoutId: "ClientLogoSection__JCjXANTjz", n9xon30Rn: addImageAlt({ pixelHeight: 60, pixelWidth: 126, src: "https://framerusercontent.com/images/G9gvtNIfKwpGBWnJuHqW9XWgU.png?width=126&height=60" }, ""), name: "Logo Card 5", style: { width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 45, width: "100px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-1ibzziv-container", "data-framer-name": "Logo Card 6", inComponentSlot: true, isModuleExternal: true, layoutDependency, layoutId: "ClientLogoSection__P1P_ZauLD-container", name: "Logo Card 6", nodeId: "P1P_ZauLD", rendersWithMotion: true, scopeId: "ZmbC6kcKD", children: /* @__PURE__ */ _jsx3(k9I8OGkLF_default, { height: "100%", id: "P1P_ZauLD", layoutId: "ClientLogoSection__P1P_ZauLD", n9xon30Rn: addImageAlt({ pixelHeight: 49, pixelWidth: 243, src: "https://framerusercontent.com/images/xOymBQvn4omrie86x0xy6zSQlOw.png?width=243&height=49" }, ""), name: "Logo Card 6", style: { width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 45, width: "100px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-apq3rx-container", "data-framer-name": "Logo Card 7", inComponentSlot: true, isModuleExternal: true, layoutDependency, layoutId: "ClientLogoSection__HfuN2yFt5-container", name: "Logo Card 7", nodeId: "HfuN2yFt5", rendersWithMotion: true, scopeId: "ZmbC6kcKD", children: /* @__PURE__ */ _jsx3(k9I8OGkLF_default, { height: "100%", id: "HfuN2yFt5", layoutId: "ClientLogoSection__HfuN2yFt5", n9xon30Rn: addImageAlt({ pixelHeight: 46, pixelWidth: 189, src: "https://framerusercontent.com/images/QUjCNF2sEpxftpKtN05ox3MZ4M.png?width=189&height=46" }, ""), name: "Logo Card 7", style: { width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 45, width: "100px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-5fayhm-container", "data-framer-name": "Logo Card 8", inComponentSlot: true, isModuleExternal: true, layoutDependency, layoutId: "ClientLogoSection__dpo79X04a-container", name: "Logo Card 8", nodeId: "dpo79X04a", rendersWithMotion: true, scopeId: "ZmbC6kcKD", children: /* @__PURE__ */ _jsx3(k9I8OGkLF_default, { height: "100%", id: "dpo79X04a", layoutId: "ClientLogoSection__dpo79X04a", n9xon30Rn: addImageAlt({ pixelHeight: 59, pixelWidth: 243, src: "https://framerusercontent.com/images/5VrvNZuTOk4EhzfLYXypiyvGZk.png?width=243&height=59" }, ""), name: "Logo Card 8", style: { width: "100%" }, width: "100%" }) }) })], speed: 20, style: { height: "100%", width: "100%" }, width: "100%", ...addPropertyOverrides({ Q8s3jAhtP: { gap: 32 } }, baseVariant, gestureVariant) }) }) }) }) }) }) });
});
var css2 = [".framer-13LMe.framer-1jejosp, .framer-13LMe .framer-1jejosp { display: block; }", ".framer-13LMe.framer-3r02q3 { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: auto; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-13LMe .framer-hj7l83-container { flex: 1 0 0px; height: 100%; position: relative; width: 1px; z-index: 1; }", ".framer-13LMe .framer-n8rgiv-container, .framer-13LMe .framer-1mt0kti-container, .framer-13LMe .framer-1jxi2y4-container, .framer-13LMe .framer-1o9hm40-container, .framer-13LMe .framer-8jcpnx-container, .framer-13LMe .framer-1ibzziv-container, .framer-13LMe .framer-apq3rx-container, .framer-13LMe .framer-5fayhm-container { height: auto; position: relative; width: 100px; }"];
var FramerZmbC6kcKD = withCSS2(Component2, css2, "framer-13LMe");
var ZmbC6kcKD_default = FramerZmbC6kcKD;
FramerZmbC6kcKD.displayName = "ClientLogoSection";
FramerZmbC6kcKD.defaultProps = { height: 45, width: 430 };
addPropertyControls3(FramerZmbC6kcKD, { variant: { options: ["QjuPpK8DZ", "Q8s3jAhtP"], optionTitles: ["Logos", "Mobile"], title: "Variant", type: ControlType3.Enum } });
addFonts2(FramerZmbC6kcKD, [{ explicitInter: true, fonts: [] }, ...LogoCardFonts, ...TickerFonts], { supportsExplicitInterCodegen: true });
FramerZmbC6kcKD.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader(k9I8OGkLF_default, {}, context)]);
} };
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerZmbC6kcKD", "slots": [], "annotations": { "framerIntrinsicHeight": "45", "framerComponentViewportWidth": "true", "framerImmutableVariables": "true", "framerContractVersion": "1", "framerAutoSizeImages": "true", "framerDisplayContentsDiv": "false", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","fixed"]},"Q8s3jAhtP":{"layout":["fixed","fixed"]}}}', "framerIntrinsicWidth": "430", "framerColorSyntax": "true" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  ZmbC6kcKD_default as default
};
