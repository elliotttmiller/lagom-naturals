var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/B1hP884jJHIfNthpw0EO/xsiEbQcoKTkU0TNGTkxQ/M5TzCTtdH.js
import { jsx as _jsx3, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx as cx3, getFontsFromSharedStyle, Instance, RichText, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS3, withFX } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion3, MotionConfigContext } from "framer-motion";
import * as React3 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/sPPEJJGDR4eUvdon1Bel/f3XESni8XlI3ypQ6Exdb/HbzxRJMyi.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 1.5 16.5 C 0.672 16.5 0 15.828 0 15 L 0 1.5 C 0 0.672 0.672 0 1.5 0 L 15 0 C 15.828 0 16.5 0.672 16.5 1.5 L 16.5 15 C 16.5 15.828 15.828 16.5 15 16.5 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="16.5px" id="qUr6K2nJv" transform="translate(3.75 3.75)" width="16.5px"/><path d="M 0 0 L 16.5 0" fill="transparent" height="1px" id="MbfmAbWGf" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(3.75 12)" width="16.5px"/><path d="M 0 0 L 0 16.5" fill="transparent" height="16.5px" id="mcA57vhod" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(12 3.75)" width="1px"/></svg>';
var getProps = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps(props);
  const href = useSVGTemplate("465907804", svg);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-ohg0r", className3), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx("use", { href }) });
});
var css = [`.framer-ohg0r { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-ohg0r");
Icon.displayName = "Plus";
var HbzxRJMyi_default = Icon;
addPropertyControls(Icon, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType.Number } });

// http-url:https://framerusercontent.com/modules/XWlg8k1reSGaD8FxxtNM/bBmqMkWmu9cdiWRo7WqL/KgtuTnV_8.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, motion as motion2, useSVGTemplate as useSVGTemplate2, withCSS as withCSS2 } from "./_framer-runtime.js";
import * as React2 from "react";
import { forwardRef as forwardRef4 } from "react";
var mask2 = "var(--framer-icon-mask)";
var Base2 = /* @__PURE__ */ forwardRef4(function(props, ref) {
  return /* @__PURE__ */ _jsx2("svg", { ...props, ref, children: props.children });
});
var MotionSVG2 = motion2.create(Base2);
var SVG2 = /* @__PURE__ */ forwardRef4((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx2(MotionSVG2, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx2("svg", { ...rest, ref, children });
});
var svg2 = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 1.5 16.5 C 0.672 16.5 0 15.828 0 15 L 0 1.5 C 0 0.672 0.672 0 1.5 0 L 15 0 C 15.828 0 16.5 0.672 16.5 1.5 L 16.5 15 C 16.5 15.828 15.828 16.5 15 16.5 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="16.5px" id="jSiOsA4GS" transform="translate(3.75 3.75)" width="16.5px"/><path d="M 0 0 L 16.5 0" fill="transparent" height="1px" id="NfSWNK3uH" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(3.75 12)" width="16.5px"/></svg>';
var getProps2 = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps2(props);
  const href = useSVGTemplate2("650073895", svg2);
  return /* @__PURE__ */ _jsx2(SVG2, { ...restProps, className: cx2("framer-I69i9", className3), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx2("use", { href }) });
});
var css2 = [`.framer-I69i9 { -webkit-mask: ${mask2}; aspect-ratio: 1; display: block; mask: ${mask2}; width: 24px; }`];
var Icon2 = withCSS2(Component2, css2, "framer-I69i9");
Icon2.displayName = "Minus";
var KgtuTnV_8_default = Icon2;
addPropertyControls2(Icon2, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType2.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType2.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType2.Number } });

// http-url:https://framerusercontent.com/modules/ZiLwJyzmfb5yYsNLqpUJ/BL4yEGOxj5ihKvIyunNa/hP4T9JYKh.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["CUSTOMV2;Satoshi Regular", "CUSTOMV2;Satoshi Bold", "CUSTOMV2;Satoshi Bold Italic", "CUSTOMV2;Satoshi Italic"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Satoshi Regular", source: "custom", style: "normal", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/4DUCFyigHLkZDMSHultGoxWxF6c.woff2", weight: "400" }, { cssFamilyName: "Satoshi Bold", source: "custom", style: "normal", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/49nn5wajwTdLi5telQzvjmGNc.woff2", weight: "700" }, { cssFamilyName: "Satoshi Bold Italic", source: "custom", style: "italic", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/CG6kqUPNTBiTqgSzrGvDdU0g3M.woff2", weight: "700" }, { cssFamilyName: "Satoshi Italic", source: "custom", style: "italic", uiFamilyName: "Satoshi", url: "https://framerusercontent.com/assets/ph4HmTgh5F9Y8JSn9KvsRc89yI0.woff2", weight: "400" }] }];
var css3 = ['.framer-8YGpi .framer-styles-preset-1vb2uzv:not(.rich-text-wrapper), .framer-8YGpi .framer-styles-preset-1vb2uzv.rich-text-wrapper p { --framer-font-family: "Satoshi Regular", "Satoshi Regular Placeholder", sans-serif; --framer-font-family-bold: "Satoshi Bold", "Satoshi Bold Placeholder", sans-serif; --framer-font-family-bold-italic: "Satoshi Bold Italic", "Satoshi Bold Italic Placeholder", sans-serif; --framer-font-family-italic: "Satoshi Italic", "Satoshi Italic Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 15px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: rgba(0, 0, 0, 0.5); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className = "framer-8YGpi";

// http-url:https://framerusercontent.com/modules/kMj2A9W43yXDvQe9eqM0/YXiCCaXIR9cVt1A9hrJu/ZZFsrL_Ft.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["GF;Geist-regular", "GF;Geist-700", "GF;Geist-700italic", "GF;Geist-italic"]);
var fonts2 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v5/gyBhhwUxId8gMGYQMKR3pzfaWI_RnOM4mJPby1QNtA.woff2", weight: "400" }, { cssFamilyName: "Geist", source: "google", style: "normal", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v5/gyBhhwUxId8gMGYQMKR3pzfaWI_Re-Q4mJPby1QNtA.woff2", weight: "700" }, { cssFamilyName: "Geist", source: "google", style: "italic", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v5/gyBjhwUxId8gMEwZAluvzlxA9ojEVKA32Zna6VEdtKCL.woff2", weight: "700" }, { cssFamilyName: "Geist", source: "google", style: "italic", uiFamilyName: "Geist", url: "https://fonts.gstatic.com/s/geist/v5/gyBjhwUxId8gMEwZAluvzlxA9ojEVKDQ3pna6VEdtKCL.woff2", weight: "400" }] }];
var css4 = ['.framer-cVTXy .framer-styles-preset-1lqtzqu:not(.rich-text-wrapper), .framer-cVTXy .framer-styles-preset-1lqtzqu.rich-text-wrapper p { --framer-font-family: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-bold-italic: "Geist", "Geist Placeholder", sans-serif; --framer-font-family-italic: "Geist", "Geist Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 19px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: -0.03em; --framer-line-height: 1.3em; --framer-paragraph-spacing: 10px; --framer-text-alignment: start; --framer-text-color: #000000; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className2 = "framer-cVTXy";

// http-url:https://framerusercontent.com/modules/B1hP884jJHIfNthpw0EO/xsiEbQcoKTkU0TNGTkxQ/M5TzCTtdH.js
var MotionDivWithFX = withFX(motion3.div);
var cycleOrder = ["hJdzL5rWi", "W5mydbL3o"];
var serializationHash = "framer-xViH7";
var variantClassNames = { hJdzL5rWi: "framer-v-1w3abx2", W5mydbL3o: "framer-v-vz6bhr" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var animation = { opacity: 0, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 60 };
var transition1 = { bounce: 0.2, delay: 0, duration: 0.6, type: "spring" };
var transition2 = { delay: 0, duration: 0.3, ease: [0.44, 0, 0.56, 1], type: "tween" };
var Transition = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "Variant 1": "hJdzL5rWi", "Variant 2": "W5mydbL3o" };
var Variants = motion3.create(React3.Fragment);
var getProps3 = ({ answer, height, id, questions, width, ...props }) => {
  return { ...props, mMOJuIJUy: answer ?? props.mMOJuIJUy ?? "We work across brand strategy, visual identity, websites, and digital experiences for ambitious teams and growing businesses", TXXSjhnNn: questions ?? props.TXXSjhnNn ?? "What kind of projects do you take on?", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "hJdzL5rWi" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className3, layoutId, variant, TXXSjhnNn, mMOJuIJUy, ...restProps } = getProps3(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "hJdzL5rWi", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTap1c6bu5j = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    setVariant("W5mydbL3o");
  });
  const onTap17w4ov = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    setVariant("hJdzL5rWi");
  });
  const sharedStyleClassNames = [className2, className];
  const scopingClassNames = cx3(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "W5mydbL3o")
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx3(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition, { value: transition2, children: /* @__PURE__ */ _jsx3(MotionDivWithFX, { ...restProps, ...gestureHandlers, __framer__animate: { transition: transition1 }, __framer__animateOnce: true, __framer__enter: animation, __framer__styleAppearEffectEnabled: true, __framer__threshold: 0.5, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: cx3(scopingClassNames, "framer-1w3abx2", className3, classNames), "data-framer-name": "Variant 1", "data-highlight": true, layoutDependency, layoutId: "Question__hJdzL5rWi", onTap: onTap1c6bu5j, ref: refBinding, style: { backgroundColor: "var(--token-1ac2ba4c-22b7-47aa-9e58-8ba58b451a8f, rgb(255, 255, 255))", borderBottomLeftRadius: 26, borderBottomRightRadius: 26, borderTopLeftRadius: 26, borderTopRightRadius: 26, ...style }, variants: { W5mydbL3o: { borderBottomLeftRadius: 24, borderBottomRightRadius: 24, borderTopLeftRadius: 24, borderTopRightRadius: 24 } }, ...addPropertyOverrides({ W5mydbL3o: { "data-framer-name": "Variant 2", onTap: onTap17w4ov } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsxs(motion3.div, { className: "framer-1cr3osp", layoutDependency, layoutId: "Question__WE2kKnfQZ", children: [/* @__PURE__ */ _jsxs(motion3.div, { className: "framer-f8dci1", layoutDependency, layoutId: "Question__n8CKA47QY", children: [/* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.p, { className: "framer-styles-preset-1lqtzqu", "data-styles-preset": "ZZFsrL_Ft", dir: "auto", style: { "--framer-text-alignment": "start", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-9498c07e-7b77-44b6-8e71-03fa38beafc1, rgb(0, 0, 0)))" }, children: "Discover" }) }), className: "framer-1ukz929", fonts: ["Inter"], layoutDependency, layoutId: "Question__movE5dHpK", style: { "--extracted-r6o4lv": "var(--token-9498c07e-7b77-44b6-8e71-03fa38beafc1, rgb(0, 0, 0))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: TXXSjhnNn, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx3(motion3.div, { className: "framer-v08s2c", "data-border": true, layoutDependency, layoutId: "Question__OLxAP7FYX", style: { "--border-bottom-width": "1px", "--border-color": "var(--token-7ae16c10-4aca-40fc-b5f2-830c3eb21322, rgb(235, 235, 233))", "--border-left-width": "1px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "1px", backgroundColor: "var(--token-3262e9ee-bb58-4333-ba85-cab31425ce1c, rgb(245, 245, 245))", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100 }, variants: { W5mydbL3o: { "--border-bottom-width": "0px", "--border-left-width": "0px", "--border-right-width": "0px", "--border-top-width": "0px", backgroundColor: "var(--token-9498c07e-7b77-44b6-8e71-03fa38beafc1, rgb(0, 0, 0))" } }, children: /* @__PURE__ */ _jsx3(Instance, { animated: true, className: "framer-1lnwby4", Component: HbzxRJMyi_default, layoutDependency, layoutId: "Question__nKkh2kHfu", style: { "--1m6trwb": 0, "--21h8s6": "var(--token-9498c07e-7b77-44b6-8e71-03fa38beafc1, rgb(0, 0, 0))", "--pgex8v": 1 }, variants: { W5mydbL3o: { "--21h8s6": "var(--token-1ac2ba4c-22b7-47aa-9e58-8ba58b451a8f, rgb(255, 255, 255))" } }, ...addPropertyOverrides({ W5mydbL3o: { Component: KgtuTnV_8_default } }, baseVariant, gestureVariant) }) })] }), isDisplayed() && /* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.p, { className: "framer-styles-preset-1vb2uzv", "data-styles-preset": "hP4T9JYKh", dir: "auto", style: { "--framer-text-alignment": "start", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-efaf5a33-59fe-4061-aab9-5ec624375fac, rgba(0, 0, 0, 0.6)))" }, children: "We learn about your goals, audience, and key challenges learn about your goals, audience, and key challenges learn about your goals, audience, and key challenges" }) }), className: "framer-14jfufm", fonts: ["Inter"], layoutDependency, layoutId: "Question__IFrkSVOiy", style: { "--extracted-r6o4lv": "var(--token-efaf5a33-59fe-4061-aab9-5ec624375fac, rgba(0, 0, 0, 0.6))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: mMOJuIJUy, verticalAlignment: "top", withExternalLayout: true })] }) }) }) }) });
});
var css5 = [".framer-xViH7.framer-1cna64f, .framer-xViH7 .framer-1cna64f { display: block; }", ".framer-xViH7.framer-1w3abx2 { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 16px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-xViH7 .framer-1cr3osp { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 20px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-xViH7 .framer-f8dci1 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 24px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-xViH7 .framer-1ukz929 { flex: 1 0 0px; height: auto; position: relative; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; }", ".framer-xViH7 .framer-v08s2c { align-content: center; align-items: center; aspect-ratio: 1 / 1; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: auto; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 28px; }", ".framer-xViH7 .framer-1lnwby4 { flex: none; height: auto; position: relative; width: 20px; }", ".framer-xViH7 .framer-14jfufm { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ...css4, ...css3, '.framer-xViH7[data-border="true"]::after, .framer-xViH7 [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerM5TzCTtdH = withCSS3(Component3, css5, "framer-xViH7");
var M5TzCTtdH_default = FramerM5TzCTtdH;
FramerM5TzCTtdH.displayName = "Question";
FramerM5TzCTtdH.defaultProps = { height: 60, width: 576 };
addPropertyControls3(FramerM5TzCTtdH, { variant: { options: ["hJdzL5rWi", "W5mydbL3o"], optionTitles: ["Variant 1", "Variant 2"], title: "Variant", type: ControlType3.Enum }, TXXSjhnNn: { defaultValue: "What kind of projects do you take on?", displayTextArea: false, title: "Questions", type: ControlType3.String }, onTXXSjhnNnChange: { changes: "TXXSjhnNn", type: ControlType3.ChangeHandler }, mMOJuIJUy: { defaultValue: "We work across brand strategy, visual identity, websites, and digital experiences for ambitious teams and growing businesses", displayTextArea: false, title: "Answer", type: ControlType3.String }, onmMOJuIJUyChange: { changes: "mMOJuIJUy", type: ControlType3.ChangeHandler } });
addFonts(FramerM5TzCTtdH, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle(fonts2), ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerM5TzCTtdH", "slots": [], "annotations": { "framerContractVersion": "1", "framerAutoSizeImages": "true", "framerDisplayContentsDiv": "false", "framerImmutableVariables": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"W5mydbL3o":{"layout":["fixed","auto"]}}}', "framerColorSyntax": "true", "framerIntrinsicHeight": "60", "framerComponentViewportWidth": "true", "framerVariables": '{"TXXSjhnNn":"questions","mMOJuIJUy":"answer"}', "framerIntrinsicWidth": "576" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  M5TzCTtdH_default as default
};
