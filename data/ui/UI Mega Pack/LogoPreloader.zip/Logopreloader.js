var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/l7hiSNKqodmUTlsuwJGk/GZIcrs0EE9lUY3jQTNPV/LogoPreloader.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState, startTransition } from "react";
import { addPropertyControls, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
function LogoPreloader(props) {
  const { logo = { src: "https://framerusercontent.com/images/GfGkADagM4KEibNcIiRUWlfrR0.jpg", alt: "Logo" }, backgroundColor, duration, logoSize, videoFile = "", backgroundImage = { src: "", alt: "" }, logoInEasing, logoOutEasing, backgroundFadeEasing, style } = props;
  const [phase, setPhase] = useState("init");
  const isStatic = useIsStaticRenderer();
  useEffect(() => {
    if (isStatic)
      return;
    const t0 = setTimeout(() => {
      startTransition(() => setPhase("loading"));
    }, 50);
    const t1 = setTimeout(() => {
      startTransition(() => setPhase("logoOut"));
    }, duration * 1e3 + 50);
    const t2 = setTimeout(() => {
      startTransition(() => setPhase("done"));
    }, duration * 1e3 + 750);
    return () => {
      clearTimeout(t0);
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [duration, isStatic]);
  if (phase === "done")
    return null;
  let logoTranslateY = 0;
  let logoOpacity = 1;
  if (phase === "init") {
    logoTranslateY = 80;
    logoOpacity = 0;
  } else if (phase === "loading") {
    logoTranslateY = 0;
    logoOpacity = 1;
  } else if (phase === "logoOut") {
    logoTranslateY = -80;
    logoOpacity = 0;
  }
  const bgOpacity = phase === "logoOut" ? 0 : 1;
  const transition = "all 0.7s cubic-bezier(.7,.2,.2,1)";
  return /* @__PURE__ */ _jsxs("div", { style: { ...style, position: "relative", width: "100%", height: "100%", background: videoFile || backgroundImage.src ? void 0 : backgroundColor, backgroundImage: !videoFile && backgroundImage.src ? `url(${backgroundImage.src})` : void 0, backgroundSize: "cover", backgroundPosition: "center", display: "flex", alignItems: "center", justifyContent: "center", transition: `opacity 0.7s cubic-bezier(.7,.2,.2,1)`, opacity: bgOpacity, pointerEvents: "all", zIndex: 9999, overflow: "hidden" }, "aria-label": "Loading", role: "status", children: [videoFile && /* @__PURE__ */ _jsx("video", { src: videoFile, autoPlay: true, muted: true, loop: true, playsInline: true, style: { position: "absolute", top: 0, left: 0, width: "100%", height: "100%", objectFit: "cover", zIndex: 0, pointerEvents: "none", opacity: bgOpacity, transition: `opacity 0.7s cubic-bezier(.7,.2,.2,1)` }, "aria-hidden": "true" }), /* @__PURE__ */ _jsx("img", { src: logo.src, alt: logo.alt || "Logo", style: { width: logoSize, height: logoSize, objectFit: "contain", transition, transform: `translateY(${logoTranslateY}px)`, opacity: logoOpacity, willChange: "transform, opacity", userSelect: "none", zIndex: 1 }, draggable: false })] });
}
addPropertyControls(LogoPreloader, { logo: { type: ControlType.ResponsiveImage, title: "Logo" }, videoFile: { type: ControlType.File, allowedFileTypes: ["mp4", "webm", "mov"], title: "Video Background" }, backgroundImage: { type: ControlType.ResponsiveImage, title: "Background Image", hidden: ({ videoFile }) => !!videoFile }, backgroundColor: { type: ControlType.Color, title: "Background", defaultValue: "#FFFFFF", hidden: ({ videoFile, backgroundImage }) => !!videoFile || !!backgroundImage?.src }, duration: { type: ControlType.Number, title: "Duration (s)", defaultValue: 2, min: 0.5, max: 10, step: 0.1 }, logoSize: { type: ControlType.Number, title: "Logo Size", defaultValue: 80, min: 24, max: 400, unit: "px" }, logoInEasing: { type: ControlType.Enum, title: "Logo In Easing", defaultValue: "cubic-bezier(.7,.2,.2,1)", options: ["ease", "ease-in", "ease-out", "ease-in-out", "cubic-bezier(.7,.2,.2,1)", "cubic-bezier(.25,.46,.45,.94)", "cubic-bezier(.55,.085,.68,.53)", "cubic-bezier(.25,.1,.25,1)", "cubic-bezier(.175,.885,.32,1.275)", "custom"], optionTitles: ["Ease", "Ease In", "Ease Out", "Ease In Out", "Smooth", "Ease Out Quad", "Ease In Cubic", "Ease Out Quart", "Back Out", "Custom"] }, logoInEasingCustom: { type: ControlType.String, title: "Custom Logo In Easing", defaultValue: "cubic-bezier(.7,.2,.2,1)", placeholder: "cubic-bezier(x1,y1,x2,y2)", hidden: ({ logoInEasing }) => logoInEasing !== "custom" }, logoOutEasing: { type: ControlType.Enum, title: "Logo Out Easing", defaultValue: "cubic-bezier(.7,.2,.2,1)", options: ["ease", "ease-in", "ease-out", "ease-in-out", "cubic-bezier(.7,.2,.2,1)", "cubic-bezier(.25,.46,.45,.94)", "cubic-bezier(.55,.085,.68,.53)", "cubic-bezier(.25,.1,.25,1)", "cubic-bezier(.175,.885,.32,1.275)", "custom"], optionTitles: ["Ease", "Ease In", "Ease Out", "Ease In Out", "Smooth", "Ease Out Quad", "Ease In Cubic", "Ease Out Quart", "Back Out", "Custom"] }, logoOutEasingCustom: { type: ControlType.String, title: "Custom Logo Out Easing", defaultValue: "cubic-bezier(.7,.2,.2,1)", placeholder: "cubic-bezier(x1,y1,x2,y2)", hidden: ({ logoOutEasing }) => logoOutEasing !== "custom" }, backgroundFadeEasing: { type: ControlType.Enum, title: "Background Fade Easing", defaultValue: "cubic-bezier(.7,.2,.2,1)", options: ["ease", "ease-in", "ease-out", "ease-in-out", "cubic-bezier(.7,.2,.2,1)", "cubic-bezier(.25,.46,.45,.94)", "cubic-bezier(.55,.085,.68,.53)", "cubic-bezier(.25,.1,.25,1)", "cubic-bezier(.175,.885,.32,1.275)", "custom"], optionTitles: ["Ease", "Ease In", "Ease Out", "Ease In Out", "Smooth", "Ease Out Quad", "Ease In Cubic", "Ease Out Quart", "Back Out", "Custom"] }, backgroundFadeEasingCustom: { type: ControlType.String, title: "Custom Background Fade Easing", defaultValue: "cubic-bezier(.7,.2,.2,1)", placeholder: "cubic-bezier(x1,y1,x2,y2)", hidden: ({ backgroundFadeEasing }) => backgroundFadeEasing !== "custom" } });
var LogoPreloader_default = LogoPreloader;
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "LogoPreloader", "slots": [], "annotations": { "framerContractVersion": "1", "framerSupportedLayoutHeight": "any-prefer-fixed", "framerSupportedLayoutWidth": "any-prefer-fixed" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  LogoPreloader_default as default
};
