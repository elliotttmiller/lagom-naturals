export interface E5hhctcwProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Dark Closed" → SnTTeaPpc
   *   "Dark Open" → jTeytEfUG
   *   "Light Closed" → qsjQryIWb
   *   "Light Open" → D09eACQPD
   */
  variant?: 'Dark Closed' | 'Dark Open' | 'Light Closed' | 'Light Open' | 'qsjQryIWb' | 'D09eACQPD' | 'SnTTeaPpc' | 'jTeytEfUG';
  /**
   * Show Clock — pass as `Jl7JpkUR3` not `showClock`.
   * @default true
   */
  Jl7JpkUR3?: boolean;
  onJl7JpkUR3Change?: string;
  /** Additional properties */
  [key: string]: unknown;
}
