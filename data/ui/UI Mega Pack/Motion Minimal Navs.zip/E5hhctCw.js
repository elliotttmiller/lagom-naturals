var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/XnYmjybQDgwQoLHZeZpZ/MujioEUIxxs2G0s0fdLd/E5HHCt_cw.js
import { jsx as _jsx11, jsxs as _jsxs4 } from "react/jsx-runtime";
import { addFonts as addFonts4, addPropertyControls as addPropertyControls11, ComponentViewportProvider, ControlType as ControlType11, cx as cx10, forwardLoader, getFonts, patchBorderRadiusScaleCorrector, RichText as RichText3, SmartComponentScopedContainer, useActiveVariantCallback, useComponentViewport as useComponentViewport4, useLocaleInfo as useLocaleInfo4, useVariantState as useVariantState4, withCSS as withCSS10 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup4, motion as motion10, MotionConfigContext as MotionConfigContext4 } from "framer-motion";
import * as React10 from "react";
import { useRef as useRef5 } from "react";

// http-url:https://framerusercontent.com/modules/4XTgiZQu54CjbB5dhliq/4qeXVdBQKTlCfMoVGgCT/rR4Yw6OW8.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 18.993 2.206 C 18.876 1.737 18.54 1.353 18.09 1.175 C 14.951 -0.033 9.75 0 9.75 0 C 9.75 0 4.549 -0.033 1.406 1.179 C 0.957 1.358 0.621 1.742 0.503 2.211 C 0.288 3.051 0 4.696 0 7.5 C 0 10.304 0.288 11.949 0.507 12.794 C 0.625 13.261 0.959 13.643 1.406 13.821 C 4.549 15.033 9.75 15 9.75 15 C 9.75 15 14.951 15.033 18.094 13.821 C 18.542 13.644 18.878 13.262 18.997 12.794 C 19.216 11.95 19.504 10.304 19.504 7.5 C 19.504 4.696 19.212 3.051 18.993 2.206 Z M 8.25 10.5 L 8.25 4.5 L 12.75 7.5 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="15.000173729153522px" id="Kxf_tc1rc" transform="translate(2.25 4.5)" width="19.503749999999997px"/><path d="M 4.5 3 L 0 0 L 0 6 Z" fill="transparent" height="6px" id="OiQVq1BcP" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(10.5 9)" width="4.5px"/><path d="M 0 7.5 C 0 10.304 0.288 11.949 0.507 12.794 C 0.625 13.261 0.959 13.643 1.406 13.821 C 4.549 15.033 9.75 15 9.75 15 C 9.75 15 14.951 15.033 18.094 13.821 C 18.542 13.644 18.878 13.262 18.997 12.794 C 19.216 11.95 19.504 10.304 19.504 7.5 C 19.504 4.696 19.216 3.052 18.997 2.206 C 18.879 1.737 18.543 1.353 18.094 1.175 C 14.951 -0.033 9.75 0 9.75 0 C 9.75 0 4.549 -0.033 1.406 1.179 C 0.957 1.358 0.621 1.742 0.503 2.211 C 0.288 3.051 0 4.696 0 7.5 Z" fill="transparent" height="15.000173729153499px" id="f0uv60ll0" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(2.25 4.5)" width="19.503749999999997px"/></svg>';
var getProps = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps(props);
  const href = useSVGTemplate("3761207643", svg);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-KIxjp", className3), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx("use", { href }) });
});
var css = [`.framer-KIxjp { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-KIxjp");
Icon.displayName = "Youtube Logo";
var rR4Yw6OW8_default = Icon;
addPropertyControls(Icon, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType.Number } });

// http-url:https://framerusercontent.com/modules/HYcHVPAbe8jLEeU7c4mp/QiycTxX7vdblEOi3o00G/Time.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2, RenderTarget, useLocaleCode } from "./_framer-runtime.js";
import { startTransition, useCallback, useEffect, useRef, useState } from "react";
var fontStack = `"Inter", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"`;
function formatTimeOrDate(outputType, { showYear, showMonth, showWeekday, showMinutes, showSeconds }, timeFormat, monthFormat, localCode) {
  const date = /* @__PURE__ */ new Date();
  const onlyYearIsShown = !showWeekday && !showMonth && showYear;
  switch (outputType) {
    case "date":
      return new Intl.DateTimeFormat(localCode, { weekday: showWeekday ? "long" : void 0, day: onlyYearIsShown ? void 0 : "numeric", month: showMonth ? monthFormat : void 0, year: showYear ? "numeric" : void 0 }).format(date);
    case "time":
      return new Intl.DateTimeFormat(localCode, { hour: "numeric", minute: showMinutes ? "numeric" : void 0, second: showSeconds && showMinutes ? "numeric" : void 0, hour12: timeFormat === "12h" }).format(date);
    default:
      return new Intl.DateTimeFormat(localCode).format(date);
  }
}
var defaultProps = { height: 20, width: 140, outputType: "time", color: "#999", timeFormat: "24h", showYear: true, showMonth: true, showWeekday: true, showMinutes: true, showSeconds: true, monthFormat: "long", alignment: "center" };
function Time(props) {
  const mergedProps = { ...defaultProps, ...props };
  const {
    outputType,
    timeFormat,
    showYear,
    showMonth,
    showWeekday,
    // showHours,
    showMinutes,
    showSeconds,
    monthFormat,
    color,
    font,
    tabularFont
  } = mergedProps;
  const localCode = useLocaleCode();
  const getTextContent = useCallback(() => formatTimeOrDate(outputType, {
    showYear,
    showMonth,
    showWeekday,
    // showHours,
    showMinutes,
    showSeconds
  }, timeFormat, monthFormat, localCode), [localCode, monthFormat, outputType, showMinutes, showMonth, showSeconds, showWeekday, showYear, timeFormat]);
  const timeoutRef = useRef();
  const updateCountdown = useCallback((node) => {
    if (node === null) {
      clearTimeout(timeoutRef.current);
      return;
    }
    let prev;
    const tick = () => {
      const date = /* @__PURE__ */ new Date();
      const next = (/* @__PURE__ */ new Date()).setSeconds(date.getSeconds() + 1, 0) - +date;
      timeoutRef.current = setTimeout(tick, next);
      const textContent = getTextContent();
      if (prev !== textContent) {
        node.textContent = textContent;
        prev = textContent;
      }
    };
    tick();
  }, [getTextContent]);
  const [visible, setIsVisible] = useState(false);
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  useEffect(() => {
    startTransition(() => setIsVisible(true));
    if (isCanvas)
      return;
  }, [isCanvas]);
  return /* @__PURE__ */ _jsx2("p", { suppressHydrationWarning: true, style: { margin: 0, padding: 0, color, fontFamily: fontStack, fontWeight: 500, fontSize: 16, lineHeight: 1, visibility: visible ? "visible" : "hidden", ...font, fontVariantNumeric: tabularFont ? "tabular-nums" : "normal", whiteSpace: "nowrap" }, ref: isCanvas ? void 0 : updateCountdown, children: getTextContent() });
}
Time.displayName = "Time & Date";
addPropertyControls2(Time, {
  outputType: { title: "Type", type: ControlType2.Enum, displaySegmentedControl: true, options: ["date", "time"], optionTitles: ["Date", "Time"], defaultValue: defaultProps.outputType },
  showWeekday: { title: "Day", type: ControlType2.Boolean, enabledTitle: "Show", disabledTitle: "Hide", defaultValue: defaultProps.showWeekday, hidden: (props) => props.outputType !== "date" },
  showMonth: { title: "Month", type: ControlType2.Boolean, enabledTitle: "Show", disabledTitle: "Hide", defaultValue: defaultProps.showMonth, hidden: (props) => props.outputType !== "date" },
  monthFormat: { title: "Format", type: ControlType2.Enum, options: ["short", "long", "numeric"], optionTitles: ["Short", "Long", "Numeric"], defaultValue: defaultProps.monthFormat, hidden: (props) => props.outputType !== "date" || !props.showMonth },
  showYear: { title: "Year", type: ControlType2.Boolean, enabledTitle: "Show", disabledTitle: "Hide", defaultValue: defaultProps.showYear, hidden: (props) => props.outputType !== "date" },
  timeFormat: { title: "Format", type: ControlType2.Enum, options: ["12h", "24h"], optionTitles: ["12h", "24h"], displaySegmentedControl: true, defaultValue: defaultProps.timeFormat, hidden: (props) => props.outputType !== "time" },
  // showHours: {
  //     title: "Hours",
  //     type: ControlType.Boolean,
  //     enabledTitle: "Show",
  //     disabledTitle: "Hide",
  //     defaultValue: defaultProps.showHours,
  //     hidden: (props) => props.outputType !== "time",
  // },
  showMinutes: { title: "Minutes", type: ControlType2.Boolean, enabledTitle: "Show", disabledTitle: "Hide", defaultValue: defaultProps.showMinutes, hidden: (props) => props.outputType !== "time" },
  showSeconds: { title: "Seconds", type: ControlType2.Boolean, enabledTitle: "Show", disabledTitle: "Hide", defaultValue: defaultProps.showSeconds, hidden: (props) => props.outputType !== "time" || !props.showMinutes },
  font: { type: ControlType2.Font, controls: "extended" },
  tabularFont: { title: "Tabular", type: ControlType2.Boolean, defaultValue: true },
  color: { type: ControlType2.Color, defaultValue: defaultProps.color }
});

// http-url:https://framerusercontent.com/modules/oMiuMYAdxzz5yk7pBqrm/j2eV5wGWikO42mvtQ2hM/Xx_sbLkzD.js
import { jsx as _jsx3 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx as cx2, motion as motion2, useSVGTemplate as useSVGTemplate2, withCSS as withCSS2 } from "./_framer-runtime.js";
import * as React2 from "react";
import { forwardRef as forwardRef4 } from "react";
var mask2 = "var(--framer-icon-mask)";
var Base2 = /* @__PURE__ */ forwardRef4(function(props, ref) {
  return /* @__PURE__ */ _jsx3("svg", { ...props, ref, children: props.children });
});
var MotionSVG2 = motion2.create(Base2);
var SVG2 = /* @__PURE__ */ forwardRef4((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx3(MotionSVG2, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx3("svg", { ...rest, ref, children });
});
var svg2 = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 0 0 L 4.5 0 L 15 16.5 L 10.5 16.5 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="16.5px" id="wBdJ15Yu6" transform="translate(4.5 3.75)" width="15px"/><path d="M 0 0 L 4.5 0 L 15 16.5 L 10.5 16.5 Z" fill="transparent" height="16.5px" id="El8uvQLqv" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(4.5 3.75)" width="15px"/><path d="M 6.176 0 L 0 6.794" fill="transparent" height="6.7940624999999955px" id="AHSzdg78i" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(4.5 13.456)" width="6.176249999999996px"/><path d="M 6.176 0 L 0 6.794" fill="transparent" height="6.794062499999999px" id="h4GjUNYzh" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(13.324 3.75)" width="6.176249999999996px"/></svg>';
var getProps2 = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps2(props);
  const href = useSVGTemplate2("1688045918", svg2);
  return /* @__PURE__ */ _jsx3(SVG2, { ...restProps, className: cx2("framer-QMsyA", className3), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx3("use", { href }) });
});
var css2 = [`.framer-QMsyA { -webkit-mask: ${mask2}; aspect-ratio: 1; display: block; mask: ${mask2}; width: 24px; }`];
var Icon2 = withCSS2(Component2, css2, "framer-QMsyA");
Icon2.displayName = "X Logo";
var Xx_sbLkzD_default = Icon2;
addPropertyControls3(Icon2, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType3.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType3.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType3.Number } });

// http-url:https://framerusercontent.com/modules/PtxaBiSAA5V6LvrpAt6G/EsR1AqByikNQR8Cp2V8c/UD0eTfbk_.js
import { jsx as _jsx4 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls4, ControlType as ControlType4, cx as cx3, motion as motion3, useSVGTemplate as useSVGTemplate3, withCSS as withCSS3 } from "./_framer-runtime.js";
import * as React3 from "react";
import { forwardRef as forwardRef6 } from "react";
var mask3 = "var(--framer-icon-mask)";
var Base3 = /* @__PURE__ */ forwardRef6(function(props, ref) {
  return /* @__PURE__ */ _jsx4("svg", { ...props, ref, children: props.children });
});
var MotionSVG3 = motion3.create(Base3);
var SVG3 = /* @__PURE__ */ forwardRef6((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx4(MotionSVG3, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx4("svg", { ...rest, ref, children });
});
var svg3 = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 13.5 0 L 4.5 0 C 2.015 0 0 2.015 0 4.5 L 0 13.5 C 0 15.985 2.015 18 4.5 18 L 13.5 18 C 15.985 18 18 15.985 18 13.5 L 18 4.5 C 18 2.015 15.985 0 13.5 0 Z M 9 12.75 C 6.929 12.75 5.25 11.071 5.25 9 C 5.25 6.929 6.929 5.25 9 5.25 C 11.071 5.25 12.75 6.929 12.75 9 C 12.75 11.071 11.071 12.75 9 12.75 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="18px" id="SuXKGhab5" transform="translate(3 3)" width="18px"/><path d="M 4.5 18 C 2.015 18 0 15.985 0 13.5 L 0 4.5 C 0 2.015 2.015 0 4.5 0 L 13.5 0 C 15.985 0 18 2.015 18 4.5 L 18 13.5 C 18 15.985 15.985 18 13.5 18 Z" fill="transparent" height="18px" id="vvJ8FLDVj" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(3 3)" width="18px"/><path d="M 0 3.75 C 0 1.679 1.679 0 3.75 0 C 5.821 0 7.5 1.679 7.5 3.75 C 7.5 5.821 5.821 7.5 3.75 7.5 C 1.679 7.5 0 5.821 0 3.75 Z" fill="transparent" height="7.5px" id="Q3v7fjWhv" stroke-dasharray="" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(8.25 8.25)" width="7.5px"/><path d="M 0 1.125 C 0 0.504 0.504 0 1.125 0 C 1.746 0 2.25 0.504 2.25 1.125 C 2.25 1.746 1.746 2.25 1.125 2.25 C 0.504 2.25 0 1.746 0 1.125 Z" fill="var(--21h8s6, rgb(0, 0, 0))" height="2.25px" id="VxeO4Hprj" transform="translate(15.75 6)" width="2.25px"/></svg>';
var getProps3 = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps3(props);
  const href = useSVGTemplate3("942143898", svg3);
  return /* @__PURE__ */ _jsx4(SVG3, { ...restProps, className: cx3("framer-SHCqu", className3), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx4("use", { href }) });
});
var css3 = [`.framer-SHCqu { -webkit-mask: ${mask3}; aspect-ratio: 1; display: block; mask: ${mask3}; width: 24px; }`];
var Icon3 = withCSS3(Component3, css3, "framer-SHCqu");
Icon3.displayName = "Instagram Logo";
var UD0eTfbk_default = Icon3;
addPropertyControls4(Icon3, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType4.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType4.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType4.Number } });

// http-url:https://framerusercontent.com/modules/TM3jYvzHznZeXDkd40PU/3MLl39y9zQ2KANxUxFFF/Q3uK_jYjo.js
import { jsx as _jsx5 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls5, ControlType as ControlType5, cx as cx4, motion as motion4, useSVGTemplate as useSVGTemplate4, withCSS as withCSS4 } from "./_framer-runtime.js";
import * as React4 from "react";
import { forwardRef as forwardRef8 } from "react";
var mask4 = "var(--framer-icon-mask)";
var Base4 = /* @__PURE__ */ forwardRef8(function(props, ref) {
  return /* @__PURE__ */ _jsx5("svg", { ...props, ref, children: props.children });
});
var MotionSVG4 = motion4.create(Base4);
var SVG4 = /* @__PURE__ */ forwardRef8((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx5(MotionSVG4, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx5("svg", { ...rest, ref, children });
});
var svg4 = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 0 4 C 0 1.791 1.791 0 4 0 C 6.209 0 8 1.791 8 4 C 8 6.209 6.209 8 4 8 C 1.791 8 0 6.209 0 4 Z" fill="transparent" height="8px" id="HeyKAqsXu" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(8 8)" width="8px"/><path d="M 0 0 L 0 2" fill="transparent" height="2px" id="EkB6G7gQx" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(12 2)" width="1px"/><path d="M 0 0 L 0 2" fill="transparent" height="2px" id="XA2ZMp5hf" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(12 20)" width="1px"/><path d="M 0 0 L 1.41 1.41" fill="transparent" height="1.4100000000000001px" id="OGHZjPr2C" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(4.93 4.93)" width="1.4100000000000001px"/><path d="M 0 0 L 1.41 1.41" fill="transparent" height="1.4100000000000001px" id="smqBk2ylC" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(17.66 17.66)" width="1.4100000000000001px"/><path d="M 0 0 L 2 0" fill="transparent" height="1px" id="gdcug9c8J" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(2 12)" width="2px"/><path d="M 0 0 L 2 0" fill="transparent" height="1px" id="jU05EVjWx" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(20 12)" width="2px"/><path d="M 1.41 0 L 0 1.41" fill="transparent" height="1.4100000000000001px" id="s7MuiUNWZ" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(4.93 17.66)" width="1.4100000000000001px"/><path d="M 1.41 0 L 0 1.41" fill="transparent" height="1.4100000000000001px" id="HVrJrmRDB" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(17.66 4.93)" width="1.4100000000000001px"/></svg>';
var getProps4 = ({ color, height, id, width, width1, ...props }) => {
  return { ...props, JEeZYcamG: width1 ?? props.JEeZYcamG ?? 2, P_DcoRcrY: color ?? props.P_DcoRcrY ?? "rgb(0, 0, 0)" };
};
var Component4 = /* @__PURE__ */ React4.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, P_DcoRcrY, JEeZYcamG, ...restProps } = getProps4(props);
  const href = useSVGTemplate4("1466876926", svg4);
  return /* @__PURE__ */ _jsx5(SVG4, { ...restProps, className: cx4("framer-ALWa2", className3), layoutId, ref, role: "presentation", style: { "--1m973uw": P_DcoRcrY, "--js9iwy": JEeZYcamG, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx5("use", { href }) });
});
var css4 = [`.framer-ALWa2 { -webkit-mask: ${mask4}; aspect-ratio: 1; display: block; mask: ${mask4}; width: 24px; }`];
var Icon4 = withCSS4(Component4, css4, "framer-ALWa2");
Icon4.displayName = "Sun";
var Q3uK_jYjo_default = Icon4;
addPropertyControls5(Icon4, { P_DcoRcrY: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType5.Color }, JEeZYcamG: { defaultValue: 2, displayStepper: true, hidden: false, max: 16, min: 1, title: "Width", type: ControlType5.Number } });

// http-url:https://framerusercontent.com/modules/TNOWoCWEr5Q4rZJjW1Ys/7a6Npqy12wRch0Aakncs/X4yTai4nL.js
import { jsx as _jsx6 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls6, ControlType as ControlType6, cx as cx5, motion as motion5, useSVGTemplate as useSVGTemplate5, withCSS as withCSS5 } from "./_framer-runtime.js";
import * as React5 from "react";
import { forwardRef as forwardRef10 } from "react";
var mask5 = "var(--framer-icon-mask)";
var Base5 = /* @__PURE__ */ forwardRef10(function(props, ref) {
  return /* @__PURE__ */ _jsx6("svg", { ...props, ref, children: props.children });
});
var MotionSVG5 = motion5.create(Base5);
var SVG5 = /* @__PURE__ */ forwardRef10((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx6(MotionSVG5, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx6("svg", { ...rest, ref, children });
});
var svg5 = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 12.75 7.313 C 14.279 8.413 16.116 9.004 18 9 L 18 5.25 C 15.101 5.25 12.75 2.899 12.75 0 L 9 0 L 9 12.375 C 8.999 13.675 8.047 14.78 6.76 14.97 C 5.474 15.161 4.242 14.382 3.863 13.137 C 3.485 11.893 4.075 10.56 5.25 10.002 L 5.25 6 C 2.266 6.532 0 9.238 0 12.375 C 0 15.896 2.854 18.75 6.375 18.75 C 9.896 18.75 12.75 15.896 12.75 12.375 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="18.75px" id="XxjC59UQP" transform="translate(3 2.25)" width="18px"/><path d="M 12.75 7.313 C 14.279 8.413 16.116 9.004 18 9 L 18 5.25 C 15.101 5.25 12.75 2.899 12.75 0 L 9 0 L 9 12.375 C 8.999 13.675 8.047 14.78 6.76 14.97 C 5.474 15.161 4.242 14.382 3.863 13.137 C 3.485 11.893 4.075 10.56 5.25 10.002 L 5.25 6 C 2.266 6.532 0 9.238 0 12.375 C 0 15.896 2.854 18.75 6.375 18.75 C 9.896 18.75 12.75 15.896 12.75 12.375 Z" fill="transparent" height="18.75px" id="J5_aSIe85" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(3 2.25)" width="18px"/></svg>';
var getProps5 = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component5 = /* @__PURE__ */ React5.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps5(props);
  const href = useSVGTemplate5("4153440109", svg5);
  return /* @__PURE__ */ _jsx6(SVG5, { ...restProps, className: cx5("framer-wQsp6", className3), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx6("use", { href }) });
});
var css5 = [`.framer-wQsp6 { -webkit-mask: ${mask5}; aspect-ratio: 1; display: block; mask: ${mask5}; width: 24px; }`];
var Icon5 = withCSS5(Component5, css5, "framer-wQsp6");
Icon5.displayName = "Tiktok Logo";
var X4yTai4nL_default = Icon5;
addPropertyControls6(Icon5, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType6.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType6.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType6.Number } });

// http-url:https://framerusercontent.com/modules/XjaQPMlGjOErBcLbXGZ7/1TuLr0pKi0FWGlyKLgam/AfVKYR46L.js
import { jsx as _jsx7 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls7, ControlType as ControlType7, cx as cx6, motion as motion6, useSVGTemplate as useSVGTemplate6, withCSS as withCSS6 } from "./_framer-runtime.js";
import * as React6 from "react";
import { forwardRef as forwardRef12 } from "react";
var mask6 = "var(--framer-icon-mask)";
var Base6 = /* @__PURE__ */ forwardRef12(function(props, ref) {
  return /* @__PURE__ */ _jsx7("svg", { ...props, ref, children: props.children });
});
var MotionSVG6 = motion6.create(Base6);
var SVG6 = /* @__PURE__ */ forwardRef12((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx7(MotionSVG6, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx7("svg", { ...rest, ref, children });
});
var svg6 = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 17.987 9.473 C 17.726 14.31 13.682 18.073 8.839 17.986 C 3.995 17.899 0.089 13.994 0.001 9.15 C -0.086 4.306 3.676 0.262 8.514 0.001 C 8.919 -0.021 9.131 0.461 8.916 0.804 C 7.435 3.173 7.786 6.251 9.761 8.226 C 11.737 10.202 14.815 10.553 17.184 9.072 C 17.528 8.857 18.009 9.068 17.987 9.473" fill="transparent" height="17.987618062653137px" id="g2TOONQaY" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--js9iwy, 2)" stroke="var(--1m973uw, rgb(0,0,0))" transform="translate(2.998 3.013)" width="17.987671078370404px"/></svg>';
var getProps6 = ({ color, height, id, width, width1, ...props }) => {
  return { ...props, JEeZYcamG: width1 ?? props.JEeZYcamG ?? 2, P_DcoRcrY: color ?? props.P_DcoRcrY ?? "rgb(0, 0, 0)" };
};
var Component6 = /* @__PURE__ */ React6.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, P_DcoRcrY, JEeZYcamG, ...restProps } = getProps6(props);
  const href = useSVGTemplate6("2905251624", svg6);
  return /* @__PURE__ */ _jsx7(SVG6, { ...restProps, className: cx6("framer-XaHHS", className3), layoutId, ref, role: "presentation", style: { "--1m973uw": P_DcoRcrY, "--js9iwy": JEeZYcamG, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx7("use", { href }) });
});
var css6 = [`.framer-XaHHS { -webkit-mask: ${mask6}; aspect-ratio: 1; display: block; mask: ${mask6}; width: 24px; }`];
var Icon6 = withCSS6(Component6, css6, "framer-XaHHS");
Icon6.displayName = "Moon";
var AfVKYR46L_default = Icon6;
addPropertyControls7(Icon6, { P_DcoRcrY: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType7.Color }, JEeZYcamG: { defaultValue: 2, displayStepper: true, hidden: false, max: 16, min: 1, title: "Width", type: ControlType7.Number } });

// http-url:https://framerusercontent.com/modules/Fb3OBEea8P4xXujm1HeO/BjhymX2FyoNaBxrlwtFb/FLXAZe6Zt.js
import { jsx as _jsx8, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls8, ControlType as ControlType8, cx as cx7, getFontsFromSharedStyle, Link, RichText, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS7 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion7, MotionConfigContext } from "framer-motion";
import * as React7 from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/aFv8VtU03CH7WRIwHt44/HdxDausx6Xcp5ZNXQWnz/gpegvGr5w.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts([]);
var fonts = [{ explicitInter: true, fonts: [] }];
var css7 = [".framer-6yQPI .framer-styles-preset-oti8pm:not(.rich-text-wrapper), .framer-6yQPI .framer-styles-preset-oti8pm.rich-text-wrapper a { transition-delay: 0s; transition-duration: 0.6s; transition-property: color; transition-timing-function: cubic-bezier(0.22, 1, 0.36, 1); }"];
var className = "framer-6yQPI";

// http-url:https://framerusercontent.com/modules/6zTUOXrVkFrxW3OsZKJc/Dd2fUKlIWo1Bj8jrAsKT/REA4tN9dV.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts([]);
var fonts2 = [{ explicitInter: true, fonts: [] }];
var css8 = [".framer-TrQ4e .framer-styles-preset-184kxn2:not(.rich-text-wrapper), .framer-TrQ4e .framer-styles-preset-184kxn2.rich-text-wrapper a { transition-delay: 0s; transition-duration: 0.6s; transition-property: color; transition-timing-function: cubic-bezier(0.22, 1, 0.36, 1); }"];
var className2 = "framer-TrQ4e";

// http-url:https://framerusercontent.com/modules/Fb3OBEea8P4xXujm1HeO/BjhymX2FyoNaBxrlwtFb/FLXAZe6Zt.js
var enabledGestures = { DHKyVjflU: { hover: true }, QHhetCOgb: { hover: true } };
var cycleOrder = ["DHKyVjflU", "QHhetCOgb"];
var serializationHash = "framer-KbbB8";
var variantClassNames = { DHKyVjflU: "framer-v-1xm5ris", QHhetCOgb: "framer-v-1ogtdl7" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { delay: 0, duration: 0.6, ease: [0.22, 1, 0.36, 1], type: "tween" };
var Transition = ({ value, children }) => {
  const config = React7.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React7.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx8(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Dark: "QHhetCOgb", Light: "DHKyVjflU" };
var Variants = motion7.create(React7.Fragment);
var getProps7 = ({ height, id, label, link, newTab, width, ...props }) => {
  return { ...props, A8naXXN6A: newTab ?? props.A8naXXN6A ?? true, rNnb4XUou: label ?? props.rNnb4XUou ?? "Products", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "DHKyVjflU", VYcl1xKnX: link ?? props.VYcl1xKnX };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component7 = /* @__PURE__ */ React7.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React7.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className3, layoutId, variant, rNnb4XUou, A8naXXN6A, VYcl1xKnX, ...restProps } = getProps7(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "DHKyVjflU", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [className2, className];
  const scopingClassNames = cx7(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx8(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx8(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx8(Transition, { value: transition1, children: /* @__PURE__ */ _jsx8(motion7.div, { ...restProps, ...gestureHandlers, className: cx7(scopingClassNames, "framer-1xm5ris", className3, classNames), "data-framer-name": "Light", layoutDependency, layoutId: "E5HHCtcw__DHKyVjflU", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ "DHKyVjflU-hover": { "data-framer-name": void 0 }, "QHhetCOgb-hover": { "data-framer-name": void 0 }, QHhetCOgb: { "data-framer-name": "Dark" } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx8(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion7.div, { className: "framer-18gr0as", "data-framer-name": "Text Wrapper", layoutDependency, layoutId: "E5HHCtcw__UNwFyoM9B", children: [/* @__PURE__ */ _jsx8(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx8(React7.Fragment, { children: /* @__PURE__ */ _jsx8(motion7.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "20px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.01em", "--framer-line-height": "1.3em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(10, 10, 10))" }, children: /* @__PURE__ */ _jsx8(Link, { href: VYcl1xKnX, motionChild: true, nodeId: "pa0Zy1PZi", openInNewTab: A8naXXN6A, relValues: [], scopeId: "FLXAZe6Zt", smoothScroll: false, children: /* @__PURE__ */ _jsx8(motion7.a, { className: "framer-styles-preset-184kxn2", "data-styles-preset": "REA4tN9dV", children: "Products" }) }) }) }), className: "framer-jpkf6d", "data-framer-name": "Menu Link 1", fonts: ["Inter-Medium"], layoutDependency, layoutId: "E5HHCtcw__pa0Zy1PZi", style: { "--extracted-r6o4lv": "rgb(10, 10, 10)", "--variable-reference-A8naXXN6A-FLXAZe6Zt": A8naXXN6A }, text: rNnb4XUou, variants: { "DHKyVjflU-hover": { "--extracted-r6o4lv": "rgb(232, 93, 38)" }, "QHhetCOgb-hover": { "--extracted-r6o4lv": "rgb(235, 118, 70)" }, QHhetCOgb: { "--extracted-r6o4lv": "rgb(247, 246, 243)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ "DHKyVjflU-hover": { children: /* @__PURE__ */ _jsx8(React7.Fragment, { children: /* @__PURE__ */ _jsx8(motion7.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "20px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.01em", "--framer-line-height": "1.3em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(232, 93, 38))" }, children: /* @__PURE__ */ _jsx8(Link, { href: VYcl1xKnX, motionChild: true, nodeId: "pa0Zy1PZi", openInNewTab: A8naXXN6A, relValues: [], scopeId: "FLXAZe6Zt", smoothScroll: false, children: /* @__PURE__ */ _jsx8(motion7.a, { className: "framer-styles-preset-184kxn2", "data-styles-preset": "REA4tN9dV", children: "Products" }) }) }) }) }, "QHhetCOgb-hover": { children: /* @__PURE__ */ _jsx8(React7.Fragment, { children: /* @__PURE__ */ _jsx8(motion7.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "20px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.01em", "--framer-line-height": "1.3em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(235, 118, 70))" }, children: /* @__PURE__ */ _jsx8(Link, { href: VYcl1xKnX, motionChild: true, nodeId: "pa0Zy1PZi", openInNewTab: A8naXXN6A, relValues: [], scopeId: "FLXAZe6Zt", smoothScroll: false, children: /* @__PURE__ */ _jsx8(motion7.a, { className: "framer-styles-preset-oti8pm", "data-styles-preset": "gpegvGr5w", children: "Products" }) }) }) }) }, QHhetCOgb: { children: /* @__PURE__ */ _jsx8(React7.Fragment, { children: /* @__PURE__ */ _jsx8(motion7.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "20px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.01em", "--framer-line-height": "1.3em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(247, 246, 243))" }, children: /* @__PURE__ */ _jsx8(Link, { href: VYcl1xKnX, motionChild: true, nodeId: "pa0Zy1PZi", openInNewTab: A8naXXN6A, relValues: [], scopeId: "FLXAZe6Zt", smoothScroll: false, children: /* @__PURE__ */ _jsx8(motion7.a, { className: "framer-styles-preset-oti8pm", "data-styles-preset": "gpegvGr5w", children: "Products" }) }) }) }) } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx8(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx8(React7.Fragment, { children: /* @__PURE__ */ _jsx8(motion7.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "20px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.01em", "--framer-line-height": "1.3em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(10, 10, 10))" }, children: /* @__PURE__ */ _jsx8(Link, { href: VYcl1xKnX, motionChild: true, nodeId: "FV17OZbNr", openInNewTab: true, relValues: [], scopeId: "FLXAZe6Zt", smoothScroll: false, children: /* @__PURE__ */ _jsx8(motion7.a, { className: "framer-styles-preset-184kxn2", "data-styles-preset": "REA4tN9dV", children: "Products" }) }) }) }), className: "framer-f7dyew", "data-framer-name": "Menu Link 1", fonts: ["Inter-Medium"], layoutDependency, layoutId: "E5HHCtcw__FV17OZbNr", style: { "--extracted-r6o4lv": "rgb(10, 10, 10)" }, text: rNnb4XUou, variants: { "DHKyVjflU-hover": { "--extracted-r6o4lv": "rgb(232, 93, 38)" }, "QHhetCOgb-hover": { "--extracted-r6o4lv": "rgb(235, 118, 70)" }, QHhetCOgb: { "--extracted-r6o4lv": "rgb(247, 246, 243)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ "DHKyVjflU-hover": { children: /* @__PURE__ */ _jsx8(React7.Fragment, { children: /* @__PURE__ */ _jsx8(motion7.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "20px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.01em", "--framer-line-height": "1.3em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(232, 93, 38))" }, children: /* @__PURE__ */ _jsx8(Link, { href: VYcl1xKnX, motionChild: true, nodeId: "FV17OZbNr", openInNewTab: true, relValues: [], scopeId: "FLXAZe6Zt", smoothScroll: false, children: /* @__PURE__ */ _jsx8(motion7.a, { className: "framer-styles-preset-184kxn2", "data-styles-preset": "REA4tN9dV", children: "Products" }) }) }) }) }, "QHhetCOgb-hover": { children: /* @__PURE__ */ _jsx8(React7.Fragment, { children: /* @__PURE__ */ _jsx8(motion7.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "20px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.01em", "--framer-line-height": "1.3em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(235, 118, 70))" }, children: /* @__PURE__ */ _jsx8(Link, { href: VYcl1xKnX, motionChild: true, nodeId: "FV17OZbNr", openInNewTab: true, relValues: [], scopeId: "FLXAZe6Zt", smoothScroll: false, children: /* @__PURE__ */ _jsx8(motion7.a, { className: "framer-styles-preset-oti8pm", "data-styles-preset": "gpegvGr5w", children: "Products" }) }) }) }) }, QHhetCOgb: { children: /* @__PURE__ */ _jsx8(React7.Fragment, { children: /* @__PURE__ */ _jsx8(motion7.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "20px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.01em", "--framer-line-height": "1.3em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(247, 246, 243))" }, children: /* @__PURE__ */ _jsx8(Link, { href: VYcl1xKnX, motionChild: true, nodeId: "FV17OZbNr", openInNewTab: true, relValues: [], scopeId: "FLXAZe6Zt", smoothScroll: false, children: /* @__PURE__ */ _jsx8(motion7.a, { className: "framer-styles-preset-oti8pm", "data-styles-preset": "gpegvGr5w", children: "Products" }) }) }) }) } }, baseVariant, gestureVariant) })] }) }) }) }) }) });
});
var css9 = [".framer-KbbB8.framer-1bvtzxf, .framer-KbbB8 .framer-1bvtzxf { display: block; }", ".framer-KbbB8.framer-1xm5ris { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 14px; height: min-content; justify-content: flex-start; padding: 5px 0px 5px 0px; position: relative; width: 100%; }", ".framer-KbbB8 .framer-18gr0as { align-content: flex-start; align-items: flex-start; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 4px; height: 26px; justify-content: flex-start; overflow: hidden; padding: 0px; position: relative; width: 1px; }", ".framer-KbbB8 .framer-jpkf6d, .framer-KbbB8 .framer-f7dyew { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-KbbB8.framer-v-1xm5ris.hover .framer-18gr0as, .framer-KbbB8.framer-v-1ogtdl7.hover .framer-18gr0as { justify-content: flex-end; }", ...css8, ...css7];
var FramerFLXAZe6Zt = withCSS7(Component7, css9, "framer-KbbB8");
var FLXAZe6Zt_default = FramerFLXAZe6Zt;
FramerFLXAZe6Zt.displayName = "Menu Link";
FramerFLXAZe6Zt.defaultProps = { height: 36, width: 182 };
addPropertyControls8(FramerFLXAZe6Zt, { variant: { options: ["DHKyVjflU", "QHhetCOgb"], optionTitles: ["Light", "Dark"], title: "Variant", type: ControlType8.Enum }, rNnb4XUou: { defaultValue: "Products", title: "Label", type: ControlType8.String }, onrNnb4XUouChange: { changes: "rNnb4XUou", type: ControlType8.ChangeHandler }, A8naXXN6A: { defaultValue: true, title: "New Tab", type: ControlType8.Boolean }, onA8naXXN6AChange: { changes: "A8naXXN6A", type: ControlType8.ChangeHandler }, VYcl1xKnX: { description: "Built by Matthias \xD6lschlegel \u{1F4AA}\n[Explore more components](https://framer.link/fsd2pgh)", title: "Link", type: ControlType8.Link } });
addFonts(FramerFLXAZe6Zt, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5A3Ce6C9YYmCjpQx9M4inSaKU.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/Qx95Xyt0Ka3SGhinnbXIGpEIyP4.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/6mJuEAguuIuMog10gGvH5d3cl8.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/xYYWaj7wCU5zSQH0eXvSaS19wo.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/otTaNuNpVK4RbdlT7zDDdKvQBA.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/UjlFhCnUjxhNfep4oYBPqnEssyo.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/DolVirEGb34pEXEp8t8FQBSK4.woff2", weight: "500" }] }, ...getFontsFromSharedStyle(fonts2), ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/F4ncU6UfEiK28xSUdsuz/t8UVze4MMlPe8IEHTKly/uh0o6Kp1Z.js
import { jsx as _jsx9, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls9, ControlType as ControlType9, cx as cx8, getFontsFromSharedStyle as getFontsFromSharedStyle2, Link as Link2, RichText as RichText2, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS8 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion8, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React8 from "react";
import { useRef as useRef3 } from "react";
var enabledGestures2 = { c6BKNoDaP: { hover: true }, njslONOSS: { hover: true } };
var cycleOrder2 = ["njslONOSS", "c6BKNoDaP"];
var serializationHash2 = "framer-HEgHZ";
var variantClassNames2 = { c6BKNoDaP: "framer-v-1ys3dxw", njslONOSS: "framer-v-12k7wth" };
function addPropertyOverrides2(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition12 = { delay: 0, duration: 0.6, ease: [0.22, 1, 0.36, 1], type: "tween" };
var Transition2 = ({ value, children }) => {
  const config = React8.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React8.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx9(MotionConfigContext2.Provider, { value: contextValue, children });
};
var humanReadableVariantMap2 = { Dark: "c6BKNoDaP", Light: "njslONOSS" };
var Variants2 = motion8.create(React8.Fragment);
var getProps8 = ({ height, id, label, link, newTab, width, ...props }) => {
  return { ...props, cE66sCxlN: label ?? props.cE66sCxlN ?? "Privacy Policy", RP7QAUtbs: link ?? props.RP7QAUtbs, twPOE0L8l: newTab ?? props.twPOE0L8l ?? true, variant: humanReadableVariantMap2[props.variant] ?? props.variant ?? "njslONOSS" };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component8 = /* @__PURE__ */ React8.forwardRef(function(props, ref) {
  const fallbackRef = useRef3(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React8.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className: className3, layoutId, variant, cE66sCxlN, twPOE0L8l, RP7QAUtbs, ...restProps } = getProps8(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder: cycleOrder2, defaultVariant: "njslONOSS", enabledGestures: enabledGestures2, ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const sharedStyleClassNames = [className2, className];
  const scopingClassNames = cx8(serializationHash2, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx9(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx9(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx9(Transition2, { value: transition12, children: /* @__PURE__ */ _jsx9(motion8.div, { ...restProps, ...gestureHandlers, className: cx8(scopingClassNames, "framer-12k7wth", className3, classNames), "data-framer-name": "Light", layoutDependency, layoutId: "E5HHCtcw__njslONOSS", ref: refBinding, style: { ...style }, ...addPropertyOverrides2({ "c6BKNoDaP-hover": { "data-framer-name": void 0 }, "njslONOSS-hover": { "data-framer-name": void 0 }, c6BKNoDaP: { "data-framer-name": "Dark" } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx9(Transition2, { value: transition12, children: /* @__PURE__ */ _jsxs2(motion8.div, { className: "framer-130ifkq", "data-framer-name": "Text Wrapper", layoutDependency, layoutId: "E5HHCtcw__SGNR4Pn0d", children: [/* @__PURE__ */ _jsx9(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx9(React8.Fragment, { children: /* @__PURE__ */ _jsx9(motion8.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "14px", "--framer-font-weight": "500", "--framer-line-height": "1.4em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(10, 10, 10))" }, children: /* @__PURE__ */ _jsx9(Link2, { href: RP7QAUtbs, motionChild: true, nodeId: "CzroGFmf1", openInNewTab: twPOE0L8l, relValues: [], scopeId: "uh0o6Kp1Z", smoothScroll: false, children: /* @__PURE__ */ _jsx9(motion8.a, { className: "framer-styles-preset-184kxn2", "data-styles-preset": "REA4tN9dV", children: "Privacy Policy" }) }) }) }), className: "framer-17iu6y3", "data-framer-name": "Label", fonts: ["Inter-Medium"], layoutDependency, layoutId: "E5HHCtcw__CzroGFmf1", style: { "--extracted-r6o4lv": "rgb(10, 10, 10)", "--variable-reference-twPOE0L8l-uh0o6Kp1Z": twPOE0L8l }, text: cE66sCxlN, variants: { "c6BKNoDaP-hover": { "--extracted-r6o4lv": "rgb(235, 118, 70)" }, "njslONOSS-hover": { "--extracted-r6o4lv": "rgb(232, 93, 38)" }, c6BKNoDaP: { "--extracted-r6o4lv": "rgb(247, 246, 243)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides2({ "c6BKNoDaP-hover": { children: /* @__PURE__ */ _jsx9(React8.Fragment, { children: /* @__PURE__ */ _jsx9(motion8.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "14px", "--framer-font-weight": "500", "--framer-line-height": "1.4em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(235, 118, 70))" }, children: /* @__PURE__ */ _jsx9(Link2, { href: RP7QAUtbs, motionChild: true, nodeId: "CzroGFmf1", openInNewTab: twPOE0L8l, relValues: [], scopeId: "uh0o6Kp1Z", smoothScroll: false, children: /* @__PURE__ */ _jsx9(motion8.a, { className: "framer-styles-preset-oti8pm", "data-styles-preset": "gpegvGr5w", children: "Privacy Policy" }) }) }) }) }, "njslONOSS-hover": { children: /* @__PURE__ */ _jsx9(React8.Fragment, { children: /* @__PURE__ */ _jsx9(motion8.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "14px", "--framer-font-weight": "500", "--framer-line-height": "1.4em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(232, 93, 38))" }, children: /* @__PURE__ */ _jsx9(Link2, { href: RP7QAUtbs, motionChild: true, nodeId: "CzroGFmf1", openInNewTab: twPOE0L8l, relValues: [], scopeId: "uh0o6Kp1Z", smoothScroll: false, children: /* @__PURE__ */ _jsx9(motion8.a, { className: "framer-styles-preset-184kxn2", "data-styles-preset": "REA4tN9dV", children: "Privacy Policy" }) }) }) }) }, c6BKNoDaP: { children: /* @__PURE__ */ _jsx9(React8.Fragment, { children: /* @__PURE__ */ _jsx9(motion8.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "14px", "--framer-font-weight": "500", "--framer-line-height": "1.4em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(247, 246, 243))" }, children: /* @__PURE__ */ _jsx9(Link2, { href: RP7QAUtbs, motionChild: true, nodeId: "CzroGFmf1", openInNewTab: twPOE0L8l, relValues: [], scopeId: "uh0o6Kp1Z", smoothScroll: false, children: /* @__PURE__ */ _jsx9(motion8.a, { className: "framer-styles-preset-oti8pm", "data-styles-preset": "gpegvGr5w", children: "Privacy Policy" }) }) }) }) } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx9(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx9(React8.Fragment, { children: /* @__PURE__ */ _jsx9(motion8.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "14px", "--framer-font-weight": "500", "--framer-line-height": "1.4em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(10, 10, 10))" }, children: /* @__PURE__ */ _jsx9(Link2, { href: RP7QAUtbs, motionChild: true, nodeId: "Bdk_bOyzL", openInNewTab: true, relValues: [], scopeId: "uh0o6Kp1Z", smoothScroll: false, children: /* @__PURE__ */ _jsx9(motion8.a, { className: "framer-styles-preset-184kxn2", "data-styles-preset": "REA4tN9dV", children: "Privacy Policy" }) }) }) }), className: "framer-125hhr0", "data-framer-name": "Label", fonts: ["Inter-Medium"], layoutDependency, layoutId: "E5HHCtcw__Bdk_bOyzL", style: { "--extracted-r6o4lv": "rgb(10, 10, 10)" }, text: cE66sCxlN, variants: { "c6BKNoDaP-hover": { "--extracted-r6o4lv": "rgb(235, 118, 70)" }, "njslONOSS-hover": { "--extracted-r6o4lv": "rgb(232, 93, 38)" }, c6BKNoDaP: { "--extracted-r6o4lv": "rgb(247, 246, 243)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides2({ "c6BKNoDaP-hover": { children: /* @__PURE__ */ _jsx9(React8.Fragment, { children: /* @__PURE__ */ _jsx9(motion8.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "14px", "--framer-font-weight": "500", "--framer-line-height": "1.4em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(235, 118, 70))" }, children: /* @__PURE__ */ _jsx9(Link2, { href: RP7QAUtbs, motionChild: true, nodeId: "Bdk_bOyzL", openInNewTab: true, relValues: [], scopeId: "uh0o6Kp1Z", smoothScroll: false, children: /* @__PURE__ */ _jsx9(motion8.a, { className: "framer-styles-preset-oti8pm", "data-styles-preset": "gpegvGr5w", children: "Privacy Policy" }) }) }) }) }, "njslONOSS-hover": { children: /* @__PURE__ */ _jsx9(React8.Fragment, { children: /* @__PURE__ */ _jsx9(motion8.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "14px", "--framer-font-weight": "500", "--framer-line-height": "1.4em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(232, 93, 38))" }, children: /* @__PURE__ */ _jsx9(Link2, { href: RP7QAUtbs, motionChild: true, nodeId: "Bdk_bOyzL", openInNewTab: true, relValues: [], scopeId: "uh0o6Kp1Z", smoothScroll: false, children: /* @__PURE__ */ _jsx9(motion8.a, { className: "framer-styles-preset-184kxn2", "data-styles-preset": "REA4tN9dV", children: "Privacy Policy" }) }) }) }) }, c6BKNoDaP: { children: /* @__PURE__ */ _jsx9(React8.Fragment, { children: /* @__PURE__ */ _jsx9(motion8.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "14px", "--framer-font-weight": "500", "--framer-line-height": "1.4em", "--framer-text-color": "var(--extracted-r6o4lv, rgb(247, 246, 243))" }, children: /* @__PURE__ */ _jsx9(Link2, { href: RP7QAUtbs, motionChild: true, nodeId: "Bdk_bOyzL", openInNewTab: true, relValues: [], scopeId: "uh0o6Kp1Z", smoothScroll: false, children: /* @__PURE__ */ _jsx9(motion8.a, { className: "framer-styles-preset-oti8pm", "data-styles-preset": "gpegvGr5w", children: "Privacy Policy" }) }) }) }) } }, baseVariant, gestureVariant) })] }) }) }) }) }) });
});
var css10 = [".framer-HEgHZ.framer-144hmen, .framer-HEgHZ .framer-144hmen { display: block; }", ".framer-HEgHZ.framer-12k7wth { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; padding: 5px 0px 5px 0px; position: relative; width: 100%; }", ".framer-HEgHZ .framer-130ifkq { align-content: flex-start; align-items: flex-start; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 4px; height: 20px; justify-content: flex-start; overflow: hidden; padding: 0px; position: relative; width: 1px; }", ".framer-HEgHZ .framer-17iu6y3, .framer-HEgHZ .framer-125hhr0 { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-HEgHZ.framer-v-12k7wth.hover .framer-130ifkq, .framer-HEgHZ.framer-v-1ys3dxw.hover .framer-130ifkq { justify-content: flex-end; }", ...css8, ...css7];
var Frameruh0o6Kp1Z = withCSS8(Component8, css10, "framer-HEgHZ");
var uh0o6Kp1Z_default = Frameruh0o6Kp1Z;
Frameruh0o6Kp1Z.displayName = "Legal Link";
Frameruh0o6Kp1Z.defaultProps = { height: 30, width: 182 };
addPropertyControls9(Frameruh0o6Kp1Z, { variant: { options: ["njslONOSS", "c6BKNoDaP"], optionTitles: ["Light", "Dark"], title: "Variant", type: ControlType9.Enum }, cE66sCxlN: { defaultValue: "Privacy Policy", title: "Label", type: ControlType9.String }, oncE66sCxlNChange: { changes: "cE66sCxlN", type: ControlType9.ChangeHandler }, twPOE0L8l: { defaultValue: true, title: "New Tab", type: ControlType9.Boolean }, ontwPOE0L8lChange: { changes: "twPOE0L8l", type: ControlType9.ChangeHandler }, RP7QAUtbs: { description: "Built by Matthias \xD6lschlegel \u{1F4AA}\n[Explore more components](https://framer.link/fsd2pgh)", title: "Link", type: ControlType9.Link } });
addFonts2(Frameruh0o6Kp1Z, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5A3Ce6C9YYmCjpQx9M4inSaKU.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/Qx95Xyt0Ka3SGhinnbXIGpEIyP4.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/6mJuEAguuIuMog10gGvH5d3cl8.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/xYYWaj7wCU5zSQH0eXvSaS19wo.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/otTaNuNpVK4RbdlT7zDDdKvQBA.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/UjlFhCnUjxhNfep4oYBPqnEssyo.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/DolVirEGb34pEXEp8t8FQBSK4.woff2", weight: "500" }] }, ...getFontsFromSharedStyle2(fonts2), ...getFontsFromSharedStyle2(fonts)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/BLEVJe6HpKOZ7WLTb7oO/HY4wSZOcPO2SKw2483xb/Zy4YYAluy.js
import { jsx as _jsx10, jsxs as _jsxs3 } from "react/jsx-runtime";
import { addFonts as addFonts3, addPropertyControls as addPropertyControls10, ControlType as ControlType10, cx as cx9, Instance, Link as Link3, useComponentViewport as useComponentViewport3, useLocaleInfo as useLocaleInfo3, useVariantState as useVariantState3, withCSS as withCSS9 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup3, motion as motion9, MotionConfigContext as MotionConfigContext3 } from "framer-motion";
import * as React9 from "react";
import { useRef as useRef4 } from "react";
var enabledGestures3 = { aWkAzH2Gx: { hover: true }, JzqYnpJB1: { hover: true } };
var cycleOrder3 = ["JzqYnpJB1", "aWkAzH2Gx"];
var serializationHash3 = "framer-hfecN";
var variantClassNames3 = { aWkAzH2Gx: "framer-v-svc543", JzqYnpJB1: "framer-v-1m1ai0b" };
function addPropertyOverrides3(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition13 = { delay: 0, duration: 0.6, ease: [0.22, 1, 0.36, 1], type: "tween" };
var Transition3 = ({ value, children }) => {
  const config = React9.useContext(MotionConfigContext3);
  const transition = value ?? config.transition;
  const contextValue = React9.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx10(MotionConfigContext3.Provider, { value: contextValue, children });
};
var humanReadableVariantMap3 = { Dark: "aWkAzH2Gx", Light: "JzqYnpJB1" };
var Variants3 = motion9.create(React9.Fragment);
var getProps9 = ({ height, icon, id, link, newTab, width, ...props }) => {
  return { ...props, u00_W2pPu: link ?? props.u00_W2pPu, variant: humanReadableVariantMap3[props.variant] ?? props.variant ?? "JzqYnpJB1", wb9ifXOeQ: icon ?? props.wb9ifXOeQ ?? UD0eTfbk_default, x1D8kuFgO: newTab ?? props.x1D8kuFgO ?? true };
};
var createLayoutDependency3 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component9 = /* @__PURE__ */ React9.forwardRef(function(props, ref) {
  const fallbackRef = useRef4(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React9.useId();
  const { activeLocale, setLocale } = useLocaleInfo3();
  const componentViewport = useComponentViewport3();
  const { style, className: className3, layoutId, variant, u00_W2pPu, x1D8kuFgO, wb9ifXOeQ, ...restProps } = getProps9(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState3({ cycleOrder: cycleOrder3, defaultVariant: "JzqYnpJB1", enabledGestures: enabledGestures3, ref: refBinding, variant, variantClassNames: variantClassNames3 });
  const layoutDependency = createLayoutDependency3(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx9(serializationHash3, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx10(LayoutGroup3, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx10(Variants3, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx10(Transition3, { value: transition13, children: /* @__PURE__ */ _jsx10(Link3, { href: u00_W2pPu, motionChild: true, nodeId: "JzqYnpJB1", openInNewTab: x1D8kuFgO, scopeId: "Zy4YYAluy", children: /* @__PURE__ */ _jsx10(motion9.a, { ...restProps, ...gestureHandlers, className: `${cx9(scopingClassNames, "framer-1m1ai0b", className3, classNames)} framer-feomib`, "data-framer-name": "Light", layoutDependency, layoutId: "E5HHCtcw__JzqYnpJB1", ref: refBinding, style: { ...style }, ...addPropertyOverrides3({ "aWkAzH2Gx-hover": { "data-framer-name": void 0 }, "JzqYnpJB1-hover": { "data-framer-name": void 0 }, aWkAzH2Gx: { "data-framer-name": "Dark" } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx10(Transition3, { value: transition13, children: /* @__PURE__ */ _jsxs3(motion9.div, { className: "framer-1q4i2tn", "data-framer-name": "Icon Wrapper", layoutDependency, layoutId: "E5HHCtcw__sZ7BmHR_B", children: [/* @__PURE__ */ _jsx10(Instance, { animated: true, className: "framer-ivdol3", Component: wb9ifXOeQ, layoutDependency, layoutId: "E5HHCtcw__q79zaARfr", style: { "--1m6trwb": 0, "--21h8s6": "rgb(10, 10, 10)", "--pgex8v": 1.7 }, variants: { "aWkAzH2Gx-hover": { "--21h8s6": "rgb(235, 118, 70)" }, "JzqYnpJB1-hover": { "--21h8s6": "rgb(232, 93, 38)" }, aWkAzH2Gx: { "--21h8s6": "rgb(247, 246, 243)" } } }), /* @__PURE__ */ _jsx10(Instance, { animated: true, className: "framer-1yp8h6s", Component: wb9ifXOeQ, layoutDependency, layoutId: "E5HHCtcw__Xjv78jzcs", style: { "--1m6trwb": 0, "--21h8s6": "rgb(10, 10, 10)", "--pgex8v": 1.7 }, variants: { "aWkAzH2Gx-hover": { "--21h8s6": "rgb(235, 118, 70)" }, "JzqYnpJB1-hover": { "--21h8s6": "rgb(232, 93, 38)" }, aWkAzH2Gx: { "--21h8s6": "rgb(247, 246, 243)" } } })] }) }) }) }) }) }) });
});
var css11 = [".framer-hfecN.framer-feomib, .framer-hfecN .framer-feomib { display: block; }", ".framer-hfecN.framer-1m1ai0b { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; padding: 5px 5px 5px 0px; position: relative; text-decoration: none; width: min-content; }", ".framer-hfecN .framer-1q4i2tn { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 8px; height: 17px; justify-content: flex-start; overflow: hidden; padding: 0px; position: relative; width: 16px; }", ".framer-hfecN .framer-ivdol3, .framer-hfecN .framer-1yp8h6s { aspect-ratio: 1 / 1; flex: none; height: auto; position: relative; width: 16px; }", ".framer-hfecN.framer-v-1m1ai0b.hover .framer-1q4i2tn, .framer-hfecN.framer-v-svc543.hover .framer-1q4i2tn { justify-content: flex-end; }"];
var FramerZy4YYAluy = withCSS9(Component9, css11, "framer-hfecN");
var Zy4YYAluy_default = FramerZy4YYAluy;
FramerZy4YYAluy.displayName = "Social Media Icon";
FramerZy4YYAluy.defaultProps = { height: 26, width: 21 };
addPropertyControls10(FramerZy4YYAluy, { variant: { options: ["JzqYnpJB1", "aWkAzH2Gx"], optionTitles: ["Light", "Dark"], title: "Variant", type: ControlType10.Enum }, u00_W2pPu: { title: "Link", type: ControlType10.Link }, x1D8kuFgO: { defaultValue: true, title: "New Tab", type: ControlType10.Boolean }, onx1D8kuFgOChange: { changes: "x1D8kuFgO", type: ControlType10.ChangeHandler }, wb9ifXOeQ: { defaultValue: { identifier: "module:PtxaBiSAA5V6LvrpAt6G/EsR1AqByikNQR8Cp2V8c/UD0eTfbk_.js:default", moduleId: "PtxaBiSAA5V6LvrpAt6G" }, description: "Built by Matthias \xD6lschlegel \u{1F4AA}\n[Explore more components](https://framer.link/fsd2pgh)", setModuleId: "omX0gWFPqDwhaiWwf6ab", title: "Icon", type: ControlType10.VectorSetItem } });
addFonts3(FramerZy4YYAluy, [{ explicitInter: true, fonts: [] }], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/XnYmjybQDgwQoLHZeZpZ/MujioEUIxxs2G0s0fdLd/E5HHCt_cw.js
var SunFonts = getFonts(Q3uK_jYjo_default);
var MoonFonts = getFonts(AfVKYR46L_default);
var TimeDateFonts = getFonts(Time);
var MenuLinkFonts = getFonts(FLXAZe6Zt_default);
var LegalLinkFonts = getFonts(uh0o6Kp1Z_default);
var SocialMediaIconFonts = getFonts(Zy4YYAluy_default);
var cycleOrder4 = ["qsjQryIWb", "D09eACQPD", "SnTTeaPpc", "jTeytEfUG"];
var serializationHash4 = "framer-e7DTD";
var variantClassNames4 = { D09eACQPD: "framer-v-7bqof3", jTeytEfUG: "framer-v-zzne2w", qsjQryIWb: "framer-v-1a06n1x", SnTTeaPpc: "framer-v-szsu6u" };
function addPropertyOverrides4(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var patchBorderRadiusScaleCorrector1 = patchBorderRadiusScaleCorrector();
var transition14 = { delay: 0, duration: 0.6, ease: [0.22, 1, 0.36, 1], type: "tween" };
var animation = { filter: "blur(6px)", opacity: 1e-3, rotate: 0, scale: 0.98, skewX: 0, skewY: 0, x: 0, y: 10 };
var transition2 = { delay: 0.05, duration: 0.5, ease: [0.22, 0.61, 0.36, 1], type: "tween" };
var textEffect = { effect: animation, repeat: true, startDelay: 0, tokenization: "character", transition: transition2, trigger: "onMount", type: "appear" };
var transition3 = { delay: 0, duration: 0.5, ease: [0.44, 0, 0.56, 1], type: "tween" };
var animation1 = { backgroundColor: "rgba(255, 255, 255, 0.1)", opacity: 1, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, transition: transition3 };
var transition4 = { delay: 0, duration: 0.5, ease: [0.22, 1, 0.36, 1], type: "tween" };
var animation2 = { backgroundColor: "rgba(0, 0, 0, 0.08)", opacity: 1, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, transition: transition3 };
var Transition4 = ({ value, children }) => {
  const config = React10.useContext(MotionConfigContext4);
  const transition = value ?? config.transition;
  const contextValue = React10.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx11(MotionConfigContext4.Provider, { value: contextValue, children });
};
var matchVariant = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var humanReadableVariantMap4 = { "Dark Closed": "SnTTeaPpc", "Dark Open": "jTeytEfUG", "Light Closed": "qsjQryIWb", "Light Open": "D09eACQPD" };
var Variants4 = motion10.create(React10.Fragment);
var getProps10 = ({ height, id, showClock, width, ...props }) => {
  return { ...props, Jl7JpkUR3: showClock ?? props.Jl7JpkUR3 ?? true, variant: humanReadableVariantMap4[props.variant] ?? props.variant ?? "qsjQryIWb" };
};
var createLayoutDependency4 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component10 = /* @__PURE__ */ React10.forwardRef(function(props, ref) {
  const fallbackRef = useRef5(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React10.useId();
  const { activeLocale, setLocale } = useLocaleInfo4();
  const componentViewport = useComponentViewport4();
  const { style, className: className3, layoutId, variant, Jl7JpkUR3, ...restProps } = getProps10(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState4({ cycleOrder: cycleOrder4, defaultVariant: "qsjQryIWb", ref: refBinding, variant, variantClassNames: variantClassNames4 });
  const layoutDependency = createLayoutDependency4(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTapq7xj56 = activeVariantCallback(async (...args) => {
    setVariant("D09eACQPD");
  });
  const onTap1sjrj5o = activeVariantCallback(async (...args) => {
    setVariant("qsjQryIWb");
  });
  const onTap19uukfy = activeVariantCallback(async (...args) => {
    setVariant("jTeytEfUG");
  });
  const onTapo20en = activeVariantCallback(async (...args) => {
    setVariant("SnTTeaPpc");
  });
  const sharedStyleClassNames = [];
  const scopingClassNames = cx10(serializationHash4, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (["D09eACQPD", "jTeytEfUG"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed1 = () => {
    if (["D09eACQPD", "jTeytEfUG"].includes(baseVariant))
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx11(LayoutGroup4, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx11(Variants4, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx11(Transition4, { value: transition14, children: /* @__PURE__ */ _jsxs4(motion10.div, { ...restProps, ...gestureHandlers, className: cx10(scopingClassNames, "framer-1a06n1x", className3, classNames), "data-framer-name": "Light Closed", layoutDependency, layoutId: "E5HHCtcw__qsjQryIWb", ref: refBinding, style: { "--corner-shape-fallback": 0.796, backgroundColor: "rgb(238, 235, 228)", borderBottomLeftRadius: "calc(24px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(24px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(24px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(24px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", cornerShape: "superellipse(1.4)", ...style }, variants: { jTeytEfUG: { backgroundColor: "rgb(15, 15, 17)" }, SnTTeaPpc: { backgroundColor: "rgb(15, 15, 17)" } }, ...addPropertyOverrides4({ D09eACQPD: { "data-framer-name": "Light Open" }, jTeytEfUG: { "data-framer-name": "Dark Open" }, SnTTeaPpc: { "data-framer-name": "Dark Closed" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs4(motion10.nav, { className: "framer-sg97ep", "data-framer-name": "Control Bar", layoutDependency, layoutId: "E5HHCtcw__DyJ7R6OoZ", style: { "--corner-shape-fallback": 1, backgroundColor: "rgb(10, 10, 10)", borderBottomLeftRadius: "calc(18px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(18px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(18px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(18px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", cornerShape: "superellipse(1)" }, variants: { jTeytEfUG: { backgroundColor: "rgb(247, 246, 243)" }, SnTTeaPpc: { backgroundColor: "rgb(247, 246, 243)" } }, children: [/* @__PURE__ */ _jsxs4(motion10.div, { className: "framer-1axf4t2", "data-framer-name": "Menu Toggle", "data-highlight": true, layoutDependency, layoutId: "E5HHCtcw__ZtetmruMK", onTap: onTapq7xj56, ...addPropertyOverrides4({ D09eACQPD: { onTap: onTap1sjrj5o }, jTeytEfUG: { onTap: onTapo20en }, SnTTeaPpc: { onTap: onTap19uukfy } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs4(motion10.div, { className: "framer-12i9dws", "data-framer-name": "Burger Icon", layoutDependency, layoutId: "E5HHCtcw__nJjeqnIka", style: { rotate: 0 }, variants: { D09eACQPD: { rotate: 90 }, jTeytEfUG: { rotate: 90 }, SnTTeaPpc: { rotate: 0 } }, children: [/* @__PURE__ */ _jsx11(motion10.div, { className: "framer-1gtz5t3", "data-framer-name": "Line Top", layoutDependency, layoutId: "E5HHCtcw__LxPtQYQy1", style: { backgroundColor: "rgb(255, 255, 255)", borderBottomLeftRadius: 2, borderBottomRightRadius: 2, borderTopLeftRadius: 2, borderTopRightRadius: 2, rotate: 0 }, variants: { D09eACQPD: { rotate: 45 }, jTeytEfUG: { backgroundColor: "rgb(10, 10, 10)", rotate: 45 }, SnTTeaPpc: { backgroundColor: "rgb(10, 10, 10)", rotate: 0 } } }), /* @__PURE__ */ _jsx11(motion10.div, { className: "framer-lw91bj", "data-framer-name": "Line Bottom", layoutDependency, layoutId: "E5HHCtcw__dNGTStgTs", style: { backgroundColor: "rgb(255, 255, 255)", borderBottomLeftRadius: 2, borderBottomRightRadius: 2, borderTopLeftRadius: 2, borderTopRightRadius: 2, rotate: 0 }, variants: { D09eACQPD: { rotate: -45 }, jTeytEfUG: { backgroundColor: "rgb(10, 10, 10)", rotate: -45 }, SnTTeaPpc: { backgroundColor: "rgb(10, 10, 10)", rotate: 0 } } })] }), isDisplayed() && /* @__PURE__ */ _jsx11(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(255, 255, 255))" }, children: "Menu" }) }), className: "framer-1j679kk", "data-framer-name": "Toggle Label", effect: textEffect, fonts: ["Inter"], layoutDependency, layoutId: "E5HHCtcw__U4D0vVuhQ", style: { "--extracted-r6o4lv": "rgb(255, 255, 255)" }, variants: { SnTTeaPpc: { "--extracted-r6o4lv": "rgb(10, 10, 10)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides4({ SnTTeaPpc: { children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(10, 10, 10))" }, children: "Menu" }) }) } }, baseVariant, gestureVariant) }), isDisplayed1() && /* @__PURE__ */ _jsx11(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(255, 255, 255))" }, children: "Close" }) }), className: "framer-1btzoe2", "data-framer-name": "Toggle Label Close", effect: textEffect, fonts: ["Inter"], layoutDependency, layoutId: "E5HHCtcw__FzBL9Iw6y", style: { "--extracted-r6o4lv": "rgb(255, 255, 255)" }, variants: { jTeytEfUG: { "--extracted-r6o4lv": "rgb(10, 10, 10)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides4({ jTeytEfUG: { children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(10, 10, 10))" }, children: "Close" }) }) } }, baseVariant, gestureVariant) })] }), /* @__PURE__ */ _jsxs4(motion10.div, { className: "framer-1yg06vj", "data-framer-name": "Right Controls", layoutDependency, layoutId: "E5HHCtcw__Z34jCIWuH", children: [/* @__PURE__ */ _jsx11(Transition4, { value: transition4, children: /* @__PURE__ */ _jsxs4(motion10.div, { className: "framer-nj0fgc", "data-border": true, "data-framer-name": "Theme Toggle", "data-highlight": true, layoutDependency, layoutId: "E5HHCtcw__q5DRov_nI", onTap: onTapo20en, style: { "--border-bottom-width": "1px", "--border-color": "rgba(255, 255, 255, 0.3)", "--border-left-width": "1px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "1px", "--corner-shape-fallback": 1, borderBottomLeftRadius: "calc(100px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(100px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(100px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(100px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", cornerShape: "superellipse(1)" }, variants: { jTeytEfUG: { "--border-color": "rgba(0, 0, 0, 0.2)" }, SnTTeaPpc: { "--border-color": "rgba(0, 0, 0, 0.2)" } }, whileHover: animation1, ...addPropertyOverrides4({ D09eACQPD: { onTap: onTap19uukfy }, jTeytEfUG: { onTap: onTapq7xj56, whileHover: animation2 }, SnTTeaPpc: { onTap: onTap1sjrj5o, whileHover: animation2 } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx11(Transition4, { value: transition4, children: /* @__PURE__ */ _jsx11(Q3uK_jYjo_default, { animated: true, className: "framer-1gd2hmp", "data-framer-name": "Sun", layoutDependency, layoutId: "E5HHCtcw__K7CbaCjkH", style: { "--1m973uw": "rgb(255, 255, 255)", "--js9iwy": 2, opacity: 1, rotate: 0 }, variants: { jTeytEfUG: { "--1m973uw": "rgb(10, 10, 10)", opacity: 0, rotate: 120 }, SnTTeaPpc: { "--1m973uw": "rgb(10, 10, 10)", opacity: 0, rotate: 120 } } }) }), /* @__PURE__ */ _jsx11(Transition4, { value: transition4, children: /* @__PURE__ */ _jsx11(AfVKYR46L_default, { animated: true, className: "framer-1so76b9", "data-framer-name": "Moon", layoutDependency, layoutId: "E5HHCtcw__zVoCsex2f", style: { "--1m973uw": "rgb(255, 255, 255)", "--js9iwy": 2, opacity: 0, rotate: -120 }, variants: { jTeytEfUG: { "--1m973uw": "rgb(10, 10, 10)", opacity: 1, rotate: 0 }, SnTTeaPpc: { "--1m973uw": "rgb(10, 10, 10)", opacity: 1, rotate: 0 } } }) })] }) }), /* @__PURE__ */ _jsx11(motion10.div, { className: "framer-7gq5bm", "data-framer-name": "Time Pill", layoutDependency, layoutId: "E5HHCtcw__qx1X0tNin", style: { "--corner-shape-fallback": 1, cornerShape: "superellipse(1)", opacity: 0.8 }, children: Jl7JpkUR3 !== false && /* @__PURE__ */ _jsx11(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-9v1q2m-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "E5HHCtcw__FwER2iDie-container", nodeId: "FwER2iDie", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(Time, { color: "rgba(255, 255, 255, 0.55)", font: { fontFamily: '"Inter", "Inter Placeholder", sans-serif', fontSize: "16px", fontStyle: "normal", fontWeight: 400, letterSpacing: "0em", lineHeight: "1em" }, height: "100%", id: "FwER2iDie", layoutId: "E5HHCtcw__FwER2iDie", monthFormat: "long", outputType: "time", showMinutes: true, showMonth: true, showSeconds: false, showWeekday: true, showYear: true, tabularFont: true, timeFormat: "24h", width: "100%", ...addPropertyOverrides4({ jTeytEfUG: { color: "rgba(10, 10, 10, 0.5)" }, SnTTeaPpc: { color: "rgba(10, 10, 10, 0.5)" } }, baseVariant, gestureVariant) }) }) }) })] })] }), /* @__PURE__ */ _jsx11(motion10.div, { className: "framer-tuvs6k", "data-framer-name": "Menu Panel", layoutDependency, layoutId: "E5HHCtcw__aQjNJDWbg", children: /* @__PURE__ */ _jsxs4(motion10.div, { className: "framer-13u3res", "data-framer-name": "Panel Content", layoutDependency, layoutId: "E5HHCtcw__n2hZNlHbY", children: [/* @__PURE__ */ _jsxs4(motion10.div, { className: "framer-ecutph", "data-framer-name": "Menu Section", layoutDependency, layoutId: "E5HHCtcw__szGH8ugm2", children: [/* @__PURE__ */ _jsx11(motion10.div, { className: "framer-1wwrgtv", "data-framer-name": "Tag Wrap", layoutDependency, layoutId: "E5HHCtcw__MHviTSm2E", children: /* @__PURE__ */ _jsx11(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-font-size": "13px", "--framer-text-color": "var(--extracted-r6o4lv, rgba(0, 0, 0, 0.4))" }, children: "Menu" }) }), className: "framer-d2sobk", "data-framer-name": "Navigate Tag", fonts: ["Inter"], layoutDependency, layoutId: "E5HHCtcw__NpBGisgUO", style: { "--extracted-r6o4lv": "rgba(0, 0, 0, 0.4)" }, variants: { jTeytEfUG: { "--extracted-r6o4lv": "rgba(255, 255, 255, 0.4)" }, SnTTeaPpc: { "--extracted-r6o4lv": "rgba(255, 255, 255, 0.4)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides4({ jTeytEfUG: { children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-font-size": "13px", "--framer-text-color": "var(--extracted-r6o4lv, rgba(255, 255, 255, 0.4))" }, children: "Menu" }) }) }, SnTTeaPpc: { children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-font-size": "13px", "--framer-text-color": "var(--extracted-r6o4lv, rgba(255, 255, 255, 0.4))" }, children: "Menu" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx11(ComponentViewportProvider, { height: 36, width: `calc(${componentViewport?.width || "100vw"} - 52px)`, y: (componentViewport?.y || 0) + 8 + 52 + 0 + 0 + 32 + 0 + 0 + 83, children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-1flustv-container", "data-framer-name": "Menu Link 1", layoutDependency, layoutId: "E5HHCtcw__Ce3OGbnZD-container", name: "Menu Link 1", nodeId: "Ce3OGbnZD", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(FLXAZe6Zt_default, { A8naXXN6A: true, height: "100%", id: "Ce3OGbnZD", layoutId: "E5HHCtcw__Ce3OGbnZD", name: "Menu Link 1", rNnb4XUou: "About", style: { width: "100%" }, variant: matchVariant("DHKyVjflU"), VYcl1xKnX: "https://framer.link/fsd2pgh", width: "100%", ...addPropertyOverrides4({ jTeytEfUG: { variant: matchVariant("QHhetCOgb") }, SnTTeaPpc: { variant: matchVariant("QHhetCOgb") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx11(ComponentViewportProvider, { height: 36, width: `calc(${componentViewport?.width || "100vw"} - 52px)`, y: (componentViewport?.y || 0) + 8 + 52 + 0 + 0 + 32 + 0 + 0 + 119, children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-1kf0zaz-container", "data-framer-name": "Menu Link 2", layoutDependency, layoutId: "E5HHCtcw__ayrv8r7OX-container", name: "Menu Link 2", nodeId: "ayrv8r7OX", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(FLXAZe6Zt_default, { A8naXXN6A: true, height: "100%", id: "ayrv8r7OX", layoutId: "E5HHCtcw__ayrv8r7OX", name: "Menu Link 2", rNnb4XUou: "Pricing", style: { width: "100%" }, variant: matchVariant("DHKyVjflU"), VYcl1xKnX: "https://framer.link/fsd2pgh", width: "100%", ...addPropertyOverrides4({ jTeytEfUG: { variant: matchVariant("QHhetCOgb") }, SnTTeaPpc: { variant: matchVariant("QHhetCOgb") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx11(ComponentViewportProvider, { height: 36, width: `calc(${componentViewport?.width || "100vw"} - 52px)`, y: (componentViewport?.y || 0) + 8 + 52 + 0 + 0 + 32 + 0 + 0 + 155, children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-sf4o54-container", "data-framer-name": "Menu Link 3", layoutDependency, layoutId: "E5HHCtcw__oZ259lV5g-container", name: "Menu Link 3", nodeId: "oZ259lV5g", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(FLXAZe6Zt_default, { A8naXXN6A: true, height: "100%", id: "oZ259lV5g", layoutId: "E5HHCtcw__oZ259lV5g", name: "Menu Link 3", rNnb4XUou: "Resources", style: { width: "100%" }, variant: matchVariant("DHKyVjflU"), VYcl1xKnX: "https://framer.link/fsd2pgh", width: "100%", ...addPropertyOverrides4({ jTeytEfUG: { variant: matchVariant("QHhetCOgb") }, SnTTeaPpc: { variant: matchVariant("QHhetCOgb") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx11(ComponentViewportProvider, { height: 36, width: `calc(${componentViewport?.width || "100vw"} - 52px)`, y: (componentViewport?.y || 0) + 8 + 52 + 0 + 0 + 32 + 0 + 0 + 191, children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-1th44rx-container", "data-framer-name": "Menu Link 4", layoutDependency, layoutId: "E5HHCtcw__nSSAEYHAG-container", name: "Menu Link 4", nodeId: "nSSAEYHAG", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(FLXAZe6Zt_default, { A8naXXN6A: true, height: "100%", id: "nSSAEYHAG", layoutId: "E5HHCtcw__nSSAEYHAG", name: "Menu Link 4", rNnb4XUou: "Our features", style: { width: "100%" }, variant: matchVariant("DHKyVjflU"), VYcl1xKnX: "https://framer.link/fsd2pgh", width: "100%", ...addPropertyOverrides4({ jTeytEfUG: { variant: matchVariant("QHhetCOgb") }, SnTTeaPpc: { variant: matchVariant("QHhetCOgb") } }, baseVariant, gestureVariant) }) }) })] }), /* @__PURE__ */ _jsx11(motion10.div, { className: "framer-1uew55z", "data-framer-name": "Divider", layoutDependency, layoutId: "E5HHCtcw__CVOWU1zaH", style: { backgroundColor: "rgba(0, 0, 0, 0.08)" }, variants: { jTeytEfUG: { backgroundColor: "rgba(255, 255, 255, 0.08)" }, SnTTeaPpc: { backgroundColor: "rgba(255, 255, 255, 0.08)" } } }), /* @__PURE__ */ _jsxs4(motion10.div, { className: "framer-a30ce1", "data-framer-name": "Other Section", layoutDependency, layoutId: "E5HHCtcw__A_U0Xuxrf", children: [/* @__PURE__ */ _jsx11(motion10.div, { className: "framer-m2o2ur", "data-framer-name": "Tag Wrap", layoutDependency, layoutId: "E5HHCtcw__PeI6ywm7J", children: /* @__PURE__ */ _jsx11(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-font-size": "13px", "--framer-text-color": "var(--extracted-r6o4lv, rgba(0, 0, 0, 0.4))" }, children: "Legal" }) }), className: "framer-qhkrw7", "data-framer-name": "Legal Tag", fonts: ["Inter"], layoutDependency, layoutId: "E5HHCtcw__RxG447Lx8", style: { "--extracted-r6o4lv": "rgba(0, 0, 0, 0.4)" }, variants: { jTeytEfUG: { "--extracted-r6o4lv": "rgba(255, 255, 255, 0.4)" }, SnTTeaPpc: { "--extracted-r6o4lv": "rgba(255, 255, 255, 0.4)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides4({ jTeytEfUG: { children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-font-size": "13px", "--framer-text-color": "var(--extracted-r6o4lv, rgba(255, 255, 255, 0.4))" }, children: "Legal" }) }) }, SnTTeaPpc: { children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-font-size": "13px", "--framer-text-color": "var(--extracted-r6o4lv, rgba(255, 255, 255, 0.4))" }, children: "Legal" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx11(ComponentViewportProvider, { height: 30, width: `calc(${componentViewport?.width || "100vw"} - 52px)`, y: (componentViewport?.y || 0) + 8 + 52 + 0 + 0 + 32 + 266 + 5 + 83, children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-q9n6x3-container", "data-framer-name": "Legal Link 1", layoutDependency, layoutId: "E5HHCtcw__gWB38j4Fi-container", name: "Legal Link 1", nodeId: "gWB38j4Fi", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(uh0o6Kp1Z_default, { cE66sCxlN: "Privacy Policy", height: "100%", id: "gWB38j4Fi", layoutId: "E5HHCtcw__gWB38j4Fi", name: "Legal Link 1", RP7QAUtbs: "https://framer.link/fsd2pgh", style: { width: "100%" }, twPOE0L8l: true, variant: matchVariant("njslONOSS"), width: "100%", ...addPropertyOverrides4({ jTeytEfUG: { variant: matchVariant("c6BKNoDaP") }, SnTTeaPpc: { variant: matchVariant("c6BKNoDaP") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx11(ComponentViewportProvider, { height: 30, width: `calc(${componentViewport?.width || "100vw"} - 52px)`, y: (componentViewport?.y || 0) + 8 + 52 + 0 + 0 + 32 + 266 + 5 + 113, children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-1ej7ywa-container", "data-framer-name": "Legal Link 2", layoutDependency, layoutId: "E5HHCtcw__zCDwcQikU-container", name: "Legal Link 2", nodeId: "zCDwcQikU", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(uh0o6Kp1Z_default, { cE66sCxlN: "Terms & Conditions", height: "100%", id: "zCDwcQikU", layoutId: "E5HHCtcw__zCDwcQikU", name: "Legal Link 2", RP7QAUtbs: "https://framer.link/fsd2pgh", style: { width: "100%" }, twPOE0L8l: true, variant: matchVariant("njslONOSS"), width: "100%", ...addPropertyOverrides4({ jTeytEfUG: { variant: matchVariant("c6BKNoDaP") }, SnTTeaPpc: { variant: matchVariant("c6BKNoDaP") } }, baseVariant, gestureVariant) }) }) })] }), /* @__PURE__ */ _jsxs4(motion10.div, { className: "framer-1knz9kk", "data-framer-name": "Social Section", layoutDependency, layoutId: "E5HHCtcw__KuyWCpokq", children: [/* @__PURE__ */ _jsx11(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-font-size": "13px", "--framer-text-color": "var(--extracted-r6o4lv, rgba(0, 0, 0, 0.4))" }, children: "Social media" }) }), className: "framer-wohzzx", "data-framer-name": "Connect Tag", fonts: ["Inter"], layoutDependency, layoutId: "E5HHCtcw__WfGQ5nQQY", style: { "--extracted-r6o4lv": "rgba(0, 0, 0, 0.4)" }, variants: { jTeytEfUG: { "--extracted-r6o4lv": "rgba(255, 255, 255, 0.4)" }, SnTTeaPpc: { "--extracted-r6o4lv": "rgba(255, 255, 255, 0.4)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides4({ jTeytEfUG: { children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-font-size": "13px", "--framer-text-color": "var(--extracted-r6o4lv, rgba(255, 255, 255, 0.4))" }, children: "Social media" }) }) }, SnTTeaPpc: { children: /* @__PURE__ */ _jsx11(React10.Fragment, { children: /* @__PURE__ */ _jsx11(motion10.p, { dir: "auto", style: { "--framer-font-size": "13px", "--framer-text-color": "var(--extracted-r6o4lv, rgba(255, 255, 255, 0.4))" }, children: "Social media" }) }) } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsxs4(motion10.div, { className: "framer-pwugvi", "data-framer-name": "Social Media Icons", layoutDependency, layoutId: "E5HHCtcw__DQx39Egyz", children: [/* @__PURE__ */ _jsx11(ComponentViewportProvider, { height: 26, y: (componentViewport?.y || 0) + 8 + 52 + 0 + 0 + 32 + 433 + 0 + 83 + 0, children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-1qdcctb-container", layoutDependency, layoutId: "E5HHCtcw__NexfOmhzq-container", nodeId: "NexfOmhzq", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(Zy4YYAluy_default, { height: "100%", id: "NexfOmhzq", layoutId: "E5HHCtcw__NexfOmhzq", u00_W2pPu: "https://framer.link/fsd2pgh", variant: matchVariant("JzqYnpJB1"), wb9ifXOeQ: UD0eTfbk_default, width: "100%", x1D8kuFgO: true, ...addPropertyOverrides4({ jTeytEfUG: { variant: matchVariant("aWkAzH2Gx") }, SnTTeaPpc: { variant: matchVariant("aWkAzH2Gx") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx11(ComponentViewportProvider, { height: 26, y: (componentViewport?.y || 0) + 8 + 52 + 0 + 0 + 32 + 433 + 0 + 83 + 0, children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-8tbq7h-container", layoutDependency, layoutId: "E5HHCtcw__dwaDzUS2i-container", nodeId: "dwaDzUS2i", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(Zy4YYAluy_default, { height: "100%", id: "dwaDzUS2i", layoutId: "E5HHCtcw__dwaDzUS2i", u00_W2pPu: "https://framer.link/fsd2pgh", variant: matchVariant("JzqYnpJB1"), wb9ifXOeQ: Xx_sbLkzD_default, width: "100%", x1D8kuFgO: true, ...addPropertyOverrides4({ jTeytEfUG: { variant: matchVariant("aWkAzH2Gx") }, SnTTeaPpc: { variant: matchVariant("aWkAzH2Gx") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx11(ComponentViewportProvider, { height: 26, y: (componentViewport?.y || 0) + 8 + 52 + 0 + 0 + 32 + 433 + 0 + 83 + 0, children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-1c52cwl-container", layoutDependency, layoutId: "E5HHCtcw__pRKZSy5A4-container", nodeId: "pRKZSy5A4", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(Zy4YYAluy_default, { height: "100%", id: "pRKZSy5A4", layoutId: "E5HHCtcw__pRKZSy5A4", u00_W2pPu: "https://framer.link/fsd2pgh", variant: matchVariant("JzqYnpJB1"), wb9ifXOeQ: X4yTai4nL_default, width: "100%", x1D8kuFgO: true, ...addPropertyOverrides4({ jTeytEfUG: { variant: matchVariant("aWkAzH2Gx") }, SnTTeaPpc: { variant: matchVariant("aWkAzH2Gx") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx11(ComponentViewportProvider, { height: 26, y: (componentViewport?.y || 0) + 8 + 52 + 0 + 0 + 32 + 433 + 0 + 83 + 0, children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer, { className: "framer-js5wtz-container", layoutDependency, layoutId: "E5HHCtcw__TTRbtLijC-container", nodeId: "TTRbtLijC", rendersWithMotion: true, scopeId: "E5HHCt_cw", children: /* @__PURE__ */ _jsx11(Zy4YYAluy_default, { height: "100%", id: "TTRbtLijC", layoutId: "E5HHCtcw__TTRbtLijC", u00_W2pPu: "https://framer.link/fsd2pgh", variant: matchVariant("JzqYnpJB1"), wb9ifXOeQ: rR4Yw6OW8_default, width: "100%", x1D8kuFgO: true, ...addPropertyOverrides4({ jTeytEfUG: { variant: matchVariant("aWkAzH2Gx") }, SnTTeaPpc: { variant: matchVariant("aWkAzH2Gx") } }, baseVariant, gestureVariant) }) }) })] })] })] }) })] }) }) }) });
});
var css12 = [".framer-e7DTD.framer-z15gbj, .framer-e7DTD .framer-z15gbj { display: block; }", ".framer-e7DTD.framer-1a06n1x { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 8px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-e7DTD .framer-sg97ep { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; height: min-content; justify-content: space-between; overflow: visible; padding: 8px 8px 8px 20px; position: relative; width: 100%; }", ".framer-e7DTD .framer-1axf4t2 { align-content: center; align-items: center; cursor: pointer; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: 36px; justify-content: flex-start; padding: 0px; position: relative; width: min-content; }", ".framer-e7DTD .framer-12i9dws { flex: none; height: 20px; overflow: visible; position: relative; width: 20px; }", ".framer-e7DTD .framer-1gtz5t3 { flex: none; height: 1px; left: 1px; position: absolute; top: 6px; width: 18px; }", ".framer-e7DTD .framer-lw91bj { flex: none; height: 1px; left: 1px; position: absolute; top: 12px; width: 18px; }", ".framer-e7DTD .framer-1j679kk, .framer-e7DTD .framer-1btzoe2 { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-e7DTD .framer-1yg06vj { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: flex-start; padding: 0px; position: relative; width: min-content; }", ".framer-e7DTD .framer-nj0fgc { cursor: pointer; flex: none; gap: 0px; height: 36px; overflow: var(--overflow-clip-fallback, clip); position: relative; width: 36px; will-change: var(--framer-will-change-effect-override, transform); }", ".framer-e7DTD .framer-1gd2hmp { aspect-ratio: 1 / 1; flex: none; height: auto; left: 9px; pointer-events: none; position: absolute; top: 9px; width: 18px; }", ".framer-e7DTD .framer-1so76b9 { aspect-ratio: 1 / 1; flex: none; height: auto; pointer-events: none; position: absolute; right: 9px; top: 9px; width: 18px; }", ".framer-e7DTD .framer-7gq5bm { -webkit-user-select: none; align-content: center; align-items: center; cursor: default; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; padding: 0px 6px 0px 6px; position: relative; user-select: none; width: min-content; }", ".framer-e7DTD .framer-9v1q2m-container, .framer-e7DTD .framer-1qdcctb-container, .framer-e7DTD .framer-8tbq7h-container, .framer-e7DTD .framer-1c52cwl-container, .framer-e7DTD .framer-js5wtz-container { flex: none; height: auto; position: relative; width: auto; }", ".framer-e7DTD .framer-tuvs6k { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: 0px; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-e7DTD .framer-13u3res { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 19px; height: min-content; justify-content: flex-start; padding: 32px 18px 24px 18px; position: relative; width: 100%; }", ".framer-e7DTD .framer-ecutph { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; padding: 0px; position: relative; width: 100%; }", ".framer-e7DTD .framer-1wwrgtv, .framer-e7DTD .framer-m2o2ur { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; padding: 0px 0px 5px 0px; position: relative; width: 100%; }", ".framer-e7DTD .framer-d2sobk, .framer-e7DTD .framer-qhkrw7, .framer-e7DTD .framer-wohzzx { -webkit-user-select: none; flex: none; height: auto; position: relative; user-select: none; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-e7DTD .framer-1flustv-container, .framer-e7DTD .framer-1kf0zaz-container, .framer-e7DTD .framer-sf4o54-container, .framer-e7DTD .framer-1th44rx-container, .framer-e7DTD .framer-q9n6x3-container, .framer-e7DTD .framer-1ej7ywa-container { flex: none; height: auto; position: relative; width: 100%; }", ".framer-e7DTD .framer-1uew55z { flex: none; height: 1px; position: relative; width: 100%; }", ".framer-e7DTD .framer-a30ce1 { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; padding: 5px 0px 0px 0px; position: relative; width: 100%; }", ".framer-e7DTD .framer-1knz9kk { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 5px; height: min-content; justify-content: flex-start; padding: 0px; position: relative; width: 100%; }", ".framer-e7DTD .framer-pwugvi { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 5px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-e7DTD.framer-v-7bqof3.framer-1a06n1x, .framer-e7DTD.framer-v-zzne2w.framer-1a06n1x { width: 100%; }", ".framer-e7DTD.framer-v-7bqof3 .framer-1gtz5t3, .framer-e7DTD.framer-v-7bqof3 .framer-lw91bj, .framer-e7DTD.framer-v-zzne2w .framer-1gtz5t3, .framer-e7DTD.framer-v-zzne2w .framer-lw91bj { top: 9px; }", ".framer-e7DTD.framer-v-7bqof3 .framer-tuvs6k, .framer-e7DTD.framer-v-zzne2w .framer-tuvs6k { height: min-content; }", '.framer-e7DTD[data-border="true"]::after, .framer-e7DTD [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerE5HHCt_cw = withCSS10(Component10, css12, "framer-e7DTD");
var E5HHCt_cw_default = FramerE5HHCt_cw;
FramerE5HHCt_cw.displayName = "Motion Minimal Navs";
FramerE5HHCt_cw.defaultProps = { height: 68, width: 280 };
addPropertyControls11(FramerE5HHCt_cw, { variant: { options: ["qsjQryIWb", "D09eACQPD", "SnTTeaPpc", "jTeytEfUG"], optionTitles: ["Light Closed", "Light Open", "Dark Closed", "Dark Open"], title: "Variant", type: ControlType11.Enum }, Jl7JpkUR3: { defaultValue: true, description: "Built by Matthias \xD6lschlegel \u{1F4AA}\n[Explore more components](https://framer.link/fsd2pgh)", title: "Show Clock", type: ControlType11.Boolean }, onJl7JpkUR3Change: { changes: "Jl7JpkUR3", type: ControlType11.ChangeHandler } });
addFonts4(FramerE5HHCt_cw, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...SunFonts, ...MoonFonts, ...TimeDateFonts, ...MenuLinkFonts, ...LegalLinkFonts, ...SocialMediaIconFonts], { supportsExplicitInterCodegen: true });
FramerE5HHCt_cw.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader(FLXAZe6Zt_default, {}, context), forwardLoader(uh0o6Kp1Z_default, {}, context), forwardLoader(Zy4YYAluy_default, {}, context)]);
} };
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerE5HHCt_cw", "slots": [], "annotations": { "framerDisplayContentsDiv": "false", "framerContractVersion": "1", "framerIntrinsicWidth": "280", "framerColorSyntax": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"D09eACQPD":{"layout":["fixed","auto"]},"SnTTeaPpc":{"layout":["fixed","auto"]},"jTeytEfUG":{"layout":["fixed","auto"]}}}', "framerAutoSizeImages": "true", "framerVariables": '{"Jl7JpkUR3":"showClock"}', "framerImmutableVariables": "true", "framerComponentViewportWidth": "true", "framerIntrinsicHeight": "68" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  E5HHCt_cw_default as default
};
