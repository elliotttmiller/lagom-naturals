export interface Qgfnhsg3pProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Variant 1" → Cob5IoNWG
   *   "Variant 2" → ezppaEGty
   */
  variant?: 'Variant 1' | 'Variant 2' | 'Cob5IoNWG' | 'ezppaEGty';
  /** Additional properties */
  [key: string]: unknown;
}
