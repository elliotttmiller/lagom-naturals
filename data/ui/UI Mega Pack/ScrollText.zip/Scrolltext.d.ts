export interface ScrolltextProps {
  /**
   * Text
   * @default "Turn your [1] into something people truly value in less time and with more [2]"
   */
  text?: string;
  /**
   * Show Slots
   * @default true
   */
  showSlots?: boolean;
  /**
   * Slots
   * @default []
   */
  slots?: unknown[];
  /**
   * Layer Gap
   * Range: min: 0, max: 100, step: 1
   * @default 2
   */
  layerGap?: number;
  /**
   * @default {"fontSize":36,"variant":"Regular","lineHeight":1.1}
   */
  font?: string;
  /**
   * @default "#FFFFFF"
   */
  textColor?: string;
  /**
   * Animation — pass as `animationStyle` not `animation`.
   * Options: "fade" | "slide"
   * @default "fade"
   */
  animationStyle?: 'fade' | 'slide';
  /**
   * Smooth — pass as `enableSmooth` not `smooth`.
   * @default true
   */
  enableSmooth?: boolean;
  /**
   * Blur — pass as `enableBlur` not `blur`.
   * @default false
   */
  enableBlur?: boolean;
  /**
   * Start Offset
   * Range: min: 0, max: 1, step: 0.01
   * @default 0.5
   */
  startOffset?: number;
  /**
   * End Offset
   * Range: min: 0, max: 1, step: 0.01
   * @default 0.5
   */
  endOffset?: number;
  /**
   * Start Opacity
   * Range: min: 0, max: 1, step: 0.01
   * @default 0
   */
  startOpacity?: number;
  /**
   * End Opacity
   * Range: min: 0, max: 1, step: 0.01
   * @default 1
   */
  endOpacity?: number;
  /** Additional properties */
  [key: string]: unknown;
}
