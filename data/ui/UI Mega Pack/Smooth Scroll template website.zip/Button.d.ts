export interface ButtonProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Dark" → rIEFgaYtd
   *   "Light" → sV7u745dJ
   *   "Small" → NoO3FX51o
   */
  variant?: 'Dark' | 'Light' | 'Small' | 'sV7u745dJ' | 'rIEFgaYtd' | 'NoO3FX51o';
  /**
   * Text — pass as `aWPRIK3cW` not `text`.
   * @default "Button text"
   */
  aWPRIK3cW?: string;
  /**
   * Link — pass as `JbyStVNTo` not `link`.
   */
  JbyStVNTo?: string;
  /**
   * New Tab — pass as `BKPcQrLno` not `newTab`.
   * @default false
   */
  BKPcQrLno?: boolean;
  /**
   * Smooth Scroll — pass as `bAEOFj2Y2` not `smoothScroll`.
   * @default true
   */
  bAEOFj2Y2?: boolean;
  /**
   * Click — pass as `T3sVDvSuO` not `click`.
   */
  T3sVDvSuO?: () => void;
  /**
   * Background Blur — pass as `wauKxDeIc` not `backgroundBlur`.
   * Range: min: 0, max: 15
   * @default 10
   */
  wauKxDeIc?: number;
  /** Additional properties */
  [key: string]: unknown;
}
