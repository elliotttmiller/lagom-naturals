export interface Gallery4Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → Pe8WEpTQv
   *   "Mobile" → RrP2167Cm
   */
  variant?: 'Desktop' | 'Mobile' | 'Pe8WEpTQv' | 'RrP2167Cm';
  /** Additional properties */
  [key: string]: unknown;
}
