/**
 * Props for Faqs4 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Faqs4Props {
  [key: string]: unknown;
}
