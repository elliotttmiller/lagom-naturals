export interface Pulse5Props {
  color?: string;
  /**
   * Range: min: 0.1, step: 0.01
   * @default 1
   */
  delay?: number;
  /**
   * Options: "in" | "out"
   * @default "out"
   */
  direction?: 'in' | 'out';
  /**
   * Range: min: 1, step: 1
   * @default 20
   */
  pulseSize?: number;
  /**
   * Range: min: 0, max: 1, step: 0.01
   * @default 0.5
   */
  pulseOpacity?: number;
  /**
   * Options: "solid" | "border"
   * @default "solid"
   */
  style?: 'solid' | 'border';
  /**
   * Outline Width — pass as `borderWidth` not `outlineWidth`.
   * Range: min: 1, step: 1
   * @default 5
   */
  borderWidth?: number;
  /**
   * Radius — pass as `radiusType` not `radius`.
   * Options: "full" | "custom"
   * @default "full"
   */
  radiusType?: 'full' | 'custom';
  /**
   *  
   * Range: min: 1, step: 1
   * @default 20
   */
  radiusValue?: number;
  /**
   * @default {"type":"spring","stiffness":150,"damping":60}
   */
  transition?: object;
  /** Additional properties */
  [key: string]: unknown;
}
