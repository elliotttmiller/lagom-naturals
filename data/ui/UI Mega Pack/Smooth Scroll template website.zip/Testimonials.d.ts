export interface TestimonialsProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → aUm3TPLRG
   *   "Mobile" → wNaqfP3tz
   */
  variant?: 'Desktop' | 'Mobile' | 'aUm3TPLRG' | 'wNaqfP3tz';
  /** Additional properties */
  [key: string]: unknown;
}
