export interface Badge15Props {
  /**
   * Text — pass as `Kf7JQm0Hr` not `text`.
   * @default "About us"
   */
  Kf7JQm0Hr?: string;
  /** Additional properties */
  [key: string]: unknown;
}
