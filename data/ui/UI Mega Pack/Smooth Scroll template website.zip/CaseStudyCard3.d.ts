export interface Casestudycard3Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Dark (mobile)" → R52w3u2i5
   *   "Dark (tablet)" → WqwRQ8xF9
   *   "Light (mobile)" → tEF1DkbCT
   *   "Light (tablet)" → KpK5Um_0P
   *   "Dark" → EYOp21BDV
   *   "Light" → FUFilgDoi
   */
  variant?: 'Dark (mobile)' | 'Dark (tablet)' | 'Light (mobile)' | 'Light (tablet)' | 'Dark' | 'Light' | 'FUFilgDoi' | 'EYOp21BDV' | 'KpK5Um_0P' | 'WqwRQ8xF9' | 'tEF1DkbCT' | 'R52w3u2i5';
  /**
   * Title — pass as `TrRAvJJ6K` not `title`.
   * @default "Case study title"
   */
  TrRAvJJ6K?: string;
  /**
   * Image — pass as `GrN3y4cXI` not `image`.
   */
  GrN3y4cXI?: string;
  /**
   * Description — pass as `a9oLMlhXr` not `description`.
   * @default "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
   */
  a9oLMlhXr?: string;
  /**
   * Quote — pass as `PpDpAwNsh` not `quote`.
   * @default "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
   */
  PpDpAwNsh?: string;
  /**
   * Client Image — pass as `LN7ilSOXi` not `clientImage`.
   */
  LN7ilSOXi?: string;
  /**
   * Client Name — pass as `YjIG4ktIZ` not `clientName`.
   * @default "Rachel Smith"
   */
  YjIG4ktIZ?: string;
  /**
   * Service — pass as `GWvyvQraR` not `service`.
   * @default "Kitchen"
   */
  GWvyvQraR?: string;
  /**
   * Duration — pass as `bAZcFm5c7` not `duration`.
   * @default "2 - 3 months"
   */
  bAZcFm5c7?: string;
  /** Additional properties */
  [key: string]: unknown;
}
