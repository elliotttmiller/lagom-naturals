export interface Statistic15Props {
  /**
   * Start — pass as `hwmcMZpxa` not `start`.
   * @default 0
   */
  hwmcMZpxa?: number;
  /**
   * End — pass as `sNi39lGOD` not `end`.
   * @default 10
   */
  sNi39lGOD?: number;
  /**
   * Prefix — pass as `cIxpXL2bb` not `prefix`.
   * @default ""
   */
  cIxpXL2bb?: string;
  /**
   * Suffix — pass as `Db_1O6OS_` not `suffix`.
   * @default ""
   */
  Db_1O6OS_?: string;
  /**
   * Title — pass as `a45OqAkJ4` not `title`.
   * @default "Years experience"
   */
  a45OqAkJ4?: string;
  /**
   * Description — pass as `Lc6Dz0rIA` not `description`.
   * @default "Years of experience in home improvement"
   */
  Lc6Dz0rIA?: string;
  /** Additional properties */
  [key: string]: unknown;
}
