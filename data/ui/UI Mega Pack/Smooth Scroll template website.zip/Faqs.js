var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/xJAwMon2Gk8Nufg941lB/Ya9fvzOibpynYyFlz6Xt/SofTjBAi7.js
import { jsx as _jsx5, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts as addFonts2, ComponentViewportProvider as ComponentViewportProvider2, cx as cx2, getFonts as getFonts2, SmartComponentScopedContainer as SmartComponentScopedContainer2, useActiveVariantCallback as useActiveVariantCallback2, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion3, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React4 from "react";
import { useRef as useRef4 } from "react";

// http-url:https://framerusercontent.com/modules/h8ioHyt4BUxuvVCE1Q10/aTM6mEMGlM19JjX8exDe/AvoidLayoutJumping_Prod.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, RenderTarget } from "./_framer-runtime.js";
import { useEffect, useRef } from "react";
function AvoidLayoutJumping({ direction, style }) {
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  const ref = useRef(null);
  const rafId = useRef();
  const vertical = direction === "vertical" || direction === "both";
  const horizontal = direction === "horizontal" || direction === "both";
  useEffect(() => {
    if (isCanvas)
      return;
    const parent = ref.current?.parentElement?.parentElement;
    if (!parent)
      return;
    const container = parent.parentElement;
    if (!container)
      return;
    const updateSize = () => {
      const rect = parent.getBoundingClientRect();
      if (horizontal) {
        container.style.width = `${rect.width}px`;
      }
      if (vertical) {
        container.style.height = `${rect.height}px`;
      }
      rafId.current = requestAnimationFrame(updateSize);
    };
    rafId.current = requestAnimationFrame(updateSize);
    return () => {
      if (rafId.current) {
        cancelAnimationFrame(rafId.current);
      }
      if (container) {
        if (horizontal) {
          container.style.width = "";
        }
        if (vertical) {
          container.style.height = "";
        }
      }
    };
  }, [direction]);
  return /* @__PURE__ */ _jsx("div", { ref, style: { ...style } });
}
AvoidLayoutJumping.displayName = "Layout Jump Preventer";
addPropertyControls(AvoidLayoutJumping, { direction: {
  type: ControlType.Enum,
  defaultValue: "vertical",
  options: ["vertical", "horizontal", "both"],
  optionTitles: ["Vertical", "Horizontal", "Both"],
  displaySegmentedControl: true,
  segmentedControlDirection: "vertical",
  // @ts-ignore
  optionIcons: ["direction-vertical", "direction-horizontal", "direction-all"],
  description: "More components at [Framer University](https://frameruni.link/cc)."
} });

// http-url:https://framerusercontent.com/modules/rJwfYW3tiv3bguXPhHNW/1g8it0BdqggXzdUCAl6c/XOSkZc1rZ.js
import { jsx as _jsx4, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ComponentViewportProvider, ControlType as ControlType4, cx, getFonts, getFontsFromSharedStyle, RichText, SmartComponentScopedContainer, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React3 from "react";
import { useRef as useRef3 } from "react";

// http-url:https://framerusercontent.com/modules/tYScH7LTqUtz5KUaUAYP/CAjjxbTJBxHwH1MagCef/Phosphor.js
import { jsx as _jsx3 } from "react/jsx-runtime";
import * as React2 from "react";
import { useState, useEffect as useEffect2, useRef as useRef2 } from "react";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType3, RenderTarget as RenderTarget2 } from "./_framer-runtime.js";
import { motion } from "framer-motion";

// http-url:https://framerusercontent.com/modules/DyldKav0OOAWR3bCAlhK/8c3l9FzyOlGpbPncYhfc/nullstate.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import * as React from "react";
var containerStyles = {
  width: "100%",
  height: "100%",
  display: "flex",
  justifyContent: "center",
  alignItems: "center"
};
var emptyStateStyle = {
  ...containerStyles,
  borderRadius: 6,
  background: "rgba(149, 149, 149, 0.1)",
  border: "1px dashed rgba(149, 149, 149, 0.15)",
  color: "#a5a5a5",
  flexDirection: "column"
};
var NullState = /* @__PURE__ */ React.forwardRef((_, ref) => {
  return /* @__PURE__ */ _jsx2("div", {
    style: emptyStateStyle,
    ref
  });
});

// http-url:https://framerusercontent.com/modules/Qc8yuHkQmGO0kFiSWbkX/i6WSiDLftYVS2GvUElTz/House.js
var Component;
var House_default = (React5) => {
  if (!Component) {
    const weights = /* @__PURE__ */ new Map([
      [
        "bold",
        /* @__PURE__ */ React5.createElement(React5.Fragment, null, /* @__PURE__ */ React5.createElement("path", { d: "M221.56,100.85,141.61,25.38l-.16-.15a19.93,19.93,0,0,0-26.91,0l-.17.15L34.44,100.85A20.07,20.07,0,0,0,28,115.55V208a20,20,0,0,0,20,20H96a20,20,0,0,0,20-20V164h24v44a20,20,0,0,0,20,20h48a20,20,0,0,0,20-20V115.55A20.07,20.07,0,0,0,221.56,100.85ZM204,204H164V160a20,20,0,0,0-20-20H112a20,20,0,0,0-20,20v44H52V117.28l76-71.75,76,71.75Z" }))
      ],
      [
        "duotone",
        /* @__PURE__ */ React5.createElement(React5.Fragment, null, /* @__PURE__ */ React5.createElement(
          "path",
          {
            d: "M216,115.54V208a8,8,0,0,1-8,8H160a8,8,0,0,1-8-8V160a8,8,0,0,0-8-8H112a8,8,0,0,0-8,8v48a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V115.54a8,8,0,0,1,2.62-5.92l80-75.54a8,8,0,0,1,10.77,0l80,75.54A8,8,0,0,1,216,115.54Z",
            opacity: "0.2"
          }
        ), /* @__PURE__ */ React5.createElement("path", { d: "M218.83,103.77l-80-75.48a1.14,1.14,0,0,1-.11-.11,16,16,0,0,0-21.53,0l-.11.11L37.17,103.77A16,16,0,0,0,32,115.55V208a16,16,0,0,0,16,16H96a16,16,0,0,0,16-16V160h32v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V115.55A16,16,0,0,0,218.83,103.77ZM208,208H160V160a16,16,0,0,0-16-16H112a16,16,0,0,0-16,16v48H48V115.55l.11-.1L128,40l79.9,75.43.11.1Z" }))
      ],
      [
        "fill",
        /* @__PURE__ */ React5.createElement(React5.Fragment, null, /* @__PURE__ */ React5.createElement("path", { d: "M224,115.55V208a16,16,0,0,1-16,16H168a16,16,0,0,1-16-16V168a8,8,0,0,0-8-8H112a8,8,0,0,0-8,8v40a16,16,0,0,1-16,16H48a16,16,0,0,1-16-16V115.55a16,16,0,0,1,5.17-11.78l80-75.48.11-.11a16,16,0,0,1,21.53,0,1.14,1.14,0,0,0,.11.11l80,75.48A16,16,0,0,1,224,115.55Z" }))
      ],
      [
        "light",
        /* @__PURE__ */ React5.createElement(React5.Fragment, null, /* @__PURE__ */ React5.createElement("path", { d: "M217.47,105.24l-80-75.5-.09-.08a13.94,13.94,0,0,0-18.83,0l-.09.08-80,75.5A14,14,0,0,0,34,115.55V208a14,14,0,0,0,14,14H96a14,14,0,0,0,14-14V160a2,2,0,0,1,2-2h32a2,2,0,0,1,2,2v48a14,14,0,0,0,14,14h48a14,14,0,0,0,14-14V115.55A14,14,0,0,0,217.47,105.24ZM210,208a2,2,0,0,1-2,2H160a2,2,0,0,1-2-2V160a14,14,0,0,0-14-14H112a14,14,0,0,0-14,14v48a2,2,0,0,1-2,2H48a2,2,0,0,1-2-2V115.55a2,2,0,0,1,.65-1.48l.09-.08,79.94-75.48a2,2,0,0,1,2.63,0L209.26,114l.08.08a2,2,0,0,1,.66,1.48Z" }))
      ],
      [
        "regular",
        /* @__PURE__ */ React5.createElement(React5.Fragment, null, /* @__PURE__ */ React5.createElement("path", { d: "M218.83,103.77l-80-75.48a1.14,1.14,0,0,1-.11-.11,16,16,0,0,0-21.53,0l-.11.11L37.17,103.77A16,16,0,0,0,32,115.55V208a16,16,0,0,0,16,16H96a16,16,0,0,0,16-16V160h32v48a16,16,0,0,0,16,16h48a16,16,0,0,0,16-16V115.55A16,16,0,0,0,218.83,103.77ZM208,208H160V160a16,16,0,0,0-16-16H112a16,16,0,0,0-16,16v48H48V115.55l.11-.1L128,40l79.9,75.43.11.1Z" }))
      ],
      [
        "thin",
        /* @__PURE__ */ React5.createElement(React5.Fragment, null, /* @__PURE__ */ React5.createElement("path", { d: "M216.13,106.72,136.07,31.13a12,12,0,0,0-16.2.05L39.93,106.67A12,12,0,0,0,36,115.54V208a12,12,0,0,0,12,12H96a12,12,0,0,0,12-12V160a4,4,0,0,1,4-4h32a4,4,0,0,1,4,4v48a12,12,0,0,0,12,12h48a12,12,0,0,0,12-12V115.54A12,12,0,0,0,216.13,106.72ZM212,208a4,4,0,0,1-4,4H160a4,4,0,0,1-4-4V160a12,12,0,0,0-12-12H112a12,12,0,0,0-12,12v48a4,4,0,0,1-4,4H48a4,4,0,0,1-4-4V115.54a4.09,4.09,0,0,1,1.36-3L125.3,37.05a4,4,0,0,1,5.33,0l80.06,75.58a4,4,0,0,1,1.31,3Z" }))
      ]
    ]);
    const House = React5.forwardRef((props, ref) => /* @__PURE__ */ React5.createElement("g", { ref, ...props }, weights.get(props.weight)));
    House.displayName = "House";
    Component = House;
  }
  return Component;
};

// http-url:https://framerusercontent.com/modules/Ma20hU0GGRxLxZphbywl/OSpwWF91FHPVFyQJjMHt/utils.js
import { useMemo } from "react";
import { ControlType as ControlType2 } from "./_framer-runtime.js";
var defaultEvents = { onClick: { type: ControlType2.EventHandler }, onMouseDown: { type: ControlType2.EventHandler }, onMouseUp: { type: ControlType2.EventHandler }, onMouseEnter: { type: ControlType2.EventHandler }, onMouseLeave: { type: ControlType2.EventHandler } };
var findByArray = (arr, search) => arr.find((a) => a.toLowerCase().includes(search));
function useIconSelection(iconKeys2, selectByList, iconSearch = "", iconSelection, lowercaseIconKeyPairs2) {
  const iconSearchResult = useMemo(() => {
    if (iconSearch == null || (iconSearch === null || iconSearch === void 0 ? void 0 : iconSearch.length) === 0)
      return null;
    const iconSearchTerm = iconSearch.toLowerCase().replace(/-|\s/g, "");
    var _iconSearchTerm;
    const searchResult = (_iconSearchTerm = lowercaseIconKeyPairs2[iconSearchTerm]) !== null && _iconSearchTerm !== void 0 ? _iconSearchTerm : findByArray(iconKeys2, iconSearchTerm);
    return searchResult;
  }, [iconSelection, iconSearch]);
  const name = selectByList ? iconSelection : iconSearchResult;
  return name;
}

// http-url:https://framerusercontent.com/modules/tYScH7LTqUtz5KUaUAYP/CAjjxbTJBxHwH1MagCef/Phosphor.js
var iconKeys = ["AddressBook", "AirTrafficControl", "Airplane", "AirplaneInFlight", "AirplaneLanding", "AirplaneTakeoff", "AirplaneTilt", "Airplay", "Alarm", "Alien", "AlignBottom", "AlignBottomSimple", "AlignCenterVertical", "AlignLeft", "AlignLeftSimple", "AlignRight", "AlignRightSimple", "AlignTop", "AlignTopSimple", "AmazonLogo", "Anchor", "AnchorSimple", "AndroidLogo", "AngularLogo", "Aperture", "AppStoreLogo", "AppWindow", "AppleLogo", "ApplePodcastsLogo", "Archive", "ArchiveBox", "ArchiveTray", "Armchair", "ArrowArcLeft", "ArrowArcRight", "ArrowBendDownLeft", "ArrowBendDownRight", "ArrowBendLeftDown", "ArrowBendLeftUp", "ArrowBendRightDown", "ArrowBendRightUp", "ArrowBendUpLeft", "ArrowBendUpRight", "ArrowCircleDown", "ArrowCircleDownLeft", "ArrowCircleDownRight", "ArrowCircleLeft", "ArrowCircleRight", "ArrowCircleUp", "ArrowCircleUpLeft", "ArrowCircleUpRight", "ArrowClockwise", "ArrowDown", "ArrowDownLeft", "ArrowDownRight", "ArrowElbowDownLeft", "ArrowElbowDownRight", "ArrowElbowLeft", "ArrowElbowLeftDown", "ArrowElbowLeftUp", "ArrowElbowRight", "ArrowElbowRightDown", "ArrowElbowRightUp", "ArrowElbowUpLeft", "ArrowElbowUpRight", "ArrowFatDown", "ArrowFatLeft", "ArrowFatLineDown", "ArrowFatLineLeft", "ArrowFatLineRight", "ArrowFatLineUp", "ArrowFatLinesDown", "ArrowFatLinesLeft", "ArrowFatLinesRight", "ArrowFatLinesUp", "ArrowFatRight", "ArrowFatUp", "ArrowLeft", "ArrowLineDown", "ArrowLineDownLeft", "ArrowLineDownRight", "ArrowLineLeft", "ArrowLineRight", "ArrowLineUp", "ArrowLineUpLeft", "ArrowLineUpRight", "ArrowRight", "ArrowSquareDown", "ArrowSquareDownLeft", "ArrowSquareDownRight", "ArrowSquareIn", "ArrowSquareLeft", "ArrowSquareOut", "ArrowSquareRight", "ArrowSquareUp", "ArrowSquareUpLeft", "ArrowSquareUpRight", "ArrowUDownLeft", "ArrowUDownRight", "ArrowULeftDown", "ArrowULeftUp", "ArrowURightDown", "ArrowURightUp", "ArrowUUpLeft", "ArrowUUpRight", "ArrowUp", "ArrowUpLeft", "ArrowUpRight", "ArrowsClockwise", "ArrowsDownUp", "ArrowsHorizontal", "ArrowsIn", "ArrowsInCardinal", "ArrowsInLineVertical", "ArrowsInSimple", "ArrowsLeftRight", "ArrowsMerge", "ArrowsOut", "ArrowsOutCardinal", "ArrowsOutSimple", "ArrowsSplit", "ArrowsVertical", "Article", "ArticleMedium", "ArticleNyTimes", "Asterisk", "AsteriskSimple", "At", "Atom", "Baby", "Backpack", "Backspace", "Bag", "BagSimple", "Balloon", "Bandaids", "Bank", "Barbell", "Barcode", "Barricade", "Baseball", "BaseballCap", "Basket", "Basketball", "Bathtub", "BatteryCharging", "BatteryEmpty", "BatteryFull", "BatteryHigh", "BatteryLow", "BatteryMedium", "BatteryPlus", "BatteryPlusVertical", "BatteryVerticalEmpty", "BatteryVerticalFull", "BatteryVerticalHigh", "BatteryVerticalLow", "BatteryWarning", "Bed", "BeerBottle", "BeerStein", "BehanceLogo", "Bell", "BellRinging", "BellSimple", "BellSimpleRinging", "BellSimpleSlash", "BellSimpleZ", "BellSlash", "BellZ", "BezierCurve", "Bicycle", "Binoculars", "Bird", "Bluetooth", "BluetoothConnected", "BluetoothSlash", "BluetoothX", "Boat", "Bone", "Book", "BookBookmark", "BookOpen", "BookOpenText", "Bookmark", "BookmarkSimple", "Bookmarks", "BookmarksSimple", "Books", "Boot", "BoundingBox", "BowlFood", "BracketsAngle", "BracketsCurly", "BracketsRound", "BracketsSquare", "Brain", "Brandy", "Bridge", "Briefcase", "BriefcaseMetal", "Broadcast", "Broom", "Browser", "Browsers", "Bug", "BugBeetle", "BugDroid", "Buildings", "Bus", "Butterfly", "Cactus", "Cake", "Calculator", "Calendar", "CalendarBlank", "CalendarCheck", "CalendarPlus", "CalendarX", "CallBell", "Camera", "CameraPlus", "CameraRotate", "CameraSlash", "Campfire", "Car", "CarProfile", "CarSimple", "Cardholder", "Cards", "CaretCircleDoubleUp", "CaretCircleDown", "CaretCircleLeft", "CaretCircleRight", "CaretCircleUp", "CaretCircleUpDown", "CaretDoubleDown", "CaretDoubleLeft", "CaretDoubleRight", "CaretDoubleUp", "CaretDown", "CaretLeft", "CaretRight", "CaretUp", "CaretUpDown", "Carrot", "CassetteTape", "CastleTurret", "Cat", "CellSignalFull", "CellSignalHigh", "CellSignalLow", "CellSignalMedium", "CellSignalNone", "CellSignalSlash", "CellSignalX", "Certificate", "Chair", "Chalkboard", "ChalkboardSimple", "ChalkboardTeacher", "Champagne", "ChargingStation", "ChartBar", "ChartBarHorizontal", "ChartDonut", "ChartLine", "ChartLineDown", "ChartLineUp", "ChartPie", "ChartPieSlice", "ChartPolar", "ChartScatter", "Chat", "ChatCentered", "ChatCenteredDots", "ChatCenteredText", "ChatCircle", "ChatCircleDots", "ChatCircleText", "ChatDots", "ChatTeardrop", "ChatTeardropDots", "ChatTeardropText", "ChatText", "Chats", "ChatsCircle", "ChatsTeardrop", "Check", "CheckCircle", "CheckFat", "CheckSquare", "CheckSquareOffset", "Checks", "Church", "Circle", "CircleDashed", "CircleHalf", "CircleHalfTilt", "CircleNotch", "CirclesFour", "CirclesThree", "CirclesThreePlus", "Circuitry", "Clipboard", "ClipboardText", "Clock", "ClockAfternoon", "ClockClockwise", "ClockCounterClockwise", "ClockCountdown", "ClosedCaptioning", "Cloud", "CloudArrowDown", "CloudArrowUp", "CloudCheck", "CloudFog", "CloudLightning", "CloudMoon", "CloudRain", "CloudSlash", "CloudSnow", "CloudSun", "CloudWarning", "CloudX", "Club", "CoatHanger", "CodaLogo", "Code", "CodeBlock", "CodeSimple", "CodepenLogo", "CodesandboxLogo", "Coffee", "Coin", "CoinVertical", "Coins", "Columns", "Command", "Compass", "CompassTool", "ComputerTower", "Confetti", "ContactlessPayment", "Control", "Cookie", "CookingPot", "Copy", "CopySimple", "Copyleft", "Copyright", "CornersIn", "CornersOut", "Couch", "Cpu", "CreditCard", "Crop", "Cross", "Crosshair", "CrosshairSimple", "Crown", "CrownSimple", "Cube", "CubeFocus", "CubeTransparent", "CurrencyBtc", "CurrencyCircleDollar", "CurrencyCny", "CurrencyDollar", "CurrencyDollarSimple", "CurrencyEth", "CurrencyEur", "CurrencyGbp", "CurrencyInr", "CurrencyJpy", "CurrencyKrw", "CurrencyKzt", "CurrencyNgn", "CurrencyRub", "Cursor", "CursorClick", "CursorText", "Cylinder", "Database", "Desktop", "DesktopTower", "Detective", "DevToLogo", "DeviceMobile", "DeviceMobileCamera", "DeviceMobileSpeaker", "DeviceTablet", "DeviceTabletCamera", "DeviceTabletSpeaker", "Devices", "Diamond", "DiamondsFour", "DiceFive", "DiceFour", "DiceOne", "DiceSix", "DiceThree", "DiceTwo", "Disc", "DiscordLogo", "Divide", "Dna", "Dog", "Door", "DoorOpen", "Dot", "DotOutline", "DotsNine", "DotsSix", "DotsSixVertical", "DotsThree", "DotsThreeCircle", "DotsThreeOutline", "DotsThreeVertical", "Download", "DownloadSimple", "Dress", "DribbbleLogo", "Drop", "DropHalf", "DropHalfBottom", "DropboxLogo", "Ear", "EarSlash", "Egg", "EggCrack", "Eject", "EjectSimple", "Elevator", "Engine", "Envelope", "EnvelopeOpen", "EnvelopeSimple", "EnvelopeSimpleOpen", "Equalizer", "Equals", "Eraser", "EscalatorDown", "EscalatorUp", "Exam", "Exclude", "ExcludeSquare", "Export", "Eye", "EyeClosed", "EyeSlash", "Eyedropper", "EyedropperSample", "Eyeglasses", "FaceMask", "FacebookLogo", "Factory", "Faders", "FadersHorizontal", "Fan", "FastForward", "FastForwardCircle", "Feather", "FigmaLogo", "File", "FileArchive", "FileArrowDown", "FileArrowUp", "FileAudio", "FileCloud", "FileCode", "FileCss", "FileCsv", "FileDashed", "FileDoc", "FileHtml", "FileImage", "FileJpg", "FileJs", "FileJsx", "FileLock", "FileMagnifyingGlass", "FileMinus", "FilePdf", "FilePlus", "FilePng", "FilePpt", "FileRs", "FileSql", "FileSvg", "FileText", "FileTs", "FileTsx", "FileVideo", "FileVue", "FileX", "FileXls", "FileZip", "Files", "FilmReel", "FilmScript", "FilmSlate", "FilmStrip", "Fingerprint", "FingerprintSimple", "FinnTheHuman", "Fire", "FireExtinguisher", "FireSimple", "FirstAid", "FirstAidKit", "Fish", "FishSimple", "Flag", "FlagBanner", "FlagCheckered", "FlagPennant", "Flame", "Flashlight", "Flask", "FloppyDisk", "FloppyDiskBack", "FlowArrow", "Flower", "FlowerLotus", "FlowerTulip", "FlyingSaucer", "Folder", "FolderDashed", "FolderLock", "FolderMinus", "FolderNotch", "FolderNotchMinus", "FolderNotchOpen", "FolderNotchPlus", "FolderOpen", "FolderPlus", "FolderSimple", "FolderSimpleDashed", "FolderSimpleLock", "FolderSimpleMinus", "FolderSimplePlus", "FolderSimpleStar", "FolderSimpleUser", "FolderStar", "FolderUser", "Folders", "Football", "Footprints", "ForkKnife", "FrameCorners", "FramerLogo", "Function", "Funnel", "FunnelSimple", "GameController", "Garage", "GasCan", "GasPump", "Gauge", "Gavel", "Gear", "GearFine", "GearSix", "GenderFemale", "GenderIntersex", "GenderMale", "GenderNeuter", "GenderNonbinary", "GenderTransgender", "Ghost", "Gif", "Gift", "GitBranch", "GitCommit", "GitDiff", "GitFork", "GitMerge", "GitPullRequest", "GithubLogo", "GitlabLogo", "GitlabLogoSimple", "Globe", "GlobeHemisphereEast", "GlobeHemisphereWest", "GlobeSimple", "GlobeStand", "Goggles", "GoodreadsLogo", "GoogleCardboardLogo", "GoogleChromeLogo", "GoogleDriveLogo", "GoogleLogo", "GooglePhotosLogo", "GooglePlayLogo", "GooglePodcastsLogo", "Gradient", "GraduationCap", "Grains", "GrainsSlash", "Graph", "GridFour", "GridNine", "Guitar", "Hamburger", "Hammer", "Hand", "HandCoins", "HandEye", "HandFist", "HandGrabbing", "HandHeart", "HandPalm", "HandPointing", "HandSoap", "HandSwipeLeft", "HandSwipeRight", "HandTap", "HandWaving", "Handbag", "HandbagSimple", "HandsClapping", "HandsPraying", "Handshake", "HardDrive", "HardDrives", "Hash", "HashStraight", "Headlights", "Headphones", "Headset", "Heart", "HeartBreak", "HeartHalf", "HeartStraight", "HeartStraightBreak", "Heartbeat", "Hexagon", "HighHeel", "HighlighterCircle", "Hoodie", "Horse", "Hourglass", "HourglassHigh", "HourglassLow", "HourglassMedium", "HourglassSimple", "HourglassSimpleHigh", "HourglassSimpleLow", "House", "HouseLine", "HouseSimple", "IceCream", "IdentificationBadge", "IdentificationCard", "Image", "ImageSquare", "Images", "ImagesSquare", "Infinity", "Info", "InstagramLogo", "Intersect", "IntersectSquare", "IntersectThree", "Jeep", "Kanban", "Key", "KeyReturn", "Keyboard", "Keyhole", "Knife", "Ladder", "LadderSimple", "Lamp", "Laptop", "Layout", "Leaf", "Lifebuoy", "Lightbulb", "LightbulbFilament", "Lighthouse", "Lightning", "LightningA", "LightningSlash", "LineSegment", "LineSegments", "Link", "LinkBreak", "LinkSimple", "LinkSimpleBreak", "LinkSimpleHorizontal", "LinkedinLogo", "LinuxLogo", "List", "ListBullets", "ListChecks", "ListDashes", "ListMagnifyingGlass", "ListNumbers", "ListPlus", "Lock", "LockKey", "LockKeyOpen", "LockLaminated", "LockLaminatedOpen", "LockOpen", "LockSimple", "LockSimpleOpen", "Lockers", "MagicWand", "Magnet", "MagnetStraight", "MagnifyingGlass", "MagnifyingGlassMinus", "MagnifyingGlassPlus", "MapPin", "MapPinLine", "MapTrifold", "MarkerCircle", "Martini", "MaskHappy", "MaskSad", "MathOperations", "Medal", "MedalMilitary", "MediumLogo", "Megaphone", "MegaphoneSimple", "MessengerLogo", "MetaLogo", "Metronome", "Microphone", "MicrophoneSlash", "MicrophoneStage", "MicrosoftExcelLogo", "MicrosoftOutlookLogo", "MicrosoftTeamsLogo", "MicrosoftWordLogo", "Minus", "MinusCircle", "MinusSquare", "Money", "Monitor", "MonitorPlay", "Moon", "MoonStars", "Moped", "MopedFront", "Mosque", "Motorcycle", "Mountains", "Mouse", "MouseSimple", "MusicNote", "MusicNoteSimple", "MusicNotes", "MusicNotesPlus", "MusicNotesSimple", "NavigationArrow", "Needle", "Newspaper", "NewspaperClipping", "Notches", "Note", "NoteBlank", "NotePencil", "Notebook", "Notepad", "Notification", "NotionLogo", "NumberCircleEight", "NumberCircleFive", "NumberCircleFour", "NumberCircleNine", "NumberCircleOne", "NumberCircleSeven", "NumberCircleSix", "NumberCircleThree", "NumberCircleTwo", "NumberCircleZero", "NumberEight", "NumberFive", "NumberFour", "NumberNine", "NumberOne", "NumberSeven", "NumberSix", "NumberSquareEight", "NumberSquareFive", "NumberSquareFour", "NumberSquareNine", "NumberSquareOne", "NumberSquareSeven", "NumberSquareSix", "NumberSquareThree", "NumberSquareTwo", "NumberSquareZero", "NumberThree", "NumberTwo", "NumberZero", "Nut", "NyTimesLogo", "Octagon", "OfficeChair", "Option", "OrangeSlice", "Package", "PaintBrush", "PaintBrushBroad", "PaintBrushHousehold", "PaintBucket", "PaintRoller", "Palette", "Pants", "PaperPlane", "PaperPlaneRight", "PaperPlaneTilt", "Paperclip", "PaperclipHorizontal", "Parachute", "Paragraph", "Parallelogram", "Park", "Password", "Path", "PatreonLogo", "Pause", "PauseCircle", "PawPrint", "PaypalLogo", "Peace", "Pen", "PenNib", "PenNibStraight", "Pencil", "PencilCircle", "PencilLine", "PencilSimple", "PencilSimpleLine", "PencilSimpleSlash", "PencilSlash", "Pentagram", "Pepper", "Percent", "Person", "PersonArmsSpread", "PersonSimple", "PersonSimpleBike", "PersonSimpleRun", "PersonSimpleThrow", "PersonSimpleWalk", "Perspective", "Phone", "PhoneCall", "PhoneDisconnect", "PhoneIncoming", "PhoneOutgoing", "PhonePlus", "PhoneSlash", "PhoneX", "PhosphorLogo", "Pi", "PianoKeys", "PictureInPicture", "PiggyBank", "Pill", "PinterestLogo", "Pinwheel", "Pizza", "Placeholder", "Planet", "Plant", "Play", "PlayCircle", "PlayPause", "Playlist", "Plug", "PlugCharging", "Plugs", "PlugsConnected", "Plus", "PlusCircle", "PlusMinus", "PlusSquare", "PokerChip", "PoliceCar", "Polygon", "Popcorn", "PottedPlant", "Power", "Prescription", "Presentation", "PresentationChart", "Printer", "Prohibit", "ProhibitInset", "ProjectorScreen", "ProjectorScreenChart", "Pulse", "PushPin", "PushPinSimple", "PushPinSimpleSlash", "PushPinSlash", "PuzzlePiece", "QrCode", "Question", "Queue", "Quotes", "Radical", "Radio", "RadioButton", "Radioactive", "Rainbow", "RainbowCloud", "ReadCvLogo", "Receipt", "ReceiptX", "Record", "Rectangle", "Recycle", "RedditLogo", "Repeat", "RepeatOnce", "Rewind", "RewindCircle", "RoadHorizon", "Robot", "Rocket", "RocketLaunch", "Rows", "Rss", "RssSimple", "Rug", "Ruler", "Scales", "Scan", "Scissors", "Scooter", "Screencast", "ScribbleLoop", "Scroll", "Seal", "SealCheck", "SealQuestion", "SealWarning", "Selection", "SelectionAll", "SelectionBackground", "SelectionForeground", "SelectionInverse", "SelectionPlus", "SelectionSlash", "Shapes", "Share", "ShareFat", "ShareNetwork", "Shield", "ShieldCheck", "ShieldCheckered", "ShieldChevron", "ShieldPlus", "ShieldSlash", "ShieldStar", "ShieldWarning", "ShirtFolded", "ShootingStar", "ShoppingBag", "ShoppingBagOpen", "ShoppingCart", "ShoppingCartSimple", "Shower", "Shrimp", "Shuffle", "ShuffleAngular", "ShuffleSimple", "Sidebar", "SidebarSimple", "Sigma", "SignIn", "SignOut", "Signature", "Signpost", "SimCard", "Siren", "SketchLogo", "SkipBack", "SkipBackCircle", "SkipForward", "SkipForwardCircle", "Skull", "SlackLogo", "Sliders", "SlidersHorizontal", "Slideshow", "Smiley", "SmileyAngry", "SmileyBlank", "SmileyMeh", "SmileyNervous", "SmileySad", "SmileySticker", "SmileyWink", "SmileyXEyes", "SnapchatLogo", "Sneaker", "SneakerMove", "Snowflake", "SoccerBall", "SortAscending", "SortDescending", "SoundcloudLogo", "Spade", "Sparkle", "SpeakerHifi", "SpeakerHigh", "SpeakerLow", "SpeakerNone", "SpeakerSimpleHigh", "SpeakerSimpleLow", "SpeakerSimpleNone", "SpeakerSimpleSlash", "SpeakerSimpleX", "SpeakerSlash", "SpeakerX", "Spinner", "SpinnerGap", "Spiral", "SplitHorizontal", "SplitVertical", "SpotifyLogo", "Square", "SquareHalf", "SquareHalfBottom", "SquareLogo", "SquareSplitVertical", "SquaresFour", "Stack", "StackOverflowLogo", "StackSimple", "Stairs", "Stamp", "Star", "StarAndCrescent", "StarFour", "StarHalf", "StarOfDavid", "SteeringWheel", "Steps", "Stethoscope", "Sticker", "Stool", "Stop", "StopCircle", "Storefront", "Strategy", "StripeLogo", "Student", "Subtitles", "Subtract", "SubtractSquare", "Suitcase", "SuitcaseRolling", "SuitcaseSimple", "Sun", "SunDim", "SunHorizon", "Sunglasses", "Swap", "Swatches", "SwimmingPool", "Sword", "Synagogue", "Syringe", "TShirt", "Table", "Tabs", "Tag", "TagChevron", "TagSimple", "Target", "Taxi", "TelegramLogo", "Television", "TelevisionSimple", "TennisBall", "Tent", "Terminal", "TerminalWindow", "TestTube", "TextAUnderline", "TextAa", "TextAlignCenter", "TextAlignJustify", "TextAlignLeft", "TextAlignRight", "TextB", "TextColumns", "TextH", "TextHFive", "TextHFour", "TextHOne", "TextHSix", "TextHThree", "TextHTwo", "TextIndent", "TextItalic", "TextOutdent", "TextStrikethrough", "TextT", "TextUnderline", "Textbox", "Thermometer", "ThermometerCold", "ThermometerHot", "ThermometerSimple", "ThumbsDown", "ThumbsUp", "Ticket", "TidalLogo", "TiktokLogo", "Timer", "Tipi", "ToggleLeft", "ToggleRight", "Toilet", "ToiletPaper", "Toolbox", "Tooth", "Tote", "ToteSimple", "Trademark", "TrademarkRegistered", "TrafficCone", "TrafficSign", "TrafficSignal", "Train", "TrainRegional", "TrainSimple", "Tram", "Translate", "Trash", "TrashSimple", "Tray", "Tree", "TreeEvergreen", "TreePalm", "TreeStructure", "TrendDown", "TrendUp", "Triangle", "Trophy", "Truck", "TwitchLogo", "TwitterLogo", "Umbrella", "UmbrellaSimple", "Unite", "UniteSquare", "Upload", "UploadSimple", "Usb", "User", "UserCircle", "UserCircleGear", "UserCircleMinus", "UserCirclePlus", "UserFocus", "UserGear", "UserList", "UserMinus", "UserPlus", "UserRectangle", "UserSquare", "UserSwitch", "Users", "UsersFour", "UsersThree", "Van", "Vault", "Vibrate", "Video", "VideoCamera", "VideoCameraSlash", "Vignette", "VinylRecord", "VirtualReality", "Virus", "Voicemail", "Volleyball", "Wall", "Wallet", "Warehouse", "Warning", "WarningCircle", "WarningDiamond", "WarningOctagon", "Watch", "WaveSawtooth", "WaveSine", "WaveSquare", "WaveTriangle", "Waveform", "Waves", "Webcam", "WebcamSlash", "WebhooksLogo", "WechatLogo", "WhatsappLogo", "Wheelchair", "WheelchairMotion", "WifiHigh", "WifiLow", "WifiMedium", "WifiNone", "WifiSlash", "WifiX", "Wind", "WindowsLogo", "Wine", "Wrench", "X", "XCircle", "XSquare", "YinYang", "YoutubeLogo"];
var moduleBaseUrl = "https://framer.com/m/phosphor-icons/";
var weightOptions = ["thin", "light", "regular", "bold", "fill", "duotone"];
var lowercaseIconKeyPairs = iconKeys.reduce((res, key) => {
  res[key.toLowerCase()] = key;
  return res;
}, {});
function Icon(props) {
  const { color, selectByList, iconSearch, iconSelection, onClick, onMouseDown, onMouseUp, onMouseEnter, onMouseLeave, weight, mirrored } = props;
  const isMounted = useRef2(false);
  const iconKey = useIconSelection(iconKeys, selectByList, iconSearch, iconSelection, lowercaseIconKeyPairs);
  const [SelectedIcon, setSelectedIcon] = useState(iconKey === "Home" ? House_default(React2) : null);
  async function importModule() {
    try {
      const version = "0.0.53";
      const iconModuleUrl = `${moduleBaseUrl}${iconKey}.js@${version}`;
      const module = await import(
        /* webpackIgnore: true */
        iconModuleUrl
      );
      if (isMounted.current)
        setSelectedIcon(module.default(React2));
    } catch (err) {
      if (isMounted.current)
        setSelectedIcon(null);
    }
  }
  useEffect2(() => {
    isMounted.current = true;
    importModule();
    return () => {
      isMounted.current = false;
    };
  }, [iconKey]);
  const isOnCanvas = RenderTarget2.current() === RenderTarget2.canvas;
  const emptyState = isOnCanvas ? /* @__PURE__ */ _jsx3(NullState, {}) : null;
  return /* @__PURE__ */ _jsx3(motion.div, { style: { display: "contents" }, onClick, onMouseEnter, onMouseLeave, onMouseDown, onMouseUp, children: SelectedIcon ? /* @__PURE__ */ _jsx3("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 256 256", style: { userSelect: "none", width: "100%", height: "100%", display: "inline-block", fill: color, color, flexShrink: 0, transform: mirrored ? "scale(-1, 1)" : void 0 }, focusable: "false", color, children: /* @__PURE__ */ _jsx3(SelectedIcon, { color, weight }) }) : emptyState });
}
Icon.displayName = "Phosphor";
Icon.defaultProps = { width: 24, height: 24, iconSelection: "House", iconSearch: "House", color: "#66F", selectByList: true, weight: "regular", mirrored: false };
addPropertyControls2(Icon, { selectByList: { type: ControlType3.Boolean, title: "Select", enabledTitle: "List", disabledTitle: "Search", defaultValue: Icon.defaultProps.selectByList }, iconSelection: { type: ControlType3.Enum, options: iconKeys, defaultValue: Icon.defaultProps.iconSelection, title: "Name", hidden: ({ selectByList }) => !selectByList, description: "Find every icon name on the [Phosphor site](https://phosphoricons.com/)" }, iconSearch: { type: ControlType3.String, title: "Name", placeholder: "Menu, Wifi, Box\u2026", hidden: ({ selectByList }) => selectByList }, color: { type: ControlType3.Color, title: "Color", defaultValue: Icon.defaultProps.color }, weight: { type: ControlType3.Enum, title: "Weight", optionTitles: weightOptions.map((piece) => piece.charAt(0).toUpperCase() + piece.slice(1)), options: weightOptions, defaultValue: Icon.defaultProps.weight }, mirrored: { type: ControlType3.Boolean, enabledTitle: "Yes", disabledTitle: "No", defaultValue: Icon.defaultProps.mirrored }, ...defaultEvents });

// http-url:https://framerusercontent.com/modules/e5csMEzVMvyGeOFddcwF/bkDsGVlZSB4xGhsliwpY/EIB3gUiL9.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["FS;Manrope-medium", "FS;Manrope-bold"]);
var fonts = [{ explicitInter: true, fonts: [{ family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/BNWG6MUI4RTC6WEND2VPDH4MHMIVU3XZ/R5YXY5FMVG6PXU36GNEEA24MIPMEPGSM/CIM4KQCLZSMMLWPVH25IDDSTY4ENPHEY.woff2", weight: "500" }, { family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/NGBUP45ES3F7RD5XGKPEDJ6QEPO4TMOK/EXDVWJ2EDDVVV65UENMX33EDDYBX6OF7/6P4FPMFQH7CCC7RZ4UU4NKSGJ2RLF7V5.woff2", weight: "700" }] }];
var css = ['.framer-ST0ew .framer-styles-preset-7kxp10:not(.rich-text-wrapper), .framer-ST0ew .framer-styles-preset-7kxp10.rich-text-wrapper h4 { --framer-font-family: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-family-bold: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 22px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.2px; --framer-line-height: 140%; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, #101014); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }', '@media (max-width: 1199px) and (min-width: 810px) { .framer-ST0ew .framer-styles-preset-7kxp10:not(.rich-text-wrapper), .framer-ST0ew .framer-styles-preset-7kxp10.rich-text-wrapper h4 { --framer-font-family: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-family-bold: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 20px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.2px; --framer-line-height: 140%; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, #101014); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }', '@media (max-width: 809px) and (min-width: 0px) { .framer-ST0ew .framer-styles-preset-7kxp10:not(.rich-text-wrapper), .framer-ST0ew .framer-styles-preset-7kxp10.rich-text-wrapper h4 { --framer-font-family: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-family-bold: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 16px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.2px; --framer-line-height: 140%; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, #101014); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }'];
var className = "framer-ST0ew";

// http-url:https://framerusercontent.com/modules/qjwWyZAhQ2DdHfZKkq1t/LkUA5NmWbauWe1EWiyh8/kTR3NcFcQ.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["FS;Manrope-regular", "FS;Manrope-bold"]);
var fonts2 = [{ explicitInter: true, fonts: [{ family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/2TYFCBHUANEXS6QGR5EQDUNAFH6LSWM3/AYNOU3VEA4LRTDNKJQUFNVNUTYSGOUOP/UXO4O7K2G3HI3D2VKD7UXVJVJD26P4BQ.woff2", weight: "400" }, { family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/NGBUP45ES3F7RD5XGKPEDJ6QEPO4TMOK/EXDVWJ2EDDVVV65UENMX33EDDYBX6OF7/6P4FPMFQH7CCC7RZ4UU4NKSGJ2RLF7V5.woff2", weight: "700" }] }];
var css2 = ['.framer-8WwI9 .framer-styles-preset-a0z0u0:not(.rich-text-wrapper), .framer-8WwI9 .framer-styles-preset-a0z0u0.rich-text-wrapper p { --framer-font-family: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-family-bold: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.1px; --framer-line-height: 150%; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-30e48027-3b22-4ff1-a546-6bd64e851575, #3d3d47); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className2 = "framer-8WwI9";

// http-url:https://framerusercontent.com/modules/rJwfYW3tiv3bguXPhHNW/1g8it0BdqggXzdUCAl6c/XOSkZc1rZ.js
var PhosphorFonts = getFonts(Icon);
var cycleOrder = ["R7PMRdpwD", "beuBFBnz9"];
var serializationHash = "framer-0Rafs";
var variantClassNames = { beuBFBnz9: "framer-v-1gn2xws", R7PMRdpwD: "framer-v-mgdn5q" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0, delay: 0, duration: 0.6, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion2.create(React3.Fragment);
var humanReadableVariantMap = { Closed: "beuBFBnz9", Open: "R7PMRdpwD" };
var getProps = ({ click, height, id, text, title, width, ...props }) => {
  return { ...props, AGXgjlkUg: text ?? props.AGXgjlkUg ?? "We primarily serve London and surrounding areas, but depending on the project, we may be able to travel further. Get in touch to discuss your location and project needs.", fbMdJnqyQ: title ?? props.fbMdJnqyQ ?? "Accordion title", Q0WMNUDZo: click ?? props.Q0WMNUDZo, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "R7PMRdpwD" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef3(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className3, layoutId, variant, fbMdJnqyQ, Q0WMNUDZo, AGXgjlkUg, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "R7PMRdpwD", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTapfve7xc = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    if (Q0WMNUDZo) {
      const res = await Q0WMNUDZo(...args);
      if (res === false)
        return false;
    }
    setVariant("beuBFBnz9");
  });
  const onTappp2tny = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    if (Q0WMNUDZo) {
      const res = await Q0WMNUDZo(...args);
      if (res === false)
        return false;
    }
  });
  const onTapyioikh = activeVariantCallback(async (...args) => {
    setVariant("beuBFBnz9");
  });
  const onTap1bp9ojb = activeVariantCallback(async (...args) => {
    setVariant("R7PMRdpwD");
  });
  const sharedStyleClassNames = [className, className2];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx4(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion2.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-mgdn5q", className3, classNames), "data-border": true, "data-framer-name": "Open", "data-highlight": true, layoutDependency, layoutId: "FAQs__R7PMRdpwD", onTap: onTapfve7xc, ref: refBinding, style: { "--border-bottom-width": "1px", "--border-color": "var(--token-138c6083-e907-40e8-909c-96eb16f3a3a3, rgb(230, 230, 230))", "--border-left-width": "1px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "1px", backgroundColor: "var(--token-de8da503-8d4d-4351-82a9-63caea8f9e9c, rgb(250, 250, 250))", borderBottomLeftRadius: 10, borderBottomRightRadius: 10, borderTopLeftRadius: 10, borderTopRightRadius: 10, ...style }, ...addPropertyOverrides({ beuBFBnz9: { "data-framer-name": "Closed", onTap: onTappp2tny } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs(motion2.div, { className: "framer-1kz8tkl", "data-framer-name": "Title", "data-highlight": true, layoutDependency, layoutId: "FAQs__ujZWfTiLz", onTap: onTapyioikh, ...addPropertyOverrides({ beuBFBnz9: { onTap: onTap1bp9ojb } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx4(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React3.Fragment, { children: /* @__PURE__ */ _jsx4(motion2.h4, { className: "framer-styles-preset-7kxp10", "data-styles-preset": "EIB3gUiL9", children: "Accordion title" }) }), className: "framer-7ndo85", fonts: ["Inter"], layoutDependency, layoutId: "FAQs__afRvE3rdj", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: fbMdJnqyQ, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx4(motion2.div, { className: "framer-1m95kvk", "data-framer-name": "Spacer", layoutDependency, layoutId: "FAQs__CY7l567wL" }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-d971ov-container", isModuleExternal: true, layoutDependency, layoutId: "FAQs__b8foBRdXI-container", nodeId: "b8foBRdXI", rendersWithMotion: true, scopeId: "XOSkZc1rZ", style: { rotate: 45 }, variants: { beuBFBnz9: { rotate: 0 } }, children: /* @__PURE__ */ _jsx4(Icon, { color: "var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, rgb(16, 16, 20))", height: "100%", iconSearch: "House", iconSelection: "Plus", id: "b8foBRdXI", layoutId: "FAQs__b8foBRdXI", mirrored: false, selectByList: true, style: { height: "100%", width: "100%" }, weight: "regular", width: "100%" }) }) })] }), /* @__PURE__ */ _jsx4(motion2.div, { className: "framer-2p4gc7", "data-framer-name": "Content", layoutDependency, layoutId: "FAQs__VJ8woFwwP", style: { opacity: 1 }, variants: { beuBFBnz9: { opacity: 0 } }, children: /* @__PURE__ */ _jsx4(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React3.Fragment, { children: /* @__PURE__ */ _jsx4(motion2.p, { className: "framer-styles-preset-a0z0u0", "data-styles-preset": "kTR3NcFcQ", children: "We primarily serve London and surrounding areas, but depending on the project, we may be able to travel further. Get in touch to discuss your location and project needs." }) }), className: "framer-1qg5dc5", fonts: ["Inter"], layoutDependency, layoutId: "FAQs__fOJ07bAr_", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: AGXgjlkUg, verticalAlignment: "top", withExternalLayout: true }) })] }) }) }) });
});
var css3 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-0Rafs.framer-1ii9ykh, .framer-0Rafs .framer-1ii9ykh { display: block; }", ".framer-0Rafs.framer-mgdn5q { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; overflow: hidden; padding: 0px 25px 0px 25px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-0Rafs .framer-1kz8tkl { align-content: center; align-items: center; cursor: pointer; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; height: min-content; justify-content: space-between; overflow: hidden; padding: 20px 0px 20px 0px; position: relative; width: 100%; }", ".framer-0Rafs .framer-7ndo85 { flex: 1 0 0px; height: auto; position: relative; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; }", ".framer-0Rafs .framer-1m95kvk { align-self: stretch; flex: none; height: auto; overflow: visible; position: relative; width: 20px; }", ".framer-0Rafs .framer-d971ov-container { flex: none; height: 24px; position: relative; width: 24px; }", ".framer-0Rafs .framer-2p4gc7 { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; overflow: hidden; padding: 0px 20px 30px 0px; position: relative; width: 100%; }", ".framer-0Rafs .framer-1qg5dc5 { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", "@supports (background: -webkit-named-image(i)) and (not (font-palette:dark)) { .framer-0Rafs.framer-mgdn5q, .framer-0Rafs .framer-2p4gc7 { gap: 0px; } .framer-0Rafs.framer-mgdn5q > *, .framer-0Rafs .framer-2p4gc7 > * { margin: 0px; margin-bottom: calc(0px / 2); margin-top: calc(0px / 2); } .framer-0Rafs.framer-mgdn5q > :first-child, .framer-0Rafs .framer-2p4gc7 > :first-child { margin-top: 0px; } .framer-0Rafs.framer-mgdn5q > :last-child, .framer-0Rafs .framer-2p4gc7 > :last-child { margin-bottom: 0px; } }", ".framer-0Rafs.framer-v-1gn2xws .framer-2p4gc7 { left: 25px; pointer-events: none; position: absolute; right: 25px; top: 71px; width: unset; z-index: 1; }", ...css, ...css2, '.framer-0Rafs[data-border="true"]::after, .framer-0Rafs [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; pointer-events: none; }'];
var FramerXOSkZc1rZ = withCSS(Component2, css3, "framer-0Rafs");
var XOSkZc1rZ_default = FramerXOSkZc1rZ;
FramerXOSkZc1rZ.displayName = "FAQs Row";
FramerXOSkZc1rZ.defaultProps = { height: 155, width: 1280 };
addPropertyControls3(FramerXOSkZc1rZ, { variant: { options: ["R7PMRdpwD", "beuBFBnz9"], optionTitles: ["Open", "Closed"], title: "Variant", type: ControlType4.Enum }, fbMdJnqyQ: { defaultValue: "Accordion title", displayTextArea: true, title: "Title", type: ControlType4.String }, Q0WMNUDZo: { title: "Click", type: ControlType4.EventHandler }, AGXgjlkUg: { defaultValue: "We primarily serve London and surrounding areas, but depending on the project, we may be able to travel further. Get in touch to discuss your location and project needs.", displayTextArea: true, title: "Text", type: ControlType4.String } });
addFonts(FramerXOSkZc1rZ, [{ explicitInter: true, fonts: [{ family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/vQyevYAyHtARFwPqUzQGpnDs.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...PhosphorFonts, ...getFontsFromSharedStyle(fonts), ...getFontsFromSharedStyle(fonts2)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/xJAwMon2Gk8Nufg941lB/Ya9fvzOibpynYyFlz6Xt/SofTjBAi7.js
var LayoutJumpPreventerFonts = getFonts2(AvoidLayoutJumping);
var FAQsRowFonts = getFonts2(XOSkZc1rZ_default);
var serializationHash2 = "framer-Z2zQ8";
var variantClassNames2 = { CeynA5A8W: "framer-v-11g4kga" };
var transition12 = { damping: 60, delay: 0, mass: 1, stiffness: 500, type: "spring" };
var transformTemplate1 = (_, t) => `translateX(-50%) ${t}`;
var Transition2 = ({ value, children }) => {
  const config = React4.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React4.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx5(MotionConfigContext2.Provider, { value: contextValue, children });
};
var Variants2 = motion3.create(React4.Fragment);
var getProps2 = ({ height, id, width, ...props }) => {
  return { ...props };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React4.forwardRef(function(props, ref) {
  const fallbackRef = useRef4(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React4.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className: className3, layoutId, variant, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ defaultVariant: "CeynA5A8W", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback2(baseVariant);
  const Q0WMNUDZo1hs7f9c = activeVariantCallback(async (...args) => {
    setVariant("CeynA5A8W");
  });
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash2, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx5(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx5(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx5(Transition2, { value: transition12, children: /* @__PURE__ */ _jsxs2(motion3.div, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-11g4kga", className3, classNames), "data-framer-name": "FAQs", layoutDependency, layoutId: "FAQs__CeynA5A8W", ref: refBinding, style: { ...style }, children: [/* @__PURE__ */ _jsx5(ComponentViewportProvider2, { children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-1bqx23h-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "FAQs__MdhRhV6Kj-container", nodeId: "MdhRhV6Kj", rendersWithMotion: true, scopeId: "SofTjBAi7", transformTemplate: transformTemplate1, children: /* @__PURE__ */ _jsx5(AvoidLayoutJumping, { direction: "vertical", height: "100%", id: "MdhRhV6Kj", layoutId: "FAQs__MdhRhV6Kj", width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 155, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + 0, children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-cp77le-container", layoutDependency, layoutId: "FAQs__YFTTxxTgV-container", nodeId: "YFTTxxTgV", rendersWithMotion: true, scopeId: "SofTjBAi7", children: /* @__PURE__ */ _jsx5(XOSkZc1rZ_default, { AGXgjlkUg: "We primarily serve London and surrounding areas, but depending on the project, we may be able to travel further. Get in touch to discuss your location and project needs.", fbMdJnqyQ: "What area are you based in?", height: "100%", id: "YFTTxxTgV", layoutId: "FAQs__YFTTxxTgV", Q0WMNUDZo: Q0WMNUDZo1hs7f9c, style: { width: "100%" }, variant: "R7PMRdpwD", width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 155, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + 175, children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-ktni7n-container", layoutDependency, layoutId: "FAQs__rO_VjZZjo-container", nodeId: "rO_VjZZjo", rendersWithMotion: true, scopeId: "SofTjBAi7", children: /* @__PURE__ */ _jsx5(XOSkZc1rZ_default, { AGXgjlkUg: "Project timelines vary depending on the scope of work. A kitchen or bathroom renovation can take a few weeks, while larger projects like extensions or loft conversions may take several months. We provide clear timelines before starting any work.", fbMdJnqyQ: "How long does a typical project take?", height: "100%", id: "rO_VjZZjo", layoutId: "FAQs__rO_VjZZjo", style: { width: "100%" }, variant: "beuBFBnz9", width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 155, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + 350, children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-14hh6qi-container", layoutDependency, layoutId: "FAQs__nhpnYoZzp-container", nodeId: "nhpnYoZzp", rendersWithMotion: true, scopeId: "SofTjBAi7", children: /* @__PURE__ */ _jsx5(XOSkZc1rZ_default, { AGXgjlkUg: "Yes! We offer free, no-obligation quotes. After an initial consultation, we\u2019ll assess your project needs and provide a detailed estimate so you know exactly what to expect.", fbMdJnqyQ: "Do you offer free quotes?", height: "100%", id: "nhpnYoZzp", layoutId: "FAQs__nhpnYoZzp", style: { width: "100%" }, variant: "beuBFBnz9", width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 155, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + 525, children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-teut0f-container", layoutDependency, layoutId: "FAQs__qfea40xGZ-container", nodeId: "qfea40xGZ", rendersWithMotion: true, scopeId: "SofTjBAi7", children: /* @__PURE__ */ _jsx5(XOSkZc1rZ_default, { AGXgjlkUg: "Some projects, such as extensions and loft conversions, may require planning permission, while others fall under permitted development. We can advise on the necessary permissions and help with the process if needed.", fbMdJnqyQ: "Will I need planning permission for my project?", height: "100%", id: "qfea40xGZ", layoutId: "FAQs__qfea40xGZ", style: { width: "100%" }, variant: "beuBFBnz9", width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 155, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + 700, children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-gkf2bt-container", layoutDependency, layoutId: "FAQs__js9F1Oe0R-container", nodeId: "js9F1Oe0R", rendersWithMotion: true, scopeId: "SofTjBAi7", children: /* @__PURE__ */ _jsx5(XOSkZc1rZ_default, { AGXgjlkUg: "Absolutely! We stand by the quality of our craftsmanship and offer guarantees on our work to give you peace of mind. Specific warranties may vary depending on the type of project\u2014just ask us for details.", fbMdJnqyQ: "Do you provide a guarantee for your work?", height: "100%", id: "js9F1Oe0R", layoutId: "FAQs__js9F1Oe0R", style: { width: "100%" }, variant: "beuBFBnz9", width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 155, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + 875, children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-hqki50-container", layoutDependency, layoutId: "FAQs__Y40di5Gkh-container", nodeId: "Y40di5Gkh", rendersWithMotion: true, scopeId: "SofTjBAi7", children: /* @__PURE__ */ _jsx5(XOSkZc1rZ_default, { AGXgjlkUg: "It depends on the type of work being carried out. For smaller projects like bathrooms and kitchens, staying at home may be possible with minimal disruption. However, larger renovations and structural work may require temporary accommodation. We\u2019ll discuss this with you before starting.", fbMdJnqyQ: "Can I stay in my home while the work is being done?", height: "100%", id: "Y40di5Gkh", layoutId: "FAQs__Y40di5Gkh", style: { width: "100%" }, variant: "beuBFBnz9", width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 155, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + 1050, children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-r7vns1-container", layoutDependency, layoutId: "FAQs__VCG9is5oe-container", nodeId: "VCG9is5oe", rendersWithMotion: true, scopeId: "SofTjBAi7", children: /* @__PURE__ */ _jsx5(XOSkZc1rZ_default, { AGXgjlkUg: "Simply get in touch! We\u2019ll arrange a consultation to discuss your vision, assess your space, and provide expert advice. From there, we\u2019ll give you a quote and a clear plan for moving forward.", fbMdJnqyQ: "How do I get started with a project?", height: "100%", id: "VCG9is5oe", layoutId: "FAQs__VCG9is5oe", style: { width: "100%" }, variant: "beuBFBnz9", width: "100%" }) }) })] }) }) }) });
});
var css4 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-Z2zQ8.framer-1mxox9d, .framer-Z2zQ8 .framer-1mxox9d { display: block; }", ".framer-Z2zQ8.framer-11g4kga { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 20px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-Z2zQ8 .framer-1bqx23h-container { flex: none; height: auto; left: 50%; position: absolute; top: 0px; width: auto; z-index: 1; }", ".framer-Z2zQ8 .framer-cp77le-container, .framer-Z2zQ8 .framer-ktni7n-container, .framer-Z2zQ8 .framer-14hh6qi-container, .framer-Z2zQ8 .framer-teut0f-container, .framer-Z2zQ8 .framer-gkf2bt-container, .framer-Z2zQ8 .framer-hqki50-container, .framer-Z2zQ8 .framer-r7vns1-container { flex: none; height: auto; position: relative; width: 100%; }"];
var FramerSofTjBAi7 = withCSS2(Component3, css4, "framer-Z2zQ8");
var SofTjBAi7_default = FramerSofTjBAi7;
FramerSofTjBAi7.displayName = "FAQs";
FramerSofTjBAi7.defaultProps = { height: 699.5, width: 1040 };
addFonts2(FramerSofTjBAi7, [{ explicitInter: true, fonts: [] }, ...LayoutJumpPreventerFonts, ...FAQsRowFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerSofTjBAi7", "slots": [], "annotations": { "framerContractVersion": "1", "framerIntrinsicHeight": "699.5", "framerIntrinsicWidth": "1040", "framerImmutableVariables": "true", "framerDisplayContentsDiv": "false", "framerComponentViewportWidth": "true", "framerAutoSizeImages": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]}}}', "framerColorSyntax": "true" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  SofTjBAi7_default as default
};
