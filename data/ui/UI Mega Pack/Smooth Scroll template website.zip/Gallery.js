var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/ygemim8axzXC8s2IHCL4/yPbdz83PbR1HniCgNiQW/uS77kU2KV.js
import { jsx as _jsx4, jsxs as _jsxs3 } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls4, ComponentViewportProvider, ControlType as ControlType4, cx as cx2, forwardLoader, getFonts, SmartComponentScopedContainer, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS3 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup4, motion as motion4, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React2 from "react";
import { useRef as useRef5 } from "react";

// http-url:https://framerusercontent.com/modules/B2xAlJLcN0gOnt11mSPw/plhC5PVnCMllW5QXjFK5/Ticker.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Children, useLayoutEffect, useEffect, useState, useRef, useMemo, useCallback, cloneElement, startTransition, forwardRef, useImperativeHandle } from "react";
import { addPropertyControls, ControlType, RenderTarget } from "./_framer-runtime.js";
import { useReducedMotion, LayoutGroup, useInView, useMotionValue, useTransform, motion, frame } from "framer-motion";
import { resize } from "@motionone/dom";
var MAX_DUPLICATED_ITEMS = 100;
var directionTransformers = { left: (offset) => `translateX(-${offset}px)`, right: (offset) => `translateX(${offset}px)`, top: (offset) => `translateY(-${offset}px)`, bottom: (offset) => `translateY(${offset}px)` };
function Ticker(props) {
  let { slots = [], gap, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft, speed, hoverFactor, direction, alignment, sizingOptions, fadeOptions, style } = props;
  const { fadeContent, overflow, fadeWidth, fadeInset, fadeAlpha } = fadeOptions;
  const { widthType, heightType } = sizingOptions;
  const paddingValue = paddingPerSide ? `${paddingTop}px ${paddingRight}px ${paddingBottom}px ${paddingLeft}px` : `${padding}px`;
  const currentTarget = RenderTarget.current();
  const isCanvas = currentTarget === RenderTarget.canvas || currentTarget === RenderTarget.export;
  const writingDirection = useWritingDirection();
  const filteredSlots = slots.filter(Boolean);
  const numChildren = Children.count(filteredSlots);
  const hasChildren = numChildren > 0;
  const offset = useMotionValue(0);
  const resolvedDirection = getTickerResolvedDirection(direction === true ? "left" : direction, writingDirection);
  const isHorizontal = resolvedDirection === "left" || resolvedDirection === "right";
  const transformer = directionTransformers[resolvedDirection];
  const transform = useTransform(offset, transformer);
  const parentRef = useRef(null);
  const childrenRef = useMemo(() => {
    return [{ current: null }, { current: null }];
  }, []);
  const [size, setSize] = useState({ parent: null, children: null });
  let clonedChildren = null;
  let dupedChildren = [];
  let duplicateBy = 0;
  let opacity = 0;
  if (isCanvas) {
    duplicateBy = numChildren ? Math.floor(10 / numChildren) : 0;
    opacity = 1;
  }
  if (!isCanvas && hasChildren && size.parent) {
    duplicateBy = Math.round(size.parent / size.children * 2) + 1;
    duplicateBy = Math.min(duplicateBy, MAX_DUPLICATED_ITEMS);
    opacity = 1;
  }
  const measure = useCallback(() => {
    if (hasChildren && parentRef.current) {
      const parentLength = isHorizontal ? parentRef.current.offsetWidth : parentRef.current.offsetHeight;
      const start = childrenRef[0].current ? isHorizontal ? childrenRef[0].current.offsetLeft : childrenRef[0].current.offsetTop : 0;
      const end = childrenRef[1].current ? isHorizontal ? childrenRef[1].current.offsetLeft + childrenRef[1].current.offsetWidth : childrenRef[1].current.offsetTop + childrenRef[1].current.offsetHeight : 0;
      const childrenLength = end - start + gap;
      startTransition(() => {
        setSize({ parent: parentLength, children: childrenLength });
      });
    }
  }, []);
  const childrenStyles = isCanvas ? { contentVisibility: "auto" } : {};
  if (hasChildren) {
    if (!isCanvas) {
      let initialResize = useRef(true);
      useLayoutEffect(() => {
        frame.read(measure, false, true);
        return resize(parentRef.current, ({ contentSize }) => {
          if (!initialResize.current && (contentSize.width || contentSize.height)) {
            frame.read(measure, false, true);
          }
          initialResize.current = false;
        });
      }, []);
    }
    clonedChildren = Children.map(filteredSlots, (child, index) => {
      let ref;
      if (index === 0) {
        ref = childrenRef[writingDirection === "rtl" && isHorizontal ? 1 : 0];
      }
      if (index === filteredSlots.length - 1) {
        ref = childrenRef[writingDirection === "rtl" && isHorizontal ? 0 : 1];
      }
      const size2 = { width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%" };
      return /* @__PURE__ */ _jsx(LayoutGroup, { inherit: "id", children: /* @__PURE__ */ _jsx(Wrapper, { ref, style: size2, children: /* @__PURE__ */ cloneElement(child, { style: { ...child.props?.style, ...size2, flexShrink: 0, ...childrenStyles }, layoutId: child.props.layoutId ? child.props.layoutId + "-original-" + index : void 0 }, child.props?.children) }) });
    });
  }
  const isInView = isCanvas ? true : useInView(parentRef);
  if (!isCanvas) {
    for (let i = 0; i < duplicateBy; i++) {
      dupedChildren = dupedChildren.concat(Children.map(filteredSlots, (child, childIndex) => {
        const size2 = { width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%", willChange: !isInView ? void 0 : "transform" };
        return /* @__PURE__ */ _jsx(LayoutGroup, { inherit: "id", children: /* @__PURE__ */ _jsx(Wrapper, { style: size2, children: /* @__PURE__ */ cloneElement(child, { key: i + " " + childIndex, style: { ...child.props?.style, width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%", flexShrink: 0, ...childrenStyles }, layoutId: child.props.layoutId ? child.props.layoutId + "-dupe-" + i : void 0 }, child.props?.children) }, i + "li" + childIndex) }, i + "lg" + childIndex);
      }));
    }
  }
  const animateToValue = size.children + size.children * Math.round(size.parent / size.children);
  const initialTime = useRef(null);
  const prevTime = useRef(null);
  const xOrY = useRef(0);
  const isHover = useRef(false);
  const isReducedMotion = useReducedMotion();
  const listRef = useRef(null);
  const animationRef = useRef(null);
  if (!isCanvas) {
    useEffect(() => {
      if (isReducedMotion || !animateToValue || !speed) {
        return;
      }
      animationRef.current = listRef.current.animate({ transform: [transformer(0), transformer(animateToValue)] }, { duration: Math.abs(animateToValue) / speed * 1e3, iterations: Infinity, iterationStart: writingDirection === "rtl" ? 1 : 0, easing: "linear" });
      return () => animationRef.current.cancel();
    }, [hoverFactor, animateToValue, speed, writingDirection]);
    const playOrPause = useCallback(() => {
      if (!animationRef.current)
        return;
      const hidden = document.hidden;
      if (isInView && !hidden && animationRef.current.playState === "paused") {
        animationRef.current.play();
      } else if ((!isInView || hidden) && animationRef.current.playState === "running") {
        animationRef.current.pause();
      }
    }, [isInView]);
    useEffect(() => {
      playOrPause();
    }, [isInView, hoverFactor, animateToValue, speed]);
    useEffect(() => {
      document.addEventListener("visibilitychange", playOrPause);
      return () => {
        document.removeEventListener("visibilitychange", playOrPause);
      };
    }, [playOrPause]);
  }
  const fadeDirection = isHorizontal ? "to right" : "to bottom";
  const fadeWidthStart = fadeWidth / 2;
  const fadeWidthEnd = 100 - fadeWidth / 2;
  const fadeInsetStart = clamp(fadeInset, 0, fadeWidthStart);
  const fadeInsetEnd = 100 - fadeInset;
  const fadeMask = `linear-gradient(${fadeDirection}, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetStart}%, rgba(0, 0, 0, 1) ${fadeWidthStart}%, rgba(0, 0, 0, 1) ${fadeWidthEnd}%, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetEnd}%)`;
  if (!hasChildren) {
    return /* @__PURE__ */ _jsxs("section", { style: placeholderStyles, children: [/* @__PURE__ */ _jsx("div", { style: emojiStyles, children: "\u2728" }), /* @__PURE__ */ _jsx("p", { style: titleStyles, children: "Connect to Content" }), /* @__PURE__ */ _jsx("p", { style: subtitleStyles, children: "Add layers or components to infinitely loop on your page." })] });
  }
  return /* @__PURE__ */ _jsx("section", { style: { ...containerStyle, opacity, WebkitMaskImage: fadeContent ? fadeMask : void 0, maskImage: fadeContent ? fadeMask : void 0, overflow: overflow ? "visible" : "hidden", padding: paddingValue }, ref: parentRef, children: /* @__PURE__ */ _jsxs(motion.ul, { ref: listRef, style: { ...containerStyle, gap, top: direction === "bottom" && isValidNumber(animateToValue) ? -animateToValue : void 0, left: direction === "right" && isValidNumber(animateToValue) ? animateToValue * (writingDirection === "rtl" ? 1 : -1) : void 0, placeItems: alignment, position: "relative", flexDirection: isHorizontal ? "row" : "column", ...style, willChange: isCanvas || !isInView ? "auto" : "transform", transform: transformer(0) }, onMouseEnter: () => {
    isHover.current = true;
    if (animationRef.current) {
      animationRef.current.playbackRate = hoverFactor;
    }
  }, onMouseLeave: () => {
    isHover.current = false;
    if (animationRef.current) {
      animationRef.current.playbackRate = 1;
    }
  }, children: [clonedChildren, dupedChildren] }) });
}
var Wrapper = /* @__PURE__ */ forwardRef(({ children, ...props }, ref) => {
  const innerRef = useRef();
  const inView = useInView(innerRef);
  useImperativeHandle(ref, () => innerRef.current);
  useEffect(() => {
    const current = innerRef.current;
    if (!current)
      return;
    if (inView) {
      current.querySelectorAll("button,a").forEach((el) => {
        const orig = el.dataset.origTabIndex;
        if (orig)
          el.tabIndex = orig;
        else
          el.removeAttribute("tabIndex");
      });
    } else {
      current.querySelectorAll("button,a").forEach((el) => {
        const orig = el.getAttribute("tabIndex");
        if (orig)
          el.dataset.origTabIndex = orig;
        el.tabIndex = -1;
      });
    }
  }, [inView]);
  return /* @__PURE__ */ _jsx("li", { ...props, "aria-hidden": !inView, ref: innerRef, children });
});
Ticker.defaultProps = { gap: 10, padding: 10, sizingOptions: { widthType: true, heightType: true }, fadeOptions: { fadeContent: true, overflow: false, fadeWidth: 25, fadeAlpha: 0, fadeInset: 0 }, direction: true };
addPropertyControls(Ticker, { slots: { type: ControlType.Array, title: "Children", control: { type: ControlType.ComponentInstance } }, speed: { type: ControlType.Number, title: "Speed", min: 0, max: 1e3, defaultValue: 100, unit: "%", displayStepper: true, step: 5 }, direction: { type: ControlType.Enum, title: "Direction", options: ["left", "right", "top", "bottom"], optionIcons: ["direction-left", "direction-right", "direction-up", "direction-down"], optionTitles: ["Left", "Right", "Top", "Bottom"], defaultValue: "left", displaySegmentedControl: true }, alignment: { type: ControlType.Enum, title: "Align", options: ["flex-start", "center", "flex-end"], optionIcons: { direction: { right: ["align-top", "align-middle", "align-bottom"], left: ["align-top", "align-middle", "align-bottom"], top: ["align-left", "align-center", "align-right"], bottom: ["align-left", "align-center", "align-right"] } }, defaultValue: "center", displaySegmentedControl: true }, gap: { type: ControlType.Number, title: "Gap" }, padding: { title: "Padding", type: ControlType.FusedNumber, toggleKey: "paddingPerSide", toggleTitles: ["Padding", "Padding per side"], valueKeys: ["paddingTop", "paddingRight", "paddingBottom", "paddingLeft"], valueLabels: ["T", "R", "B", "L"], min: 0 }, sizingOptions: { type: ControlType.Object, title: "Sizing", controls: { widthType: { type: ControlType.Boolean, title: "Width", enabledTitle: "Auto", disabledTitle: "Stretch", defaultValue: true }, heightType: { type: ControlType.Boolean, title: "Height", enabledTitle: "Auto", disabledTitle: "Stretch", defaultValue: true } } }, fadeOptions: { type: ControlType.Object, title: "Clipping", controls: { fadeContent: { type: ControlType.Boolean, title: "Fade", defaultValue: true }, overflow: { type: ControlType.Boolean, title: "Overflow", enabledTitle: "Show", disabledTitle: "Hide", defaultValue: false, hidden(props) {
  return props.fadeContent === true;
} }, fadeWidth: { type: ControlType.Number, title: "Width", defaultValue: 25, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeInset: { type: ControlType.Number, title: "Inset", defaultValue: 0, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeAlpha: { type: ControlType.Number, title: "Opacity", defaultValue: 0, min: 0, max: 1, step: 0.05, hidden(props) {
  return props.fadeContent === false;
} } } }, hoverFactor: { type: ControlType.Number, title: "Hover", min: 0, max: 1, unit: "x", defaultValue: 1, step: 0.1, displayStepper: true, description: "Slows down the speed while you are hovering." } });
var containerStyle = { display: "flex", width: "100%", height: "100%", maxWidth: "100%", maxHeight: "100%", placeItems: "center", margin: 0, padding: 0, listStyleType: "none", textIndent: "none" };
var placeholderStyles = { display: "flex", width: "100%", height: "100%", placeContent: "center", placeItems: "center", flexDirection: "column", color: "#96F", background: "rgba(136, 85, 255, 0.1)", fontSize: 11, overflow: "hidden", padding: "20px 20px 30px 20px" };
var emojiStyles = { fontSize: 32, marginBottom: 10 };
var titleStyles = { margin: 0, marginBottom: 10, fontWeight: 600, textAlign: "center" };
var subtitleStyles = { margin: 0, opacity: 0.7, maxWidth: 150, lineHeight: 1.5, textAlign: "center" };
var clamp = (num, min, max) => Math.min(Math.max(num, min), max);
var isValidNumber = (value) => typeof value === "number" && !isNaN(value);
function useWritingDirection() {
  if (!__dai_window || !__dai_window.document || !__dai_window.document.documentElement)
    return "ltr";
  return __dai_window.document.documentElement.dir === "rtl" ? "rtl" : "ltr";
}
function getTickerResolvedDirection(direction, writingDirection) {
  if (writingDirection !== "rtl")
    return direction;
  if (direction === "left")
    return "right";
  if (direction === "right")
    return "left";
  return direction;
}

// http-url:https://framerusercontent.com/modules/zvkTOpMSuRzRhLzZZIwG/7GuSIJ2Jm6VU0TIDHoiR/SlideShow.js
import { jsx as _jsx2, jsxs as _jsxs2 } from "react/jsx-runtime";
import { resize as resize2 } from "@motionone/dom";
import { ControlType as ControlType2, RenderTarget as RenderTarget2, addPropertyControls as addPropertyControls2, withCSS } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, animate, frame as frame2, mix, motion as motion2, useInView as useInView2, useMotionValue as useMotionValue2, usePageInView, useTransform as useTransform2, wrap } from "framer-motion";
import { Children as Children2, cloneElement as cloneElement2, forwardRef as forwardRef2, memo, startTransition as startTransition2, useCallback as useCallback3, useEffect as useEffect2, useLayoutEffect as useLayoutEffect3, useRef as useRef3, useState as useState2 } from "react";

// http-url:https://framerusercontent.com/modules/zvkTOpMSuRzRhLzZZIwG/7GuSIJ2Jm6VU0TIDHoiR/use-effect-event
import { useCallback as useCallback2, useLayoutEffect as useLayoutEffect2, useRef as useRef2 } from "react";
function useEffectEvent(fn) {
  const ref = useRef2(fn);
  useLayoutEffect2(() => {
    ref.current = fn;
  });
  return useCallback2((...args) => ref.current(...args), []);
}

// http-url:https://framerusercontent.com/modules/zvkTOpMSuRzRhLzZZIwG/7GuSIJ2Jm6VU0TIDHoiR/SlideShow.js
var slideshowClassName = "framer-slideshow";
var slideshowAxisXClassName = "framer-slideshow-axis-x";
var slideshowAxisYClassName = "framer-slideshow-axis-y";
var slideshowDirectionMultiplierVariable = "--framer-dir-multiplier";
var slideshowDirectionMultiplier = `var(${slideshowDirectionMultiplierVariable}, -1)`;
function SlideshowWithoutCSS(props) {
  const { slots = [], startFrom, direction, effectsOptions, autoPlayControl, dragControl, alignment, gap, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft, itemAmount: visibleItemsCount, fadeOptions, intervalControl, transitionControl, arrowOptions, borderRadius, progressOptions, style } = props;
  const { effectsOpacity, effectsScale, effectsRotate, effectsPerspective, effectsHover, playOffscreen } = effectsOptions;
  const { fadeContent, overflow, fadeWidth, fadeInset, fadeAlpha } = fadeOptions;
  const { showMouseControls, arrowSize, arrowRadius, arrowFill, leftArrow, rightArrow, arrowShouldSpace = true, arrowShouldFadeIn = false, arrowPosition, arrowPadding, arrowGap, arrowPaddingTop, arrowPaddingRight, arrowPaddingBottom, arrowPaddingLeft } = arrowOptions;
  const { showProgressDots, dotSize, dotsInset, dotsRadius, dotsPadding, dotsGap, dotsFill, dotsBackground, dotsActiveOpacity, dotsOpacity, dotsBlur } = progressOptions;
  const paddingValue = paddingPerSide ? `${paddingTop}px ${paddingRight}px ${paddingBottom}px ${paddingLeft}px` : `${padding}px`;
  const isCanvas = RenderTarget2.current() === RenderTarget2.canvas;
  const filteredSlots = slots.filter(Boolean);
  const totalItemsCount = Children2.count(filteredSlots);
  const hasChildren = totalItemsCount > 0;
  if (!hasChildren) {
    return /* @__PURE__ */ _jsxs2("section", { style: placeholderStyles2, children: [/* @__PURE__ */ _jsx2("div", { style: emojiStyles2, children: "\u2B50\uFE0F" }), /* @__PURE__ */ _jsx2("p", { style: titleStyles2, children: "Connect to Content" }), /* @__PURE__ */ _jsx2("p", { style: subtitleStyles2, children: "Add layers or components to make infinite auto-playing slideshows." })] });
  }
  const scheduleMeasureIfEverythingReady = useCallback3(() => {
    if (parentRef.current && firstChildRef.current && lastChildRef.current) {
      scheduleMeasure();
    }
  }, []);
  const parentRef = useRef3(null);
  const parentRefFn = useCallback3((node) => {
    parentRef.current = node;
    scheduleMeasureIfEverythingReady();
  }, [scheduleMeasureIfEverythingReady]);
  const firstChildRef = useRef3(null);
  const firstChildRefFn = useCallback3((node) => {
    firstChildRef.current = node;
    scheduleMeasureIfEverythingReady();
  }, [scheduleMeasureIfEverythingReady]);
  const lastChildRef = useRef3(null);
  const lastChildRefFn = useCallback3((node) => {
    lastChildRef.current = node;
    scheduleMeasureIfEverythingReady();
  }, [scheduleMeasureIfEverythingReady]);
  const [size, setSize] = useState2({ parent: null, children: null, item: null, itemWidth: null, itemHeight: null, viewportLength: null });
  const isHorizontal = direction === "left" || direction === "right";
  const writingDirection = useWritingDirection2();
  const rtlDirectionModifier = isHorizontal && writingDirection === "rtl" ? -1 : 1;
  const [isHovering, setIsHovering] = useState2(false);
  const [shouldPlayOnHover, setShouldPlayOnHover] = useState2(autoPlayControl);
  const [isMouseDown, setIsMouseDown] = useState2(false);
  const isInitialized = size?.item !== null && size?.parent !== null && writingDirection !== null;
  const extraCopyCount = Math.ceil((startFrom + visibleItemsCount) / totalItemsCount);
  let dupedChildren = [];
  let duplicateBy = extraCopyCount * 4;
  if (isCanvas || !isInitialized) {
    duplicateBy = extraCopyCount;
  }
  const [currentItem, setCurrentItem] = useState2(startFrom + totalItemsCount);
  useEffect2(() => {
    if (!size.item || !writingDirection)
      return;
    const computedNewPosition = -1 * currentItem * ((size.item ?? 0) + gap) * (writingDirection === "rtl" ? -1 : 1);
    if (xOrY.get() !== computedNewPosition) {
      animate(xOrY, computedNewPosition, transitionControl);
    }
  }, [currentItem, size.item, gap, writingDirection]);
  const measure = () => {
    if (!parentRef.current || !firstChildRef.current || !lastChildRef.current)
      return;
    const writingDirection2 = getWritingDirection();
    const isRTL = isHorizontal && writingDirection2 === "rtl";
    const firstChild = isRTL ? lastChildRef.current : firstChildRef.current;
    const lastChild = isRTL ? firstChildRef.current : lastChildRef.current;
    const parentLength = isHorizontal ? parentRef.current.offsetWidth : parentRef.current.offsetHeight;
    const start = firstChild ? isHorizontal ? firstChild.offsetLeft : firstChild.offsetTop : 0;
    const end = lastChild ? isHorizontal ? lastChild.offsetLeft + lastChild.offsetWidth : lastChild.offsetTop + lastChild.offsetHeight : 0;
    const childrenLength = end - start + gap;
    const itemSize = firstChild ? isHorizontal ? firstChild.offsetWidth : firstChild.offsetHeight : 0;
    const itemWidth = firstChild ? firstChild.offsetWidth : 0;
    const itemHeight = firstChild ? firstChild.offsetHeight : 0;
    const viewportLength = isHorizontal ? Math.max(document.documentElement.clientWidth || 0, __dai_window.innerWidth || 0, parentRef.current.offsetWidth) : Math.max(document.documentElement.clientHeight || 0, __dai_window.innerHeight || 0, parentRef.current.offsetHeight);
    setSize({ parent: parentLength, children: childrenLength, item: itemSize, itemWidth, itemHeight, viewportLength });
  };
  const scheduleMeasure = useEffectEvent(async () => {
    frame2.read(measure, false, true);
  });
  useLayoutEffect3(() => {
    scheduleMeasure();
  }, [slots.length, visibleItemsCount, gap, direction, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft]);
  useEffect2(() => {
    const node = parentRef.current;
    if (!node)
      return;
    return resize2(node, ({ contentSize }) => {
      if (contentSize.width || contentSize.height) {
        scheduleMeasure();
      }
    });
  }, []);
  const childrenSize = isCanvas ? 0 : size?.children;
  const [isDragging, setIsDragging] = useState2(false);
  const visibilityRef = useRef3(null);
  const isInView = useInView2(visibilityRef);
  const isVisible = usePageInView() && isInView;
  const xOrY = useMotionValue2(childrenSize);
  const wrappedXOrY = !isCanvas ? useTransform2(xOrY, (value) => {
    const resolvedChildrenSize = childrenSize ?? 0;
    const resolvedValue = value ?? 0;
    const wrapped = wrap(-resolvedChildrenSize * rtlDirectionModifier, -resolvedChildrenSize * rtlDirectionModifier * 2, resolvedValue);
    return Number.isNaN(wrapped) ? 0 : wrapped;
  }) : 0;
  const wrappedIndex = wrap(0, totalItemsCount, currentItem);
  const setDelta = (delta) => {
    startTransition2(() => setCurrentItem((item) => item + delta));
  };
  const setPage = (index) => {
    const currentItemWrapped = wrap(0, totalItemsCount, currentItem);
    const goto = index - currentItemWrapped;
    startTransition2(() => setCurrentItem((item) => item + goto));
  };
  const autoplayStep = (direction === "right" || direction === "bottom" ? -1 : 1) * rtlDirectionModifier;
  const canAutoplay = autoPlayControl && shouldPlayOnHover && (playOffscreen || isVisible) && !isCanvas && totalItemsCount > 1 && !isDragging && isInitialized;
  useEffect2(() => {
    if (!canAutoplay)
      return;
    const timeoutId = setTimeout(() => {
      setDelta(autoplayStep);
    }, intervalControl * 1e3);
    return () => clearTimeout(timeoutId);
  }, [canAutoplay, autoplayStep, intervalControl, currentItem]);
  const handleDragStart = () => {
    startTransition2(() => setIsDragging(true));
  };
  const handleDragEnd = (event, { offset, velocity }) => {
    startTransition2(() => setIsDragging(false));
    const offsetXorY = isHorizontal ? offset.x : offset.y;
    const velocityThreshold = 200;
    const velocityXorY = isHorizontal ? velocity.x : velocity.y;
    const isHalfOfNext = offsetXorY < -size.item / 2;
    const isHalfOfPrev = offsetXorY > size.item / 2;
    const normalizedOffset = Math.abs(offsetXorY);
    const itemDelta = Math.round(normalizedOffset / size.item);
    const itemDeltaFromOne = itemDelta === 0 ? 1 : itemDelta;
    if (velocityXorY > velocityThreshold) {
      setDelta(-itemDeltaFromOne * rtlDirectionModifier);
    } else if (velocityXorY < -velocityThreshold) {
      setDelta(itemDeltaFromOne * rtlDirectionModifier);
    } else {
      if (isHalfOfNext) {
        setDelta(itemDelta * rtlDirectionModifier);
      }
      if (isHalfOfPrev) {
        setDelta(-itemDelta * rtlDirectionModifier);
      }
    }
  };
  const staticStartFrom = Math.max(0, Math.min(startFrom ?? 0, Math.max(0, totalItemsCount - 1)));
  const staticPercentOffset = staticStartFrom * 100 / visibleItemsCount;
  const staticPixelOffset = staticStartFrom * gap / visibleItemsCount;
  let childCounter = 0;
  const columnOrRowValue = `calc(${100 / visibleItemsCount}% - ${gap}px + ${gap / visibleItemsCount}px)`;
  for (let index = 0; index < duplicateBy; index++) {
    dupedChildren = dupedChildren.concat(Children2.map(filteredSlots, (child, childIndex) => {
      let ref;
      if (index === 0) {
        if (childIndex === 0) {
          ref = firstChildRefFn;
        } else if (childIndex === filteredSlots.length - 1) {
          ref = lastChildRefFn;
        }
      }
      return /* @__PURE__ */ _jsx2(Slide, { ref, slideKey: index + childIndex + "lg", index, width: isHorizontal ? visibleItemsCount > 1 ? columnOrRowValue : "100%" : "100%", height: !isHorizontal ? visibleItemsCount > 1 ? columnOrRowValue : "100%" : "100%", size, child, numChildren: filteredSlots?.length, wrappedXOrY, childCounter: childCounter++, gap, isCanvas, isInitialized, isHorizontal, effectsOpacity, effectsScale, effectsRotate, writingDirection, rtlDirectionModifier, children: index + childIndex }, index + childIndex + "lg");
    }));
  }
  const fadeDirection = isHorizontal ? "to right" : "to bottom";
  const fadeWidthStart = fadeWidth / 2;
  const fadeWidthEnd = 100 - fadeWidth / 2;
  const fadeInsetStart = clamp2(fadeInset, 0, fadeWidthStart);
  const fadeInsetEnd = 100 - fadeInset;
  const fadeMask = `linear-gradient(${fadeDirection}, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetStart}%, rgba(0, 0, 0, 1) ${fadeWidthStart}%, rgba(0, 0, 0, 1) ${fadeWidthEnd}%, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetEnd}%)`;
  const dots = [];
  const dotsBlurStyle = {};
  if (showProgressDots) {
    for (let i = 0; i < filteredSlots?.length; i++) {
      dots.push(/* @__PURE__ */ _jsx2(Dot, { dotStyle: { ...dotStyle, width: dotSize, height: dotSize, backgroundColor: dotsFill }, buttonStyle: baseButtonStyles, selectedOpacity: dotsActiveOpacity, opacity: dotsOpacity, disabled: !isCanvas && !isInitialized, onClick: () => setPage(i), wrappedIndex: isCanvas || !isInitialized ? staticStartFrom : wrappedIndex, total: totalItemsCount, index: i, gap: dotsGap, padding: dotsPadding, isHorizontal }, i));
    }
    if (dotsBlur > 0) {
      dotsBlurStyle.backdropFilter = dotsBlurStyle.WebkitBackdropFilter = `blur(${dotsBlur}px)`;
    }
  }
  const dragProps = isInitialized && dragControl ? { drag: isHorizontal ? "x" : "y", onDragStart: handleDragStart, onDragEnd: handleDragEnd, dragDirectionLock: true, values: { x: writingDirection === "rtl" ? -xOrY : xOrY, y: xOrY }, dragMomentum: false } : {};
  const arrowHasTop = arrowPosition === "top-left" || arrowPosition === "top-mid" || arrowPosition === "top-right";
  const arrowHasBottom = arrowPosition === "bottom-left" || arrowPosition === "bottom-mid" || arrowPosition === "bottom-right";
  const arrowHasLeft = arrowPosition === "top-left" || arrowPosition === "bottom-left";
  const arrowHasRight = arrowPosition === "top-right" || arrowPosition === "bottom-right";
  const arrowHasMid = arrowPosition === "top-mid" || arrowPosition === "bottom-mid" || arrowPosition === "auto";
  const leftArrowSrc = leftArrow || "https://framerusercontent.com/images/6tTbkXggWgQCAJ4DO2QEdXXmgM.svg?arrow=left";
  const rightArrowSrc = rightArrow || "https://framerusercontent.com/images/11KSGbIZoRSg4pjdnUoif6MKHI.svg?arrow=right";
  return /* @__PURE__ */ _jsxs2("section", { className: `${slideshowClassName} ${isHorizontal ? slideshowAxisXClassName : slideshowAxisYClassName}`, style: { ...containerStyle2, padding: paddingValue, WebkitMaskImage: fadeContent ? fadeMask : void 0, maskImage: fadeContent ? fadeMask : void 0, userSelect: "none" }, onMouseEnter: () => {
    setIsHovering(true);
    if (!effectsHover)
      setShouldPlayOnHover(false);
  }, onMouseLeave: () => {
    setIsHovering(false);
    if (!effectsHover)
      setShouldPlayOnHover(true);
  }, onMouseDown: (event) => {
    event.preventDefault();
    startTransition2(() => setIsMouseDown(true));
  }, onMouseUp: () => startTransition2(() => setIsMouseDown(false)), ref: visibilityRef, children: [/* @__PURE__ */ _jsx2("div", { style: { width: "100%", height: "100%", margin: 0, padding: "inherit", position: "absolute", inset: 0, overflow: overflow ? "visible" : "hidden", borderRadius, userSelect: "none", perspective: isCanvas ? "none" : effectsPerspective }, children: /* @__PURE__ */ _jsx2(motion2.ul, { ref: parentRefFn, ...dragProps, style: { ...containerStyle2, gap, placeItems: alignment, ...isCanvas || !isInitialized ? { transform: isHorizontal ? `translateX(calc(${slideshowDirectionMultiplier} * (${staticPercentOffset}% + ${staticPixelOffset}px)))` : `translateY(calc(${slideshowDirectionMultiplier} * (${staticPercentOffset}% + ${staticPixelOffset}px)))` } : { x: isHorizontal ? wrappedXOrY : 0, y: !isHorizontal ? wrappedXOrY : 0 }, flexDirection: isHorizontal ? "row" : "column", transformStyle: effectsRotate !== 0 && !isCanvas ? "preserve-3d" : void 0, cursor: (isCanvas || isInitialized) && dragControl ? isMouseDown ? "grabbing" : "grab" : "auto", userSelect: "none", ...style }, children: dupedChildren }) }), /* @__PURE__ */ _jsxs2("fieldset", { style: { ...controlsStyles }, "aria-label": "Slideshow pagination controls", className: "framer--slideshow-controls", children: [/* @__PURE__ */ _jsxs2(motion2.div, { style: { position: "absolute", display: "flex", flexDirection: isHorizontal ? "row" : "column", justifyContent: arrowShouldSpace ? "space-between" : "center", gap: arrowShouldSpace ? "unset" : arrowGap, opacity: arrowShouldFadeIn || !isCanvas && !isInitialized ? 0 : 1, alignItems: "center", inset: arrowPadding, top: arrowShouldSpace ? arrowPadding : arrowHasTop ? arrowPaddingTop : "unset", left: arrowShouldSpace ? arrowPadding : arrowHasLeft ? arrowPaddingLeft : arrowHasMid ? 0 : "unset", right: arrowShouldSpace ? arrowPadding : arrowHasRight ? arrowPaddingRight : arrowHasMid ? 0 : "unset", bottom: arrowShouldSpace ? arrowPadding : arrowHasBottom ? arrowPaddingBottom : "unset" }, animate: isCanvas || isInitialized ? arrowShouldFadeIn ? { opacity: isHovering ? 1 : 0 } : { opacity: 1 } : { opacity: 0 }, transition: transitionControl, children: [/* @__PURE__ */ _jsx2(motion2.button, { type: "button", style: { ...baseButtonStyles, backgroundColor: arrowFill, width: arrowSize, height: arrowSize, borderRadius: arrowRadius, rotate: !isHorizontal ? 90 : 0, display: showMouseControls ? "block" : "none", pointerEvents: isCanvas || isInitialized ? "auto" : "none", cursor: isCanvas || isInitialized ? "pointer" : "default" }, disabled: !(isCanvas || isInitialized), onClick: () => setDelta(-1), "aria-label": "Previous", whileTap: { scale: 0.9 }, transition: { duration: 0.15 }, children: /* @__PURE__ */ _jsx2("img", { decoding: "async", width: arrowSize, height: arrowSize, src: isHorizontal && writingDirection === "rtl" ? rightArrowSrc : leftArrowSrc, alt: "Back Arrow" }) }), /* @__PURE__ */ _jsx2(motion2.button, { type: "button", style: { ...baseButtonStyles, backgroundColor: arrowFill, width: arrowSize, height: arrowSize, borderRadius: arrowRadius, rotate: !isHorizontal ? 90 : 0, display: showMouseControls ? "block" : "none", pointerEvents: isCanvas || isInitialized ? "auto" : "none", cursor: isCanvas || isInitialized ? "pointer" : "default" }, disabled: !(isCanvas || isInitialized), onClick: () => setDelta(1), "aria-label": "Next", whileTap: { scale: 0.9 }, transition: { duration: 0.15 }, children: /* @__PURE__ */ _jsx2("img", { decoding: "async", width: arrowSize, height: arrowSize, src: isHorizontal && writingDirection === "rtl" ? leftArrowSrc : rightArrowSrc, alt: "Next Arrow" }) })] }), dots.length > 1 ? /* @__PURE__ */ _jsx2(motion2.div, { style: {
    ...dotsContainerStyle,
    left: isHorizontal ? "50%" : dotsInset,
    top: !isHorizontal ? "50%" : "unset",
    transform: isHorizontal ? "translateX(-50%)" : "translateY(-50%)",
    flexDirection: isHorizontal ? "row" : "column",
    bottom: isHorizontal ? dotsInset : "unset",
    borderRadius: dotsRadius,
    backgroundColor: dotsBackground,
    userSelect: "none",
    ...dotsBlurStyle,
    // Hard-code opacity to 1 on canvas. In SSR, it will be animated from 0 to 1 in `animate`
    opacity: isCanvas ? 1 : 0,
    pointerEvents: isCanvas || isInitialized ? "auto" : "none"
  }, animate: { opacity: isInitialized ? 1 : 0 }, transition: { duration: 0.35, ease: "easeOut" }, children: dots }) : null] })] });
}
var Slideshow = withCSS(SlideshowWithoutCSS, [`.${slideshowAxisXClassName} { ${slideshowDirectionMultiplierVariable}: -1; }`, `html[dir="rtl"] .${slideshowAxisXClassName} { ${slideshowDirectionMultiplierVariable}: 1; }`, `.${slideshowAxisYClassName} { ${slideshowDirectionMultiplierVariable}: -1; }`], "framer-slideshow-component");
var SlideShow_default = Slideshow;
Slideshow.defaultProps = { direction: "left", dragControl: false, startFrom: 0, itemAmount: 1, infinity: true, gap: 10, padding: 10, autoPlayControl: true, effectsOptions: { effectsOpacity: 1, effectsScale: 1, effectsRotate: 0, effectsPerspective: 1200, effectsHover: true, playOffscreen: false }, transitionControl: { type: "spring", stiffness: 200, damping: 40 }, fadeOptions: { fadeContent: false, overflow: false, fadeWidth: 25, fadeAlpha: 0, fadeInset: 0 }, arrowOptions: { showMouseControls: true, arrowShouldFadeIn: false, arrowShouldSpace: true, arrowFill: "rgba(0,0,0,0.2)", arrowSize: 40 }, progressOptions: { showProgressDots: true } };
addPropertyControls2(Slideshow, { slots: { type: ControlType2.Array, title: "Content", control: { type: ControlType2.ComponentInstance } }, direction: { type: ControlType2.Enum, title: "Direction", options: ["left", "right", "top", "bottom"], optionIcons: ["direction-left", "direction-right", "direction-up", "direction-down"], optionTitles: ["Left", "Right", "Top", "Bottom"], displaySegmentedControl: true, defaultValue: Slideshow.defaultProps.direction }, autoPlayControl: { type: ControlType2.Boolean, title: "Auto Play", defaultValue: true }, intervalControl: { type: ControlType2.Number, title: "Interval", defaultValue: 1.5, min: 0.5, max: 10, step: 0.1, displayStepper: true, unit: "s", hidden: (props) => !props.autoPlayControl }, dragControl: { type: ControlType2.Boolean, title: "Draggable", defaultValue: false }, startFrom: { type: ControlType2.Number, title: "Current", min: 0, max: 10, displayStepper: true, defaultValue: Slideshow.defaultProps.startFrom }, effectsOptions: { type: ControlType2.Object, title: "Effects", controls: { effectsOpacity: { type: ControlType2.Number, title: "Opacity", defaultValue: Slideshow.defaultProps.effectsOptions.effectsOpacity, min: 0, max: 1, step: 0.01, displayStepper: true }, effectsScale: { type: ControlType2.Number, title: "Scale", defaultValue: Slideshow.defaultProps.effectsOptions.effectsScale, min: 0, max: 1, step: 0.01, displayStepper: true }, effectsPerspective: { type: ControlType2.Number, title: "Perspective", defaultValue: Slideshow.defaultProps.effectsOptions.effectsPerspective, min: 200, max: 2e3, step: 1 }, effectsRotate: { type: ControlType2.Number, title: "Rotate", defaultValue: Slideshow.defaultProps.effectsOptions.effectsRotate, min: -180, max: 180, step: 1 }, effectsHover: { type: ControlType2.Boolean, title: "On Hover", enabledTitle: "Play", disabledTitle: "Pause", defaultValue: Slideshow.defaultProps.effectsOptions.effectsHover }, playOffscreen: { type: ControlType2.Boolean, title: "Offscreen", enabledTitle: "Play", disabledTitle: "Pause", defaultValue: Slideshow.defaultProps.effectsOptions.playOffscreen } } }, alignment: { type: ControlType2.Enum, title: "Align", options: ["flex-start", "center", "flex-end"], optionIcons: { direction: { right: ["align-top", "align-middle", "align-bottom"], left: ["align-top", "align-middle", "align-bottom"], top: ["align-left", "align-center", "align-right"], bottom: ["align-left", "align-center", "align-right"] } }, defaultValue: "center", displaySegmentedControl: true }, itemAmount: { type: ControlType2.Number, title: "Items", min: 1, max: 10, displayStepper: true, defaultValue: Slideshow.defaultProps.itemAmount }, gap: { type: ControlType2.Number, title: "Gap", min: 0 }, padding: { title: "Padding", type: ControlType2.FusedNumber, toggleKey: "paddingPerSide", toggleTitles: ["Padding", "Padding per side"], defaultValue: 0, valueKeys: ["paddingTop", "paddingRight", "paddingBottom", "paddingLeft"], valueLabels: ["T", "R", "B", "L"], min: 0 }, borderRadius: { type: ControlType2.Number, title: "Radius", min: 0, max: 500, displayStepper: true, defaultValue: 0 }, transitionControl: { type: ControlType2.Transition, defaultValue: Slideshow.defaultProps.transitionControl, title: "Transition" }, fadeOptions: { type: ControlType2.Object, title: "Clipping", controls: { fadeContent: { type: ControlType2.Boolean, title: "Fade", defaultValue: false }, overflow: { type: ControlType2.Boolean, title: "Overflow", enabledTitle: "Show", disabledTitle: "Hide", defaultValue: false, hidden(props) {
  return props.fadeContent === true;
} }, fadeWidth: { type: ControlType2.Number, title: "Width", defaultValue: 25, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeInset: { type: ControlType2.Number, title: "Inset", defaultValue: 0, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeAlpha: { type: ControlType2.Number, title: "Opacity", defaultValue: 0, min: 0, max: 1, step: 0.05, hidden(props) {
  return props.fadeContent === false;
} } } }, arrowOptions: { type: ControlType2.Object, title: "Arrows", controls: { showMouseControls: { type: ControlType2.Boolean, title: "Show", defaultValue: Slideshow.defaultProps.arrowOptions.showMouseControls }, arrowFill: { type: ControlType2.Color, title: "Fill", hidden: (props) => !props.showMouseControls, defaultValue: Slideshow.defaultProps.arrowOptions.arrowFill }, leftArrow: { type: ControlType2.Image, title: "Previous", hidden: (props) => !props.showMouseControls }, rightArrow: { type: ControlType2.Image, title: "Next", hidden: (props) => !props.showMouseControls }, arrowSize: { type: ControlType2.Number, title: "Size", min: 0, max: 200, displayStepper: true, defaultValue: Slideshow.defaultProps.arrowOptions.arrowSize, hidden: (props) => !props.showMouseControls }, arrowRadius: { type: ControlType2.Number, title: "Radius", min: 0, max: 500, defaultValue: 40, hidden: (props) => !props.showMouseControls }, arrowShouldFadeIn: { type: ControlType2.Boolean, title: "Fade In", defaultValue: false, hidden: (props) => !props.showMouseControls }, arrowShouldSpace: { type: ControlType2.Boolean, title: "Distance", enabledTitle: "Space", disabledTitle: "Group", defaultValue: Slideshow.defaultProps.arrowOptions.arrowShouldSpace, hidden: (props) => !props.showMouseControls }, arrowPosition: { type: ControlType2.Enum, title: "Position", options: ["auto", "top-left", "top-mid", "top-right", "bottom-left", "bottom-mid", "bottom-right"], optionTitles: ["Center", "Top Left", "Top Middle", "Top Right", "Bottom Left", "Bottom Middle", "Bottom Right"], hidden: (props) => !props.showMouseControls || props.arrowShouldSpace }, arrowPadding: { type: ControlType2.Number, title: "Inset", min: -100, max: 100, defaultValue: 20, displayStepper: true, hidden: (props) => !props.showMouseControls || !props.arrowShouldSpace }, arrowPaddingTop: { type: ControlType2.Number, title: "Top", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "bottom-mid" || props.arrowPosition === "bottom-left" || props.arrowPosition === "bottom-right" }, arrowPaddingBottom: { type: ControlType2.Number, title: "Bottom", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "top-mid" || props.arrowPosition === "top-left" || props.arrowPosition === "top-right" }, arrowPaddingRight: { type: ControlType2.Number, title: "Right", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "top-left" || props.arrowPosition === "top-mid" || props.arrowPosition === "bottom-left" || props.arrowPosition === "bottom-mid" }, arrowPaddingLeft: { type: ControlType2.Number, title: "Left", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "top-right" || props.arrowPosition === "top-mid" || props.arrowPosition === "bottom-right" || props.arrowPosition === "bottom-mid" }, arrowGap: { type: ControlType2.Number, title: "Gap", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace } } }, progressOptions: { type: ControlType2.Object, title: "Dots", controls: { showProgressDots: { type: ControlType2.Boolean, title: "Show", defaultValue: false }, dotSize: { type: ControlType2.Number, title: "Size", min: 1, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsInset: { type: ControlType2.Number, title: "Inset", min: -100, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsGap: { type: ControlType2.Number, title: "Gap", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsPadding: { type: ControlType2.Number, title: "Padding", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsFill: { type: ControlType2.Color, title: "Fill", defaultValue: "#fff", hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsBackground: { type: ControlType2.Color, title: "Backdrop", defaultValue: "rgba(0,0,0,0.2)", hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsRadius: { type: ControlType2.Number, title: "Radius", min: 0, max: 200, defaultValue: 50, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsOpacity: { type: ControlType2.Number, title: "Opacity", min: 0, max: 1, defaultValue: 0.5, step: 0.1, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsActiveOpacity: { type: ControlType2.Number, title: "Current", min: 0, max: 1, defaultValue: 1, step: 0.1, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsBlur: { type: ControlType2.Number, title: "Blur", min: 0, max: 50, defaultValue: 0, step: 1, hidden: (props) => !props.showProgressDots || props.showScrollbar } } } });
var containerStyle2 = { display: "flex", flexDirection: "row", width: "100%", height: "100%", maxWidth: "100%", maxHeight: "100%", placeItems: "center", margin: 0, padding: 0, listStyleType: "none", textIndent: "none" };
var placeholderStyles2 = { display: "flex", width: "100%", height: "100%", placeContent: "center", placeItems: "center", flexDirection: "column", color: "#96F", background: "rgba(136, 85, 255, 0.1)", fontSize: 11, overflow: "hidden", padding: "20px 20px 30px 20px" };
var emojiStyles2 = { fontSize: 32, marginBottom: 10 };
var titleStyles2 = { margin: 0, marginBottom: 10, fontWeight: 600, textAlign: "center" };
var subtitleStyles2 = { margin: 0, opacity: 0.7, maxWidth: 180, lineHeight: 1.5, textAlign: "center" };
var baseButtonStyles = { border: "none", display: "flex", placeContent: "center", placeItems: "center", overflow: "hidden", background: "transparent", cursor: "pointer", margin: 0, padding: 0 };
var controlsStyles = { display: "flex", justifyContent: "space-between", alignItems: "center", position: "absolute", pointerEvents: "none", userSelect: "none", top: 0, left: 0, right: 0, bottom: 0, border: 0, padding: 0, margin: 0 };
var clamp2 = (num, min, max) => Math.min(Math.max(num, min), max);
var Slide = /* @__PURE__ */ memo(/* @__PURE__ */ forwardRef2(function Component(props, ref) {
  const {
    slideKey,
    width,
    height,
    child,
    size,
    gap,
    wrappedXOrY,
    numChildren,
    childCounter,
    isCanvas,
    isInitialized,
    effects,
    effectsOpacity,
    effectsScale,
    effectsRotate,
    isHorizontal,
    isLast,
    index,
    /** "ltr" or "rtl" */
    writingDirection,
    /** -1 in RTL, 1 in LTR */
    rtlDirectionModifier
  } = props;
  const fallbackRef = useRef3();
  const itemSize = size?.item ?? 0;
  const parentSize = size?.parent ?? 0;
  const childOffset = (itemSize + gap) * childCounter;
  const scrollRange = (
    // @ivan: this was picked experimentally when fixing semi-working-but-broken RTL
    // implementation in the existing Carousel code. Don’t ask me why these specific values, I’m
    // finding it hard to fully reason about RTL in carousel :/
    (isHorizontal && writingDirection === "rtl" ? [itemSize - gap, 0, -parentSize + itemSize - gap, -parentSize - gap] : [-itemSize, 0, parentSize - itemSize + gap, parentSize]).map((val) => val - childOffset * rtlDirectionModifier)
  );
  const rotateY = !isCanvas && useTransform2(
    wrappedXOrY,
    scrollRange,
    // Why flip the rotateY effect when RTL is enabled?
    //
    // Unlike other effects, rotation is vertically symmetrical. Say the user sets a 60 degree rotation.
    // The carousel will look like this:
    //   ) □ ▣ ▤ (
    // where
    // - □ ▣ ▤ are the three slides visible within the carousel,
    // - ) is an out-of-view slide to the left of the viewport,
    // - and ( is an out-of-view slide to the right of the viewport.
    // With 60° rotation, both out-of-view slides look “turned towards” the viewport,
    // which matters for the animation when the slides switch.
    //
    // If a user sets RTL, all items in the carousel will flip around. The carousel, by default, will now look like this:
    //   ( ▤ ▣ □ )
    // Notice how all slides reversed. The slide that was to the left of the viewport: ) – is now to the right of it!
    // And is now turned away from the viewport! So if we don’t flip the rotateY effect, the animation will look off.
    isHorizontal && writingDirection === "rtl" ? [effectsRotate, 0, 0, -effectsRotate] : [-effectsRotate, 0, 0, effectsRotate]
  );
  const rotateX = !isCanvas && useTransform2(wrappedXOrY, scrollRange, [effectsRotate, 0, 0, -effectsRotate]);
  const opacity = !isCanvas && useTransform2(wrappedXOrY, scrollRange, [effectsOpacity, 1, 1, effectsOpacity]);
  const scale = !isCanvas && useTransform2(wrappedXOrY, scrollRange, [effectsScale, 1, 1, effectsScale]);
  const originXorY = !isCanvas && useTransform2(
    wrappedXOrY,
    scrollRange,
    // Just like above, because in RTL, the items are flipped vertically, RTL needs a separate treatment
    isHorizontal && writingDirection === "rtl" ? [0, 0, 1, 1] : [1, 1, 0, 0]
  );
  const isVisible = !isCanvas && useTransform2(wrappedXOrY, (latest) => {
    const min = Math.min(scrollRange[1], scrollRange[2]);
    const max = Math.max(scrollRange[1], scrollRange[2]);
    return latest >= min && latest <= max;
  });
  useEffect2(() => {
    if (!isVisible || !isInitialized)
      return;
    function manageVisibility(visible) {
      const node = ref?.current ?? fallbackRef.current;
      if (!node)
        return;
      if (visible) {
        node.querySelectorAll("button,a").forEach((el) => {
          const orig = el.dataset.origTabIndex;
          if (orig)
            el.tabIndex = orig;
          else
            el.removeAttribute("tabIndex");
        });
      } else {
        node.querySelectorAll("button,a").forEach((el) => {
          const orig = el.getAttribute("tabIndex");
          if (orig)
            el.dataset.origTabIndex = orig;
          el.tabIndex = -1;
        });
      }
      node.setAttribute("aria-hidden", !visible);
    }
    manageVisibility(isVisible);
    return isVisible.on("change", (visible) => {
      manageVisibility(visible);
    });
  }, [isInitialized]);
  const visibility = isCanvas ? "visible" : useTransform2(wrappedXOrY, [scrollRange[0] - size.viewportLength * rtlDirectionModifier, mix(scrollRange[1], scrollRange[2], 0.5), scrollRange[3] + size.viewportLength * rtlDirectionModifier], ["hidden", "visible", "hidden"]);
  const key = slideKey + "child";
  return /* @__PURE__ */ _jsx2(LayoutGroup2, { inherit: "id", id: key, children: /* @__PURE__ */ _jsx2("li", { style: { display: "contents" }, children: /* @__PURE__ */ cloneElement2(child, { ref: ref ?? fallbackRef, key, style: { ...child.props?.style, flexShrink: 0, userSelect: "none", width, height, ...isInitialized ? { opacity, scale, originX: isHorizontal ? originXorY : 0.5, originY: !isHorizontal ? originXorY : 0.5, rotateY: isHorizontal ? rotateY : 0, rotateX: !isHorizontal ? rotateX : 0, visibility } : {} }, layoutId: child.props.layoutId ? child.props.layoutId + "-original-" + index : void 0 }) }) });
}));
var Dot = /* @__PURE__ */ memo(function Dot2({ selectedOpacity, opacity, total, index, wrappedIndex, dotStyle: dotStyle2, buttonStyle, gap, padding, isHorizontal, ...props }) {
  const isSelected = wrappedIndex === index;
  const inlinePadding = gap / 2;
  const top = !isHorizontal && index !== 0 ? inlinePadding : padding;
  const bottom = !isHorizontal && index !== total - 1 ? inlinePadding : padding;
  const inlineStart = isHorizontal ? index === 0 ? padding : inlinePadding : padding;
  const inlineEnd = isHorizontal ? index === total - 1 ? padding : inlinePadding : padding;
  return /* @__PURE__ */ _jsx2("button", { "aria-label": `Scroll to page ${index + 1}`, type: "button", ...props, style: { ...buttonStyle, paddingTop: top, paddingBottom: bottom, paddingInlineStart: inlineStart, paddingInlineEnd: inlineEnd }, children: /* @__PURE__ */ _jsx2(motion2.div, { style: { ...dotStyle2 }, initial: false, animate: { opacity: isSelected ? selectedOpacity : opacity }, transition: { duration: 0.3 } }) });
});
var dotsContainerStyle = { display: "flex", placeContent: "center", placeItems: "center", overflow: "hidden", position: "absolute", pointerEvents: "auto" };
var dotStyle = { borderRadius: "50%", background: "white", cursor: "pointer", border: "none", placeContent: "center", placeItems: "center", padding: 0 };
function getWritingDirection() {
  return __dai_window?.document?.documentElement?.dir === "rtl" ? "rtl" : "ltr";
}
function useWritingDirection2() {
  const [writingDirection, setWritingDirection] = useState2(null);
  useEffect2(() => {
    setWritingDirection(getWritingDirection());
    return onWritingDirectionChange(() => {
      setWritingDirection(getWritingDirection());
    });
  }, []);
  return writingDirection;
}
var observer = null;
var callbacks = [];
function onWritingDirectionChange(callback) {
  callbacks.push(callback);
  if (!observer) {
    observer = new MutationObserver(() => callbacks.forEach((callback2) => callback2()));
    observer.observe(document.documentElement, { attributeFilter: ["dir"] });
  }
  return () => {
    callbacks.splice(callbacks.indexOf(callback), 1);
    if (callbacks.length === 0) {
      observer?.disconnect();
      observer = null;
    }
  };
}

// http-url:https://framerusercontent.com/modules/3raQlC1eMM2CR8hFtjTl/EB5bjeeTj9xLp4T8tnmY/bwcX7mWF7.js
import { jsx as _jsx3 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx, getLoadingLazyAtYPosition, Image, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup3, motion as motion3, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef as useRef4 } from "react";
var serializationHash = "framer-8dscJ";
var variantClassNames = { OS6CvgIvQ: "framer-v-1cr5qt0" };
var transition1 = { damping: 60, delay: 0, mass: 1, stiffness: 500, type: "spring" };
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion3.create(React.Fragment);
var getProps = ({ height, id, image, width, ...props }) => {
  return { ...props, jw2NQdsXq: image ?? props.jw2NQdsXq ?? { src: "https://framerusercontent.com/images/yyYhQHFqAUi9h1nO5lH9iqGVY7o.png?scale-down-to=1024", srcSet: "https://framerusercontent.com/images/yyYhQHFqAUi9h1nO5lH9iqGVY7o.png?scale-down-to=512 512w,https://framerusercontent.com/images/yyYhQHFqAUi9h1nO5lH9iqGVY7o.png?scale-down-to=1024 1024w,https://framerusercontent.com/images/yyYhQHFqAUi9h1nO5lH9iqGVY7o.png 1200w" } };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef4(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, jw2NQdsXq, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "OS6CvgIvQ", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx3(LayoutGroup3, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition, { value: transition1, children: /* @__PURE__ */ _jsx3(motion3.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-1cr5qt0", className, classNames), "data-framer-name": "Variant 1", layoutDependency, layoutId: "Gallery__OS6CvgIvQ", ref: refBinding, style: { ...style }, children: /* @__PURE__ */ _jsx3(Image, { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 0 + (((componentViewport?.height || 550) - 0 - (((componentViewport?.height || 550) - 0) * 1 + 0)) / 2 + 0 + 0)), sizes: componentViewport?.width || "100vw", ...toResponsiveImage(jw2NQdsXq), ...{ positionX: "center", positionY: "center" } }, className: "framer-16a69do", "data-framer-name": "Image", layoutDependency, layoutId: "Gallery__xBWQf_AOJ" }) }) }) }) });
});
var css = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-8dscJ.framer-emdino, .framer-8dscJ .framer-emdino { display: block; }", ".framer-8dscJ.framer-1cr5qt0 { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: auto; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-8dscJ .framer-16a69do { flex: none; height: 100%; position: relative; width: 100%; }", "@supports (background: -webkit-named-image(i)) and (not (font-palette:dark)) { .framer-8dscJ.framer-1cr5qt0 { gap: 0px; } .framer-8dscJ.framer-1cr5qt0 > * { margin: 0px; margin-bottom: calc(10px / 2); margin-top: calc(10px / 2); } .framer-8dscJ.framer-1cr5qt0 > :first-child { margin-top: 0px; } .framer-8dscJ.framer-1cr5qt0 > :last-child { margin-bottom: 0px; } }"];
var FramerbwcX7mWF7 = withCSS2(Component2, css, "framer-8dscJ");
var bwcX7mWF7_default = FramerbwcX7mWF7;
FramerbwcX7mWF7.displayName = "Ticker Image";
FramerbwcX7mWF7.defaultProps = { height: 550, width: 400 };
addPropertyControls3(FramerbwcX7mWF7, { jw2NQdsXq: { __defaultAssetReference: "data:framer/asset-reference,yyYhQHFqAUi9h1nO5lH9iqGVY7o.png?originalFilename=QmPosyYDjWTpTRrTuAcFJHRsCVaQVK9d693DDvSCMkZ34D%3Fauto%3Dformat%26h%3D1200.png&preferredSize=auto", title: "Image", type: ControlType3.ResponsiveImage } });
addFonts(FramerbwcX7mWF7, [{ explicitInter: true, fonts: [] }], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/ygemim8axzXC8s2IHCL4/yPbdz83PbR1HniCgNiQW/uS77kU2KV.js
var TickerImageFonts = getFonts(bwcX7mWF7_default);
var TickerFonts = getFonts(Ticker);
var SlideshowFonts = getFonts(SlideShow_default);
var cycleOrder = ["Pe8WEpTQv", "RrP2167Cm"];
var serializationHash2 = "framer-djUoi";
var variantClassNames2 = { Pe8WEpTQv: "framer-v-19qei4b", RrP2167Cm: "framer-v-mruugj" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition12 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var addImageAlt = (image, alt) => {
  if (!image || typeof image !== "object") {
    return;
  }
  return { ...image, alt };
};
var Transition2 = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext2.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Desktop: "Pe8WEpTQv", Mobile: "RrP2167Cm" };
var Variants2 = motion4.create(React2.Fragment);
var getProps2 = ({ height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "Pe8WEpTQv" };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef5(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className, layoutId, variant, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder, defaultVariant: "Pe8WEpTQv", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash2, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "RrP2167Cm")
      return false;
    return true;
  };
  const isDisplayed1 = () => {
    if (baseVariant === "RrP2167Cm")
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx4(LayoutGroup4, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition2, { value: transition12, children: /* @__PURE__ */ _jsxs3(motion4.div, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-19qei4b", className, classNames), "data-framer-name": "Desktop", layoutDependency, layoutId: "Gallery__Pe8WEpTQv", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ RrP2167Cm: { "data-framer-name": "Mobile" } }, baseVariant, gestureVariant), children: [isDisplayed() && /* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-68zoko-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "Gallery__sQO4awPyA-container", nodeId: "sQO4awPyA", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(Ticker, { alignment: "flex-start", direction: "left", fadeOptions: { fadeAlpha: 0, fadeContent: false, fadeInset: 0, fadeWidth: 25, overflow: false }, gap: 32, height: "100%", hoverFactor: 0.5, id: "sQO4awPyA", layoutId: "Gallery__sQO4awPyA", padding: 0, paddingBottom: 0, paddingLeft: 0, paddingPerSide: false, paddingRight: 0, paddingTop: 0, sizingOptions: { heightType: false, widthType: true }, slots: [/* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 550, width: "400px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-cwf5tq-container", "data-framer-name": "Ticker Image 1", inComponentSlot: true, layoutDependency, layoutId: "Gallery__uhVBKZA4b-container", name: "Ticker Image 1", nodeId: "uhVBKZA4b", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "uhVBKZA4b", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/bwP8CYttC1lINgPtK7lQja0.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/bwP8CYttC1lINgPtK7lQja0.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/bwP8CYttC1lINgPtK7lQja0.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/bwP8CYttC1lINgPtK7lQja0.png?width=1200&height=1200 1200w" }, ""), layoutId: "Gallery__uhVBKZA4b", name: "Ticker Image 1", style: { height: "100%", width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 550, width: "400px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1njhf5m-container", "data-framer-name": "Ticker Image 2", inComponentSlot: true, layoutDependency, layoutId: "Gallery__a1e8yCNF_-container", name: "Ticker Image 2", nodeId: "a1e8yCNF_", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "a1e8yCNF_", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 896, src: "https://framerusercontent.com/images/RbmRrHiT87wxDx7Cox6FOA1sM3k.png?width=896&height=1200", srcSet: "https://framerusercontent.com/images/RbmRrHiT87wxDx7Cox6FOA1sM3k.png?scale-down-to=1024&width=896&height=1200 764w,https://framerusercontent.com/images/RbmRrHiT87wxDx7Cox6FOA1sM3k.png?width=896&height=1200 896w" }, ""), layoutId: "Gallery__a1e8yCNF_", name: "Ticker Image 2", style: { height: "100%", width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 560, width: "407.2727px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-gv0qzm-container", "data-framer-name": "Ticker Image 3", inComponentSlot: true, layoutDependency, layoutId: "Gallery__YsIIzgt7F-container", name: "Ticker Image 3", nodeId: "YsIIzgt7F", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "YsIIzgt7F", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/tWbl1rD5H93nV4ujsuqC2FUaqKM.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/tWbl1rD5H93nV4ujsuqC2FUaqKM.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/tWbl1rD5H93nV4ujsuqC2FUaqKM.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/tWbl1rD5H93nV4ujsuqC2FUaqKM.png?width=1200&height=1200 1200w" }, ""), layoutId: "Gallery__YsIIzgt7F", name: "Ticker Image 3", style: { height: "100%", width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 550, width: "400px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-djbkjw-container", "data-framer-name": "Ticker Image 4", inComponentSlot: true, layoutDependency, layoutId: "Gallery__Tk8dkQUIc-container", name: "Ticker Image 4", nodeId: "Tk8dkQUIc", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "Tk8dkQUIc", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 960, src: "https://framerusercontent.com/images/A7yE2PBsrF4l2EgA4yTO9HiAcPQ.png?width=960&height=1200", srcSet: "https://framerusercontent.com/images/A7yE2PBsrF4l2EgA4yTO9HiAcPQ.png?scale-down-to=1024&width=960&height=1200 819w,https://framerusercontent.com/images/A7yE2PBsrF4l2EgA4yTO9HiAcPQ.png?width=960&height=1200 960w" }, ""), layoutId: "Gallery__Tk8dkQUIc", name: "Ticker Image 4", style: { height: "100%", width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 550, width: "400px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-14sq3u2-container", "data-framer-name": "Ticker Image 5", inComponentSlot: true, layoutDependency, layoutId: "Gallery__QonYEBobN-container", name: "Ticker Image 5", nodeId: "QonYEBobN", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "QonYEBobN", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/uIxBIlcieM1DRX71NtmymFxTUI.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/uIxBIlcieM1DRX71NtmymFxTUI.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/uIxBIlcieM1DRX71NtmymFxTUI.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/uIxBIlcieM1DRX71NtmymFxTUI.png?width=1200&height=1200 1200w" }, ""), layoutId: "Gallery__QonYEBobN", name: "Ticker Image 5", style: { height: "100%", width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 550, width: "400px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1cosb6b-container", "data-framer-name": "Ticker Image 6", inComponentSlot: true, layoutDependency, layoutId: "Gallery__uhafyGa0L-container", name: "Ticker Image 6", nodeId: "uhafyGa0L", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "uhafyGa0L", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/ww0GmyZcc1yAIo8GBgwRahYQjtc.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/ww0GmyZcc1yAIo8GBgwRahYQjtc.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/ww0GmyZcc1yAIo8GBgwRahYQjtc.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/ww0GmyZcc1yAIo8GBgwRahYQjtc.png?width=1200&height=1200 1200w" }, ""), layoutId: "Gallery__uhafyGa0L", name: "Ticker Image 6", style: { height: "100%", width: "100%" }, width: "100%" }) }) })], speed: 35, style: { height: "100%", width: "100%" }, width: "100%" }) }) }), isDisplayed1() && /* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-wtlm01-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "Gallery__fvdiiTztO-container", nodeId: "fvdiiTztO", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(SlideShow_default, { alignment: "flex-start", arrowOptions: { arrowFill: "rgba(0, 0, 0, 0.2)", arrowGap: 10, arrowPadding: -10, arrowPaddingBottom: 0, arrowPaddingLeft: 0, arrowPaddingRight: 0, arrowPaddingTop: 0, arrowPosition: "auto", arrowRadius: 40, arrowShouldFadeIn: false, arrowShouldSpace: true, arrowSize: 40, showMouseControls: false }, autoPlayControl: true, borderRadius: 0, direction: "left", dragControl: true, effectsOptions: { effectsHover: true, effectsOpacity: 1, effectsPerspective: 1200, effectsRotate: 0, effectsScale: 1, playOffscreen: false }, fadeOptions: { fadeAlpha: 0, fadeContent: false, fadeInset: 0, fadeWidth: 25, overflow: true }, gap: 20, height: "100%", id: "fvdiiTztO", intervalControl: 3, itemAmount: 1, layoutId: "Gallery__fvdiiTztO", padding: 0, paddingBottom: 50, paddingLeft: 0, paddingPerSide: true, paddingRight: 0, paddingTop: 0, progressOptions: { dotsActiveOpacity: 1, dotsBackground: "rgba(0, 0, 0, 0)", dotsBlur: 0, dotsFill: "var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, rgb(16, 16, 20))", dotsGap: 10, dotsInset: 10, dotSize: 10, dotsOpacity: 0.5, dotsPadding: 10, dotsRadius: 50, showProgressDots: true }, slots: [/* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 550, width: "400px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-cwf5tq-container", "data-framer-name": "Ticker Image 1", inComponentSlot: true, layoutDependency, layoutId: "Gallery__uhVBKZA4b-container", name: "Ticker Image 1", nodeId: "uhVBKZA4b", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "uhVBKZA4b", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/bwP8CYttC1lINgPtK7lQja0.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/bwP8CYttC1lINgPtK7lQja0.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/bwP8CYttC1lINgPtK7lQja0.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/bwP8CYttC1lINgPtK7lQja0.png?width=1200&height=1200 1200w" }, ""), layoutId: "Gallery__uhVBKZA4b", name: "Ticker Image 1", style: { height: "100%", width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 550, width: "400px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1njhf5m-container", "data-framer-name": "Ticker Image 2", inComponentSlot: true, layoutDependency, layoutId: "Gallery__a1e8yCNF_-container", name: "Ticker Image 2", nodeId: "a1e8yCNF_", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "a1e8yCNF_", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 896, src: "https://framerusercontent.com/images/RbmRrHiT87wxDx7Cox6FOA1sM3k.png?width=896&height=1200", srcSet: "https://framerusercontent.com/images/RbmRrHiT87wxDx7Cox6FOA1sM3k.png?scale-down-to=1024&width=896&height=1200 764w,https://framerusercontent.com/images/RbmRrHiT87wxDx7Cox6FOA1sM3k.png?width=896&height=1200 896w" }, ""), layoutId: "Gallery__a1e8yCNF_", name: "Ticker Image 2", style: { height: "100%", width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 560, width: "407.2727px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-gv0qzm-container", "data-framer-name": "Ticker Image 3", inComponentSlot: true, layoutDependency, layoutId: "Gallery__YsIIzgt7F-container", name: "Ticker Image 3", nodeId: "YsIIzgt7F", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "YsIIzgt7F", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/tWbl1rD5H93nV4ujsuqC2FUaqKM.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/tWbl1rD5H93nV4ujsuqC2FUaqKM.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/tWbl1rD5H93nV4ujsuqC2FUaqKM.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/tWbl1rD5H93nV4ujsuqC2FUaqKM.png?width=1200&height=1200 1200w" }, ""), layoutId: "Gallery__YsIIzgt7F", name: "Ticker Image 3", style: { height: "100%", width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 550, width: "400px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-djbkjw-container", "data-framer-name": "Ticker Image 4", inComponentSlot: true, layoutDependency, layoutId: "Gallery__Tk8dkQUIc-container", name: "Ticker Image 4", nodeId: "Tk8dkQUIc", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "Tk8dkQUIc", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 960, src: "https://framerusercontent.com/images/A7yE2PBsrF4l2EgA4yTO9HiAcPQ.png?width=960&height=1200", srcSet: "https://framerusercontent.com/images/A7yE2PBsrF4l2EgA4yTO9HiAcPQ.png?scale-down-to=1024&width=960&height=1200 819w,https://framerusercontent.com/images/A7yE2PBsrF4l2EgA4yTO9HiAcPQ.png?width=960&height=1200 960w" }, ""), layoutId: "Gallery__Tk8dkQUIc", name: "Ticker Image 4", style: { height: "100%", width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 550, width: "400px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-14sq3u2-container", "data-framer-name": "Ticker Image 5", inComponentSlot: true, layoutDependency, layoutId: "Gallery__QonYEBobN-container", name: "Ticker Image 5", nodeId: "QonYEBobN", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "QonYEBobN", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/uIxBIlcieM1DRX71NtmymFxTUI.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/uIxBIlcieM1DRX71NtmymFxTUI.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/uIxBIlcieM1DRX71NtmymFxTUI.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/uIxBIlcieM1DRX71NtmymFxTUI.png?width=1200&height=1200 1200w" }, ""), layoutId: "Gallery__QonYEBobN", name: "Ticker Image 5", style: { height: "100%", width: "100%" }, width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 550, width: "400px", children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1cosb6b-container", "data-framer-name": "Ticker Image 6", inComponentSlot: true, layoutDependency, layoutId: "Gallery__uhafyGa0L-container", name: "Ticker Image 6", nodeId: "uhafyGa0L", rendersWithMotion: true, scopeId: "uS77kU2KV", children: /* @__PURE__ */ _jsx4(bwcX7mWF7_default, { height: "100%", id: "uhafyGa0L", jw2NQdsXq: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/ww0GmyZcc1yAIo8GBgwRahYQjtc.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/ww0GmyZcc1yAIo8GBgwRahYQjtc.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/ww0GmyZcc1yAIo8GBgwRahYQjtc.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/ww0GmyZcc1yAIo8GBgwRahYQjtc.png?width=1200&height=1200 1200w" }, ""), layoutId: "Gallery__uhafyGa0L", name: "Ticker Image 6", style: { height: "100%", width: "100%" }, width: "100%" }) }) })], startFrom: 0, style: { height: "100%", maxWidth: "100%", width: "100%" }, transitionControl: { damping: 40, delay: 0, mass: 1, stiffness: 200, type: "spring" }, width: "100%" }) }) })] }) }) }) });
});
var css2 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-djUoi.framer-qtsise, .framer-djUoi .framer-qtsise { display: block; }", ".framer-djUoi.framer-19qei4b { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 40px; height: min-content; justify-content: center; overflow: visible; padding: 0px 20px 0px 20px; position: relative; width: 100%; }", ".framer-djUoi .framer-68zoko-container { flex: none; height: 500px; position: relative; width: 100%; }", ".framer-djUoi .framer-cwf5tq-container, .framer-djUoi .framer-1njhf5m-container, .framer-djUoi .framer-djbkjw-container, .framer-djUoi .framer-14sq3u2-container, .framer-djUoi .framer-1cosb6b-container { aspect-ratio: 0.7272727272727273 / 1; height: var(--framer-aspect-ratio-supported, 550px); position: relative; width: 400px; }", ".framer-djUoi .framer-gv0qzm-container { aspect-ratio: 0.7272727272727273 / 1; height: var(--framer-aspect-ratio-supported, 560px); position: relative; width: 407px; }", ".framer-djUoi .framer-wtlm01-container { aspect-ratio: 0.6542056074766355 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 306px); max-width: 390px; position: relative; width: 100%; }", ".framer-djUoi.framer-v-mruugj.framer-19qei4b { overflow: hidden; padding: 0px 20px 0px 20px; width: 100%; }"];
var FrameruS77kU2KV = withCSS3(Component3, css2, "framer-djUoi");
var uS77kU2KV_default = FrameruS77kU2KV;
FrameruS77kU2KV.displayName = "Gallery";
FrameruS77kU2KV.defaultProps = { height: 500, width: 1440 };
addPropertyControls4(FrameruS77kU2KV, { variant: { options: ["Pe8WEpTQv", "RrP2167Cm"], optionTitles: ["Desktop", "Mobile"], title: "Variant", type: ControlType4.Enum } });
addFonts2(FrameruS77kU2KV, [{ explicitInter: true, fonts: [] }, ...TickerImageFonts, ...TickerFonts, ...SlideshowFonts], { supportsExplicitInterCodegen: true });
FrameruS77kU2KV.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader(bwcX7mWF7_default, {}, context)]);
} };
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FrameruS77kU2KV", "slots": [], "annotations": { "framerDisplayContentsDiv": "false", "framerColorSyntax": "true", "framerImmutableVariables": "true", "framerContractVersion": "1", "framerComponentViewportWidth": "true", "framerAutoSizeImages": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"RrP2167Cm":{"layout":["fixed","auto"]}}}', "framerIntrinsicHeight": "500", "framerIntrinsicWidth": "1440" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  uS77kU2KV_default as default
};
