/**
 * Props for ContactForm6 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Contactform6Props {
  [key: string]: unknown;
}
