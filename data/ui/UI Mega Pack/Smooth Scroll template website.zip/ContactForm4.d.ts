/**
 * Props for ContactForm4 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Contactform4Props {
  [key: string]: unknown;
}
