var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/G40DIZFR09dGWjv80UEm/Y2JeWomkArzlwWxo4EUq/P0trriao5.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addFonts, addPropertyControls, ControlType, cx, getFontsFromSharedStyle, RichText, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/2TktXTD1Ntlfr30EHSrd/vstI3e2NSopzowSu5VVx/di5fvJSis.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["FS;Manrope-medium"]);
var fonts = [{ explicitInter: true, fonts: [{ family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/BNWG6MUI4RTC6WEND2VPDH4MHMIVU3XZ/R5YXY5FMVG6PXU36GNEEA24MIPMEPGSM/CIM4KQCLZSMMLWPVH25IDDSTY4ENPHEY.woff2", weight: "500" }] }];
var css = ['.framer-EBMNQ .framer-styles-preset-1gg00x3:not(.rich-text-wrapper), .framer-EBMNQ .framer-styles-preset-1gg00x3.rich-text-wrapper h2 { --framer-font-family: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 16px; --framer-font-style: normal; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-letter-spacing: 0.5px; --framer-line-height: 100%; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-0c2325eb-32e6-4468-b86d-b2000f27f938, #ffffff); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className = "framer-EBMNQ";

// http-url:https://framerusercontent.com/modules/G40DIZFR09dGWjv80UEm/Y2JeWomkArzlwWxo4EUq/P0trriao5.js
var serializationHash = "framer-fRyMg";
var variantClassNames = { DKrz4mlZx: "framer-v-1b46a0z" };
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion.create(React.Fragment);
var getProps = ({ height, id, text, width, ...props }) => {
  return { ...props, Kf7JQm0Hr: text ?? props.Kf7JQm0Hr ?? "About us" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className2, layoutId, variant, Kf7JQm0Hr, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "DKrz4mlZx", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [className];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsx(motion.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-1b46a0z", className2, classNames), "data-framer-name": "Badge", layoutDependency, layoutId: "Badge__DKrz4mlZx", ref: refBinding, style: { backgroundColor: "var(--token-b1d7783f-5583-4e49-9d17-5f2ef803e56a, rgb(40, 40, 44))", borderBottomLeftRadius: 16, borderBottomRightRadius: 16, borderTopLeftRadius: 16, borderTopRightRadius: 16, ...style }, children: /* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.h2, { className: "framer-styles-preset-1gg00x3", "data-styles-preset": "di5fvJSis", children: "About us" }) }), className: "framer-1a4oes0", fonts: ["Inter"], layoutDependency, layoutId: "Badge__Vr8l1UgIX", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: Kf7JQm0Hr, verticalAlignment: "top", withExternalLayout: true }) }) }) }) });
});
var css2 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-fRyMg.framer-10656yz, .framer-fRyMg .framer-10656yz { display: block; }", ".framer-fRyMg.framer-1b46a0z { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: center; overflow: hidden; padding: 5px 12px 6px 12px; position: relative; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-fRyMg .framer-1a4oes0 { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", "@supports (background: -webkit-named-image(i)) and (not (font-palette:dark)) { .framer-fRyMg.framer-1b46a0z { gap: 0px; } .framer-fRyMg.framer-1b46a0z > * { margin: 0px; margin-left: calc(8px / 2); margin-right: calc(8px / 2); } .framer-fRyMg.framer-1b46a0z > :first-child { margin-left: 0px; } .framer-fRyMg.framer-1b46a0z > :last-child { margin-right: 0px; } }", ...css];
var FramerP0trriao5 = withCSS(Component, css2, "framer-fRyMg");
var P0trriao5_default = FramerP0trriao5;
FramerP0trriao5.displayName = "Badge";
FramerP0trriao5.defaultProps = { height: 27, width: 95 };
addPropertyControls(FramerP0trriao5, { Kf7JQm0Hr: { defaultValue: "About us", displayTextArea: false, title: "Text", type: ControlType.String } });
addFonts(FramerP0trriao5, [{ explicitInter: true, fonts: [{ family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/vQyevYAyHtARFwPqUzQGpnDs.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerP0trriao5", "slots": [], "annotations": { "framerComponentViewportWidth": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]}}}', "framerContractVersion": "1", "framerIntrinsicHeight": "27", "framerImmutableVariables": "true", "framerIntrinsicWidth": "95", "framerDisplayContentsDiv": "false", "framerVariables": '{"Kf7JQm0Hr":"text"}' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  P0trriao5_default as default
};
