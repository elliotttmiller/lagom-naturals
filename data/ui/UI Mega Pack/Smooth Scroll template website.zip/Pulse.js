var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/rPrVbDP2B66QlV6CoMCf/tzG4qyGDRRHnXzwg8jRY/Pulse.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { addPropertyControls, ControlType } from "./_framer-runtime.js";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";
function Pulse({ props, onAnimationComplete }) {
  const animateOut = props.direction === "out";
  return /* @__PURE__ */ _jsx(motion.div, { style: { position: "absolute", backgroundColor: props.style === "border" ? "none" : props.color, border: props.style === "border" ? `${props.borderWidth}px solid ${props.color}` : "none" }, variants: { in: { opacity: props.pulseOpacity, inset: "0px", borderRadius: props.radiusType == "full" ? 1e4 : props.radiusValue }, out: { opacity: 0, inset: `-${props.pulseSize}px`, borderRadius: props.radiusType == "full" ? 1e4 : props.radiusValue + props.pulseSize } }, initial: animateOut ? "in" : "out", animate: animateOut ? "out" : "in", transition: props.transition, onAnimationComplete });
}
function PulseEffect(props) {
  const [pulses, setPulses] = useState([]);
  useEffect(() => {
    const createPulse = () => {
      const newPulseKey = Date.now();
      setPulses((prevPulses) => [...prevPulses, newPulseKey]);
    };
    const interval = setInterval(createPulse, props.delay * 1e3);
    createPulse();
    return () => clearInterval(interval);
  }, []);
  const handleAnimationComplete = (completedPulseKey) => {
    setPulses((prevPulses) => prevPulses.filter((key) => key !== completedPulseKey));
  };
  return /* @__PURE__ */ _jsxs("div", { children: [pulses.map((key) => /* @__PURE__ */ _jsx(Pulse, { props, onAnimationComplete: () => handleAnimationComplete(key) }, key)), /* @__PURE__ */ _jsx("div", { style: { position: "absolute", inset: 0, backgroundColor: props.color, borderRadius: props.radiusType == "full" ? 1e4 : props.radiusValue } })] });
}
PulseEffect.displayName = "Pulse";
addPropertyControls(PulseEffect, { color: { type: ControlType.Color }, delay: { type: ControlType.Number, defaultValue: 1, min: 0.1, step: 0.01, unit: "s" }, direction: { type: ControlType.Enum, defaultValue: "out", options: ["in", "out"], optionTitles: ["In", "Out"], displaySegmentedControl: true }, pulseSize: { type: ControlType.Number, defaultValue: 20, min: 1, step: 1 }, pulseOpacity: { type: ControlType.Number, defaultValue: 0.5, min: 0, max: 1, step: 0.01 }, style: { type: ControlType.Enum, defaultValue: "solid", options: ["solid", "border"], optionTitles: ["Solid", "Outline"], displaySegmentedControl: true }, borderWidth: { type: ControlType.Number, defaultValue: 5, min: 1, step: 1, title: "Outline Width", hidden: (props) => props.style !== "border" }, radiusType: { type: ControlType.Enum, defaultValue: "full", options: ["full", "custom"], optionTitles: ["Full", "Custom"], displaySegmentedControl: true, title: "Radius" }, radiusValue: { type: ControlType.Number, defaultValue: 20, min: 1, step: 1, title: " ", hidden: (props) => props.radiusType !== "custom" }, transition: { type: ControlType.Transition, defaultValue: { type: "spring", stiffness: 150, damping: 60 } } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "PulseEffect", "slots": [], "annotations": { "framerIntrinsicHeight": "20", "framerIntrinsicWidth": "20", "framerSupportedLayoutWidth": "fixed", "framerContractVersion": "1", "framerSupportedLayoutHeight": "fixed" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  PulseEffect as default
};
