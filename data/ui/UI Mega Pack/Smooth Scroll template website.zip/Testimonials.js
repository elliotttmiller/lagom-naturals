var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/EpDb0lbn1KEivjiYgBGv/ox6OKCjDzJQysUEKbJk7/lcMJgSJHP.js
import { jsx as _jsx5, jsxs as _jsxs5 } from "react/jsx-runtime";
import { addFonts as addFonts3, addPropertyControls as addPropertyControls5, ComponentViewportProvider as ComponentViewportProvider2, ControlType as ControlType5, cx as cx3, forwardLoader, getFonts as getFonts2, SmartComponentScopedContainer as SmartComponentScopedContainer2, useComponentViewport as useComponentViewport3, useLocaleInfo as useLocaleInfo3, useVariantState as useVariantState3, withCSS as withCSS4 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup5, motion as motion5, MotionConfigContext as MotionConfigContext3 } from "framer-motion";
import * as React3 from "react";
import { useRef as useRef6 } from "react";

// http-url:https://framerusercontent.com/modules/B2xAlJLcN0gOnt11mSPw/plhC5PVnCMllW5QXjFK5/Ticker.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Children, useLayoutEffect, useEffect, useState, useRef, useMemo, useCallback, cloneElement, startTransition, forwardRef, useImperativeHandle } from "react";
import { addPropertyControls, ControlType, RenderTarget } from "./_framer-runtime.js";
import { useReducedMotion, LayoutGroup, useInView, useMotionValue, useTransform, motion, frame } from "framer-motion";
import { resize } from "@motionone/dom";
var MAX_DUPLICATED_ITEMS = 100;
var directionTransformers = { left: (offset) => `translateX(-${offset}px)`, right: (offset) => `translateX(${offset}px)`, top: (offset) => `translateY(-${offset}px)`, bottom: (offset) => `translateY(${offset}px)` };
function Ticker(props) {
  let { slots = [], gap, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft, speed, hoverFactor, direction, alignment, sizingOptions, fadeOptions, style } = props;
  const { fadeContent, overflow, fadeWidth, fadeInset, fadeAlpha } = fadeOptions;
  const { widthType, heightType } = sizingOptions;
  const paddingValue = paddingPerSide ? `${paddingTop}px ${paddingRight}px ${paddingBottom}px ${paddingLeft}px` : `${padding}px`;
  const currentTarget = RenderTarget.current();
  const isCanvas = currentTarget === RenderTarget.canvas || currentTarget === RenderTarget.export;
  const writingDirection = useWritingDirection();
  const filteredSlots = slots.filter(Boolean);
  const numChildren = Children.count(filteredSlots);
  const hasChildren = numChildren > 0;
  const offset = useMotionValue(0);
  const resolvedDirection = getTickerResolvedDirection(direction === true ? "left" : direction, writingDirection);
  const isHorizontal = resolvedDirection === "left" || resolvedDirection === "right";
  const transformer = directionTransformers[resolvedDirection];
  const transform = useTransform(offset, transformer);
  const parentRef = useRef(null);
  const childrenRef = useMemo(() => {
    return [{ current: null }, { current: null }];
  }, []);
  const [size, setSize] = useState({ parent: null, children: null });
  let clonedChildren = null;
  let dupedChildren = [];
  let duplicateBy = 0;
  let opacity = 0;
  if (isCanvas) {
    duplicateBy = numChildren ? Math.floor(10 / numChildren) : 0;
    opacity = 1;
  }
  if (!isCanvas && hasChildren && size.parent) {
    duplicateBy = Math.round(size.parent / size.children * 2) + 1;
    duplicateBy = Math.min(duplicateBy, MAX_DUPLICATED_ITEMS);
    opacity = 1;
  }
  const measure = useCallback(() => {
    if (hasChildren && parentRef.current) {
      const parentLength = isHorizontal ? parentRef.current.offsetWidth : parentRef.current.offsetHeight;
      const start = childrenRef[0].current ? isHorizontal ? childrenRef[0].current.offsetLeft : childrenRef[0].current.offsetTop : 0;
      const end = childrenRef[1].current ? isHorizontal ? childrenRef[1].current.offsetLeft + childrenRef[1].current.offsetWidth : childrenRef[1].current.offsetTop + childrenRef[1].current.offsetHeight : 0;
      const childrenLength = end - start + gap;
      startTransition(() => {
        setSize({ parent: parentLength, children: childrenLength });
      });
    }
  }, []);
  const childrenStyles = isCanvas ? { contentVisibility: "auto" } : {};
  if (hasChildren) {
    if (!isCanvas) {
      let initialResize = useRef(true);
      useLayoutEffect(() => {
        frame.read(measure, false, true);
        return resize(parentRef.current, ({ contentSize }) => {
          if (!initialResize.current && (contentSize.width || contentSize.height)) {
            frame.read(measure, false, true);
          }
          initialResize.current = false;
        });
      }, []);
    }
    clonedChildren = Children.map(filteredSlots, (child, index) => {
      let ref;
      if (index === 0) {
        ref = childrenRef[writingDirection === "rtl" && isHorizontal ? 1 : 0];
      }
      if (index === filteredSlots.length - 1) {
        ref = childrenRef[writingDirection === "rtl" && isHorizontal ? 0 : 1];
      }
      const size2 = { width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%" };
      return /* @__PURE__ */ _jsx(LayoutGroup, { inherit: "id", children: /* @__PURE__ */ _jsx(Wrapper, { ref, style: size2, children: /* @__PURE__ */ cloneElement(child, { style: { ...child.props?.style, ...size2, flexShrink: 0, ...childrenStyles }, layoutId: child.props.layoutId ? child.props.layoutId + "-original-" + index : void 0 }, child.props?.children) }) });
    });
  }
  const isInView = isCanvas ? true : useInView(parentRef);
  if (!isCanvas) {
    for (let i = 0; i < duplicateBy; i++) {
      dupedChildren = dupedChildren.concat(Children.map(filteredSlots, (child, childIndex) => {
        const size2 = { width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%", willChange: !isInView ? void 0 : "transform" };
        return /* @__PURE__ */ _jsx(LayoutGroup, { inherit: "id", children: /* @__PURE__ */ _jsx(Wrapper, { style: size2, children: /* @__PURE__ */ cloneElement(child, { key: i + " " + childIndex, style: { ...child.props?.style, width: widthType ? child.props?.width : "100%", height: heightType ? child.props?.height : "100%", flexShrink: 0, ...childrenStyles }, layoutId: child.props.layoutId ? child.props.layoutId + "-dupe-" + i : void 0 }, child.props?.children) }, i + "li" + childIndex) }, i + "lg" + childIndex);
      }));
    }
  }
  const animateToValue = size.children + size.children * Math.round(size.parent / size.children);
  const initialTime = useRef(null);
  const prevTime = useRef(null);
  const xOrY = useRef(0);
  const isHover = useRef(false);
  const isReducedMotion = useReducedMotion();
  const listRef = useRef(null);
  const animationRef = useRef(null);
  if (!isCanvas) {
    useEffect(() => {
      if (isReducedMotion || !animateToValue || !speed) {
        return;
      }
      animationRef.current = listRef.current.animate({ transform: [transformer(0), transformer(animateToValue)] }, { duration: Math.abs(animateToValue) / speed * 1e3, iterations: Infinity, iterationStart: writingDirection === "rtl" ? 1 : 0, easing: "linear" });
      return () => animationRef.current.cancel();
    }, [hoverFactor, animateToValue, speed, writingDirection]);
    const playOrPause = useCallback(() => {
      if (!animationRef.current)
        return;
      const hidden = document.hidden;
      if (isInView && !hidden && animationRef.current.playState === "paused") {
        animationRef.current.play();
      } else if ((!isInView || hidden) && animationRef.current.playState === "running") {
        animationRef.current.pause();
      }
    }, [isInView]);
    useEffect(() => {
      playOrPause();
    }, [isInView, hoverFactor, animateToValue, speed]);
    useEffect(() => {
      document.addEventListener("visibilitychange", playOrPause);
      return () => {
        document.removeEventListener("visibilitychange", playOrPause);
      };
    }, [playOrPause]);
  }
  const fadeDirection = isHorizontal ? "to right" : "to bottom";
  const fadeWidthStart = fadeWidth / 2;
  const fadeWidthEnd = 100 - fadeWidth / 2;
  const fadeInsetStart = clamp(fadeInset, 0, fadeWidthStart);
  const fadeInsetEnd = 100 - fadeInset;
  const fadeMask = `linear-gradient(${fadeDirection}, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetStart}%, rgba(0, 0, 0, 1) ${fadeWidthStart}%, rgba(0, 0, 0, 1) ${fadeWidthEnd}%, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetEnd}%)`;
  if (!hasChildren) {
    return /* @__PURE__ */ _jsxs("section", { style: placeholderStyles, children: [/* @__PURE__ */ _jsx("div", { style: emojiStyles, children: "\u2728" }), /* @__PURE__ */ _jsx("p", { style: titleStyles, children: "Connect to Content" }), /* @__PURE__ */ _jsx("p", { style: subtitleStyles, children: "Add layers or components to infinitely loop on your page." })] });
  }
  return /* @__PURE__ */ _jsx("section", { style: { ...containerStyle, opacity, WebkitMaskImage: fadeContent ? fadeMask : void 0, maskImage: fadeContent ? fadeMask : void 0, overflow: overflow ? "visible" : "hidden", padding: paddingValue }, ref: parentRef, children: /* @__PURE__ */ _jsxs(motion.ul, { ref: listRef, style: { ...containerStyle, gap, top: direction === "bottom" && isValidNumber(animateToValue) ? -animateToValue : void 0, left: direction === "right" && isValidNumber(animateToValue) ? animateToValue * (writingDirection === "rtl" ? 1 : -1) : void 0, placeItems: alignment, position: "relative", flexDirection: isHorizontal ? "row" : "column", ...style, willChange: isCanvas || !isInView ? "auto" : "transform", transform: transformer(0) }, onMouseEnter: () => {
    isHover.current = true;
    if (animationRef.current) {
      animationRef.current.playbackRate = hoverFactor;
    }
  }, onMouseLeave: () => {
    isHover.current = false;
    if (animationRef.current) {
      animationRef.current.playbackRate = 1;
    }
  }, children: [clonedChildren, dupedChildren] }) });
}
var Wrapper = /* @__PURE__ */ forwardRef(({ children, ...props }, ref) => {
  const innerRef = useRef();
  const inView = useInView(innerRef);
  useImperativeHandle(ref, () => innerRef.current);
  useEffect(() => {
    const current = innerRef.current;
    if (!current)
      return;
    if (inView) {
      current.querySelectorAll("button,a").forEach((el) => {
        const orig = el.dataset.origTabIndex;
        if (orig)
          el.tabIndex = orig;
        else
          el.removeAttribute("tabIndex");
      });
    } else {
      current.querySelectorAll("button,a").forEach((el) => {
        const orig = el.getAttribute("tabIndex");
        if (orig)
          el.dataset.origTabIndex = orig;
        el.tabIndex = -1;
      });
    }
  }, [inView]);
  return /* @__PURE__ */ _jsx("li", { ...props, "aria-hidden": !inView, ref: innerRef, children });
});
Ticker.defaultProps = { gap: 10, padding: 10, sizingOptions: { widthType: true, heightType: true }, fadeOptions: { fadeContent: true, overflow: false, fadeWidth: 25, fadeAlpha: 0, fadeInset: 0 }, direction: true };
addPropertyControls(Ticker, { slots: { type: ControlType.Array, title: "Children", control: { type: ControlType.ComponentInstance } }, speed: { type: ControlType.Number, title: "Speed", min: 0, max: 1e3, defaultValue: 100, unit: "%", displayStepper: true, step: 5 }, direction: { type: ControlType.Enum, title: "Direction", options: ["left", "right", "top", "bottom"], optionIcons: ["direction-left", "direction-right", "direction-up", "direction-down"], optionTitles: ["Left", "Right", "Top", "Bottom"], defaultValue: "left", displaySegmentedControl: true }, alignment: { type: ControlType.Enum, title: "Align", options: ["flex-start", "center", "flex-end"], optionIcons: { direction: { right: ["align-top", "align-middle", "align-bottom"], left: ["align-top", "align-middle", "align-bottom"], top: ["align-left", "align-center", "align-right"], bottom: ["align-left", "align-center", "align-right"] } }, defaultValue: "center", displaySegmentedControl: true }, gap: { type: ControlType.Number, title: "Gap" }, padding: { title: "Padding", type: ControlType.FusedNumber, toggleKey: "paddingPerSide", toggleTitles: ["Padding", "Padding per side"], valueKeys: ["paddingTop", "paddingRight", "paddingBottom", "paddingLeft"], valueLabels: ["T", "R", "B", "L"], min: 0 }, sizingOptions: { type: ControlType.Object, title: "Sizing", controls: { widthType: { type: ControlType.Boolean, title: "Width", enabledTitle: "Auto", disabledTitle: "Stretch", defaultValue: true }, heightType: { type: ControlType.Boolean, title: "Height", enabledTitle: "Auto", disabledTitle: "Stretch", defaultValue: true } } }, fadeOptions: { type: ControlType.Object, title: "Clipping", controls: { fadeContent: { type: ControlType.Boolean, title: "Fade", defaultValue: true }, overflow: { type: ControlType.Boolean, title: "Overflow", enabledTitle: "Show", disabledTitle: "Hide", defaultValue: false, hidden(props) {
  return props.fadeContent === true;
} }, fadeWidth: { type: ControlType.Number, title: "Width", defaultValue: 25, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeInset: { type: ControlType.Number, title: "Inset", defaultValue: 0, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeAlpha: { type: ControlType.Number, title: "Opacity", defaultValue: 0, min: 0, max: 1, step: 0.05, hidden(props) {
  return props.fadeContent === false;
} } } }, hoverFactor: { type: ControlType.Number, title: "Hover", min: 0, max: 1, unit: "x", defaultValue: 1, step: 0.1, displayStepper: true, description: "Slows down the speed while you are hovering." } });
var containerStyle = { display: "flex", width: "100%", height: "100%", maxWidth: "100%", maxHeight: "100%", placeItems: "center", margin: 0, padding: 0, listStyleType: "none", textIndent: "none" };
var placeholderStyles = { display: "flex", width: "100%", height: "100%", placeContent: "center", placeItems: "center", flexDirection: "column", color: "#96F", background: "rgba(136, 85, 255, 0.1)", fontSize: 11, overflow: "hidden", padding: "20px 20px 30px 20px" };
var emojiStyles = { fontSize: 32, marginBottom: 10 };
var titleStyles = { margin: 0, marginBottom: 10, fontWeight: 600, textAlign: "center" };
var subtitleStyles = { margin: 0, opacity: 0.7, maxWidth: 150, lineHeight: 1.5, textAlign: "center" };
var clamp = (num, min, max) => Math.min(Math.max(num, min), max);
var isValidNumber = (value) => typeof value === "number" && !isNaN(value);
function useWritingDirection() {
  if (!__dai_window || !__dai_window.document || !__dai_window.document.documentElement)
    return "ltr";
  return __dai_window.document.documentElement.dir === "rtl" ? "rtl" : "ltr";
}
function getTickerResolvedDirection(direction, writingDirection) {
  if (writingDirection !== "rtl")
    return direction;
  if (direction === "left")
    return "right";
  if (direction === "right")
    return "left";
  return direction;
}

// http-url:https://framerusercontent.com/modules/zvkTOpMSuRzRhLzZZIwG/7GuSIJ2Jm6VU0TIDHoiR/SlideShow.js
import { jsx as _jsx2, jsxs as _jsxs2 } from "react/jsx-runtime";
import { resize as resize2 } from "@motionone/dom";
import { ControlType as ControlType2, RenderTarget as RenderTarget2, addPropertyControls as addPropertyControls2, withCSS } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, animate, frame as frame2, mix, motion as motion2, useInView as useInView2, useMotionValue as useMotionValue2, usePageInView, useTransform as useTransform2, wrap } from "framer-motion";
import { Children as Children2, cloneElement as cloneElement2, forwardRef as forwardRef2, memo, startTransition as startTransition2, useCallback as useCallback3, useEffect as useEffect2, useLayoutEffect as useLayoutEffect3, useRef as useRef3, useState as useState2 } from "react";

// http-url:https://framerusercontent.com/modules/zvkTOpMSuRzRhLzZZIwG/7GuSIJ2Jm6VU0TIDHoiR/use-effect-event
import { useCallback as useCallback2, useLayoutEffect as useLayoutEffect2, useRef as useRef2 } from "react";
function useEffectEvent(fn) {
  const ref = useRef2(fn);
  useLayoutEffect2(() => {
    ref.current = fn;
  });
  return useCallback2((...args) => ref.current(...args), []);
}

// http-url:https://framerusercontent.com/modules/zvkTOpMSuRzRhLzZZIwG/7GuSIJ2Jm6VU0TIDHoiR/SlideShow.js
var slideshowClassName = "framer-slideshow";
var slideshowAxisXClassName = "framer-slideshow-axis-x";
var slideshowAxisYClassName = "framer-slideshow-axis-y";
var slideshowDirectionMultiplierVariable = "--framer-dir-multiplier";
var slideshowDirectionMultiplier = `var(${slideshowDirectionMultiplierVariable}, -1)`;
function SlideshowWithoutCSS(props) {
  const { slots = [], startFrom, direction, effectsOptions, autoPlayControl, dragControl, alignment, gap, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft, itemAmount: visibleItemsCount, fadeOptions, intervalControl, transitionControl, arrowOptions, borderRadius, progressOptions, style } = props;
  const { effectsOpacity, effectsScale, effectsRotate, effectsPerspective, effectsHover, playOffscreen } = effectsOptions;
  const { fadeContent, overflow, fadeWidth, fadeInset, fadeAlpha } = fadeOptions;
  const { showMouseControls, arrowSize, arrowRadius, arrowFill, leftArrow, rightArrow, arrowShouldSpace = true, arrowShouldFadeIn = false, arrowPosition, arrowPadding, arrowGap, arrowPaddingTop, arrowPaddingRight, arrowPaddingBottom, arrowPaddingLeft } = arrowOptions;
  const { showProgressDots, dotSize, dotsInset, dotsRadius, dotsPadding, dotsGap, dotsFill, dotsBackground, dotsActiveOpacity, dotsOpacity, dotsBlur } = progressOptions;
  const paddingValue = paddingPerSide ? `${paddingTop}px ${paddingRight}px ${paddingBottom}px ${paddingLeft}px` : `${padding}px`;
  const isCanvas = RenderTarget2.current() === RenderTarget2.canvas;
  const filteredSlots = slots.filter(Boolean);
  const totalItemsCount = Children2.count(filteredSlots);
  const hasChildren = totalItemsCount > 0;
  if (!hasChildren) {
    return /* @__PURE__ */ _jsxs2("section", { style: placeholderStyles2, children: [/* @__PURE__ */ _jsx2("div", { style: emojiStyles2, children: "\u2B50\uFE0F" }), /* @__PURE__ */ _jsx2("p", { style: titleStyles2, children: "Connect to Content" }), /* @__PURE__ */ _jsx2("p", { style: subtitleStyles2, children: "Add layers or components to make infinite auto-playing slideshows." })] });
  }
  const scheduleMeasureIfEverythingReady = useCallback3(() => {
    if (parentRef.current && firstChildRef.current && lastChildRef.current) {
      scheduleMeasure();
    }
  }, []);
  const parentRef = useRef3(null);
  const parentRefFn = useCallback3((node) => {
    parentRef.current = node;
    scheduleMeasureIfEverythingReady();
  }, [scheduleMeasureIfEverythingReady]);
  const firstChildRef = useRef3(null);
  const firstChildRefFn = useCallback3((node) => {
    firstChildRef.current = node;
    scheduleMeasureIfEverythingReady();
  }, [scheduleMeasureIfEverythingReady]);
  const lastChildRef = useRef3(null);
  const lastChildRefFn = useCallback3((node) => {
    lastChildRef.current = node;
    scheduleMeasureIfEverythingReady();
  }, [scheduleMeasureIfEverythingReady]);
  const [size, setSize] = useState2({ parent: null, children: null, item: null, itemWidth: null, itemHeight: null, viewportLength: null });
  const isHorizontal = direction === "left" || direction === "right";
  const writingDirection = useWritingDirection2();
  const rtlDirectionModifier = isHorizontal && writingDirection === "rtl" ? -1 : 1;
  const [isHovering, setIsHovering] = useState2(false);
  const [shouldPlayOnHover, setShouldPlayOnHover] = useState2(autoPlayControl);
  const [isMouseDown, setIsMouseDown] = useState2(false);
  const isInitialized = size?.item !== null && size?.parent !== null && writingDirection !== null;
  const extraCopyCount = Math.ceil((startFrom + visibleItemsCount) / totalItemsCount);
  let dupedChildren = [];
  let duplicateBy = extraCopyCount * 4;
  if (isCanvas || !isInitialized) {
    duplicateBy = extraCopyCount;
  }
  const [currentItem, setCurrentItem] = useState2(startFrom + totalItemsCount);
  useEffect2(() => {
    if (!size.item || !writingDirection)
      return;
    const computedNewPosition = -1 * currentItem * ((size.item ?? 0) + gap) * (writingDirection === "rtl" ? -1 : 1);
    if (xOrY.get() !== computedNewPosition) {
      animate(xOrY, computedNewPosition, transitionControl);
    }
  }, [currentItem, size.item, gap, writingDirection]);
  const measure = () => {
    if (!parentRef.current || !firstChildRef.current || !lastChildRef.current)
      return;
    const writingDirection2 = getWritingDirection();
    const isRTL = isHorizontal && writingDirection2 === "rtl";
    const firstChild = isRTL ? lastChildRef.current : firstChildRef.current;
    const lastChild = isRTL ? firstChildRef.current : lastChildRef.current;
    const parentLength = isHorizontal ? parentRef.current.offsetWidth : parentRef.current.offsetHeight;
    const start = firstChild ? isHorizontal ? firstChild.offsetLeft : firstChild.offsetTop : 0;
    const end = lastChild ? isHorizontal ? lastChild.offsetLeft + lastChild.offsetWidth : lastChild.offsetTop + lastChild.offsetHeight : 0;
    const childrenLength = end - start + gap;
    const itemSize = firstChild ? isHorizontal ? firstChild.offsetWidth : firstChild.offsetHeight : 0;
    const itemWidth = firstChild ? firstChild.offsetWidth : 0;
    const itemHeight = firstChild ? firstChild.offsetHeight : 0;
    const viewportLength = isHorizontal ? Math.max(document.documentElement.clientWidth || 0, __dai_window.innerWidth || 0, parentRef.current.offsetWidth) : Math.max(document.documentElement.clientHeight || 0, __dai_window.innerHeight || 0, parentRef.current.offsetHeight);
    setSize({ parent: parentLength, children: childrenLength, item: itemSize, itemWidth, itemHeight, viewportLength });
  };
  const scheduleMeasure = useEffectEvent(async () => {
    frame2.read(measure, false, true);
  });
  useLayoutEffect3(() => {
    scheduleMeasure();
  }, [slots.length, visibleItemsCount, gap, direction, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft]);
  useEffect2(() => {
    const node = parentRef.current;
    if (!node)
      return;
    return resize2(node, ({ contentSize }) => {
      if (contentSize.width || contentSize.height) {
        scheduleMeasure();
      }
    });
  }, []);
  const childrenSize = isCanvas ? 0 : size?.children;
  const [isDragging, setIsDragging] = useState2(false);
  const visibilityRef = useRef3(null);
  const isInView = useInView2(visibilityRef);
  const isVisible = usePageInView() && isInView;
  const xOrY = useMotionValue2(childrenSize);
  const wrappedXOrY = !isCanvas ? useTransform2(xOrY, (value) => {
    const resolvedChildrenSize = childrenSize ?? 0;
    const resolvedValue = value ?? 0;
    const wrapped = wrap(-resolvedChildrenSize * rtlDirectionModifier, -resolvedChildrenSize * rtlDirectionModifier * 2, resolvedValue);
    return Number.isNaN(wrapped) ? 0 : wrapped;
  }) : 0;
  const wrappedIndex = wrap(0, totalItemsCount, currentItem);
  const setDelta = (delta) => {
    startTransition2(() => setCurrentItem((item) => item + delta));
  };
  const setPage = (index) => {
    const currentItemWrapped = wrap(0, totalItemsCount, currentItem);
    const goto = index - currentItemWrapped;
    startTransition2(() => setCurrentItem((item) => item + goto));
  };
  const autoplayStep = (direction === "right" || direction === "bottom" ? -1 : 1) * rtlDirectionModifier;
  const canAutoplay = autoPlayControl && shouldPlayOnHover && (playOffscreen || isVisible) && !isCanvas && totalItemsCount > 1 && !isDragging && isInitialized;
  useEffect2(() => {
    if (!canAutoplay)
      return;
    const timeoutId = setTimeout(() => {
      setDelta(autoplayStep);
    }, intervalControl * 1e3);
    return () => clearTimeout(timeoutId);
  }, [canAutoplay, autoplayStep, intervalControl, currentItem]);
  const handleDragStart = () => {
    startTransition2(() => setIsDragging(true));
  };
  const handleDragEnd = (event, { offset, velocity }) => {
    startTransition2(() => setIsDragging(false));
    const offsetXorY = isHorizontal ? offset.x : offset.y;
    const velocityThreshold = 200;
    const velocityXorY = isHorizontal ? velocity.x : velocity.y;
    const isHalfOfNext = offsetXorY < -size.item / 2;
    const isHalfOfPrev = offsetXorY > size.item / 2;
    const normalizedOffset = Math.abs(offsetXorY);
    const itemDelta = Math.round(normalizedOffset / size.item);
    const itemDeltaFromOne = itemDelta === 0 ? 1 : itemDelta;
    if (velocityXorY > velocityThreshold) {
      setDelta(-itemDeltaFromOne * rtlDirectionModifier);
    } else if (velocityXorY < -velocityThreshold) {
      setDelta(itemDeltaFromOne * rtlDirectionModifier);
    } else {
      if (isHalfOfNext) {
        setDelta(itemDelta * rtlDirectionModifier);
      }
      if (isHalfOfPrev) {
        setDelta(-itemDelta * rtlDirectionModifier);
      }
    }
  };
  const staticStartFrom = Math.max(0, Math.min(startFrom ?? 0, Math.max(0, totalItemsCount - 1)));
  const staticPercentOffset = staticStartFrom * 100 / visibleItemsCount;
  const staticPixelOffset = staticStartFrom * gap / visibleItemsCount;
  let childCounter = 0;
  const columnOrRowValue = `calc(${100 / visibleItemsCount}% - ${gap}px + ${gap / visibleItemsCount}px)`;
  for (let index = 0; index < duplicateBy; index++) {
    dupedChildren = dupedChildren.concat(Children2.map(filteredSlots, (child, childIndex) => {
      let ref;
      if (index === 0) {
        if (childIndex === 0) {
          ref = firstChildRefFn;
        } else if (childIndex === filteredSlots.length - 1) {
          ref = lastChildRefFn;
        }
      }
      return /* @__PURE__ */ _jsx2(Slide, { ref, slideKey: index + childIndex + "lg", index, width: isHorizontal ? visibleItemsCount > 1 ? columnOrRowValue : "100%" : "100%", height: !isHorizontal ? visibleItemsCount > 1 ? columnOrRowValue : "100%" : "100%", size, child, numChildren: filteredSlots?.length, wrappedXOrY, childCounter: childCounter++, gap, isCanvas, isInitialized, isHorizontal, effectsOpacity, effectsScale, effectsRotate, writingDirection, rtlDirectionModifier, children: index + childIndex }, index + childIndex + "lg");
    }));
  }
  const fadeDirection = isHorizontal ? "to right" : "to bottom";
  const fadeWidthStart = fadeWidth / 2;
  const fadeWidthEnd = 100 - fadeWidth / 2;
  const fadeInsetStart = clamp2(fadeInset, 0, fadeWidthStart);
  const fadeInsetEnd = 100 - fadeInset;
  const fadeMask = `linear-gradient(${fadeDirection}, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetStart}%, rgba(0, 0, 0, 1) ${fadeWidthStart}%, rgba(0, 0, 0, 1) ${fadeWidthEnd}%, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetEnd}%)`;
  const dots = [];
  const dotsBlurStyle = {};
  if (showProgressDots) {
    for (let i = 0; i < filteredSlots?.length; i++) {
      dots.push(/* @__PURE__ */ _jsx2(Dot, { dotStyle: { ...dotStyle, width: dotSize, height: dotSize, backgroundColor: dotsFill }, buttonStyle: baseButtonStyles, selectedOpacity: dotsActiveOpacity, opacity: dotsOpacity, disabled: !isCanvas && !isInitialized, onClick: () => setPage(i), wrappedIndex: isCanvas || !isInitialized ? staticStartFrom : wrappedIndex, total: totalItemsCount, index: i, gap: dotsGap, padding: dotsPadding, isHorizontal }, i));
    }
    if (dotsBlur > 0) {
      dotsBlurStyle.backdropFilter = dotsBlurStyle.WebkitBackdropFilter = `blur(${dotsBlur}px)`;
    }
  }
  const dragProps = isInitialized && dragControl ? { drag: isHorizontal ? "x" : "y", onDragStart: handleDragStart, onDragEnd: handleDragEnd, dragDirectionLock: true, values: { x: writingDirection === "rtl" ? -xOrY : xOrY, y: xOrY }, dragMomentum: false } : {};
  const arrowHasTop = arrowPosition === "top-left" || arrowPosition === "top-mid" || arrowPosition === "top-right";
  const arrowHasBottom = arrowPosition === "bottom-left" || arrowPosition === "bottom-mid" || arrowPosition === "bottom-right";
  const arrowHasLeft = arrowPosition === "top-left" || arrowPosition === "bottom-left";
  const arrowHasRight = arrowPosition === "top-right" || arrowPosition === "bottom-right";
  const arrowHasMid = arrowPosition === "top-mid" || arrowPosition === "bottom-mid" || arrowPosition === "auto";
  const leftArrowSrc = leftArrow || "https://framerusercontent.com/images/6tTbkXggWgQCAJ4DO2QEdXXmgM.svg?arrow=left";
  const rightArrowSrc = rightArrow || "https://framerusercontent.com/images/11KSGbIZoRSg4pjdnUoif6MKHI.svg?arrow=right";
  return /* @__PURE__ */ _jsxs2("section", { className: `${slideshowClassName} ${isHorizontal ? slideshowAxisXClassName : slideshowAxisYClassName}`, style: { ...containerStyle2, padding: paddingValue, WebkitMaskImage: fadeContent ? fadeMask : void 0, maskImage: fadeContent ? fadeMask : void 0, userSelect: "none" }, onMouseEnter: () => {
    setIsHovering(true);
    if (!effectsHover)
      setShouldPlayOnHover(false);
  }, onMouseLeave: () => {
    setIsHovering(false);
    if (!effectsHover)
      setShouldPlayOnHover(true);
  }, onMouseDown: (event) => {
    event.preventDefault();
    startTransition2(() => setIsMouseDown(true));
  }, onMouseUp: () => startTransition2(() => setIsMouseDown(false)), ref: visibilityRef, children: [/* @__PURE__ */ _jsx2("div", { style: { width: "100%", height: "100%", margin: 0, padding: "inherit", position: "absolute", inset: 0, overflow: overflow ? "visible" : "hidden", borderRadius, userSelect: "none", perspective: isCanvas ? "none" : effectsPerspective }, children: /* @__PURE__ */ _jsx2(motion2.ul, { ref: parentRefFn, ...dragProps, style: { ...containerStyle2, gap, placeItems: alignment, ...isCanvas || !isInitialized ? { transform: isHorizontal ? `translateX(calc(${slideshowDirectionMultiplier} * (${staticPercentOffset}% + ${staticPixelOffset}px)))` : `translateY(calc(${slideshowDirectionMultiplier} * (${staticPercentOffset}% + ${staticPixelOffset}px)))` } : { x: isHorizontal ? wrappedXOrY : 0, y: !isHorizontal ? wrappedXOrY : 0 }, flexDirection: isHorizontal ? "row" : "column", transformStyle: effectsRotate !== 0 && !isCanvas ? "preserve-3d" : void 0, cursor: (isCanvas || isInitialized) && dragControl ? isMouseDown ? "grabbing" : "grab" : "auto", userSelect: "none", ...style }, children: dupedChildren }) }), /* @__PURE__ */ _jsxs2("fieldset", { style: { ...controlsStyles }, "aria-label": "Slideshow pagination controls", className: "framer--slideshow-controls", children: [/* @__PURE__ */ _jsxs2(motion2.div, { style: { position: "absolute", display: "flex", flexDirection: isHorizontal ? "row" : "column", justifyContent: arrowShouldSpace ? "space-between" : "center", gap: arrowShouldSpace ? "unset" : arrowGap, opacity: arrowShouldFadeIn || !isCanvas && !isInitialized ? 0 : 1, alignItems: "center", inset: arrowPadding, top: arrowShouldSpace ? arrowPadding : arrowHasTop ? arrowPaddingTop : "unset", left: arrowShouldSpace ? arrowPadding : arrowHasLeft ? arrowPaddingLeft : arrowHasMid ? 0 : "unset", right: arrowShouldSpace ? arrowPadding : arrowHasRight ? arrowPaddingRight : arrowHasMid ? 0 : "unset", bottom: arrowShouldSpace ? arrowPadding : arrowHasBottom ? arrowPaddingBottom : "unset" }, animate: isCanvas || isInitialized ? arrowShouldFadeIn ? { opacity: isHovering ? 1 : 0 } : { opacity: 1 } : { opacity: 0 }, transition: transitionControl, children: [/* @__PURE__ */ _jsx2(motion2.button, { type: "button", style: { ...baseButtonStyles, backgroundColor: arrowFill, width: arrowSize, height: arrowSize, borderRadius: arrowRadius, rotate: !isHorizontal ? 90 : 0, display: showMouseControls ? "block" : "none", pointerEvents: isCanvas || isInitialized ? "auto" : "none", cursor: isCanvas || isInitialized ? "pointer" : "default" }, disabled: !(isCanvas || isInitialized), onClick: () => setDelta(-1), "aria-label": "Previous", whileTap: { scale: 0.9 }, transition: { duration: 0.15 }, children: /* @__PURE__ */ _jsx2("img", { decoding: "async", width: arrowSize, height: arrowSize, src: isHorizontal && writingDirection === "rtl" ? rightArrowSrc : leftArrowSrc, alt: "Back Arrow" }) }), /* @__PURE__ */ _jsx2(motion2.button, { type: "button", style: { ...baseButtonStyles, backgroundColor: arrowFill, width: arrowSize, height: arrowSize, borderRadius: arrowRadius, rotate: !isHorizontal ? 90 : 0, display: showMouseControls ? "block" : "none", pointerEvents: isCanvas || isInitialized ? "auto" : "none", cursor: isCanvas || isInitialized ? "pointer" : "default" }, disabled: !(isCanvas || isInitialized), onClick: () => setDelta(1), "aria-label": "Next", whileTap: { scale: 0.9 }, transition: { duration: 0.15 }, children: /* @__PURE__ */ _jsx2("img", { decoding: "async", width: arrowSize, height: arrowSize, src: isHorizontal && writingDirection === "rtl" ? leftArrowSrc : rightArrowSrc, alt: "Next Arrow" }) })] }), dots.length > 1 ? /* @__PURE__ */ _jsx2(motion2.div, { style: {
    ...dotsContainerStyle,
    left: isHorizontal ? "50%" : dotsInset,
    top: !isHorizontal ? "50%" : "unset",
    transform: isHorizontal ? "translateX(-50%)" : "translateY(-50%)",
    flexDirection: isHorizontal ? "row" : "column",
    bottom: isHorizontal ? dotsInset : "unset",
    borderRadius: dotsRadius,
    backgroundColor: dotsBackground,
    userSelect: "none",
    ...dotsBlurStyle,
    // Hard-code opacity to 1 on canvas. In SSR, it will be animated from 0 to 1 in `animate`
    opacity: isCanvas ? 1 : 0,
    pointerEvents: isCanvas || isInitialized ? "auto" : "none"
  }, animate: { opacity: isInitialized ? 1 : 0 }, transition: { duration: 0.35, ease: "easeOut" }, children: dots }) : null] })] });
}
var Slideshow = withCSS(SlideshowWithoutCSS, [`.${slideshowAxisXClassName} { ${slideshowDirectionMultiplierVariable}: -1; }`, `html[dir="rtl"] .${slideshowAxisXClassName} { ${slideshowDirectionMultiplierVariable}: 1; }`, `.${slideshowAxisYClassName} { ${slideshowDirectionMultiplierVariable}: -1; }`], "framer-slideshow-component");
var SlideShow_default = Slideshow;
Slideshow.defaultProps = { direction: "left", dragControl: false, startFrom: 0, itemAmount: 1, infinity: true, gap: 10, padding: 10, autoPlayControl: true, effectsOptions: { effectsOpacity: 1, effectsScale: 1, effectsRotate: 0, effectsPerspective: 1200, effectsHover: true, playOffscreen: false }, transitionControl: { type: "spring", stiffness: 200, damping: 40 }, fadeOptions: { fadeContent: false, overflow: false, fadeWidth: 25, fadeAlpha: 0, fadeInset: 0 }, arrowOptions: { showMouseControls: true, arrowShouldFadeIn: false, arrowShouldSpace: true, arrowFill: "rgba(0,0,0,0.2)", arrowSize: 40 }, progressOptions: { showProgressDots: true } };
addPropertyControls2(Slideshow, { slots: { type: ControlType2.Array, title: "Content", control: { type: ControlType2.ComponentInstance } }, direction: { type: ControlType2.Enum, title: "Direction", options: ["left", "right", "top", "bottom"], optionIcons: ["direction-left", "direction-right", "direction-up", "direction-down"], optionTitles: ["Left", "Right", "Top", "Bottom"], displaySegmentedControl: true, defaultValue: Slideshow.defaultProps.direction }, autoPlayControl: { type: ControlType2.Boolean, title: "Auto Play", defaultValue: true }, intervalControl: { type: ControlType2.Number, title: "Interval", defaultValue: 1.5, min: 0.5, max: 10, step: 0.1, displayStepper: true, unit: "s", hidden: (props) => !props.autoPlayControl }, dragControl: { type: ControlType2.Boolean, title: "Draggable", defaultValue: false }, startFrom: { type: ControlType2.Number, title: "Current", min: 0, max: 10, displayStepper: true, defaultValue: Slideshow.defaultProps.startFrom }, effectsOptions: { type: ControlType2.Object, title: "Effects", controls: { effectsOpacity: { type: ControlType2.Number, title: "Opacity", defaultValue: Slideshow.defaultProps.effectsOptions.effectsOpacity, min: 0, max: 1, step: 0.01, displayStepper: true }, effectsScale: { type: ControlType2.Number, title: "Scale", defaultValue: Slideshow.defaultProps.effectsOptions.effectsScale, min: 0, max: 1, step: 0.01, displayStepper: true }, effectsPerspective: { type: ControlType2.Number, title: "Perspective", defaultValue: Slideshow.defaultProps.effectsOptions.effectsPerspective, min: 200, max: 2e3, step: 1 }, effectsRotate: { type: ControlType2.Number, title: "Rotate", defaultValue: Slideshow.defaultProps.effectsOptions.effectsRotate, min: -180, max: 180, step: 1 }, effectsHover: { type: ControlType2.Boolean, title: "On Hover", enabledTitle: "Play", disabledTitle: "Pause", defaultValue: Slideshow.defaultProps.effectsOptions.effectsHover }, playOffscreen: { type: ControlType2.Boolean, title: "Offscreen", enabledTitle: "Play", disabledTitle: "Pause", defaultValue: Slideshow.defaultProps.effectsOptions.playOffscreen } } }, alignment: { type: ControlType2.Enum, title: "Align", options: ["flex-start", "center", "flex-end"], optionIcons: { direction: { right: ["align-top", "align-middle", "align-bottom"], left: ["align-top", "align-middle", "align-bottom"], top: ["align-left", "align-center", "align-right"], bottom: ["align-left", "align-center", "align-right"] } }, defaultValue: "center", displaySegmentedControl: true }, itemAmount: { type: ControlType2.Number, title: "Items", min: 1, max: 10, displayStepper: true, defaultValue: Slideshow.defaultProps.itemAmount }, gap: { type: ControlType2.Number, title: "Gap", min: 0 }, padding: { title: "Padding", type: ControlType2.FusedNumber, toggleKey: "paddingPerSide", toggleTitles: ["Padding", "Padding per side"], defaultValue: 0, valueKeys: ["paddingTop", "paddingRight", "paddingBottom", "paddingLeft"], valueLabels: ["T", "R", "B", "L"], min: 0 }, borderRadius: { type: ControlType2.Number, title: "Radius", min: 0, max: 500, displayStepper: true, defaultValue: 0 }, transitionControl: { type: ControlType2.Transition, defaultValue: Slideshow.defaultProps.transitionControl, title: "Transition" }, fadeOptions: { type: ControlType2.Object, title: "Clipping", controls: { fadeContent: { type: ControlType2.Boolean, title: "Fade", defaultValue: false }, overflow: { type: ControlType2.Boolean, title: "Overflow", enabledTitle: "Show", disabledTitle: "Hide", defaultValue: false, hidden(props) {
  return props.fadeContent === true;
} }, fadeWidth: { type: ControlType2.Number, title: "Width", defaultValue: 25, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeInset: { type: ControlType2.Number, title: "Inset", defaultValue: 0, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeAlpha: { type: ControlType2.Number, title: "Opacity", defaultValue: 0, min: 0, max: 1, step: 0.05, hidden(props) {
  return props.fadeContent === false;
} } } }, arrowOptions: { type: ControlType2.Object, title: "Arrows", controls: { showMouseControls: { type: ControlType2.Boolean, title: "Show", defaultValue: Slideshow.defaultProps.arrowOptions.showMouseControls }, arrowFill: { type: ControlType2.Color, title: "Fill", hidden: (props) => !props.showMouseControls, defaultValue: Slideshow.defaultProps.arrowOptions.arrowFill }, leftArrow: { type: ControlType2.Image, title: "Previous", hidden: (props) => !props.showMouseControls }, rightArrow: { type: ControlType2.Image, title: "Next", hidden: (props) => !props.showMouseControls }, arrowSize: { type: ControlType2.Number, title: "Size", min: 0, max: 200, displayStepper: true, defaultValue: Slideshow.defaultProps.arrowOptions.arrowSize, hidden: (props) => !props.showMouseControls }, arrowRadius: { type: ControlType2.Number, title: "Radius", min: 0, max: 500, defaultValue: 40, hidden: (props) => !props.showMouseControls }, arrowShouldFadeIn: { type: ControlType2.Boolean, title: "Fade In", defaultValue: false, hidden: (props) => !props.showMouseControls }, arrowShouldSpace: { type: ControlType2.Boolean, title: "Distance", enabledTitle: "Space", disabledTitle: "Group", defaultValue: Slideshow.defaultProps.arrowOptions.arrowShouldSpace, hidden: (props) => !props.showMouseControls }, arrowPosition: { type: ControlType2.Enum, title: "Position", options: ["auto", "top-left", "top-mid", "top-right", "bottom-left", "bottom-mid", "bottom-right"], optionTitles: ["Center", "Top Left", "Top Middle", "Top Right", "Bottom Left", "Bottom Middle", "Bottom Right"], hidden: (props) => !props.showMouseControls || props.arrowShouldSpace }, arrowPadding: { type: ControlType2.Number, title: "Inset", min: -100, max: 100, defaultValue: 20, displayStepper: true, hidden: (props) => !props.showMouseControls || !props.arrowShouldSpace }, arrowPaddingTop: { type: ControlType2.Number, title: "Top", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "bottom-mid" || props.arrowPosition === "bottom-left" || props.arrowPosition === "bottom-right" }, arrowPaddingBottom: { type: ControlType2.Number, title: "Bottom", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "top-mid" || props.arrowPosition === "top-left" || props.arrowPosition === "top-right" }, arrowPaddingRight: { type: ControlType2.Number, title: "Right", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "top-left" || props.arrowPosition === "top-mid" || props.arrowPosition === "bottom-left" || props.arrowPosition === "bottom-mid" }, arrowPaddingLeft: { type: ControlType2.Number, title: "Left", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "top-right" || props.arrowPosition === "top-mid" || props.arrowPosition === "bottom-right" || props.arrowPosition === "bottom-mid" }, arrowGap: { type: ControlType2.Number, title: "Gap", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace } } }, progressOptions: { type: ControlType2.Object, title: "Dots", controls: { showProgressDots: { type: ControlType2.Boolean, title: "Show", defaultValue: false }, dotSize: { type: ControlType2.Number, title: "Size", min: 1, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsInset: { type: ControlType2.Number, title: "Inset", min: -100, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsGap: { type: ControlType2.Number, title: "Gap", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsPadding: { type: ControlType2.Number, title: "Padding", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsFill: { type: ControlType2.Color, title: "Fill", defaultValue: "#fff", hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsBackground: { type: ControlType2.Color, title: "Backdrop", defaultValue: "rgba(0,0,0,0.2)", hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsRadius: { type: ControlType2.Number, title: "Radius", min: 0, max: 200, defaultValue: 50, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsOpacity: { type: ControlType2.Number, title: "Opacity", min: 0, max: 1, defaultValue: 0.5, step: 0.1, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsActiveOpacity: { type: ControlType2.Number, title: "Current", min: 0, max: 1, defaultValue: 1, step: 0.1, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsBlur: { type: ControlType2.Number, title: "Blur", min: 0, max: 50, defaultValue: 0, step: 1, hidden: (props) => !props.showProgressDots || props.showScrollbar } } } });
var containerStyle2 = { display: "flex", flexDirection: "row", width: "100%", height: "100%", maxWidth: "100%", maxHeight: "100%", placeItems: "center", margin: 0, padding: 0, listStyleType: "none", textIndent: "none" };
var placeholderStyles2 = { display: "flex", width: "100%", height: "100%", placeContent: "center", placeItems: "center", flexDirection: "column", color: "#96F", background: "rgba(136, 85, 255, 0.1)", fontSize: 11, overflow: "hidden", padding: "20px 20px 30px 20px" };
var emojiStyles2 = { fontSize: 32, marginBottom: 10 };
var titleStyles2 = { margin: 0, marginBottom: 10, fontWeight: 600, textAlign: "center" };
var subtitleStyles2 = { margin: 0, opacity: 0.7, maxWidth: 180, lineHeight: 1.5, textAlign: "center" };
var baseButtonStyles = { border: "none", display: "flex", placeContent: "center", placeItems: "center", overflow: "hidden", background: "transparent", cursor: "pointer", margin: 0, padding: 0 };
var controlsStyles = { display: "flex", justifyContent: "space-between", alignItems: "center", position: "absolute", pointerEvents: "none", userSelect: "none", top: 0, left: 0, right: 0, bottom: 0, border: 0, padding: 0, margin: 0 };
var clamp2 = (num, min, max) => Math.min(Math.max(num, min), max);
var Slide = /* @__PURE__ */ memo(/* @__PURE__ */ forwardRef2(function Component(props, ref) {
  const {
    slideKey,
    width,
    height,
    child,
    size,
    gap,
    wrappedXOrY,
    numChildren,
    childCounter,
    isCanvas,
    isInitialized,
    effects,
    effectsOpacity,
    effectsScale,
    effectsRotate,
    isHorizontal,
    isLast,
    index,
    /** "ltr" or "rtl" */
    writingDirection,
    /** -1 in RTL, 1 in LTR */
    rtlDirectionModifier
  } = props;
  const fallbackRef = useRef3();
  const itemSize = size?.item ?? 0;
  const parentSize = size?.parent ?? 0;
  const childOffset = (itemSize + gap) * childCounter;
  const scrollRange = (
    // @ivan: this was picked experimentally when fixing semi-working-but-broken RTL
    // implementation in the existing Carousel code. Don’t ask me why these specific values, I’m
    // finding it hard to fully reason about RTL in carousel :/
    (isHorizontal && writingDirection === "rtl" ? [itemSize - gap, 0, -parentSize + itemSize - gap, -parentSize - gap] : [-itemSize, 0, parentSize - itemSize + gap, parentSize]).map((val) => val - childOffset * rtlDirectionModifier)
  );
  const rotateY = !isCanvas && useTransform2(
    wrappedXOrY,
    scrollRange,
    // Why flip the rotateY effect when RTL is enabled?
    //
    // Unlike other effects, rotation is vertically symmetrical. Say the user sets a 60 degree rotation.
    // The carousel will look like this:
    //   ) □ ▣ ▤ (
    // where
    // - □ ▣ ▤ are the three slides visible within the carousel,
    // - ) is an out-of-view slide to the left of the viewport,
    // - and ( is an out-of-view slide to the right of the viewport.
    // With 60° rotation, both out-of-view slides look “turned towards” the viewport,
    // which matters for the animation when the slides switch.
    //
    // If a user sets RTL, all items in the carousel will flip around. The carousel, by default, will now look like this:
    //   ( ▤ ▣ □ )
    // Notice how all slides reversed. The slide that was to the left of the viewport: ) – is now to the right of it!
    // And is now turned away from the viewport! So if we don’t flip the rotateY effect, the animation will look off.
    isHorizontal && writingDirection === "rtl" ? [effectsRotate, 0, 0, -effectsRotate] : [-effectsRotate, 0, 0, effectsRotate]
  );
  const rotateX = !isCanvas && useTransform2(wrappedXOrY, scrollRange, [effectsRotate, 0, 0, -effectsRotate]);
  const opacity = !isCanvas && useTransform2(wrappedXOrY, scrollRange, [effectsOpacity, 1, 1, effectsOpacity]);
  const scale = !isCanvas && useTransform2(wrappedXOrY, scrollRange, [effectsScale, 1, 1, effectsScale]);
  const originXorY = !isCanvas && useTransform2(
    wrappedXOrY,
    scrollRange,
    // Just like above, because in RTL, the items are flipped vertically, RTL needs a separate treatment
    isHorizontal && writingDirection === "rtl" ? [0, 0, 1, 1] : [1, 1, 0, 0]
  );
  const isVisible = !isCanvas && useTransform2(wrappedXOrY, (latest) => {
    const min = Math.min(scrollRange[1], scrollRange[2]);
    const max = Math.max(scrollRange[1], scrollRange[2]);
    return latest >= min && latest <= max;
  });
  useEffect2(() => {
    if (!isVisible || !isInitialized)
      return;
    function manageVisibility(visible) {
      const node = ref?.current ?? fallbackRef.current;
      if (!node)
        return;
      if (visible) {
        node.querySelectorAll("button,a").forEach((el) => {
          const orig = el.dataset.origTabIndex;
          if (orig)
            el.tabIndex = orig;
          else
            el.removeAttribute("tabIndex");
        });
      } else {
        node.querySelectorAll("button,a").forEach((el) => {
          const orig = el.getAttribute("tabIndex");
          if (orig)
            el.dataset.origTabIndex = orig;
          el.tabIndex = -1;
        });
      }
      node.setAttribute("aria-hidden", !visible);
    }
    manageVisibility(isVisible);
    return isVisible.on("change", (visible) => {
      manageVisibility(visible);
    });
  }, [isInitialized]);
  const visibility = isCanvas ? "visible" : useTransform2(wrappedXOrY, [scrollRange[0] - size.viewportLength * rtlDirectionModifier, mix(scrollRange[1], scrollRange[2], 0.5), scrollRange[3] + size.viewportLength * rtlDirectionModifier], ["hidden", "visible", "hidden"]);
  const key = slideKey + "child";
  return /* @__PURE__ */ _jsx2(LayoutGroup2, { inherit: "id", id: key, children: /* @__PURE__ */ _jsx2("li", { style: { display: "contents" }, children: /* @__PURE__ */ cloneElement2(child, { ref: ref ?? fallbackRef, key, style: { ...child.props?.style, flexShrink: 0, userSelect: "none", width, height, ...isInitialized ? { opacity, scale, originX: isHorizontal ? originXorY : 0.5, originY: !isHorizontal ? originXorY : 0.5, rotateY: isHorizontal ? rotateY : 0, rotateX: !isHorizontal ? rotateX : 0, visibility } : {} }, layoutId: child.props.layoutId ? child.props.layoutId + "-original-" + index : void 0 }) }) });
}));
var Dot = /* @__PURE__ */ memo(function Dot2({ selectedOpacity, opacity, total, index, wrappedIndex, dotStyle: dotStyle2, buttonStyle, gap, padding, isHorizontal, ...props }) {
  const isSelected = wrappedIndex === index;
  const inlinePadding = gap / 2;
  const top = !isHorizontal && index !== 0 ? inlinePadding : padding;
  const bottom = !isHorizontal && index !== total - 1 ? inlinePadding : padding;
  const inlineStart = isHorizontal ? index === 0 ? padding : inlinePadding : padding;
  const inlineEnd = isHorizontal ? index === total - 1 ? padding : inlinePadding : padding;
  return /* @__PURE__ */ _jsx2("button", { "aria-label": `Scroll to page ${index + 1}`, type: "button", ...props, style: { ...buttonStyle, paddingTop: top, paddingBottom: bottom, paddingInlineStart: inlineStart, paddingInlineEnd: inlineEnd }, children: /* @__PURE__ */ _jsx2(motion2.div, { style: { ...dotStyle2 }, initial: false, animate: { opacity: isSelected ? selectedOpacity : opacity }, transition: { duration: 0.3 } }) });
});
var dotsContainerStyle = { display: "flex", placeContent: "center", placeItems: "center", overflow: "hidden", position: "absolute", pointerEvents: "auto" };
var dotStyle = { borderRadius: "50%", background: "white", cursor: "pointer", border: "none", placeContent: "center", placeItems: "center", padding: 0 };
function getWritingDirection() {
  return __dai_window?.document?.documentElement?.dir === "rtl" ? "rtl" : "ltr";
}
function useWritingDirection2() {
  const [writingDirection, setWritingDirection] = useState2(null);
  useEffect2(() => {
    setWritingDirection(getWritingDirection());
    return onWritingDirectionChange(() => {
      setWritingDirection(getWritingDirection());
    });
  }, []);
  return writingDirection;
}
var observer = null;
var callbacks = [];
function onWritingDirectionChange(callback) {
  callbacks.push(callback);
  if (!observer) {
    observer = new MutationObserver(() => callbacks.forEach((callback2) => callback2()));
    observer.observe(document.documentElement, { attributeFilter: ["dir"] });
  }
  return () => {
    callbacks.splice(callbacks.indexOf(callback), 1);
    if (callbacks.length === 0) {
      observer?.disconnect();
      observer = null;
    }
  };
}

// http-url:https://framerusercontent.com/modules/k6JJwIpfKgqp0NlN8HMy/7LzvPcg02zjTnJVOgvWR/N49YAfiyO.js
import { jsx as _jsx4, jsxs as _jsxs4 } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls4, ComponentViewportProvider, ControlType as ControlType4, cx as cx2, getFonts, getFontsFromSharedStyle, getLoadingLazyAtYPosition, Image, RichText, SmartComponentScopedContainer, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS3 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup4, motion as motion4, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React2 from "react";
import { useRef as useRef5 } from "react";

// http-url:https://framerusercontent.com/modules/qjwWyZAhQ2DdHfZKkq1t/LkUA5NmWbauWe1EWiyh8/kTR3NcFcQ.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["FS;Manrope-regular", "FS;Manrope-bold"]);
var fonts = [{ explicitInter: true, fonts: [{ family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/2TYFCBHUANEXS6QGR5EQDUNAFH6LSWM3/AYNOU3VEA4LRTDNKJQUFNVNUTYSGOUOP/UXO4O7K2G3HI3D2VKD7UXVJVJD26P4BQ.woff2", weight: "400" }, { family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/NGBUP45ES3F7RD5XGKPEDJ6QEPO4TMOK/EXDVWJ2EDDVVV65UENMX33EDDYBX6OF7/6P4FPMFQH7CCC7RZ4UU4NKSGJ2RLF7V5.woff2", weight: "700" }] }];
var css = ['.framer-8WwI9 .framer-styles-preset-a0z0u0:not(.rich-text-wrapper), .framer-8WwI9 .framer-styles-preset-a0z0u0.rich-text-wrapper p { --framer-font-family: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-family-bold: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 18px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.1px; --framer-line-height: 150%; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-30e48027-3b22-4ff1-a546-6bd64e851575, #3d3d47); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className = "framer-8WwI9";

// http-url:https://framerusercontent.com/modules/xEBo97cVWFr8Wsxymm2p/SWvAt8lRgaKxfQAdQFfV/zXonZCMXX.js
import { jsx as _jsx3, jsxs as _jsxs3 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx, SVG, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup3, motion as motion3, MotionConfigContext } from "framer-motion";
import * as React from "react";
var cycleOrder = ["SNeVeFwMn", "C33x8yyS8", "xozFa03Y8", "vYWThECsb", "PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"];
var serializationHash = "framer-VENYI";
var variantClassNames = { C33x8yyS8: "framer-v-1jbghx9", C8f2WOGzl: "framer-v-19hngfh", CYWGIEi_h: "framer-v-y2ozhz", du5n_Rd4l: "framer-v-1et3jj8", PJsBffpXq: "framer-v-qbaxz1", Qizuh7B2i: "framer-v-16s5c90", QPVR2e_fL: "framer-v-12is2hm", SNeVeFwMn: "framer-v-7mdbtb", vtnvZUrR_: "framer-v-1wvfx6t", vYWThECsb: "framer-v-12rha3s", xozFa03Y8: "framer-v-1l85t44" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion3.create(React.Fragment);
var humanReadableVariantMap = { "0 stars": "du5n_Rd4l", "0.5 stars": "C8f2WOGzl", "1 star": "Qizuh7B2i", "1.5 stars": "vtnvZUrR_", "2 stars": "CYWGIEi_h", "2.5 stars": "QPVR2e_fL", "3 stars": "PJsBffpXq", "3.5 stars": "vYWThECsb", "4 stars": "xozFa03Y8", "4.5 stars": "C33x8yyS8", "5 stars": "SNeVeFwMn" };
var getProps = ({ height, id, starColor, width, ...props }) => {
  return { ...props, NrYSLS2cT: starColor ?? props.NrYSLS2cT ?? "var(--token-0c2325eb-32e6-4468-b86d-b2000f27f938, rgb(255, 255, 255))", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "SNeVeFwMn" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { activeLocale, setLocale } = useLocaleInfo();
  const { style, className: className2, layoutId, variant, NrYSLS2cT, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "SNeVeFwMn", variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  const ref1 = React.useRef(null);
  const isDisplayed = () => {
    if (["C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed1 = () => {
    if (["vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed2 = () => {
    if (["QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed3 = () => {
    if (["vYWThECsb", "PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed4 = () => {
    if (["C33x8yyS8", "xozFa03Y8", "vYWThECsb", "PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed5 = () => {
    if (["C33x8yyS8", "vYWThECsb", "QPVR2e_fL", "vtnvZUrR_", "C8f2WOGzl"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed6 = () => {
    if (["xozFa03Y8", "vYWThECsb", "PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed7 = () => {
    if (baseVariant === "du5n_Rd4l")
      return true;
    return false;
  };
  const isDisplayed8 = () => {
    if (["Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed9 = () => {
    if (["CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed10 = () => {
    if (["PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return true;
    return false;
  };
  const defaultLayoutId = React.useId();
  const componentViewport = useComponentViewport();
  return /* @__PURE__ */ _jsx3(LayoutGroup3, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs3(motion3.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-7mdbtb", className2, classNames), "data-framer-name": "5 stars", layoutDependency, layoutId: "Testimonials__SNeVeFwMn", ref: ref ?? ref1, style: { ...style }, ...addPropertyOverrides({ C33x8yyS8: { "data-framer-name": "4.5 stars" }, C8f2WOGzl: { "data-framer-name": "0.5 stars" }, CYWGIEi_h: { "data-framer-name": "2 stars" }, du5n_Rd4l: { "data-framer-name": "0 stars" }, PJsBffpXq: { "data-framer-name": "3 stars" }, Qizuh7B2i: { "data-framer-name": "1 star" }, QPVR2e_fL: { "data-framer-name": "2.5 stars" }, vtnvZUrR_: { "data-framer-name": "1.5 stars" }, vYWThECsb: { "data-framer-name": "3.5 stars" }, xozFa03Y8: { "data-framer-name": "4 stars" } }, baseVariant, gestureVariant), children: [isDisplayed() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-1g59teg", "data-framer-name": "Star", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__q5oNOyXse", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m5.825 21 1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed1() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-1auge5l", "data-framer-name": "Star", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__rsE5w4CZj", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m5.825 21 1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed2() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-1tq1rwa", "data-framer-name": "Star", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__hvZYj7yBq", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m5.825 21 1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed3() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-1jpi7l6", "data-framer-name": "Star", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__Zxtyx5aF1", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m5.825 21 1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed4() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-1ptboap", "data-framer-name": "Star", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__unuUehAtf", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m5.825 21 1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed5() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-1b7ffol", "data-framer-name": "Star-half", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__lTxZRRdN2", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m15.15 16.85-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4v7.8zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed6() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-1dyx8os", "data-framer-name": "Star-outline", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__hODUYUJFG", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.85 16.825 3.15-1.9 3.15 1.925-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4-1.45 3.375-3.65.325 2.775 2.425zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275zM12 12.25"/></svg>', withExternalLayout: true }), isDisplayed7() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-87sana", "data-framer-name": "Star-outline", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__DpG33iSNb", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.85 16.825 3.15-1.9 3.15 1.925-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4-1.45 3.375-3.65.325 2.775 2.425zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275zM12 12.25"/></svg>', withExternalLayout: true }), isDisplayed8() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-1rau8d1", "data-framer-name": "Star-outline", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__fifMOufgg", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.85 16.825 3.15-1.9 3.15 1.925-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4-1.45 3.375-3.65.325 2.775 2.425zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275zM12 12.25"/></svg>', withExternalLayout: true }), isDisplayed9() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-1tfpoyz", "data-framer-name": "Star-outline", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__GvwW5ZD76", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.85 16.825 3.15-1.9 3.15 1.925-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4-1.45 3.375-3.65.325 2.775 2.425zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275zM12 12.25"/></svg>', withExternalLayout: true }), isDisplayed10() && /* @__PURE__ */ _jsx3(SVG, { className: "framer-7d04ze", "data-framer-name": "Star-outline", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "Testimonials__GVXWG_zfJ", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.85 16.825 3.15-1.9 3.15 1.925-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4-1.45 3.375-3.65.325 2.775 2.425zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275zM12 12.25"/></svg>', withExternalLayout: true })] }) }) }) });
});
var css2 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-VENYI.framer-qslqvu, .framer-VENYI .framer-qslqvu { display: block; }", ".framer-VENYI.framer-7mdbtb { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 4px; height: min-content; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: min-content; }", ".framer-VENYI .framer-1g59teg, .framer-VENYI .framer-1auge5l, .framer-VENYI .framer-1tq1rwa, .framer-VENYI .framer-1jpi7l6, .framer-VENYI .framer-1ptboap, .framer-VENYI .framer-87sana, .framer-VENYI .framer-1rau8d1, .framer-VENYI .framer-1tfpoyz, .framer-VENYI .framer-7d04ze { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 20px); position: relative; width: 20px; }", ".framer-VENYI .framer-1b7ffol, .framer-VENYI .framer-1dyx8os { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 24px); position: relative; width: 20px; }", "@supports (background: -webkit-named-image(i)) and (not (font-palette:dark)) { .framer-VENYI.framer-7mdbtb { gap: 0px; } .framer-VENYI.framer-7mdbtb > * { margin: 0px; margin-left: calc(4px / 2); margin-right: calc(4px / 2); } .framer-VENYI.framer-7mdbtb > :first-child { margin-left: 0px; } .framer-VENYI.framer-7mdbtb > :last-child { margin-right: 0px; } }", ".framer-VENYI.framer-v-1jbghx9 .framer-1b7ffol, .framer-VENYI.framer-v-1l85t44 .framer-1dyx8os, .framer-VENYI.framer-v-12rha3s .framer-1b7ffol, .framer-VENYI.framer-v-12rha3s .framer-1dyx8os, .framer-VENYI.framer-v-qbaxz1 .framer-1dyx8os, .framer-VENYI.framer-v-12is2hm .framer-1b7ffol, .framer-VENYI.framer-v-12is2hm .framer-1dyx8os, .framer-VENYI.framer-v-y2ozhz .framer-1dyx8os, .framer-VENYI.framer-v-1wvfx6t .framer-1b7ffol, .framer-VENYI.framer-v-1wvfx6t .framer-1dyx8os, .framer-VENYI.framer-v-16s5c90 .framer-1dyx8os, .framer-VENYI.framer-v-19hngfh .framer-1b7ffol, .framer-VENYI.framer-v-19hngfh .framer-1dyx8os, .framer-VENYI.framer-v-1et3jj8 .framer-1dyx8os { height: var(--framer-aspect-ratio-supported, 20px); }"];
var FramerzXonZCMXX = withCSS2(Component2, css2, "framer-VENYI");
var zXonZCMXX_default = FramerzXonZCMXX;
FramerzXonZCMXX.displayName = "Star Rating";
FramerzXonZCMXX.defaultProps = { height: 20, width: 116 };
addPropertyControls3(FramerzXonZCMXX, { variant: { options: ["SNeVeFwMn", "C33x8yyS8", "xozFa03Y8", "vYWThECsb", "PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"], optionTitles: ["5 stars", "4.5 stars", "4 stars", "3.5 stars", "3 stars", "2.5 stars", "2 stars", "1.5 stars", "1 star", "0.5 stars", "0 stars"], title: "Variant", type: ControlType3.Enum }, NrYSLS2cT: { defaultValue: 'var(--token-0c2325eb-32e6-4468-b86d-b2000f27f938, rgb(255, 255, 255)) /* {"name":"White"} */', title: "Star color", type: ControlType3.Color } });
addFonts(FramerzXonZCMXX, [{ explicitInter: true, fonts: [] }], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/k6JJwIpfKgqp0NlN8HMy/7LzvPcg02zjTnJVOgvWR/N49YAfiyO.js
var StarRatingFonts = getFonts(zXonZCMXX_default);
var cycleOrder2 = ["r8ZzAWHL8", "ICMB543r_"];
var serializationHash2 = "framer-U25Nt";
var variantClassNames2 = { ICMB543r_: "framer-v-19lz2up", r8ZzAWHL8: "framer-v-1tc2eie" };
function addPropertyOverrides2(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition12 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var Transition2 = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext2.Provider, { value: contextValue, children });
};
var Variants2 = motion4.create(React2.Fragment);
var humanReadableVariantMap2 = { Light: "r8ZzAWHL8", Mid: "ICMB543r_" };
var getProps2 = ({ height, id, image, name1, text, width, ...props }) => {
  return { ...props, NQ6B20sX9: name1 ?? props.NQ6B20sX9 ?? "Rachel Smith", t9TK5wU0p: text ?? props.t9TK5wU0p ?? "Plumbing's team is reliable and courteous, resolving our plumbing issues promptly and with meticulous attention to detail.", variant: humanReadableVariantMap2[props.variant] ?? props.variant ?? "r8ZzAWHL8", VuQLO25Gf: image ?? props.VuQLO25Gf ?? { alt: "", positionX: "49.1%", positionY: "12.8%", src: "https://framerusercontent.com/images/qSZ1ms3EA4kPmxSpRlAlNSLLCQ.png?scale-down-to=512", srcSet: "https://framerusercontent.com/images/qSZ1ms3EA4kPmxSpRlAlNSLLCQ.png?scale-down-to=1024 771w,https://framerusercontent.com/images/qSZ1ms3EA4kPmxSpRlAlNSLLCQ.png?scale-down-to=2048 1542w,https://framerusercontent.com/images/qSZ1ms3EA4kPmxSpRlAlNSLLCQ.png 1856w" } };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef5(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className: className2, layoutId, variant, t9TK5wU0p, NQ6B20sX9, VuQLO25Gf, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder: cycleOrder2, defaultVariant: "r8ZzAWHL8", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const sharedStyleClassNames = [className];
  const scopingClassNames = cx2(serializationHash2, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx4(LayoutGroup4, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition2, { value: transition12, children: /* @__PURE__ */ _jsxs4(motion4.div, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-1tc2eie", className2, classNames), "data-border": true, "data-framer-name": "Light", layoutDependency, layoutId: "Testimonials__r8ZzAWHL8", ref: refBinding, style: { "--border-bottom-width": "1px", "--border-color": "var(--token-138c6083-e907-40e8-909c-96eb16f3a3a3, rgb(230, 230, 230))", "--border-left-width": "1px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "1px", backgroundColor: "var(--token-de8da503-8d4d-4351-82a9-63caea8f9e9c, rgb(250, 250, 250))", borderBottomLeftRadius: 10, borderBottomRightRadius: 10, borderTopLeftRadius: 10, borderTopRightRadius: 10, ...style }, variants: { ICMB543r_: { backgroundColor: "var(--token-45695a13-9dfd-47b5-ba76-74af44701abb, rgb(233, 236, 242))" } }, ...addPropertyOverrides2({ ICMB543r_: { "data-framer-name": "Mid" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs4(motion4.div, { className: "framer-1oc4rva", "data-framer-name": "Review", layoutDependency, layoutId: "Testimonials__yfFxOvK4t", children: [/* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 20, y: (componentViewport?.y || 0) + 30 + (0 + 0 + ((componentViewport?.height || 258) - 60 - 320) / 2 * 0) + 0 + 0, children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1atcyno-container", layoutDependency, layoutId: "Testimonials__h6Gpk4OCt-container", nodeId: "h6Gpk4OCt", rendersWithMotion: true, scopeId: "N49YAfiyO", children: /* @__PURE__ */ _jsx4(zXonZCMXX_default, { height: "100%", id: "h6Gpk4OCt", layoutId: "Testimonials__h6Gpk4OCt", NrYSLS2cT: "var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, rgb(16, 16, 20))", variant: "SNeVeFwMn", width: "100%" }) }) }), /* @__PURE__ */ _jsx4(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React2.Fragment, { children: /* @__PURE__ */ _jsx4(motion4.p, { className: "framer-styles-preset-a0z0u0", "data-styles-preset": "kTR3NcFcQ", children: "Plumbing's team is reliable and courteous, resolving our plumbing issues promptly and with meticulous attention to detail." }) }), className: "framer-1yficqt", fonts: ["Inter"], layoutDependency, layoutId: "Testimonials__Q9VNc8ovY", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: t9TK5wU0p, verticalAlignment: "top", withExternalLayout: true })] }), /* @__PURE__ */ _jsx4(motion4.div, { className: "framer-yzefk9", "data-framer-name": "Spacer", layoutDependency, layoutId: "Testimonials__LcxI0Bn3s" }), /* @__PURE__ */ _jsxs4(motion4.div, { className: "framer-5hmvc7", "data-framer-name": "Citation", layoutDependency, layoutId: "Testimonials__uFct_nHmr", children: [/* @__PURE__ */ _jsx4(Image, { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 30 + (0 + 185 + ((componentViewport?.height || 258) - 60 - 320) / 2 * 2) + 47.5), pixelHeight: 2464, pixelWidth: 1856, sizes: "40px", ...toResponsiveImage(VuQLO25Gf) }, className: "framer-3nspsd", "data-border": true, layoutDependency, layoutId: "Testimonials__jPsqyTFiu", style: { "--border-bottom-width": "1px", "--border-color": "var(--token-ac728068-b0a8-49a3-8b2a-7c06001e6872, rgb(219, 218, 217))", "--border-left-width": "1px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "1px", borderBottomLeftRadius: 1e3, borderBottomRightRadius: 1e3, borderTopLeftRadius: 1e3, borderTopRightRadius: 1e3 } }), /* @__PURE__ */ _jsx4(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React2.Fragment, { children: /* @__PURE__ */ _jsx4(motion4.p, { className: "framer-styles-preset-a0z0u0", "data-styles-preset": "kTR3NcFcQ", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, rgb(16, 16, 20)))" }, children: "Rachel Smith" }) }), className: "framer-ddkqlv", fonts: ["Inter"], layoutDependency, layoutId: "Testimonials__BjtsZq9l8", style: { "--extracted-r6o4lv": "var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, rgb(16, 16, 20))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: NQ6B20sX9, verticalAlignment: "top", withExternalLayout: true })] })] }) }) }) });
});
var css3 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-U25Nt.framer-naov20, .framer-U25Nt .framer-naov20 { display: block; }", ".framer-U25Nt.framer-1tc2eie { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; height: min-content; justify-content: space-between; overflow: hidden; padding: 30px 40px 30px 40px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-U25Nt .framer-1oc4rva { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-U25Nt .framer-1atcyno-container { flex: none; height: auto; position: relative; width: auto; }", ".framer-U25Nt .framer-1yficqt { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-U25Nt .framer-yzefk9 { flex: none; height: 20px; overflow: visible; position: relative; width: 100%; }", ".framer-U25Nt .framer-5hmvc7 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: flex-start; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-U25Nt .framer-3nspsd { flex: none; height: 40px; overflow: hidden; position: relative; width: 40px; will-change: var(--framer-will-change-override, transform); }", ".framer-U25Nt .framer-ddkqlv { flex: 1 0 0px; height: auto; position: relative; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; }", "@supports (background: -webkit-named-image(i)) and (not (font-palette:dark)) { .framer-U25Nt .framer-1oc4rva, .framer-U25Nt .framer-5hmvc7 { gap: 0px; } .framer-U25Nt .framer-1oc4rva > * { margin: 0px; margin-bottom: calc(10px / 2); margin-top: calc(10px / 2); } .framer-U25Nt .framer-1oc4rva > :first-child { margin-top: 0px; } .framer-U25Nt .framer-1oc4rva > :last-child { margin-bottom: 0px; } .framer-U25Nt .framer-5hmvc7 > * { margin: 0px; margin-left: calc(10px / 2); margin-right: calc(10px / 2); } .framer-U25Nt .framer-5hmvc7 > :first-child { margin-left: 0px; } .framer-U25Nt .framer-5hmvc7 > :last-child { margin-right: 0px; } }", ...css, '.framer-U25Nt[data-border="true"]::after, .framer-U25Nt [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; pointer-events: none; }'];
var FramerN49YAfiyO = withCSS3(Component3, css3, "framer-U25Nt");
var N49YAfiyO_default = FramerN49YAfiyO;
FramerN49YAfiyO.displayName = "Review Card";
FramerN49YAfiyO.defaultProps = { height: 258, width: 400 };
addPropertyControls4(FramerN49YAfiyO, { variant: { options: ["r8ZzAWHL8", "ICMB543r_"], optionTitles: ["Light", "Mid"], title: "Variant", type: ControlType4.Enum }, t9TK5wU0p: { defaultValue: "Plumbing's team is reliable and courteous, resolving our plumbing issues promptly and with meticulous attention to detail.", displayTextArea: true, title: "Text", type: ControlType4.String }, NQ6B20sX9: { defaultValue: "Rachel Smith", displayTextArea: false, title: "Name", type: ControlType4.String }, VuQLO25Gf: { __defaultAssetReference: "data:framer/asset-reference,qSZ1ms3EA4kPmxSpRlAlNSLLCQ.png?originalFilename=QmVXbSwfKo6TgYsbpBxEj9RKe8MYobnEYgMqTmQ7TQLECV.png&preferredSize=auto", __vekterDefault: { alt: "", assetReference: "data:framer/asset-reference,qSZ1ms3EA4kPmxSpRlAlNSLLCQ.png?originalFilename=QmVXbSwfKo6TgYsbpBxEj9RKe8MYobnEYgMqTmQ7TQLECV.png&preferredSize=auto", positionX: "49.1%", positionY: "12.8%" }, title: "Image", type: ControlType4.ResponsiveImage } });
addFonts2(FramerN49YAfiyO, [{ explicitInter: true, fonts: [{ family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/vQyevYAyHtARFwPqUzQGpnDs.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...StarRatingFonts, ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/EpDb0lbn1KEivjiYgBGv/ox6OKCjDzJQysUEKbJk7/lcMJgSJHP.js
var ReviewCardFonts = getFonts2(N49YAfiyO_default);
var TickerFonts = getFonts2(Ticker);
var SlideshowFonts = getFonts2(SlideShow_default);
var cycleOrder3 = ["aUm3TPLRG", "wNaqfP3tz"];
var serializationHash3 = "framer-ncJPH";
var variantClassNames3 = { aUm3TPLRG: "framer-v-ke739s", wNaqfP3tz: "framer-v-stgqdo" };
function addPropertyOverrides3(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition13 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var addImageAlt = (image, alt) => {
  if (!image || typeof image !== "object") {
    return;
  }
  return { ...image, alt };
};
var matchVariant = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var Transition3 = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext3);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx5(MotionConfigContext3.Provider, { value: contextValue, children });
};
var humanReadableVariantMap3 = { Desktop: "aUm3TPLRG", Mobile: "wNaqfP3tz" };
var Variants3 = motion5.create(React3.Fragment);
var getProps3 = ({ height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap3[props.variant] ?? props.variant ?? "aUm3TPLRG" };
};
var createLayoutDependency3 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component4 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef6(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo3();
  const componentViewport = useComponentViewport3();
  const { style, className: className2, layoutId, variant, ...restProps } = getProps3(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState3({ cycleOrder: cycleOrder3, defaultVariant: "aUm3TPLRG", ref: refBinding, variant, variantClassNames: variantClassNames3 });
  const layoutDependency = createLayoutDependency3(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx3(serializationHash3, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "wNaqfP3tz")
      return false;
    return true;
  };
  const isDisplayed1 = () => {
    if (baseVariant === "wNaqfP3tz")
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx5(LayoutGroup5, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx5(Variants3, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx5(Transition3, { value: transition13, children: /* @__PURE__ */ _jsxs5(motion5.div, { ...restProps, ...gestureHandlers, className: cx3(scopingClassNames, "framer-ke739s", className2, classNames), "data-framer-name": "Desktop", layoutDependency, layoutId: "Testimonials__aUm3TPLRG", ref: refBinding, style: { ...style }, ...addPropertyOverrides3({ wNaqfP3tz: { "data-framer-name": "Mobile" } }, baseVariant, gestureVariant), children: [isDisplayed() && /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-ian7to-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "Testimonials__IxdLk9_hc-container", nodeId: "IxdLk9_hc", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(Ticker, { alignment: "center", direction: "left", fadeOptions: { fadeAlpha: 0, fadeContent: false, fadeInset: 0, fadeWidth: 25, overflow: true }, gap: 32, height: "100%", hoverFactor: 0.5, id: "IxdLk9_hc", layoutId: "Testimonials__IxdLk9_hc", padding: 0, paddingBottom: 0, paddingLeft: 0, paddingPerSide: false, paddingRight: 0, paddingTop: 0, sizingOptions: { heightType: false, widthType: true }, slots: [/* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-rsq4ye-container", "data-framer-name": "Review 1", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__FNIa6q3WO-container", name: "Review 1", nodeId: "FNIa6q3WO", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "FNIa6q3WO", layoutId: "Testimonials__FNIa6q3WO", name: "Review 1", NQ6B20sX9: "Emily Carter", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Refit did an incredible job on our kitchen. The craftsmanship was top-notch, and the team was professional from start to finish. Highly recommend!", variant: matchVariant("r8ZzAWHL8"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 904, positionX: "46.9%", positionY: "15.6%", src: "https://framerusercontent.com/images/7fL4QJDsuimM3GmAxnTxB58Lrw.jpg?width=904&height=1200", srcSet: "https://framerusercontent.com/images/7fL4QJDsuimM3GmAxnTxB58Lrw.jpg?scale-down-to=1024&width=904&height=1200 771w,https://framerusercontent.com/images/7fL4QJDsuimM3GmAxnTxB58Lrw.jpg?width=904&height=1200 904w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-yuvvbw-container", "data-framer-name": "Review 2", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__eA78PuzzX-container", name: "Review 2", nodeId: "eA78PuzzX", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "eA78PuzzX", layoutId: "Testimonials__eA78PuzzX", name: "Review 2", NQ6B20sX9: "James Richardson", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Brilliant service from start to finish. The team was professional, communicative, and the results exceeded my expectations. My new bathroom looks amazing!", variant: matchVariant("ICMB543r_"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 673, src: "https://framerusercontent.com/images/AqDU62U0ILWH6uLvadot2OfuggA.jpg?width=673&height=1200", srcSet: "https://framerusercontent.com/images/AqDU62U0ILWH6uLvadot2OfuggA.jpg?scale-down-to=1024&width=673&height=1200 574w,https://framerusercontent.com/images/AqDU62U0ILWH6uLvadot2OfuggA.jpg?width=673&height=1200 673w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-1ci9s35-container", "data-framer-name": "Review 3", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__lfFOwY6zi-container", name: "Review 3", nodeId: "lfFOwY6zi", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "lfFOwY6zi", layoutId: "Testimonials__lfFOwY6zi", name: "Review 3", NQ6B20sX9: "Sophie Williams", style: { height: "100%", width: "100%" }, t9TK5wU0p: "I couldn\u2019t be happier with my loft conversion. The attention to detail and quality of work were outstanding. Refit made the whole process smooth and stress-free!", variant: matchVariant("r8ZzAWHL8"), VuQLO25Gf: addImageAlt({ pixelHeight: 992, pixelWidth: 1200, src: "https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?width=1200&height=992", srcSet: "https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?scale-down-to=512&width=1200&height=992 512w,https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?scale-down-to=1024&width=1200&height=992 1024w,https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?width=1200&height=992 1200w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-1ru9jp-container", "data-framer-name": "Review 4", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__KnXDQvRl1-container", name: "Review 4", nodeId: "KnXDQvRl1", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "KnXDQvRl1", layoutId: "Testimonials__KnXDQvRl1", name: "Review 4", NQ6B20sX9: "Daniel Foster", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Refit transformed our outdoor space with a beautiful garden path. The work was completed on time, and the finish is excellent. A great team to work with!", variant: matchVariant("ICMB543r_"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?width=1200&height=1200 1200w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-67hml5-container", "data-framer-name": "Review 5", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__CrJ_f4Efz-container", name: "Review 5", nodeId: "CrJ_f4Efz", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "CrJ_f4Efz", layoutId: "Testimonials__CrJ_f4Efz", name: "Review 5", NQ6B20sX9: "Charlotte Harris", style: { height: "100%", width: "100%" }, t9TK5wU0p: "From the first consultation to the final touches, Refit delivered on every promise. Our home extension is exactly what we wanted\u2014spacious, modern, and beautifully finished!", variant: matchVariant("r8ZzAWHL8"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?width=1200&height=1200 1200w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-fonqa0-container", "data-framer-name": "Review 6", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__Lno4zCETJ-container", name: "Review 6", nodeId: "Lno4zCETJ", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "Lno4zCETJ", layoutId: "Testimonials__Lno4zCETJ", name: "Review 6", NQ6B20sX9: "Oliver Bennett", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Fantastic workmanship! The team renovated our bathroom with precision and care. It now feels like a luxury space. Would definitely use Refit again.", variant: matchVariant("ICMB543r_"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?width=1200&height=1200 1200w" }, ""), width: "100%" }) }) })], speed: 35, style: { height: "100%", width: "100%" }, width: "100%" }) }) }), isDisplayed() && /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-800ie3-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "Testimonials__XJ5id7sBy-container", nodeId: "XJ5id7sBy", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(Ticker, { alignment: "center", direction: "right", fadeOptions: { fadeAlpha: 0, fadeContent: false, fadeInset: 0, fadeWidth: 25, overflow: true }, gap: 32, height: "100%", hoverFactor: 0.5, id: "XJ5id7sBy", layoutId: "Testimonials__XJ5id7sBy", padding: 0, paddingBottom: 0, paddingLeft: 0, paddingPerSide: false, paddingRight: 0, paddingTop: 0, sizingOptions: { heightType: false, widthType: true }, slots: [/* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-fonqa0-container", "data-framer-name": "Review 6", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__Lno4zCETJ-container", name: "Review 6", nodeId: "Lno4zCETJ", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "Lno4zCETJ", layoutId: "Testimonials__Lno4zCETJ", name: "Review 6", NQ6B20sX9: "Oliver Bennett", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Fantastic workmanship! The team renovated our bathroom with precision and care. It now feels like a luxury space. Would definitely use Refit again.", variant: matchVariant("ICMB543r_"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?width=1200&height=1200 1200w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-67hml5-container", "data-framer-name": "Review 5", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__CrJ_f4Efz-container", name: "Review 5", nodeId: "CrJ_f4Efz", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "CrJ_f4Efz", layoutId: "Testimonials__CrJ_f4Efz", name: "Review 5", NQ6B20sX9: "Charlotte Harris", style: { height: "100%", width: "100%" }, t9TK5wU0p: "From the first consultation to the final touches, Refit delivered on every promise. Our home extension is exactly what we wanted\u2014spacious, modern, and beautifully finished!", variant: matchVariant("r8ZzAWHL8"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?width=1200&height=1200 1200w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-1ru9jp-container", "data-framer-name": "Review 4", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__KnXDQvRl1-container", name: "Review 4", nodeId: "KnXDQvRl1", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "KnXDQvRl1", layoutId: "Testimonials__KnXDQvRl1", name: "Review 4", NQ6B20sX9: "Daniel Foster", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Refit transformed our outdoor space with a beautiful garden path. The work was completed on time, and the finish is excellent. A great team to work with!", variant: matchVariant("ICMB543r_"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?width=1200&height=1200 1200w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-1ci9s35-container", "data-framer-name": "Review 3", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__lfFOwY6zi-container", name: "Review 3", nodeId: "lfFOwY6zi", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "lfFOwY6zi", layoutId: "Testimonials__lfFOwY6zi", name: "Review 3", NQ6B20sX9: "Sophie Williams", style: { height: "100%", width: "100%" }, t9TK5wU0p: "I couldn\u2019t be happier with my loft conversion. The attention to detail and quality of work were outstanding. Refit made the whole process smooth and stress-free!", variant: matchVariant("r8ZzAWHL8"), VuQLO25Gf: addImageAlt({ pixelHeight: 992, pixelWidth: 1200, src: "https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?width=1200&height=992", srcSet: "https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?scale-down-to=512&width=1200&height=992 512w,https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?scale-down-to=1024&width=1200&height=992 1024w,https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?width=1200&height=992 1200w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-yuvvbw-container", "data-framer-name": "Review 2", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__eA78PuzzX-container", name: "Review 2", nodeId: "eA78PuzzX", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "eA78PuzzX", layoutId: "Testimonials__eA78PuzzX", name: "Review 2", NQ6B20sX9: "James Richardson", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Brilliant service from start to finish. The team was professional, communicative, and the results exceeded my expectations. My new bathroom looks amazing!", variant: matchVariant("ICMB543r_"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 673, src: "https://framerusercontent.com/images/AqDU62U0ILWH6uLvadot2OfuggA.jpg?width=673&height=1200", srcSet: "https://framerusercontent.com/images/AqDU62U0ILWH6uLvadot2OfuggA.jpg?scale-down-to=1024&width=673&height=1200 574w,https://framerusercontent.com/images/AqDU62U0ILWH6uLvadot2OfuggA.jpg?width=673&height=1200 673w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-rsq4ye-container", "data-framer-name": "Review 1", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__FNIa6q3WO-container", name: "Review 1", nodeId: "FNIa6q3WO", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "FNIa6q3WO", layoutId: "Testimonials__FNIa6q3WO", name: "Review 1", NQ6B20sX9: "Emily Carter", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Refit did an incredible job on our kitchen. The craftsmanship was top-notch, and the team was professional from start to finish. Highly recommend!", variant: matchVariant("r8ZzAWHL8"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 904, positionX: "46.9%", positionY: "15.6%", src: "https://framerusercontent.com/images/7fL4QJDsuimM3GmAxnTxB58Lrw.jpg?width=904&height=1200", srcSet: "https://framerusercontent.com/images/7fL4QJDsuimM3GmAxnTxB58Lrw.jpg?scale-down-to=1024&width=904&height=1200 771w,https://framerusercontent.com/images/7fL4QJDsuimM3GmAxnTxB58Lrw.jpg?width=904&height=1200 904w" }, ""), width: "100%" }) }) })], speed: 35, style: { height: "100%", width: "100%" }, width: "100%" }) }) }), isDisplayed1() && /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-8rjr20-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "Testimonials__usY2ERR9D-container", nodeId: "usY2ERR9D", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(SlideShow_default, { alignment: "flex-start", arrowOptions: { arrowFill: "rgba(0, 0, 0, 0.2)", arrowGap: 10, arrowPadding: -10, arrowPaddingBottom: 0, arrowPaddingLeft: 0, arrowPaddingRight: 0, arrowPaddingTop: 0, arrowPosition: "auto", arrowRadius: 40, arrowShouldFadeIn: false, arrowShouldSpace: true, arrowSize: 40, showMouseControls: false }, autoPlayControl: false, borderRadius: 0, direction: "left", dragControl: true, effectsOptions: { effectsHover: true, effectsOpacity: 1, effectsPerspective: 1200, effectsRotate: 0, effectsScale: 1, playOffscreen: false }, fadeOptions: { fadeAlpha: 0, fadeContent: false, fadeInset: 0, fadeWidth: 25, overflow: false }, gap: 20, height: "100%", id: "usY2ERR9D", intervalControl: 3, itemAmount: 1, layoutId: "Testimonials__usY2ERR9D", padding: 0, paddingBottom: 50, paddingLeft: 0, paddingPerSide: true, paddingRight: 0, paddingTop: 0, progressOptions: { dotsActiveOpacity: 1, dotsBackground: "rgba(0, 0, 0, 0)", dotsBlur: 0, dotsFill: "var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, rgb(16, 16, 20))", dotsGap: 10, dotsInset: 10, dotSize: 10, dotsOpacity: 0.5, dotsPadding: 10, dotsRadius: 50, showProgressDots: true }, slots: [/* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-rsq4ye-container", "data-framer-name": "Review 1", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__FNIa6q3WO-container", name: "Review 1", nodeId: "FNIa6q3WO", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "FNIa6q3WO", layoutId: "Testimonials__FNIa6q3WO", name: "Review 1", NQ6B20sX9: "Emily Carter", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Refit did an incredible job on our kitchen. The craftsmanship was top-notch, and the team was professional from start to finish. Highly recommend!", variant: matchVariant("r8ZzAWHL8"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 904, positionX: "46.9%", positionY: "15.6%", src: "https://framerusercontent.com/images/7fL4QJDsuimM3GmAxnTxB58Lrw.jpg?width=904&height=1200", srcSet: "https://framerusercontent.com/images/7fL4QJDsuimM3GmAxnTxB58Lrw.jpg?scale-down-to=1024&width=904&height=1200 771w,https://framerusercontent.com/images/7fL4QJDsuimM3GmAxnTxB58Lrw.jpg?width=904&height=1200 904w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-yuvvbw-container", "data-framer-name": "Review 2", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__eA78PuzzX-container", name: "Review 2", nodeId: "eA78PuzzX", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "eA78PuzzX", layoutId: "Testimonials__eA78PuzzX", name: "Review 2", NQ6B20sX9: "James Richardson", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Brilliant service from start to finish. The team was professional, communicative, and the results exceeded my expectations. My new bathroom looks amazing!", variant: matchVariant("ICMB543r_"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 673, src: "https://framerusercontent.com/images/AqDU62U0ILWH6uLvadot2OfuggA.jpg?width=673&height=1200", srcSet: "https://framerusercontent.com/images/AqDU62U0ILWH6uLvadot2OfuggA.jpg?scale-down-to=1024&width=673&height=1200 574w,https://framerusercontent.com/images/AqDU62U0ILWH6uLvadot2OfuggA.jpg?width=673&height=1200 673w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-1ci9s35-container", "data-framer-name": "Review 3", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__lfFOwY6zi-container", name: "Review 3", nodeId: "lfFOwY6zi", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "lfFOwY6zi", layoutId: "Testimonials__lfFOwY6zi", name: "Review 3", NQ6B20sX9: "Sophie Williams", style: { height: "100%", width: "100%" }, t9TK5wU0p: "I couldn\u2019t be happier with my loft conversion. The attention to detail and quality of work were outstanding. Refit made the whole process smooth and stress-free!", variant: matchVariant("r8ZzAWHL8"), VuQLO25Gf: addImageAlt({ pixelHeight: 992, pixelWidth: 1200, src: "https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?width=1200&height=992", srcSet: "https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?scale-down-to=512&width=1200&height=992 512w,https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?scale-down-to=1024&width=1200&height=992 1024w,https://framerusercontent.com/images/OuUloSm0m69zkSLax5gEBHqD8Y.png?width=1200&height=992 1200w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-1ru9jp-container", "data-framer-name": "Review 4", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__KnXDQvRl1-container", name: "Review 4", nodeId: "KnXDQvRl1", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "KnXDQvRl1", layoutId: "Testimonials__KnXDQvRl1", name: "Review 4", NQ6B20sX9: "Daniel Foster", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Refit transformed our outdoor space with a beautiful garden path. The work was completed on time, and the finish is excellent. A great team to work with!", variant: matchVariant("ICMB543r_"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/cZ9VBNOcSpg8RiRzIkAXdz6ScF4.png?width=1200&height=1200 1200w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-67hml5-container", "data-framer-name": "Review 5", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__CrJ_f4Efz-container", name: "Review 5", nodeId: "CrJ_f4Efz", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "CrJ_f4Efz", layoutId: "Testimonials__CrJ_f4Efz", name: "Review 5", NQ6B20sX9: "Charlotte Harris", style: { height: "100%", width: "100%" }, t9TK5wU0p: "From the first consultation to the final touches, Refit delivered on every promise. Our home extension is exactly what we wanted\u2014spacious, modern, and beautifully finished!", variant: matchVariant("r8ZzAWHL8"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/rG3mqtO2ErGwJ4dpgrkKuC1iB4.png?width=1200&height=1200 1200w" }, ""), width: "100%" }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 285, width: "400px", children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-fonqa0-container", "data-framer-name": "Review 6", inComponentSlot: true, layoutDependency, layoutId: "Testimonials__Lno4zCETJ-container", name: "Review 6", nodeId: "Lno4zCETJ", rendersWithMotion: true, scopeId: "lcMJgSJHP", children: /* @__PURE__ */ _jsx5(N49YAfiyO_default, { height: "100%", id: "Lno4zCETJ", layoutId: "Testimonials__Lno4zCETJ", name: "Review 6", NQ6B20sX9: "Oliver Bennett", style: { height: "100%", width: "100%" }, t9TK5wU0p: "Fantastic workmanship! The team renovated our bathroom with precision and care. It now feels like a luxury space. Would definitely use Refit again.", variant: matchVariant("ICMB543r_"), VuQLO25Gf: addImageAlt({ pixelHeight: 1200, pixelWidth: 1200, src: "https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?width=1200&height=1200", srcSet: "https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?scale-down-to=512&width=1200&height=1200 512w,https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?scale-down-to=1024&width=1200&height=1200 1024w,https://framerusercontent.com/images/js5oJLlObYjJL8Rfq2iwUlXwYIE.png?width=1200&height=1200 1200w" }, ""), width: "100%" }) }) })], startFrom: 0, style: { height: "100%", width: "100%" }, transitionControl: { damping: 40, delay: 0, mass: 1, stiffness: 200, type: "spring" }, width: "100%" }) }) })] }) }) }) });
});
var css4 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-ncJPH.framer-w0ndts, .framer-ncJPH .framer-w0ndts { display: block; }", ".framer-ncJPH.framer-ke739s { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 32px; height: min-content; justify-content: center; overflow: hidden; padding: 0px 20px 0px 20px; position: relative; width: 100%; }", ".framer-ncJPH .framer-ian7to-container, .framer-ncJPH .framer-800ie3-container { flex: none; height: 300px; position: relative; width: 100%; }", ".framer-ncJPH .framer-rsq4ye-container, .framer-ncJPH .framer-yuvvbw-container, .framer-ncJPH .framer-1ci9s35-container, .framer-ncJPH .framer-1ru9jp-container, .framer-ncJPH .framer-67hml5-container, .framer-ncJPH .framer-fonqa0-container { height: 285px; position: relative; width: 400px; }", ".framer-ncJPH .framer-8rjr20-container { flex: none; height: 399px; position: relative; width: 100%; }", ".framer-ncJPH.framer-v-stgqdo.framer-ke739s { padding: 0px 20px 0px 20px; width: 100%; }"];
var FramerlcMJgSJHP = withCSS4(Component4, css4, "framer-ncJPH");
var lcMJgSJHP_default = FramerlcMJgSJHP;
FramerlcMJgSJHP.displayName = "Testimonials";
FramerlcMJgSJHP.defaultProps = { height: 632, width: 1440 };
addPropertyControls5(FramerlcMJgSJHP, { variant: { options: ["aUm3TPLRG", "wNaqfP3tz"], optionTitles: ["Desktop", "Mobile"], title: "Variant", type: ControlType5.Enum } });
addFonts3(FramerlcMJgSJHP, [{ explicitInter: true, fonts: [] }, ...ReviewCardFonts, ...TickerFonts, ...SlideshowFonts], { supportsExplicitInterCodegen: true });
FramerlcMJgSJHP.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader(N49YAfiyO_default, {}, context)]);
} };
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerlcMJgSJHP", "slots": [], "annotations": { "framerIntrinsicWidth": "1440", "framerImmutableVariables": "true", "framerComponentViewportWidth": "true", "framerDisplayContentsDiv": "false", "framerAutoSizeImages": "true", "framerColorSyntax": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"wNaqfP3tz":{"layout":["fixed","auto"]}}}', "framerIntrinsicHeight": "632", "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  lcMJgSJHP_default as default
};
