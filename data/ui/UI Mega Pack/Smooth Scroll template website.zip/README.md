# Smooth Scroll

Exported from Framer using Design to AI.

## Components

- `SmoothscrollProd`
- `Pulse`
- `Button`
- `Star`
- `Badge`
- `Gallery`
- `Statistic`
- `Statistic2`
- `Statistic3`
- `Statistic4`
- `Badge2`
- `Services`
- `Badge3`
- `CaseStudyCard`
- `CaseStudyCard2`
- `CaseStudyCard3`
- `Badge4`
- `Testimonials`
- `Badge5`
- `Button2`
- `Faqs`
- `Badge6`
- `ContactForm`
- `SmoothscrollProd2`
- `Pulse2`
- `Button3`
- `Star2`
- `Badge7`
- `Gallery2`
- `Statistic5`
- `Statistic6`
- `Statistic7`
- `Statistic8`
- `Badge8`
- `Services2`
- `Badge9`
- `CaseStudyCard4`
- `CaseStudyCard5`
- `CaseStudyCard6`
- `Badge10`
- `Testimonials2`
- `Badge11`
- `Button4`
- `Faqs2`
- `Badge12`
- `ContactForm2`
- `SmoothscrollProd3`
- `Pulse3`
- `Button5`
- `Star3`
- `Badge13`
- `Gallery3`
- `Statistic9`
- `Statistic10`
- `Statistic11`
- `Statistic12`
- `Badge14`
- `Services3`
- `Badge15`
- `CaseStudyCard7`
- `CaseStudyCard8`
- `CaseStudyCard9`
- `Badge16`
- `Testimonials3`
- `Badge17`
- `Button6`
- `Faqs3`
- `Badge18`
- `ContactForm3`
- `SmoothscrollProd4`
- `Pulse4`
- `Button7`
- `Star4`
- `Badge19`
- `Gallery4`
- `Statistic13`
- `Statistic14`
- `Statistic15`
- `Statistic16`
- `Badge20`
- `Services4`
- `Badge21`
- `CaseStudyCard10`
- `CaseStudyCard11`
- `CaseStudyCard12`
- `Badge22`
- `Testimonials4`
- `Badge23`
- `Button8`
- `Faqs4`
- `Badge24`
- `ContactForm4`
- `SmoothscrollProd5`
- `Pulse5`
- `Button9`
- `Star5`
- `Badge25`
- `Gallery5`
- `Statistic17`
- `Statistic18`
- `Statistic19`
- `Statistic20`
- `Badge26`
- `Services5`
- `Badge27`
- `CaseStudyCard13`
- `CaseStudyCard14`
- `CaseStudyCard15`
- `Badge28`
- `Testimonials5`
- `Badge29`
- `Button10`
- `Faqs5`
- `Badge30`
- `ContactForm5`
- `SmoothscrollProd6`
- `Pulse6`
- `Button11`
- `Star6`
- `Badge31`
- `Gallery6`
- `Statistic21`
- `Statistic22`
- `Statistic23`
- `Statistic24`
- `Badge32`
- `Services6`
- `Badge33`
- `CaseStudyCard16`
- `CaseStudyCard17`
- `CaseStudyCard18`
- `Badge34`
- `Testimonials6`
- `Badge35`
- `Button12`
- `Faqs6`
- `Badge36`
- `ContactForm6`

## Installation

```bash
# Copy this folder to your project, then install dependencies:
npm install react react-dom framer-motion lenis@1.1.2 @motionone/dom@10.13.1
```

## Usage

```tsx
import { SmoothscrollProd } from './Smooth Scroll';

function App() {
  return <SmoothscrollProd />;
}
```

## Responsive Components

For components with responsive variants, use the responsive runtime:

```tsx
// Import the CSS for responsive breakpoints
import './Smooth Scroll/_responsive-runtime.css';

// Option 1: Use the useBreakpoint hook
import { useBreakpoint } from './Smooth Scroll/_responsive-runtime';

function App() {
  const breakpoint = useBreakpoint(); // 'base' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

  return <SmoothscrollProd variant={breakpoint === 'base' ? 'mobile' : 'desktop'} />;
}

// Option 2: Use the WithBreakpoints HOC
import { WithBreakpoints } from './Smooth Scroll/_responsive-runtime';

function App() {
  return (
    <WithBreakpoints
      Component={SmoothscrollProd}
      variants={{
        base: 'mobile',    // 0px+
        md: 'tablet',      // 768px+
        lg: 'desktop'      // 1024px+
      }}
    />
  );
}
```

### Breakpoints

| Name | Min Width | Typical Use |
|------|-----------|-------------|
| base | 0px | Mobile |
| sm | 390px | Large mobile |
| md | 768px | Tablet |
| lg | 1024px | Laptop |
| xl | 1280px | Desktop |
| 2xl | 1536px | Large desktop |

## Peer Dependencies

These components require the following packages in your project:

- `react` >= 18.0.0
- `react-dom` >= 18.0.0
- `framer-motion` >= 10.0.0

## Note

The Framer runtime is bundled as `_framer-runtime.js` - no external Framer dependency needed.
These exports are self-contained and work out of the box.

## Generated

Created with [Design to AI](https://designtoai.com)
