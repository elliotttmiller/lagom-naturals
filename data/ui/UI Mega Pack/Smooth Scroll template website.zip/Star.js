var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/xEBo97cVWFr8Wsxymm2p/SWvAt8lRgaKxfQAdQFfV/zXonZCMXX.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls, ControlType, cx, SVG, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React from "react";
var cycleOrder = ["SNeVeFwMn", "C33x8yyS8", "xozFa03Y8", "vYWThECsb", "PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"];
var serializationHash = "framer-VENYI";
var variantClassNames = { C33x8yyS8: "framer-v-1jbghx9", C8f2WOGzl: "framer-v-19hngfh", CYWGIEi_h: "framer-v-y2ozhz", du5n_Rd4l: "framer-v-1et3jj8", PJsBffpXq: "framer-v-qbaxz1", Qizuh7B2i: "framer-v-16s5c90", QPVR2e_fL: "framer-v-12is2hm", SNeVeFwMn: "framer-v-7mdbtb", vtnvZUrR_: "framer-v-1wvfx6t", vYWThECsb: "framer-v-12rha3s", xozFa03Y8: "framer-v-1l85t44" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion.create(React.Fragment);
var humanReadableVariantMap = { "0 stars": "du5n_Rd4l", "0.5 stars": "C8f2WOGzl", "1 star": "Qizuh7B2i", "1.5 stars": "vtnvZUrR_", "2 stars": "CYWGIEi_h", "2.5 stars": "QPVR2e_fL", "3 stars": "PJsBffpXq", "3.5 stars": "vYWThECsb", "4 stars": "xozFa03Y8", "4.5 stars": "C33x8yyS8", "5 stars": "SNeVeFwMn" };
var getProps = ({ height, id, starColor, width, ...props }) => {
  return { ...props, NrYSLS2cT: starColor ?? props.NrYSLS2cT ?? "var(--token-0c2325eb-32e6-4468-b86d-b2000f27f938, rgb(255, 255, 255))", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "SNeVeFwMn" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { activeLocale, setLocale } = useLocaleInfo();
  const { style, className, layoutId, variant, NrYSLS2cT, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "SNeVeFwMn", variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  const ref1 = React.useRef(null);
  const isDisplayed = () => {
    if (["C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed1 = () => {
    if (["vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed2 = () => {
    if (["QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed3 = () => {
    if (["vYWThECsb", "PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed4 = () => {
    if (["C33x8yyS8", "xozFa03Y8", "vYWThECsb", "PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed5 = () => {
    if (["C33x8yyS8", "vYWThECsb", "QPVR2e_fL", "vtnvZUrR_", "C8f2WOGzl"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed6 = () => {
    if (["xozFa03Y8", "vYWThECsb", "PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed7 = () => {
    if (baseVariant === "du5n_Rd4l")
      return true;
    return false;
  };
  const isDisplayed8 = () => {
    if (["Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed9 = () => {
    if (["CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed10 = () => {
    if (["PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"].includes(baseVariant))
      return true;
    return false;
  };
  const defaultLayoutId = React.useId();
  const componentViewport = useComponentViewport();
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-7mdbtb", className, classNames), "data-framer-name": "5 stars", layoutDependency, layoutId: "StarRating__SNeVeFwMn", ref: ref ?? ref1, style: { ...style }, ...addPropertyOverrides({ C33x8yyS8: { "data-framer-name": "4.5 stars" }, C8f2WOGzl: { "data-framer-name": "0.5 stars" }, CYWGIEi_h: { "data-framer-name": "2 stars" }, du5n_Rd4l: { "data-framer-name": "0 stars" }, PJsBffpXq: { "data-framer-name": "3 stars" }, Qizuh7B2i: { "data-framer-name": "1 star" }, QPVR2e_fL: { "data-framer-name": "2.5 stars" }, vtnvZUrR_: { "data-framer-name": "1.5 stars" }, vYWThECsb: { "data-framer-name": "3.5 stars" }, xozFa03Y8: { "data-framer-name": "4 stars" } }, baseVariant, gestureVariant), children: [isDisplayed() && /* @__PURE__ */ _jsx(SVG, { className: "framer-1g59teg", "data-framer-name": "Star", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__q5oNOyXse", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m5.825 21 1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed1() && /* @__PURE__ */ _jsx(SVG, { className: "framer-1auge5l", "data-framer-name": "Star", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__rsE5w4CZj", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m5.825 21 1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed2() && /* @__PURE__ */ _jsx(SVG, { className: "framer-1tq1rwa", "data-framer-name": "Star", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__hvZYj7yBq", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m5.825 21 1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed3() && /* @__PURE__ */ _jsx(SVG, { className: "framer-1jpi7l6", "data-framer-name": "Star", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__Zxtyx5aF1", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m5.825 21 1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed4() && /* @__PURE__ */ _jsx(SVG, { className: "framer-1ptboap", "data-framer-name": "Star", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__unuUehAtf", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m5.825 21 1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed5() && /* @__PURE__ */ _jsx(SVG, { className: "framer-1b7ffol", "data-framer-name": "Star-half", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__lTxZRRdN2", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m15.15 16.85-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4v7.8zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275z"/></svg>', withExternalLayout: true }), isDisplayed6() && /* @__PURE__ */ _jsx(SVG, { className: "framer-1dyx8os", "data-framer-name": "Star-outline", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__hODUYUJFG", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.85 16.825 3.15-1.9 3.15 1.925-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4-1.45 3.375-3.65.325 2.775 2.425zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275zM12 12.25"/></svg>', withExternalLayout: true }), isDisplayed7() && /* @__PURE__ */ _jsx(SVG, { className: "framer-87sana", "data-framer-name": "Star-outline", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__DpG33iSNb", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.85 16.825 3.15-1.9 3.15 1.925-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4-1.45 3.375-3.65.325 2.775 2.425zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275zM12 12.25"/></svg>', withExternalLayout: true }), isDisplayed8() && /* @__PURE__ */ _jsx(SVG, { className: "framer-1rau8d1", "data-framer-name": "Star-outline", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__fifMOufgg", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.85 16.825 3.15-1.9 3.15 1.925-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4-1.45 3.375-3.65.325 2.775 2.425zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275zM12 12.25"/></svg>', withExternalLayout: true }), isDisplayed9() && /* @__PURE__ */ _jsx(SVG, { className: "framer-1tfpoyz", "data-framer-name": "Star-outline", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__GvwW5ZD76", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.85 16.825 3.15-1.9 3.15 1.925-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4-1.45 3.375-3.65.325 2.775 2.425zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275zM12 12.25"/></svg>', withExternalLayout: true }), isDisplayed10() && /* @__PURE__ */ _jsx(SVG, { className: "framer-7d04ze", "data-framer-name": "Star-outline", fill: NrYSLS2cT, intrinsicHeight: 24, intrinsicWidth: 24, layoutDependency, layoutId: "StarRating__GVXWG_zfJ", svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.85 16.825 3.15-1.9 3.15 1.925-.825-3.6 2.775-2.4-3.65-.325-1.45-3.4-1.45 3.375-3.65.325 2.775 2.425zM5.825 21l1.625-7.025L2 9.25l7.2-.625L12 2l2.8 6.625 7.2.625-5.45 4.725L18.175 21 12 17.275zM12 12.25"/></svg>', withExternalLayout: true })] }) }) }) });
});
var css = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-VENYI.framer-qslqvu, .framer-VENYI .framer-qslqvu { display: block; }", ".framer-VENYI.framer-7mdbtb { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 4px; height: min-content; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: min-content; }", ".framer-VENYI .framer-1g59teg, .framer-VENYI .framer-1auge5l, .framer-VENYI .framer-1tq1rwa, .framer-VENYI .framer-1jpi7l6, .framer-VENYI .framer-1ptboap, .framer-VENYI .framer-87sana, .framer-VENYI .framer-1rau8d1, .framer-VENYI .framer-1tfpoyz, .framer-VENYI .framer-7d04ze { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 20px); position: relative; width: 20px; }", ".framer-VENYI .framer-1b7ffol, .framer-VENYI .framer-1dyx8os { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 24px); position: relative; width: 20px; }", "@supports (background: -webkit-named-image(i)) and (not (font-palette:dark)) { .framer-VENYI.framer-7mdbtb { gap: 0px; } .framer-VENYI.framer-7mdbtb > * { margin: 0px; margin-left: calc(4px / 2); margin-right: calc(4px / 2); } .framer-VENYI.framer-7mdbtb > :first-child { margin-left: 0px; } .framer-VENYI.framer-7mdbtb > :last-child { margin-right: 0px; } }", ".framer-VENYI.framer-v-1jbghx9 .framer-1b7ffol, .framer-VENYI.framer-v-1l85t44 .framer-1dyx8os, .framer-VENYI.framer-v-12rha3s .framer-1b7ffol, .framer-VENYI.framer-v-12rha3s .framer-1dyx8os, .framer-VENYI.framer-v-qbaxz1 .framer-1dyx8os, .framer-VENYI.framer-v-12is2hm .framer-1b7ffol, .framer-VENYI.framer-v-12is2hm .framer-1dyx8os, .framer-VENYI.framer-v-y2ozhz .framer-1dyx8os, .framer-VENYI.framer-v-1wvfx6t .framer-1b7ffol, .framer-VENYI.framer-v-1wvfx6t .framer-1dyx8os, .framer-VENYI.framer-v-16s5c90 .framer-1dyx8os, .framer-VENYI.framer-v-19hngfh .framer-1b7ffol, .framer-VENYI.framer-v-19hngfh .framer-1dyx8os, .framer-VENYI.framer-v-1et3jj8 .framer-1dyx8os { height: var(--framer-aspect-ratio-supported, 20px); }"];
var FramerzXonZCMXX = withCSS(Component, css, "framer-VENYI");
var zXonZCMXX_default = FramerzXonZCMXX;
FramerzXonZCMXX.displayName = "Star Rating";
FramerzXonZCMXX.defaultProps = { height: 20, width: 116 };
addPropertyControls(FramerzXonZCMXX, { variant: { options: ["SNeVeFwMn", "C33x8yyS8", "xozFa03Y8", "vYWThECsb", "PJsBffpXq", "QPVR2e_fL", "CYWGIEi_h", "vtnvZUrR_", "Qizuh7B2i", "C8f2WOGzl", "du5n_Rd4l"], optionTitles: ["5 stars", "4.5 stars", "4 stars", "3.5 stars", "3 stars", "2.5 stars", "2 stars", "1.5 stars", "1 star", "0.5 stars", "0 stars"], title: "Variant", type: ControlType.Enum }, NrYSLS2cT: { defaultValue: 'var(--token-0c2325eb-32e6-4468-b86d-b2000f27f938, rgb(255, 255, 255)) /* {"name":"White"} */', title: "Star color", type: ControlType.Color } });
addFonts(FramerzXonZCMXX, [{ explicitInter: true, fonts: [] }], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerzXonZCMXX", "slots": [], "annotations": { "framerIntrinsicHeight": "20", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"C33x8yyS8":{"layout":["auto","auto"]},"xozFa03Y8":{"layout":["auto","auto"]},"vYWThECsb":{"layout":["auto","auto"]},"PJsBffpXq":{"layout":["auto","auto"]},"QPVR2e_fL":{"layout":["auto","auto"]},"CYWGIEi_h":{"layout":["auto","auto"]},"vtnvZUrR_":{"layout":["auto","auto"]},"Qizuh7B2i":{"layout":["auto","auto"]},"C8f2WOGzl":{"layout":["auto","auto"]},"du5n_Rd4l":{"layout":["auto","auto"]}}}', "framerDisplayContentsDiv": "false", "framerContractVersion": "1", "framerImmutableVariables": "true", "framerIntrinsicWidth": "116", "framerVariables": '{"NrYSLS2cT":"starColor"}', "framerComponentViewportWidth": "true" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  zXonZCMXX_default as default
};
