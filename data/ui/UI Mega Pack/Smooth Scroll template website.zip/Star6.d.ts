export interface Star6Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "0 stars" → du5n_Rd4l
   *   "0.5 stars" → C8f2WOGzl
   *   "1 star" → Qizuh7B2i
   *   "1.5 stars" → vtnvZUrR_
   *   "2 stars" → CYWGIEi_h
   *   "2.5 stars" → QPVR2e_fL
   *   "3 stars" → PJsBffpXq
   *   "3.5 stars" → vYWThECsb
   *   "4 stars" → xozFa03Y8
   *   "4.5 stars" → C33x8yyS8
   *   "5 stars" → SNeVeFwMn
   */
  variant?: '0 stars' | '0.5 stars' | '1 star' | '1.5 stars' | '2 stars' | '2.5 stars' | '3 stars' | '3.5 stars' | '4 stars' | '4.5 stars' | '5 stars' | 'SNeVeFwMn' | 'C33x8yyS8' | 'xozFa03Y8' | 'vYWThECsb' | 'PJsBffpXq' | 'QPVR2e_fL' | 'CYWGIEi_h' | 'vtnvZUrR_' | 'Qizuh7B2i' | 'C8f2WOGzl' | 'du5n_Rd4l';
  /**
   * Star color — pass as `NrYSLS2cT` not `starColor`.
   * @default "var(--token-0c2325eb-32e6-4468-b86d-b2000f27f938, rgb(255, 255, 255)) /* {"name":"White"} */"
   */
  NrYSLS2cT?: string;
  /** Additional properties */
  [key: string]: unknown;
}
