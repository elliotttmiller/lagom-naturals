export interface Services2Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "2" → H7_YPkqyz
   *   "3" → L0AyCHCHe
   *   "4" → zAFG3QXVq
   *   "5" → cWP8kjAl_
   *   "6" → n_kk3wZQf
   *   "2 (tablet/mobile)" → jheFFY1n9
   *   "3 (tablet/mobile)" → YpvZKvXha
   *   "4 (tablet/mobile)" → Bi8HzdATW
   *   "5 (tablet/mobile)" → oTCD6c21Q
   *   "6 (tablet/mobile)" → yFUgcuNuy
   *   "First open (tablet/mobile)" → e1DJeH6JF
   *   "First open" → QDfYGxs2l
   */
  variant?: '2' | '3' | '4' | '5' | '6' | '2 (tablet/mobile)' | '3 (tablet/mobile)' | '4 (tablet/mobile)' | '5 (tablet/mobile)' | '6 (tablet/mobile)' | 'First open (tablet/mobile)' | 'First open' | 'QDfYGxs2l' | 'H7_YPkqyz' | 'L0AyCHCHe' | 'zAFG3QXVq' | 'cWP8kjAl_' | 'n_kk3wZQf' | 'e1DJeH6JF' | 'jheFFY1n9' | 'YpvZKvXha' | 'Bi8HzdATW' | 'oTCD6c21Q' | 'yFUgcuNuy';
  /** Additional properties */
  [key: string]: unknown;
}
