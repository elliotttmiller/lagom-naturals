var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/8ZFj6XbswGragMJUEFDo/LZYeSj1BxlwSK7HlIol1/IJOffH5nF.js
import { jsx as _jsx, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ComponentViewportProvider, ControlType as ControlType2, cx, getFonts, getFontsFromSharedStyle, getPropertyControls, RichText, SmartComponentScopedContainer, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/qpjhCcDm4G1NbFAlpMKV/OnyZiTlIjOBuSKcKQWFv/AnimatedNumberCounter_Prod.js
import { jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { addPropertyControls, ControlType, RenderTarget } from "./_framer-runtime.js";
import { useEffect, useState, useRef } from "react";
import { motion, useMotionValue, animate, useInView } from "framer-motion";
function AnimatedNumberCounter(props) {
  const { mode, start, end, value, decimals, commas, color, animation } = props;
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  const Tag = props.tag;
  const MotionTag = motion[props.tag];
  const isDefault = mode == "default";
  const initialValue = isDefault ? start : value;
  const transition = isDefault ? animation.transition : props.transition;
  const formatNumber = (number2) => {
    let numberString = number2.toFixed(decimals);
    if (commas) {
      numberString = numberString.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    return numberString;
  };
  const [number, setNumber] = useState(initialValue);
  const [finalValue, setFinalValue] = useState(number);
  const [currentAnimation, setCurrentAnimation] = useState(null);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: !props.animation.replay, amount: "some" });
  const motionValue = useMotionValue(value);
  const runAnimation = (from, to) => {
    if (!isCanvas) {
      if (currentAnimation) {
        currentAnimation.stop();
      }
      setFinalValue(to);
      setCurrentAnimation(animate(from, to, { ...transition, onUpdate: (latest) => {
        setNumber(latest);
      } }));
    }
  };
  useEffect(() => {
    if (isDefault && animation.trigger == "appear") {
      runAnimation(start, end);
    }
  }, []);
  useEffect(() => {
    if (isDefault && animation.trigger == "layerInView") {
      if (isInView) {
        runAnimation(start, end);
      } else {
        if (currentAnimation) {
          currentAnimation.stop();
        }
        setNumber(start);
      }
    }
  }, [isInView]);
  useEffect(() => {
    if (!isDefault) {
      runAnimation(number, value);
    }
  }, [value]);
  return /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsxs(Tag, { style: { ...props.style, margin: 0, opacity: 0, pointerEvents: "none", userSelect: "none", textWrap: props.balance ? "balance" : void 0, fontVariantNumeric: props.monospace ? "tabular-nums" : void 0, textAlign: "center", ...props.font }, children: [props.prefix, formatNumber(isCanvas ? initialValue : finalValue), props.suffix] }), /* @__PURE__ */ _jsxs(MotionTag, { ref, style: { position: "absolute", inset: 0, userSelect: props.userSelect ? "auto" : "none", fontVariantNumeric: props.monospace ? "tabular-nums" : void 0, margin: 0, ...color.mode == "solid" ? { color: color.color } : { WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundImage: `linear-gradient(${color.angle}deg, ${color.startColor}, ${color.endColor})` }, textDecoration: props.decoration, textWrap: props.balance ? "balance" : void 0, textAlign: "center", ...props.font, ...props.style }, children: [props.prefix, formatNumber(isCanvas ? initialValue : number), props.suffix] })] });
}
AnimatedNumberCounter.displayName = "Animated Number Counter";
addPropertyControls(AnimatedNumberCounter, { mode: { type: ControlType.Enum, options: ["default", "variants"], optionTitles: ["Default", "Variants"], displaySegmentedControl: true }, value: { type: ControlType.Number, defaultValue: 0, hidden: (props) => props.mode !== "variants" }, start: { type: ControlType.Number, defaultValue: 0, hidden: (props) => props.mode !== "default" }, end: { type: ControlType.Number, defaultValue: 100, hidden: (props) => props.mode !== "default" }, animation: { type: ControlType.Object, icon: "effect", hidden: (props) => props.mode !== "default", controls: { trigger: { type: ControlType.Enum, defaultValue: "layerInView", options: ["appear", "layerInView"], optionTitles: ["Appear", "Layer in View"], displaySegmentedControl: true, segmentedControlDirection: "vertical" }, replay: { type: ControlType.Boolean, defaultValue: true, hidden(props) {
  return props.trigger !== "layerInView";
} }, transition: { type: ControlType.Transition, defaultValue: { type: "spring", duration: 1, bounce: 0 } } } }, transition: { type: ControlType.Transition, defaultValue: { type: "spring", duration: 1, bounce: 0 }, hidden: (props) => props.mode !== "variants" }, decimals: { type: ControlType.Enum, defaultValue: 0, options: [0, 1, 2, 3], optionTitles: ["Off", "1", "2", "3"], displaySegmentedControl: true }, commas: { type: ControlType.Boolean, defaultValue: true }, font: { type: "font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: 16, lineHeight: 1 } }, color: { type: ControlType.Object, controls: { mode: { type: ControlType.Enum, defaultValue: "solid", options: ["solid", "gradient"], optionTitles: ["Solid", "Gradient"], displaySegmentedControl: true }, color: { type: ControlType.Color, defaultValue: "#000", hidden: (props) => props.mode !== "solid" }, startColor: { type: ControlType.Color, defaultValue: "#000", hidden: (props) => props.mode !== "gradient" }, endColor: { type: ControlType.Color, defaultValue: "#FFF", hidden: (props) => props.mode !== "gradient" }, angle: { type: ControlType.Number, defaultValue: 180, min: -360, max: 360, unit: "\xB0", hidden: (props) => props.mode !== "gradient" } } }, prefix: { type: ControlType.String, placeholder: "Prefix" }, suffix: { type: ControlType.String, placeholder: "Suffix" }, decoration: { type: ControlType.Enum, defaultValue: "none", options: ["none", "underline", "line-through"], optionTitles: ["None", "Underline", "Strikethrough"] }, balance: { type: ControlType.Boolean, defaultValue: false }, userSelect: { type: ControlType.Boolean, defaultValue: true }, tag: { type: ControlType.Enum, defaultValue: "p", displaySegmentedControl: true, options: ["h1", "h2", "h3", "p"], optionTitles: ["H1", "H2", "H3", "P"] }, monospace: { type: ControlType.Boolean, defaultValue: false, description: "More components at [Framer University](https://frameruni.link/cc)." } });

// http-url:https://framerusercontent.com/modules/moBBEfp6Ams1lF3iPMKF/9IwZk47Ek4fEw9ww6TbA/ehdRgl_aR.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["FS;Manrope-semibold", "FS;Manrope-bold"]);
var fonts = [{ explicitInter: true, fonts: [{ family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/6U2SGH566NSNERG6RGEV3DSNEK7DL2RF/JRDYRKMSAW2H35IWEQIPL67HAJQ35MG5/JNU3GNMUBPWW6V6JTED3S27XL5HN7NM5.woff2", weight: "600" }, { family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/NGBUP45ES3F7RD5XGKPEDJ6QEPO4TMOK/EXDVWJ2EDDVVV65UENMX33EDDYBX6OF7/6P4FPMFQH7CCC7RZ4UU4NKSGJ2RLF7V5.woff2", weight: "700" }] }];
var css = ['.framer-Mx4yn .framer-styles-preset-1bvv7wo:not(.rich-text-wrapper), .framer-Mx4yn .framer-styles-preset-1bvv7wo.rich-text-wrapper h4 { --framer-font-family: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-family-bold: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 20px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 600; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.2px; --framer-line-height: 150%; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, #101014); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className = "framer-Mx4yn";

// http-url:https://framerusercontent.com/modules/cfnoiB0PsBwpPvPBP4Y0/VmTZaI50SLXz8VgYjtyr/MHmNpcoFD.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["FS;Manrope-regular", "FS;Manrope-bold"]);
var fonts2 = [{ explicitInter: true, fonts: [{ family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/2TYFCBHUANEXS6QGR5EQDUNAFH6LSWM3/AYNOU3VEA4LRTDNKJQUFNVNUTYSGOUOP/UXO4O7K2G3HI3D2VKD7UXVJVJD26P4BQ.woff2", weight: "400" }, { family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/NGBUP45ES3F7RD5XGKPEDJ6QEPO4TMOK/EXDVWJ2EDDVVV65UENMX33EDDYBX6OF7/6P4FPMFQH7CCC7RZ4UU4NKSGJ2RLF7V5.woff2", weight: "700" }] }];
var css2 = ['.framer-hr9WG .framer-styles-preset-18tc05i:not(.rich-text-wrapper), .framer-hr9WG .framer-styles-preset-18tc05i.rich-text-wrapper p { --framer-font-family: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-family-bold: "Manrope", "Manrope Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 16px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: -0.1px; --framer-line-height: 130%; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-0c2325eb-32e6-4468-b86d-b2000f27f938, #ffffff); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className2 = "framer-hr9WG";

// http-url:https://framerusercontent.com/modules/8ZFj6XbswGragMJUEFDo/LZYeSj1BxlwSK7HlIol1/IJOffH5nF.js
var AnimatedNumberCounterFonts = getFonts(AnimatedNumberCounter);
var AnimatedNumberCounterControls = getPropertyControls(AnimatedNumberCounter);
var serializationHash = "framer-Avxn5";
var variantClassNames = { De8tkJayw: "framer-v-1sfdt9p" };
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion2.create(React.Fragment);
var humanReadableEnumMap = {};
var getProps = ({ decimals, description, end, height, id, prefix, start, suffix, title, width, ...props }) => {
  return { ...props, a45OqAkJ4: title ?? props.a45OqAkJ4 ?? "Years experience", cIxpXL2bb: prefix ?? props.cIxpXL2bb, Db_1O6OS_: suffix ?? props.Db_1O6OS_, fsQsolJw6: humanReadableEnumMap[decimals] ?? decimals ?? props.fsQsolJw6, hwmcMZpxa: start ?? props.hwmcMZpxa, Lc6Dz0rIA: description ?? props.Lc6Dz0rIA ?? "Years of experience in home improvement", sNi39lGOD: end ?? props.sNi39lGOD ?? 10 };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className3, layoutId, variant, hwmcMZpxa, sNi39lGOD, fsQsolJw6, cIxpXL2bb, Db_1O6OS_, a45OqAkJ4, Lc6Dz0rIA, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "De8tkJayw", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [className, className2];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs2(motion2.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-1sfdt9p", className3, classNames), "data-framer-name": "Desktop", layoutDependency, layoutId: "Statistic__De8tkJayw", ref: refBinding, style: { ...style }, children: [/* @__PURE__ */ _jsx(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx(SmartComponentScopedContainer, { className: "framer-1d3zokl-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "Statistic__nG_2qR9mO-container", nodeId: "nG_2qR9mO", rendersWithMotion: true, scopeId: "IJOffH5nF", children: /* @__PURE__ */ _jsx(AnimatedNumberCounter, { animation: { replay: false, transition: { bounce: 0, delay: 0, duration: 1, type: "spring" }, trigger: "layerInView" }, balance: false, color: { angle: 180, color: "var(--token-293955a5-6f9a-470e-8eb8-8f52a27509f0, rgb(16, 16, 20))", endColor: "rgb(255, 255, 255)", mode: "solid", startColor: "rgb(0, 0, 0)" }, commas: true, decimals: fsQsolJw6, decoration: "none", end: sNi39lGOD, font: { fontFamily: '"Manrope", "Manrope Placeholder", sans-serif', fontSize: "72px", fontStyle: "normal", fontWeight: 300, letterSpacing: "-0.8px", lineHeight: "100%" }, height: "100%", id: "nG_2qR9mO", layoutId: "Statistic__nG_2qR9mO", mode: "default", monospace: false, prefix: cIxpXL2bb, start: hwmcMZpxa, suffix: Db_1O6OS_, tag: "p", transition: { bounce: 0, delay: 0, duration: 1, type: "spring" }, userSelect: true, value: 3, width: "100%" }) }) }), /* @__PURE__ */ _jsxs2(motion2.div, { className: "framer-1duzu1", "data-framer-name": "Content", layoutDependency, layoutId: "Statistic__aIj8WHkoq", children: [/* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion2.h4, { className: "framer-styles-preset-1bvv7wo", "data-styles-preset": "ehdRgl_aR", children: "Years experience" }) }), className: "framer-tdcpvn", fonts: ["Inter"], layoutDependency, layoutId: "Statistic__ydI3aUp2v", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: a45OqAkJ4, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion2.p, { className: "framer-styles-preset-18tc05i", "data-styles-preset": "MHmNpcoFD", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-30e48027-3b22-4ff1-a546-6bd64e851575, rgb(61, 61, 71)))" }, children: "Years of experience in home improvement" }) }), className: "framer-azeypg", fonts: ["Inter"], layoutDependency, layoutId: "Statistic__UDEaQu_HL", style: { "--extracted-r6o4lv": "var(--token-30e48027-3b22-4ff1-a546-6bd64e851575, rgb(61, 61, 71))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: Lc6Dz0rIA, verticalAlignment: "top", withExternalLayout: true })] })] }) }) }) });
});
var css3 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-Avxn5.framer-1bohmlm, .framer-Avxn5 .framer-1bohmlm { display: block; }", ".framer-Avxn5.framer-1sfdt9p { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 20px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-Avxn5 .framer-1d3zokl-container { flex: none; height: auto; position: relative; width: auto; }", ".framer-Avxn5 .framer-1duzu1 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 5px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-Avxn5 .framer-tdcpvn, .framer-Avxn5 .framer-azeypg { flex: none; height: auto; max-width: 100%; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", "@supports (background: -webkit-named-image(i)) and (not (font-palette:dark)) { .framer-Avxn5.framer-1sfdt9p, .framer-Avxn5 .framer-1duzu1 { gap: 0px; } .framer-Avxn5.framer-1sfdt9p > * { margin: 0px; margin-bottom: calc(20px / 2); margin-top: calc(20px / 2); } .framer-Avxn5.framer-1sfdt9p > :first-child, .framer-Avxn5 .framer-1duzu1 > :first-child { margin-top: 0px; } .framer-Avxn5.framer-1sfdt9p > :last-child, .framer-Avxn5 .framer-1duzu1 > :last-child { margin-bottom: 0px; } .framer-Avxn5 .framer-1duzu1 > * { margin: 0px; margin-bottom: calc(5px / 2); margin-top: calc(5px / 2); } }", ...css, ...css2];
var FramerIJOffH5nF = withCSS(Component, css3, "framer-Avxn5");
var IJOffH5nF_default = FramerIJOffH5nF;
FramerIJOffH5nF.displayName = "Statistic";
FramerIJOffH5nF.defaultProps = { height: 168.5, width: 230 };
addPropertyControls2(FramerIJOffH5nF, { hwmcMZpxa: { defaultValue: 0, displayStepper: true, title: "Start", type: ControlType2.Number }, sNi39lGOD: { defaultValue: 10, displayStepper: true, title: "End", type: ControlType2.Number }, fsQsolJw6: AnimatedNumberCounterControls?.["decimals"] && { ...AnimatedNumberCounterControls["decimals"], defaultValue: 0, description: void 0, hidden: void 0, title: "Decimals" }, cIxpXL2bb: { defaultValue: "", placeholder: "Prefix", title: "Prefix", type: ControlType2.String }, Db_1O6OS_: { defaultValue: "", placeholder: "Suffix", title: "Suffix", type: ControlType2.String }, a45OqAkJ4: { defaultValue: "Years experience", displayTextArea: false, title: "Title", type: ControlType2.String }, Lc6Dz0rIA: { defaultValue: "Years of experience in home improvement", displayTextArea: true, title: "Description", type: ControlType2.String } });
addFonts(FramerIJOffH5nF, [{ explicitInter: true, fonts: [{ family: "Manrope", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/R46SR2KWPHAT6QKQ5J22GMKGX57ZRVAR/Z5WLPW3IGEZJHN5HBLPCBJIK6QBBSHX6/2W7RU2QRQHEAEGUDZDHBPHR6WI27JNIQ.woff2", weight: "300" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/vQyevYAyHtARFwPqUzQGpnDs.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...AnimatedNumberCounterFonts, ...getFontsFromSharedStyle(fonts), ...getFontsFromSharedStyle(fonts2)], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerIJOffH5nF", "slots": [], "annotations": { "framerComponentViewportWidth": "true", "framerContractVersion": "1", "framerImmutableVariables": "true", "framerVariables": '{"hwmcMZpxa":"start","sNi39lGOD":"end","fsQsolJw6":"decimals","cIxpXL2bb":"prefix","Db_1O6OS_":"suffix","a45OqAkJ4":"title","Lc6Dz0rIA":"description"}', "framerIntrinsicHeight": "168.5", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]}}}', "framerIntrinsicWidth": "230", "framerDisplayContentsDiv": "false" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  IJOffH5nF_default as default
};
