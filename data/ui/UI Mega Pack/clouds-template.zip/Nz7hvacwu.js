var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/c4HsHmhw2A874wd4HUv4/eiMgKnTLbWkmDtuRAl8s/Nz7HVaCWU.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 4.5 12 C 4.5 12 -0.67 9 0.073 0.75 C 0.073 0.75 3.791 4.5 8.25 5.25 L 8.25 3.75 C 8.25 1.688 9.938 -0.025 12 0 C 13.486 0.018 14.827 0.895 15.438 2.25 L 18.75 2.25 L 15.75 5.25 C 15.351 11.517 10.117 16.5 3.75 16.5 C 0.75 16.5 0 15.375 0 15.375 C 0 15.375 3 14.25 4.5 12 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="16.500277009874278px" id="m75eVfHb1" transform="translate(3.75 4.5)" width="18.75px"/><path d="M 4.5 12 C 4.5 12 -0.67 9 0.073 0.75 C 0.073 0.75 3.791 4.5 8.25 5.25 L 8.25 3.75 C 8.25 1.688 9.938 -0.025 12 0 C 13.486 0.018 14.827 0.895 15.438 2.25 L 18.75 2.25 L 15.75 5.25 C 15.351 11.517 10.117 16.5 3.75 16.5 C 0.75 16.5 0 15.375 0 15.375 C 0 15.375 3 14.25 4.5 12 Z" fill="transparent" height="16.500277009874278px" id="t6GDkf38W" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(3.75 4.5)" width="18.75px"/></svg>';
var getProps = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps(props);
  const href = useSVGTemplate("1559402302", svg);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-0bjwk", className), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx("use", { href }) });
});
var css = [`.framer-0bjwk { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-0bjwk");
Icon.displayName = "Twitter Logo";
var Nz7HVaCWU_default = Icon;
addPropertyControls(Icon, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType.Number } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "Icon", "slots": [], "annotations": { "framerDisableUnlink": "true", "framerIntrinsicHeight": "24", "framerIntrinsicWidth": "24", "framerImmutableVariables": "true", "framerSupportedLayoutWidth": "any-prefer-fixed", "framerVector": '{"name":"Twitter Logo","color":{"type":"variable","value":"21h8s6"},"set":{"localId":"vectorSet/NGVKdicsm","id":"NGVKdicsm","moduleId":"omX0gWFPqDwhaiWwf6ab"}}', "framerContractVersion": "1", "framerSupportedLayoutHeight": "any-prefer-fixed", "framerVariables": '{"ezTt3ayMo":"color","lschgej4H":"width1","qxTvv_EBh":"alpha"}' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  Nz7HVaCWU_default as default
};
