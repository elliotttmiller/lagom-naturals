var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/n57x7pUtparegV6rvCXB/XiBbzo9BI6TcvdY4iuSg/cixK6t3Sw.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, getFonts, Link, RichText, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/oFR5KZKH0Wlmr3hYA9ry/VrAYP8bkI7K0K8zmkGf1/VNP9qEHCb.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 20 15" xmlns="http://www.w3.org/2000/svg"><path d="M 0 6.5 L 18 6.5 M 11.7 0 L 18 6.5 L 11.7 13" fill="transparent" height="13px" id="cdTXRUVSB" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--c8na3v, 1.5)" stroke="var(--deve01, rgb(0,0,0))" transform="translate(1 1)" width="18px"/></svg>';
var getProps = ({ height, iconColor, iconWidth, id, width, ...props }) => {
  return { ...props, MEYxWidI6: iconColor ?? props.MEYxWidI6 ?? "rgb(0, 0, 0)", RpiPLOz13: iconWidth ?? props.RpiPLOz13 ?? 1.5 };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, MEYxWidI6, RpiPLOz13, ...restProps } = getProps(props);
  const href = useSVGTemplate("3459912891", svg);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-uoyYP", className), layoutId, ref, role: "presentation", style: { "--c8na3v": RpiPLOz13, "--deve01": MEYxWidI6, ...style }, viewBox: "0 0 20 15", children: /* @__PURE__ */ _jsx("use", { href }) });
});
var css = [`.framer-uoyYP { -webkit-mask: ${mask}; aspect-ratio: 1.3333333333333333; display: block; mask: ${mask}; width: 20px; }`];
var Icon = withCSS(Component, css, "framer-uoyYP");
Icon.displayName = "Arrow Icon";
var VNP9qEHCb_default = Icon;
addPropertyControls(Icon, { MEYxWidI6: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Icon Color", type: ControlType.Color }, RpiPLOz13: { defaultValue: 1.5, hidden: false, min: 0, title: "Icon Width", type: ControlType.Number } });

// http-url:https://framerusercontent.com/modules/n57x7pUtparegV6rvCXB/XiBbzo9BI6TcvdY4iuSg/cixK6t3Sw.js
var ArrowIconFonts = getFonts(VNP9qEHCb_default);
var enabledGestures = { oLokgxbjW: { hover: true } };
var serializationHash = "framer-kzscb";
var variantClassNames = { oLokgxbjW: "framer-v-1l43iix" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.3, delay: 0, duration: 1, type: "spring" };
var transformTemplate1 = (_, t) => `translateY(-50%) ${t}`;
var transformTemplate2 = (_, t) => `translate(-50%, -50%) ${t}`;
var transition2 = { bounce: 0.3, delay: 0.3, duration: 1, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion2.create(React2.Fragment);
var getProps2 = ({ bottomLineColor, fontColor, fontSize, height, iconColor, iconWidth, id, link, text, width, ...props }) => {
  return { ...props, C3SRcaKeX: iconColor ?? props.C3SRcaKeX ?? "rgb(0, 0, 0)", CKnnJ09y4: iconWidth ?? props.CKnnJ09y4 ?? 1.5, dRsyVOAD8: text ?? props.dRsyVOAD8 ?? "View More Work", jaIRXGE2t: link ?? props.jaIRXGE2t, Li3YJ63Dj: bottomLineColor ?? props.Li3YJ63Dj ?? "rgb(0, 0, 0)", vDkujOasE: fontSize ?? props.vDkujOasE ?? 24, zpE5lwrue: fontColor ?? props.zpE5lwrue ?? "rgb(0, 0, 0)" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, dRsyVOAD8, zpE5lwrue, vDkujOasE, Li3YJ63Dj, C3SRcaKeX, CKnnJ09y4, jaIRXGE2t, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "oLokgxbjW", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsx2(Link, { href: jaIRXGE2t, motionChild: true, nodeId: "oLokgxbjW", openInNewTab: true, scopeId: "cixK6t3Sw", children: /* @__PURE__ */ _jsx2(motion2.a, { ...restProps, ...gestureHandlers, className: `${cx2(scopingClassNames, "framer-1l43iix", className, classNames)} framer-1wykfc7`, "data-framer-name": "Default", layoutDependency, layoutId: "cixK6t3Sw__oLokgxbjW", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ "oLokgxbjW-hover": { "data-framer-name": void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsxs(motion2.div, { className: "framer-dx14z0", "data-framer-name": "Content Wrapper", layoutDependency, layoutId: "cixK6t3Sw__Y6LSnEDbP", children: [/* @__PURE__ */ _jsxs(motion2.div, { className: "framer-bb0v0p", "data-framer-name": "Top", layoutDependency, layoutId: "cixK6t3Sw__m_vRDcsgF", children: [/* @__PURE__ */ _jsx2(motion2.div, { className: "framer-vixfmr", "data-framer-name": "Arrow Left", layoutDependency, layoutId: "cixK6t3Sw__KLmAfcMjt", style: { opacity: 0, rotate: -90, scale: 0 }, transformTemplate: transformTemplate1, variants: { "oLokgxbjW-hover": { opacity: 1, rotate: 0, scale: 1 } }, ...addPropertyOverrides({ "oLokgxbjW-hover": { transformTemplate: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx2(VNP9qEHCb_default, { animated: true, className: "framer-1f9vpxl", layoutDependency, layoutId: "cixK6t3Sw__r80oH5NjD", style: { "--c8na3v": CKnnJ09y4, "--deve01": C3SRcaKeX } }) }), /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { dir: "auto", style: { "--font-selector": "R0Y7R29vZ2xlIFNhbnMgRmxleC1yZWd1bGFy", "--framer-font-family": '"Google Sans Flex", "Google Sans Flex Placeholder", sans-serif', "--framer-font-open-type-features": "'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on", "--framer-font-size": "calc(var(--variable-reference-vDkujOasE-cixK6t3Sw) * 1px)", "--framer-letter-spacing": "-0.02em", "--framer-line-height": "1em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-zpE5lwrue-cixK6t3Sw))" }, children: "View More Work" }) }), className: "framer-u5fho8", "data-framer-name": "Label", fonts: ["GF;Google Sans Flex-regular"], layoutDependency, layoutId: "cixK6t3Sw__OCITD6vyl", style: { "--extracted-r6o4lv": "var(--variable-reference-zpE5lwrue-cixK6t3Sw)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline", "--variable-reference-vDkujOasE-cixK6t3Sw": vDkujOasE, "--variable-reference-zpE5lwrue-cixK6t3Sw": zpE5lwrue }, text: dRsyVOAD8, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-15a8znd", "data-framer-name": "Arrow Right", layoutDependency, layoutId: "cixK6t3Sw__AgEyfi4bj", style: { rotate: 0, scale: 1 }, variants: { "oLokgxbjW-hover": { rotate: -90, scale: 0 } }, ...addPropertyOverrides({ "oLokgxbjW-hover": { transformTemplate: transformTemplate1 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx2(VNP9qEHCb_default, { animated: true, className: "framer-1nwrk8k", layoutDependency, layoutId: "cixK6t3Sw__MG2a9_1_o", style: { "--c8na3v": CKnnJ09y4, "--deve01": C3SRcaKeX } }) })] }), /* @__PURE__ */ _jsxs(motion2.div, { className: "framer-ii80ep", "data-framer-name": "Bottom", layoutDependency, layoutId: "cixK6t3Sw__scKynP0JN", transformTemplate: transformTemplate2, children: [/* @__PURE__ */ _jsx2(Transition, { value: transition1, ...addPropertyOverrides({ "oLokgxbjW-hover": { value: transition2 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-yymq8p", "data-framer-name": "Line Left", layoutDependency, layoutId: "cixK6t3Sw__BEzkGidCJ", style: { backgroundColor: Li3YJ63Dj } }) }), /* @__PURE__ */ _jsx2(Transition, { value: transition2, ...addPropertyOverrides({ "oLokgxbjW-hover": { value: transition1 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx2(motion2.div, { className: "framer-jrbed1", "data-framer-name": "Line Right", layoutDependency, layoutId: "cixK6t3Sw__BXCFG6OnX", style: { backgroundColor: Li3YJ63Dj } }) })] })] }) }) }) }) }) });
});
var css2 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-kzscb.framer-1wykfc7, .framer-kzscb .framer-1wykfc7 { display: block; }", ".framer-kzscb.framer-1l43iix { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; text-decoration: none; width: min-content; }", ".framer-kzscb .framer-dx14z0 { align-content: center; align-items: center; align-self: stretch; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: auto; }", ".framer-kzscb .framer-bb0v0p { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: min-content; }", ".framer-kzscb .framer-vixfmr { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 32px; height: min-content; justify-content: center; left: -20px; overflow: visible; padding: 0px; position: absolute; top: 50%; width: min-content; z-index: 1; }", ".framer-kzscb .framer-1f9vpxl, .framer-kzscb .framer-1nwrk8k { flex: none; height: var(--framer-aspect-ratio-supported, 15px); position: relative; width: 20px; }", ".framer-kzscb .framer-u5fho8 { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-kzscb .framer-15a8znd { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 32px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: min-content; }", ".framer-kzscb .framer-ii80ep { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 32px; height: min-content; justify-content: center; left: 50%; min-height: 1px; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: absolute; top: 129%; width: 100%; z-index: 1; }", ".framer-kzscb .framer-yymq8p { bottom: 0px; flex: none; height: 1px; left: -3px; overflow: var(--overflow-clip-fallback, clip); position: absolute; width: 1%; z-index: 1; }", ".framer-kzscb .framer-jrbed1 { bottom: 0px; flex: none; height: 1px; overflow: var(--overflow-clip-fallback, clip); position: absolute; right: 0px; width: 100%; z-index: 1; }", ".framer-kzscb.framer-v-1l43iix.hover .framer-vixfmr { left: unset; position: relative; top: unset; }", ".framer-kzscb.framer-v-1l43iix.hover .framer-15a8znd { position: absolute; right: 0px; top: 50%; z-index: 1; }", ".framer-kzscb.framer-v-1l43iix.hover .framer-yymq8p { left: 0px; width: 100%; }", ".framer-kzscb.framer-v-1l43iix.hover .framer-jrbed1 { right: -3px; width: 1%; }"];
var FramercixK6t3Sw = withCSS2(Component2, css2, "framer-kzscb");
var cixK6t3Sw_default = FramercixK6t3Sw;
FramercixK6t3Sw.displayName = "Text Arrow CTA";
FramercixK6t3Sw.defaultProps = { height: 24, width: 206.5 };
addPropertyControls2(FramercixK6t3Sw, { dRsyVOAD8: { defaultValue: "View More Work", displayTextArea: false, title: "Text", type: ControlType2.String }, ondRsyVOAD8Change: { changes: "dRsyVOAD8", type: ControlType2.ChangeHandler }, zpE5lwrue: { defaultValue: "rgb(0, 0, 0)", title: "Font Color", type: ControlType2.Color }, vDkujOasE: { defaultValue: 24, title: "Font Size", type: ControlType2.Number }, onvDkujOasEChange: { changes: "vDkujOasE", type: ControlType2.ChangeHandler }, Li3YJ63Dj: { defaultValue: "rgb(0, 0, 0)", title: "Bottom Line Color", type: ControlType2.Color }, C3SRcaKeX: { defaultValue: "rgb(0, 0, 0)", title: "Icon Color", type: ControlType2.Color }, CKnnJ09y4: { defaultValue: 1.5, min: 0, title: "Icon Width", type: ControlType2.Number }, onCKnnJ09y4Change: { changes: "CKnnJ09y4", type: ControlType2.ChangeHandler }, jaIRXGE2t: { title: "Link", type: ControlType2.Link } });
addFonts(FramercixK6t3Sw, [{ explicitInter: true, fonts: [{ cssFamilyName: "Google Sans Flex", openType: true, source: "google", style: "normal", uiFamilyName: "Google Sans Flex", url: "https://fonts.gstatic.com/s/googlesansflex/v20/t5sJIQcYNIWbFgDgAAzZ34auoVyXkJCOvp3SFWJbN5hF8Ju1x6sKCyp0l9sI40swNJwInycYAJzz0m7kJ4qFQOJBOjLvDSndo0SKMpKSTzwliVdHAy4bxTDHg_ugnAakp8ubyc5qU4LBMUM.woff2", weight: "400" }] }, ...ArrowIconFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramercixK6t3Sw", "slots": [], "annotations": { "framerComponentViewportWidth": "true", "framerIntrinsicWidth": "206.5", "framerVariables": '{"dRsyVOAD8":"text","zpE5lwrue":"fontColor","vDkujOasE":"fontSize","Li3YJ63Dj":"bottomLineColor","C3SRcaKeX":"iconColor","CKnnJ09y4":"iconWidth","jaIRXGE2t":"link"}', "framerColorSyntax": "true", "framerImmutableVariables": "true", "framerIntrinsicHeight": "24", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"OyGQLVx6C":{"layout":["auto","auto"]}}}', "framerAutoSizeImages": "true", "framerContractVersion": "1", "framerDisplayContentsDiv": "false" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  cixK6t3Sw_default as default
};
