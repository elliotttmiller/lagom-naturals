export interface Cixk6t3swProps {
  /**
   * Text — pass as `dRsyVOAD8` not `text`.
   * @default "View More Work"
   */
  dRsyVOAD8?: string;
  ondRsyVOAD8Change?: string;
  /**
   * Font Color — pass as `zpE5lwrue` not `fontColor`.
   * @default "rgb(0, 0, 0)"
   */
  zpE5lwrue?: string;
  /**
   * Font Size — pass as `vDkujOasE` not `fontSize`.
   * @default 24
   */
  vDkujOasE?: number;
  onvDkujOasEChange?: string;
  /**
   * Bottom Line Color — pass as `Li3YJ63Dj` not `bottomLineColor`.
   * @default "rgb(0, 0, 0)"
   */
  Li3YJ63Dj?: string;
  /**
   * Icon Color — pass as `C3SRcaKeX` not `iconColor`.
   * @default "rgb(0, 0, 0)"
   */
  C3SRcaKeX?: string;
  /**
   * Icon Width — pass as `CKnnJ09y4` not `iconWidth`.
   * Range: min: 0
   * @default 1.5
   */
  CKnnJ09y4?: number;
  onCKnnJ09y4Change?: string;
  /**
   * Link — pass as `jaIRXGE2t` not `link`.
   */
  jaIRXGE2t?: string;
  /** Additional properties */
  [key: string]: unknown;
}
