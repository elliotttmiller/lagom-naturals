var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/ctsSjSUsPwDF9VtMh6IV/8ds9Rxhq1Q8Lozs7zO9y/vrx1cXOaH.js
import { jsx as _jsx4, jsxs as _jsxs4 } from "react/jsx-runtime";
import { addFonts as addFonts3, addPropertyControls as addPropertyControls4, ComponentViewportProvider, ControlType as ControlType4, cx as cx3, forwardLoader, getFonts, Link as Link1, RichText as RichText3, runTasksWithYield, SmartComponentScopedContainer, useComponentViewport as useComponentViewport3, useLocaleInfo as useLocaleInfo3, useVariantState as useVariantState3, withCSS as withCSS3 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup3, motion as motion3, MotionConfigContext as MotionConfigContext3 } from "framer-motion";
import * as React4 from "react";
import { useRef as useRef4 } from "react";

// http-url:https://framerusercontent.com/modules/NAb0fNaNS96sDzXmtAXU/adQ8mAztkeZwoQ4507BH/FooterCharacter.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from "react";
import { addPropertyControls, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
var BODY_IMAGE_URL = "https://framerusercontent.com/images/P8SGqtkRA7CWBDeDaPn256X17SA.png";
var DEFAULT_EYES = { finish: "graphite", size: 10.5, spacing: 15.5, positionY: 54, shape: 1.1, pupilSize: 56, eyeColor: "#3B3F43" };
var DEFAULT_MOTION = { followPointer: true, gazeRange: 85, smoothness: 72, idleMotion: true, blink: true, blinkOnPress: true, tilt: 1.5, depth: 5, floatAmount: 8 };
var clamp = (n, min, max) => Math.min(max, Math.max(min, n));
function FooterCharacter({ image = { src: BODY_IMAGE_URL }, characterSize = 100, characterY = 0, fit = "floating", eyes: customEyes = DEFAULT_EYES, movement: customMovement = DEFAULT_MOTION, surfaceLight = true, focusColor = "#222625", followLinks = true, gazeArea = "page", style }) {
  const isStatic = useIsStaticRenderer();
  const instanceId = `footer-character-${React.useId().replace(/[^a-zA-Z0-9_-]/g, "")}`;
  const rootRef = React.useRef(null);
  const mascotRef = React.useRef(null);
  const eyeRefs = React.useRef([]);
  const blinkAction = React.useRef(() => {
  });
  const eyes = { ...DEFAULT_EYES, ...customEyes };
  const movement = { ...DEFAULT_MOTION, ...customMovement };
  const eyeSize = clamp(eyes.size, 5, 25);
  const eyeSpacing = Math.max(eyeSize * 0.92, eyes.spacing);
  const eyeHeight = eyeSize / clamp(eyes.shape, 0.7, 1.2);
  const faceWidth = eyeSpacing + eyeSize;
  const pupilSize = clamp(eyes.pupilSize, 25, 75);
  const imageSrc = image?.src || BODY_IMAGE_URL;
  const interactiveEyes = movement.blinkOnPress && !isStatic;
  React.useEffect(() => {
    const stage = rootRef.current;
    const mascot = mascotRef.current;
    if (!stage || !mascot || typeof __dai_window === "undefined")
      return;
    const measure = () => {
      const width = stage.clientWidth;
      const height = stage.clientHeight;
      if (width <= 0 || height <= 0)
        return;
      const size = Math.max(1, Math.min(width * characterSize / 100, height * (fit === "floating" ? 0.94 : 1.64)));
      mascot.style.width = `${size}px`;
      mascot.style.top = `${(fit === "floating" ? (height - size) / 2 : 0) + characterY}px`;
    };
    measure();
    const resize = typeof ResizeObserver !== "undefined" ? new ResizeObserver(measure) : null;
    resize?.observe(stage);
    __dai_window.addEventListener("resize", measure, { passive: true });
    return () => {
      resize?.disconnect();
      __dai_window.removeEventListener("resize", measure);
    };
  }, [characterSize, characterY, fit]);
  React.useEffect(() => {
    if (isStatic || typeof __dai_window === "undefined" || typeof document === "undefined")
      return;
    const root = rootRef.current;
    const mascot = mascotRef.current;
    if (!root || !mascot)
      return;
    const media = __dai_window.matchMedia("(prefers-reduced-motion: reduce)");
    let reduced = media.matches;
    let visible = true;
    let disposed = false;
    let frame = 0;
    let previousTime = 0;
    let localTime = 0;
    let nextBlink = 2600 + Math.random() * 3200;
    let blinkStart = -1e3;
    let doubleBlink = false;
    let secondBlinkAt = -1;
    let manualBlink = false;
    let hoveredElement = null;
    let focusedElement = null;
    let hasPointer = false;
    let pointerX = 0;
    let pointerY = 0;
    let tilt = 0;
    let depthX = 0;
    let depthY = 0;
    let lightX = 50;
    let lightY = 30;
    const positions = [{ x: 0, y: 0 }, { x: 0, y: 0 }];
    const targets = [{ x: 0, y: 0 }, { x: 0, y: 0 }];
    let targetTilt = 0;
    let targetDepthX = 0;
    let targetDepthY = 0;
    let targetLightX = 50;
    let targetLightY = 30;
    let lastPointerAt = 0;
    const nativeFooter = () => root.closest("footer");
    const resolveLink = (target) => {
      if (!followLinks || !movement.followPointer)
        return null;
      const footer = nativeFooter();
      if (!footer)
        return null;
      const element = target instanceof Element ? target : target instanceof Node ? target.parentElement : null;
      const link = element?.closest("a[href], button:not([disabled])");
      return link instanceof HTMLElement && footer.contains(link) && !root.contains(link) ? link : null;
    };
    const allowsPointer = (target) => {
      if (gazeArea === "page")
        return true;
      const scope = nativeFooter() || root;
      return target instanceof Node && scope.contains(target);
    };
    const reset = () => {
      mascot.style.setProperty("--fuzzy-breathe", "0px");
      mascot.style.setProperty("--fuzzy-tilt", "0deg");
      mascot.style.setProperty("--fuzzy-depth-x", "0deg");
      mascot.style.setProperty("--fuzzy-depth-y", "0deg");
      mascot.style.setProperty("--fuzzy-light-x", "50%");
      mascot.style.setProperty("--fuzzy-light-y", "30%");
      root.style.setProperty("--fuzzy-blink", "0");
    };
    const updateTargets = (x, y) => {
      eyeRefs.current.forEach((eye, index) => {
        if (!eye)
          return;
        const rect2 = eye.getBoundingClientRect();
        const dx = x - (rect2.left + rect2.width / 2);
        const dy = y - (rect2.top + rect2.height / 2);
        const length = Math.hypot(dx, dy, Math.max(110, rect2.width * 1.55));
        const travel = eye.clientWidth * (1 - pupilSize / 100) * 0.45 * movement.gazeRange / 100;
        targets[index].x = dx / length * travel;
        targets[index].y = dy / length * travel * 0.92;
      });
      const rect = mascot.getBoundingClientRect();
      const normalizedX = clamp((x - rect.left - rect.width / 2) / Math.max(180, rect.width / 2), -1, 1);
      const normalizedY = clamp((y - rect.top - rect.height / 2) / Math.max(180, rect.height / 2), -1, 1);
      targetTilt = normalizedX * movement.tilt;
      targetDepthX = -normalizedY * clamp(movement.depth, 0, 5);
      targetDepthY = normalizedX * clamp(movement.depth, 0, 5);
      targetLightX = 50 + normalizedX * 22;
      targetLightY = 30 + normalizedY * 16;
    };
    const canRun = () => !disposed && visible && !document.hidden;
    const queueFrame = () => {
      if (!frame && canRun())
        frame = __dai_window.requestAnimationFrame(tick);
    };
    const triggerBlink = () => {
      if (!canRun())
        return;
      manualBlink = true;
      blinkStart = localTime;
      secondBlinkAt = -1;
      nextBlink = localTime + 3500 + Math.random() * 4e3;
      queueFrame();
    };
    const tick = (now) => {
      frame = 0;
      if (!canRun())
        return;
      const delta = previousTime ? Math.min(48, now - previousTime) : 16.67;
      previousTime = now;
      localTime += delta;
      const blend = reduced ? 1 : 1 - Math.exp(-delta / (35 + movement.smoothness * 1.65));
      let settling = false;
      positions.forEach((position, index) => {
        position.x += (targets[index].x - position.x) * blend;
        position.y += (targets[index].y - position.y) * blend;
        const eye = eyeRefs.current[index];
        eye?.style.setProperty("--fuzzy-look-x", `${position.x.toFixed(3)}px`);
        eye?.style.setProperty("--fuzzy-look-y", `${position.y.toFixed(3)}px`);
        settling = settling || Math.abs(targets[index].x - position.x) + Math.abs(targets[index].y - position.y) > 0.025;
      });
      if (!reduced) {
        tilt += (targetTilt - tilt) * blend * 0.55;
        mascot.style.setProperty("--fuzzy-tilt", `${tilt.toFixed(3)}deg`);
        settling = settling || Math.abs(targetTilt - tilt) > 0.01;
        depthX += (targetDepthX - depthX) * blend * 0.65;
        depthY += (targetDepthY - depthY) * blend * 0.65;
        mascot.style.setProperty("--fuzzy-depth-x", `${depthX.toFixed(3)}deg`);
        mascot.style.setProperty("--fuzzy-depth-y", `${depthY.toFixed(3)}deg`);
        settling = settling || Math.abs(targetDepthX - depthX) + Math.abs(targetDepthY - depthY) > 0.015;
        if (surfaceLight) {
          lightX += (targetLightX - lightX) * blend * 0.7;
          lightY += (targetLightY - lightY) * blend * 0.7;
          mascot.style.setProperty("--fuzzy-light-x", `${lightX.toFixed(3)}%`);
          mascot.style.setProperty("--fuzzy-light-y", `${lightY.toFixed(3)}%`);
          settling = settling || Math.abs(targetLightX - lightX) + Math.abs(targetLightY - lightY) > 0.03;
        }
        if (movement.idleMotion) {
          const breath = Math.sin(localTime / 1600) * movement.floatAmount;
          mascot.style.setProperty("--fuzzy-breathe", `${breath.toFixed(3)}px`);
        }
        if (movement.blink && localTime >= nextBlink) {
          blinkStart = localTime;
          doubleBlink = Math.random() < 0.22;
          secondBlinkAt = doubleBlink ? localTime + 290 : -1;
          nextBlink = localTime + 3600 + Math.random() * 4700;
        }
        if (secondBlinkAt >= 0 && localTime >= secondBlinkAt) {
          blinkStart = localTime;
          secondBlinkAt = -1;
        }
      }
      const elapsed = localTime - blinkStart;
      const blinkActive = (!reduced || manualBlink) && elapsed >= 0 && elapsed < 180;
      const closure = blinkActive ? elapsed < 65 ? elapsed / 65 : Math.max(0, 1 - (elapsed - 65) / 115) : 0;
      root.style.setProperty("--fuzzy-blink", closure.toFixed(4));
      if (elapsed >= 180)
        manualBlink = false;
      settling = settling || blinkActive || !reduced && secondBlinkAt >= 0;
      if (settling || !reduced && (movement.idleMotion || movement.blink))
        queueFrame();
    };
    const point = (event) => {
      if (!movement.followPointer || !canRun())
        return;
      if (!allowsPointer(event.target)) {
        hoveredElement = null;
        focusedElement = null;
        center();
        return;
      }
      pointerX = event.clientX;
      pointerY = event.clientY;
      hasPointer = true;
      lastPointerAt = performance.now();
      focusedElement = null;
      const interactiveTarget = resolveLink(event.target);
      if (interactiveTarget)
        hoveredElement = interactiveTarget;
      if (hoveredElement && event.target instanceof Node && hoveredElement.contains(event.target)) {
        const rect = hoveredElement.getBoundingClientRect();
        updateTargets(rect.left + rect.width / 2, rect.top + rect.height / 2);
      } else {
        hoveredElement = null;
        updateTargets(pointerX, pointerY);
      }
      queueFrame();
    };
    const center = () => {
      if (hoveredElement || focusedElement)
        return;
      hasPointer = false;
      targets.forEach((target) => {
        target.x = 0;
        target.y = 0;
      });
      targetTilt = 0;
      targetDepthX = 0;
      targetDepthY = 0;
      targetLightX = 50;
      targetLightY = 30;
      queueFrame();
    };
    const leave = (event) => {
      if (event.pointerType !== "touch")
        center();
    };
    const refresh = () => {
      const target = hoveredElement || focusedElement;
      if (target && resolveLink(target) === target) {
        const rect = target.getBoundingClientRect();
        updateTargets(rect.left + rect.width / 2, rect.top + rect.height / 2);
      } else if (hasPointer && movement.followPointer)
        updateTargets(pointerX, pointerY);
      queueFrame();
    };
    const visibility = () => {
      previousTime = 0;
      if (document.hidden) {
        __dai_window.cancelAnimationFrame(frame);
        frame = 0;
      } else {
        nextBlink = localTime + 1800 + Math.random() * 3e3;
        refresh();
      }
    };
    const preference = () => {
      reduced = media.matches;
      if (reduced)
        reset();
      previousTime = 0;
      queueFrame();
    };
    const gazeAt = (element, mode) => {
      if (!movement.followPointer)
        return;
      if (mode === "hover")
        hoveredElement = element;
      else {
        focusedElement = element;
        hoveredElement = null;
      }
      const rect = element.getBoundingClientRect();
      updateTargets(rect.left + rect.width / 2, rect.top + rect.height / 2);
      queueFrame();
    };
    const release = (element, mode) => {
      if (mode === "hover" && hoveredElement === element)
        hoveredElement = null;
      if (mode === "focus" && focusedElement === element)
        focusedElement = null;
      if (hoveredElement || focusedElement)
        refresh();
      else if (hasPointer && performance.now() - lastPointerAt < 8e3)
        updateTargets(pointerX, pointerY);
      else
        center();
      queueFrame();
    };
    const pointerOver = (event) => {
      const link = resolveLink(event.target);
      if (link)
        gazeAt(link, "hover");
    };
    const pointerOut = (event) => {
      const link = resolveLink(event.target);
      if (link && link !== resolveLink(event.relatedTarget))
        release(link, "hover");
    };
    const focusIn = (event) => {
      const link = resolveLink(event.target);
      if (link)
        gazeAt(link, "focus");
    };
    const focusOut = (event) => {
      const link = resolveLink(event.target);
      if (link && link !== resolveLink(event.relatedTarget))
        release(link, "focus");
    };
    blinkAction.current = triggerBlink;
    const observer = typeof IntersectionObserver !== "undefined" ? new IntersectionObserver((entries) => {
      visible = entries[0]?.isIntersecting ?? true;
      previousTime = 0;
      if (visible)
        refresh();
      else {
        __dai_window.cancelAnimationFrame(frame);
        frame = 0;
      }
    }, { rootMargin: "60px" }) : null;
    observer?.observe(root);
    __dai_window.addEventListener("pointermove", point, { passive: true });
    __dai_window.addEventListener("pointerdown", point, { passive: true });
    __dai_window.addEventListener("blur", center);
    __dai_window.addEventListener("resize", refresh, { passive: true });
    __dai_window.addEventListener("scroll", refresh, { passive: true, capture: true });
    document.documentElement.addEventListener("pointerleave", leave);
    document.addEventListener("visibilitychange", visibility);
    document.addEventListener("pointerover", pointerOver, { passive: true });
    document.addEventListener("pointerout", pointerOut, { passive: true });
    document.addEventListener("focusin", focusIn);
    document.addEventListener("focusout", focusOut);
    media.addEventListener("change", preference);
    queueFrame();
    return () => {
      disposed = true;
      __dai_window.cancelAnimationFrame(frame);
      observer?.disconnect();
      __dai_window.removeEventListener("pointermove", point);
      __dai_window.removeEventListener("pointerdown", point);
      __dai_window.removeEventListener("blur", center);
      __dai_window.removeEventListener("resize", refresh);
      __dai_window.removeEventListener("scroll", refresh, true);
      document.documentElement.removeEventListener("pointerleave", leave);
      document.removeEventListener("visibilitychange", visibility);
      document.removeEventListener("pointerover", pointerOver);
      document.removeEventListener("pointerout", pointerOut);
      document.removeEventListener("focusin", focusIn);
      document.removeEventListener("focusout", focusOut);
      media.removeEventListener("change", preference);
      blinkAction.current = () => {
      };
      reset();
    };
  }, [isStatic, pupilSize, eyeSize, eyeSpacing, eyes.positionY, eyes.shape, characterY, followLinks, gazeArea, surfaceLight, movement.followPointer, movement.gazeRange, movement.smoothness, movement.idleMotion, movement.blink, movement.blinkOnPress, movement.tilt, movement.depth, movement.floatAmount]);
  const FaceTag = interactiveEyes ? "button" : "div";
  const graphite = eyes.finish === "graphite";
  return /* @__PURE__ */ _jsxs("div", { id: instanceId, ref: rootRef, className: "fuzzy-character-stage", style: { ...style, position: "relative", width: "100%", height: "100%", minWidth: 0, boxSizing: "border-box", isolation: "isolate", overflow: "visible", clipPath: "inset(0 -240px 0 -240px)", background: "transparent", pointerEvents: "none", "--fuzzy-eye": eyes.eyeColor, "--fuzzy-focus": focusColor }, children: [/* @__PURE__ */ _jsx("style", { children: `
                footer:has(#${instanceId}):not(:has(footer #${instanceId})) :is(a[href], button):focus-visible:not(footer:has(#${instanceId}):not(:has(footer #${instanceId})) footer *) {
                    outline: 2px solid ${focusColor} !important; outline-offset: 5px !important;
                }
                #${instanceId} .fuzzy-face { outline: none; }
                #${instanceId} .fuzzy-face:focus-visible { outline: 2px solid var(--fuzzy-focus); outline-offset: 6px; }
                #${instanceId} .fuzzy-eye {
                    position: absolute; top: 50%; width: ${eyeSize / faceWidth * 100}%; height: 100%;
                    transform: translate(-50%, -50%); border-radius: 49% 49% 48% 48%;
                    pointer-events: none; filter: drop-shadow(0 5px 4px rgba(0,0,0,.36));
                    clip-path: inset(calc(var(--fuzzy-blink, 0) * 49.95%) 0 round 48%);
                }
                #${instanceId} .fuzzy-sclera {
                    position: absolute; inset: 0; border-radius: inherit; overflow: hidden;
                    background: ${graphite ? "radial-gradient(ellipse at 32% 18%, rgba(255,255,255,.22), rgba(255,255,255,.03) 48%, rgba(0,0,0,.48) 96%)" : "radial-gradient(ellipse at 35% 22%, rgba(255,255,255,.94) 0%, rgba(255,255,255,.15) 43%, rgba(125,149,180,.14) 65%, rgba(47,66,116,.36) 93%)"}, var(--fuzzy-eye);
                    box-shadow: ${graphite ? "inset -3px -5px 9px rgba(0,0,0,.5), inset 1px 2px 3px rgba(255,255,255,.16)" : "inset -4px -8px 13px rgba(31,50,96,.25), inset 3px 3px 6px rgba(255,255,255,.88)"};
                }
                #${instanceId} .fuzzy-pupil {
                    position: absolute; width: ${pupilSize}%; aspect-ratio: 1; left: 50%; top: 49%;
                    border-radius: 50%; transform: translate(calc(-50% + var(--fuzzy-look-x, 0px)), calc(-50% + var(--fuzzy-look-y, 0px)));
                    background: radial-gradient(ellipse at 32% 18%, #243348 0%, #111722 21%, #04060B 52%, #000107 78%);
                    box-shadow: inset 0 0 3px rgba(0,0,0,.95), 0 1px 2px rgba(33,51,74,.35);
                }
                #${instanceId} .fuzzy-pupil::before {
                    content: ""; position: absolute; width: 31%; height: 24%; left: 17%; top: 14%;
                    border-radius: 50%; transform: rotate(-29deg);
                    background: linear-gradient(145deg, rgba(255,255,255,.98), rgba(238,247,255,.47));
                    filter: blur(.5px);
                }
                #${instanceId} .fuzzy-pupil::after {
                    content: ""; position: absolute; width: 9%; height: 9%; right: 21%; bottom: 20%;
                    border-radius: 50%; background: rgba(159,201,255,.42); filter: blur(.7px);
                }
            ` }), /* @__PURE__ */ _jsxs("div", { ref: mascotRef, className: "fuzzy-mascot", style: { position: "absolute", left: "50%", top: fit === "floating" ? "3%" : characterY, width: `min(${characterSize}%, ${fit === "floating" ? "450px" : "700px"})`, aspectRatio: "1", transformOrigin: "50% 50%", transform: "translateX(-50%) translateY(var(--fuzzy-breathe, 0px)) perspective(1000px) rotateX(var(--fuzzy-depth-x, 0deg)) rotateY(var(--fuzzy-depth-y, 0deg)) rotateZ(var(--fuzzy-tilt, 0deg))", userSelect: "none", pointerEvents: "none" }, children: [/* @__PURE__ */ _jsx("img", { src: imageSrc, srcSet: image?.srcSet || (imageSrc === BODY_IMAGE_URL ? `${BODY_IMAGE_URL}?scale-down-to=512 512w, ${BODY_IMAGE_URL} 1254w` : void 0), sizes: "(max-width: 860px) 100vw, 800px", decoding: "async", loading: isStatic ? "eager" : "lazy", alt: "", draggable: false, style: { position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "contain", pointerEvents: "none" } }), surfaceLight && /* @__PURE__ */ _jsx("div", { className: "fuzzy-surface-light", "aria-hidden": "true", style: { position: "absolute", inset: 0, pointerEvents: "none", userSelect: "none", background: "radial-gradient(ellipse at var(--fuzzy-light-x, 50%) var(--fuzzy-light-y, 30%), rgba(255,255,255,.12) 0%, rgba(255,255,255,.035) 36%, rgba(255,255,255,0) 68%)", mixBlendMode: "screen", WebkitMaskImage: `url("${imageSrc}")`, maskImage: `url("${imageSrc}")`, WebkitMaskSize: "contain", maskSize: "contain", WebkitMaskPosition: "center", maskPosition: "center", WebkitMaskRepeat: "no-repeat", maskRepeat: "no-repeat" } }), /* @__PURE__ */ _jsx(FaceTag, { className: "fuzzy-face", ...interactiveEyes ? { type: "button", "aria-label": "Make the character blink", onClick: () => blinkAction.current() } : { "aria-hidden": true }, style: { position: "absolute", left: `${50 - faceWidth / 2}%`, top: `${eyes.positionY - eyeHeight / 2}%`, width: `${faceWidth}%`, height: `${eyeHeight}%`, padding: 0, margin: 0, border: "none", borderRadius: "999px", appearance: "none", background: "transparent", cursor: interactiveEyes ? "pointer" : "default", pointerEvents: interactiveEyes ? "auto" : "none", WebkitTapHighlightColor: "transparent", touchAction: "manipulation" }, children: [0, 1].map((index) => /* @__PURE__ */ _jsx("div", { className: "fuzzy-eye", "aria-hidden": "true", ref: (element) => {
    eyeRefs.current[index] = element;
  }, style: { left: `${(eyeSize / 2 + index * eyeSpacing) / faceWidth * 100}%` }, children: /* @__PURE__ */ _jsx("div", { className: "fuzzy-sclera", children: /* @__PURE__ */ _jsx("div", { className: "fuzzy-pupil" }) }) }, index)) })] })] });
}
addPropertyControls(FooterCharacter, { image: { type: ControlType.ResponsiveImage, title: "Character", description: "Optional transparent square image. Leave empty to use the included character." }, fit: { type: ControlType.Enum, title: "Fit", options: ["floating", "cropped"], optionTitles: ["Floating", "Cropped"], defaultValue: "floating", displaySegmentedControl: true }, characterSize: { type: ControlType.Number, title: "Size", defaultValue: 100, min: 40, max: 180, step: 1, unit: "%", description: "Width within its native stage. Floating keeps the whole silhouette visible." }, characterY: { type: ControlType.Number, title: "Offset Y", defaultValue: 0, min: -160, max: 160, step: 1, unit: "px" }, eyes: { type: ControlType.Object, title: "Eyes", defaultValue: DEFAULT_EYES, controls: { finish: { type: ControlType.Enum, title: "Finish", options: ["graphite", "classic"], optionTitles: ["Graphite", "Classic"], defaultValue: "graphite" }, size: { type: ControlType.Number, title: "Size", defaultValue: 10.5, min: 5, max: 25, step: 0.1, unit: "%" }, spacing: { type: ControlType.Number, title: "Spacing", defaultValue: 15.5, min: 5, max: 40, step: 0.1, unit: "%" }, positionY: { type: ControlType.Number, title: "Position Y", defaultValue: 54, min: 15, max: 70, step: 0.1, unit: "%" }, shape: { type: ControlType.Number, title: "Aspect Ratio", defaultValue: 1.1, min: 0.7, max: 1.2, step: 0.01 }, pupilSize: { type: ControlType.Number, title: "Pupil Size", defaultValue: 56, min: 25, max: 75, step: 1, unit: "%" }, eyeColor: { type: ControlType.Color, title: "Eye Color", defaultValue: "#3B3F43" } } }, movement: { type: ControlType.Object, title: "Motion", defaultValue: DEFAULT_MOTION, controls: { followPointer: { type: ControlType.Boolean, title: "Follow Pointer", defaultValue: true }, gazeRange: { type: ControlType.Number, title: "Gaze Range", defaultValue: 85, min: 0, max: 100, step: 1, unit: "%", hidden: (props) => !props.followPointer }, smoothness: { type: ControlType.Number, title: "Smoothness", defaultValue: 72, min: 0, max: 100, step: 1, unit: "%", hidden: (props) => !props.followPointer }, tilt: { type: ControlType.Number, title: "Body Tilt", defaultValue: 1.5, min: 0, max: 2, step: 0.1, unit: "\xB0", hidden: (props) => !props.followPointer }, depth: { type: ControlType.Number, title: "Depth", defaultValue: 5, min: 0, max: 5, step: 0.1, unit: "\xB0", hidden: (props) => !props.followPointer }, idleMotion: { type: ControlType.Boolean, title: "Float", defaultValue: true }, floatAmount: { type: ControlType.Number, title: "Float Amount", defaultValue: 8, min: 0, max: 12, step: 0.5, unit: "px", hidden: (props) => !props.idleMotion }, blink: { type: ControlType.Boolean, title: "Auto Blink", defaultValue: true }, blinkOnPress: { type: ControlType.Boolean, title: "Blink on Press", defaultValue: true } } }, surfaceLight: { type: ControlType.Boolean, title: "Surface Light", defaultValue: true, description: "A subtle highlight follows the pointer across the character\u2019s silhouette." }, focusColor: { type: ControlType.Color, title: "Focus Color", defaultValue: "#222625", description: "Keyboard focus ring around the eyes and native links in the nearest Footer." }, followLinks: { type: ControlType.Boolean, title: "Follow Links", defaultValue: true, description: "Look at native links and buttons inside the nearest Footer HTML element. Other page links are ignored." }, gazeArea: { type: ControlType.Enum, title: "Gaze Area", options: ["page", "footer"], optionTitles: ["Page", "Footer"], defaultValue: "page", displaySegmentedControl: true, description: "Track the pointer across the page or only within the native Footer. Without a Footer ancestor, Footer mode uses this character\u2019s stage.\n\nBuilt by Matthias \xD6lschlegel \u{1F4AA}\n[Explore more components](https://framer.link/fsd2pgh)" } });

// http-url:https://framerusercontent.com/modules/g9kLfyPPCUmDjwM6tKiB/lMFgBetQJuIavZXobZIN/hJv3Audcp.js
import { jsx as _jsx2, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx, Link, RichText, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef as useRef2 } from "react";
var enabledGestures = { EE9o0Gw0v: { hover: true }, l39us4Glc: { hover: true }, oKg5zJ7Y4: { hover: true } };
var cycleOrder = ["oKg5zJ7Y4", "l39us4Glc", "EE9o0Gw0v"];
var serializationHash = "framer-r0IGG";
var variantClassNames = { EE9o0Gw0v: "framer-v-1qkrogk", l39us4Glc: "framer-v-k7muc4", oKg5zJ7Y4: "framer-v-az0tx7" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { delay: 0, duration: 0.34, ease: [0.22, 0.7, 0.25, 1], type: "tween" };
var transformTemplate1 = (_, t) => `translateY(-50%) ${t}`;
var transition2 = { delay: 0, duration: 0.32, ease: [0.22, 0.7, 0.25, 1], type: "tween" };
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Desktop: "oKg5zJ7Y4", Phone: "EE9o0Gw0v", Tablet: "l39us4Glc" };
var Variants = motion.create(React2.Fragment);
var getProps = ({ accentColor, destination, height, id, label, openInNewTab, textColor, width, ...props }) => {
  return { ...props, ddtPsbqpS: accentColor ?? props.ddtPsbqpS ?? "rgb(20, 95, 234)", lZrHhdMHU: textColor ?? props.lZrHhdMHU ?? "rgb(34, 38, 37)", QeixqNjQo: destination ?? props.QeixqNjQo, tYunU2guM: label ?? props.tYunU2guM ?? "Let\u2019s talk.", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "oKg5zJ7Y4", voXVPzECt: openInNewTab ?? props.voXVPzECt ?? false };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, tYunU2guM, QeixqNjQo, voXVPzECt, lZrHhdMHU, ddtPsbqpS, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "oKg5zJ7Y4", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsx2(Link, { href: QeixqNjQo, motionChild: true, nodeId: "oKg5zJ7Y4", openInNewTab: voXVPzECt, scopeId: "hJv3Audcp", children: /* @__PURE__ */ _jsxs2(motion.a, { ...restProps, ...gestureHandlers, "aria-label": tYunU2guM, className: `${cx(scopingClassNames, "framer-az0tx7", className, classNames)} framer-1vberpg`, "data-framer-name": "Desktop", layoutDependency, layoutId: "vrx1cXOaH__oKg5zJ7Y4", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ "EE9o0Gw0v-hover": { "data-framer-name": void 0 }, "l39us4Glc-hover": { "data-framer-name": void 0 }, "oKg5zJ7Y4-hover": { "data-framer-name": void 0 }, EE9o0Gw0v: { "data-framer-name": "Phone" }, l39us4Glc: { "data-framer-name": "Tablet" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs2(motion.div, { className: "framer-1qqbsd7", "data-framer-name": "Rolling Contact Label", layoutDependency, layoutId: "vrx1cXOaH__v4Snl1wm5", children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "76px", "--framer-font-weight": "500", "--framer-letter-spacing": "-4.6px", "--framer-line-height": "1.06em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-lZrHhdMHU-hJv3Audcp))" }, children: "Label" }) }), className: "framer-d0by7r", "data-framer-name": "Label Measure", fonts: ["Inter-Medium"], layoutDependency, layoutId: "vrx1cXOaH__oKxqoJvlx", style: { "--extracted-r6o4lv": "var(--variable-reference-lZrHhdMHU-hJv3Audcp)", "--variable-reference-lZrHhdMHU-hJv3Audcp": lZrHhdMHU, opacity: 0 }, text: tYunU2guM, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ EE9o0Gw0v: { children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "42px", "--framer-font-weight": "500", "--framer-letter-spacing": "-2.5px", "--framer-line-height": "1.06em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-lZrHhdMHU-hJv3Audcp))" }, children: "Label" }) }) }, l39us4Glc: { children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "64px", "--framer-font-weight": "500", "--framer-letter-spacing": "-3.8px", "--framer-line-height": "1.06em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-lZrHhdMHU-hJv3Audcp))" }, children: "Label" }) }) } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "76px", "--framer-font-weight": "500", "--framer-letter-spacing": "-4.6px", "--framer-line-height": "1.06em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-lZrHhdMHU-hJv3Audcp))" }, children: "Label" }) }), className: "framer-1ow9fbf", "data-framer-name": "Label", fonts: ["Inter-Medium"], layoutDependency, layoutId: "vrx1cXOaH__iQ3P2IsqV", style: { "--extracted-r6o4lv": "var(--variable-reference-lZrHhdMHU-hJv3Audcp)", "--variable-reference-lZrHhdMHU-hJv3Audcp": lZrHhdMHU }, text: tYunU2guM, transformTemplate: transformTemplate1, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ EE9o0Gw0v: { children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "42px", "--framer-font-weight": "500", "--framer-letter-spacing": "-2.5px", "--framer-line-height": "1.06em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-lZrHhdMHU-hJv3Audcp))" }, children: "Let\u2019s talk." }) }) }, l39us4Glc: { children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "64px", "--framer-font-weight": "500", "--framer-letter-spacing": "-3.8px", "--framer-line-height": "1.06em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-lZrHhdMHU-hJv3Audcp))" }, children: "Let\u2019s talk." }) }) } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "76px", "--framer-font-weight": "500", "--framer-letter-spacing": "-4.6px", "--framer-line-height": "1.06em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-lZrHhdMHU-hJv3Audcp))" }, children: "Label" }) }), className: "framer-1vto5os", "data-framer-name": "Hover Label", fonts: ["Inter-Medium"], layoutDependency, layoutId: "vrx1cXOaH__TP7Nf5MuP", style: { "--extracted-r6o4lv": "var(--variable-reference-lZrHhdMHU-hJv3Audcp)", "--variable-reference-lZrHhdMHU-hJv3Audcp": lZrHhdMHU }, text: tYunU2guM, transformTemplate: transformTemplate1, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ EE9o0Gw0v: { children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "42px", "--framer-font-weight": "500", "--framer-letter-spacing": "-2.5px", "--framer-line-height": "1.06em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-lZrHhdMHU-hJv3Audcp))" }, children: "Let\u2019s talk." }) }) }, l39us4Glc: { children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "64px", "--framer-font-weight": "500", "--framer-letter-spacing": "-3.8px", "--framer-line-height": "1.06em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-lZrHhdMHU-hJv3Audcp))" }, children: "Let\u2019s talk." }) }) } }, baseVariant, gestureVariant) })] }), /* @__PURE__ */ _jsx2(motion.div, { className: "framer-1aap35u", "data-border": true, "data-framer-name": "Arrow Circle", layoutDependency, layoutId: "vrx1cXOaH__CL9BkQxRL", style: { "--border-bottom-width": "1px", "--border-color": "rgba(34, 38, 37, 0.22)", "--border-left-width": "1px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "1px", backgroundColor: "rgba(0, 0, 0, 0)", borderBottomLeftRadius: "50%", borderBottomRightRadius: "50%", borderTopLeftRadius: "50%", borderTopRightRadius: "50%", rotate: 0 }, variants: { "EE9o0Gw0v-hover": { "--border-color": "rgb(0, 0, 0)", backgroundColor: ddtPsbqpS, rotate: 5 }, "l39us4Glc-hover": { "--border-color": "rgb(0, 0, 0)", backgroundColor: ddtPsbqpS, rotate: 5 }, "oKg5zJ7Y4-hover": { "--border-color": "rgb(0, 0, 0)", backgroundColor: ddtPsbqpS, rotate: 5 } }, children: /* @__PURE__ */ _jsxs2(motion.div, { className: "framer-5eiqge", "data-framer-name": "Arrow Window", layoutDependency, layoutId: "vrx1cXOaH__s2E3BIHGK", children: [/* @__PURE__ */ _jsx2(Transition, { value: transition2, children: /* @__PURE__ */ _jsxs2(motion.div, { className: "framer-1jgxn2n", "data-framer-name": "Arrow \xB7 Native", layoutDependency, layoutId: "vrx1cXOaH__EdlVPng0z", children: [/* @__PURE__ */ _jsx2(motion.div, { className: "framer-1pj6uyd", "data-framer-name": "Arrow top", layoutDependency, layoutId: "vrx1cXOaH__uEP2d_LTz", style: { backgroundColor: lZrHhdMHU, borderBottomLeftRadius: 999, borderBottomRightRadius: 999, borderTopLeftRadius: 999, borderTopRightRadius: 999 }, variants: { "EE9o0Gw0v-hover": { backgroundColor: "rgb(255, 255, 255)" }, "l39us4Glc-hover": { backgroundColor: "rgb(255, 255, 255)" }, "oKg5zJ7Y4-hover": { backgroundColor: "rgb(255, 255, 255)" } } }), /* @__PURE__ */ _jsx2(motion.div, { className: "framer-17vorp7", "data-framer-name": "Arrow right", layoutDependency, layoutId: "vrx1cXOaH__DQoKHLta4", style: { backgroundColor: lZrHhdMHU, borderBottomLeftRadius: 999, borderBottomRightRadius: 999, borderTopLeftRadius: 999, borderTopRightRadius: 999 }, variants: { "EE9o0Gw0v-hover": { backgroundColor: "rgb(255, 255, 255)" }, "l39us4Glc-hover": { backgroundColor: "rgb(255, 255, 255)" }, "oKg5zJ7Y4-hover": { backgroundColor: "rgb(255, 255, 255)" } } }), /* @__PURE__ */ _jsx2(motion.div, { className: "framer-erqgvo", "data-framer-name": "Arrow shaft", layoutDependency, layoutId: "vrx1cXOaH__RLYdtWVgC", style: { backgroundColor: lZrHhdMHU, borderBottomLeftRadius: 999, borderBottomRightRadius: 999, borderTopLeftRadius: 999, borderTopRightRadius: 999, rotate: -45 }, variants: { "EE9o0Gw0v-hover": { backgroundColor: "rgb(255, 255, 255)" }, "l39us4Glc-hover": { backgroundColor: "rgb(255, 255, 255)" }, "oKg5zJ7Y4-hover": { backgroundColor: "rgb(255, 255, 255)" } } })] }) }), /* @__PURE__ */ _jsx2(Transition, { value: transition2, children: /* @__PURE__ */ _jsxs2(motion.div, { className: "framer-jqavcs", "data-framer-name": "Incoming Arrow \xB7 Native", layoutDependency, layoutId: "vrx1cXOaH__RWuNg9U5C", children: [/* @__PURE__ */ _jsx2(motion.div, { className: "framer-13e9c07", "data-framer-name": "Arrow top", layoutDependency, layoutId: "vrx1cXOaH__iAPVz6An3", style: { backgroundColor: lZrHhdMHU, borderBottomLeftRadius: 999, borderBottomRightRadius: 999, borderTopLeftRadius: 999, borderTopRightRadius: 999 }, variants: { "EE9o0Gw0v-hover": { backgroundColor: "rgb(255, 255, 255)" }, "l39us4Glc-hover": { backgroundColor: "rgb(255, 255, 255)" }, "oKg5zJ7Y4-hover": { backgroundColor: "rgb(255, 255, 255)" } } }), /* @__PURE__ */ _jsx2(motion.div, { className: "framer-q5dayr", "data-framer-name": "Arrow right", layoutDependency, layoutId: "vrx1cXOaH__EHdfesfEq", style: { backgroundColor: lZrHhdMHU, borderBottomLeftRadius: 999, borderBottomRightRadius: 999, borderTopLeftRadius: 999, borderTopRightRadius: 999 }, variants: { "EE9o0Gw0v-hover": { backgroundColor: "rgb(255, 255, 255)" }, "l39us4Glc-hover": { backgroundColor: "rgb(255, 255, 255)" }, "oKg5zJ7Y4-hover": { backgroundColor: "rgb(255, 255, 255)" } } }), /* @__PURE__ */ _jsx2(motion.div, { className: "framer-xv5n3e", "data-framer-name": "Arrow shaft", layoutDependency, layoutId: "vrx1cXOaH__CJtGhSb2D", style: { backgroundColor: lZrHhdMHU, borderBottomLeftRadius: 999, borderBottomRightRadius: 999, borderTopLeftRadius: 999, borderTopRightRadius: 999, rotate: -45 }, variants: { "EE9o0Gw0v-hover": { backgroundColor: "rgb(255, 255, 255)" }, "l39us4Glc-hover": { backgroundColor: "rgb(255, 255, 255)" }, "oKg5zJ7Y4-hover": { backgroundColor: "rgb(255, 255, 255)" } } })] }) })] }) })] }) }) }) }) });
});
var css = [".framer-r0IGG.framer-1vberpg, .framer-r0IGG .framer-1vberpg { display: block; }", ".framer-r0IGG.framer-az0tx7 { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 24px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px 2px 28px 2px; position: relative; text-decoration: none; width: 984px; }", ".framer-r0IGG .framer-1qqbsd7 { align-content: center; align-items: center; display: flex; flex: 1 0 0px; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 4px 0px 4px 0px; pointer-events: none; position: relative; width: 1px; }", ".framer-r0IGG .framer-d0by7r { -webkit-user-select: none; flex: none; height: auto; pointer-events: none; position: relative; user-select: none; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-r0IGG .framer-1ow9fbf { -webkit-user-select: none; flex: none; height: auto; left: 0px; pointer-events: none; position: absolute; top: 50%; user-select: none; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-r0IGG .framer-1vto5os { -webkit-user-select: none; flex: none; height: auto; left: 0px; pointer-events: none; position: absolute; top: 150%; user-select: none; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-r0IGG .framer-1aap35u { -webkit-user-select: none; align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: 76px; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; user-select: none; width: 76px; will-change: var(--framer-will-change-override, transform); }", ".framer-r0IGG .framer-5eiqge { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: 30px; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; pointer-events: none; position: relative; width: 30px; }", ".framer-r0IGG .framer-1jgxn2n { -webkit-user-select: none; flex: none; height: 30px; left: 0px; overflow: visible; pointer-events: none; position: absolute; top: 0px; user-select: none; width: 30px; }", ".framer-r0IGG .framer-1pj6uyd, .framer-r0IGG .framer-13e9c07 { -webkit-user-select: none; flex: none; height: 2px; left: 8px; pointer-events: none; position: absolute; top: 8px; user-select: none; width: 14px; }", ".framer-r0IGG .framer-17vorp7, .framer-r0IGG .framer-q5dayr { -webkit-user-select: none; flex: none; height: 14px; left: 20px; pointer-events: none; position: absolute; top: 8px; user-select: none; width: 2px; }", ".framer-r0IGG .framer-erqgvo, .framer-r0IGG .framer-xv5n3e { -webkit-user-select: none; flex: none; height: 2px; left: 5px; pointer-events: none; position: absolute; top: 14px; user-select: none; width: 19px; }", ".framer-r0IGG .framer-jqavcs { -webkit-user-select: none; flex: none; height: 30px; left: -34px; overflow: visible; pointer-events: none; position: absolute; top: 34px; user-select: none; width: 30px; }", ".framer-r0IGG.framer-v-k7muc4.framer-az0tx7 { width: 666px; }", ".framer-r0IGG.framer-v-1qkrogk.framer-az0tx7 { gap: 16px; padding: 0px 2px 24px 2px; width: 310px; }", ".framer-r0IGG.framer-v-1qkrogk .framer-1aap35u { height: 48px; width: 48px; }", ".framer-r0IGG.framer-v-1qkrogk .framer-5eiqge, .framer-r0IGG.framer-v-1qkrogk .framer-1jgxn2n, .framer-r0IGG.framer-v-1qkrogk .framer-jqavcs { height: 23px; width: 23px; }", ".framer-r0IGG.framer-v-1qkrogk .framer-1pj6uyd, .framer-r0IGG.framer-v-1qkrogk .framer-13e9c07 { height: 1px; left: 6px; top: 6px; width: 11px; }", ".framer-r0IGG.framer-v-1qkrogk .framer-17vorp7, .framer-r0IGG.framer-v-1qkrogk .framer-q5dayr { height: 11px; left: 16px; top: 6px; width: 1px; }", ".framer-r0IGG.framer-v-1qkrogk .framer-erqgvo, .framer-r0IGG.framer-v-1qkrogk .framer-xv5n3e { height: 1px; left: 4px; top: 11px; width: 15px; }", ".framer-r0IGG.framer-v-az0tx7.hover .framer-1ow9fbf, .framer-r0IGG.framer-v-k7muc4.hover .framer-1ow9fbf, .framer-r0IGG.framer-v-1qkrogk.hover .framer-1ow9fbf { top: -50%; }", ".framer-r0IGG.framer-v-az0tx7.hover .framer-1vto5os, .framer-r0IGG.framer-v-k7muc4.hover .framer-1vto5os, .framer-r0IGG.framer-v-1qkrogk.hover .framer-1vto5os { top: 50%; }", ".framer-r0IGG.framer-v-az0tx7.hover .framer-1jgxn2n, .framer-r0IGG.framer-v-k7muc4.hover .framer-1jgxn2n, .framer-r0IGG.framer-v-1qkrogk.hover .framer-1jgxn2n { left: 34px; top: -34px; }", ".framer-r0IGG.framer-v-az0tx7.hover .framer-jqavcs, .framer-r0IGG.framer-v-k7muc4.hover .framer-jqavcs, .framer-r0IGG.framer-v-1qkrogk.hover .framer-jqavcs { left: 0px; top: 0px; }", '.framer-r0IGG[data-border="true"]::after, .framer-r0IGG [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerhJv3Audcp = withCSS(Component, css, "framer-r0IGG");
var hJv3Audcp_default = FramerhJv3Audcp;
FramerhJv3Audcp.displayName = "Contact";
FramerhJv3Audcp.defaultProps = { height: 117, width: 984 };
addPropertyControls2(FramerhJv3Audcp, { variant: { options: ["oKg5zJ7Y4", "l39us4Glc", "EE9o0Gw0v"], optionTitles: ["Desktop", "Tablet", "Phone"], title: "Variant", type: ControlType2.Enum }, tYunU2guM: { defaultValue: "Let\u2019s talk.", title: "Label", type: ControlType2.String }, ontYunU2guMChange: { changes: "tYunU2guM", type: ControlType2.ChangeHandler }, QeixqNjQo: { title: "Destination", type: ControlType2.Link }, voXVPzECt: { defaultValue: false, title: "Open In New Tab", type: ControlType2.Boolean }, onvoXVPzECtChange: { changes: "voXVPzECt", type: ControlType2.ChangeHandler }, lZrHhdMHU: { defaultValue: "rgb(34, 38, 37)", title: "Text Color", type: ControlType2.Color }, ddtPsbqpS: { defaultValue: "rgb(20, 95, 234)", description: "Built by Matthias \xD6lschlegel \u{1F4AA}\n[Explore more components](https://framer.link/fsd2pgh)", title: "Accent Color", type: ControlType2.Color } });
addFonts(FramerhJv3Audcp, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5A3Ce6C9YYmCjpQx9M4inSaKU.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/Qx95Xyt0Ka3SGhinnbXIGpEIyP4.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/6mJuEAguuIuMog10gGvH5d3cl8.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/xYYWaj7wCU5zSQH0eXvSaS19wo.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/otTaNuNpVK4RbdlT7zDDdKvQBA.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/UjlFhCnUjxhNfep4oYBPqnEssyo.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/DolVirEGb34pEXEp8t8FQBSK4.woff2", weight: "500" }] }], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/Zk6UCvUql10u486hJZ2Y/YVgqcpoDghRWGH6ODHtZ/RXzmy3vEP.js
import { jsx as _jsx3, jsxs as _jsxs3 } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx as cx2, Link as Link2, RichText as RichText2, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion2, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React3 from "react";
import { useRef as useRef3 } from "react";
var enabledGestures2 = { L1DXTpgU_: { hover: true }, QYn2ghRct: { hover: true }, W8c6O7kbG: { hover: true } };
var cycleOrder2 = ["L1DXTpgU_", "W8c6O7kbG", "QYn2ghRct"];
var serializationHash2 = "framer-bVnQv";
var variantClassNames2 = { L1DXTpgU_: "framer-v-14kc866", QYn2ghRct: "framer-v-8nkicl", W8c6O7kbG: "framer-v-1kxg6le" };
function addPropertyOverrides2(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition12 = { delay: 0, duration: 0.36, ease: [0.22, 1, 0.36, 1], type: "tween" };
var Transition2 = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext2.Provider, { value: contextValue, children });
};
var humanReadableVariantMap2 = { Legal: "QYn2ghRct", Primary: "L1DXTpgU_", Secondary: "W8c6O7kbG" };
var Variants2 = motion2.create(React3.Fragment);
var getProps2 = ({ accentColor, destination, height, id, label, openInNewTab, textColor, width, ...props }) => {
  return { ...props, AQbRDahX5: label ?? props.AQbRDahX5 ?? "Work", jgnrz798u: textColor ?? props.jgnrz798u ?? "rgb(34, 38, 37)", MHlUBfhKl: openInNewTab ?? props.MHlUBfhKl ?? false, P4VHPLyy_: destination ?? props.P4VHPLyy_, QFTkDPEEO: accentColor ?? props.QFTkDPEEO ?? "rgb(20, 95, 234)", variant: humanReadableVariantMap2[props.variant] ?? props.variant ?? "L1DXTpgU_" };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef3(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className, layoutId, variant, AQbRDahX5, P4VHPLyy_, MHlUBfhKl, jgnrz798u, QFTkDPEEO, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder: cycleOrder2, defaultVariant: "L1DXTpgU_", enabledGestures: enabledGestures2, ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash2, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (gestureVariant === "QYn2ghRct-hover")
      return false;
    if (baseVariant === "QYn2ghRct")
      return false;
    return true;
  };
  return /* @__PURE__ */ _jsx3(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition2, { value: transition12, children: /* @__PURE__ */ _jsx3(Link2, { href: P4VHPLyy_, motionChild: true, nodeId: "L1DXTpgU_", openInNewTab: MHlUBfhKl, scopeId: "RXzmy3vEP", children: /* @__PURE__ */ _jsxs3(motion2.a, { ...restProps, ...gestureHandlers, "aria-label": AQbRDahX5, className: `${cx2(scopingClassNames, "framer-14kc866", className, classNames)} framer-1rwo466`, "data-framer-name": "Primary", layoutDependency, layoutId: "vrx1cXOaH__L1DXTpgU_", ref: refBinding, style: { ...style }, ...addPropertyOverrides2({ "L1DXTpgU_-hover": { "data-framer-name": void 0 }, "QYn2ghRct-hover": { "data-framer-name": void 0 }, "W8c6O7kbG-hover": { "data-framer-name": void 0 }, QYn2ghRct: { "data-framer-name": "Legal" }, W8c6O7kbG: { "data-framer-name": "Secondary" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs3(motion2.div, { className: "framer-1nm3ljg", "data-framer-name": "Rolling Label", layoutDependency, layoutId: "vrx1cXOaH__wf4GpywWQ", children: [/* @__PURE__ */ _jsx3(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "24px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.6px", "--framer-line-height": "32px", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-jgnrz798u-RXzmy3vEP))" }, children: "Work" }) }), className: "framer-1g884m", "data-framer-name": "Label", fonts: ["Inter-Medium"], layoutDependency, layoutId: "vrx1cXOaH__vkg5fPqIp", style: { "--extracted-r6o4lv": "var(--variable-reference-jgnrz798u-RXzmy3vEP)", "--variable-reference-jgnrz798u-RXzmy3vEP": jgnrz798u }, text: AQbRDahX5, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides2({ QYn2ghRct: { children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "12px", "--framer-font-weight": "500", "--framer-letter-spacing": "0px", "--framer-line-height": "22px", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-jgnrz798u-RXzmy3vEP))" }, children: "Work" }) }) }, W8c6O7kbG: { children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-weight": "500", "--framer-letter-spacing": "0px", "--framer-line-height": "24px", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-jgnrz798u-RXzmy3vEP))" }, children: "Work" }) }) } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx3(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "24px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.6px", "--framer-line-height": "32px", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-QFTkDPEEO-RXzmy3vEP))" }, children: "Work" }) }), className: "framer-atthe9", "data-framer-name": "Hover Label", fonts: ["Inter-Medium"], layoutDependency, layoutId: "vrx1cXOaH__NB11y3u1B", style: { "--extracted-r6o4lv": "var(--variable-reference-QFTkDPEEO-RXzmy3vEP)", "--variable-reference-QFTkDPEEO-RXzmy3vEP": QFTkDPEEO }, text: AQbRDahX5, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides2({ QYn2ghRct: { children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "12px", "--framer-font-weight": "500", "--framer-letter-spacing": "0px", "--framer-line-height": "22px", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-QFTkDPEEO-RXzmy3vEP))" }, children: "Work" }) }) }, W8c6O7kbG: { children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-weight": "500", "--framer-letter-spacing": "0px", "--framer-line-height": "24px", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-QFTkDPEEO-RXzmy3vEP))" }, children: "Work" }) }) } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx3(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "24px", "--framer-font-weight": "500", "--framer-letter-spacing": "-0.6px", "--framer-line-height": "32px" }, children: "Work" }) }), className: "framer-d9q4a2", "data-framer-name": "Label Width", fonts: ["Inter-Medium"], layoutDependency, layoutId: "vrx1cXOaH__dTzTtIMGS", style: { opacity: 0 }, text: AQbRDahX5, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides2({ QYn2ghRct: { children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-size": "12px", "--framer-font-weight": "500", "--framer-letter-spacing": "0px", "--framer-line-height": "22px" }, children: "Work" }) }) }, W8c6O7kbG: { children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion2.p, { dir: "auto", style: { "--font-selector": "SW50ZXItTWVkaXVt", "--framer-font-weight": "500", "--framer-letter-spacing": "0px", "--framer-line-height": "24px" }, children: "Work" }) }) } }, baseVariant, gestureVariant) })] }), isDisplayed() && /* @__PURE__ */ _jsxs3(motion2.div, { className: "framer-1bo597v", "data-framer-name": "Arrow \xB7 Native", layoutDependency, layoutId: "vrx1cXOaH__CuFcBPF0l", style: { opacity: 0 }, variants: { "L1DXTpgU_-hover": { opacity: 1 }, "W8c6O7kbG-hover": { opacity: 1 } }, children: [/* @__PURE__ */ _jsx3(motion2.div, { className: "framer-3un4w5", "data-framer-name": "Arrow top", layoutDependency, layoutId: "vrx1cXOaH__GPtzkI4NX", style: { backgroundColor: QFTkDPEEO, borderBottomLeftRadius: 999, borderBottomRightRadius: 999, borderTopLeftRadius: 999, borderTopRightRadius: 999 } }), /* @__PURE__ */ _jsx3(motion2.div, { className: "framer-wa3d6z", "data-framer-name": "Arrow right", layoutDependency, layoutId: "vrx1cXOaH__KGmXtHNb0", style: { backgroundColor: QFTkDPEEO, borderBottomLeftRadius: 999, borderBottomRightRadius: 999, borderTopLeftRadius: 999, borderTopRightRadius: 999 } }), /* @__PURE__ */ _jsx3(motion2.div, { className: "framer-w79rlr", "data-framer-name": "Arrow shaft", layoutDependency, layoutId: "vrx1cXOaH__tyCyHm061", style: { backgroundColor: QFTkDPEEO, borderBottomLeftRadius: 999, borderBottomRightRadius: 999, borderTopLeftRadius: 999, borderTopRightRadius: 999, rotate: -45 } })] })] }) }) }) }) });
});
var css2 = [".framer-bVnQv.framer-1rwo466, .framer-bVnQv .framer-1rwo466 { display: block; }", ".framer-bVnQv.framer-14kc866 { -webkit-user-select: none; align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 8px; height: 48px; justify-content: flex-start; overflow: visible; padding: 0px 2px 0px 2px; position: relative; text-decoration: none; user-select: none; width: min-content; }", ".framer-bVnQv .framer-1nm3ljg { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: 32px; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: min-content; }", ".framer-bVnQv .framer-1g884m { -webkit-user-select: none; flex: none; height: 32px; left: 0px; position: absolute; top: 0px; user-select: none; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-bVnQv .framer-atthe9 { -webkit-user-select: none; flex: none; height: 32px; left: 0px; position: absolute; top: 34px; user-select: none; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-bVnQv .framer-d9q4a2 { -webkit-user-select: none; flex: none; height: 32px; pointer-events: none; position: relative; user-select: none; white-space: pre; width: auto; }", ".framer-bVnQv .framer-1bo597v { -webkit-user-select: none; flex: none; height: 18px; overflow: visible; pointer-events: none; position: relative; user-select: none; width: 18px; }", ".framer-bVnQv .framer-3un4w5 { -webkit-user-select: none; flex: none; height: 1px; left: 5px; pointer-events: none; position: absolute; top: 5px; user-select: none; width: 9px; }", ".framer-bVnQv .framer-wa3d6z { -webkit-user-select: none; flex: none; height: 9px; left: 12px; pointer-events: none; position: absolute; top: 5px; user-select: none; width: 1px; }", ".framer-bVnQv .framer-w79rlr { -webkit-user-select: none; flex: none; height: 1px; left: 3px; pointer-events: none; position: absolute; top: 8px; user-select: none; width: 12px; }", ".framer-bVnQv.framer-v-1kxg6le.framer-14kc866 { height: 42px; }", ".framer-bVnQv.framer-v-1kxg6le .framer-1nm3ljg, .framer-bVnQv.framer-v-1kxg6le .framer-1g884m, .framer-bVnQv.framer-v-1kxg6le .framer-d9q4a2 { height: 24px; }", ".framer-bVnQv.framer-v-1kxg6le .framer-atthe9 { height: 24px; top: 26px; }", ".framer-bVnQv.framer-v-1kxg6le .framer-1bo597v { height: 15px; width: 15px; }", ".framer-bVnQv.framer-v-1kxg6le .framer-3un4w5 { height: 1px; left: 4px; top: 4px; width: 7px; }", ".framer-bVnQv.framer-v-1kxg6le .framer-wa3d6z { height: 7px; left: 10px; top: 4px; width: 1px; }", ".framer-bVnQv.framer-v-1kxg6le .framer-w79rlr { height: 1px; left: 3px; top: 7px; width: 10px; }", ".framer-bVnQv.framer-v-8nkicl.framer-14kc866 { gap: 0px; height: 40px; }", ".framer-bVnQv.framer-v-8nkicl .framer-1nm3ljg, .framer-bVnQv.framer-v-8nkicl .framer-1g884m, .framer-bVnQv.framer-v-8nkicl .framer-d9q4a2 { height: 22px; }", ".framer-bVnQv.framer-v-8nkicl .framer-atthe9 { height: 22px; top: 24px; }", ".framer-bVnQv.framer-v-14kc866.hover.framer-14kc866, .framer-bVnQv.framer-v-1kxg6le.hover.framer-14kc866 { gap: 12px; }", ".framer-bVnQv.framer-v-14kc866.hover .framer-1g884m { top: -34px; }", ".framer-bVnQv.framer-v-14kc866.hover .framer-atthe9, .framer-bVnQv.framer-v-1kxg6le.hover .framer-atthe9, .framer-bVnQv.framer-v-8nkicl.hover .framer-atthe9 { top: 0px; }", ".framer-bVnQv.framer-v-1kxg6le.hover .framer-1g884m { top: -26px; }", ".framer-bVnQv.framer-v-8nkicl.hover .framer-1g884m { top: -24px; }"];
var FramerRXzmy3vEP = withCSS2(Component2, css2, "framer-bVnQv");
var RXzmy3vEP_default = FramerRXzmy3vEP;
FramerRXzmy3vEP.displayName = "Link";
FramerRXzmy3vEP.defaultProps = { height: 48, width: 88 };
addPropertyControls3(FramerRXzmy3vEP, { variant: { options: ["L1DXTpgU_", "W8c6O7kbG", "QYn2ghRct"], optionTitles: ["Primary", "Secondary", "Legal"], title: "Variant", type: ControlType3.Enum }, AQbRDahX5: { defaultValue: "Work", title: "Label", type: ControlType3.String }, onAQbRDahX5Change: { changes: "AQbRDahX5", type: ControlType3.ChangeHandler }, P4VHPLyy_: { title: "Destination", type: ControlType3.Link }, MHlUBfhKl: { defaultValue: false, title: "Open In New Tab", type: ControlType3.Boolean }, onMHlUBfhKlChange: { changes: "MHlUBfhKl", type: ControlType3.ChangeHandler }, jgnrz798u: { defaultValue: "rgb(34, 38, 37)", title: "Text Color", type: ControlType3.Color }, QFTkDPEEO: { defaultValue: "rgb(20, 95, 234)", description: "Built by Matthias \xD6lschlegel \u{1F4AA}\n[Explore more components](https://framer.link/fsd2pgh)", title: "Accent Color", type: ControlType3.Color } });
addFonts2(FramerRXzmy3vEP, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5A3Ce6C9YYmCjpQx9M4inSaKU.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/Qx95Xyt0Ka3SGhinnbXIGpEIyP4.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/6mJuEAguuIuMog10gGvH5d3cl8.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/xYYWaj7wCU5zSQH0eXvSaS19wo.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/otTaNuNpVK4RbdlT7zDDdKvQBA.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/UjlFhCnUjxhNfep4oYBPqnEssyo.woff2", weight: "500" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/DolVirEGb34pEXEp8t8FQBSK4.woff2", weight: "500" }] }], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/ctsSjSUsPwDF9VtMh6IV/8ds9Rxhq1Q8Lozs7zO9y/vrx1cXOaH.js
var ContactFonts = getFonts(hJv3Audcp_default);
var LinkFonts = getFonts(RXzmy3vEP_default);
var FooterCharacterFonts = getFonts(FooterCharacter);
var cycleOrder3 = ["wb3gECfnV", "liGNwVU8M", "Tg8e4tMNu"];
var serializationHash3 = "framer-3Zp8H";
var variantClassNames3 = { liGNwVU8M: "framer-v-kkdkuy", Tg8e4tMNu: "framer-v-u2dyh7", wb3gECfnV: "framer-v-bibvfq" };
function addPropertyOverrides3(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition13 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var matchVariant = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var Transition3 = ({ value, children }) => {
  const config = React4.useContext(MotionConfigContext3);
  const transition = value ?? config.transition;
  const contextValue = React4.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext3.Provider, { value: contextValue, children });
};
var humanReadableVariantMap3 = { Desktop: "wb3gECfnV", Phone: "Tg8e4tMNu", Tablet: "liGNwVU8M" };
var Variants3 = motion3.create(React4.Fragment);
var useStateVariable = (externalState, setExternalState) => {
  const [internalState, setInternalState] = React4.useState(externalState);
  const [previousExternalState, setPreviousExternalState] = React4.useState(externalState);
  if (setExternalState) {
    return [externalState, setExternalState];
  }
  if (externalState !== previousExternalState) {
    setInternalState(externalState);
    setPreviousExternalState(externalState);
  }
  return [internalState, setInternalState];
};
var getProps3 = ({ accentColor, background, contactDestination, contactLabel, contactNewTab, copyright, copyrightLink, copyrightNewTab, explore1Destination, explore1Label, explore1NewTab, explore2Destination, explore2Label, explore2NewTab, explore3Destination, explore3Label, explore3NewTab, explore4Destination, explore4Label, explore4NewTab, exploreLabel, followLabel, height, id, legal1Destination, legal1Label, legal1NewTab, legal2Destination, legal2Label, legal2NewTab, showAtmosphere, showCharacter, showSpotlight, social1Destination, social1Label, social1NewTab, social2Destination, social2Label, social2NewTab, social3Destination, social3Label, social3NewTab, textColor, width, ...props }) => {
  return { ...props, abbxFui6y: legal2NewTab ?? props.abbxFui6y ?? false, aSQJ1nikH: legal1Destination ?? props.aSQJ1nikH, axksOicBS: textColor ?? props.axksOicBS ?? "rgb(34, 38, 37)", bPmfCVkJa: legal1NewTab ?? props.bPmfCVkJa ?? false, byLNhI2KU: contactNewTab ?? props.byLNhI2KU ?? false, e1jHydvVt: explore3Destination ?? props.e1jHydvVt, E7oeSd0DQ: background ?? props.E7oeSd0DQ ?? "rgb(236, 237, 235)", Fa96Ldi7a: explore1Destination ?? props.Fa96Ldi7a, GlXfPXCkO: contactDestination ?? props.GlXfPXCkO, GOWB6uYYA: copyrightNewTab ?? props.GOWB6uYYA ?? false, HCf4Hw9TY: explore2NewTab ?? props.HCf4Hw9TY ?? false, hMxI_GLYo: accentColor ?? props.hMxI_GLYo ?? "rgb(20, 95, 234)", jhpKnf9dQ: social3NewTab ?? props.jhpKnf9dQ ?? false, lhjGosi_A: explore3NewTab ?? props.lhjGosi_A ?? false, ljaR7xZCH: legal2Label ?? props.ljaR7xZCH ?? "Terms", ljswdoYA2: legal1Label ?? props.ljswdoYA2 ?? "Privacy", Ltu9jKcR9: social2Destination ?? props.Ltu9jKcR9, mnuEhVpEM: copyrightLink ?? props.mnuEhVpEM, mo8TleJzZ: explore2Destination ?? props.mo8TleJzZ, MOxKIx5hB: explore2Label ?? props.MOxKIx5hB ?? "Studio", NFhj0r1FH: social2NewTab ?? props.NFhj0r1FH ?? false, O_nLfO1dy: legal2Destination ?? props.O_nLfO1dy, o77r0Oia8: contactLabel ?? props.o77r0Oia8 ?? "Let\u2019s talk.", PfrA_KzF_: explore4Destination ?? props.PfrA_KzF_, Pj3uUQmwM: showSpotlight ?? props.Pj3uUQmwM ?? true, PNLbophQR: showAtmosphere ?? props.PNLbophQR ?? true, qZXA9i_dF: social3Label ?? props.qZXA9i_dF ?? "Dribbble", r6wyRWURn: explore4NewTab ?? props.r6wyRWURn ?? false, Ri426N47U: social1Destination ?? props.Ri426N47U, rUXNFyUY3: showCharacter ?? props.rUXNFyUY3 ?? true, sj_4Za9pQ: social2Label ?? props.sj_4Za9pQ ?? "LinkedIn", SKVOJot62: social1NewTab ?? props.SKVOJot62 ?? false, T1PQmWGyS: explore3Label ?? props.T1PQmWGyS ?? "Services", tfB4bfcS3: explore1NewTab ?? props.tfB4bfcS3 ?? false, u_nblm_JG: explore4Label ?? props.u_nblm_JG ?? "Journal", variant: humanReadableVariantMap3[props.variant] ?? props.variant ?? "wb3gECfnV", VTGMY6Vcr: social3Destination ?? props.VTGMY6Vcr, xupq9c7vx: exploreLabel ?? props.xupq9c7vx ?? "Explore", XWC7a0Bi4: copyright ?? props.XWC7a0Bi4 ?? "\xA9 2026", xWfihUARj: social1Label ?? props.xWfihUARj ?? "Instagram", ye7rOqe5h: explore1Label ?? props.ye7rOqe5h ?? "Work", zJduH6lMs: followLabel ?? props.zJduH6lMs ?? "Follow" };
};
var createLayoutDependency3 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React4.forwardRef(function(props, ref) {
  const fallbackRef = useRef4(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React4.useId();
  const { activeLocale, setLocale } = useLocaleInfo3();
  const componentViewport = useComponentViewport3();
  const { style, className, layoutId, variant, "o77r0Oia8": externalo77r0Oia8, "ono77r0Oia8Change": setExternalo77r0Oia8, "byLNhI2KU": externalbyLNhI2KU, "onbyLNhI2KUChange": setExternalbyLNhI2KU, xupq9c7vx, zJduH6lMs, XWC7a0Bi4, mnuEhVpEM, GOWB6uYYA, E7oeSd0DQ, axksOicBS, hMxI_GLYo, PNLbophQR, rUXNFyUY3, GlXfPXCkO, "ye7rOqe5h": externalye7rOqe5h, "onye7rOqe5hChange": setExternalye7rOqe5h, Fa96Ldi7a, "tfB4bfcS3": externaltfB4bfcS3, "ontfB4bfcS3Change": setExternaltfB4bfcS3, "MOxKIx5hB": externalMOxKIx5hB, "onMOxKIx5hBChange": setExternalMOxKIx5hB, mo8TleJzZ, "HCf4Hw9TY": externalHCf4Hw9TY, "onHCf4Hw9TYChange": setExternalHCf4Hw9TY, "T1PQmWGyS": externalT1PQmWGyS, "onT1PQmWGySChange": setExternalT1PQmWGyS, e1jHydvVt, "lhjGosi_A": externallhjGosi_A, "onlhjGosi_AChange": setExternallhjGosi_A, "u_nblm_JG": externalu_nblm_JG, "onu_nblm_JGChange": setExternalu_nblm_JG, PfrA_KzF_, "r6wyRWURn": externalr6wyRWURn, "onr6wyRWURnChange": setExternalr6wyRWURn, "xWfihUARj": externalxWfihUARj, "onxWfihUARjChange": setExternalxWfihUARj, Ri426N47U, "SKVOJot62": externalSKVOJot62, "onSKVOJot62Change": setExternalSKVOJot62, "sj_4Za9pQ": externalsj_4Za9pQ, "onsj_4Za9pQChange": setExternalsj_4Za9pQ, Ltu9jKcR9, "NFhj0r1FH": externalNFhj0r1FH, "onNFhj0r1FHChange": setExternalNFhj0r1FH, "qZXA9i_dF": externalqZXA9i_dF, "onqZXA9i_dFChange": setExternalqZXA9i_dF, VTGMY6Vcr, "jhpKnf9dQ": externaljhpKnf9dQ, "onjhpKnf9dQChange": setExternaljhpKnf9dQ, "ljswdoYA2": externalljswdoYA2, "onljswdoYA2Change": setExternalljswdoYA2, aSQJ1nikH, "bPmfCVkJa": externalbPmfCVkJa, "onbPmfCVkJaChange": setExternalbPmfCVkJa, "ljaR7xZCH": externalljaR7xZCH, "onljaR7xZCHChange": setExternalljaR7xZCH, O_nLfO1dy, "abbxFui6y": externalabbxFui6y, "onabbxFui6yChange": setExternalabbxFui6y, Pj3uUQmwM, ...restProps } = getProps3(props);
  const [o77r0Oia8, seto77r0Oia8] = useStateVariable(externalo77r0Oia8, setExternalo77r0Oia8);
  const [byLNhI2KU, setbyLNhI2KU] = useStateVariable(externalbyLNhI2KU, setExternalbyLNhI2KU);
  const [ye7rOqe5h, setye7rOqe5h] = useStateVariable(externalye7rOqe5h, setExternalye7rOqe5h);
  const [tfB4bfcS3, settfB4bfcS3] = useStateVariable(externaltfB4bfcS3, setExternaltfB4bfcS3);
  const [MOxKIx5hB, setMOxKIx5hB] = useStateVariable(externalMOxKIx5hB, setExternalMOxKIx5hB);
  const [HCf4Hw9TY, setHCf4Hw9TY] = useStateVariable(externalHCf4Hw9TY, setExternalHCf4Hw9TY);
  const [T1PQmWGyS, setT1PQmWGyS] = useStateVariable(externalT1PQmWGyS, setExternalT1PQmWGyS);
  const [lhjGosi_A, setlhjGosi_A] = useStateVariable(externallhjGosi_A, setExternallhjGosi_A);
  const [u_nblm_JG, setu_nblm_JG] = useStateVariable(externalu_nblm_JG, setExternalu_nblm_JG);
  const [r6wyRWURn, setr6wyRWURn] = useStateVariable(externalr6wyRWURn, setExternalr6wyRWURn);
  const [xWfihUARj, setxWfihUARj] = useStateVariable(externalxWfihUARj, setExternalxWfihUARj);
  const [SKVOJot62, setSKVOJot62] = useStateVariable(externalSKVOJot62, setExternalSKVOJot62);
  const [sj_4Za9pQ, setsj_4Za9pQ] = useStateVariable(externalsj_4Za9pQ, setExternalsj_4Za9pQ);
  const [NFhj0r1FH, setNFhj0r1FH] = useStateVariable(externalNFhj0r1FH, setExternalNFhj0r1FH);
  const [qZXA9i_dF, setqZXA9i_dF] = useStateVariable(externalqZXA9i_dF, setExternalqZXA9i_dF);
  const [jhpKnf9dQ, setjhpKnf9dQ] = useStateVariable(externaljhpKnf9dQ, setExternaljhpKnf9dQ);
  const [ljswdoYA2, setljswdoYA2] = useStateVariable(externalljswdoYA2, setExternalljswdoYA2);
  const [bPmfCVkJa, setbPmfCVkJa] = useStateVariable(externalbPmfCVkJa, setExternalbPmfCVkJa);
  const [ljaR7xZCH, setljaR7xZCH] = useStateVariable(externalljaR7xZCH, setExternalljaR7xZCH);
  const [abbxFui6y, setabbxFui6y] = useStateVariable(externalabbxFui6y, setExternalabbxFui6y);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState3({ cycleOrder: cycleOrder3, defaultVariant: "wb3gECfnV", ref: refBinding, variant, variantClassNames: variantClassNames3 });
  const layoutDependency = createLayoutDependency3(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx3(serializationHash3, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx4(LayoutGroup3, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants3, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition3, { value: transition13, children: /* @__PURE__ */ _jsxs4(motion3.footer, { ...restProps, ...gestureHandlers, className: cx3(scopingClassNames, "framer-bibvfq", className, classNames), "data-framer-name": "Desktop", layoutDependency, layoutId: "vrx1cXOaH__wb3gECfnV", ref: refBinding, style: { backgroundColor: E7oeSd0DQ, borderBottomLeftRadius: 28, borderBottomRightRadius: 28, borderTopLeftRadius: 28, borderTopRightRadius: 28, ...style }, variants: { Tg8e4tMNu: { borderBottomLeftRadius: 24, borderBottomRightRadius: 24, borderTopLeftRadius: 24, borderTopRightRadius: 24 } }, ...addPropertyOverrides3({ liGNwVU8M: { "data-framer-name": "Tablet" }, Tg8e4tMNu: { "data-framer-name": "Phone" } }, baseVariant, gestureVariant), children: [PNLbophQR !== false && /* @__PURE__ */ _jsx4(motion3.div, { className: "framer-1ywgrki", "data-framer-name": "Silver Atmosphere", layoutDependency, layoutId: "vrx1cXOaH__ve8fxPC6g", style: { background: "linear-gradient(145deg, rgb(250, 250, 247) 0%, rgb(232, 238, 237) 46%, rgb(199, 216, 229) 100%)" } }), Pj3uUQmwM !== false && /* @__PURE__ */ _jsx4(motion3.div, { className: "framer-5wbqs8", "data-framer-name": "Sculpture Spotlight", layoutDependency, layoutId: "vrx1cXOaH__AXFUqp31A", style: { background: "radial-gradient(50% 50% at 50% 50%, rgba(255, 255, 255, 0.96) 0%, rgba(190, 217, 239, 0.74) 30%, rgba(171, 207, 232, 0.24) 52%, rgba(205, 222, 229, 0) 74%)", borderBottomLeftRadius: "50%", borderBottomRightRadius: "50%", borderTopLeftRadius: "50%", borderTopRightRadius: "50%" } }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 834, width: `calc(${componentViewport?.width || "100vw"} - 96px)`, y: (componentViewport?.y || 0) + 48 + 0, ...addPropertyOverrides3({ liGNwVU8M: { width: `calc(${componentViewport?.width || "100vw"} - 64px)`, y: (componentViewport?.y || 0) + 36 + 0 }, Tg8e4tMNu: { width: `calc(${componentViewport?.width || "100vw"} - 48px)`, y: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1f5nqex-container", "data-framer-name": "Contact", layoutDependency, layoutId: "vrx1cXOaH__jAwSpZULt-container", name: "Contact", nodeId: "jAwSpZULt", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(hJv3Audcp_default, { ddtPsbqpS: hMxI_GLYo, height: "100%", id: "jAwSpZULt", layoutId: "vrx1cXOaH__jAwSpZULt", lZrHhdMHU: axksOicBS, name: "Contact", ontYunU2guMChange: seto77r0Oia8, onvoXVPzECtChange: setbyLNhI2KU, QeixqNjQo: GlXfPXCkO, style: { width: "100%" }, tYunU2guM: o77r0Oia8, variant: matchVariant("oKg5zJ7Y4"), voXVPzECt: byLNhI2KU, width: "100%", ...addPropertyOverrides3({ liGNwVU8M: { variant: matchVariant("l39us4Glc") }, Tg8e4tMNu: { variant: matchVariant("EE9o0Gw0v") } }, baseVariant, gestureVariant) }) }) }), /* @__PURE__ */ _jsx4(motion3.div, { className: "framer-1absmqj", "data-framer-name": "Top Divider", layoutDependency, layoutId: "vrx1cXOaH__R2Jm2leDL", style: { backgroundColor: "rgba(46, 60, 63, 0.18)" } }), /* @__PURE__ */ _jsxs4(motion3.div, { className: "framer-1lcio3c", "data-framer-name": "Directory and Character", layoutDependency, layoutId: "vrx1cXOaH__d7DfeFx8U", children: [/* @__PURE__ */ _jsxs4(motion3.div, { className: "framer-15vb1cr", "data-framer-name": "Link Columns", layoutDependency, layoutId: "vrx1cXOaH__CIiQRyrVI", children: [/* @__PURE__ */ _jsxs4(motion3.div, { className: "framer-dbl12e", "data-framer-name": "Explore", layoutDependency, layoutId: "vrx1cXOaH__OfTvd2JL4", children: [/* @__PURE__ */ _jsx4(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React4.Fragment, { children: /* @__PURE__ */ _jsx4(motion3.p, { dir: "auto", style: { "--framer-font-size": "11px", "--framer-letter-spacing": "0.3px", "--framer-line-height": "16px", "--framer-text-color": "var(--extracted-r6o4lv, rgb(89, 100, 102))" }, children: "Explore Label" }) }), className: "framer-laors5", "data-framer-name": "Column Label", fonts: ["Inter"], layoutDependency, layoutId: "vrx1cXOaH__Cl2vp6V3X", style: { "--extracted-r6o4lv": "rgb(89, 100, 102)" }, text: xupq9c7vx, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx4(motion3.div, { className: "framer-1qtt3tl", "data-framer-name": "Label Spacing", layoutDependency, layoutId: "vrx1cXOaH__ezMfQWKoc" }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 48, width: "188px", y: (componentViewport?.y || 0) + 48 + 835 + 32 + 0 + 0 + 0 + 94, ...addPropertyOverrides3({ liGNwVU8M: { width: "152px", y: (componentViewport?.y || 0) + 36 + 835 + 28 + 0 + 0 + 0 + 94 }, Tg8e4tMNu: { width: `max((${componentViewport?.width || "100vw"} - 66px) / 2, 1px)`, y: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1mogc4c-container", "data-framer-name": "Work", layoutDependency, layoutId: "vrx1cXOaH__dxKu6teWN-container", name: "Work", nodeId: "dxKu6teWN", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(RXzmy3vEP_default, { AQbRDahX5: ye7rOqe5h, height: "100%", id: "dxKu6teWN", jgnrz798u: axksOicBS, layoutId: "vrx1cXOaH__dxKu6teWN", MHlUBfhKl: tfB4bfcS3, name: "Work", onAQbRDahX5Change: setye7rOqe5h, onMHlUBfhKlChange: settfB4bfcS3, P4VHPLyy_: Fa96Ldi7a, QFTkDPEEO: hMxI_GLYo, style: { width: "100%" }, variant: matchVariant("L1DXTpgU_"), width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 48, width: "188px", y: (componentViewport?.y || 0) + 48 + 835 + 32 + 0 + 0 + 0 + 142, ...addPropertyOverrides3({ liGNwVU8M: { width: "152px", y: (componentViewport?.y || 0) + 36 + 835 + 28 + 0 + 0 + 0 + 142 }, Tg8e4tMNu: { width: `max((${componentViewport?.width || "100vw"} - 66px) / 2, 1px)`, y: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1i7bo1o-container", "data-framer-name": "Studio", layoutDependency, layoutId: "vrx1cXOaH__dOAl3x0jp-container", name: "Studio", nodeId: "dOAl3x0jp", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(RXzmy3vEP_default, { AQbRDahX5: MOxKIx5hB, height: "100%", id: "dOAl3x0jp", jgnrz798u: axksOicBS, layoutId: "vrx1cXOaH__dOAl3x0jp", MHlUBfhKl: HCf4Hw9TY, name: "Studio", onAQbRDahX5Change: setMOxKIx5hB, onMHlUBfhKlChange: setHCf4Hw9TY, P4VHPLyy_: mo8TleJzZ, QFTkDPEEO: hMxI_GLYo, style: { width: "100%" }, variant: matchVariant("L1DXTpgU_"), width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 48, width: "188px", y: (componentViewport?.y || 0) + 48 + 835 + 32 + 0 + 0 + 0 + 190, ...addPropertyOverrides3({ liGNwVU8M: { width: "152px", y: (componentViewport?.y || 0) + 36 + 835 + 28 + 0 + 0 + 0 + 190 }, Tg8e4tMNu: { width: `max((${componentViewport?.width || "100vw"} - 66px) / 2, 1px)`, y: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1qx02x8-container", "data-framer-name": "Services", layoutDependency, layoutId: "vrx1cXOaH__Y06tAaTYC-container", name: "Services", nodeId: "Y06tAaTYC", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(RXzmy3vEP_default, { AQbRDahX5: T1PQmWGyS, height: "100%", id: "Y06tAaTYC", jgnrz798u: axksOicBS, layoutId: "vrx1cXOaH__Y06tAaTYC", MHlUBfhKl: lhjGosi_A, name: "Services", onAQbRDahX5Change: setT1PQmWGyS, onMHlUBfhKlChange: setlhjGosi_A, P4VHPLyy_: e1jHydvVt, QFTkDPEEO: hMxI_GLYo, style: { width: "100%" }, variant: matchVariant("L1DXTpgU_"), width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 48, width: "188px", y: (componentViewport?.y || 0) + 48 + 835 + 32 + 0 + 0 + 0 + 238, ...addPropertyOverrides3({ liGNwVU8M: { width: "152px", y: (componentViewport?.y || 0) + 36 + 835 + 28 + 0 + 0 + 0 + 238 }, Tg8e4tMNu: { width: `max((${componentViewport?.width || "100vw"} - 66px) / 2, 1px)`, y: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1rkhiae-container", "data-framer-name": "Journal", layoutDependency, layoutId: "vrx1cXOaH__nPFDI_BhZ-container", name: "Journal", nodeId: "nPFDI_BhZ", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(RXzmy3vEP_default, { AQbRDahX5: u_nblm_JG, height: "100%", id: "nPFDI_BhZ", jgnrz798u: axksOicBS, layoutId: "vrx1cXOaH__nPFDI_BhZ", MHlUBfhKl: r6wyRWURn, name: "Journal", onAQbRDahX5Change: setu_nblm_JG, onMHlUBfhKlChange: setr6wyRWURn, P4VHPLyy_: PfrA_KzF_, QFTkDPEEO: hMxI_GLYo, style: { width: "100%" }, variant: matchVariant("L1DXTpgU_"), width: "100%" }) }) })] }), /* @__PURE__ */ _jsxs4(motion3.div, { className: "framer-veretm", "data-framer-name": "Follow", layoutDependency, layoutId: "vrx1cXOaH__fVfY489iD", children: [/* @__PURE__ */ _jsx4(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React4.Fragment, { children: /* @__PURE__ */ _jsx4(motion3.p, { dir: "auto", style: { "--framer-font-size": "11px", "--framer-letter-spacing": "0.3px", "--framer-line-height": "16px", "--framer-text-color": "var(--extracted-r6o4lv, rgb(89, 100, 102))" }, children: "Follow Label" }) }), className: "framer-twyjyl", "data-framer-name": "Column Label", fonts: ["Inter"], layoutDependency, layoutId: "vrx1cXOaH__a7mwavv1P", style: { "--extracted-r6o4lv": "rgb(89, 100, 102)" }, text: zJduH6lMs, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx4(motion3.div, { className: "framer-1alvgwg", "data-framer-name": "Label Spacing", layoutDependency, layoutId: "vrx1cXOaH__x3ViTBCtz" }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 48, width: "100px", y: (componentViewport?.y || 0) + 48 + 835 + 32 + 0 + 0 + 0 + 94, ...addPropertyOverrides3({ liGNwVU8M: { width: "142px", y: (componentViewport?.y || 0) + 36 + 835 + 28 + 0 + 0 + 0 + 94 }, Tg8e4tMNu: { width: `max((${componentViewport?.width || "100vw"} - 66px) / 2, 1px)`, y: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-10iciru-container", "data-framer-name": "Instagram", layoutDependency, layoutId: "vrx1cXOaH__SYYF5T8Dj-container", name: "Instagram", nodeId: "SYYF5T8Dj", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(RXzmy3vEP_default, { AQbRDahX5: xWfihUARj, height: "100%", id: "SYYF5T8Dj", jgnrz798u: axksOicBS, layoutId: "vrx1cXOaH__SYYF5T8Dj", MHlUBfhKl: SKVOJot62, name: "Instagram", onAQbRDahX5Change: setxWfihUARj, onMHlUBfhKlChange: setSKVOJot62, P4VHPLyy_: Ri426N47U, QFTkDPEEO: hMxI_GLYo, style: { width: "100%" }, variant: matchVariant("W8c6O7kbG"), width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 48, width: "100px", y: (componentViewport?.y || 0) + 48 + 835 + 32 + 0 + 0 + 0 + 142, ...addPropertyOverrides3({ liGNwVU8M: { width: "142px", y: (componentViewport?.y || 0) + 36 + 835 + 28 + 0 + 0 + 0 + 142 }, Tg8e4tMNu: { width: `max((${componentViewport?.width || "100vw"} - 66px) / 2, 1px)`, y: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1q4tgax-container", "data-framer-name": "LinkedIn", layoutDependency, layoutId: "vrx1cXOaH__Cn2_eN2iK-container", name: "LinkedIn", nodeId: "Cn2_eN2iK", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(RXzmy3vEP_default, { AQbRDahX5: sj_4Za9pQ, height: "100%", id: "Cn2_eN2iK", jgnrz798u: axksOicBS, layoutId: "vrx1cXOaH__Cn2_eN2iK", MHlUBfhKl: NFhj0r1FH, name: "LinkedIn", onAQbRDahX5Change: setsj_4Za9pQ, onMHlUBfhKlChange: setNFhj0r1FH, P4VHPLyy_: Ltu9jKcR9, QFTkDPEEO: hMxI_GLYo, style: { width: "100%" }, variant: matchVariant("W8c6O7kbG"), width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 48, width: "100px", y: (componentViewport?.y || 0) + 48 + 835 + 32 + 0 + 0 + 0 + 190, ...addPropertyOverrides3({ liGNwVU8M: { width: "142px", y: (componentViewport?.y || 0) + 36 + 835 + 28 + 0 + 0 + 0 + 190 }, Tg8e4tMNu: { width: `max((${componentViewport?.width || "100vw"} - 66px) / 2, 1px)`, y: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-jiv7su-container", "data-framer-name": "Dribbble", layoutDependency, layoutId: "vrx1cXOaH__TEn9voYhZ-container", name: "Dribbble", nodeId: "TEn9voYhZ", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(RXzmy3vEP_default, { AQbRDahX5: qZXA9i_dF, height: "100%", id: "TEn9voYhZ", jgnrz798u: axksOicBS, layoutId: "vrx1cXOaH__TEn9voYhZ", MHlUBfhKl: jhpKnf9dQ, name: "Dribbble", onAQbRDahX5Change: setqZXA9i_dF, onMHlUBfhKlChange: setjhpKnf9dQ, P4VHPLyy_: VTGMY6Vcr, QFTkDPEEO: hMxI_GLYo, style: { width: "100%" }, variant: matchVariant("W8c6O7kbG"), width: "100%" }) }) })] })] }), rUXNFyUY3 !== false && /* @__PURE__ */ _jsx4(motion3.div, { className: "framer-8ruma7", "data-framer-name": "Levitation Shadow", layoutDependency, layoutId: "vrx1cXOaH__BaITs3F3s", style: { background: "radial-gradient(50% 50% at 50% 50%, rgba(31, 59, 86, 0.3) 0%, rgba(44, 74, 99, 0.13) 30%, rgba(51, 78, 101, 0) 72%)", borderBottomLeftRadius: "50%", borderBottomRightRadius: "50%", borderTopLeftRadius: "50%", borderTopRightRadius: "50%", filter: "blur(12px)", WebkitFilter: "blur(12px)" } }), rUXNFyUY3 !== false && /* @__PURE__ */ _jsx4(motion3.div, { className: "framer-1y7y2hn", "data-framer-name": "Character Stage", layoutDependency, layoutId: "vrx1cXOaH__vvXuIOPe4", children: /* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1ju5416-container", "data-code-component-plugin-id": "api", "data-framer-name": "Floating Character", isAuthoredByUser: true, layoutDependency, layoutId: "vrx1cXOaH__muWNbmTVM-container", name: "Floating Character", nodeId: "muWNbmTVM", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(FooterCharacter, { characterSize: 100, characterY: 0, eyes: { eyeColor: "rgb(59, 63, 67)", finish: "graphite", positionY: 54, pupilSize: 56, shape: 1.1, size: 10.5, spacing: 15.5 }, fit: "floating", focusColor: "rgb(34, 38, 37)", followLinks: true, gazeArea: "page", height: "100%", id: "muWNbmTVM", layoutId: "vrx1cXOaH__muWNbmTVM", movement: { blink: true, blinkOnPress: true, depth: 5, floatAmount: 8, followPointer: true, gazeRange: 85, idleMotion: true, smoothness: 72, tilt: 1.5 }, name: "Floating Character", style: { height: "100%", width: "100%" }, surfaceLight: true, width: "100%" }) }) }) })] }), /* @__PURE__ */ _jsx4(motion3.div, { className: "framer-12bvwzf", "data-framer-name": "Bottom Divider", layoutDependency, layoutId: "vrx1cXOaH__S_q0VSrm6", style: { backgroundColor: "rgba(46, 60, 63, 0.18)" } }), /* @__PURE__ */ _jsxs4(motion3.div, { className: "framer-fczprw", "data-framer-name": "Legal", layoutDependency, layoutId: "vrx1cXOaH__JX9DzKmDQ", children: [/* @__PURE__ */ _jsx4(Link1, { href: mnuEhVpEM, motionChild: true, nodeId: "zOY7UQuLI", openInNewTab: GOWB6uYYA, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(motion3.a, { className: "framer-1m3cmn4 framer-ir8ile", "data-framer-name": "Copyright", layoutDependency, layoutId: "vrx1cXOaH__zOY7UQuLI", children: /* @__PURE__ */ _jsx4(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React4.Fragment, { children: /* @__PURE__ */ _jsx4(motion3.p, { dir: "auto", style: { "--framer-font-size": "12px", "--framer-line-height": "18px", "--framer-text-color": "var(--extracted-r6o4lv, rgb(89, 100, 102))" }, children: "Copyright" }) }), className: "framer-od66kp", "data-framer-name": "Copyright", fonts: ["Inter"], layoutDependency, layoutId: "vrx1cXOaH__LPOcPvizm", style: { "--extracted-r6o4lv": "rgb(89, 100, 102)" }, text: XWC7a0Bi4, verticalAlignment: "top", withExternalLayout: true }) }) }), /* @__PURE__ */ _jsxs4(motion3.div, { className: "framer-ktqr6v", "data-framer-name": "Legal Links", layoutDependency, layoutId: "vrx1cXOaH__gEeBT1ReS", children: [/* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 48, y: (componentViewport?.y || 0) + 48 + 1356 + 14 + 0, ...addPropertyOverrides3({ liGNwVU8M: { y: (componentViewport?.y || 0) + 36 + 1286 + 14 + 0 }, Tg8e4tMNu: { y: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-yag8gw-container", "data-framer-name": "Privacy", layoutDependency, layoutId: "vrx1cXOaH__kCZqaPhL7-container", name: "Privacy", nodeId: "kCZqaPhL7", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(RXzmy3vEP_default, { AQbRDahX5: ljswdoYA2, height: "100%", id: "kCZqaPhL7", jgnrz798u: axksOicBS, layoutId: "vrx1cXOaH__kCZqaPhL7", MHlUBfhKl: bPmfCVkJa, name: "Privacy", onAQbRDahX5Change: setljswdoYA2, onMHlUBfhKlChange: setbPmfCVkJa, P4VHPLyy_: aSQJ1nikH, QFTkDPEEO: hMxI_GLYo, variant: matchVariant("QYn2ghRct"), width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { height: 48, y: (componentViewport?.y || 0) + 48 + 1356 + 14 + 0, ...addPropertyOverrides3({ liGNwVU8M: { y: (componentViewport?.y || 0) + 36 + 1286 + 14 + 0 }, Tg8e4tMNu: { y: void 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1cv86qe-container", "data-framer-name": "Terms", layoutDependency, layoutId: "vrx1cXOaH__s9Zyqmcwz-container", name: "Terms", nodeId: "s9Zyqmcwz", rendersWithMotion: true, scopeId: "vrx1cXOaH", children: /* @__PURE__ */ _jsx4(RXzmy3vEP_default, { AQbRDahX5: ljaR7xZCH, height: "100%", id: "s9Zyqmcwz", jgnrz798u: axksOicBS, layoutId: "vrx1cXOaH__s9Zyqmcwz", MHlUBfhKl: abbxFui6y, name: "Terms", onAQbRDahX5Change: setljaR7xZCH, onMHlUBfhKlChange: setabbxFui6y, P4VHPLyy_: O_nLfO1dy, QFTkDPEEO: hMxI_GLYo, variant: matchVariant("QYn2ghRct"), width: "100%" }) }) })] })] })] }) }) }) });
});
var css3 = [".framer-3Zp8H.framer-ir8ile, .framer-3Zp8H .framer-ir8ile { display: block; }", ".framer-3Zp8H.framer-bibvfq { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 48px 48px 18px 48px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-3Zp8H .framer-1ywgrki { flex: none; height: 100%; left: 0px; pointer-events: none; position: absolute; top: 0px; width: 100%; }", ".framer-3Zp8H .framer-5wbqs8 { flex: none; height: 600px; left: calc(50% - 660px / 2); pointer-events: none; position: absolute; top: 130px; width: 660px; }", ".framer-3Zp8H .framer-1f5nqex-container, .framer-3Zp8H .framer-1mogc4c-container, .framer-3Zp8H .framer-1i7bo1o-container, .framer-3Zp8H .framer-1qx02x8-container, .framer-3Zp8H .framer-1rkhiae-container, .framer-3Zp8H .framer-10iciru-container, .framer-3Zp8H .framer-1q4tgax-container, .framer-3Zp8H .framer-jiv7su-container { flex: none; height: auto; position: relative; width: 100%; }", ".framer-3Zp8H .framer-1absmqj, .framer-3Zp8H .framer-12bvwzf { flex: none; height: 1px; pointer-events: none; position: relative; width: 100%; }", ".framer-3Zp8H .framer-1lcio3c { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: 520px; justify-content: flex-start; overflow: visible; padding: 32px 0px 0px 0px; position: relative; width: 100%; }", ".framer-3Zp8H .framer-15vb1cr { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; height: min-content; justify-content: space-between; overflow: visible; padding: 0px; position: relative; width: 100%; z-index: 2; }", ".framer-3Zp8H .framer-dbl12e { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: 188px; }", ".framer-3Zp8H .framer-laors5, .framer-3Zp8H .framer-twyjyl { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-3Zp8H .framer-1qtt3tl, .framer-3Zp8H .framer-1alvgwg { flex: none; height: 14px; pointer-events: none; position: relative; width: 1px; }", ".framer-3Zp8H .framer-veretm { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: 100px; }", ".framer-3Zp8H .framer-8ruma7 { bottom: 18px; flex: none; height: 36px; left: calc(50% - 260px / 2); pointer-events: none; position: absolute; width: 260px; }", ".framer-3Zp8H .framer-1y7y2hn { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: 500px; justify-content: center; left: calc(50% - 600px / 2); overflow: visible; padding: 0px; position: absolute; top: 0px; width: 600px; }", ".framer-3Zp8H .framer-1ju5416-container { flex: none; height: 100%; position: relative; width: 100%; }", ".framer-3Zp8H .framer-fczprw { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; height: min-content; justify-content: space-between; overflow: visible; padding: 14px 0px 0px 0px; position: relative; width: 100%; }", ".framer-3Zp8H .framer-1m3cmn4 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 60px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; text-decoration: none; width: min-content; }", ".framer-3Zp8H .framer-od66kp { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-3Zp8H .framer-ktqr6v { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 14px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: min-content; }", ".framer-3Zp8H .framer-yag8gw-container, .framer-3Zp8H .framer-1cv86qe-container { flex: none; height: auto; position: relative; width: auto; }", ".framer-3Zp8H.framer-v-kkdkuy.framer-bibvfq { padding: 36px 32px 18px 32px; width: 100%; }", ".framer-3Zp8H.framer-v-kkdkuy .framer-5wbqs8 { height: 530px; left: calc(50% - 540px / 2); top: 110px; width: 540px; }", ".framer-3Zp8H.framer-v-kkdkuy .framer-1lcio3c { height: 450px; padding: 28px 0px 0px 0px; }", ".framer-3Zp8H.framer-v-kkdkuy .framer-dbl12e { width: 152px; }", ".framer-3Zp8H.framer-v-kkdkuy .framer-veretm { width: 142px; }", ".framer-3Zp8H.framer-v-kkdkuy .framer-8ruma7 { bottom: 14px; left: calc(50% - 220px / 2); width: 220px; }", ".framer-3Zp8H.framer-v-kkdkuy .framer-1y7y2hn { height: 430px; left: calc(50% - 440px / 2); width: 440px; }", ".framer-3Zp8H.framer-v-u2dyh7.framer-bibvfq { padding: 26px 24px 16px 24px; width: 100%; }", ".framer-3Zp8H.framer-v-u2dyh7 .framer-5wbqs8 { height: 480px; left: calc(50% - 430px / 2); top: 340px; width: 430px; }", ".framer-3Zp8H.framer-v-u2dyh7 .framer-1lcio3c { gap: 12px; height: min-content; padding: 24px 0px 12px 0px; }", ".framer-3Zp8H.framer-v-u2dyh7 .framer-15vb1cr { gap: 18px; justify-content: flex-start; }", ".framer-3Zp8H.framer-v-u2dyh7 .framer-dbl12e, .framer-3Zp8H.framer-v-u2dyh7 .framer-veretm { flex: 1 0 0px; width: 1px; }", ".framer-3Zp8H.framer-v-u2dyh7 .framer-8ruma7 { bottom: 15px; left: calc(50% - 180px / 2); width: 180px; }", ".framer-3Zp8H.framer-v-u2dyh7 .framer-1y7y2hn { height: 360px; left: unset; position: relative; top: unset; width: 100%; }", ".framer-3Zp8H.framer-v-u2dyh7 .framer-fczprw { flex-wrap: wrap; }"];
var Framervrx1cXOaH = withCSS3(Component3, css3, "framer-3Zp8H");
var vrx1cXOaH_default = Framervrx1cXOaH;
Framervrx1cXOaH.displayName = "Interactive Footer";
Framervrx1cXOaH.defaultProps = { height: 759, width: 1080 };
addPropertyControls4(Framervrx1cXOaH, { variant: { options: ["wb3gECfnV", "liGNwVU8M", "Tg8e4tMNu"], optionTitles: ["Desktop", "Tablet", "Phone"], title: "Variant", type: ControlType4.Enum }, o77r0Oia8: { defaultValue: "Let\u2019s talk.", title: "Contact Label", type: ControlType4.String }, ono77r0Oia8Change: { changes: "o77r0Oia8", type: ControlType4.ChangeHandler }, byLNhI2KU: { defaultValue: false, title: "Contact New Tab", type: ControlType4.Boolean }, onbyLNhI2KUChange: { changes: "byLNhI2KU", type: ControlType4.ChangeHandler }, xupq9c7vx: { defaultValue: "Explore", title: "Explore Label", type: ControlType4.String }, onxupq9c7vxChange: { changes: "xupq9c7vx", type: ControlType4.ChangeHandler }, zJduH6lMs: { defaultValue: "Follow", title: "Follow Label", type: ControlType4.String }, onzJduH6lMsChange: { changes: "zJduH6lMs", type: ControlType4.ChangeHandler }, XWC7a0Bi4: { defaultValue: "\xA9 2026", title: "Copyright", type: ControlType4.String }, onXWC7a0Bi4Change: { changes: "XWC7a0Bi4", type: ControlType4.ChangeHandler }, mnuEhVpEM: { title: "Copyright Link", type: ControlType4.Link }, GOWB6uYYA: { defaultValue: false, title: "Copyright New Tab", type: ControlType4.Boolean }, onGOWB6uYYAChange: { changes: "GOWB6uYYA", type: ControlType4.ChangeHandler }, E7oeSd0DQ: { defaultValue: "rgb(236, 237, 235)", title: "Background", type: ControlType4.Color }, axksOicBS: { defaultValue: "rgb(34, 38, 37)", title: "Text Color", type: ControlType4.Color }, hMxI_GLYo: { defaultValue: "rgb(20, 95, 234)", title: "Accent Color", type: ControlType4.Color }, PNLbophQR: { defaultValue: true, title: "Show Atmosphere", type: ControlType4.Boolean }, onPNLbophQRChange: { changes: "PNLbophQR", type: ControlType4.ChangeHandler }, rUXNFyUY3: { defaultValue: true, title: "Show Character", type: ControlType4.Boolean }, onrUXNFyUY3Change: { changes: "rUXNFyUY3", type: ControlType4.ChangeHandler }, GlXfPXCkO: { title: "Contact Destination", type: ControlType4.Link }, ye7rOqe5h: { defaultValue: "Work", title: "Explore 1 Label", type: ControlType4.String }, onye7rOqe5hChange: { changes: "ye7rOqe5h", type: ControlType4.ChangeHandler }, Fa96Ldi7a: { title: "Explore 1 Destination", type: ControlType4.Link }, tfB4bfcS3: { defaultValue: false, title: "Explore 1 New Tab", type: ControlType4.Boolean }, ontfB4bfcS3Change: { changes: "tfB4bfcS3", type: ControlType4.ChangeHandler }, MOxKIx5hB: { defaultValue: "Studio", title: "Explore 2 Label", type: ControlType4.String }, onMOxKIx5hBChange: { changes: "MOxKIx5hB", type: ControlType4.ChangeHandler }, mo8TleJzZ: { title: "Explore 2 Destination", type: ControlType4.Link }, HCf4Hw9TY: { defaultValue: false, title: "Explore 2 New Tab", type: ControlType4.Boolean }, onHCf4Hw9TYChange: { changes: "HCf4Hw9TY", type: ControlType4.ChangeHandler }, T1PQmWGyS: { defaultValue: "Services", title: "Explore 3 Label", type: ControlType4.String }, onT1PQmWGySChange: { changes: "T1PQmWGyS", type: ControlType4.ChangeHandler }, e1jHydvVt: { title: "Explore 3 Destination", type: ControlType4.Link }, lhjGosi_A: { defaultValue: false, title: "Explore 3 New Tab", type: ControlType4.Boolean }, onlhjGosi_AChange: { changes: "lhjGosi_A", type: ControlType4.ChangeHandler }, u_nblm_JG: { defaultValue: "Journal", title: "Explore 4 Label", type: ControlType4.String }, onu_nblm_JGChange: { changes: "u_nblm_JG", type: ControlType4.ChangeHandler }, PfrA_KzF_: { title: "Explore 4 Destination", type: ControlType4.Link }, r6wyRWURn: { defaultValue: false, title: "Explore 4 New Tab", type: ControlType4.Boolean }, onr6wyRWURnChange: { changes: "r6wyRWURn", type: ControlType4.ChangeHandler }, xWfihUARj: { defaultValue: "Instagram", title: "Social 1 Label", type: ControlType4.String }, onxWfihUARjChange: { changes: "xWfihUARj", type: ControlType4.ChangeHandler }, Ri426N47U: { title: "Social 1 Destination", type: ControlType4.Link }, SKVOJot62: { defaultValue: false, title: "Social 1 New Tab", type: ControlType4.Boolean }, onSKVOJot62Change: { changes: "SKVOJot62", type: ControlType4.ChangeHandler }, sj_4Za9pQ: { defaultValue: "LinkedIn", title: "Social 2 Label", type: ControlType4.String }, onsj_4Za9pQChange: { changes: "sj_4Za9pQ", type: ControlType4.ChangeHandler }, Ltu9jKcR9: { title: "Social 2 Destination", type: ControlType4.Link }, NFhj0r1FH: { defaultValue: false, title: "Social 2 New Tab", type: ControlType4.Boolean }, onNFhj0r1FHChange: { changes: "NFhj0r1FH", type: ControlType4.ChangeHandler }, qZXA9i_dF: { defaultValue: "Dribbble", title: "Social 3 Label", type: ControlType4.String }, onqZXA9i_dFChange: { changes: "qZXA9i_dF", type: ControlType4.ChangeHandler }, VTGMY6Vcr: { title: "Social 3 Destination", type: ControlType4.Link }, jhpKnf9dQ: { defaultValue: false, title: "Social 3 New Tab", type: ControlType4.Boolean }, onjhpKnf9dQChange: { changes: "jhpKnf9dQ", type: ControlType4.ChangeHandler }, ljswdoYA2: { defaultValue: "Privacy", title: "Legal 1 Label", type: ControlType4.String }, onljswdoYA2Change: { changes: "ljswdoYA2", type: ControlType4.ChangeHandler }, aSQJ1nikH: { title: "Legal 1 Destination", type: ControlType4.Link }, bPmfCVkJa: { defaultValue: false, title: "Legal 1 New Tab", type: ControlType4.Boolean }, onbPmfCVkJaChange: { changes: "bPmfCVkJa", type: ControlType4.ChangeHandler }, ljaR7xZCH: { defaultValue: "Terms", title: "Legal 2 Label", type: ControlType4.String }, onljaR7xZCHChange: { changes: "ljaR7xZCH", type: ControlType4.ChangeHandler }, O_nLfO1dy: { title: "Legal 2 Destination", type: ControlType4.Link }, abbxFui6y: { defaultValue: false, title: "Legal 2 New Tab", type: ControlType4.Boolean }, onabbxFui6yChange: { changes: "abbxFui6y", type: ControlType4.ChangeHandler }, Pj3uUQmwM: { defaultValue: true, description: "Show the soft light behind the sculpture.\n\nBuilt by Matthias \xD6lschlegel \u{1F4AA}\n[Explore more components](https://framer.link/fsd2pgh)", title: "Show Spotlight", type: ControlType4.Boolean }, onPj3uUQmwMChange: { changes: "Pj3uUQmwM", type: ControlType4.ChangeHandler } });
addFonts3(Framervrx1cXOaH, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...ContactFonts, ...LinkFonts, ...FooterCharacterFonts], { supportsExplicitInterCodegen: true });
Framervrx1cXOaH.loader = { load: (props, context) => {
  return runTasksWithYield([() => forwardLoader(hJv3Audcp_default, {}, context), () => forwardLoader(RXzmy3vEP_default, {}, context)], context);
} };
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "Framervrx1cXOaH", "slots": [], "annotations": { "framerVariables": '{"o77r0Oia8":"contactLabel","byLNhI2KU":"contactNewTab","xupq9c7vx":"exploreLabel","zJduH6lMs":"followLabel","XWC7a0Bi4":"copyright","mnuEhVpEM":"copyrightLink","GOWB6uYYA":"copyrightNewTab","E7oeSd0DQ":"background","axksOicBS":"textColor","hMxI_GLYo":"accentColor","PNLbophQR":"showAtmosphere","rUXNFyUY3":"showCharacter","GlXfPXCkO":"contactDestination","ye7rOqe5h":"explore1Label","Fa96Ldi7a":"explore1Destination","tfB4bfcS3":"explore1NewTab","MOxKIx5hB":"explore2Label","mo8TleJzZ":"explore2Destination","HCf4Hw9TY":"explore2NewTab","T1PQmWGyS":"explore3Label","e1jHydvVt":"explore3Destination","lhjGosi_A":"explore3NewTab","u_nblm_JG":"explore4Label","PfrA_KzF_":"explore4Destination","r6wyRWURn":"explore4NewTab","xWfihUARj":"social1Label","Ri426N47U":"social1Destination","SKVOJot62":"social1NewTab","sj_4Za9pQ":"social2Label","Ltu9jKcR9":"social2Destination","NFhj0r1FH":"social2NewTab","qZXA9i_dF":"social3Label","VTGMY6Vcr":"social3Destination","jhpKnf9dQ":"social3NewTab","ljswdoYA2":"legal1Label","aSQJ1nikH":"legal1Destination","bPmfCVkJa":"legal1NewTab","ljaR7xZCH":"legal2Label","O_nLfO1dy":"legal2Destination","abbxFui6y":"legal2NewTab","Pj3uUQmwM":"showSpotlight"}', "framerAutoSizeImages": "true", "framerIntrinsicHeight": "759", "framerContractVersion": "1", "framerColorSyntax": "true", "framerComponentViewportWidth": "true", "framerIntrinsicWidth": "1080", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"liGNwVU8M":{"layout":["fixed","auto"]},"Tg8e4tMNu":{"layout":["fixed","auto"]}}}', "framerDisplayContentsDiv": "false", "framerImmutableVariables": "true" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  vrx1cXOaH_default as default
};
