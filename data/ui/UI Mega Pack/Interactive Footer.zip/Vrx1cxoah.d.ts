export interface Vrx1cxoahProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → wb3gECfnV
   *   "Phone" → Tg8e4tMNu
   *   "Tablet" → liGNwVU8M
   */
  variant?: 'Desktop' | 'Phone' | 'Tablet' | 'wb3gECfnV' | 'liGNwVU8M' | 'Tg8e4tMNu';
  /**
   * Contact Label — pass as `o77r0Oia8` not `contactLabel`.
   * @default "Let’s talk."
   */
  o77r0Oia8?: string;
  ono77r0Oia8Change?: string;
  /**
   * Contact New Tab — pass as `byLNhI2KU` not `contactNewTab`.
   * @default false
   */
  byLNhI2KU?: boolean;
  onbyLNhI2KUChange?: string;
  /**
   * Explore Label — pass as `xupq9c7vx` not `exploreLabel`.
   * @default "Explore"
   */
  xupq9c7vx?: string;
  onxupq9c7vxChange?: string;
  /**
   * Follow Label — pass as `zJduH6lMs` not `followLabel`.
   * @default "Follow"
   */
  zJduH6lMs?: string;
  onzJduH6lMsChange?: string;
  /**
   * Copyright — pass as `XWC7a0Bi4` not `copyright`.
   * @default "© 2026"
   */
  XWC7a0Bi4?: string;
  onXWC7a0Bi4Change?: string;
  /**
   * Copyright Link — pass as `mnuEhVpEM` not `copyrightLink`.
   */
  mnuEhVpEM?: string;
  /**
   * Copyright New Tab — pass as `GOWB6uYYA` not `copyrightNewTab`.
   * @default false
   */
  GOWB6uYYA?: boolean;
  onGOWB6uYYAChange?: string;
  /**
   * Background — pass as `E7oeSd0DQ` not `background`.
   * @default "rgb(236, 237, 235)"
   */
  E7oeSd0DQ?: string;
  /**
   * Text Color — pass as `axksOicBS` not `textColor`.
   * @default "rgb(34, 38, 37)"
   */
  axksOicBS?: string;
  /**
   * Accent Color — pass as `hMxI_GLYo` not `accentColor`.
   * @default "rgb(20, 95, 234)"
   */
  hMxI_GLYo?: string;
  /**
   * Show Atmosphere — pass as `PNLbophQR` not `showAtmosphere`.
   * @default true
   */
  PNLbophQR?: boolean;
  onPNLbophQRChange?: string;
  /**
   * Show Character — pass as `rUXNFyUY3` not `showCharacter`.
   * @default true
   */
  rUXNFyUY3?: boolean;
  onrUXNFyUY3Change?: string;
  /**
   * Contact Destination — pass as `GlXfPXCkO` not `contactDestination`.
   */
  GlXfPXCkO?: string;
  /**
   * Explore 1 Label — pass as `ye7rOqe5h` not `explore1Label`.
   * @default "Work"
   */
  ye7rOqe5h?: string;
  onye7rOqe5hChange?: string;
  /**
   * Explore 1 Destination — pass as `Fa96Ldi7a` not `explore1Destination`.
   */
  Fa96Ldi7a?: string;
  /**
   * Explore 1 New Tab — pass as `tfB4bfcS3` not `explore1NewTab`.
   * @default false
   */
  tfB4bfcS3?: boolean;
  ontfB4bfcS3Change?: string;
  /**
   * Explore 2 Label — pass as `MOxKIx5hB` not `explore2Label`.
   * @default "Studio"
   */
  MOxKIx5hB?: string;
  onMOxKIx5hBChange?: string;
  /**
   * Explore 2 Destination — pass as `mo8TleJzZ` not `explore2Destination`.
   */
  mo8TleJzZ?: string;
  /**
   * Explore 2 New Tab — pass as `HCf4Hw9TY` not `explore2NewTab`.
   * @default false
   */
  HCf4Hw9TY?: boolean;
  onHCf4Hw9TYChange?: string;
  /**
   * Explore 3 Label — pass as `T1PQmWGyS` not `explore3Label`.
   * @default "Services"
   */
  T1PQmWGyS?: string;
  onT1PQmWGySChange?: string;
  /**
   * Explore 3 Destination — pass as `e1jHydvVt` not `explore3Destination`.
   */
  e1jHydvVt?: string;
  /**
   * Explore 3 New Tab — pass as `lhjGosi_A` not `explore3NewTab`.
   * @default false
   */
  lhjGosi_A?: boolean;
  onlhjGosi_AChange?: string;
  /**
   * Explore 4 Label — pass as `u_nblm_JG` not `explore4Label`.
   * @default "Journal"
   */
  u_nblm_JG?: string;
  onu_nblm_JGChange?: string;
  /**
   * Explore 4 Destination — pass as `PfrA_KzF_` not `explore4Destination`.
   */
  PfrA_KzF_?: string;
  /**
   * Explore 4 New Tab — pass as `r6wyRWURn` not `explore4NewTab`.
   * @default false
   */
  r6wyRWURn?: boolean;
  onr6wyRWURnChange?: string;
  /**
   * Social 1 Label — pass as `xWfihUARj` not `social1Label`.
   * @default "Instagram"
   */
  xWfihUARj?: string;
  onxWfihUARjChange?: string;
  /**
   * Social 1 Destination — pass as `Ri426N47U` not `social1Destination`.
   */
  Ri426N47U?: string;
  /**
   * Social 1 New Tab — pass as `SKVOJot62` not `social1NewTab`.
   * @default false
   */
  SKVOJot62?: boolean;
  onSKVOJot62Change?: string;
  /**
   * Social 2 Label — pass as `sj_4Za9pQ` not `social2Label`.
   * @default "LinkedIn"
   */
  sj_4Za9pQ?: string;
  onsj_4Za9pQChange?: string;
  /**
   * Social 2 Destination — pass as `Ltu9jKcR9` not `social2Destination`.
   */
  Ltu9jKcR9?: string;
  /**
   * Social 2 New Tab — pass as `NFhj0r1FH` not `social2NewTab`.
   * @default false
   */
  NFhj0r1FH?: boolean;
  onNFhj0r1FHChange?: string;
  /**
   * Social 3 Label — pass as `qZXA9i_dF` not `social3Label`.
   * @default "Dribbble"
   */
  qZXA9i_dF?: string;
  onqZXA9i_dFChange?: string;
  /**
   * Social 3 Destination — pass as `VTGMY6Vcr` not `social3Destination`.
   */
  VTGMY6Vcr?: string;
  /**
   * Social 3 New Tab — pass as `jhpKnf9dQ` not `social3NewTab`.
   * @default false
   */
  jhpKnf9dQ?: boolean;
  onjhpKnf9dQChange?: string;
  /**
   * Legal 1 Label — pass as `ljswdoYA2` not `legal1Label`.
   * @default "Privacy"
   */
  ljswdoYA2?: string;
  onljswdoYA2Change?: string;
  /**
   * Legal 1 Destination — pass as `aSQJ1nikH` not `legal1Destination`.
   */
  aSQJ1nikH?: string;
  /**
   * Legal 1 New Tab — pass as `bPmfCVkJa` not `legal1NewTab`.
   * @default false
   */
  bPmfCVkJa?: boolean;
  onbPmfCVkJaChange?: string;
  /**
   * Legal 2 Label — pass as `ljaR7xZCH` not `legal2Label`.
   * @default "Terms"
   */
  ljaR7xZCH?: string;
  onljaR7xZCHChange?: string;
  /**
   * Legal 2 Destination — pass as `O_nLfO1dy` not `legal2Destination`.
   */
  O_nLfO1dy?: string;
  /**
   * Legal 2 New Tab — pass as `abbxFui6y` not `legal2NewTab`.
   * @default false
   */
  abbxFui6y?: boolean;
  onabbxFui6yChange?: string;
  /**
   * Show Spotlight — pass as `Pj3uUQmwM` not `showSpotlight`.
   * @default true
   */
  Pj3uUQmwM?: boolean;
  onPj3uUQmwMChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
