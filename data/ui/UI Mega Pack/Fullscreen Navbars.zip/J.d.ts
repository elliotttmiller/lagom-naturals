export interface JProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Dark Desktop Closed" → yBzCN4CQQ
   *   "Dark Desktop Open" → D6duG3qNq
   *   "Dark Phone Closed" → oIU_m299E
   *   "Dark Phone Open" → xb0h23Mko
   *   "Light Desktop Closed" → O_UbZiv70
   *   "Light Desktop Open" → c2gAZTlwQ
   *   "Light Phone Closed" → RYYNIb9_N
   *   "Light Phone Open" → Lh_JzIMKi
   */
  variant?: 'Dark Desktop Closed' | 'Dark Desktop Open' | 'Dark Phone Closed' | 'Dark Phone Open' | 'Light Desktop Closed' | 'Light Desktop Open' | 'Light Phone Closed' | 'Light Phone Open' | 'yBzCN4CQQ' | 'D6duG3qNq' | 'oIU_m299E' | 'xb0h23Mko' | 'O_UbZiv70' | 'c2gAZTlwQ' | 'RYYNIb9_N' | 'Lh_JzIMKi';
  /**
   * Logo Name — pass as `JRzkQ2_C8` not `logoName`.
   * @default "Élan"
   */
  JRzkQ2_C8?: string;
  onJRzkQ2_C8Change?: string;
  /** Additional properties */
  [key: string]: unknown;
}
