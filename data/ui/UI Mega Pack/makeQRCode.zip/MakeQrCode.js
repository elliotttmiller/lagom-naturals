var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/WaSdoDYjeoUFHmy15NCS/nauAwUItJIxjLY19MwCI/Make_QR_Code.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { addPropertyControls, ControlType } from "./_framer-runtime.js";
import { QRCodeSVG } from "qrcode.react";
function makeQRCode(props) {
  const { input, size, darkMode, margin, radius } = props;
  const defaultValue = "https://www.framer.com";
  const value = (input || "").trim() || defaultValue;
  const fg = darkMode ? "#ffffff" : "#000000";
  const bg = darkMode ? "#000000" : "#ffffff";
  return /* @__PURE__ */ _jsxs("div", { style: { display: "flex", justifyContent: "center", alignItems: "center", width: "100%", height: "100%", position: "relative" }, children: [/* @__PURE__ */ _jsx("div", { style: { position: "absolute", width: size + margin * 2, height: size + margin * 2, backgroundColor: bg, borderRadius: radius, zIndex: 0 } }), /* @__PURE__ */ _jsx(QRCodeSVG, { value, size, fgColor: fg, bgColor: "transparent", level: "H", includeMargin: false, style: { zIndex: 1 } })] });
}
makeQRCode.defaultProps = { input: "", size: 160, darkMode: false, margin: 8, radius: 8 };
addPropertyControls(makeQRCode, { input: { type: ControlType.String, title: "Input", placeholder: "https://framer.com", defaultValue: "" }, size: { type: ControlType.Number, title: "QR Size", min: 80, max: 512, step: 2, defaultValue: makeQRCode.defaultProps.size }, darkMode: { type: ControlType.Boolean, title: "Dark Mode", enabledTitle: "Yes", disabledTitle: "No", defaultValue: makeQRCode.defaultProps.darkMode }, margin: { type: ControlType.Number, title: "Margin", min: 0, max: 64, step: 2, defaultValue: makeQRCode.defaultProps.margin }, radius: { type: ControlType.Number, title: "Radius", min: 0, max: 64, step: 1, defaultValue: makeQRCode.defaultProps.radius } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "makeQRCode", "slots": [], "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  makeQRCode as default
};
