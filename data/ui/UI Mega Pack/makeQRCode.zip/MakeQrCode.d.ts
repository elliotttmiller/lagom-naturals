export interface MakeqrcodeProps {
  /**
   * Input
   * @default ""
   */
  input?: string;
  /**
   * QR Size — pass as `size` not `qrSize`.
   * Range: min: 80, max: 512, step: 2
   */
  size?: number;
  /**
   * Dark Mode
   */
  darkMode?: boolean;
  /**
   * Margin
   * Range: min: 0, max: 64, step: 2
   */
  margin?: number;
  /**
   * Radius
   * Range: min: 0, max: 64, step: 1
   */
  radius?: number;
  /** Additional properties */
  [key: string]: unknown;
}
