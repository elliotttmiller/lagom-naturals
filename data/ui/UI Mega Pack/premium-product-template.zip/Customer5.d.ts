/**
 * Props for Customer5 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Customer5Props {
  [key: string]: unknown;
}
