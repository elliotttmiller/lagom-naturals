/**
 * Props for Customer component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface CustomerProps {
  [key: string]: unknown;
}
