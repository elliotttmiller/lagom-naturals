/**
 * Props for Customer4 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Customer4Props {
  [key: string]: unknown;
}
