/**
 * Props for Customer2 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Customer2Props {
  [key: string]: unknown;
}
