export interface Featuresbadge26Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Features Badge Filled Style" → fXRHQDHb1
   *   "Blured" → bJxNMSX4k
   *   "Small" → jW0FQ3kgP
   */
  variant?: 'Features Badge Filled Style' | 'Blured' | 'Small' | 'fXRHQDHb1' | 'bJxNMSX4k' | 'jW0FQ3kgP';
  /**
   * Icon — pass as `cHISqe95w` not `icon`.
   * @default {"identifier":"module:KWNNduwKoKnTbOk1rXSC/tvASeTv7v4EcfcuyftvV/LbO3HXMGE.js:default","moduleId":"KWNNduwKoKnTbOk1rXSC"}
   */
  cHISqe95w?: string;
  /**
   * Title — pass as `SdYib0uc9` not `title`.
   * @default "40 MM"
   */
  SdYib0uc9?: string;
  /**
   * Text — pass as `pxIupHMzn` not `text`.
   * @default "Driver Size"
   */
  pxIupHMzn?: string;
  /** Additional properties */
  [key: string]: unknown;
}
