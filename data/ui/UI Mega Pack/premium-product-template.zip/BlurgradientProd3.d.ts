export interface Blurgradientprod3Props {
  /**
   * Blur
   * Range: min: 0, max: 100, step: 1
   * @default 10
   */
  blur?: number;
  /**
   * Radius — pass as `borderRadius` not `radius`.
   * @default "0px"
   */
  borderRadius?: string;
  /**
   * Direction
   * Options: "to bottom" | "to top" | "to left" | "to right"
   * @default "to bottom"
   */
  direction?: string;
  /**
   * Transition
   * @default {"duration":0.3}
   */
  transition?: object;
  /** Additional properties */
  [key: string]: unknown;
}
