export interface Slider6Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Mobile Slide 1" → nSk0ooZAs
   *   "Mobile Slide 2" → vsNl2d2c0
   *   "Mobile Slide 3" → gZT38hFmD
   *   "Slide 1" → R8u_L31kT
   *   "Slide 2" → cmsDEy36o
   *   "Slide 3" → wiOpDkuuO
   */
  variant?: 'Mobile Slide 1' | 'Mobile Slide 2' | 'Mobile Slide 3' | 'Slide 1' | 'Slide 2' | 'Slide 3' | 'R8u_L31kT' | 'cmsDEy36o' | 'wiOpDkuuO' | 'nSk0ooZAs' | 'vsNl2d2c0' | 'gZT38hFmD';
  /**
   * Slide 1 Overlay Visible — pass as `q2prnALbW` not `slide1OverlayVisible`.
   * @default true
   */
  q2prnALbW?: boolean;
  /**
   * Slide 1 Image — pass as `XDxNdTkH4` not `slide1Image`.
   */
  XDxNdTkH4?: string;
  /**
   * Slide 1 Title — pass as `hLePJiPIF` not `slide1Title`.
   * @default "Move without limits with Airbuds"
   */
  hLePJiPIF?: string;
  /**
   * Slide 1 Copy — pass as `kxIY3jt2x` not `slide1Copy`.
   * @default "Probuds stay secure and deliver uninterrupted sound no matter where life takes you."
   */
  kxIY3jt2x?: string;
  /**
   * Slide 2 Overlay Visible — pass as `NQQ7btaxa` not `slide2OverlayVisible`.
   * @default true
   */
  NQQ7btaxa?: boolean;
  /**
   * Slide 2 Image — pass as `zeFEQ2kkX` not `slide2Image`.
   */
  zeFEQ2kkX?: string;
  /**
   * Slide 2 Title — pass as `p_6vGH3Dk` not `slide2Title`.
   * @default "Premium Sound Quality!"
   */
  p_6vGH3Dk?: string;
  /**
   * Slide 2 Copy — pass as `a3qANK_u7` not `slide2Copy`.
   * @default "Probuds stay secure and deliver uninterrupted sound no matter where life takes you."
   */
  a3qANK_u7?: string;
  /**
   * Slide 3 Overlay Visible — pass as `CORP6dV8C` not `slide3OverlayVisible`.
   * @default true
   */
  CORP6dV8C?: boolean;
  /**
   * Slide 3 Image — pass as `b3PDn9Fta` not `slide3Image`.
   */
  b3PDn9Fta?: string;
  /**
   * Slide 3 Title — pass as `pVF_hOA2L` not `slide3Title`.
   * @default "More Than You Need!"
   */
  pVF_hOA2L?: string;
  /**
   * Slide 3 Copy — pass as `NBimnNQ3Q` not `slide3Copy`.
   * @default "text"
   */
  NBimnNQ3Q?: string;
  /** Additional properties */
  [key: string]: unknown;
}
