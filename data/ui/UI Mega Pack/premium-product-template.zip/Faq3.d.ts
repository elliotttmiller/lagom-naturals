/**
 * Props for Faq3 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Faq3Props {
  [key: string]: unknown;
}
