export interface ComponentsfeaturecardProps {
  /**
   * Icon — pass as `uE6lIrQTc` not `icon`.
   * @default {"identifier":"module:SUBEdtCFaOJwrjN2Inhk/bznEUerLEqVVXGfsDOYE/pKERsxd4H.js:default","moduleId":"SUBEdtCFaOJwrjN2Inhk"}
   */
  uE6lIrQTc?: string;
  /**
   * Heading — pass as `aUatvygbQ` not `heading`.
   * @default "The Best Airbuds"
   */
  aUatvygbQ?: string;
  /**
   * Paragraph — pass as `Zdb0MwW97` not `paragraph`.
   * @default "Rich bass and crisp highs for an immersive listening experience."
   */
  Zdb0MwW97?: string;
  /** Additional properties */
  [key: string]: unknown;
}
