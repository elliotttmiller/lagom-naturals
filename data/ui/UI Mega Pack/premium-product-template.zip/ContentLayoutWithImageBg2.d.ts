export interface Contentlayoutwithimagebg2Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → BQGIQsRXv
   *   "Phone" → rV7fpbCOo
   *   "Tablet" → OC45nAVQr
   */
  variant?: 'Desktop' | 'Phone' | 'Tablet' | 'BQGIQsRXv' | 'OC45nAVQr' | 'rV7fpbCOo';
  /**
   * Image — pass as `FCwYVL21M` not `image`.
   */
  FCwYVL21M?: string;
  /**
   * Text — pass as `ApnrYYxzU` not `text`.
   * @default "Get Airbuds Pro & Listen Wherever You Want!"
   */
  ApnrYYxzU?: string;
  /**
   * Title — pass as `B46nqkYgA` not `title`.
   * @default "Power that keeps you going"
   */
  B46nqkYgA?: string;
  /**
   * Badge — pass as `gtjl5kjfH` not `badge`.
   * @default "7 Hours per charge"
   */
  gtjl5kjfH?: string;
  /**
   * Features Card Title — pass as `YSu4XTon0` not `featuresCardTitle`.
   * @default "All-Day Battery Life"
   */
  YSu4XTon0?: string;
  /**
   * Features Card Text — pass as `SBkgu1iHn` not `featuresCardText`.
   * @default "A quick 10-minute charge gives you 2 more hours of uninterrupted music."
   */
  SBkgu1iHn?: string;
  /** Additional properties */
  [key: string]: unknown;
}
