export interface Badge24Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Badge Classic Style" → q6EjI1Rwt
   *   "Blured" → No_tDSdq_
   */
  variant?: 'Badge Classic Style' | 'Blured' | 'q6EjI1Rwt' | 'No_tDSdq_';
  /**
   * Title — pass as `CDHmYMD4c` not `title`.
   * @default "Badge"
   */
  CDHmYMD4c?: string;
  /** Additional properties */
  [key: string]: unknown;
}
