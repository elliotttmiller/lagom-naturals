/**
 * Props for Faq4 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Faq4Props {
  [key: string]: unknown;
}
