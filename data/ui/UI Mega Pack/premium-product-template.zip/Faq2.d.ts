/**
 * Props for Faq2 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Faq2Props {
  [key: string]: unknown;
}
