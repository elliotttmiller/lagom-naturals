export interface Pointer3Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Active" → V4B7aSRsV
   *   "Pointer" → ptasSkYUc
   */
  variant?: 'Active' | 'Pointer' | 'ptasSkYUc' | 'V4B7aSRsV';
  /**
   * Icon — pass as `xHqW0E70B` not `icon`.
   * @default {"identifier":"module:ESVgFAiOjIiHnC6O20iw/ntAZUtULN9zZFje9pVdp/RTghPsDqv.js:default","moduleId":"ESVgFAiOjIiHnC6O20iw"}
   */
  xHqW0E70B?: string;
  /**
   * Title — pass as `OwcNA1EDn` not `title`.
   * @default "Voice Mode"
   */
  OwcNA1EDn?: string;
  /**
   * Text — pass as `Dj00MTkNN` not `text`.
   * @default "Clear speech"
   */
  Dj00MTkNN?: string;
  /** Additional properties */
  [key: string]: unknown;
}
