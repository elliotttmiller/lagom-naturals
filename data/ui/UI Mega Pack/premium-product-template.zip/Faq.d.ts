/**
 * Props for Faq component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface FaqProps {
  [key: string]: unknown;
}
