var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/xWQBrhtD3D2b6ziRsYeN/HjVp3cBypiAw0DzbgGLA/wcwfO2Oe5.js
import { jsx as _jsx5 } from "react/jsx-runtime";
import { addFonts as addFonts2, ComponentViewportProvider as ComponentViewportProvider2, cx as cx2, forwardLoader, getFonts as getFonts2, SmartComponentScopedContainer as SmartComponentScopedContainer2, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup3, motion as motion4, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React6 from "react";
import { useRef as useRef6 } from "react";

// http-url:https://framerusercontent.com/modules/UIrMjSS6ZX89L0CsT8k6/3dMrKtwDsHhQeeykStyV/Carousel.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Children, useCallback as useCallback2, useEffect as useEffect7, useState as useState3, useRef as useRef3, cloneElement, startTransition, useId } from "react";
import { addPropertyControls, ControlType as ControlType4, RenderTarget as RenderTarget3 } from "./_framer-runtime.js";
import { scroll, resize } from "@motionone/dom";
import { clamp } from "@motionone/utils";
import { animate as animate2, motion, useMotionValue, useTransform, useReducedMotion, LayoutGroup } from "framer-motion";

// http-url:https://framerusercontent.com/modules/VTUDdizacRHpwbkOamr7/AykinQJbgwl92LvMGZwu/constants.js
import { ControlType } from "./_framer-runtime.js";
var containerStyles = {
  position: "relative",
  width: "100%",
  height: "100%",
  display: "flex",
  justifyContent: "center",
  alignItems: "center"
};
var emptyStateStyle = {
  ...containerStyles,
  borderRadius: 6,
  background: "rgba(136, 85, 255, 0.3)",
  color: "#85F",
  border: "1px dashed #85F",
  flexDirection: "column"
};
var defaultEvents = {
  onClick: {
    type: ControlType.EventHandler
  },
  onMouseEnter: {
    type: ControlType.EventHandler
  },
  onMouseLeave: {
    type: ControlType.EventHandler
  }
};
var fontSizeOptions = {
  type: ControlType.Number,
  title: "Font Size",
  min: 2,
  max: 200,
  step: 1,
  displayStepper: true
};
var fontControls = {
  font: {
    type: ControlType.Boolean,
    title: "Font",
    defaultValue: false,
    disabledTitle: "Default",
    enabledTitle: "Custom"
  },
  fontFamily: {
    type: ControlType.String,
    title: "Family",
    placeholder: "Inter",
    hidden: ({ font }) => !font
  },
  fontWeight: {
    type: ControlType.Enum,
    title: "Weight",
    options: [
      100,
      200,
      300,
      400,
      500,
      600,
      700,
      800,
      900
    ],
    optionTitles: [
      "Thin",
      "Extra-light",
      "Light",
      "Regular",
      "Medium",
      "Semi-bold",
      "Bold",
      "Extra-bold",
      "Black"
    ],
    hidden: ({ font }) => !font
  }
};

// http-url:https://framerusercontent.com/modules/D4TWeLfcxT6Tysr2BlYg/iZjmqdxVx1EOiM3k1FaW/useOnNavigationTargetChange.js
import { useIsInCurrentNavigationTarget } from "./_framer-runtime.js";
import { useEffect } from "react";

// http-url:https://framerusercontent.com/modules/ExNgrA7EJTKUPpH6vIlN/eiOrSJ2Ab5M9jPCvVwUz/useConstant.js
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/D2Lz5CmnNVPZFFiZXalt/QaCzPbriZBfXWZIIycFI/colorFromToken.js
import { Color } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/3mKFSGQqKHV82uOV1eBc/5fbRLvOpxZC0JOXugvwm/isMotionValue.js
import { MotionValue } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/xDiQsqBGXzmMsv7AlEVy/uhunpMiNsbXxzjlXsg1y/useUniqueClassName.js
import * as React from "react";

// http-url:https://framerusercontent.com/modules/ETACN5BJyFTSo0VVDJfu/NHRqowOiXkF9UwOzczF7/variantUtils.js
import { ControlType as ControlType2 } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/eMBrwoqQK7h6mEeGQUH8/GuplvPJVjmxpk9zqOTcb/isBrowser.js
import { useMemo } from "react";

// http-url:https://framerusercontent.com/modules/v9AWX2URmiYsHf7GbctE/XxKAZ9KlhWqf5x1JMyyF/useOnChange.js
import { useEffect as useEffect3 } from "react";

// http-url:https://framerusercontent.com/modules/kNDwabfjDEb3vUxkQlZS/fSIr3AOAYbGlfSPgXpYu/useAutoMotionValue.js
import { useCallback, useEffect as useEffect4, useRef as useRef2 } from "react";
import { motionValue, animate, RenderTarget } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/cuQH4dmpDnV8YK1mSgQX/KqRXqunFjE6ufhpc7ZRu/useFontControls.js
import { fontStore } from "./_framer-runtime.js";
import { useEffect as useEffect5 } from "react";

// http-url:https://framerusercontent.com/modules/afBE9Yx1W6bY5q32qPxe/m3q7puE2tbo1S2C0s0CT/useRenderTarget.js
import { useMemo as useMemo2 } from "react";
import { RenderTarget as RenderTarget2 } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/zGkoP8tPDCkoBzMdt5uq/0zFSjxIYliHxrQQnryFX/useControlledState.js
import * as React2 from "react";

// http-url:https://framerusercontent.com/modules/5SM58HxZHxjjv7aLMOgQ/WXz9i6mVki0bBCrKdqB3/propUtils.js
import { useMemo as useMemo3 } from "react";
import { ControlType as ControlType3 } from "./_framer-runtime.js";
var borderRadiusControl = {
  borderRadius: {
    title: "Radius",
    type: ControlType3.FusedNumber,
    toggleKey: "isMixedBorderRadius",
    toggleTitles: [
      "Radius",
      "Radius per corner"
    ],
    valueKeys: [
      "topLeftRadius",
      "topRightRadius",
      "bottomRightRadius",
      "bottomLeftRadius"
    ],
    valueLabels: [
      "TL",
      "TR",
      "BR",
      "BL"
    ],
    min: 0
  }
};
function usePadding(props) {
  const { padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft } = props;
  const paddingValue = useMemo3(
    () => paddingPerSide ? `${paddingTop}px ${paddingRight}px ${paddingBottom}px ${paddingLeft}px` : padding,
    [
      padding,
      paddingPerSide,
      paddingTop,
      paddingRight,
      paddingBottom,
      paddingLeft
    ]
  );
  return paddingValue;
}
var paddingControl = {
  padding: {
    type: ControlType3.FusedNumber,
    toggleKey: "paddingPerSide",
    toggleTitles: [
      "Padding",
      "Padding per side"
    ],
    valueKeys: [
      "paddingTop",
      "paddingRight",
      "paddingBottom",
      "paddingLeft"
    ],
    valueLabels: [
      "T",
      "R",
      "B",
      "L"
    ],
    min: 0,
    title: "Padding"
  }
};

// http-url:https://framerusercontent.com/modules/UIrMjSS6ZX89L0CsT8k6/3dMrKtwDsHhQeeykStyV/Carousel.js
function calcMaskWidth([inset, width]) {
  return inset + (100 - inset) * (width / 100) * 0.5;
}
function checkLimit(progress, target, { edgeOpacity, moreItems, buttonRef }, transition) {
  if (moreItems.current && progress === target) {
    moreItems.current = false;
    animate2(edgeOpacity, 1, transition);
    buttonRef.current?.setAttribute("disabled", "");
  } else if (!moreItems.current && progress !== target) {
    moreItems.current = true;
    animate2(edgeOpacity, 0, transition);
    buttonRef.current?.removeAttribute("disabled");
  }
}
function useGUI(initialMoreItems, initialAlpha) {
  const moreItems = useRef3(initialMoreItems);
  const edgeOpacity = useMotionValue(moreItems.current ? 0 : 1);
  const fadeOpacity = useTransform(edgeOpacity, [0, 1], [initialAlpha || 0, 1]);
  const buttonOpacity = useTransform(edgeOpacity, (v) => 1 - v);
  const buttonRef = useRef3(null);
  const pointerEvents = useTransform(buttonOpacity, (v) => v > 0.2 ? "auto" : "none");
  const cursor = useTransform(pointerEvents, (v) => v === "auto" ? "pointer" : "default");
  const buttonStyle = { ...baseButtonStyles, opacity: buttonOpacity, pointerEvents, cursor };
  return { moreItems, fadeOpacity, edgeOpacity, buttonStyle, buttonRef };
}
function setAriaVisible({ element }) {
  element.setAttribute("aria-hidden", false);
}
function useScrollLimits(container, axis, directionModifier, scrollInfo, updateCurrentScroll, targetScroll, checkLimits, measureItems) {
  useEffect7(() => {
    if (!container.current)
      return;
    const updateScrollInfo = (info) => {
      scrollInfo.current = info[axis];
      if (info[axis].current * directionModifier === targetScroll.current) {
        targetScroll.current = void 0;
      }
      updateCurrentScroll(info[axis].current);
      checkLimits();
    };
    const stopScroll = scroll(updateScrollInfo, { container: container.current, axis });
    const stopResize = resize(container.current, () => {
      measureItems();
      checkLimits();
    });
    return () => {
      stopScroll();
      stopResize();
    };
  }, [checkLimits, measureItems]);
}
function Carousel({ slots, gap, axis, align, sizingObject, fadeObject, arrowObject, snapObject, progressObject, ariaLabel, borderRadius, effectsObject, ...props }) {
  const filteredSlots = slots?.filter(Boolean);
  const numItems = Children.count(filteredSlots);
  const isCanvas = RenderTarget3.current() === RenderTarget3.canvas;
  const writingDirection = useWritingDirection();
  const directionModifier = axis && writingDirection === "rtl" ? -1 : 1;
  const padding = usePadding(props);
  const axisLabel = axis ? "x" : "y";
  const { fadeContent, fadeWidth, fadeInset, fadeTransition, fadeAlpha } = fadeObject;
  const { snap, snapEdge, fluid } = snapObject;
  const { widthType, widthInset, widthColumns, heightType, heightInset, heightRows } = sizingObject;
  const { showScrollbar, showProgressDots, dotSize, dotsInset, dotsRadius, dotsPadding, dotsGap, dotsFill, dotsBackground, dotsActiveOpacity, dotsOpacity, dotsBlur } = progressObject;
  const { showMouseControls, arrowSize, arrowRadius, arrowFill, leftArrow, rightArrow, arrowPadding } = arrowObject;
  const scrollInfo = useRef3(void 0);
  const targetScroll = useRef3(void 0);
  const currentScroll = useMotionValue(0);
  const updateCurrentScroll = (newScroll) => {
    currentScroll.set(targetScroll.current !== void 0 ? targetScroll.current : newScroll);
  };
  const start = useGUI(writingDirection === "rtl", fadeAlpha);
  const end = useGUI(writingDirection !== "rtl", fadeAlpha);
  const startMaskInset = useMotionValue(fadeInset * 0.5);
  const endMaskInset = useTransform(startMaskInset, (v) => 100 - v);
  const baseWidth = useMotionValue(fadeWidth);
  const startMaskWidth = useTransform([startMaskInset, baseWidth], calcMaskWidth);
  const endMaskWidth = useTransform(startMaskWidth, (v) => 100 - v);
  const direction = useMotionValue(axis ? "right" : "bottom");
  const mask = useTransform([direction, start.fadeOpacity, startMaskInset, startMaskWidth, end.fadeOpacity, endMaskInset, endMaskWidth], (latest) => {
    return `linear-gradient(to ${latest[0]}, rgb(0, 0, 0, ${latest[1]}) ${latest[2]}%, rgb(0, 0, 0, 1) ${latest[3]}%, rgba(0, 0, 0, 1) ${latest[6]}%, rgb(0, 0, 0, ${latest[4]}) ${latest[5]}%)`;
  });
  const carouselRef = useRef3(null);
  const [numPages, setNumPages] = useState3(isCanvas ? 4 : 1);
  const itemStyle = { scrollSnapAlign: snapEdge, flexShrink: 0 };
  const childStyle = {};
  if (align === "stretch") {
    if (axis) {
      childStyle.height = "100%";
      itemStyle.height = "auto";
    } else {
      childStyle.width = "100%";
      itemStyle.width = "auto";
    }
  }
  if (!fluid) {
    itemStyle.scrollSnapStop = "always";
  }
  if (widthType === "stretch") {
    itemStyle.width = `calc(100% - ${widthInset || 0}px)`;
    childStyle.width = "100%";
  } else if (widthType === "columns") {
    itemStyle.width = `calc(${100 / widthColumns}% - ${gap}px + ${gap / widthColumns}px)`;
    childStyle.width = "100%";
  }
  if (heightType === "stretch") {
    itemStyle.height = `calc(100% - ${heightInset || 0}px)`;
    childStyle.height = "100%";
  } else if (heightType === "rows") {
    itemStyle.height = `calc(${100 / heightRows}% - ${gap}px + ${gap / heightRows}px)`;
    childStyle.height = "100%";
  }
  const scrollOverflow = isCanvas ? "hidden" : "auto";
  const containerStyle = { ...baseContainerStyle, padding };
  const carouselStyle = { ...baseCarouselStyle, gap, alignItems: align, flexDirection: axis ? "row" : "column", overflowX: axis ? scrollOverflow : "hidden", overflowY: axis ? "hidden" : scrollOverflow, scrollSnapType: snap ? `${axisLabel} mandatory` : void 0, WebkitOverflowScrolling: "touch", WebkitMaskImage: fadeContent ? mask : void 0, maskImage: fadeContent ? mask : void 0, borderRadius };
  const carouselA11y = { ["aria-roledescription"]: "carousel" };
  if (ariaLabel) {
    carouselA11y["aria-title"] = ariaLabel;
  }
  const itemA11y = {};
  if (align === "stretch") {
    itemA11y["aria-role"] = "group";
    itemA11y["aria-roledescription"] = "slide";
  }
  if (!isCanvas) {
    const itemSizes = useRef3([]);
    useScrollLimits(carouselRef, axisLabel, directionModifier, scrollInfo, updateCurrentScroll, targetScroll, useCallback2(() => {
      if (!scrollInfo.current)
        return;
      const { targetLength, containerLength, scrollLength } = scrollInfo.current;
      const current = currentScroll.get();
      if (!targetLength && !containerLength)
        return;
      if (targetLength > containerLength) {
        checkLimit(current * directionModifier, 0, start, fadeTransition);
        checkLimit(current * directionModifier, scrollLength, end, fadeTransition);
        for (let i = 0; i < itemSizes.current.length; i++) {
          const { element, start: start2, end: end2 } = itemSizes.current[i];
          const outOfView = end2 < current || start2 > current + containerLength;
          element.setAttribute("aria-hidden", outOfView);
          if (!outOfView) {
            element.querySelectorAll("button,a").forEach((el) => {
              const orig = el.dataset.origTabIndex;
              if (orig)
                el.tabIndex = orig;
              else
                el.removeAttribute("tabIndex");
            });
          } else {
            element.querySelectorAll("button,a").forEach((el) => {
              const orig = el.getAttribute("tabIndex");
              if (orig)
                el.dataset.origTabIndex = orig;
              el.tabIndex = -1;
            });
          }
        }
      } else {
        checkLimit(0, 0, start, fadeTransition);
        checkLimit(1, 1, end, fadeTransition);
        itemSizes.current.forEach(setAriaVisible);
      }
      let newNumPages = Math.ceil(targetLength / containerLength);
      if (!isNaN(newNumPages)) {
        if (newNumPages / numItems > 0.65)
          newNumPages = numItems;
        if (newNumPages !== numPages)
          setNumPages(newNumPages);
      }
    }, [numPages]), useCallback2(() => {
      if (!carouselRef.current)
        return;
      itemSizes.current = Array.from(carouselRef.current.children).map((element) => {
        return axis ? { element, start: element.offsetLeft, end: element.offsetLeft + element.offsetWidth } : { element, start: element.offsetTop, end: element.offsetTop + element.offsetHeight };
      });
    }, []));
  }
  if (isCanvas) {
    useEffect7(() => {
      baseWidth.set(fadeWidth);
    }, [fadeWidth]);
    useEffect7(() => {
      startMaskInset.set(fadeInset * 0.5);
    }, [fadeInset]);
    useEffect7(() => {
      direction.set(axis ? "right" : "bottom");
    }, [axis]);
  }
  const isReducedMotion = useReducedMotion();
  const goto = (scrollTo) => {
    targetScroll.current = scrollTo;
    const options = axis ? { left: scrollTo } : { top: scrollTo };
    carouselRef.current.scrollTo({ ...options, behavior: isReducedMotion ? "auto" : "smooth" });
  };
  const gotoPage = (page, adjustment = 0) => {
    if (!scrollInfo.current)
      return;
    const { scrollLength } = scrollInfo.current;
    const totalLen = scrollLength / (numPages - 1);
    goto((page * totalLen + adjustment * totalLen) * directionModifier);
  };
  const gotoDelta = (delta) => () => {
    if (!scrollInfo.current)
      return;
    const { containerLength, scrollLength } = scrollInfo.current;
    const current = currentScroll.get() * directionModifier;
    const pageLength = scrollLength / numPages;
    const currentPage = clamp(0, numPages - 1, Math.floor(current / pageLength));
    let adjustment = 0;
    if (snap && (snapEdge === "start" || snapEdge === "end") && delta >= 1)
      adjustment = 0.4;
    gotoPage(currentPage + delta, adjustment);
  };
  if (numItems === 0) {
    return /* @__PURE__ */ _jsx(Placeholder, {});
  }
  const dots = [];
  const dotsBlurStyle = {};
  if (numPages > 1 && showProgressDots && !showScrollbar) {
    for (let i = 0; i < numPages; i++) {
      const isSelected = isCanvas && !i || false;
      dots.push(/* @__PURE__ */ _jsx(Dot, { dotStyle: { ...dotStyle, width: dotSize, height: dotSize, backgroundColor: dotsFill }, buttonStyle: baseButtonStyles, isSelected, selectedOpacity: dotsActiveOpacity, opacity: dotsOpacity, onClick: () => startTransition(() => gotoPage(i)), currentScroll, scrollInfo, total: numPages, index: i, gap: dotsGap, padding: dotsPadding, axis, directionModifier }));
    }
    if (dotsBlur) {
      dotsBlurStyle.backdropFilter = dotsBlurStyle.WebkitBackdropFilter = `blur(${dotsBlur}px)`;
    }
  }
  const leftArrowSrc = leftArrow || "https://framerusercontent.com/images/6tTbkXggWgQCAJ4DO2QEdXXmgM.svg";
  const rightArrowSrc = rightArrow || "https://framerusercontent.com/images/11KSGbIZoRSg4pjdnUoif6MKHI.svg";
  return /* @__PURE__ */ _jsxs("section", { style: containerStyle, ...carouselA11y, children: [/* @__PURE__ */ _jsx(motion.ul, { ref: carouselRef, style: carouselStyle, className: "framer--carousel", "data-show-scrollbar": showScrollbar, "aria-atomic": "false", "aria-live": "polite", onWheel: () => targetScroll.current = void 0, children: Children.map(filteredSlots, (child, index) => /* @__PURE__ */ _jsx(AutoIdLayoutGroup, { inherit: "id", children: /* @__PURE__ */ _jsx("li", { style: itemStyle, ...itemA11y, "aria-label": `${index + 1} of ${numItems}`, children: /* @__PURE__ */ cloneElement(child, { ...child.props, style: { ...child.props?.style, ...childStyle } }) }) })) }), /* @__PURE__ */ _jsxs("fieldset", { style: { ...controlsStyles, padding: arrowPadding, display: "flex", flexDirection: axis ? "row" : "column" }, "aria-label": "Carousel pagination controls", className: "framer--carousel-controls", "data-show-mouse-controls": showMouseControls, children: [
    // isMouseDevice &&
    /* @__PURE__ */ _jsx(motion.button, { ref: start.buttonRef, type: "button", style: { ...start.buttonStyle, backgroundColor: arrowFill, width: arrowSize, height: arrowSize, borderRadius: arrowRadius, rotate: !axis ? 90 : 0, display: showMouseControls ? "block" : "none" }, onClick: gotoDelta(-1), "aria-label": "Previous", whileTap: { scale: 0.9 }, transition: { duration: 0.05 }, children: /* @__PURE__ */ _jsx("img", { decoding: "async", alt: "", width: arrowSize, height: arrowSize, src: writingDirection === "rtl" && axis ? rightArrowSrc : leftArrowSrc }) }),
    // isMouseDevice &&
    /* @__PURE__ */ _jsx(motion.button, { ref: end.buttonRef, type: "button", style: { ...end.buttonStyle, backgroundColor: arrowFill, width: arrowSize, height: arrowSize, borderRadius: arrowRadius, rotate: !axis ? 90 : 0, display: showMouseControls ? "block" : "none" }, onClick: gotoDelta(1), "aria-label": "Next", whileTap: { scale: 0.9 }, transition: { duration: 0.05 }, children: /* @__PURE__ */ _jsx("img", { decoding: "async", alt: "", width: arrowSize, height: arrowSize, src: writingDirection === "rtl" && axis ? leftArrowSrc : rightArrowSrc }) }),
    dots.length > 1 ? /* @__PURE__ */ _jsx("div", { style: { ...dotsContainerStyle, left: axis ? "50%" : dotsInset, top: !axis ? "50%" : "unset", transform: axis ? "translateX(-50%)" : "translateY(-50%)", flexDirection: axis ? "row" : "column", bottom: axis ? dotsInset : "unset", borderRadius: dotsRadius, backgroundColor: dotsBackground, ...dotsBlurStyle }, children: dots }) : null
  ] }), /* @__PURE__ */ _jsx(MouseStyles, {})] });
}
Carousel.defaultProps = { gap: 10, padding: 10, progressObject: { showScrollbar: false, showProgressDots: false }, sizingObject: { widthType: "auto", widthOffset: 0, widthColumns: 2, heightType: "auto", heightOffset: 0, heightRows: 2 }, borderRadius: 0 };
addPropertyControls(Carousel, { slots: { type: ControlType4.Array, title: "Children", control: { type: ControlType4.ComponentInstance } }, axis: { type: ControlType4.Enum, title: "Direction", options: [true, false], optionIcons: ["direction-horizontal", "direction-vertical"], displaySegmentedControl: true }, align: { type: ControlType4.Enum, title: "Align", options: ["flex-start", "center", "flex-end"], optionIcons: { axis: { true: ["align-top", "align-middle", "align-bottom"], false: ["align-left", "align-center", "align-right"] } }, defaultValue: "center", displaySegmentedControl: true }, gap: { type: ControlType4.Number, title: "Gap" }, ...paddingControl, sizingObject: { type: ControlType4.Object, title: "Sizing", controls: { widthType: { type: ControlType4.Enum, title: "Width", options: ["auto", "stretch", "columns"], optionTitles: ["Auto", "Stretch", "Columns"], defaultValue: "auto" }, widthInset: { type: ControlType4.Number, title: "Inset", min: 0, max: 500, defaultValue: 0, hidden: (props) => props.widthType !== "stretch" }, widthColumns: { type: ControlType4.Number, title: "Columns", min: 1, max: 10, defaultValue: 2, displayStepper: true, hidden: (props) => props.widthType !== "columns" }, heightType: { type: ControlType4.Enum, title: "Height", options: ["auto", "stretch", "rows"], optionTitles: ["Auto", "Stretch", "Rows"], defaultValue: "auto" }, heightInset: { type: ControlType4.Number, title: "Inset", min: 0, max: 500, defaultValue: 0, hidden: (props) => props.heightType !== "stretch" }, heightRows: { type: ControlType4.Number, title: "Rows", min: 1, max: 10, defaultValue: 2, displayStepper: true, hidden: (props) => props.heightType !== "rows" } } }, snapObject: { type: ControlType4.Object, title: "Snapping", controls: { snap: { type: ControlType4.Boolean, title: "Enable" }, snapEdge: { type: ControlType4.Enum, title: "Edge", options: ["start", "center", "end"], optionTitles: ["Left", "Center", "Right"], defaultValue: "center", hidden: (props) => !props.snap }, fluid: { type: ControlType4.Boolean, title: "Fluid", defaultValue: false, hidden: (props) => !props.snap } } }, fadeObject: { type: ControlType4.Object, title: "Fading", controls: { fadeContent: { type: ControlType4.Boolean, title: "Enable", defaultValue: false }, fadeWidth: { type: ControlType4.Number, title: "Width", defaultValue: 25, min: 0, max: 100, unit: "%", hidden: (props) => !props.fadeContent }, fadeInset: { type: ControlType4.Number, title: "Inset", defaultValue: 0, min: 0, max: 100, unit: "%", hidden: (props) => !props.fadeContent }, fadeAlpha: { type: ControlType4.Number, title: "Opacity", hidden: (props) => !props.fadeContent, min: 0, max: 1, step: 0.05, defaultValue: 0 }, fadeTransition: { type: ControlType4.Transition, title: "Transition", hidden: (props) => !props.fadeContent } } }, progressObject: { type: ControlType4.Object, title: "Progress", controls: { showScrollbar: { type: ControlType4.Boolean, title: "Scroll Bar", defaultValue: false }, showProgressDots: { type: ControlType4.Boolean, title: "Dots", defaultValue: false, hidden: (props) => props.showScrollbar }, dotSize: { type: ControlType4.Number, title: "Size", min: 1, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsInset: { type: ControlType4.Number, title: "Inset", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsGap: { type: ControlType4.Number, title: "Gap", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsPadding: { type: ControlType4.Number, title: "Padding", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsFill: { type: ControlType4.Color, title: "Fill", defaultValue: "#fff", hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsBackground: { type: ControlType4.Color, title: "Backdrop", defaultValue: "rgba(0,0,0,0.2)", hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsRadius: { type: ControlType4.Number, title: "Radius", min: 0, max: 200, defaultValue: 50, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsOpacity: { type: ControlType4.Number, title: "Opacity", min: 0, max: 1, defaultValue: 0.5, step: 0.1, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsActiveOpacity: { type: ControlType4.Number, title: "Current", min: 0, max: 1, defaultValue: 1, step: 0.1, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsBlur: { type: ControlType4.Number, title: "Blur", min: 0, max: 50, defaultValue: 4, step: 1, hidden: (props) => !props.showProgressDots || props.showScrollbar } } }, arrowObject: { type: ControlType4.Object, title: "Arrows", controls: { showMouseControls: { type: ControlType4.Boolean, title: "Show", defaultValue: true }, arrowFill: { type: ControlType4.Color, title: "Fill", defaultValue: "rgba(0,0,0,0.2)", hidden: (props) => !props.showMouseControls }, leftArrow: { type: ControlType4.Image, title: "Previous", hidden: (props) => !props.showMouseControls }, rightArrow: { type: ControlType4.Image, title: "Next", hidden: (props) => !props.showMouseControls }, arrowSize: { type: ControlType4.Number, title: "Size", min: 0, max: 200, displayStepper: true, defaultValue: 40, hidden: (props) => !props.showMouseControls }, arrowRadius: { type: ControlType4.Number, title: "Radius", min: 0, max: 500, defaultValue: 40, hidden: (props) => !props.showMouseControls }, arrowPadding: { type: ControlType4.Number, title: "Inset", min: 0, max: 100, defaultValue: 20, displayStepper: true, hidden: (props) => !props.showMouseControls } } }, ariaLabel: { type: ControlType4.String, title: "Aria Label", placeholder: "Movies..." }, borderRadius: { type: ControlType4.Number, title: "Radius", min: 0, max: 500, displayStepper: true, defaultValue: 0 } });
function Dot({ currentScroll, scrollInfo, isSelected, selectedOpacity, opacity: unselectedOpacity, total, index, dotStyle: dotStyle2, buttonStyle, gap, padding, axis, directionModifier, ...props }) {
  const opacity = useTransform(currentScroll, (v) => {
    if (!scrollInfo.current?.scrollLength) {
      return index === 0 ? selectedOpacity : unselectedOpacity;
    }
    const currentScroll2 = v * directionModifier;
    const pageLength = scrollInfo.current?.scrollLength / total;
    const minScroll = pageLength * index;
    const maxScroll = minScroll + pageLength;
    const isSelected2 = currentScroll2 >= minScroll && (index < total - 1 ? currentScroll2 < maxScroll : index === total - 1);
    return isSelected2 ? selectedOpacity : unselectedOpacity;
  });
  const inlinePadding = gap / 2;
  let top = !axis && index > 0 ? inlinePadding : padding;
  let bottom = !axis && index !== total - 1 ? inlinePadding : padding;
  let right = axis && index !== total - 1 ? inlinePadding : padding;
  let left = axis && index > 0 ? inlinePadding : padding;
  return /* @__PURE__ */ _jsx("button", { "aria-label": `Scroll to page ${index + 1}`, type: "button", ...props, style: { ...buttonStyle, padding: `${top}px ${right}px ${bottom}px ${left}px` }, children: /* @__PURE__ */ _jsx(motion.div, { style: { ...dotStyle2, opacity } }) });
}
function Placeholder() {
  return /* @__PURE__ */ _jsxs("section", { style: placeholderStyles, children: [/* @__PURE__ */ _jsx("div", { style: emojiStyles, children: "\u2728" }), /* @__PURE__ */ _jsx("p", { style: titleStyles, children: "Connect to Content" }), /* @__PURE__ */ _jsx("p", { style: subtitleStyles, children: "Add layers or components to swipe between." })] });
}
function MouseStyles() {
  return /* @__PURE__ */ _jsx("div", { dangerouslySetInnerHTML: { __html: `<style>@media (pointer: fine) {
                .framer--carousel[data-show-scrollbar="false"]::-webkit-scrollbar {
                    display: none;
                    -webkit-appearance: none;
                    width: 0;
                    height: 0;
                }

                .framer--carousel[data-show-scrollbar="false"]::-webkit-scrollbar-thumb {
                    display: none;
                }

                .framer--carousel[data-show-scrollbar="false"] {
                    scrollbar-width: none;
                    scrollbar-height: none;
                }
            }</style>` } });
}
var placeholderStyles = { display: "flex", width: "100%", height: "100%", placeContent: "center", placeItems: "center", flexDirection: "column", color: "#96F", background: "rgba(136, 85, 255, 0.1)", fontSize: 11, overflow: "hidden", padding: "20px 20px 30px 20px" };
var emojiStyles = { fontSize: 32, marginBottom: 10 };
var titleStyles = { margin: 0, marginBottom: 10, fontWeight: 600, textAlign: "center" };
var subtitleStyles = { margin: 0, opacity: 0.7, maxWidth: 130, lineHeight: 1.5, textAlign: "center" };
var baseContainerStyle = { display: "flex", overflow: "hidden", width: "100%", height: "100%", position: "relative" };
var baseCarouselStyle = { padding: 0, margin: 0, listStyle: "none", position: "relative", display: "flex", flex: "1 1 100%", width: "100%", height: "100%" };
var baseButtonStyles = { border: "none", display: "flex", placeContent: "center", placeItems: "center", overflow: "hidden", background: "transparent", cursor: "pointer", margin: 0, padding: 0 };
var controlsStyles = { display: "flex", justifyContent: "space-between", alignItems: "center", position: "absolute", top: 0, left: 0, right: 0, bottom: 0, pointerEvents: "none", border: 0, padding: 0, margin: 0 };
var dotsContainerStyle = { display: "flex", placeContent: "center", placeItems: "center", overflow: "hidden", position: "absolute", pointerEvents: "auto" };
var dotStyle = { borderRadius: "50%", background: "white", cursor: "pointer", border: "none", placeContent: "center", placeItems: "center", padding: 0 };
function useWritingDirection() {
  const [writingDirection, setWritingDirection] = useState3("ltr");
  useEffect7(() => {
    if (__dai_window?.document?.documentElement?.dir === "rtl") {
      setWritingDirection("rtl");
    }
  }, []);
  return writingDirection;
}
function AutoIdLayoutGroup({ children, ...props }) {
  const id = useId();
  return /* @__PURE__ */ _jsx(LayoutGroup, { id, ...props, children });
}

// http-url:https://framerusercontent.com/modules/wm83w8Ounl6dPhQAuYBm/RLDN5EfVhNSO3xwIZj0M/cAWq5iJ2z.js
import { jsx as _jsx4, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ComponentViewportProvider, ControlType as ControlType7, cx, getFonts, getFontsFromSharedStyle, getLoadingLazyAtYPosition, Image, RichText, SmartComponentScopedContainer, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion3, MotionConfigContext } from "framer-motion";
import * as React5 from "react";
import { useRef as useRef5 } from "react";

// http-url:https://framerusercontent.com/modules/tYScH7LTqUtz5KUaUAYP/p8dptk4UIND8hbFWz9V7/Phosphor.js
import { jsx as _jsx3 } from "react/jsx-runtime";
import * as React4 from "react";
import { useState as useState4, useEffect as useEffect8, useRef as useRef4 } from "react";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType6, RenderTarget as RenderTarget4 } from "./_framer-runtime.js";
import { motion as motion2 } from "framer-motion";

// http-url:https://framerusercontent.com/modules/DyldKav0OOAWR3bCAlhK/8c3l9FzyOlGpbPncYhfc/nullstate.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import * as React3 from "react";
var containerStyles2 = {
  width: "100%",
  height: "100%",
  display: "flex",
  justifyContent: "center",
  alignItems: "center"
};
var emptyStateStyle2 = {
  ...containerStyles2,
  borderRadius: 6,
  background: "rgba(149, 149, 149, 0.1)",
  border: "1px dashed rgba(149, 149, 149, 0.15)",
  color: "#a5a5a5",
  flexDirection: "column"
};
var NullState = /* @__PURE__ */ React3.forwardRef((_, ref) => {
  return /* @__PURE__ */ _jsx2("div", {
    style: emptyStateStyle2,
    ref
  });
});

// http-url:https://framerusercontent.com/modules/Qc8yuHkQmGO0kFiSWbkX/rVmMAFttOHuuiwSg6KjZ/House.js
var Component;
var IconInner;
var Icon = (React7) => {
  if (!Component) {
    Component = /* @__PURE__ */ new Map([
      [
        "bold",
        /* @__PURE__ */ React7.createElement(React7.Fragment, null, /* @__PURE__ */ React7.createElement("path", { d: "M222.14,105.85l-80-80a20,20,0,0,0-28.28,0l-80,80A19.86,19.86,0,0,0,28,120v96a12,12,0,0,0,12,12h64a12,12,0,0,0,12-12V164h24v52a12,12,0,0,0,12,12h64a12,12,0,0,0,12-12V120A19.86,19.86,0,0,0,222.14,105.85ZM204,204H164V152a12,12,0,0,0-12-12H104a12,12,0,0,0-12,12v52H52V121.65l76-76,76,76Z" }))
      ],
      [
        "duotone",
        /* @__PURE__ */ React7.createElement(React7.Fragment, null, /* @__PURE__ */ React7.createElement(
          "path",
          {
            d: "M216,120v96H152V152H104v64H40V120a8,8,0,0,1,2.34-5.66l80-80a8,8,0,0,1,11.32,0l80,80A8,8,0,0,1,216,120Z",
            opacity: "0.2"
          }
        ), /* @__PURE__ */ React7.createElement("path", { d: "M219.31,108.68l-80-80a16,16,0,0,0-22.62,0l-80,80A15.87,15.87,0,0,0,32,120v96a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V160h32v56a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V120A15.87,15.87,0,0,0,219.31,108.68ZM208,208H160V152a8,8,0,0,0-8-8H104a8,8,0,0,0-8,8v56H48V120l80-80,80,80Z" }))
      ],
      [
        "fill",
        /* @__PURE__ */ React7.createElement(React7.Fragment, null, /* @__PURE__ */ React7.createElement("path", { d: "M224,120v96a8,8,0,0,1-8,8H160a8,8,0,0,1-8-8V164a4,4,0,0,0-4-4H108a4,4,0,0,0-4,4v52a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V120a16,16,0,0,1,4.69-11.31l80-80a16,16,0,0,1,22.62,0l80,80A16,16,0,0,1,224,120Z" }))
      ],
      [
        "light",
        /* @__PURE__ */ React7.createElement(React7.Fragment, null, /* @__PURE__ */ React7.createElement("path", { d: "M217.9,110.1l-80-80a14,14,0,0,0-19.8,0l-80,80A13.92,13.92,0,0,0,34,120v96a6,6,0,0,0,6,6h64a6,6,0,0,0,6-6V158h36v58a6,6,0,0,0,6,6h64a6,6,0,0,0,6-6V120A13.92,13.92,0,0,0,217.9,110.1ZM210,210H158V152a6,6,0,0,0-6-6H104a6,6,0,0,0-6,6v58H46V120a2,2,0,0,1,.58-1.42l80-80a2,2,0,0,1,2.84,0l80,80A2,2,0,0,1,210,120Z" }))
      ],
      [
        "regular",
        /* @__PURE__ */ React7.createElement(React7.Fragment, null, /* @__PURE__ */ React7.createElement("path", { d: "M219.31,108.68l-80-80a16,16,0,0,0-22.62,0l-80,80A15.87,15.87,0,0,0,32,120v96a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V160h32v56a8,8,0,0,0,8,8h64a8,8,0,0,0,8-8V120A15.87,15.87,0,0,0,219.31,108.68ZM208,208H160V152a8,8,0,0,0-8-8H104a8,8,0,0,0-8,8v56H48V120l80-80,80,80Z" }))
      ],
      [
        "thin",
        /* @__PURE__ */ React7.createElement(React7.Fragment, null, /* @__PURE__ */ React7.createElement("path", { d: "M216.49,111.51l-80-80a12,12,0,0,0-17,0l-80,80A12,12,0,0,0,36,120v96a4,4,0,0,0,4,4h64a4,4,0,0,0,4-4V156h40v60a4,4,0,0,0,4,4h64a4,4,0,0,0,4-4V120A12,12,0,0,0,216.49,111.51ZM212,212H156V152a4,4,0,0,0-4-4H104a4,4,0,0,0-4,4v60H44V120a4,4,0,0,1,1.17-2.83l80-80a4,4,0,0,1,5.66,0l80,80A4,4,0,0,1,212,120Z" }))
      ]
    ]);
    IconInner = React7.forwardRef((props, ref) => /* @__PURE__ */ React7.createElement("g", { ref, ...props }, Component.get(props.weight)));
  }
  return IconInner;
};
var House_default = Icon;

// http-url:https://framerusercontent.com/modules/Ma20hU0GGRxLxZphbywl/OSpwWF91FHPVFyQJjMHt/utils.js
import { useMemo as useMemo4 } from "react";
import { ControlType as ControlType5 } from "./_framer-runtime.js";
var defaultEvents2 = { onClick: { type: ControlType5.EventHandler }, onMouseDown: { type: ControlType5.EventHandler }, onMouseUp: { type: ControlType5.EventHandler }, onMouseEnter: { type: ControlType5.EventHandler }, onMouseLeave: { type: ControlType5.EventHandler } };
var findByArray = (arr, search) => arr.find((a) => a.toLowerCase().includes(search));
function useIconSelection(iconKeys2, selectByList, iconSearch = "", iconSelection, lowercaseIconKeyPairs2) {
  const iconSearchResult = useMemo4(() => {
    if (iconSearch == null || (iconSearch === null || iconSearch === void 0 ? void 0 : iconSearch.length) === 0)
      return null;
    const iconSearchTerm = iconSearch.toLowerCase().replace(/-|\s/g, "");
    var _iconSearchTerm;
    const searchResult = (_iconSearchTerm = lowercaseIconKeyPairs2[iconSearchTerm]) !== null && _iconSearchTerm !== void 0 ? _iconSearchTerm : findByArray(iconKeys2, iconSearchTerm);
    return searchResult;
  }, [iconSelection, iconSearch]);
  const name = selectByList ? iconSelection : iconSearchResult;
  return name;
}

// http-url:https://framerusercontent.com/modules/tYScH7LTqUtz5KUaUAYP/p8dptk4UIND8hbFWz9V7/Phosphor.js
var iconKeys = ["Acorn", "AddressBook", "AddressBookTabs", "AirTrafficControl", "Airplane", "AirplaneInFlight", "AirplaneLanding", "AirplaneTakeoff", "AirplaneTaxiing", "AirplaneTilt", "Airplay", "Alarm", "Alien", "AlignBottom", "AlignBottomSimple", "AlignCenterVertical", "AlignLeft", "AlignLeftSimple", "AlignRight", "AlignRightSimple", "AlignTop", "AlignTopSimple", "AmazonLogo", "Ambulance", "Anchor", "AnchorSimple", "AndroidLogo", "Angle", "AngularLogo", "Aperture", "AppStoreLogo", "AppWindow", "AppleLogo", "ApplePodcastsLogo", "ApproximateEquals", "Archive", "ArchiveBox", "ArchiveTray", "Armchair", "ArrowArcLeft", "ArrowArcRight", "ArrowBendDownLeft", "ArrowBendDownRight", "ArrowBendLeftDown", "ArrowBendLeftUp", "ArrowBendRightDown", "ArrowBendRightUp", "ArrowBendUpLeft", "ArrowBendUpRight", "ArrowCircleDown", "ArrowCircleDownLeft", "ArrowCircleDownRight", "ArrowCircleLeft", "ArrowCircleRight", "ArrowCircleUp", "ArrowCircleUpLeft", "ArrowCircleUpRight", "ArrowClockwise", "ArrowDown", "ArrowDownLeft", "ArrowDownRight", "ArrowElbowDownLeft", "ArrowElbowDownRight", "ArrowElbowLeft", "ArrowElbowLeftDown", "ArrowElbowLeftUp", "ArrowElbowRight", "ArrowElbowRightDown", "ArrowElbowRightUp", "ArrowElbowUpLeft", "ArrowElbowUpRight", "ArrowFatDown", "ArrowFatLeft", "ArrowFatLineDown", "ArrowFatLineLeft", "ArrowFatLineRight", "ArrowFatLineUp", "ArrowFatLinesDown", "ArrowFatLinesLeft", "ArrowFatLinesRight", "ArrowFatLinesUp", "ArrowFatRight", "ArrowFatUp", "ArrowLeft", "ArrowLineDown", "ArrowLineDownLeft", "ArrowLineDownRight", "ArrowLineLeft", "ArrowLineRight", "ArrowLineUp", "ArrowLineUpLeft", "ArrowLineUpRight", "ArrowRight", "ArrowSquareDown", "ArrowSquareDownLeft", "ArrowSquareDownRight", "ArrowSquareIn", "ArrowSquareLeft", "ArrowSquareOut", "ArrowSquareRight", "ArrowSquareUp", "ArrowSquareUpLeft", "ArrowSquareUpRight", "ArrowUDownLeft", "ArrowUDownRight", "ArrowULeftDown", "ArrowULeftUp", "ArrowURightDown", "ArrowURightUp", "ArrowUUpLeft", "ArrowUUpRight", "ArrowUp", "ArrowUpLeft", "ArrowUpRight", "ArrowsClockwise", "ArrowsDownUp", "ArrowsHorizontal", "ArrowsIn", "ArrowsInCardinal", "ArrowsInLineVertical", "ArrowsInSimple", "ArrowsLeftRight", "ArrowsMerge", "ArrowsOut", "ArrowsOutCardinal", "ArrowsOutSimple", "ArrowsSplit", "ArrowsVertical", "Article", "ArticleMedium", "ArticleNyTimes", "Asclepius", "Asterisk", "AsteriskSimple", "At", "Atom", "Avocado", "Axe", "Baby", "BabyCarriage", "Backpack", "Backspace", "Bag", "BagSimple", "Balloon", "Bandaids", "Bank", "Barbell", "Barcode", "Barn", "Barricade", "Baseball", "BaseballCap", "BaseballHelmet", "Basket", "Basketball", "Bathtub", "BatteryCharging", "BatteryEmpty", "BatteryFull", "BatteryHigh", "BatteryLow", "BatteryMedium", "BatteryPlus", "BatteryPlusVertical", "BatteryVerticalEmpty", "BatteryVerticalFull", "BatteryVerticalHigh", "BatteryVerticalLow", "BatteryWarning", "BeachBall", "Beanie", "Bed", "BeerBottle", "BeerStein", "BehanceLogo", "Bell", "BellRinging", "BellSimple", "BellSimpleRinging", "BellSimpleSlash", "BellSimpleZ", "BellSlash", "BellZ", "Belt", "BezierCurve", "Bicycle", "Binary", "Binoculars", "Biohazard", "Bird", "Blueprint", "Bluetooth", "BluetoothConnected", "BluetoothSlash", "BluetoothX", "Boat", "Bomb", "Bone", "Book", "BookBookmark", "BookOpen", "BookOpenText", "BookOpenUser", "BookUser", "Bookmark", "BookmarkSimple", "Bookmarks", "BookmarksSimple", "Books", "Boot", "Boules", "BoundingBox", "BowlFood", "BowlSteam", "BowlingBall", "BoxArrowDown", "BoxArrowUp", "BoxingGlove", "BracketsAngle", "BracketsCurly", "BracketsRound", "BracketsSquare", "Brain", "Brandy", "Bread", "Bridge", "Briefcase", "BriefcaseMetal", "Broadcast", "Broom", "Browser", "Browsers", "Bug", "BugBeetle", "BugDroid", "Building", "BuildingApartment", "BuildingOffice", "Buildings", "Bulldozer", "Bus", "Butterfly", "CableCar", "Cactus", "Cake", "Calculator", "Calendar", "CalendarBlank", "CalendarCheck", "CalendarDot", "CalendarDots", "CalendarHeart", "CalendarMinus", "CalendarPlus", "CalendarSlash", "CalendarStar", "CalendarX", "CallBell", "Camera", "CameraPlus", "CameraRotate", "CameraSlash", "Campfire", "Car", "CarBattery", "CarProfile", "CarSimple", "Cardholder", "Cards", "CardsThree", "CaretCircleDoubleUp", "CaretCircleDown", "CaretCircleLeft", "CaretCircleRight", "CaretCircleUp", "CaretCircleUpDown", "CaretDoubleDown", "CaretDoubleLeft", "CaretDoubleRight", "CaretDoubleUp", "CaretDown", "CaretLeft", "CaretLineDown", "CaretLineLeft", "CaretLineRight", "CaretLineUp", "CaretRight", "CaretUp", "CaretUpDown", "Carrot", "CashRegister", "CassetteTape", "CastleTurret", "Cat", "CellSignalFull", "CellSignalHigh", "CellSignalLow", "CellSignalMedium", "CellSignalNone", "CellSignalSlash", "CellSignalX", "CellTower", "Certificate", "Chair", "Chalkboard", "ChalkboardSimple", "ChalkboardTeacher", "Champagne", "ChargingStation", "ChartBar", "ChartBarHorizontal", "ChartDonut", "ChartLine", "ChartLineDown", "ChartLineUp", "ChartPie", "ChartPieSlice", "ChartPolar", "ChartScatter", "Chat", "ChatCentered", "ChatCenteredDots", "ChatCenteredSlash", "ChatCenteredText", "ChatCircle", "ChatCircleDots", "ChatCircleSlash", "ChatCircleText", "ChatDots", "ChatSlash", "ChatTeardrop", "ChatTeardropDots", "ChatTeardropSlash", "ChatTeardropText", "ChatText", "Chats", "ChatsCircle", "ChatsTeardrop", "Check", "CheckCircle", "CheckFat", "CheckSquare", "CheckSquareOffset", "Checkerboard", "Checks", "Cheers", "Cheese", "ChefHat", "Cherries", "Church", "Cigarette", "CigaretteSlash", "Circle", "CircleDashed", "CircleHalf", "CircleHalfTilt", "CircleNotch", "CirclesFour", "CirclesThree", "CirclesThreePlus", "Circuitry", "City", "Clipboard", "ClipboardText", "Clock", "ClockAfternoon", "ClockClockwise", "ClockCountdown", "ClockUser", "ClosedCaptioning", "Cloud", "CloudArrowDown", "CloudArrowUp", "CloudCheck", "CloudFog", "CloudLightning", "CloudMoon", "CloudRain", "CloudSlash", "CloudSnow", "CloudSun", "CloudWarning", "CloudX", "Clover", "Club", "CoatHanger", "CodaLogo", "Code", "CodeBlock", "CodeSimple", "CodepenLogo", "CodesandboxLogo", "Coffee", "CoffeeBean", "Coin", "CoinVertical", "Coins", "Columns", "ColumnsPlusLeft", "ColumnsPlusRight", "Command", "Compass", "CompassRose", "CompassTool", "ComputerTower", "Confetti", "ContactlessPayment", "Control", "Cookie", "CookingPot", "Copy", "CopySimple", "Copyleft", "Copyright", "CornersIn", "CornersOut", "Couch", "CourtBasketball", "Cow", "CowboyHat", "Cpu", "Crane", "CraneTower", "CreditCard", "Cricket", "Crop", "Cross", "Crosshair", "CrosshairSimple", "Crown", "CrownCross", "CrownSimple", "Cube", "CubeFocus", "CubeTransparent", "CurrencyBtc", "CurrencyCircleDollar", "CurrencyCny", "CurrencyDollar", "CurrencyDollarSimple", "CurrencyEth", "CurrencyEur", "CurrencyGbp", "CurrencyInr", "CurrencyJpy", "CurrencyKrw", "CurrencyKzt", "CurrencyNgn", "CurrencyRub", "Cursor", "CursorClick", "CursorText", "Cylinder", "Database", "Desk", "Desktop", "DesktopTower", "Detective", "DevToLogo", "DeviceMobile", "DeviceMobileCamera", "DeviceMobileSlash", "DeviceMobileSpeaker", "DeviceRotate", "DeviceTablet", "DeviceTabletCamera", "DeviceTabletSpeaker", "Devices", "Diamond", "DiamondsFour", "DiceFive", "DiceFour", "DiceOne", "DiceSix", "DiceThree", "DiceTwo", "Disc", "DiscoBall", "DiscordLogo", "Divide", "Dna", "Dog", "Door", "DoorOpen", "Dot", "DotOutline", "DotsNine", "DotsSix", "DotsSixVertical", "DotsThree", "DotsThreeCircle", "DotsThreeOutline", "DotsThreeVertical", "Download", "DownloadSimple", "Dress", "Dresser", "DribbbleLogo", "Drone", "Drop", "DropHalf", "DropHalfBottom", "DropSimple", "DropSlash", "DropboxLogo", "Ear", "EarSlash", "Egg", "EggCrack", "Eject", "EjectSimple", "Elevator", "Empty", "Engine", "Envelope", "EnvelopeOpen", "EnvelopeSimple", "EnvelopeSimpleOpen", "Equalizer", "Equals", "Eraser", "EscalatorDown", "EscalatorUp", "Exam", "ExclamationMark", "Exclude", "ExcludeSquare", "Export", "Eye", "EyeClosed", "EyeSlash", "Eyedropper", "EyedropperSample", "Eyeglasses", "Eyes", "FaceMask", "FacebookLogo", "Factory", "Faders", "FadersHorizontal", "FalloutShelter", "Fan", "Farm", "FastForward", "FastForwardCircle", "Feather", "FediverseLogo", "FigmaLogo", "File", "FileArchive", "FileArrowDown", "FileArrowUp", "FileAudio", "FileC", "FileCloud", "FileCode", "FileCpp", "FileCss", "FileCsv", "FileDashed", "FileDoc", "FileHtml", "FileImage", "FileIni", "FileJpg", "FileJs", "FileJsx", "FileLock", "FileMagnifyingGlass", "FileMd", "FileMinus", "FilePdf", "FilePlus", "FilePng", "FilePpt", "FilePy", "FileRs", "FileSql", "FileSvg", "FileText", "FileTs", "FileTsx", "FileTxt", "FileVideo", "FileVue", "FileX", "FileXls", "FileZip", "Files", "FilmReel", "FilmScript", "FilmSlate", "FilmStrip", "Fingerprint", "FingerprintSimple", "FinnTheHuman", "Fire", "FireExtinguisher", "FireSimple", "FireTruck", "FirstAid", "FirstAidKit", "Fish", "FishSimple", "Flag", "FlagBanner", "FlagBannerFold", "FlagCheckered", "FlagPennant", "Flame", "Flashlight", "Flask", "FlipHorizontal", "FlipVertical", "FloppyDisk", "FloppyDiskBack", "FlowArrow", "Flower", "FlowerLotus", "FlowerTulip", "FlyingSaucer", "Folder", "FolderDashed", "FolderLock", "FolderMinus", "FolderNotch", "FolderNotchMinus", "FolderNotchOpen", "FolderNotchPlus", "FolderOpen", "FolderPlus", "FolderSimple", "FolderSimpleDashed", "FolderSimpleLock", "FolderSimpleMinus", "FolderSimplePlus", "FolderSimpleStar", "FolderSimpleUser", "FolderStar", "FolderUser", "Folders", "Football", "FootballHelmet", "Footprints", "ForkKnife", "FourK", "FrameCorners", "FramerLogo", "Function", "Funnel", "FunnelSimple", "FunnelSimpleX", "FunnelX", "GameController", "Garage", "GasCan", "GasPump", "Gauge", "Gavel", "Gear", "GearFine", "GearSix", "GenderFemale", "GenderIntersex", "GenderMale", "GenderNeuter", "GenderNonbinary", "GenderTransgender", "Ghost", "Gif", "Gift", "GitBranch", "GitCommit", "GitDiff", "GitFork", "GitMerge", "GitPullRequest", "GithubLogo", "GitlabLogo", "GitlabLogoSimple", "Globe", "GlobeHemisphereEast", "GlobeHemisphereWest", "GlobeSimple", "GlobeSimpleX", "GlobeStand", "GlobeX", "Goggles", "Golf", "GoodreadsLogo", "GoogleCardboardLogo", "GoogleChromeLogo", "GoogleDriveLogo", "GoogleLogo", "GooglePhotosLogo", "GooglePlayLogo", "GooglePodcastsLogo", "Gps", "GpsFix", "GpsSlash", "Gradient", "GraduationCap", "Grains", "GrainsSlash", "Graph", "GraphicsCard", "GreaterThan", "GreaterThanOrEqual", "GridFour", "GridNine", "Guitar", "HairDryer", "Hamburger", "Hammer", "Hand", "HandArrowDown", "HandArrowUp", "HandCoins", "HandDeposit", "HandEye", "HandFist", "HandGrabbing", "HandHeart", "HandPalm", "HandPeace", "HandPointing", "HandSoap", "HandSwipeLeft", "HandSwipeRight", "HandTap", "HandWaving", "HandWithdraw", "Handbag", "HandbagSimple", "HandsClapping", "HandsPraying", "Handshake", "HardDrive", "HardDrives", "HardHat", "Hash", "HashStraight", "HeadCircuit", "Headlights", "Headphones", "Headset", "Heart", "HeartBreak", "HeartHalf", "HeartStraight", "HeartStraightBreak", "Heartbeat", "Hexagon", "HighDefinition", "HighHeel", "Highlighter", "HighlighterCircle", "Hockey", "Hoodie", "Horse", "Hospital", "Hourglass", "HourglassHigh", "HourglassLow", "HourglassMedium", "HourglassSimple", "HourglassSimpleHigh", "HourglassSimpleLow", "House", "HouseLine", "HouseSimple", "Hurricane", "IceCream", "IdentificationBadge", "IdentificationCard", "Image", "ImageBroken", "ImageSquare", "Images", "ImagesSquare", "Infinity", "Info", "InstagramLogo", "Intersect", "IntersectSquare", "IntersectThree", "Intersection", "Invoice", "Island", "Jar", "JarLabel", "Jeep", "Joystick", "Kanban", "Key", "KeyReturn", "Keyboard", "Keyhole", "Knife", "Ladder", "LadderSimple", "Lamp", "LampPendant", "Laptop", "Lasso", "LastfmLogo", "Layout", "Leaf", "Lectern", "Lego", "LegoSmiley", "LessThan", "LessThanOrEqual", "LetterCircleH", "LetterCircleP", "LetterCircleV", "Lifebuoy", "Lightbulb", "LightbulbFilament", "Lighthouse", "Lightning", "LightningA", "LightningSlash", "LineSegment", "LineSegments", "LineVertical", "Link", "LinkBreak", "LinkSimple", "LinkSimpleBreak", "LinkSimpleHorizontal", "LinkedinLogo", "LinktreeLogo", "LinuxLogo", "List", "ListBullets", "ListChecks", "ListDashes", "ListHeart", "ListMagnifyingGlass", "ListNumbers", "ListPlus", "ListStar", "Lock", "LockKey", "LockKeyOpen", "LockLaminated", "LockLaminatedOpen", "LockOpen", "LockSimple", "LockSimpleOpen", "Lockers", "Log", "MagicWand", "Magnet", "MagnetStraight", "MagnifyingGlass", "MagnifyingGlassMinus", "MagnifyingGlassPlus", "Mailbox", "MapPin", "MapPinArea", "MapPinLine", "MapPinPlus", "MapPinSimple", "MapPinSimpleArea", "MapPinSimpleLine", "MapTrifold", "MarkdownLogo", "MarkerCircle", "Martini", "MaskHappy", "MaskSad", "MastodonLogo", "MathOperations", "MatrixLogo", "Medal", "MedalMilitary", "MediumLogo", "Megaphone", "MegaphoneSimple", "MemberOf", "Memory", "MessengerLogo", "MetaLogo", "Meteor", "Metronome", "Microphone", "MicrophoneSlash", "MicrophoneStage", "Microscope", "MicrosoftExcelLogo", "MicrosoftOutlookLogo", "MicrosoftTeamsLogo", "MicrosoftWordLogo", "Minus", "MinusCircle", "MinusSquare", "Money", "MoneyWavy", "Monitor", "MonitorArrowUp", "MonitorPlay", "Moon", "MoonStars", "Moped", "MopedFront", "Mosque", "Motorcycle", "Mountains", "Mouse", "MouseLeftClick", "MouseMiddleClick", "MouseRightClick", "MouseScroll", "MouseSimple", "MusicNote", "MusicNoteSimple", "MusicNotes", "MusicNotesMinus", "MusicNotesPlus", "MusicNotesSimple", "NavigationArrow", "Needle", "Network", "NetworkSlash", "NetworkX", "Newspaper", "NewspaperClipping", "NotEquals", "NotMemberOf", "NotSubsetOf", "NotSupersetOf", "Notches", "Note", "NoteBlank", "NotePencil", "Notebook", "Notepad", "Notification", "NotionLogo", "NuclearPlant", "NumberCircleEight", "NumberCircleFive", "NumberCircleFour", "NumberCircleNine", "NumberCircleOne", "NumberCircleSeven", "NumberCircleSix", "NumberCircleThree", "NumberCircleTwo", "NumberCircleZero", "NumberEight", "NumberFive", "NumberFour", "NumberNine", "NumberOne", "NumberSeven", "NumberSix", "NumberSquareEight", "NumberSquareFive", "NumberSquareFour", "NumberSquareNine", "NumberSquareOne", "NumberSquareSeven", "NumberSquareSix", "NumberSquareThree", "NumberSquareTwo", "NumberSquareZero", "NumberThree", "NumberTwo", "NumberZero", "Numpad", "Nut", "NyTimesLogo", "Octagon", "OfficeChair", "Onigiri", "OpenAiLogo", "Option", "Orange", "OrangeSlice", "Oven", "Package", "PaintBrush", "PaintBrushBroad", "PaintBrushHousehold", "PaintBucket", "PaintRoller", "Palette", "Panorama", "Pants", "PaperPlane", "PaperPlaneRight", "PaperPlaneTilt", "Paperclip", "PaperclipHorizontal", "Parachute", "Paragraph", "Parallelogram", "Park", "Password", "Path", "PatreonLogo", "Pause", "PauseCircle", "PawPrint", "PaypalLogo", "Peace", "Pen", "PenNib", "PenNibStraight", "Pencil", "PencilCircle", "PencilLine", "PencilRuler", "PencilSimple", "PencilSimpleLine", "PencilSimpleSlash", "PencilSlash", "Pentagon", "Pentagram", "Pepper", "Percent", "Person", "PersonArmsSpread", "PersonSimple", "PersonSimpleBike", "PersonSimpleCircle", "PersonSimpleHike", "PersonSimpleRun", "PersonSimpleSki", "PersonSimpleSwim", "PersonSimpleTaiChi", "PersonSimpleThrow", "PersonSimpleWalk", "Perspective", "Phone", "PhoneCall", "PhoneDisconnect", "PhoneIncoming", "PhoneList", "PhoneOutgoing", "PhonePause", "PhonePlus", "PhoneSlash", "PhoneTransfer", "PhoneX", "PhosphorLogo", "Pi", "PianoKeys", "PicnicTable", "PictureInPicture", "PiggyBank", "Pill", "PingPong", "PintGlass", "PinterestLogo", "Pinwheel", "Pipe", "PipeWrench", "PixLogo", "Pizza", "Placeholder", "Planet", "Plant", "Play", "PlayCircle", "PlayPause", "Playlist", "Plug", "PlugCharging", "Plugs", "PlugsConnected", "Plus", "PlusCircle", "PlusMinus", "PlusSquare", "PokerChip", "PoliceCar", "Polygon", "Popcorn", "Popsicle", "PottedPlant", "Power", "Prescription", "Presentation", "PresentationChart", "Printer", "Prohibit", "ProhibitInset", "ProjectorScreen", "ProjectorScreenChart", "Pulse", "PushPin", "PushPinSimple", "PushPinSimpleSlash", "PushPinSlash", "PuzzlePiece", "QrCode", "Question", "QuestionMark", "Queue", "Quotes", "Rabbit", "Racquet", "Radical", "Radio", "RadioButton", "Radioactive", "Rainbow", "RainbowCloud", "Ranking", "ReadCvLogo", "Receipt", "ReceiptX", "Record", "Rectangle", "RectangleDashed", "Recycle", "RedditLogo", "Repeat", "RepeatOnce", "ReplitLogo", "Resize", "Rewind", "RewindCircle", "RoadHorizon", "Robot", "Rocket", "RocketLaunch", "Rows", "RowsPlusBottom", "RowsPlusTop", "Rss", "RssSimple", "Rug", "Ruler", "Sailboat", "Scales", "Scan", "ScanSmiley", "Scissors", "Scooter", "Screencast", "Screwdriver", "Scribble", "ScribbleLoop", "Scroll", "Seal", "SealCheck", "SealPercent", "SealQuestion", "SealWarning", "Seat", "Seatbelt", "SecurityCamera", "Selection", "SelectionAll", "SelectionBackground", "SelectionForeground", "SelectionInverse", "SelectionPlus", "SelectionSlash", "Shapes", "Share", "ShareFat", "ShareNetwork", "Shield", "ShieldCheck", "ShieldCheckered", "ShieldChevron", "ShieldPlus", "ShieldSlash", "ShieldStar", "ShieldWarning", "ShippingContainer", "ShirtFolded", "ShootingStar", "ShoppingBag", "ShoppingBagOpen", "ShoppingCart", "ShoppingCartSimple", "Shovel", "Shower", "Shrimp", "Shuffle", "ShuffleAngular", "ShuffleSimple", "Sidebar", "SidebarSimple", "Sigma", "SignIn", "SignOut", "Signature", "Signpost", "SimCard", "Siren", "SketchLogo", "SkipBack", "SkipBackCircle", "SkipForward", "SkipForwardCircle", "Skull", "SkypeLogo", "SlackLogo", "Sliders", "SlidersHorizontal", "Slideshow", "Smiley", "SmileyAngry", "SmileyBlank", "SmileyMeh", "SmileyMelting", "SmileyNervous", "SmileySad", "SmileySticker", "SmileyWink", "SmileyXEyes", "SnapchatLogo", "Sneaker", "SneakerMove", "Snowflake", "SoccerBall", "Sock", "SolarPanel", "SolarRoof", "SortAscending", "SortDescending", "SoundcloudLogo", "Spade", "Sparkle", "SpeakerHifi", "SpeakerHigh", "SpeakerLow", "SpeakerNone", "SpeakerSimpleHigh", "SpeakerSimpleLow", "SpeakerSimpleNone", "SpeakerSimpleSlash", "SpeakerSimpleX", "SpeakerSlash", "SpeakerX", "Speedometer", "Sphere", "Spinner", "SpinnerBall", "SpinnerGap", "Spiral", "SplitHorizontal", "SplitVertical", "SpotifyLogo", "SprayBottle", "Square", "SquareHalf", "SquareHalfBottom", "SquareLogo", "SquareSplitVertical", "SquaresFour", "Stack", "StackMinus", "StackOverflowLogo", "StackPlus", "StackSimple", "Stairs", "Stamp", "StandardDefinition", "Star", "StarAndCrescent", "StarFour", "StarHalf", "StarOfDavid", "SteamLogo", "SteeringWheel", "Steps", "Stethoscope", "Sticker", "Stool", "Stop", "StopCircle", "Storefront", "Strategy", "StripeLogo", "Student", "SubsetOf", "SubsetProperOf", "Subtitles", "SubtitlesSlash", "Subtract", "SubtractSquare", "Subway", "Suitcase", "SuitcaseRolling", "SuitcaseSimple", "Sun", "SunDim", "SunHorizon", "Sunglasses", "SupersetOf", "SupersetProperOf", "Swap", "Swatches", "SwimmingPool", "Sword", "Synagogue", "Syringe", "TShirt", "Table", "Tabs", "Tag", "TagChevron", "TagSimple", "Target", "Taxi", "TeaBag", "TelegramLogo", "Television", "TelevisionSimple", "TennisBall", "Tent", "Terminal", "TerminalWindow", "TestTube", "TextAUnderline", "TextAa", "TextAlignCenter", "TextAlignJustify", "TextAlignLeft", "TextAlignRight", "TextB", "TextColumns", "TextH", "TextHFive", "TextHFour", "TextHOne", "TextHSix", "TextHThree", "TextHTwo", "TextIndent", "TextItalic", "TextOutdent", "TextStrikethrough", "TextSubscript", "TextSuperscript", "TextT", "TextTSlash", "TextUnderline", "Textbox", "Thermometer", "ThermometerCold", "ThermometerHot", "ThermometerSimple", "ThreadsLogo", "ThreeD", "ThumbsDown", "ThumbsUp", "Ticket", "TidalLogo", "TiktokLogo", "Tilde", "Timer", "TipJar", "Tipi", "Tire", "ToggleLeft", "ToggleRight", "Toilet", "ToiletPaper", "Toolbox", "Tooth", "Tornado", "Tote", "ToteSimple", "Towel", "Tractor", "Trademark", "TrademarkRegistered", "TrafficCone", "TrafficSign", "TrafficSignal", "Train", "TrainRegional", "TrainSimple", "Tram", "Translate", "Trash", "TrashSimple", "Tray", "TrayArrowDown", "TrayArrowUp", "TreasureChest", "Tree", "TreeEvergreen", "TreePalm", "TreeStructure", "TreeView", "TrendDown", "TrendUp", "Triangle", "TriangleDashed", "Trolley", "TrolleySuitcase", "Trophy", "Truck", "TruckTrailer", "TumblrLogo", "TwitchLogo", "TwitterLogo", "Umbrella", "UmbrellaSimple", "Union", "Unite", "UniteSquare", "Upload", "UploadSimple", "Usb", "User", "UserCheck", "UserCircle", "UserCircleCheck", "UserCircleDashed", "UserCircleGear", "UserCircleMinus", "UserCirclePlus", "UserFocus", "UserGear", "UserList", "UserMinus", "UserPlus", "UserRectangle", "UserSound", "UserSquare", "UserSwitch", "Users", "UsersFour", "UsersThree", "Van", "Vault", "VectorThree", "VectorTwo", "Vibrate", "Video", "VideoCamera", "VideoCameraSlash", "VideoConference", "Vignette", "VinylRecord", "VirtualReality", "Virus", "Visor", "Voicemail", "Volleyball", "Wall", "Wallet", "Warehouse", "Warning", "WarningCircle", "WarningDiamond", "WarningOctagon", "WashingMachine", "Watch", "WaveSawtooth", "WaveSine", "WaveSquare", "WaveTriangle", "Waveform", "WaveformSlash", "Waves", "Webcam", "WebcamSlash", "WebhooksLogo", "WechatLogo", "WhatsappLogo", "Wheelchair", "WheelchairMotion", "WifiHigh", "WifiLow", "WifiMedium", "WifiNone", "WifiSlash", "WifiX", "Wind", "Windmill", "WindowsLogo", "Wine", "Wrench", "X", "XCircle", "XLogo", "XSquare", "Yarn", "YinYang", "YoutubeLogo"];
var moduleBaseUrl = "https://framer.com/m/phosphor-icons/";
var weightOptions = ["thin", "light", "regular", "bold", "fill", "duotone"];
var lowercaseIconKeyPairs = iconKeys.reduce((res, key) => {
  res[key.toLowerCase()] = key;
  return res;
}, {});
function Icon2(props) {
  const { color, selectByList, iconSearch, iconSelection, onClick, onMouseDown, onMouseUp, onMouseEnter, onMouseLeave, weight, mirrored } = props;
  const isMounted = useRef4(false);
  const iconKey = useIconSelection(iconKeys, selectByList, iconSearch, iconSelection, lowercaseIconKeyPairs);
  const [SelectedIcon, setSelectedIcon] = useState4(iconKey === "Home" ? House_default(React4) : null);
  async function importModule() {
    try {
      const version = "0.0.57";
      const iconModuleUrl = `${moduleBaseUrl}${iconKey}.js@${version}`;
      const module = await import(
        /* webpackIgnore: true */
        iconModuleUrl
      );
      if (isMounted.current)
        setSelectedIcon(module.default(React4));
    } catch (err) {
      if (isMounted.current)
        setSelectedIcon(null);
    }
  }
  useEffect8(() => {
    isMounted.current = true;
    importModule();
    return () => {
      isMounted.current = false;
    };
  }, [iconKey]);
  const isOnCanvas = RenderTarget4.current() === RenderTarget4.canvas;
  const emptyState = isOnCanvas ? /* @__PURE__ */ _jsx3(NullState, {}) : null;
  return /* @__PURE__ */ _jsx3(motion2.div, { style: { display: "contents" }, onClick, onMouseEnter, onMouseLeave, onMouseDown, onMouseUp, children: SelectedIcon ? /* @__PURE__ */ _jsx3("svg", { xmlns: "http://www.w3.org/2000/svg", viewBox: "0 0 256 256", style: { userSelect: "none", width: "100%", height: "100%", display: "inline-block", fill: color, color, flexShrink: 0, transform: mirrored ? "scale(-1, 1)" : void 0 }, focusable: "false", color, children: /* @__PURE__ */ _jsx3(SelectedIcon, { color, weight }) }) : emptyState });
}
Icon2.displayName = "Phosphor";
Icon2.defaultProps = { width: 24, height: 24, iconSelection: "House", iconSearch: "House", color: "#66F", selectByList: true, weight: "regular", mirrored: false };
addPropertyControls2(Icon2, { selectByList: { type: ControlType6.Boolean, title: "Select", enabledTitle: "List", disabledTitle: "Search", defaultValue: Icon2.defaultProps.selectByList }, iconSelection: { type: ControlType6.Enum, options: iconKeys, defaultValue: Icon2.defaultProps.iconSelection, title: "Name", hidden: ({ selectByList }) => !selectByList, description: "Find every icon name on the [Phosphor site](https://phosphoricons.com/)" }, iconSearch: { type: ControlType6.String, title: "Name", placeholder: "Menu, Wifi, Box\u2026", hidden: ({ selectByList }) => selectByList }, color: { type: ControlType6.Color, title: "Color", defaultValue: Icon2.defaultProps.color }, weight: { type: ControlType6.Enum, title: "Weight", optionTitles: weightOptions.map((piece) => piece.charAt(0).toUpperCase() + piece.slice(1)), options: weightOptions, defaultValue: Icon2.defaultProps.weight }, mirrored: { type: ControlType6.Boolean, enabledTitle: "Yes", disabledTitle: "No", defaultValue: Icon2.defaultProps.mirrored }, ...defaultEvents2 });

// http-url:https://framerusercontent.com/modules/8LCazyoPCExBe0SjzDZM/2YQRaOXfddWLKfipF5gK/F5mq3rDN6.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["FS;Cabinet Grotesk-regular", "FS;Cabinet Grotesk-bold"]);
var fonts = [{ explicitInter: true, fonts: [{ family: "Cabinet Grotesk", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/J6PPRPKWXDUIYA47IXLEQB4R4OPVYDQH/N2ZXAXWEHVMLISD2TIXJC7EF4GOY43L4/NXM4Z4TDCMYWBZ7AVI2N6DQ5VMWNENMU.woff2", weight: "400" }, { family: "Cabinet Grotesk", source: "fontshare", style: "normal", url: "https://framerusercontent.com/third-party-assets/fontshare/wf/XMXWOHABYLQDJ42L65EFRYNVRY37HQCB/B2O4O6V3JMFM2WDCYQI3A47L5U4THDUL/WN5274VQ3AUBDFP74GB4EC4XYJ3EKVNE.woff2", weight: "700" }] }];
var css = [`.framer-zzb4K .framer-styles-preset-8kyz28:not(.rich-text-wrapper), .framer-zzb4K .framer-styles-preset-8kyz28.rich-text-wrapper h6 { --framer-font-family: "Cabinet Grotesk", "Cabinet Grotesk Placeholder", sans-serif; --framer-font-family-bold: "Cabinet Grotesk", "Cabinet Grotesk Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv09' on, 'cv03' on, 'cv04' on, 'cv11' on; --framer-font-size: 20px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-letter-spacing: 0em; --framer-line-height: 1.4em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-8e9f7d65-9fbe-4bbc-aa91-54812dc50f56, #262628); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }`];
var className = "framer-zzb4K";

// http-url:https://framerusercontent.com/modules/hgd2hRdl4jGz8BqAnD7x/oxjiUVdT9CSkAG866DWR/iNmdt_Omm.js
import { fontStore as fontStore3 } from "./_framer-runtime.js";
fontStore3.loadFonts(["GF;Hanken Grotesk-regular", "GF;Hanken Grotesk-700", "GF;Hanken Grotesk-700italic", "GF;Hanken Grotesk-italic"]);
var fonts2 = [{ explicitInter: true, fonts: [{ family: "Hanken Grotesk", source: "google", style: "normal", url: "https://fonts.gstatic.com/s/hankengrotesk/v11/ieVq2YZDLWuGJpnzaiwFXS9tYvBRzyFLlZg_f_Ncs2Za5PpNzXhRKA.woff2", weight: "400" }, { family: "Hanken Grotesk", source: "google", style: "normal", url: "https://fonts.gstatic.com/s/hankengrotesk/v11/ieVq2YZDLWuGJpnzaiwFXS9tYvBRzyFLlZg_f_NcVGFa5PpNzXhRKA.woff2", weight: "700" }, { family: "Hanken Grotesk", source: "google", style: "italic", url: "https://fonts.gstatic.com/s/hankengrotesk/v11/ieVo2YZDLWuGJpnzaiwFXS9tYtpY_d6T_POl0fRJeyVVpfBM731BKMSK.woff2", weight: "700" }, { family: "Hanken Grotesk", source: "google", style: "italic", url: "https://fonts.gstatic.com/s/hankengrotesk/v11/ieVo2YZDLWuGJpnzaiwFXS9tYtpY_d6T_POl0fRJeyWyovBM731BKMSK.woff2", weight: "400" }] }];
var css2 = ['.framer-qxaFP .framer-styles-preset-1dsqqmj:not(.rich-text-wrapper), .framer-qxaFP .framer-styles-preset-1dsqqmj.rich-text-wrapper p { --framer-font-family: "Hanken Grotesk", "Hanken Grotesk Placeholder", sans-serif; --framer-font-family-bold: "Hanken Grotesk", "Hanken Grotesk Placeholder", sans-serif; --framer-font-family-bold-italic: "Hanken Grotesk", "Hanken Grotesk Placeholder", sans-serif; --framer-font-family-italic: "Hanken Grotesk", "Hanken Grotesk Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 16px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0em; --framer-line-height: 1.5em; --framer-paragraph-spacing: 10px; --framer-text-alignment: left; --framer-text-color: var(--token-8cb0b1cf-31eb-44ae-ab53-2ab688199995, #575757); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className2 = "framer-qxaFP";

// http-url:https://framerusercontent.com/modules/wm83w8Ounl6dPhQAuYBm/RLDN5EfVhNSO3xwIZj0M/cAWq5iJ2z.js
var PhosphorFonts = getFonts(Icon2);
var serializationHash = "framer-Zatel";
var variantClassNames = { RkbbEjEVf: "framer-v-lwbe6v" };
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var Transition = ({ value, children }) => {
  const config = React5.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React5.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion3.create(React5.Fragment);
var getProps = ({ height, id, image, name1, testimonial, width, ...props }) => {
  return { ...props, cyFQUmIYu: image ?? props.cyFQUmIYu ?? { alt: "", pixelHeight: 979, pixelWidth: 735, src: "https://framerusercontent.com/images/1SYQmltCZOQxx1RHNZILDhPtuI.jpg?scale-down-to=512&width=735&height=979", srcSet: "https://framerusercontent.com/images/1SYQmltCZOQxx1RHNZILDhPtuI.jpg?width=735&height=979 735w" }, uy8zrhqsP: testimonial ?? props.uy8zrhqsP ?? "I purchased from this store has completely transformed my work setup.", yMGrSSEO1: name1 ?? props.yMGrSSEO1 ?? "Merry Jane" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React5.forwardRef(function(props, ref) {
  const fallbackRef = useRef5(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React5.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className3, layoutId, variant, yMGrSSEO1, uy8zrhqsP, cyFQUmIYu, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "RkbbEjEVf", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [className2, className];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx4(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition, { value: transition1, children: /* @__PURE__ */ _jsx4(motion3.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-lwbe6v", className3, classNames), "data-framer-name": "Testimonial Card", layoutDependency, layoutId: "CustomerReviews__RkbbEjEVf", ref: refBinding, style: { backgroundColor: "var(--token-d183fc7c-8cef-45d0-aef0-23c6a141ce23, rgb(255, 255, 255))", borderBottomLeftRadius: 25, borderBottomRightRadius: 25, borderTopLeftRadius: 25, borderTopRightRadius: 25, ...style }, children: /* @__PURE__ */ _jsxs2(motion3.div, { className: "framer-c2omqh", "data-framer-name": "Content", layoutDependency, layoutId: "CustomerReviews__eqjbD6lsI", children: [/* @__PURE__ */ _jsxs2(motion3.div, { className: "framer-1dfn1mr", "data-framer-name": "Top", layoutDependency, layoutId: "CustomerReviews__WTUiTajXT", children: [/* @__PURE__ */ _jsx4(Image, { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 32 + (((componentViewport?.height || 208) - 64 - 424) / 2 + 0 + 0) + 0 + 0 + 49), pixelHeight: 979, pixelWidth: 735, sizes: "46px", ...toResponsiveImage(cyFQUmIYu) }, className: "framer-a8mtm8", layoutDependency, layoutId: "CustomerReviews__RZoRWniI8", style: { borderBottomLeftRadius: 22, borderBottomRightRadius: 22, borderTopLeftRadius: 22, borderTopRightRadius: 22 } }), /* @__PURE__ */ _jsxs2(motion3.div, { className: "framer-kti1r5", "data-framer-name": "Stars", layoutDependency, layoutId: "CustomerReviews__xjpo8LkiY", children: [/* @__PURE__ */ _jsxs2(motion3.figure, { className: "framer-ffw3wr", "data-framer-name": "Stars", layoutDependency, layoutId: "CustomerReviews__mpk08v14_", children: [/* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-b63ao5-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "CustomerReviews__tzyylqXJ5-container", nodeId: "tzyylqXJ5", rendersWithMotion: true, scopeId: "cAWq5iJ2z", children: /* @__PURE__ */ _jsx4(Icon2, { color: "var(--token-fd07b8ca-fc64-4992-b509-a060507e8d6d, rgb(255, 94, 14))", height: "100%", iconSearch: "House", iconSelection: "Star", id: "tzyylqXJ5", layoutId: "CustomerReviews__tzyylqXJ5", mirrored: false, selectByList: true, style: { height: "100%", width: "100%" }, weight: "fill", width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1n4n5o9-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "CustomerReviews__EzeZpV9WC-container", nodeId: "EzeZpV9WC", rendersWithMotion: true, scopeId: "cAWq5iJ2z", children: /* @__PURE__ */ _jsx4(Icon2, { color: "var(--token-fd07b8ca-fc64-4992-b509-a060507e8d6d, rgb(255, 94, 14))", height: "100%", iconSearch: "House", iconSelection: "Star", id: "EzeZpV9WC", layoutId: "CustomerReviews__EzeZpV9WC", mirrored: false, selectByList: true, style: { height: "100%", width: "100%" }, weight: "fill", width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1o6v42b-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "CustomerReviews__hfb95rY0Q-container", nodeId: "hfb95rY0Q", rendersWithMotion: true, scopeId: "cAWq5iJ2z", children: /* @__PURE__ */ _jsx4(Icon2, { color: "var(--token-fd07b8ca-fc64-4992-b509-a060507e8d6d, rgb(255, 94, 14))", height: "100%", iconSearch: "House", iconSelection: "Star", id: "hfb95rY0Q", layoutId: "CustomerReviews__hfb95rY0Q", mirrored: false, selectByList: true, style: { height: "100%", width: "100%" }, weight: "fill", width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-3h2sqd-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "CustomerReviews__Ij7ufjVBv-container", nodeId: "Ij7ufjVBv", rendersWithMotion: true, scopeId: "cAWq5iJ2z", children: /* @__PURE__ */ _jsx4(Icon2, { color: "var(--token-fd07b8ca-fc64-4992-b509-a060507e8d6d, rgb(255, 94, 14))", height: "100%", iconSearch: "House", iconSelection: "Star", id: "Ij7ufjVBv", layoutId: "CustomerReviews__Ij7ufjVBv", mirrored: false, selectByList: true, style: { height: "100%", width: "100%" }, weight: "fill", width: "100%" }) }) }), /* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-2jvhkj-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "CustomerReviews__sFx2uur2b-container", nodeId: "sFx2uur2b", rendersWithMotion: true, scopeId: "cAWq5iJ2z", children: /* @__PURE__ */ _jsx4(Icon2, { color: "var(--token-fd07b8ca-fc64-4992-b509-a060507e8d6d, rgb(255, 94, 14))", height: "100%", iconSearch: "House", iconSelection: "Star", id: "sFx2uur2b", layoutId: "CustomerReviews__sFx2uur2b", mirrored: false, selectByList: true, style: { height: "100%", width: "100%" }, weight: "fill", width: "100%" }) }) })] }), /* @__PURE__ */ _jsx4(motion3.div, { className: "framer-1bhpbop", "data-framer-name": "Reviews", layoutDependency, layoutId: "CustomerReviews__FvkLHFnBH", children: /* @__PURE__ */ _jsx4(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React5.Fragment, { children: /* @__PURE__ */ _jsx4(motion3.p, { className: "framer-styles-preset-1dsqqmj", "data-styles-preset": "iNmdt_Omm", style: { "--framer-text-alignment": "right", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-8e9f7d65-9fbe-4bbc-aa91-54812dc50f56, rgb(38, 38, 40)))" }, children: "4.9/5" }) }), className: "framer-1bqfjlz", fonts: ["Inter"], layoutDependency, layoutId: "CustomerReviews__W_hJh4Wte", style: { "--extracted-r6o4lv": "var(--token-8e9f7d65-9fbe-4bbc-aa91-54812dc50f56, rgb(38, 38, 40))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true }) })] })] }), /* @__PURE__ */ _jsxs2(motion3.div, { className: "framer-1tphvn1", "data-framer-name": "Testimonial", layoutDependency, layoutId: "CustomerReviews__zVS7r7rXC", children: [/* @__PURE__ */ _jsx4(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React5.Fragment, { children: /* @__PURE__ */ _jsx4(motion3.p, { className: "framer-styles-preset-8kyz28", "data-styles-preset": "F5mq3rDN6", children: /* @__PURE__ */ _jsx4(motion3.strong, { children: "Merry Jane" }) }) }), className: "framer-m58qcp", fonts: ["Inter", "Inter-Bold"], layoutDependency, layoutId: "CustomerReviews__HXJDL64su", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: yMGrSSEO1, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx4(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React5.Fragment, { children: /* @__PURE__ */ _jsx4(motion3.p, { className: "framer-styles-preset-1dsqqmj", "data-styles-preset": "iNmdt_Omm", style: { "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-8cb0b1cf-31eb-44ae-ab53-2ab688199995, rgb(87, 87, 87)))" }, children: "I purchased from this store has completely transformed my work setup." }) }), className: "framer-ec6t90", fonts: ["Inter"], layoutDependency, layoutId: "CustomerReviews__VQKnzgiWb", style: { "--extracted-r6o4lv": "var(--token-8cb0b1cf-31eb-44ae-ab53-2ab688199995, rgb(87, 87, 87))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: uy8zrhqsP, verticalAlignment: "top", withExternalLayout: true })] })] }) }) }) }) });
});
var css3 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-Zatel.framer-6180y5, .framer-Zatel .framer-6180y5 { display: block; }", ".framer-Zatel.framer-lwbe6v { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 80px; height: min-content; justify-content: center; overflow: hidden; padding: 32px; position: relative; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-Zatel .framer-c2omqh { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 15px; height: min-content; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: 289px; }", ".framer-Zatel .framer-1dfn1mr { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; height: min-content; justify-content: space-between; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-Zatel .framer-a8mtm8 { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 46px); overflow: var(--overflow-clip-fallback, clip); position: relative; width: 46px; will-change: var(--framer-will-change-override, transform); }", ".framer-Zatel .framer-kti1r5 { align-content: flex-end; align-items: flex-end; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 5px; height: min-content; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 1px; }", ".framer-Zatel .framer-ffw3wr { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 7px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: min-content; }", ".framer-Zatel .framer-b63ao5-container, .framer-Zatel .framer-1n4n5o9-container, .framer-Zatel .framer-1o6v42b-container, .framer-Zatel .framer-3h2sqd-container, .framer-Zatel .framer-2jvhkj-container { flex: none; height: 16px; position: relative; width: 16px; }", ".framer-Zatel .framer-1bhpbop { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 3px 0px 0px 0px; position: relative; width: 100%; }", ".framer-Zatel .framer-1bqfjlz { flex: 1 0 0px; height: auto; position: relative; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; }", ".framer-Zatel .framer-1tphvn1 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 5px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-Zatel .framer-m58qcp, .framer-Zatel .framer-ec6t90 { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ...css2, ...css];
var FramercAWq5iJ2z = withCSS(Component2, css3, "framer-Zatel");
var cAWq5iJ2z_default = FramercAWq5iJ2z;
FramercAWq5iJ2z.displayName = "Testimonial-card";
FramercAWq5iJ2z.defaultProps = { height: 208, width: 353 };
addPropertyControls3(FramercAWq5iJ2z, { yMGrSSEO1: { defaultValue: "Merry Jane", displayTextArea: false, title: "Name", type: ControlType7.String }, uy8zrhqsP: { defaultValue: "I purchased from this store has completely transformed my work setup.", displayTextArea: false, title: "Testimonial", type: ControlType7.String }, cyFQUmIYu: { __defaultAssetReference: "data:framer/asset-reference,1SYQmltCZOQxx1RHNZILDhPtuI.jpg?originalFilename=3ea9607179248d8eab1ef166f047c49b.jpg&preferredSize=auto", __vekterDefault: { alt: "", assetReference: "data:framer/asset-reference,1SYQmltCZOQxx1RHNZILDhPtuI.jpg?originalFilename=3ea9607179248d8eab1ef166f047c49b.jpg&preferredSize=auto" }, title: "Image", type: ControlType7.ResponsiveImage } });
addFonts(FramercAWq5iJ2z, [{ explicitInter: true, fonts: [{ family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/DpPBYI0sL4fYLgAkX8KXOPVt7c.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/4RAEQdEOrcnDkhHiiCbJOw92Lk.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/1K3W8DizY3v4emK8Mb08YHxTbs.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/tUSCtfYVM1I1IchuyCwz9gDdQ.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/VgYFWiwsAC5OYxAycRXXvhze58.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/syRNPWzAMIrcJ3wIlPIP43KjQs.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/GIryZETIX4IFypco5pYZONKhJIo.woff2", weight: "700" }] }, ...PhosphorFonts, ...getFontsFromSharedStyle(fonts2), ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/xWQBrhtD3D2b6ziRsYeN/HjVp3cBypiAw0DzbgGLA/wcwfO2Oe5.js
var TestimonialCardFonts = getFonts2(cAWq5iJ2z_default);
var CarouselFonts = getFonts2(Carousel);
var serializationHash2 = "framer-ZmriT";
var variantClassNames2 = { Lm21yjs8v: "framer-v-1cnu2yr" };
var transition12 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var addImageAlt = (image, alt) => {
  if (!image || typeof image !== "object") {
    return;
  }
  return { ...image, alt };
};
var Transition2 = ({ value, children }) => {
  const config = React6.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React6.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx5(MotionConfigContext2.Provider, { value: contextValue, children });
};
var Variants2 = motion4.create(React6.Fragment);
var getProps2 = ({ height, id, width, ...props }) => {
  return { ...props };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React6.forwardRef(function(props, ref) {
  const fallbackRef = useRef6(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React6.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className: className3, layoutId, variant, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ defaultVariant: "Lm21yjs8v", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash2, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx5(LayoutGroup3, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx5(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx5(Transition2, { value: transition12, children: /* @__PURE__ */ _jsx5(motion4.div, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-1cnu2yr", className3, classNames), "data-framer-name": "Variant 1", layoutDependency, layoutId: "CustomerReviews__Lm21yjs8v", ref: refBinding, style: { ...style }, children: /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-1798nwt-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "CustomerReviews__Cpl2_z_Da-container", nodeId: "Cpl2_z_Da", rendersWithMotion: true, scopeId: "wcwfO2Oe5", children: /* @__PURE__ */ _jsx5(Carousel, { align: "center", ariaLabel: "", arrowObject: { arrowFill: "rgba(0, 0, 0, 0.2)", arrowPadding: 20, arrowRadius: 40, arrowSize: 40, showMouseControls: true }, axis: true, borderRadius: 0, fadeObject: { fadeAlpha: 0, fadeContent: true, fadeInset: 0, fadeTransition: { damping: 60, delay: 0, mass: 1, stiffness: 500, type: "spring" }, fadeWidth: 25 }, gap: 15, height: "100%", id: "Cpl2_z_Da", layoutId: "CustomerReviews__Cpl2_z_Da", padding: 0, paddingBottom: 0, paddingLeft: 0, paddingPerSide: false, paddingRight: 0, paddingTop: 0, progressObject: { dotsActiveOpacity: 1, dotsBackground: "rgba(0, 0, 0, 0.2)", dotsBlur: 4, dotsFill: "rgb(255, 255, 255)", dotsGap: 10, dotsInset: 10, dotSize: 10, dotsOpacity: 0.5, dotsPadding: 10, dotsRadius: 50, showProgressDots: false, showScrollbar: false }, sizingObject: { heightInset: 0, heightRows: 2, heightType: "auto", widthColumns: 2, widthInset: 0, widthType: "auto" }, slots: [/* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 208, children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-fziagi-container", inComponentSlot: true, layoutDependency, layoutId: "CustomerReviews__gzopPkIdW-container", nodeId: "gzopPkIdW", rendersWithMotion: true, scopeId: "wcwfO2Oe5", children: /* @__PURE__ */ _jsx5(cAWq5iJ2z_default, { cyFQUmIYu: addImageAlt({ pixelHeight: 1536, pixelWidth: 1024, src: "https://framerusercontent.com/images/znEPu9IEdUCqc4unS8T9dOUbmLM.png?width=1024&height=1536", srcSet: "https://framerusercontent.com/images/znEPu9IEdUCqc4unS8T9dOUbmLM.png?scale-down-to=1024&width=1024&height=1536 682w,https://framerusercontent.com/images/znEPu9IEdUCqc4unS8T9dOUbmLM.png?width=1024&height=1536 1024w" }, ""), height: "100%", id: "gzopPkIdW", layoutId: "CustomerReviews__gzopPkIdW", uy8zrhqsP: "They fit so comfortably and never fall out, even during workouts.", width: "100%", yMGrSSEO1: "Olivia M." }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 208, children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-zci4ok-container", inComponentSlot: true, layoutDependency, layoutId: "CustomerReviews__KPIPbH7ed-container", nodeId: "KPIPbH7ed", rendersWithMotion: true, scopeId: "wcwfO2Oe5", children: /* @__PURE__ */ _jsx5(cAWq5iJ2z_default, { cyFQUmIYu: addImageAlt({ pixelHeight: 1024, pixelWidth: 1024, src: "https://framerusercontent.com/images/1DtFLK9rVEG9yvCgC8H4kOqucU0.png?width=1024&height=1024", srcSet: "https://framerusercontent.com/images/1DtFLK9rVEG9yvCgC8H4kOqucU0.png?scale-down-to=512&width=1024&height=1024 512w,https://framerusercontent.com/images/1DtFLK9rVEG9yvCgC8H4kOqucU0.png?width=1024&height=1024 1024w" }, ""), height: "100%", id: "KPIPbH7ed", layoutId: "CustomerReviews__KPIPbH7ed", uy8zrhqsP: "Battery life is insane. I charge once and it lasts me for days.", width: "100%", yMGrSSEO1: "Emily N." }) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider2, { height: 208, children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer2, { className: "framer-xyb8u5-container", inComponentSlot: true, layoutDependency, layoutId: "CustomerReviews__ZJDAKlmpp-container", nodeId: "ZJDAKlmpp", rendersWithMotion: true, scopeId: "wcwfO2Oe5", children: /* @__PURE__ */ _jsx5(cAWq5iJ2z_default, { height: "100%", id: "ZJDAKlmpp", layoutId: "CustomerReviews__ZJDAKlmpp", uy8zrhqsP: "The sound is incredible\u2014clear vocals and strong bass.", width: "100%", yMGrSSEO1: "Merry Jane" }) }) })], snapObject: { fluid: false, snap: true, snapEdge: "center" }, style: { width: "100%" }, width: "100%" }) }) }) }) }) }) });
});
var css4 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-ZmriT.framer-1h6c3su, .framer-ZmriT .framer-1h6c3su { display: block; }", ".framer-ZmriT.framer-1cnu2yr { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-ZmriT .framer-1798nwt-container { flex: none; height: auto; position: relative; width: 100%; }", ".framer-ZmriT .framer-fziagi-container, .framer-ZmriT .framer-zci4ok-container, .framer-ZmriT .framer-xyb8u5-container { height: auto; position: relative; width: auto; }"];
var FramerwcwfO2Oe5 = withCSS2(Component3, css4, "framer-ZmriT");
var wcwfO2Oe5_default = FramerwcwfO2Oe5;
FramerwcwfO2Oe5.displayName = "Customer Reviews";
FramerwcwfO2Oe5.defaultProps = { height: 208, width: 579 };
addFonts2(FramerwcwfO2Oe5, [{ explicitInter: true, fonts: [] }, ...TestimonialCardFonts, ...CarouselFonts], { supportsExplicitInterCodegen: true });
FramerwcwfO2Oe5.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader(cAWq5iJ2z_default, {}, context)]);
} };
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerwcwfO2Oe5", "slots": [], "annotations": { "framerColorSyntax": "true", "framerIntrinsicWidth": "579", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]}}}', "framerAutoSizeImages": "true", "framerContractVersion": "1", "framerImmutableVariables": "true", "framerIntrinsicHeight": "208", "framerDisplayContentsDiv": "false", "framerComponentViewportWidth": "true" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  wcwfO2Oe5_default as default
};
