export interface Gradient16Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Button Large Variant" → bVJfOvDrI
   *   "Button Small" → Yzi4C2T4W
   *   "Button XL" → xyNM_BO7j
   *   "Badge" → EgPH3Stqk
   *   "XS" → YQAtvdz4i
   */
  variant?: 'Button Large Variant' | 'Button Small' | 'Button XL' | 'Badge' | 'XS' | 'bVJfOvDrI' | 'Yzi4C2T4W' | 'xyNM_BO7j' | 'EgPH3Stqk' | 'YQAtvdz4i';
  /**
   * Title — pass as `g2lYt0MHf` not `title`.
   * @default "Buy It Now"
   */
  g2lYt0MHf?: string;
  /**
   * Link — pass as `WNfOGlLkp` not `link`.
   */
  WNfOGlLkp?: string;
  /**
   * Icon Visible — pass as `ZDCzXhMJC` not `iconVisible`.
   * @default false
   */
  ZDCzXhMJC?: boolean;
  /**
   * Icon — pass as `qYJib1_RS` not `icon`.
   * @default {"identifier":"module:SUBEdtCFaOJwrjN2Inhk/bznEUerLEqVVXGfsDOYE/pKERsxd4H.js:default","moduleId":"SUBEdtCFaOJwrjN2Inhk"}
   */
  qYJib1_RS?: string;
  /** Additional properties */
  [key: string]: unknown;
}
