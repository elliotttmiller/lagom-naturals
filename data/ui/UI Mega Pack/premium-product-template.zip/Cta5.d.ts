export interface Cta5Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "CTA Desktop Layout" → pT0AoioBx
   *   "Mobile" → stq1v0rL6
   */
  variant?: 'CTA Desktop Layout' | 'Mobile' | 'pT0AoioBx' | 'stq1v0rL6';
  /**
   * Title — pass as `ZxIvqZnrt` not `title`.
   * @default "Get Airbuds Pro Now!"
   */
  ZxIvqZnrt?: string;
  onZxIvqZnrtChange?: string;
  /**
   * Text — pass as `KLVJ5OA2t` not `text`.
   * @default "Probuds combine premium sound, sleek design, and reliable performance."
   */
  KLVJ5OA2t?: string;
  onKLVJ5OA2tChange?: string;
  /**
   * Badge Title — pass as `n4NXZQLN5` not `badgeTitle`.
   * @default "Best Seller"
   */
  n4NXZQLN5?: string;
  onn4NXZQLN5Change?: string;
  /**
   * Image — pass as `CSYldL4fs` not `image`.
   */
  CSYldL4fs?: string;
  /**
   * Gradient Overlay Visible — pass as `oAsruWZHg` not `gradientOverlayVisible`.
   * @default true
   */
  oAsruWZHg?: boolean;
  onoAsruWZHgChange?: string;
  onEvYmSSY97Change?: string;
  /** Additional properties */
  [key: string]: unknown;
}
