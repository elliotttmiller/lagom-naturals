export interface Productdetailscard30Props {
  /**
   * Title — pass as `dUMTT01Kf` not `title`.
   * @default "Action camera"
   */
  dUMTT01Kf?: string;
  /**
   * Text — pass as `VIKPpY2Nb` not `text`.
   * @default "ProDuck Edge is the next-generation action camera"
   */
  VIKPpY2Nb?: string;
  /**
   * Image — pass as `oGBANDMc_` not `image`.
   */
  oGBANDMc_?: string;
  /** Additional properties */
  [key: string]: unknown;
}
