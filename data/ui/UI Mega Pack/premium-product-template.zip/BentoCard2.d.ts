export interface Bentocard2Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Bento Card Large Layout" → BGGX7KA6A
   *   "Without Copy" → kt8Emwqbm
   *   "Small" → UxDtip0sL
   */
  variant?: 'Bento Card Large Layout' | 'Without Copy' | 'Small' | 'BGGX7KA6A' | 'UxDtip0sL' | 'kt8Emwqbm';
  /**
   * Title — pass as `ZW2AOjU4W` not `title`.
   * @default "Immersive Sound"
   */
  ZW2AOjU4W?: string;
  /**
   * Text — pass as `RGsrYHSy4` not `text`.
   * @default "Hear music the way it was meant to be heard."
   */
  RGsrYHSy4?: string;
  /**
   * Image — pass as `Y7FuFLnn0` not `image`.
   */
  Y7FuFLnn0?: string;
  /**
   * Hover — pass as `yenmJ9VAg` not `hover`.
   */
  yenmJ9VAg?: () => void;
  /** Additional properties */
  [key: string]: unknown;
}
