export interface ScrollindicatorProps {
  /**
   * Border Color
   * @default "#FFFFFF"
   */
  borderColor?: string;
  /**
   * Border Opacity
   * Range: min: 0, max: 1, step: 0.1
   * @default 0.5
   */
  borderOpacity?: number;
  /**
   * Dot Color
   * @default "#FFFFFF"
   */
  dotColor?: string;
  /**
   * Pill Width
   * Range: min: 20, max: 60, step: 1
   * @default 24
   */
  pillWidth?: number;
  /**
   * Pill Height
   * Range: min: 30, max: 80, step: 1
   * @default 40
   */
  pillHeight?: number;
  /**
   * Dot Size
   * Range: min: 4, max: 12, step: 1
   * @default 6
   */
  dotSize?: number;
  /**
   * Border Width
   * Range: min: 1, max: 4, step: 1
   * @default 2
   */
  borderWidth?: number;
  /**
   * Border Radius
   * Range: min: 0, max: 40, step: 1
   * @default 20
   */
  borderRadius?: number;
  /**
   * Animation Speed
   * Range: min: 1, max: 10, step: 0.1
   * @default 3
   */
  animationSpeed?: number;
  /**
   * Scroll Type
   * Options: "section" | "link"
   * @default "section"
   */
  scrollType?: 'section' | 'link';
  /**
   * Section Name
   * @default ""
   */
  sectionName?: string;
  /**
   * Custom Link
   * @default ""
   */
  customLink?: string;
  /**
   * Animation Preset
   * Options: "default" | "elegant-chevrons" | "minimalist-scroll"
   * @default "default"
   */
  animationPreset?: 'default' | 'elegant-chevrons' | 'minimalist-scroll';
  /**
   * Chevron Color
   * @default "#FFFFFF"
   */
  chevronColor?: string;
  /**
   * Icon Size — pass as `chevronSize` not `iconSize`.
   * Range: min: 1, max: 10, step: 1
   * @default 4
   */
  chevronSize?: number;
  /**
   * Chevron Spacing — pass as `chevronGap` not `chevronSpacing`.
   * Range: min: 1, max: 10, step: 1
   * @default 4
   */
  chevronGap?: number;
  /**
   * Color — pass as `minimalistColor` not `color`.
   * @default "#FFFFFF"
   */
  minimalistColor?: string;
  /**
   * Font Size — pass as `minimalistFontSize` not `fontSize`.
   * Range: min: 1, max: 10, step: 1
   * @default 3
   */
  minimalistFontSize?: number;
  /**
   * Animation Speed — pass as `minimalistSpeed` not `animationSpeed`.
   * Range: min: 1, max: 10, step: 0.1
   * @default 5
   */
  minimalistSpeed?: number;
  /** Additional properties */
  [key: string]: unknown;
}
