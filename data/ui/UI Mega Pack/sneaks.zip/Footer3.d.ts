export interface Footer3Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → X9hTTumzK
   *   "Phone" → oUwH_wJFZ
   *   "Tablet" → DhXHGg0IN
   */
  variant?: 'Desktop' | 'Phone' | 'Tablet' | 'X9hTTumzK' | 'DhXHGg0IN' | 'oUwH_wJFZ';
  /** Additional properties */
  [key: string]: unknown;
}
