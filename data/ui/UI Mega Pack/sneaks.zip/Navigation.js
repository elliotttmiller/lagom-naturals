
// ─────────────────────────────────────────────────────────────
// CMS Data Stub (Framer plugin v15)
//
// This component was bound to a Framer Collection. The runtime CMS
// machinery has been stripped — wire up your own data source by
// populating this object. Keys are the query aliases used internally
// by the design; values are arrays of items.
//
// AI INTEGRATION NOTE: identify the .map(item => ...) call(s) in
// the component below to learn what fields each item needs. Then
// replace the empty arrays here with your data (fetched from your
// CMS, an API, a JSON file, props, etc.).
// ─────────────────────────────────────────────────────────────
const __FRAMER_CMS_DATA__ = {
  // alias: [ { /* item fields */ } ],
};
const __framer_useQueryData = (query) => {
  const alias = query && query.from && query.from.alias;
  return (alias && __FRAMER_CMS_DATA__[alias]) || [];
};

var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// http-url:https://framerusercontent.com/modules/x792CL25E5sD9xXrqvMm/uqYErgItcWBHF3VgPrdn/bLruI0oTL.js
import { fontStore as fontStore7 } from "./_framer-runtime.js";
var variationAxes6, fonts7, css15, className7;
var init_bLruI0oTL = __esm({
  "http-url:https://framerusercontent.com/modules/x792CL25E5sD9xXrqvMm/uqYErgItcWBHF3VgPrdn/bLruI0oTL.js"() {
    fontStore7.loadFonts(["Inter-Variable", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNTI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNTI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNTI1"]);
    variationAxes6 = [{ defaultValue: 14, maxValue: 32, minValue: 14, name: "Optical size", tag: "opsz" }, { defaultValue: 400, maxValue: 900, minValue: 100, name: "Weight", tag: "wght" }];
    fonts7 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/mYcqTSergLb16PdbJJQMl9ebYm4.woff2", variationAxes: variationAxes6, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/ZRl8AlxwsX1m7xS1eJCiSPbztg.woff2", variationAxes: variationAxes6, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/nhSQpBRqFmXNUBY2p5SENQ8NplQ.woff2", variationAxes: variationAxes6, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/DYHjxG0qXjopUuruoacfl5SA.woff2", variationAxes: variationAxes6, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/s7NH6sl7w4NU984r5hcmo1tPSYo.woff2", variationAxes: variationAxes6, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/7lw0VWkeXrGYJT05oB3DsFy8BaY.woff2", variationAxes: variationAxes6, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/wx5nfqEgOXnxuFaxB0Mn9OhmcZA.woff2", variationAxes: variationAxes6, weight: "400" }] }];
    css15 = ['.framer-UktaB .framer-styles-preset-1sqkecy:not(.rich-text-wrapper), .framer-UktaB .framer-styles-preset-1sqkecy.rich-text-wrapper p { --framer-font-family: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 12px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: normal; --framer-font-style-italic: normal; --framer-font-variation-axes: "opsz" 14, "wght" 525; --framer-font-variation-axes-bold: "opsz" 14, "wght" 525; --framer-font-variation-axes-bold-italic: "opsz" 14, "wght" 525; --framer-font-variation-axes-italic: "opsz" 14, "wght" 525; --framer-font-weight: 400; --framer-font-weight-bold: 400; --framer-font-weight-bold-italic: 400; --framer-font-weight-italic: 400; --framer-letter-spacing: -0.04em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: center; --framer-text-color: var(--token-d53ec7b6-ca11-471f-93d4-6939f860246e, #000000); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
    className7 = "framer-UktaB";
  }
});

// http-url:https://framerusercontent.com/modules/rvQmVwf0GZo8cRTnvMj1/wzFMOfI6Ln0UDwWoBHVL/WIiaJAMT7.js
import { fontStore as fontStore8 } from "./_framer-runtime.js";
var variationAxes7, fonts8, css16, className8;
var init_WIiaJAMT7 = __esm({
  "http-url:https://framerusercontent.com/modules/rvQmVwf0GZo8cRTnvMj1/wzFMOfI6Ln0UDwWoBHVL/WIiaJAMT7.js"() {
    fontStore8.loadFonts(["Inter-Variable", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNDI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNDI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNDI1"]);
    variationAxes7 = [{ defaultValue: 14, maxValue: 32, minValue: 14, name: "Optical size", tag: "opsz" }, { defaultValue: 400, maxValue: 900, minValue: 100, name: "Weight", tag: "wght" }];
    fonts8 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/mYcqTSergLb16PdbJJQMl9ebYm4.woff2", variationAxes: variationAxes7, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/ZRl8AlxwsX1m7xS1eJCiSPbztg.woff2", variationAxes: variationAxes7, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/nhSQpBRqFmXNUBY2p5SENQ8NplQ.woff2", variationAxes: variationAxes7, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/DYHjxG0qXjopUuruoacfl5SA.woff2", variationAxes: variationAxes7, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/s7NH6sl7w4NU984r5hcmo1tPSYo.woff2", variationAxes: variationAxes7, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/7lw0VWkeXrGYJT05oB3DsFy8BaY.woff2", variationAxes: variationAxes7, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/wx5nfqEgOXnxuFaxB0Mn9OhmcZA.woff2", variationAxes: variationAxes7, weight: "400" }] }];
    css16 = ['.framer-dy7z7 .framer-styles-preset-y1k16k:not(.rich-text-wrapper), .framer-dy7z7 .framer-styles-preset-y1k16k.rich-text-wrapper p { --framer-font-family: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 13px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: normal; --framer-font-style-italic: normal; --framer-font-variation-axes: "opsz" 14, "wght" 425; --framer-font-variation-axes-bold: "opsz" 14, "wght" 425; --framer-font-variation-axes-bold-italic: "opsz" 14, "wght" 425; --framer-font-variation-axes-italic: "opsz" 14, "wght" 425; --framer-font-weight: 400; --framer-font-weight-bold: 400; --framer-font-weight-bold-italic: 400; --framer-font-weight-italic: 400; --framer-letter-spacing: -0.02em; --framer-line-height: 1.5em; --framer-paragraph-spacing: 20px; --framer-text-alignment: center; --framer-text-color: var(--token-d53ec7b6-ca11-471f-93d4-6939f860246e, #000000); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
    className8 = "framer-dy7z7";
  }
});

// http-url:https://framerusercontent.com/modules/7Fv1DKwShuhMvjoxe6as/nO2hVN5B6hhq6jrnosi3/W76pPiwFl.js
var W76pPiwFl_exports = {};
__export(W76pPiwFl_exports, {
  __FramerMetadata__: () => __FramerMetadata__,
  default: () => W76pPiwFl_default
});
import { jsx as _jsx9, jsxs as _jsxs6 } from "react/jsx-runtime";
import { addFonts as addFonts7, addPropertyControls as addPropertyControls8, ControlType as ControlType8, cx as cx9, getFontsFromSharedStyle as getFontsFromSharedStyle5, RichText as RichText5, useComponentViewport as useComponentViewport7, useLocaleInfo as useLocaleInfo7, useVariantState as useVariantState7, withCSS as withCSS9 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup7, motion as motion9, MotionConfigContext as MotionConfigContext7 } from "framer-motion";
import * as React9 from "react";
import { useRef as useRef7 } from "react";
function addPropertyOverrides7(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var cycleOrder7, serializationHash7, variantClassNames7, transition17, Transition7, humanReadableVariantMap7, Variants7, getProps9, createLayoutDependency7, Component9, css17, FramerW76pPiwFl, W76pPiwFl_default, __FramerMetadata__;
var init_W76pPiwFl = __esm({
  "http-url:https://framerusercontent.com/modules/7Fv1DKwShuhMvjoxe6as/nO2hVN5B6hhq6jrnosi3/W76pPiwFl.js"() {
    init_bLruI0oTL();
    init_WIiaJAMT7();
    cycleOrder7 = ["fzTpjTBPb", "iwvIJgSxT", "aZuD0jNSC", "rmDSVRFVj"];
    serializationHash7 = "framer-6KPyM";
    variantClassNames7 = { aZuD0jNSC: "framer-v-w4sipw", fzTpjTBPb: "framer-v-1qh5yry", iwvIJgSxT: "framer-v-15y057s", rmDSVRFVj: "framer-v-15y3qjp" };
    transition17 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
    Transition7 = ({ value, children }) => {
      const config = React9.useContext(MotionConfigContext7);
      const transition = value ?? config.transition;
      const contextValue = React9.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
      return /* @__PURE__ */ _jsx9(MotionConfigContext7.Provider, { value: contextValue, children });
    };
    humanReadableVariantMap7 = { "Sky Blue": "aZuD0jNSC", Beige: "fzTpjTBPb", Grey: "rmDSVRFVj", Orange: "iwvIJgSxT" };
    Variants7 = motion9.create(React9.Fragment);
    getProps9 = ({ height, id, tag, title, width, ...props }) => {
      return { ...props, eez7kHeWw: title ?? props.eez7kHeWw ?? "Limited edition collection", variant: humanReadableVariantMap7[props.variant] ?? props.variant ?? "fzTpjTBPb", weK3S2rqe: tag ?? props.weK3S2rqe ?? "New" };
    };
    createLayoutDependency7 = (props, variants) => {
      if (props.layoutDependency)
        return variants.join("-") + props.layoutDependency;
      return variants.join("-");
    };
    Component9 = /* @__PURE__ */ React9.forwardRef(function(props, ref) {
      const fallbackRef = useRef7(null);
      const refBinding = ref ?? fallbackRef;
      const defaultLayoutId = React9.useId();
      const { activeLocale, setLocale } = useLocaleInfo7();
      const componentViewport = useComponentViewport7();
      const { style, className: className9, layoutId, variant, eez7kHeWw, weK3S2rqe, ...restProps } = getProps9(props);
      const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState7({ cycleOrder: cycleOrder7, defaultVariant: "fzTpjTBPb", ref: refBinding, variant, variantClassNames: variantClassNames7 });
      const layoutDependency = createLayoutDependency7(props, variants);
      const sharedStyleClassNames = [className7, className8];
      const scopingClassNames = cx9(serializationHash7, ...sharedStyleClassNames);
      return /* @__PURE__ */ _jsx9(LayoutGroup7, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx9(Variants7, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx9(Transition7, { value: transition17, children: /* @__PURE__ */ _jsxs6(motion9.div, { ...restProps, ...gestureHandlers, className: cx9(scopingClassNames, "framer-1qh5yry", className9, classNames), "data-border": true, "data-framer-name": "Beige", layoutDependency, layoutId: "Navigation__fzTpjTBPb", ref: refBinding, style: { "--border-bottom-width": "0.75px", "--border-color": "var(--token-facdf9ba-ab59-43c2-ab8f-07ddd27ed78e, rgb(227, 207, 179))", "--border-left-width": "0.75px", "--border-right-width": "0.75px", "--border-style": "solid", "--border-top-width": "0.75px", backgroundColor: "var(--token-9039c660-569a-421b-a527-9ac056ae9951, rgb(255, 255, 255))", borderBottomLeftRadius: 1e3, borderBottomRightRadius: 1e3, borderTopLeftRadius: 1e3, borderTopRightRadius: 1e3, ...style }, variants: { aZuD0jNSC: { "--border-color": "var(--token-975004f8-b431-4c64-9cbe-cba253835067, rgb(179, 211, 227))" }, iwvIJgSxT: { "--border-color": "var(--token-a81a54c4-cf8d-443b-a6d8-1594e37ce8c3, rgb(255, 193, 107))" }, rmDSVRFVj: { "--border-bottom-width": "0.5px", "--border-color": "var(--token-66c17a07-9665-42f4-bcc6-e569faf2b983, rgb(138, 138, 138))", "--border-left-width": "0.5px", "--border-right-width": "0.5px", "--border-top-width": "0.5px" } }, ...addPropertyOverrides7({ aZuD0jNSC: { "data-framer-name": "Sky Blue" }, iwvIJgSxT: { "data-framer-name": "Orange" }, rmDSVRFVj: { "data-framer-name": "Grey" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx9(motion9.div, { className: "framer-1k3l7si", "data-border": true, "data-framer-name": "Tag", layoutDependency, layoutId: "Navigation__eFPAOiPiC", style: { "--border-bottom-width": "0.5px", "--border-color": "var(--token-28a2250d-baec-4b0b-8342-a78e4073532a, rgb(186, 166, 138))", "--border-left-width": "0.5px", "--border-right-width": "0.5px", "--border-style": "solid", "--border-top-width": "0.5px", background: "linear-gradient(180deg, rgb(255, 255, 255) 0%, rgb(227, 207, 179) 100%)", borderBottomLeftRadius: 1e3, borderBottomRightRadius: 1e3, borderTopLeftRadius: 1e3, borderTopRightRadius: 1e3 }, variants: { aZuD0jNSC: { "--border-color": "var(--token-1b38fbfc-6fb2-48eb-8328-d159880837c1, rgb(138, 176, 186))", background: "linear-gradient(180deg, rgb(255, 255, 255) 0%, rgb(179, 218, 227) 100%)" }, iwvIJgSxT: { "--border-color": "var(--token-b0f905ca-4456-4e10-9d5e-13d7035c98df, rgb(199, 148, 78))", background: "linear-gradient(180deg, rgb(255, 255, 255) 0%, rgb(237, 180, 100) 100%)" }, rmDSVRFVj: { "--border-color": "var(--token-66c17a07-9665-42f4-bcc6-e569faf2b983, rgb(138, 138, 138))", background: "linear-gradient(180deg, rgb(255, 255, 255) 0%, rgb(186, 186, 186) 100%)" } }, children: /* @__PURE__ */ _jsx9(RichText5, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx9(React9.Fragment, { children: /* @__PURE__ */ _jsx9(motion9.p, { className: "framer-styles-preset-1sqkecy", "data-styles-preset": "bLruI0oTL", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(79, 79, 79))" }, children: /* @__PURE__ */ _jsx9(motion9.span, { "data-text-fill": "true", style: { backgroundImage: "linear-gradient(356deg, rgb(117, 77, 21) 0%, var(--token-86f4ddbd-7b32-4e2b-b915-97c05602f890, rgb(227, 207, 179)) 99.4774070945946%)" }, children: "New" }) }) }), className: "framer-142nmne", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__uPJhDT7tr", style: { "--extracted-r6o4lv": "rgb(79, 79, 79)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: weK3S2rqe, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides7({ aZuD0jNSC: { children: /* @__PURE__ */ _jsx9(React9.Fragment, { children: /* @__PURE__ */ _jsx9(motion9.p, { className: "framer-styles-preset-1sqkecy", "data-styles-preset": "bLruI0oTL", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(79, 79, 79))" }, children: /* @__PURE__ */ _jsx9(motion9.span, { "data-text-fill": "true", style: { backgroundImage: "linear-gradient(356deg, rgb(21, 74, 117) 0%, rgb(179, 209, 227) 100%)" }, children: "New" }) }) }) }, iwvIJgSxT: { children: /* @__PURE__ */ _jsx9(React9.Fragment, { children: /* @__PURE__ */ _jsx9(motion9.p, { className: "framer-styles-preset-1sqkecy", "data-styles-preset": "bLruI0oTL", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(79, 79, 79))" }, children: /* @__PURE__ */ _jsx9(motion9.span, { "data-text-fill": "true", style: { backgroundImage: "linear-gradient(356deg, rgb(161, 108, 18) 0%, rgb(237, 164, 62) 100%)" }, children: "New" }) }) }) }, rmDSVRFVj: { children: /* @__PURE__ */ _jsx9(React9.Fragment, { children: /* @__PURE__ */ _jsx9(motion9.p, { className: "framer-styles-preset-1sqkecy", "data-styles-preset": "bLruI0oTL", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(79, 79, 79))" }, children: /* @__PURE__ */ _jsx9(motion9.span, { "data-text-fill": "true", style: { backgroundImage: "linear-gradient(356deg, rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%)" }, children: "New" }) }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx9(RichText5, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx9(React9.Fragment, { children: /* @__PURE__ */ _jsx9(motion9.p, { className: "framer-styles-preset-y1k16k", "data-styles-preset": "WIiaJAMT7", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(156, 115, 59))" }, children: /* @__PURE__ */ _jsx9(motion9.span, { "data-text-fill": "true", style: { backgroundImage: "linear-gradient(0deg, rgb(156, 115, 59) 0%, rgba(255, 232, 199, 0.3) 100%)" }, children: "Limited edition collection" }) }) }), className: "framer-osa7ii", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__eYC6Ya7Xd", style: { "--extracted-r6o4lv": "rgb(156, 115, 59)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: eez7kHeWw, variants: { aZuD0jNSC: { "--extracted-r6o4lv": "rgb(79, 79, 79)" }, iwvIJgSxT: { "--extracted-r6o4lv": "rgb(79, 79, 79)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides7({ aZuD0jNSC: { children: /* @__PURE__ */ _jsx9(React9.Fragment, { children: /* @__PURE__ */ _jsx9(motion9.p, { className: "framer-styles-preset-y1k16k", "data-styles-preset": "WIiaJAMT7", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(79, 79, 79))" }, children: /* @__PURE__ */ _jsx9(motion9.span, { "data-text-fill": "true", style: { backgroundImage: "linear-gradient(356deg, rgb(21, 74, 117) 0%, rgb(179, 209, 227) 100%)" }, children: "Limited edition collection" }) }) }) }, iwvIJgSxT: { children: /* @__PURE__ */ _jsx9(React9.Fragment, { children: /* @__PURE__ */ _jsx9(motion9.p, { className: "framer-styles-preset-y1k16k", "data-styles-preset": "WIiaJAMT7", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(79, 79, 79))" }, children: /* @__PURE__ */ _jsx9(motion9.span, { "data-text-fill": "true", style: { backgroundImage: "linear-gradient(356deg, rgb(161, 108, 18) 0%, rgb(237, 164, 62) 100%)" }, children: "Limited edition collection" }) }) }) }, rmDSVRFVj: { children: /* @__PURE__ */ _jsx9(React9.Fragment, { children: /* @__PURE__ */ _jsx9(motion9.p, { className: "framer-styles-preset-y1k16k", "data-styles-preset": "WIiaJAMT7", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(156, 115, 59))" }, children: /* @__PURE__ */ _jsx9(motion9.span, { "data-text-fill": "true", style: { backgroundImage: "linear-gradient(0deg, rgb(0, 0, 0) 0%, rgb(224, 224, 224) 100%)" }, children: "Limited edition collection" }) }) }) } }, baseVariant, gestureVariant) })] }) }) }) });
    });
    css17 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-6KPyM.framer-z7blk, .framer-6KPyM .framer-z7blk { display: block; }", ".framer-6KPyM.framer-1qh5yry { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 6px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 4px 12px 4px 4px; position: relative; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-6KPyM .framer-1k3l7si { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 2px 6px 1px 6px; position: relative; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-6KPyM .framer-142nmne, .framer-6KPyM .framer-osa7ii { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ...css15, ...css16, '.framer-6KPyM[data-border="true"]::after, .framer-6KPyM [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
    FramerW76pPiwFl = withCSS9(Component9, css17, "framer-6KPyM");
    W76pPiwFl_default = FramerW76pPiwFl;
    FramerW76pPiwFl.displayName = "Recent Activity Chip";
    FramerW76pPiwFl.defaultProps = { height: 27, width: 205 };
    addPropertyControls8(FramerW76pPiwFl, { variant: { options: ["fzTpjTBPb", "iwvIJgSxT", "aZuD0jNSC", "rmDSVRFVj"], optionTitles: ["Beige", "Orange", "Sky Blue", "Grey"], title: "Variant", type: ControlType8.Enum }, eez7kHeWw: { defaultValue: "Limited edition collection", displayTextArea: false, title: "Title", type: ControlType8.String }, oneez7kHeWwChange: { changes: "eez7kHeWw", type: ControlType8.ChangeHandler }, weK3S2rqe: { defaultValue: "New", displayTextArea: false, title: "Tag", type: ControlType8.String }, onweK3S2rqeChange: { changes: "weK3S2rqe", type: ControlType8.ChangeHandler } });
    addFonts7(FramerW76pPiwFl, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle5(fonts7), ...getFontsFromSharedStyle5(fonts8)], { supportsExplicitInterCodegen: true });
    __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerW76pPiwFl", "slots": [], "annotations": { "framerIntrinsicWidth": "205", "framerIntrinsicHeight": "27", "framerComponentViewportWidth": "true", "framerContractVersion": "1", "framerImmutableVariables": "true", "framerVariables": '{"eez7kHeWw":"title","weK3S2rqe":"tag"}', "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"iwvIJgSxT":{"layout":["auto","auto"]},"aZuD0jNSC":{"layout":["auto","auto"]},"rmDSVRFVj":{"layout":["auto","auto"]}}}', "framerColorSyntax": "true", "framerDisplayContentsDiv": "false", "framerAutoSizeImages": "true" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
  }
});

// http-url:https://framerusercontent.com/modules/iHHfZVT7vYl7zYFJczGc/95B5lwRhZ35QWArdIoHO/pz6ecTfU2.js
import { jsx as _jsx13, jsxs as _jsxs10 } from "react/jsx-runtime";
import { addFonts as addFonts11, addPropertyControls as addPropertyControls12, ComponentViewportProvider as ComponentViewportProvider5, ControlType as ControlType12, cx as cx13, forwardLoader as forwardLoader5, getFonts as getFonts5, getFontsFromSharedStyle as getFontsFromSharedStyle9, Link as Link5, patchBorderRadiusScaleCorrector as patchBorderRadiusScaleCorrector6, RichText as RichText9, SmartComponentScopedContainer as SmartComponentScopedContainer5, useActiveVariantCallback as useActiveVariantCallback6, useComponentViewport as useComponentViewport11, useLocaleInfo as useLocaleInfo11, useVariantState as useVariantState11, withCSS as withCSS13, withFX as withFX2, withOptimizedAppearEffect as withOptimizedAppearEffect2 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup11, motion as motion13, MotionConfigContext as MotionConfigContext11 } from "framer-motion";
import * as React13 from "react";
import { useRef as useRef11 } from "react";

// http-url:https://framerusercontent.com/modules/y2d0OkoyRx7p7dPgjusY/4YW2URfY9snHeO527GYC/kw43ePOKN.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["Inter-Variable", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNTI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNTI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNTI1"]);
var variationAxes = [{ defaultValue: 14, maxValue: 32, minValue: 14, name: "Optical size", tag: "opsz" }, { defaultValue: 400, maxValue: 900, minValue: 100, name: "Weight", tag: "wght" }];
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/mYcqTSergLb16PdbJJQMl9ebYm4.woff2", variationAxes, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/ZRl8AlxwsX1m7xS1eJCiSPbztg.woff2", variationAxes, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/nhSQpBRqFmXNUBY2p5SENQ8NplQ.woff2", variationAxes, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/DYHjxG0qXjopUuruoacfl5SA.woff2", variationAxes, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/s7NH6sl7w4NU984r5hcmo1tPSYo.woff2", variationAxes, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/7lw0VWkeXrGYJT05oB3DsFy8BaY.woff2", variationAxes, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/wx5nfqEgOXnxuFaxB0Mn9OhmcZA.woff2", variationAxes, weight: "400" }] }];
var css = ['.framer-KthDU .framer-styles-preset-10suf4d:not(.rich-text-wrapper), .framer-KthDU .framer-styles-preset-10suf4d.rich-text-wrapper p { --framer-font-family: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 13px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: normal; --framer-font-style-italic: normal; --framer-font-variation-axes: "opsz" 14, "wght" 525; --framer-font-variation-axes-bold: "opsz" 14, "wght" 525; --framer-font-variation-axes-bold-italic: "opsz" 14, "wght" 525; --framer-font-variation-axes-italic: "opsz" 14, "wght" 525; --framer-font-weight: 400; --framer-font-weight-bold: 400; --framer-font-weight-bold-italic: 400; --framer-font-weight-italic: 400; --framer-letter-spacing: -0.02em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: left; --framer-text-color: var(--token-d53ec7b6-ca11-471f-93d4-6939f860246e, #000000); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className = "framer-KthDU";

// http-url:https://framerusercontent.com/modules/JLSdMdw3IEXRji0TMuUs/8L6w2VIxzdCvIF8UKkP1/QawiXOoTj.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts([]);
var fonts2 = [{ explicitInter: true, fonts: [] }];
var css2 = [".framer-LV2Ws .framer-styles-preset-1eqj9u:not(.rich-text-wrapper), .framer-LV2Ws .framer-styles-preset-1eqj9u.rich-text-wrapper a { --framer-link-current-text-color: var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, #292929); --framer-link-hover-text-color: var(--token-d53ec7b6-ca11-471f-93d4-6939f860246e, #000000); --framer-link-text-color: var(--token-bbe0c2aa-5207-4997-b514-2bd605315d76, #424242); }"];
var className2 = "framer-LV2Ws";

// http-url:https://framerusercontent.com/modules/3CbRyBziBzBaGFOrDjFm/v7VAWuazJMTdCVErDC3h/alWRNtbeL.js
import { jsx as _jsx } from "react/jsx-runtime";
import { cx, motion, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M 17.088 0.03 C 12.278 0.03 7.612 0.025 2.946 0.033 C 0.097 0.037 -0.735 1.434 0.666 3.872 C 3.803 9.334 6.98 14.774 10.079 20.258 C 11.054 21.985 12.502 22.621 14.365 22.627 C 18.02 22.64 21.681 22.54 25.33 22.694 C 33.125 23.025 39.101 26.649 43.151 33.25 C 46.832 39.248 51.907 43.181 58.87 44.375 C 68.544 46.035 77.417 41.82 82.343 33.333 C 88.064 23.476 93.734 13.591 99.42 3.714 C 100.684 1.517 99.84 0.044 97.299 0.038 C 90.949 0.022 84.6 0.052 78.251 0.02 C 76.376 0.01 75.051 0.763 74.12 2.383 C 68.944 11.388 63.746 20.379 58.556 29.375 C 58.46 29.542 58.378 29.717 58.281 29.883 C 57.057 31.979 55.781 32.011 54.576 29.939 C 52.4 26.198 50.296 22.415 48.08 18.698 C 46.013 15.233 44.344 11.517 41.787 8.36 C 37.443 2.995 31.736 0.304 24.88 0.047 C 22.334 -0.048 19.781 0.031 17.088 0.03 Z M 31.464 77.128 C 34.957 71.082 38.387 65.122 41.841 59.175 C 43.006 57.17 44.255 57.201 45.432 59.234 C 49.046 65.477 52.594 71.759 56.276 77.961 C 60.576 85.203 67.069 88.903 75.439 89.084 C 82.651 89.241 89.87 89.124 97.086 89.119 C 99.924 89.118 100.727 87.727 99.307 85.251 C 96.222 79.869 93.096 74.511 90.039 69.113 C 89.033 67.338 87.614 66.483 85.585 66.498 C 82.121 66.523 78.656 66.574 75.194 66.478 C 67.053 66.251 60.859 62.564 56.642 55.639 C 54.435 52.013 51.587 49.107 47.86 47.096 C 37.757 41.645 24.272 44.4 17.709 55.745 C 12.026 65.569 6.375 75.411 0.718 85.25 C -0.715 87.743 0.068 89.108 2.921 89.112 C 9.174 89.12 15.428 89.093 21.682 89.133 C 23.675 89.146 25.043 88.329 26.01 86.595 C 27.766 83.446 29.605 80.341 31.464 77.128 Z" fill="var(--token-20891e9f-0dd5-476a-bdd1-5f7056109a89, rgb(0, 0, 0))" height="89.16537360973305px" id="hyANsVxZq" transform="translate(0 5)" width="100px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(motion.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx("div", { ...rest, ref });
});
var getProps = ({ height, id, width, ...props }) => {
  return { ...props };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className: className9, layoutId, variant, ...restProps } = getProps(props);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-Ttzji", className9), layoutId, ref, style: { ...style } });
});
var css3 = [`.framer-Ttzji { -webkit-mask: ${mask}; aspect-ratio: 1; background-color: var(--token-20891e9f-0dd5-476a-bdd1-5f7056109a89, #000000); mask: ${mask}; width: 100px; }`];
var Icon = withCSS(Component, css3, "framer-Ttzji");
Icon.displayName = "Square Black";
var alWRNtbeL_default = Icon;

// http-url:https://framerusercontent.com/modules/pB0uzod1DzPIFquIrJSC/yt3mroBddIIBMh9RxMpi/A36GR14UW.js
import { jsx as _jsx6, jsxs as _jsxs3, Fragment as _Fragment } from "react/jsx-runtime";
import { addFonts as addFonts4, addPropertyControls as addPropertyControls5, ChildrenCanSuspend, ComponentViewportProvider, ControlType as ControlType5, cx as cx6, forwardLoader, getFonts, getFontsFromSharedStyle as getFontsFromSharedStyle3, Link as Link3, PathVariablesContext, queryCache, ResolveLinks, RichText as RichText3, SmartComponentScopedContainer, useActiveVariantCallback as useActiveVariantCallback2, useComponentViewport as useComponentViewport4, useLocaleInfo as useLocaleInfo4, useQueryData, useRouter, useVariantState as useVariantState4, withCSS as withCSS6 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup4, motion as motion6, MotionConfigContext as MotionConfigContext4 } from "framer-motion";
import * as React6 from "react";
import { useRef as useRef4 } from "react";

// http-url:https://framerusercontent.com/modules/bxbAzRjBaLPl1Q6Vqz0q/QEofGjON8Ow9ZSLvTCfX/nRUBpiZY0.js
import { addPropertyControls as e4, ControlType as t4, QueryEngine as l3 } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/bxbAzRjBaLPl1Q6Vqz0q/QEofGjON8Ow9ZSLvTCfX/nRUBpiZY0-0.js
import { ControlType as y } from "./_framer-runtime.js";
import { ControlType as P } from "./_framer-runtime.js";
var t;
var e = Object.create;
var r = Object.defineProperty;
var n = Object.getOwnPropertyDescriptor;
var i = Object.getOwnPropertyNames;
var s = Object.getPrototypeOf;
var a = Object.prototype.hasOwnProperty;
var o = (t13, e14, n10) => e14 in t13 ? r(t13, e14, { enumerable: true, configurable: true, writable: true, value: n10 }) : t13[e14] = n10;
var u = (t13, e14) => function() {
  return e14 || (0, t13[i(t13)[0]])((e14 = { exports: {} }).exports, e14), e14.exports;
};
var l = (t13, e14, s8, o9) => {
  if (e14 && "object" == typeof e14 || "function" == typeof e14)
    for (let u10 of i(e14))
      a.call(t13, u10) || u10 === s8 || r(t13, u10, { get: () => e14[u10], enumerable: !(o9 = n(e14, u10)) || o9.enumerable });
  return t13;
};
var h = (t13, n10, i7) => (i7 = null != t13 ? e(s(t13)) : {}, l(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  !n10 && t13 && t13.__esModule ? i7 : r(i7, "default", { value: t13, enumerable: true }),
  t13
));
var c = (t13, e14, r9) => o(t13, "symbol" != typeof e14 ? e14 + "" : e14, r9);
var f = u({ "../../../node_modules/dataloader/index.js"(t13, e14) {
  var r9, n10 = /* @__PURE__ */ function() {
    function t14(t15, e16) {
      if ("function" != typeof t15)
        throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but got: " + t15 + ".");
      this._batchLoadFn = t15, this._maxBatchSize = function(t16) {
        if (!(!t16 || false !== t16.batch))
          return 1;
        var e17 = t16 && t16.maxBatchSize;
        if (void 0 === e17)
          return 1 / 0;
        if ("number" != typeof e17 || e17 < 1)
          throw TypeError("maxBatchSize must be a positive number: " + e17);
        return e17;
      }(e16), this._batchScheduleFn = function(t16) {
        var e17 = t16 && t16.batchScheduleFn;
        if (void 0 === e17)
          return i7;
        if ("function" != typeof e17)
          throw TypeError("batchScheduleFn must be a function: " + e17);
        return e17;
      }(e16), this._cacheKeyFn = function(t16) {
        var e17 = t16 && t16.cacheKeyFn;
        if (void 0 === e17)
          return function(t17) {
            return t17;
          };
        if ("function" != typeof e17)
          throw TypeError("cacheKeyFn must be a function: " + e17);
        return e17;
      }(e16), this._cacheMap = function(t16) {
        if (!(!t16 || false !== t16.cache))
          return null;
        var e17 = t16 && t16.cacheMap;
        if (void 0 === e17)
          return /* @__PURE__ */ new Map();
        if (null !== e17) {
          var r10 = ["get", "set", "delete", "clear"].filter(function(t17) {
            return e17 && "function" != typeof e17[t17];
          });
          if (0 !== r10.length)
            throw TypeError("Custom cacheMap missing methods: " + r10.join(", "));
        }
        return e17;
      }(e16), this._batch = null, this.name = e16 && e16.name ? e16.name : null;
    }
    var e15 = t14.prototype;
    return e15.load = function(t15) {
      if (null == t15)
        throw TypeError("The loader.load() function must be called with a value, but got: " + String(t15) + ".");
      var e16 = function(t16) {
        var e17 = t16._batch;
        if (null !== e17 && !e17.hasDispatched && e17.keys.length < t16._maxBatchSize)
          return e17;
        var r11 = { hasDispatched: false, keys: [], callbacks: [] };
        return t16._batch = r11, t16._batchScheduleFn(function() {
          (function(t17, e18) {
            var r12;
            if (e18.hasDispatched = true, 0 === e18.keys.length) {
              a8(e18);
              return;
            }
            try {
              r12 = t17._batchLoadFn(e18.keys);
            } catch (r13) {
              return s8(t17, e18, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function errored synchronously: " + String(r13) + "."));
            }
            if (!r12 || "function" != typeof r12.then)
              return s8(t17, e18, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise: " + String(r12) + "."));
            r12.then(function(t18) {
              if (!o9(t18))
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array: " + String(t18) + ".");
              if (t18.length !== e18.keys.length)
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array of the same length as the Array of keys.\n\nKeys:\n" + String(e18.keys) + "\n\nValues:\n" + String(t18));
              a8(e18);
              for (var r13 = 0; r13 < e18.callbacks.length; r13++) {
                var n12 = t18[r13];
                n12 instanceof Error ? e18.callbacks[r13].reject(n12) : e18.callbacks[r13].resolve(n12);
              }
            }).catch(function(r13) {
              s8(t17, e18, r13);
            });
          })(t16, r11);
        }), r11;
      }(this), r10 = this._cacheMap, n11 = this._cacheKeyFn(t15);
      if (r10) {
        var i8 = r10.get(n11);
        if (i8) {
          var u10 = e16.cacheHits || (e16.cacheHits = []);
          return new Promise(function(t16) {
            u10.push(function() {
              t16(i8);
            });
          });
        }
      }
      e16.keys.push(t15);
      var l10 = new Promise(function(t16, r11) {
        e16.callbacks.push({ resolve: t16, reject: r11 });
      });
      return r10 && r10.set(n11, l10), l10;
    }, e15.loadMany = function(t15) {
      if (!o9(t15))
        throw TypeError("The loader.loadMany() function must be called with Array<key> but got: " + t15 + ".");
      for (var e16 = [], r10 = 0; r10 < t15.length; r10++)
        e16.push(this.load(t15[r10]).catch(function(t16) {
          return t16;
        }));
      return Promise.all(e16);
    }, e15.clear = function(t15) {
      var e16 = this._cacheMap;
      if (e16) {
        var r10 = this._cacheKeyFn(t15);
        e16.delete(r10);
      }
      return this;
    }, e15.clearAll = function() {
      var t15 = this._cacheMap;
      return t15 && t15.clear(), this;
    }, e15.prime = function(t15, e16) {
      var r10 = this._cacheMap;
      if (r10) {
        var n11, i8 = this._cacheKeyFn(t15);
        void 0 === r10.get(i8) && (e16 instanceof Error ? (n11 = Promise.reject(e16)).catch(function() {
        }) : n11 = Promise.resolve(e16), r10.set(i8, n11));
      }
      return this;
    }, t14;
  }(), i7 = "object" == typeof process && "function" == typeof process.nextTick ? function(t14) {
    r9 || (r9 = Promise.resolve()), r9.then(function() {
      process.nextTick(t14);
    });
  } : "function" == typeof setImmediate ? function(t14) {
    setImmediate(t14);
  } : function(t14) {
    setTimeout(t14);
  };
  function s8(t14, e15, r10) {
    a8(e15);
    for (var n11 = 0; n11 < e15.keys.length; n11++)
      t14.clear(e15.keys[n11]), e15.callbacks[n11].reject(r10);
  }
  function a8(t14) {
    if (t14.cacheHits)
      for (var e15 = 0; e15 < t14.cacheHits.length; e15++)
        t14.cacheHits[e15]();
  }
  function o9(t14) {
    return "object" == typeof t14 && null !== t14 && "number" == typeof t14.length && (0 === t14.length || t14.length > 0 && Object.prototype.hasOwnProperty.call(t14, t14.length - 1));
  }
  e14.exports = n10;
} });
var d = h(f(), 1);
var g = { Uint8: 1, Uint16: 2, Uint32: 4, BigUint64: 8, Int8: 1, Int16: 2, Int32: 4, BigInt64: 8, Float32: 4, Float64: 8 };
var p = class {
  getOffset() {
    return this.offset;
  }
  ensureLength(t13) {
    let e14 = this.bytes.length;
    if (!(this.offset + t13 <= e14))
      throw Error("Reading out of bounds");
  }
  readUint8() {
    let t13 = g.Uint8;
    this.ensureLength(t13);
    let e14 = this.view.getUint8(this.offset);
    return this.offset += t13, e14;
  }
  readUint16() {
    let t13 = g.Uint16;
    this.ensureLength(t13);
    let e14 = this.view.getUint16(this.offset);
    return this.offset += t13, e14;
  }
  readUint32() {
    let t13 = g.Uint32;
    this.ensureLength(t13);
    let e14 = this.view.getUint32(this.offset);
    return this.offset += t13, e14;
  }
  readUint64() {
    let t13 = this.readBigUint64();
    return Number(t13);
  }
  readBigUint64() {
    let t13 = g.BigUint64;
    this.ensureLength(t13);
    let e14 = this.view.getBigUint64(this.offset);
    return this.offset += t13, e14;
  }
  readInt8() {
    let t13 = g.Int8;
    this.ensureLength(t13);
    let e14 = this.view.getInt8(this.offset);
    return this.offset += t13, e14;
  }
  readInt16() {
    let t13 = g.Int16;
    this.ensureLength(t13);
    let e14 = this.view.getInt16(this.offset);
    return this.offset += t13, e14;
  }
  readInt32() {
    let t13 = g.Int32;
    this.ensureLength(t13);
    let e14 = this.view.getInt32(this.offset);
    return this.offset += t13, e14;
  }
  readInt64() {
    let t13 = this.readBigInt64();
    return Number(t13);
  }
  readBigInt64() {
    let t13 = g.BigInt64;
    this.ensureLength(t13);
    let e14 = this.view.getBigInt64(this.offset);
    return this.offset += t13, e14;
  }
  readFloat32() {
    let t13 = g.Float32;
    this.ensureLength(t13);
    let e14 = this.view.getFloat32(this.offset);
    return this.offset += t13, e14;
  }
  readFloat64() {
    let t13 = g.Float64;
    this.ensureLength(t13);
    let e14 = this.view.getFloat64(this.offset);
    return this.offset += t13, e14;
  }
  readBytes(t13) {
    let e14 = this.offset, r9 = e14 + t13, n10 = this.bytes.subarray(e14, r9);
    return this.offset = r9, n10;
  }
  readString() {
    let t13 = this.readUint32(), e14 = this.readBytes(t13);
    return this.decoder.decode(e14);
  }
  readJson() {
    let t13 = this.readString();
    return JSON.parse(t13);
  }
  constructor(t13) {
    this.bytes = t13, c(this, "offset", 0), c(this, "view"), c(this, "decoder", new TextDecoder()), this.view = v(this.bytes);
  }
};
function v(t13) {
  return new DataView(t13.buffer, t13.byteOffset, t13.byteLength);
}
var m = "undefined" != typeof __dai_window;
var w = m && "function" == typeof __dai_window.requestIdleCallback;
function I(t13, ...e14) {
  if (!t13)
    throw Error("Assertion Error" + (e14.length > 0 ? ": " + e14.join(" ") : ""));
}
function b(t13) {
  throw Error(`Unexpected value: ${t13}`);
}
var k = (t13) => 2 ** t13 - 1;
var L = (t13) => -(2 ** (t13 - 1));
var B = (t13) => 2 ** (t13 - 1) - 1;
var E = { Uint8: 0, Uint16: 0, Uint32: 0, Uint64: 0, BigUint64: 0, Int8: L(8), Int16: L(16), Int32: L(32), Int64: Number.MIN_SAFE_INTEGER, BigInt64: -(BigInt(2) ** BigInt(63)) };
var M = { Uint8: k(8), Uint16: k(16), Uint32: k(32), Uint64: Number.MAX_SAFE_INTEGER, BigUint64: BigInt(2) ** BigInt(64) - BigInt(1), Int8: B(8), Int16: B(16), Int32: B(32), Int64: Number.MAX_SAFE_INTEGER, BigInt64: BigInt(2) ** BigInt(63) - BigInt(1) };
function x(t13) {
  return "string" == typeof t13;
}
function N(t13) {
  return Number.isFinite(t13);
}
function A(t13) {
  return null === t13;
}
var O = class t2 {
  static fromString(e14) {
    let [r9, n10, i7] = e14.split("/").map(Number);
    return I(N(r9), "Invalid chunkId"), I(N(n10), "Invalid offset"), I(N(i7), "Invalid length"), new t2(r9, n10, i7);
  }
  toString() {
    return `${this.chunkId}/${this.offset}/${this.length}`;
  }
  static read(e14) {
    let r9 = e14.readUint16(), n10 = e14.readUint32(), i7 = e14.readUint32();
    return new t2(r9, n10, i7);
  }
  write(t13) {
    t13.writeUint16(this.chunkId), t13.writeUint32(this.offset), t13.writeUint32(this.length);
  }
  compare(t13) {
    return this.chunkId < t13.chunkId ? -1 : this.chunkId > t13.chunkId ? 1 : this.offset < t13.offset ? -1 : this.offset > t13.offset ? 1 : (I(this.length === t13.length), 0);
  }
  constructor(t13, e14, r9) {
    this.chunkId = t13, this.offset = e14, this.length = r9;
  }
};
function R(t13) {
  if (A(t13))
    return 0;
  switch (t13.type) {
    case P.Array:
      return 1;
    case P.Boolean:
      return 2;
    case P.Color:
      return 3;
    case P.Date:
      return 4;
    case P.Enum:
      return 5;
    case P.File:
      return 6;
    case P.ResponsiveImage:
      return 10;
    case P.Link:
      return 7;
    case P.Number:
      return 8;
    case P.Object:
      return 9;
    case P.RichText:
      return 11;
    case P.String:
      return 12;
    case P.VectorSetItem:
      return 13;
    default:
      b(t13);
  }
}
function q(e14) {
  let r9 = e14.readUint16(), n10 = [];
  for (let i7 = 0; i7 < r9; i7++) {
    let r10 = t.read(e14);
    n10.push(r10);
  }
  return { type: P.Array, value: n10 };
}
function _(e14, r9) {
  for (let n10 of (e14.writeUint16(r9.value.length), r9.value))
    t.write(e14, n10);
}
function D(e14, r9, n10) {
  let i7 = e14.value.length, s8 = r9.value.length;
  if (i7 < s8)
    return -1;
  if (i7 > s8)
    return 1;
  for (let s9 = 0; s9 < i7; s9++) {
    let i8 = e14.value[s9], a8 = r9.value[s9], o9 = t.compare(i8, a8, n10);
    if (0 !== o9)
      return o9;
  }
  return 0;
}
function j(t13) {
  return { type: P.Boolean, value: 0 !== t13.readUint8() };
}
function C(t13, e14) {
  t13.writeUint8(e14.value ? 1 : 0);
}
function J(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function V(t13) {
  return { type: P.Color, value: t13.readString() };
}
function W(t13, e14) {
  t13.writeString(e14.value);
}
function $(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function z(t13) {
  let e14 = t13.readInt64(), r9 = new Date(e14);
  return { type: P.Date, value: r9.toISOString() };
}
function G(t13, e14) {
  let r9 = new Date(e14.value), n10 = r9.getTime();
  t13.writeInt64(n10);
}
function K(t13, e14) {
  let r9 = new Date(t13.value), n10 = new Date(e14.value);
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
function H(t13) {
  return { type: P.Enum, value: t13.readString() };
}
function X(t13, e14) {
  t13.writeString(e14.value);
}
function Q(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function Y(t13) {
  return { type: P.File, value: t13.readString() };
}
function Z(t13, e14) {
  t13.writeString(e14.value);
}
function tt(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function te(t13) {
  return { type: P.Link, value: t13.readJson() };
}
function tr(t13, e14) {
  t13.writeJson(e14.value);
}
function tn(t13, e14) {
  let r9 = JSON.stringify(t13.value), n10 = JSON.stringify(e14.value);
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
function ti(t13) {
  return { type: P.Number, value: t13.readFloat64() };
}
function ts(t13, e14) {
  t13.writeFloat64(e14.value);
}
function ta(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function to(e14) {
  let r9 = e14.readUint16(), n10 = {};
  for (let i7 = 0; i7 < r9; i7++) {
    let r10 = e14.readString();
    n10[r10] = t.read(e14);
  }
  return { type: P.Object, value: n10 };
}
function tu(e14, r9) {
  let n10 = Object.entries(r9.value);
  for (let [r10, i7] of (e14.writeUint16(n10.length), n10))
    e14.writeString(r10), t.write(e14, i7);
}
function tl(e14, r9, n10) {
  let i7 = Object.keys(e14.value).sort(), s8 = Object.keys(r9.value).sort();
  if (i7.length < s8.length)
    return -1;
  if (i7.length > s8.length)
    return 1;
  for (let a8 = 0; a8 < i7.length; a8++) {
    let o9 = i7[a8], u10 = s8[a8];
    if (o9 < u10)
      return -1;
    if (o9 > u10)
      return 1;
    let l10 = e14.value[o9] ?? null, h5 = r9.value[u10] ?? null, c9 = t.compare(l10, h5, n10);
    if (0 !== c9)
      return c9;
  }
  return 0;
}
function th(t13) {
  return { type: P.ResponsiveImage, value: t13.readJson() };
}
function tc(t13, e14) {
  t13.writeJson(e14.value);
}
function tf(t13, e14) {
  let r9 = JSON.stringify(t13.value), n10 = JSON.stringify(e14.value);
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
function td(t13) {
  let e14 = t13.readInt8();
  if (0 === e14)
    return { type: P.RichText, value: t13.readUint32() };
  if (1 === e14)
    return { type: P.RichText, value: t13.readString() };
  throw Error("Invalid rich text pointer");
}
function tg(t13, e14) {
  if (N(e14.value)) {
    t13.writeInt8(0), t13.writeUint32(e14.value);
    return;
  }
  if (x(e14.value)) {
    t13.writeInt8(1), t13.writeString(e14.value);
    return;
  }
  throw Error("Invalid rich text pointer");
}
function tp(t13, e14) {
  let r9 = t13.value, n10 = e14.value;
  if (N(r9) && N(n10) || x(r9) && x(n10))
    return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
  throw Error("Invalid rich text pointer");
}
function tv(t13) {
  return { type: P.String, value: t13.readString() };
}
function ty(t13, e14) {
  t13.writeString(e14.value);
}
function tm(t13, e14, r9) {
  let n10 = t13.value, i7 = e14.value;
  return (0 === r9.type && (n10 = t13.value.toLowerCase(), i7 = e14.value.toLowerCase()), n10 < i7) ? -1 : n10 > i7 ? 1 : 0;
}
function tw(t13) {
  return { type: P.VectorSetItem, value: t13.readUint32() };
}
function tI(t13, e14) {
  t13.writeUint32(e14.value);
}
function tb(t13, e14) {
  let r9 = t13.value, n10 = e14.value;
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
((t13) => {
  t13.read = function(t14) {
    let e14 = t14.readUint8();
    switch (e14) {
      case 0:
        return null;
      case 1:
        return q(t14);
      case 2:
        return j(t14);
      case 3:
        return V(t14);
      case 4:
        return z(t14);
      case 5:
        return H(t14);
      case 6:
        return Y(t14);
      case 7:
        return te(t14);
      case 8:
        return ti(t14);
      case 9:
        return to(t14);
      case 10:
        return th(t14);
      case 11:
        return td(t14);
      case 12:
        return tv(t14);
      case 13:
        return tw(t14);
      default:
        b(e14);
    }
  }, t13.write = function(t14, e14) {
    let r9 = R(e14);
    if (t14.writeUint8(r9), !A(e14))
      switch (e14.type) {
        case P.Array:
          return _(t14, e14);
        case P.Boolean:
          return C(t14, e14);
        case P.Color:
          return W(t14, e14);
        case P.Date:
          return G(t14, e14);
        case P.Enum:
          return X(t14, e14);
        case P.File:
          return Z(t14, e14);
        case P.Link:
          return tr(t14, e14);
        case P.Number:
          return ts(t14, e14);
        case P.Object:
          return tu(t14, e14);
        case P.ResponsiveImage:
          return tc(t14, e14);
        case P.RichText:
          return tg(t14, e14);
        case P.VectorSetItem:
          return tI(t14, e14);
        case P.String:
          return ty(t14, e14);
        default:
          b(e14);
      }
  }, t13.compare = function(t14, e14, r9) {
    let n10 = R(t14), i7 = R(e14);
    if (n10 < i7)
      return -1;
    if (n10 > i7)
      return 1;
    if (A(t14) || A(e14))
      return 0;
    switch (t14.type) {
      case P.Array:
        return I(e14.type === P.Array), D(t14, e14, r9);
      case P.Boolean:
        return I(e14.type === P.Boolean), J(t14, e14);
      case P.Color:
        return I(e14.type === P.Color), $(t14, e14);
      case P.Date:
        return I(e14.type === P.Date), K(t14, e14);
      case P.Enum:
        return I(e14.type === P.Enum), Q(t14, e14);
      case P.File:
        return I(e14.type === P.File), tt(t14, e14);
      case P.Link:
        return I(e14.type === P.Link), tn(t14, e14);
      case P.Number:
        return I(e14.type === P.Number), ta(t14, e14);
      case P.Object:
        return I(e14.type === P.Object), tl(t14, e14, r9);
      case P.ResponsiveImage:
        return I(e14.type === P.ResponsiveImage), tf(t14, e14);
      case P.RichText:
        return I(e14.type === P.RichText), tp(t14, e14);
      case P.VectorSetItem:
        return I(e14.type === P.VectorSetItem), tb(t14, e14);
      case P.String:
        return I(e14.type === P.String), tm(t14, e14, r9);
      default:
        b(t14);
    }
  };
})(t || (t = {}));
var tS = 3;
var tk = 250;
var tL = [
  408,
  // Request Timeout
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
];
var tB = async (t13, e14) => {
  let r9 = 0;
  for (; ; ) {
    try {
      let n10 = await fetch(t13, e14);
      if (!tL.includes(n10.status) || ++r9 > tS)
        return n10;
    } catch (t14) {
      if (e14?.signal?.aborted || ++r9 > tS)
        throw t14;
    }
    await tE(r9);
  }
};
async function tE(t13) {
  let e14 = Math.floor(tk * (Math.random() + 1) * 2 ** (t13 - 1));
  await new Promise((t14) => {
    setTimeout(t14, e14);
  });
}
async function tM(t13, e14) {
  let r9 = tx(e14), n10 = [], i7 = 0;
  for (let t14 of r9)
    n10.push(`${t14.from}-${t14.to - 1}`), i7 += t14.to - t14.from;
  let s8 = new URL(t13), a8 = n10.join(",");
  s8.searchParams.set("range", a8);
  let o9 = await tB(s8);
  if (200 !== o9.status)
    throw Error(`Request failed: ${o9.status} ${o9.statusText}`);
  let u10 = await o9.arrayBuffer(), l10 = new Uint8Array(u10);
  if (l10.length !== i7)
    throw Error("Request failed: Unexpected response length");
  let h5 = new tT(), c9 = 0;
  for (let t14 of r9) {
    let e15 = t14.to - t14.from, r10 = c9 + e15, n11 = l10.subarray(c9, r10);
    h5.write(t14.from, n11), c9 = r10;
  }
  return e14.map((t14) => h5.read(t14.from, t14.to - t14.from));
}
var tT = class {
  read(t13, e14) {
    for (let r9 of this.chunks) {
      if (t13 < r9.start)
        break;
      if (t13 > r9.end)
        continue;
      if (t13 + e14 > r9.end)
        break;
      let n10 = t13 - r9.start, i7 = n10 + e14;
      return r9.data.slice(n10, i7);
    }
    throw Error("Missing data");
  }
  write(t13, e14) {
    let r9 = t13, n10 = r9 + e14.length, i7 = 0, s8 = this.chunks.length;
    for (; i7 < s8; i7++) {
      let t14 = this.chunks[i7];
      if (I(t14, "Missing chunk"), !(r9 > t14.end)) {
        if (r9 > t14.start) {
          let n11 = r9 - t14.start, i8 = t14.data.subarray(0, n11);
          e14 = tF(i8, e14), r9 = t14.start;
        }
        break;
      }
    }
    for (; s8 > i7; s8--) {
      let t14 = this.chunks[s8 - 1];
      if (I(t14, "Missing chunk"), !(n10 < t14.start)) {
        if (n10 < t14.end) {
          let r10 = n10 - t14.start, i8 = t14.data.subarray(r10);
          e14 = tF(e14, i8), n10 = t14.end;
        }
        break;
      }
    }
    let a8 = { start: r9, end: n10, data: e14 }, o9 = s8 - i7;
    this.chunks.splice(i7, o9, a8);
  }
  constructor() {
    c(this, "chunks", []);
  }
};
function tF(t13, e14) {
  let r9 = t13.length + e14.length, n10 = new Uint8Array(r9);
  return n10.set(t13, 0), n10.set(e14, t13.length), n10;
}
function tx(t13) {
  I(t13.length > 0, "Must have at least one range");
  let e14 = [...t13].sort((t14, e15) => t14.from - e15.from), r9 = [];
  for (let t14 of e14) {
    let e15 = r9.length - 1, n10 = r9[e15];
    n10 && t14.from <= n10.to ? r9[e15] = { from: n10.from, to: Math.max(n10.to, t14.to) } : r9.push(t14);
  }
  return r9;
}
var tA = class e2 {
  static read(r9) {
    let n10 = new e2(), i7 = r9.readUint16();
    for (let e14 = 0; e14 < i7; e14++) {
      let e15 = r9.readString(), i8 = t.read(r9);
      n10.setField(e15, i8);
    }
    return n10;
  }
  write(e14) {
    for (let [r9, n10] of (e14.writeUint16(this.fields.size), this.fields))
      e14.writeString(r9), t.write(e14, n10);
  }
  getData() {
    let t13 = {};
    for (let [e14, r9] of this.fields)
      t13[e14] = r9;
    return t13;
  }
  setField(t13, e14) {
    this.fields.set(t13, e14);
  }
  getField(t13) {
    return this.fields.get(t13);
  }
  constructor() {
    c(this, "fields", /* @__PURE__ */ new Map());
  }
};
var tO = class {
  scanItems() {
    return this.itemsPromise ?? (this.itemsPromise = tB(this.url).then(async (t13) => {
      if (!t13.ok)
        throw Error(`Request failed: ${t13.status} ${t13.statusText}`);
      let e14 = await t13.arrayBuffer(), r9 = new Uint8Array(e14), n10 = new p(r9), i7 = [], s8 = n10.readUint32();
      for (let t14 = 0; t14 < s8; t14++) {
        let t15 = n10.getOffset(), e15 = tA.read(n10), r10 = n10.getOffset() - t15, s9 = new O(this.id, t15, r10), a8 = s9.toString(), o9 = { pointer: a8, data: e15.getData() };
        this.itemLoader.prime(a8, o9), i7.push(o9);
      }
      return i7;
    })), this.itemsPromise;
  }
  resolveItem(t13) {
    return this.itemLoader.load(t13);
  }
  constructor(t13, e14) {
    this.id = t13, this.url = e14, c(this, "itemsPromise"), c(this, "itemLoader", new d.default(async (t14) => {
      let e15 = t14.map((t15) => {
        let e16 = O.fromString(t15);
        return { from: e16.offset, to: e16.offset + e16.length };
      }), r9 = await tM(this.url, e15);
      return r9.map((e16, r10) => {
        let n10 = new p(e16), i7 = tA.read(n10), s8 = t14[r10];
        return I(s8, "Missing pointer"), { pointer: s8, data: i7.getData() };
      });
    }, { maxBatchSize: 250 }));
  }
};
var tP = class {
  async scanItems() {
    let t13 = await Promise.all(this.chunks.map(async (t14) => t14.scanItems()));
    return t13.flat();
  }
  resolveItems(t13) {
    return Promise.all(t13.map((t14) => {
      let e14 = O.fromString(t14), r9 = this.chunks[e14.chunkId];
      return I(r9, "Missing chunk"), r9.resolveItem(t14);
    }));
  }
  compareItems(t13, e14) {
    let r9 = O.fromString(t13.pointer), n10 = O.fromString(e14.pointer);
    return r9.compare(n10);
  }
  compareValues(e14, r9, n10) {
    return t.compare(e14, r9, n10);
  }
  constructor(t13) {
    this.options = t13, c(this, "id"), c(this, "schema"), c(this, "indexes"), c(this, "resolveRichText"), c(this, "resolveVectorSetItem"), c(this, "chunks"), this.chunks = this.options.chunks.map((t14, e14) => new tO(e14, t14)), this.schema = t13.schema, this.indexes = t13.indexes, this.resolveRichText = t13.resolveRichText, this.resolveVectorSetItem = t13.resolveVectorSetItem, this.id = t13.id;
  }
};

// http-url:https://framerusercontent.com/modules/bxbAzRjBaLPl1Q6Vqz0q/QEofGjON8Ow9ZSLvTCfX/nRUBpiZY0-1.js
import { jsx as e3 } from "react/jsx-runtime";
import { AutoBreakpointVariant as t3, ComponentPresetsConsumer as r2, Link as n2, motion as o2 } from "./_framer-runtime.js";
import { isValidElement as i2 } from "react";
import { Fragment as p2, createElement as s2 } from "react";
var a2;
var l2 = "undefined" != typeof __dai_window;
var f2 = l2 && "function" == typeof __dai_window.requestIdleCallback;
var u2 = "preload";
function c2(e14) {
  return "object" == typeof e14 && null !== e14 && !/* @__PURE__ */ i2(e14) && u2 in e14;
}
function m2(e14, ...t13) {
  if (!e14)
    throw Error("Assertion Error" + (t13.length > 0 ? ": " + t13.join(" ") : ""));
}
var d2 = ((a2 = d2 || {})[a2.Fragment = 1] = "Fragment", a2[a2.Link = 2] = "Link", a2[a2.Module = 3] = "Module", a2[a2.Tag = 4] = "Tag", a2[a2.Text = 5] = "Text", a2);
function g2(i7) {
  let a8 = /* @__PURE__ */ new Map();
  return (l10) => {
    let f8 = a8.get(l10);
    if (f8)
      return f8;
    let u10 = JSON.parse(l10), d10 = function a9(l11) {
      switch (l11[0]) {
        case 1: {
          let [, ...e14] = l11, t13 = e14.map(a9);
          return /* @__PURE__ */ s2(p2, void 0, ...t13);
        }
        case 2: {
          let [, e14, ...t13] = l11, r9 = t13.map(a9);
          return /* @__PURE__ */ s2(n2, e14, ...r9);
        }
        case 3: {
          let [, n10, o9, f9, u11] = l11;
          for (let e14 of f9) {
            let t13 = o9[e14];
            t13 && (o9[e14] = a9(t13));
          }
          for (let e14 of u11) {
            let t13 = o9[e14];
            if ("string" != typeof t13)
              continue;
            let r9 = i7[t13];
            r9 && (c2(r9) && r9.preload(), o9[e14] = r9);
          }
          let p10 = i7[n10];
          return m2(p10, "Module not found"), c2(p10) && p10.preload(), /* @__PURE__ */ e3(r2, { componentIdentifier: n10, children: (r9) => /* @__PURE__ */ e3(t3, { component: p10, props: { ...r9, ...o9 } }) });
        }
        case 4: {
          let [, e14, t13, ...r9] = l11, n10 = r9.map(a9);
          if ("a" === e14)
            return /* @__PURE__ */ s2(o2.a, t13, ...n10);
          return /* @__PURE__ */ s2(e14, t13, ...n10);
        }
        case 5: {
          let [, e14] = l11;
          return e14;
        }
      }
    }(u10);
    return a8.set(l10, d10), d10;
  };
}

// http-url:https://framerusercontent.com/modules/bxbAzRjBaLPl1Q6Vqz0q/QEofGjON8Ow9ZSLvTCfX/nRUBpiZY0.js
var n3 = { CFyGUV2JN: { isNullable: true, type: t4.String }, createdAt: { isNullable: true, type: t4.Date }, dQLMp3Snn: { isNullable: true, type: t4.String }, H9WdVkZCK: { isNullable: true, type: t4.String }, id: { isNullable: false, type: t4.String }, iHo87M7PO: { isNullable: true, type: t4.String }, iiMCZWLBK: { isNullable: true, type: t4.Link }, MS1Ep5QnQ: { isNullable: true, type: t4.Date }, nextItemId: { isNullable: true, type: t4.String }, previousItemId: { isNullable: true, type: t4.String }, qHzx1Qnq4: { isNullable: true, type: t4.Date }, qVHdJamkG: { isNullable: true, type: t4.Link }, T0OpxvaIF: { isNullable: true, type: t4.RichText }, updatedAt: { isNullable: true, type: t4.Date }, vDyzh1chb: { isNullable: true, type: t4.ResponsiveImage } };
var p3 = [];
var r3 = (e14) => {
  let t13 = p3[e14];
  if (t13)
    return t13().then((e15) => e15.default);
};
var o3 = {};
var d3 = g2(o3);
var u3 = new l3();
var y2 = { collectionByLocaleId: { default: new tP({ chunks: [""], id: "53891c41-ecb1-4b0e-97f1-453a6b8d2052default", indexes: [], resolveRichText: d3, resolveVectorSetItem: r3, schema: n3 }) }, displayName: "Stores", id: "53891c41-ecb1-4b0e-97f1-453a6b8d2052" };
var nRUBpiZY0_default = y2;
e4(y2, { iHo87M7PO: { defaultValue: "", title: "Store Name", type: t4.String }, dQLMp3Snn: { preventLocalization: true, title: "Slug", type: t4.String }, CFyGUV2JN: { defaultValue: "", title: "Google Coordinates", type: t4.String }, qVHdJamkG: { title: "Google Maps Link", type: t4.Link }, T0OpxvaIF: { defaultValue: "", title: "Store Address", type: t4.RichText }, H9WdVkZCK: { defaultValue: "", title: "Store Contact", type: t4.String }, iiMCZWLBK: { title: "Store Contact Link", type: t4.Link }, qHzx1Qnq4: { displayTime: true, title: "Opens At", type: t4.Date }, MS1Ep5QnQ: { displayTime: true, title: "Closes At", type: t4.Date }, vDyzh1chb: { title: "Store Image", type: t4.ResponsiveImage }, createdAt: { title: "Created", type: t4.Date }, updatedAt: { title: "Updated", type: t4.Date }, previousItemId: { dataIdentifier: "local-module:collection/nRUBpiZY0:default", title: "Previous", type: t4.CollectionReference }, nextItemId: { dataIdentifier: "local-module:collection/nRUBpiZY0:default", title: "Next", type: t4.CollectionReference } });

// http-url:https://framerusercontent.com/modules/XcWm95OqMMgibdoCvVcb/deChp29LadbLFuqjm8mg/hWdlH0iq7.js
import { fontStore as fontStore3 } from "./_framer-runtime.js";
fontStore3.loadFonts(["Inter-Variable", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNTI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNTI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNTI1"]);
var variationAxes2 = [{ defaultValue: 14, maxValue: 32, minValue: 14, name: "Optical size", tag: "opsz" }, { defaultValue: 400, maxValue: 900, minValue: 100, name: "Weight", tag: "wght" }];
var fonts3 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/mYcqTSergLb16PdbJJQMl9ebYm4.woff2", variationAxes: variationAxes2, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/ZRl8AlxwsX1m7xS1eJCiSPbztg.woff2", variationAxes: variationAxes2, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/nhSQpBRqFmXNUBY2p5SENQ8NplQ.woff2", variationAxes: variationAxes2, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/DYHjxG0qXjopUuruoacfl5SA.woff2", variationAxes: variationAxes2, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/s7NH6sl7w4NU984r5hcmo1tPSYo.woff2", variationAxes: variationAxes2, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/7lw0VWkeXrGYJT05oB3DsFy8BaY.woff2", variationAxes: variationAxes2, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/wx5nfqEgOXnxuFaxB0Mn9OhmcZA.woff2", variationAxes: variationAxes2, weight: "400" }] }];
var css4 = ['.framer-M6mYX .framer-styles-preset-1nkfhjw:not(.rich-text-wrapper), .framer-M6mYX .framer-styles-preset-1nkfhjw.rich-text-wrapper p { --framer-font-family: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 16px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: normal; --framer-font-style-italic: normal; --framer-font-variation-axes: "opsz" 14, "wght" 525; --framer-font-variation-axes-bold: "opsz" 14, "wght" 525; --framer-font-variation-axes-bold-italic: "opsz" 14, "wght" 525; --framer-font-variation-axes-italic: "opsz" 14, "wght" 525; --framer-font-weight: 400; --framer-font-weight-bold: 400; --framer-font-weight-bold-italic: 400; --framer-font-weight-italic: 400; --framer-letter-spacing: -0.03em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: left; --framer-text-color: var(--token-d53ec7b6-ca11-471f-93d4-6939f860246e, #000000); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className3 = "framer-M6mYX";

// http-url:https://framerusercontent.com/modules/Fs5VQrVyKoruA9COVjYx/V45WQoTRvnjjKwxyThBd/wggGXhZaC.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx as cx2, motion as motion2, withCSS as withCSS2 } from "./_framer-runtime.js";
import * as React2 from "react";
import { forwardRef as forwardRef4 } from "react";
var mask2 = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M 0 39.757 L 38.539 1.218 C 39.317 0.438 40.373 0 41.475 0 C 42.577 0 43.633 0.438 44.411 1.218 L 82.95 39.757 M 41.475 14.872 L 41.475 81.232" fill="transparent" height="81.23205219268812px" id="jOHsmej4_" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="16.59" stroke="var(--118a55, var(--token-20891e9f-0dd5-476a-bdd1-5f7056109a89, rgb(0, 0, 0)))" transform="translate(8.5 9.51) rotate(90 41.475 40.616)" width="82.95000000000005px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG2 = /* @__PURE__ */ forwardRef4((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx2(motion2.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx2("div", { ...rest, ref });
});
var getProps2 = ({ color, height, id, width, ...props }) => {
  return { ...props, GaDHsaDms: color ?? props.GaDHsaDms ?? "var(--token-20891e9f-0dd5-476a-bdd1-5f7056109a89, rgb(0, 0, 0))" };
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const { style, className: className9, layoutId, variant, GaDHsaDms, ...restProps } = getProps2(props);
  return /* @__PURE__ */ _jsx2(SVG2, { ...restProps, className: cx2("framer-ZtDxP", className9), layoutId, ref, style: { "--118a55": GaDHsaDms, ...style } });
});
var css5 = [`.framer-ZtDxP { -webkit-mask: ${mask2}; aspect-ratio: 1; background-color: var(--118a55); mask: ${mask2}; width: 100px; }`];
var Icon2 = withCSS2(Component2, css5, "framer-ZtDxP");
Icon2.displayName = "Arrow Right";
var wggGXhZaC_default = Icon2;
addPropertyControls(Icon2, { GaDHsaDms: { defaultValue: 'var(--token-20891e9f-0dd5-476a-bdd1-5f7056109a89, rgb(0, 0, 0)) /* {"name":"Icon Black"} */', hidden: false, title: "Color", type: ControlType.Color } });

// http-url:https://framerusercontent.com/modules/43vtRLgqAD4qjXRuHU4x/NLk3lqJPLUt0ooeBkBx4/b_m5Js9Ir.js
import { jsx as _jsx3, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx3, getFontsFromSharedStyle, Instance, Link, RichText, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS3 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion3, MotionConfigContext } from "framer-motion";
import * as React3 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/pmoggTWmhxccZ8VWFvMy/CwgfCjbZuajs7tE5WxYA/ocOde6Lm9.js
import { fontStore as fontStore4 } from "./_framer-runtime.js";
fontStore4.loadFonts(["Inter-Variable", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNjI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNjI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNjI1"]);
var variationAxes3 = [{ defaultValue: 14, maxValue: 32, minValue: 14, name: "Optical size", tag: "opsz" }, { defaultValue: 400, maxValue: 900, minValue: 100, name: "Weight", tag: "wght" }];
var fonts4 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/mYcqTSergLb16PdbJJQMl9ebYm4.woff2", variationAxes: variationAxes3, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/ZRl8AlxwsX1m7xS1eJCiSPbztg.woff2", variationAxes: variationAxes3, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/nhSQpBRqFmXNUBY2p5SENQ8NplQ.woff2", variationAxes: variationAxes3, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/DYHjxG0qXjopUuruoacfl5SA.woff2", variationAxes: variationAxes3, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/s7NH6sl7w4NU984r5hcmo1tPSYo.woff2", variationAxes: variationAxes3, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/7lw0VWkeXrGYJT05oB3DsFy8BaY.woff2", variationAxes: variationAxes3, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/wx5nfqEgOXnxuFaxB0Mn9OhmcZA.woff2", variationAxes: variationAxes3, weight: "400" }] }];
var css6 = ['.framer-hoAO6 .framer-styles-preset-1v7qm6:not(.rich-text-wrapper), .framer-hoAO6 .framer-styles-preset-1v7qm6.rich-text-wrapper p { --framer-font-family: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 13px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: normal; --framer-font-style-italic: normal; --framer-font-variation-axes: "opsz" 14, "wght" 625; --framer-font-variation-axes-bold: "opsz" 14, "wght" 625; --framer-font-variation-axes-bold-italic: "opsz" 14, "wght" 625; --framer-font-variation-axes-italic: "opsz" 14, "wght" 625; --framer-font-weight: 400; --framer-font-weight-bold: 400; --framer-font-weight-bold-italic: 400; --framer-font-weight-italic: 400; --framer-letter-spacing: -0.04em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: center; --framer-text-color: var(--token-d53ec7b6-ca11-471f-93d4-6939f860246e, #000000); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className4 = "framer-hoAO6";

// http-url:https://framerusercontent.com/modules/43vtRLgqAD4qjXRuHU4x/NLk3lqJPLUt0ooeBkBx4/b_m5Js9Ir.js
var enabledGestures = { fGebBpVaS: { hover: true }, zq5haw0aW: { hover: true } };
var cycleOrder = ["fGebBpVaS", "zq5haw0aW"];
var serializationHash = "framer-3PDQe";
var variantClassNames = { fGebBpVaS: "framer-v-1o0lmo4", zq5haw0aW: "framer-v-ae5cq4" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Primary: "fGebBpVaS", Secondary: "zq5haw0aW" };
var Variants = motion3.create(React3.Fragment);
var getProps3 = ({ click, height, icon, id, link, showIcon, title, width, ...props }) => {
  return { ...props, DY2dzgeiO: click ?? props.DY2dzgeiO, hZdVwdl_Y: showIcon ?? props.hZdVwdl_Y ?? false, peKL8pfJA: icon ?? props.peKL8pfJA ?? wggGXhZaC_default, TDPWRYXxk: title ?? props.TDPWRYXxk ?? "Button", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "fGebBpVaS", vFRI3q06T: link ?? props.vFRI3q06T };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className9, layoutId, variant, TDPWRYXxk, vFRI3q06T, DY2dzgeiO, peKL8pfJA, hZdVwdl_Y, ...restProps } = getProps3(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "fGebBpVaS", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTappg0bwd = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    if (DY2dzgeiO) {
      const res = await DY2dzgeiO(...args);
      if (res === false)
        return false;
    }
  });
  const sharedStyleClassNames = [className4, className];
  const scopingClassNames = cx3(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx3(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition, { value: transition1, children: /* @__PURE__ */ _jsx3(Link, { href: vFRI3q06T, motionChild: true, nodeId: "fGebBpVaS", openInNewTab: false, scopeId: "b_m5Js9Ir", children: /* @__PURE__ */ _jsxs(motion3.a, { ...restProps, ...gestureHandlers, className: `${cx3(scopingClassNames, "framer-1o0lmo4", className9, classNames)} framer-1oaml23`, "data-framer-name": "Primary", "data-highlight": true, draggable: "false", layoutDependency, layoutId: "Navigation__fGebBpVaS", onTap: onTappg0bwd, ref: refBinding, style: { backgroundColor: "var(--token-8ef28781-a0a2-43db-933d-3d729ae85487, rgb(0, 81, 255))", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100, ...style }, variants: { "fGebBpVaS-hover": { backgroundColor: "var(--token-d5dcd97d-793f-4a02-b4b2-f1cfb443a4e6, rgb(0, 102, 255))" }, "zq5haw0aW-hover": { backgroundColor: "var(--token-8bac5f11-507c-413f-b3a4-632beefe55cb, rgb(227, 227, 227))" }, zq5haw0aW: { backgroundColor: "var(--token-ef4d7bc1-0431-483d-9665-aeb18fbabc63, rgb(240, 240, 240))" } }, ...addPropertyOverrides({ "fGebBpVaS-hover": { "data-framer-name": void 0 }, "zq5haw0aW-hover": { "data-framer-name": void 0 }, zq5haw0aW: { "data-framer-name": "Secondary" } }, baseVariant, gestureVariant), children: [hZdVwdl_Y !== false && /* @__PURE__ */ _jsx3(Instance, { animated: true, className: "framer-1qra2si", Component: peKL8pfJA, layoutDependency, layoutId: "Navigation__yMwwNckn2", style: { "--118a55": "var(--token-c4652695-7f66-461d-9ec5-551c9e0af1d0, rgb(255, 255, 255))" }, variants: { zq5haw0aW: { "--118a55": "var(--token-20891e9f-0dd5-476a-bdd1-5f7056109a89, rgb(0, 0, 0))" } } }), /* @__PURE__ */ _jsx3(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.p, { className: "framer-styles-preset-1v7qm6", "data-styles-preset": "ocOde6Lm9", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-e0ec22b8-2ee9-41b9-9c9b-068af203c374, rgb(255, 255, 255)))" }, children: "Join Waitlist" }) }), className: "framer-1iwjqtp", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__E50KQQY7B", style: { "--extracted-r6o4lv": "var(--token-e0ec22b8-2ee9-41b9-9c9b-068af203c374, rgb(255, 255, 255))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: TDPWRYXxk, variants: { zq5haw0aW: { "--extracted-r6o4lv": "var(--token-d53ec7b6-ca11-471f-93d4-6939f860246e, rgb(0, 0, 0))" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ zq5haw0aW: { children: /* @__PURE__ */ _jsx3(React3.Fragment, { children: /* @__PURE__ */ _jsx3(motion3.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-d53ec7b6-ca11-471f-93d4-6939f860246e, rgb(0, 0, 0)))" }, children: "Button" }) }) } }, baseVariant, gestureVariant) })] }) }) }) }) });
});
var css7 = [".framer-3PDQe.framer-1oaml23, .framer-3PDQe .framer-1oaml23 { display: block; }", ".framer-3PDQe.framer-1o0lmo4 { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 7px 14px 7px 14px; position: relative; text-decoration: none; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-3PDQe .framer-1qra2si { aspect-ratio: 1 / 1; flex: none; height: auto; position: relative; width: 10px; }", ".framer-3PDQe .framer-1iwjqtp { flex: none; height: auto; position: relative; white-space: pre; width: auto; z-index: 2; }", ...css6, ...css];
var Framerb_m5Js9Ir = withCSS3(Component3, css7, "framer-3PDQe");
var b_m5Js9Ir_default = Framerb_m5Js9Ir;
Framerb_m5Js9Ir.displayName = "Button";
Framerb_m5Js9Ir.defaultProps = { height: 29.5, width: 66 };
addPropertyControls2(Framerb_m5Js9Ir, { variant: { options: ["fGebBpVaS", "zq5haw0aW"], optionTitles: ["Primary", "Secondary"], title: "Variant", type: ControlType2.Enum }, TDPWRYXxk: { defaultValue: "Button", displayTextArea: false, title: "Title", type: ControlType2.String }, onTDPWRYXxkChange: { changes: "TDPWRYXxk", type: ControlType2.ChangeHandler }, vFRI3q06T: { title: "Link", type: ControlType2.Link }, DY2dzgeiO: { title: "Click", type: ControlType2.EventHandler }, peKL8pfJA: { defaultValue: { identifier: "local-module:vector/wggGXhZaC:default", moduleId: "Fs5VQrVyKoruA9COVjYx" }, setModuleId: "v49rTnsQ31Y5gd6DySlU", title: "Icon", type: ControlType2.VectorSetItem }, hZdVwdl_Y: { defaultValue: false, title: "Show Icon", type: ControlType2.Boolean }, onhZdVwdl_YChange: { changes: "hZdVwdl_Y", type: ControlType2.ChangeHandler } });
addFonts(Framerb_m5Js9Ir, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle(fonts4), ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/6gSeLGufj9YMO6ADzqOD/pnSAXwDC0JfNjp5xAcUa/BbFuZPGaK.js
import { jsx as _jsx4 } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx as cx4, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS4 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion4, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React4 from "react";
import { useRef as useRef2 } from "react";
var cycleOrder2 = ["FveAb6f2W", "I5Li6kC_5"];
var serializationHash2 = "framer-axTw0";
var variantClassNames2 = { FveAb6f2W: "framer-v-zl82vu", I5Li6kC_5: "framer-v-344k82" };
function addPropertyOverrides2(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition12 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition2 = ({ value, children }) => {
  const config = React4.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React4.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext2.Provider, { value: contextValue, children });
};
var humanReadableVariantMap2 = { "100": "FveAb6f2W", "200": "I5Li6kC_5" };
var Variants2 = motion4.create(React4.Fragment);
var getProps4 = ({ height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap2[props.variant] ?? props.variant ?? "FveAb6f2W" };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component4 = /* @__PURE__ */ React4.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React4.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className: className9, layoutId, variant, ...restProps } = getProps4(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder: cycleOrder2, defaultVariant: "FveAb6f2W", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx4(serializationHash2, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx4(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition2, { value: transition12, children: /* @__PURE__ */ _jsx4(motion4.div, { ...restProps, ...gestureHandlers, className: cx4(scopingClassNames, "framer-zl82vu", className9, classNames), "data-framer-name": "100", layoutDependency, layoutId: "Navigation__FveAb6f2W", ref: refBinding, style: { backgroundColor: "var(--token-914b1e49-c6dc-49fc-93ac-369519474e4f, rgb(227, 227, 227))", ...style }, variants: { I5Li6kC_5: { backgroundColor: "var(--token-fb0f7462-27b2-4a53-b10e-81b2a62b8279, rgb(204, 204, 204))" } }, ...addPropertyOverrides2({ I5Li6kC_5: { "data-framer-name": "200" } }, baseVariant, gestureVariant) }) }) }) });
});
var css8 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-axTw0.framer-2kef09, .framer-axTw0 .framer-2kef09 { display: block; }", ".framer-axTw0.framer-zl82vu { height: auto; overflow: var(--overflow-clip-fallback, clip); position: relative; width: 100%; }"];
var FramerBbFuZPGaK = withCSS4(Component4, css8, "framer-axTw0");
var BbFuZPGaK_default = FramerBbFuZPGaK;
FramerBbFuZPGaK.displayName = "Separator";
FramerBbFuZPGaK.defaultProps = { height: 1, width: 1072 };
addPropertyControls3(FramerBbFuZPGaK, { variant: { options: ["FveAb6f2W", "I5Li6kC_5"], optionTitles: ["100", "200"], title: "Variant", type: ControlType3.Enum } });
addFonts2(FramerBbFuZPGaK, [{ explicitInter: true, fonts: [] }], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/p90TcFj4N5gUXQezOyLl/06rqjk5knZ7axSONAqT4/LJ9PcGxE0.js
import { jsx as _jsx5, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts as addFonts3, addPropertyControls as addPropertyControls4, ControlType as ControlType4, cx as cx5, getFontsFromSharedStyle as getFontsFromSharedStyle2, getLoadingLazyAtYPosition, Image as Image1, Link as Link2, patchBorderRadiusScaleCorrector, RichText as RichText2, useComponentViewport as useComponentViewport3, useLocaleCode, useLocaleInfo as useLocaleInfo3, useVariantState as useVariantState3, withCSS as withCSS5 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup3, motion as motion5, MotionConfigContext as MotionConfigContext3 } from "framer-motion";
import * as React5 from "react";
import { useRef as useRef3 } from "react";

// http-url:https://framerusercontent.com/modules/7fD7o2yl2ikIKpE0Z3qs/cvFG7h3quPS8ykPhV2yx/amNEcipQY.js
import { fontStore as fontStore5 } from "./_framer-runtime.js";
fontStore5.loadFonts(["Inter-Variable", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNDI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNDI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNDI1"]);
var variationAxes4 = [{ defaultValue: 14, maxValue: 32, minValue: 14, name: "Optical size", tag: "opsz" }, { defaultValue: 400, maxValue: 900, minValue: 100, name: "Weight", tag: "wght" }];
var fonts5 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/mYcqTSergLb16PdbJJQMl9ebYm4.woff2", variationAxes: variationAxes4, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/ZRl8AlxwsX1m7xS1eJCiSPbztg.woff2", variationAxes: variationAxes4, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/nhSQpBRqFmXNUBY2p5SENQ8NplQ.woff2", variationAxes: variationAxes4, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/DYHjxG0qXjopUuruoacfl5SA.woff2", variationAxes: variationAxes4, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/s7NH6sl7w4NU984r5hcmo1tPSYo.woff2", variationAxes: variationAxes4, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/7lw0VWkeXrGYJT05oB3DsFy8BaY.woff2", variationAxes: variationAxes4, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/wx5nfqEgOXnxuFaxB0Mn9OhmcZA.woff2", variationAxes: variationAxes4, weight: "400" }] }];
var css9 = ['.framer-cc5NC .framer-styles-preset-9tj2n0:not(.rich-text-wrapper), .framer-cc5NC .framer-styles-preset-9tj2n0.rich-text-wrapper p { --framer-font-family: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 14px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: normal; --framer-font-style-italic: normal; --framer-font-variation-axes: "opsz" 14, "wght" 425; --framer-font-variation-axes-bold: "opsz" 14, "wght" 425; --framer-font-variation-axes-bold-italic: "opsz" 14, "wght" 425; --framer-font-variation-axes-italic: "opsz" 14, "wght" 425; --framer-font-weight: 400; --framer-font-weight-bold: 400; --framer-font-weight-bold-italic: 400; --framer-font-weight-italic: 400; --framer-letter-spacing: -0.02em; --framer-line-height: 1.5em; --framer-paragraph-spacing: 20px; --framer-text-alignment: center; --framer-text-color: var(--token-d53ec7b6-ca11-471f-93d4-6939f860246e, #000000); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className5 = "framer-cc5NC";

// http-url:https://framerusercontent.com/modules/rsWOt5cAB8VEXHAgWn5n/2s5U2EXSLrfojQ3VRhQ9/pcXFA2pNr.js
import { fontStore as fontStore6 } from "./_framer-runtime.js";
fontStore6.loadFonts(["Inter-Variable", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNjI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNjI1", "Inter-VariableVF=Im9wc3oiIDE0LCAid2dodCIgNjI1"]);
var variationAxes5 = [{ defaultValue: 14, maxValue: 32, minValue: 14, name: "Optical size", tag: "opsz" }, { defaultValue: 400, maxValue: 900, minValue: 100, name: "Weight", tag: "wght" }];
var fonts6 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/mYcqTSergLb16PdbJJQMl9ebYm4.woff2", variationAxes: variationAxes5, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/ZRl8AlxwsX1m7xS1eJCiSPbztg.woff2", variationAxes: variationAxes5, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/nhSQpBRqFmXNUBY2p5SENQ8NplQ.woff2", variationAxes: variationAxes5, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/DYHjxG0qXjopUuruoacfl5SA.woff2", variationAxes: variationAxes5, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/s7NH6sl7w4NU984r5hcmo1tPSYo.woff2", variationAxes: variationAxes5, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/7lw0VWkeXrGYJT05oB3DsFy8BaY.woff2", variationAxes: variationAxes5, weight: "400" }, { cssFamilyName: "Inter Variable", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/wx5nfqEgOXnxuFaxB0Mn9OhmcZA.woff2", variationAxes: variationAxes5, weight: "400" }] }];
var css10 = ['.framer-lxLpP .framer-styles-preset-rr2jlr:not(.rich-text-wrapper), .framer-lxLpP .framer-styles-preset-rr2jlr.rich-text-wrapper p { --framer-font-family: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-family-italic: "Inter Variable", "Inter Variable Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 14px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: normal; --framer-font-style-italic: normal; --framer-font-variation-axes: "opsz" 14, "wght" 625; --framer-font-variation-axes-bold: "opsz" 14, "wght" 625; --framer-font-variation-axes-bold-italic: "opsz" 14, "wght" 625; --framer-font-variation-axes-italic: "opsz" 14, "wght" 625; --framer-font-weight: 400; --framer-font-weight-bold: 400; --framer-font-weight-bold-italic: 400; --framer-font-weight-italic: 400; --framer-letter-spacing: -0.02em; --framer-line-height: 1.5em; --framer-paragraph-spacing: 20px; --framer-text-alignment: center; --framer-text-color: var(--token-d53ec7b6-ca11-471f-93d4-6939f860246e, #000000); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }'];
var className6 = "framer-lxLpP";

// http-url:https://framerusercontent.com/modules/p90TcFj4N5gUXQezOyLl/06rqjk5knZ7axSONAqT4/LJ9PcGxE0.js
var enabledGestures2 = { dGmjTDsPY: { hover: true, pressed: true } };
var cycleOrder3 = ["dGmjTDsPY", "VlW2qFZ1I"];
var serializationHash3 = "framer-VP2dB";
var variantClassNames3 = { dGmjTDsPY: "framer-v-w4521k", VlW2qFZ1I: "framer-v-2mpa6s" };
function addPropertyOverrides3(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var patchBorderRadiusScaleCorrector1 = patchBorderRadiusScaleCorrector();
var transition13 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var sharedDateFormatter = (value, formatOptions, locale) => {
  if (typeof value !== "string")
    return "";
  const date = new Date(value);
  if (isNaN(date.getTime()))
    return "";
  const fallbackLocale = "en-US";
  try {
    return date.toLocaleString(locale || fallbackLocale, formatOptions);
  } catch {
    return date.toLocaleString(fallbackLocale, formatOptions);
  }
};
var dateOptions = { hour: "2-digit", hour12: false, minute: "2-digit", timeZone: "UTC" };
var toDateString = (value, activeLocale) => {
  return sharedDateFormatter(value, dateOptions, activeLocale);
};
var Transition3 = ({ value, children }) => {
  const config = React5.useContext(MotionConfigContext3);
  const transition = value ?? config.transition;
  const contextValue = React5.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx5(MotionConfigContext3.Provider, { value: contextValue, children });
};
var humanReadableVariantMap3 = { Primary: "dGmjTDsPY", Secondary: "VlW2qFZ1I" };
var Variants3 = motion5.create(React5.Fragment);
var getProps5 = ({ closesAt, height, id, link, name1, opensAt, storeImage, width, ...props }) => {
  return { ...props, DQlyb9AxK: name1 ?? props.DQlyb9AxK ?? "Name", DTo3eWHMm: closesAt ?? props.DTo3eWHMm ?? "1970-01-01T22:00:00.000Z", lnDO4oCV5: opensAt ?? props.lnDO4oCV5 ?? "1970-01-01T09:00:00.000Z", t28BBddO1: link ?? props.t28BBddO1, variant: humanReadableVariantMap3[props.variant] ?? props.variant ?? "dGmjTDsPY", WqR63SlWf: storeImage ?? props.WqR63SlWf };
};
var createLayoutDependency3 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component5 = /* @__PURE__ */ React5.forwardRef(function(props, ref) {
  const fallbackRef = useRef3(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React5.useId();
  const { activeLocale, setLocale } = useLocaleInfo3();
  const componentViewport = useComponentViewport3();
  const { style, className: className9, layoutId, variant, DQlyb9AxK, WqR63SlWf, lnDO4oCV5, DTo3eWHMm, t28BBddO1, ...restProps } = getProps5(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState3({ cycleOrder: cycleOrder3, defaultVariant: "dGmjTDsPY", enabledGestures: enabledGestures2, ref: refBinding, variant, variantClassNames: variantClassNames3 });
  const layoutDependency = createLayoutDependency3(props, variants);
  const sharedStyleClassNames = [className6, className5];
  const scopingClassNames = cx5(serializationHash3, ...sharedStyleClassNames);
  const activeLocaleCode = useLocaleCode();
  const textContent = toDateString(lnDO4oCV5, activeLocaleCode);
  const textContent1 = toDateString(DTo3eWHMm, activeLocaleCode);
  return /* @__PURE__ */ _jsx5(LayoutGroup3, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx5(Variants3, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx5(Transition3, { value: transition13, children: /* @__PURE__ */ _jsx5(Link2, { href: t28BBddO1, motionChild: true, nodeId: "dGmjTDsPY", openInNewTab: false, scopeId: "LJ9PcGxE0", children: /* @__PURE__ */ _jsxs2(motion5.a, { ...restProps, ...gestureHandlers, className: `${cx5(scopingClassNames, "framer-w4521k", className9, classNames)} framer-yyqn8i`, "data-framer-name": "Primary", "data-selection": true, layoutDependency, layoutId: "Navigation__dGmjTDsPY", ref: refBinding, style: { "--corner-shape-fallback": 0.796, backgroundColor: "var(--token-f8fea787-91d7-4f16-9ffc-1b8878b28370, rgba(255, 255, 255, 0))", borderBottomLeftRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", cornerShape: "superellipse(1.4)", ...style }, variants: { "dGmjTDsPY-hover": { backgroundColor: "var(--token-95c084b4-d1a9-4aff-952a-4e4df875dae3, rgba(0, 0, 0, 0.03))" }, "dGmjTDsPY-pressed": { backgroundColor: "var(--token-10b1d161-c117-4b84-9b1c-fd7497ecf71a, rgba(0, 0, 0, 0.05))" } }, ...addPropertyOverrides3({ "dGmjTDsPY-hover": { "data-framer-name": void 0 }, "dGmjTDsPY-pressed": { "data-framer-name": void 0 }, VlW2qFZ1I: { "data-framer-name": "Secondary" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx5(Image1, { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + (8 + ((componentViewport?.height || 200) - 16 - 52) / 2)), pixelHeight: 1200, pixelWidth: 967, sizes: "52px", ...toResponsiveImage(WqR63SlWf) }, className: "framer-goxyw4", draggable: "false", layoutDependency, layoutId: "Navigation__XVra9etBX", style: { "--corner-shape-fallback": 0.796, borderBottomLeftRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", cornerShape: "superellipse(1.4)" }, ...addPropertyOverrides3({ VlW2qFZ1I: { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + (0 + ((componentViewport?.height || 200) - 0 - 52) / 2)), pixelHeight: 1200, pixelWidth: 967, sizes: "52px", ...toResponsiveImage(WqR63SlWf) } } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsxs2(motion5.div, { className: "framer-161jb1l", "data-framer-name": "Name & Opening Hours", layoutDependency, layoutId: "Navigation__lurQeD2Fi", children: [/* @__PURE__ */ _jsx5(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx5(React5.Fragment, { children: /* @__PURE__ */ _jsx5(motion5.p, { className: "framer-styles-preset-rr2jlr", "data-styles-preset": "pcXFA2pNr", dir: "auto", style: { "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "Shoe Title" }) }), className: "framer-gryyhc", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__H0lAFsf0k", style: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))", "--framer-paragraph-spacing": "0px" }, text: DQlyb9AxK, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsxs2(motion5.div, { className: "framer-16o80nv", "data-framer-name": "Opening Hours", layoutDependency, layoutId: "Navigation__o1bvjBx23", children: [/* @__PURE__ */ _jsx5(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx5(React5.Fragment, { children: /* @__PURE__ */ _jsx5(motion5.p, { className: "framer-styles-preset-9tj2n0", "data-styles-preset": "amNEcipQY", dir: "auto", style: { "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-5c950482-85ac-4716-bcd5-1945331447e4, rgb(133, 133, 133)))" }, children: "9:00 PM" }) }), className: "framer-1p0ufg8", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__hENJ4zFeF", style: { "--extracted-r6o4lv": "var(--token-5c950482-85ac-4716-bcd5-1945331447e4, rgb(133, 133, 133))", "--framer-paragraph-spacing": "0px" }, text: /* @__PURE__ */ _jsx5("time", { dateTime: lnDO4oCV5, children: textContent }), verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx5(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx5(React5.Fragment, { children: /* @__PURE__ */ _jsx5(motion5.p, { className: "framer-styles-preset-9tj2n0", "data-styles-preset": "amNEcipQY", dir: "auto", style: { "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-5c950482-85ac-4716-bcd5-1945331447e4, rgb(133, 133, 133)))" }, children: "to" }) }), className: "framer-10ne72n", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__fP3Y9qkpj", style: { "--extracted-r6o4lv": "var(--token-5c950482-85ac-4716-bcd5-1945331447e4, rgb(133, 133, 133))", "--framer-paragraph-spacing": "0px" }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx5(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx5(React5.Fragment, { children: /* @__PURE__ */ _jsx5(motion5.p, { className: "framer-styles-preset-9tj2n0", "data-styles-preset": "amNEcipQY", dir: "auto", style: { "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-5c950482-85ac-4716-bcd5-1945331447e4, rgb(133, 133, 133)))" }, children: "9:00 PM" }) }), className: "framer-1u9kbhx", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__M29MG1qDy", style: { "--extracted-r6o4lv": "var(--token-5c950482-85ac-4716-bcd5-1945331447e4, rgb(133, 133, 133))", "--framer-paragraph-spacing": "0px" }, text: /* @__PURE__ */ _jsx5("time", { dateTime: DTo3eWHMm, children: textContent1 }), verticalAlignment: "top", withExternalLayout: true })] })] })] }) }) }) }) });
});
var css11 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-VP2dB.framer-yyqn8i, .framer-VP2dB .framer-yyqn8i { display: block; }", ".framer-VP2dB.framer-w4521k { --selection-background-color: rgba(0, 153, 255, 0.15); --selection-color: #0099FF; align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 8px; position: relative; text-decoration: none; width: 350px; }", ".framer-VP2dB .framer-goxyw4 { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 52px); overflow: var(--overflow-clip-fallback, clip); position: relative; width: 52px; will-change: var(--framer-will-change-override, transform); }", ".framer-VP2dB .framer-161jb1l { -webkit-user-select: none; align-content: flex-start; align-items: flex-start; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 2px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; user-select: none; width: 1px; }", '.framer-VP2dB .framer-gryyhc { --text-truncation-display-inline-for-safari-16: inline; --text-truncation-display-none-for-safari-16: none; --text-truncation-line-break-for-safari-16: "\\A"; -webkit-box-orient: vertical; -webkit-line-clamp: 1; display: -webkit-box; flex: none; height: auto; overflow: var(--overflow-clip-fallback, clip); position: relative; white-space: pre-line; width: 100%; word-break: break-word; word-wrap: break-word; z-index: 1; }', ".framer-VP2dB .framer-16o80nv { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 7px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-VP2dB .framer-1p0ufg8, .framer-VP2dB .framer-10ne72n, .framer-VP2dB .framer-1u9kbhx { flex: none; height: auto; position: relative; white-space: pre; width: auto; z-index: 1; }", ".framer-VP2dB.framer-v-2mpa6s.framer-w4521k { cursor: unset; padding: 0px; }", ...css10, ...css9, '.framer-VP2dB[data-selection="true"] * ::selection, .framer-VP2dB [data-selection="true"] * ::selection { color: var(--selection-color, none); background-color: var(--selection-background-color, none); }'];
var FramerLJ9PcGxE0 = withCSS5(Component5, css11, "framer-VP2dB");
var LJ9PcGxE0_default = FramerLJ9PcGxE0;
FramerLJ9PcGxE0.displayName = "Store Dropdown Item";
FramerLJ9PcGxE0.defaultProps = { height: 68, width: 350 };
addPropertyControls4(FramerLJ9PcGxE0, { variant: { options: ["dGmjTDsPY", "VlW2qFZ1I"], optionTitles: ["Primary", "Secondary"], title: "Variant", type: ControlType4.Enum }, DQlyb9AxK: { defaultValue: "Name", displayTextArea: false, title: "Name", type: ControlType4.String }, onDQlyb9AxKChange: { changes: "DQlyb9AxK", type: ControlType4.ChangeHandler }, WqR63SlWf: { title: "Store Image", type: ControlType4.ResponsiveImage }, lnDO4oCV5: { defaultValue: "1970-01-01T09:00:00.000Z", displayTime: true, title: "Opens At", type: ControlType4.Date }, onlnDO4oCV5Change: { changes: "lnDO4oCV5", type: ControlType4.ChangeHandler }, DTo3eWHMm: { defaultValue: "1970-01-01T22:00:00.000Z", displayTime: true, title: "Closes At", type: ControlType4.Date }, onDTo3eWHMmChange: { changes: "DTo3eWHMm", type: ControlType4.ChangeHandler }, t28BBddO1: { title: "Link", type: ControlType4.Link } });
addFonts3(FramerLJ9PcGxE0, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle2(fonts6), ...getFontsFromSharedStyle2(fonts5)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/pB0uzod1DzPIFquIrJSC/yt3mroBddIIBMh9RxMpi/A36GR14UW.js
var SeparatorFonts = getFonts(BbFuZPGaK_default);
var StoreDropdownItemFonts = getFonts(LJ9PcGxE0_default);
var ButtonFonts = getFonts(b_m5Js9Ir_default);
var cycleOrder4 = ["f_Ov0WwU2", "WFVFttEGq"];
var serializationHash4 = "framer-6CpHc";
var variantClassNames4 = { f_Ov0WwU2: "framer-v-1sgwjdq", WFVFttEGq: "framer-v-yvxmju" };
function addPropertyOverrides4(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition14 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var matchVariant = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var toResponsiveImage2 = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var query1 = () => ({ from: { alias: "jgWhXqMP6", data: nRUBpiZY0_default, type: "Collection" }, limit: { type: "LiteralValue", value: 3 }, select: [{ collection: "jgWhXqMP6", name: "dQLMp3Snn", type: "Identifier" }, { collection: "jgWhXqMP6", name: "iHo87M7PO", type: "Identifier" }, { collection: "jgWhXqMP6", name: "vDyzh1chb", type: "Identifier" }, { collection: "jgWhXqMP6", name: "qHzx1Qnq4", type: "Identifier" }, { collection: "jgWhXqMP6", name: "MS1Ep5QnQ", type: "Identifier" }, { collection: "jgWhXqMP6", name: "id", type: "Identifier" }] });
var QueryData = ({ query, pageSize, children }) => {
  const data = __framer_useQueryData(query);
  return children(data);
};
var Transition4 = ({ value, children }) => {
  const config = React6.useContext(MotionConfigContext4);
  const transition = value ?? config.transition;
  const contextValue = React6.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx6(MotionConfigContext4.Provider, { value: contextValue, children });
};
var humanReadableVariantMap4 = { Primary: "f_Ov0WwU2", Secondary: "WFVFttEGq" };
var Variants4 = motion6.create(React6.Fragment);
var getProps6 = ({ closeNavigation, height, id, width, ...props }) => {
  return { ...props, gL5KEwxuC: closeNavigation ?? props.gL5KEwxuC, variant: humanReadableVariantMap4[props.variant] ?? props.variant ?? "f_Ov0WwU2" };
};
var createLayoutDependency4 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component6 = /* @__PURE__ */ React6.forwardRef(function(props, ref) {
  const fallbackRef = useRef4(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React6.useId();
  const { activeLocale, setLocale } = useLocaleInfo4();
  const componentViewport = useComponentViewport4();
  const { style, className: className9, layoutId, variant, gL5KEwxuC, ...restProps } = getProps6(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState4({ cycleOrder: cycleOrder4, defaultVariant: "f_Ov0WwU2", ref: refBinding, variant, variantClassNames: variantClassNames4 });
  const layoutDependency = createLayoutDependency4(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback2(baseVariant);
  const DY2dzgeiOp6klit = activeVariantCallback(async (...args) => {
    if (gL5KEwxuC) {
      const res = await gL5KEwxuC(...args);
      if (res === false)
        return false;
    }
  });
  const sharedStyleClassNames = [className3];
  const scopingClassNames = cx6(serializationHash4, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "WFVFttEGq")
      return false;
    return true;
  };
  const router = useRouter();
  return /* @__PURE__ */ _jsx6(LayoutGroup4, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx6(Variants4, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx6(Transition4, { value: transition14, children: /* @__PURE__ */ _jsxs3(motion6.div, { ...restProps, ...gestureHandlers, className: cx6(scopingClassNames, "framer-1sgwjdq", className9, classNames), "data-framer-name": "Primary", layoutDependency, layoutId: "Navigation__f_Ov0WwU2", ref: refBinding, style: { ...style }, ...addPropertyOverrides4({ WFVFttEGq: { "data-framer-name": "Secondary" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx6(ComponentViewportProvider, { height: 1, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 12 + 0, ...addPropertyOverrides4({ WFVFttEGq: { y: (componentViewport?.y || 0) + 0 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx6(SmartComponentScopedContainer, { className: "framer-1t6c5lb-container", layoutDependency, layoutId: "Navigation__Z6RH2LrgE-container", nodeId: "Z6RH2LrgE", rendersWithMotion: true, scopeId: "A36GR14UW", children: /* @__PURE__ */ _jsx6(BbFuZPGaK_default, { height: "100%", id: "Z6RH2LrgE", layoutId: "Navigation__Z6RH2LrgE", style: { height: "100%", width: "100%" }, variant: matchVariant("FveAb6f2W"), width: "100%" }) }) }), /* @__PURE__ */ _jsxs3(motion6.div, { className: "framer-11muyzk", "data-framer-name": "Content", layoutDependency, layoutId: "Navigation__w7ChAMhF1", children: [isDisplayed() && /* @__PURE__ */ _jsx6(motion6.div, { className: "framer-a26uns", "data-framer-name": "Header", layoutDependency, layoutId: "Navigation__RnLCNCRVm", children: /* @__PURE__ */ _jsx6(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx6(React6.Fragment, { children: /* @__PURE__ */ _jsx6(motion6.p, { className: "framer-styles-preset-1nkfhjw", "data-styles-preset": "hWdlH0iq7", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "Find a store" }) }), className: "framer-ig7b0x", "data-framer-name": "Title", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__yvhmYsDXT", style: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))", "--framer-paragraph-spacing": "0px" }, verticalAlignment: "top", withExternalLayout: true }) }), /* @__PURE__ */ _jsx6(motion6.div, { className: "framer-m3co59", "data-framer-name": "Stores", layoutDependency, layoutId: "Navigation__g8Shw3zMB", children: /* @__PURE__ */ _jsx6(motion6.div, { className: "framer-19cc2ao", layoutDependency, layoutId: "Navigation__jgWhXqMP6", children: /* @__PURE__ */ _jsx6(ChildrenCanSuspend, { children: /* @__PURE__ */ _jsx6(QueryData, { query: query1(), children: (collection, paginationInfo, loadMore) => {
    return /* @__PURE__ */ _jsx6(_Fragment, { children: collection?.map(({ dQLMp3Snn: dQLMp3SnnjgWhXqMP6, id: idjgWhXqMP6, iHo87M7PO: iHo87M7POjgWhXqMP6, MS1Ep5QnQ: MS1Ep5QnQjgWhXqMP6, qHzx1Qnq4: qHzx1Qnq4jgWhXqMP6, vDyzh1chb: vDyzh1chbjgWhXqMP6 }, index) => {
      dQLMp3SnnjgWhXqMP6 ?? (dQLMp3SnnjgWhXqMP6 = "");
      iHo87M7POjgWhXqMP6 ?? (iHo87M7POjgWhXqMP6 = "");
      return /* @__PURE__ */ _jsx6(LayoutGroup4, { id: `jgWhXqMP6-${idjgWhXqMP6}`, children: /* @__PURE__ */ _jsx6(PathVariablesContext.Provider, { value: { dQLMp3Snn: dQLMp3SnnjgWhXqMP6 }, children: /* @__PURE__ */ _jsx6(Link3, { href: { pathVariables: { dQLMp3Snn: dQLMp3SnnjgWhXqMP6 }, webPageId: "hlb0hjsQy" }, motionChild: true, nodeId: "uZsTZEqWa", openInNewTab: false, scopeId: "A36GR14UW", children: /* @__PURE__ */ _jsx6(motion6.a, { className: "framer-1kzuywn framer-1onrpv7", layoutDependency, layoutId: "Navigation__uZsTZEqWa", children: /* @__PURE__ */ _jsx6(ResolveLinks, { links: [{ href: { pathVariables: { dQLMp3Snn: dQLMp3SnnjgWhXqMP6 }, webPageId: "hlb0hjsQy" }, implicitPathVariables: void 0 }, { href: { pathVariables: { dQLMp3Snn: dQLMp3SnnjgWhXqMP6 }, webPageId: "hlb0hjsQy" }, implicitPathVariables: void 0 }], children: (resolvedLinks) => /* @__PURE__ */ _jsx6(ComponentViewportProvider, { height: 68, width: `max(${componentViewport?.width || "100vw"}, 1px)`, y: (componentViewport?.y || 0) + 12 + 17 + 0 + 106 + 0 + 0 + 0 + 136 + 0, ...addPropertyOverrides4({ WFVFttEGq: { y: (componentViewport?.y || 0) + 0 + 13 + 0 + 0 + 0 + 0 + 0 + 168 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx6(SmartComponentScopedContainer, { className: "framer-1hlhwrp-container", layoutDependency, layoutId: "Navigation__kjJuig0HP-container", nodeId: "kjJuig0HP", rendersWithMotion: true, scopeId: "A36GR14UW", children: /* @__PURE__ */ _jsx6(LJ9PcGxE0_default, { DQlyb9AxK: iHo87M7POjgWhXqMP6, DTo3eWHMm: MS1Ep5QnQjgWhXqMP6, height: "100%", id: "kjJuig0HP", layoutId: "Navigation__kjJuig0HP", lnDO4oCV5: qHzx1Qnq4jgWhXqMP6, style: { width: "100%" }, t28BBddO1: resolvedLinks[0], variant: matchVariant("dGmjTDsPY"), width: "100%", WqR63SlWf: toResponsiveImage2(vDyzh1chbjgWhXqMP6), ...addPropertyOverrides4({ WFVFttEGq: { t28BBddO1: resolvedLinks[1], variant: matchVariant("VlW2qFZ1I") } }, baseVariant, gestureVariant) }) }) }) }) }) }) }) }, idjgWhXqMP6);
    }) });
  } }) }) }) }), /* @__PURE__ */ _jsx6(ResolveLinks, { links: [{ href: { webPageId: "duGnOs2MS" }, implicitPathVariables: void 0 }, { href: { webPageId: "duGnOs2MS" }, implicitPathVariables: void 0 }], children: (resolvedLinks1) => /* @__PURE__ */ _jsx6(ComponentViewportProvider, { height: 29, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 12 + 17 + 0 + 320, ...addPropertyOverrides4({ WFVFttEGq: { y: (componentViewport?.y || 0) + 0 + 13 + 0 + 252 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx6(SmartComponentScopedContainer, { className: "framer-1u7u1r0-container", layoutDependency, layoutId: "Navigation__xdB5cS91F-container", nodeId: "xdB5cS91F", rendersWithMotion: true, scopeId: "A36GR14UW", children: /* @__PURE__ */ _jsx6(b_m5Js9Ir_default, { DY2dzgeiO: DY2dzgeiOp6klit, height: "100%", hZdVwdl_Y: false, id: "xdB5cS91F", layoutId: "Navigation__xdB5cS91F", peKL8pfJA: wggGXhZaC_default, style: { width: "100%" }, TDPWRYXxk: "View all", variant: matchVariant("zq5haw0aW"), vFRI3q06T: resolvedLinks1[0], width: "100%", ...addPropertyOverrides4({ WFVFttEGq: { vFRI3q06T: resolvedLinks1[1] } }, baseVariant, gestureVariant) }) }) }) })] })] }) }) }) });
});
var css12 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-6CpHc.framer-1onrpv7, .framer-6CpHc .framer-1onrpv7 { display: block; }", ".framer-6CpHc.framer-1sgwjdq { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: flex-start; overflow: visible; padding: 12px 0px 0px 0px; position: relative; width: 100%; }", ".framer-6CpHc .framer-1t6c5lb-container { flex: none; height: 1px; position: relative; width: 100%; }", ".framer-6CpHc .framer-11muyzk { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-6CpHc .framer-a26uns { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 0px 8px 0px 8px; position: relative; width: 100%; }", ".framer-6CpHc .framer-ig7b0x { flex: 1 0 0px; height: auto; position: relative; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; z-index: 1; }", ".framer-6CpHc .framer-m3co59 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-6CpHc .framer-19cc2ao { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; padding: 0px; position: relative; width: 100%; }", ".framer-6CpHc .framer-1kzuywn { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: flex-start; padding: 0px; position: relative; text-decoration: none; width: 100%; }", ".framer-6CpHc .framer-1hlhwrp-container { flex: 1 0 0px; height: auto; position: relative; width: 1px; }", ".framer-6CpHc .framer-1u7u1r0-container { flex: none; height: auto; position: relative; width: 100%; }", ".framer-6CpHc.framer-v-yvxmju.framer-1sgwjdq { gap: 12px; padding: 0px; }", ".framer-6CpHc.framer-v-yvxmju .framer-11muyzk, .framer-6CpHc.framer-v-yvxmju .framer-19cc2ao { gap: 16px; }", ".framer-6CpHc.framer-v-yvxmju .framer-m3co59 { gap: 12px; }", ...css4];
var FramerA36GR14UW = withCSS6(Component6, css12, "framer-6CpHc");
var A36GR14UW_default = FramerA36GR14UW;
FramerA36GR14UW.displayName = "Store Dropdown";
FramerA36GR14UW.defaultProps = { height: 302, width: 350 };
addPropertyControls5(FramerA36GR14UW, { variant: { options: ["f_Ov0WwU2", "WFVFttEGq"], optionTitles: ["Primary", "Secondary"], title: "Variant", type: ControlType5.Enum }, gL5KEwxuC: { title: "Close Navigation", type: ControlType5.EventHandler } });
addFonts4(FramerA36GR14UW, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...SeparatorFonts, ...StoreDropdownItemFonts, ...ButtonFonts, ...getFontsFromSharedStyle3(fonts3)], { supportsExplicitInterCodegen: true });
FramerA36GR14UW.loader = { load: (props, context) => {
  const locale = context.locale;
  const queryCacheEntry = queryCache.get(query1(), locale);
  return Promise.allSettled([queryCacheEntry.preload(), forwardLoader(BbFuZPGaK_default, {}, context), forwardLoader(b_m5Js9Ir_default, {}, context), (async () => {
    const parentData = await queryCacheEntry.readMaybeAsync() ?? [];
    return Promise.allSettled(parentData.flatMap((item) => forwardLoader(LJ9PcGxE0_default, {}, context)));
  })()]);
} };

// http-url:https://framerusercontent.com/modules/6GKsi4VdcO4UYHAWN9zA/yY9eEpXnJf5gnFeyBX3M/lRoz_3Oi8.js
import { jsx as _jsx7, jsxs as _jsxs4 } from "react/jsx-runtime";
import { addFonts as addFonts5, addPropertyControls as addPropertyControls6, ComponentViewportProvider as ComponentViewportProvider2, ControlType as ControlType6, cx as cx7, forwardLoader as forwardLoader2, getFonts as getFonts2, getFontsFromSharedStyle as getFontsFromSharedStyle4, patchBorderRadiusScaleCorrector as patchBorderRadiusScaleCorrector2, ResolveLinks as ResolveLinks2, RichText as RichText4, SmartComponentScopedContainer as SmartComponentScopedContainer2, useActiveVariantCallback as useActiveVariantCallback3, useComponentViewport as useComponentViewport5, useLocaleInfo as useLocaleInfo5, useRouter as useRouter2, useVariantState as useVariantState5, withCSS as withCSS7 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup5, motion as motion7, MotionConfigContext as MotionConfigContext5 } from "framer-motion";
import * as React7 from "react";
import { useRef as useRef5 } from "react";
var SeparatorFonts2 = getFonts2(BbFuZPGaK_default);
var SquareBlackFonts = getFonts2(alWRNtbeL_default);
var ButtonFonts2 = getFonts2(b_m5Js9Ir_default);
var cycleOrder5 = ["VTyYzhEwj", "PvaObb4oi"];
var serializationHash5 = "framer-NfXyw";
var variantClassNames5 = { PvaObb4oi: "framer-v-hrlc6o", VTyYzhEwj: "framer-v-jkketg" };
function addPropertyOverrides5(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition15 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var matchVariant2 = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var patchBorderRadiusScaleCorrector12 = patchBorderRadiusScaleCorrector2();
var Transition5 = ({ value, children }) => {
  const config = React7.useContext(MotionConfigContext5);
  const transition = value ?? config.transition;
  const contextValue = React7.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx7(MotionConfigContext5.Provider, { value: contextValue, children });
};
var humanReadableVariantMap5 = { Primary: "VTyYzhEwj", Secondary: "PvaObb4oi" };
var Variants5 = motion7.create(React7.Fragment);
var getProps7 = ({ closeNavigation, height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap5[props.variant] ?? props.variant ?? "VTyYzhEwj", vKtJHm_WC: closeNavigation ?? props.vKtJHm_WC };
};
var createLayoutDependency5 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component7 = /* @__PURE__ */ React7.forwardRef(function(props, ref) {
  const fallbackRef = useRef5(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React7.useId();
  const { activeLocale, setLocale } = useLocaleInfo5();
  const componentViewport = useComponentViewport5();
  const { style, className: className9, layoutId, variant, vKtJHm_WC, ...restProps } = getProps7(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState5({ cycleOrder: cycleOrder5, defaultVariant: "VTyYzhEwj", ref: refBinding, variant, variantClassNames: variantClassNames5 });
  const layoutDependency = createLayoutDependency5(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback3(baseVariant);
  const DY2dzgeiO1hx2djg = activeVariantCallback(async (...args) => {
    if (vKtJHm_WC) {
      const res = await vKtJHm_WC(...args);
      if (res === false)
        return false;
    }
  });
  const sharedStyleClassNames = [className3, className5];
  const scopingClassNames = cx7(serializationHash5, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "PvaObb4oi")
      return false;
    return true;
  };
  const isDisplayed1 = () => {
    if (baseVariant === "PvaObb4oi")
      return true;
    return false;
  };
  const router = useRouter2();
  return /* @__PURE__ */ _jsx7(LayoutGroup5, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx7(Variants5, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx7(Transition5, { value: transition15, children: /* @__PURE__ */ _jsxs4(motion7.div, { ...restProps, ...gestureHandlers, className: cx7(scopingClassNames, "framer-jkketg", className9, classNames), "data-framer-name": "Primary", layoutDependency, layoutId: "Navigation__VTyYzhEwj", ref: refBinding, style: { ...style }, ...addPropertyOverrides5({ PvaObb4oi: { "data-framer-name": "Secondary" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx7(ComponentViewportProvider2, { height: 1, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 12 + 0, ...addPropertyOverrides5({ PvaObb4oi: { y: (componentViewport?.y || 0) + 0 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx7(SmartComponentScopedContainer2, { className: "framer-1kzrqn7-container", layoutDependency, layoutId: "Navigation__OPZtHCwSK-container", nodeId: "OPZtHCwSK", rendersWithMotion: true, scopeId: "lRoz_3Oi8", children: /* @__PURE__ */ _jsx7(BbFuZPGaK_default, { height: "100%", id: "OPZtHCwSK", layoutId: "Navigation__OPZtHCwSK", style: { height: "100%", width: "100%" }, variant: matchVariant2("FveAb6f2W"), width: "100%" }) }) }), /* @__PURE__ */ _jsxs4(motion7.div, { className: "framer-h5oeu4", "data-framer-name": "Content", layoutDependency, layoutId: "Navigation__tkSVbYZO6", children: [isDisplayed() && /* @__PURE__ */ _jsx7(RichText4, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx7(React7.Fragment, { children: /* @__PURE__ */ _jsx7(motion7.p, { className: "framer-styles-preset-1nkfhjw", "data-styles-preset": "hWdlH0iq7", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "About us" }) }), className: "framer-3qqemo", "data-framer-name": "Title", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__U7u2Zz__F", style: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))", "--framer-paragraph-spacing": "0px" }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsxs4(motion7.div, { className: "framer-1t2xles", "data-framer-name": "Body", layoutDependency, layoutId: "Navigation__UXDuc9Kjf", children: [/* @__PURE__ */ _jsx7(motion7.div, { className: "framer-ce20s7", "data-framer-name": "Logo", layoutDependency, layoutId: "Navigation__gLOEn1bSh", style: { "--corner-shape-fallback": 0.796, backgroundColor: "var(--token-43e9dbe7-8368-4198-a5cc-76110f78e208, rgba(255, 255, 255, 0.5))", borderBottomLeftRadius: "calc(26px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(26px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(26px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(26px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", boxShadow: "inset 0px 0px 0px 1px var(--token-b1c961a3-f1c5-4b40-bc8a-b110ebb296f2, rgba(0, 0, 0, 0.1))", cornerShape: "superellipse(1.4)" }, variants: { PvaObb4oi: { borderBottomLeftRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))" } }, children: /* @__PURE__ */ _jsx7(alWRNtbeL_default, { animated: true, className: "framer-ra7oig", layoutDependency, layoutId: "Navigation__Piob8YNJa" }) }), /* @__PURE__ */ _jsx7(RichText4, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx7(React7.Fragment, { children: /* @__PURE__ */ _jsx7(motion7.p, { className: "framer-styles-preset-9tj2n0", "data-styles-preset": "amNEcipQY", dir: "auto", style: { "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-55732a59-bc62-4580-8bcc-abc8c3da47fc, rgb(97, 97, 97)))" }, children: "We're launching a limited edition collection in the coming months, join the waitlist to get notified." }) }), className: "framer-17qjqfb", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__cao1EsrHn", style: { "--extracted-r6o4lv": "var(--token-55732a59-bc62-4580-8bcc-abc8c3da47fc, rgb(97, 97, 97))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true }), isDisplayed1() && /* @__PURE__ */ _jsx7(RichText4, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx7(React7.Fragment, { children: /* @__PURE__ */ _jsx7(motion7.p, { className: "framer-styles-preset-1nkfhjw", "data-styles-preset": "hWdlH0iq7", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "Sneaks" }) }), className: "framer-1mplng7", "data-framer-name": "Title", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__Vh18BEonW", style: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))", "--framer-paragraph-spacing": "0px" }, verticalAlignment: "top", withExternalLayout: true })] }), /* @__PURE__ */ _jsx7(ResolveLinks2, { links: [{ href: { webPageId: "K4poKvWOC" }, implicitPathVariables: void 0 }, { href: { webPageId: "K4poKvWOC" }, implicitPathVariables: void 0 }], children: (resolvedLinks) => /* @__PURE__ */ _jsx7(ComponentViewportProvider2, { height: 27, y: (componentViewport?.y || 0) + 12 + 17 + 0 + 325, ...addPropertyOverrides5({ PvaObb4oi: { y: (componentViewport?.y || 0) + 0 + 17 + 0 + 293 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx7(SmartComponentScopedContainer2, { className: "framer-148q8lx-container", layoutDependency, layoutId: "Navigation__lYBI_oGN5-container", nodeId: "lYBI_oGN5", rendersWithMotion: true, scopeId: "lRoz_3Oi8", children: /* @__PURE__ */ _jsx7(b_m5Js9Ir_default, { DY2dzgeiO: DY2dzgeiO1hx2djg, height: "100%", id: "lYBI_oGN5", layoutId: "Navigation__lYBI_oGN5", TDPWRYXxk: "Read More", variant: matchVariant2("fGebBpVaS"), vFRI3q06T: resolvedLinks[0], width: "100%", ...addPropertyOverrides5({ PvaObb4oi: { vFRI3q06T: resolvedLinks[1] } }, baseVariant, gestureVariant) }) }) }) })] })] }) }) }) });
});
var css13 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-NfXyw.framer-1outzmp, .framer-NfXyw .framer-1outzmp { display: block; }", ".framer-NfXyw.framer-jkketg { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: flex-start; overflow: visible; padding: 12px 0px 0px 0px; position: relative; width: 100%; }", ".framer-NfXyw .framer-1kzrqn7-container { flex: none; height: 1px; position: relative; width: 100%; }", ".framer-NfXyw .framer-h5oeu4 { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 20px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-NfXyw .framer-3qqemo, .framer-NfXyw .framer-1mplng7 { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; z-index: 1; }", ".framer-NfXyw .framer-1t2xles { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-NfXyw .framer-ce20s7 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 20px; position: relative; width: min-content; }", ".framer-NfXyw .framer-ra7oig { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 34px); position: relative; width: 34px; }", ".framer-NfXyw .framer-17qjqfb { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-NfXyw .framer-148q8lx-container { flex: none; height: auto; position: relative; width: auto; }", ".framer-NfXyw.framer-v-hrlc6o.framer-jkketg { padding: 0px; }", ".framer-NfXyw.framer-v-hrlc6o .framer-ce20s7 { order: 0; padding: 16px; }", ".framer-NfXyw.framer-v-hrlc6o .framer-ra7oig { height: var(--framer-aspect-ratio-supported, 20px); width: 20px; }", ".framer-NfXyw.framer-v-hrlc6o .framer-17qjqfb { order: 2; }", ".framer-NfXyw.framer-v-hrlc6o .framer-1mplng7 { order: 1; }", ...css4, ...css9];
var FramerlRoz_3Oi8 = withCSS7(Component7, css13, "framer-NfXyw");
var lRoz_3Oi8_default = FramerlRoz_3Oi8;
FramerlRoz_3Oi8.displayName = "About Dropdown";
FramerlRoz_3Oi8.defaultProps = { height: 242, width: 352 };
addPropertyControls6(FramerlRoz_3Oi8, { variant: { options: ["VTyYzhEwj", "PvaObb4oi"], optionTitles: ["Primary", "Secondary"], title: "Variant", type: ControlType6.Enum }, vKtJHm_WC: { title: "Close Navigation", type: ControlType6.EventHandler } });
addFonts5(FramerlRoz_3Oi8, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...SeparatorFonts2, ...SquareBlackFonts, ...ButtonFonts2, ...getFontsFromSharedStyle4(fonts3), ...getFontsFromSharedStyle4(fonts5)], { supportsExplicitInterCodegen: true });
FramerlRoz_3Oi8.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader2(BbFuZPGaK_default, {}, context), forwardLoader2(b_m5Js9Ir_default, {}, context)]);
} };

// http-url:https://framerusercontent.com/modules/Ny5milG0gMDheF8wjCHy/Abhz709DUdVsayiNGX7W/MdkITL0hO.js
import { jsx as _jsx8, jsxs as _jsxs5 } from "react/jsx-runtime";
import { addFonts as addFonts6, addPropertyControls as addPropertyControls7, ControlType as ControlType7, cx as cx8, useComponentViewport as useComponentViewport6, useLocaleInfo as useLocaleInfo6, useVariantState as useVariantState6, withCSS as withCSS8 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup6, motion as motion8, MotionConfigContext as MotionConfigContext6 } from "framer-motion";
import * as React8 from "react";
import { useRef as useRef6 } from "react";
var cycleOrder6 = ["y3jfTuSAY", "Rksq9LVn5"];
var serializationHash6 = "framer-2d0gn";
var variantClassNames6 = { Rksq9LVn5: "framer-v-12r0isa", y3jfTuSAY: "framer-v-1ynw328" };
function addPropertyOverrides6(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition16 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition6 = ({ value, children }) => {
  const config = React8.useContext(MotionConfigContext6);
  const transition = value ?? config.transition;
  const contextValue = React8.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx8(MotionConfigContext6.Provider, { value: contextValue, children });
};
var humanReadableVariantMap6 = { Close: "Rksq9LVn5", Menu: "y3jfTuSAY" };
var Variants6 = motion8.create(React8.Fragment);
var getProps8 = ({ height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap6[props.variant] ?? props.variant ?? "y3jfTuSAY" };
};
var createLayoutDependency6 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component8 = /* @__PURE__ */ React8.forwardRef(function(props, ref) {
  const fallbackRef = useRef6(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React8.useId();
  const { activeLocale, setLocale } = useLocaleInfo6();
  const componentViewport = useComponentViewport6();
  const { style, className: className9, layoutId, variant, ...restProps } = getProps8(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState6({ cycleOrder: cycleOrder6, defaultVariant: "y3jfTuSAY", ref: refBinding, variant, variantClassNames: variantClassNames6 });
  const layoutDependency = createLayoutDependency6(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx8(serializationHash6, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx8(LayoutGroup6, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx8(Variants6, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx8(Transition6, { value: transition16, children: /* @__PURE__ */ _jsxs5(motion8.div, { ...restProps, ...gestureHandlers, className: cx8(scopingClassNames, "framer-1ynw328", className9, classNames), "data-framer-name": "Menu", layoutDependency, layoutId: "Navigation__y3jfTuSAY", ref: refBinding, style: { ...style }, ...addPropertyOverrides6({ Rksq9LVn5: { "data-framer-name": "Close" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx8(motion8.div, { className: "framer-1f89hg1", "data-framer-name": "Top Line", layoutDependency, layoutId: "Navigation__r73ZbaIqD", style: { backgroundColor: "var(--token-27377471-6d4a-46b0-90a8-188d33236a38, rgb(133, 133, 133))", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100, rotate: 0 }, variants: { Rksq9LVn5: { rotate: 45 } } }), /* @__PURE__ */ _jsx8(motion8.div, { className: "framer-t4pcvn", "data-framer-name": "Bottom Line", layoutDependency, layoutId: "Navigation__yACoQ6uoh", style: { backgroundColor: "var(--token-27377471-6d4a-46b0-90a8-188d33236a38, rgb(133, 133, 133))", borderBottomLeftRadius: 100, borderBottomRightRadius: 100, borderTopLeftRadius: 100, borderTopRightRadius: 100, rotate: 0 }, variants: { Rksq9LVn5: { rotate: -45 } } })] }) }) }) });
});
var css14 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-2d0gn.framer-1whg2y5, .framer-2d0gn .framer-1whg2y5 { display: block; }", ".framer-2d0gn.framer-1ynw328 { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 4px; height: auto; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-2d0gn .framer-1f89hg1 { flex: none; height: 2px; left: calc(50.00000000000002% - 100% / 2); overflow: var(--overflow-clip-fallback, clip); position: absolute; top: 5px; width: 100%; will-change: var(--framer-will-change-override, transform); z-index: 1; }", ".framer-2d0gn .framer-t4pcvn { bottom: 5px; flex: none; height: 2px; left: calc(50.00000000000002% - 100% / 2); overflow: var(--overflow-clip-fallback, clip); position: absolute; width: 100%; will-change: var(--framer-will-change-override, transform); z-index: 1; }", ".framer-2d0gn.framer-v-12r0isa .framer-1f89hg1 { left: calc(50.00000000000002% - 90% / 2); top: calc(50.00000000000002% - 2px / 2); width: 90%; }", ".framer-2d0gn.framer-v-12r0isa .framer-t4pcvn { bottom: unset; left: calc(50.00000000000002% - 90% / 2); top: calc(50.00000000000002% - 2px / 2); width: 90%; }"];
var FramerMdkITL0hO = withCSS8(Component8, css14, "framer-2d0gn");
var MdkITL0hO_default = FramerMdkITL0hO;
FramerMdkITL0hO.displayName = "Phone Menu Trigger";
FramerMdkITL0hO.defaultProps = { height: 18, width: 18 };
addPropertyControls7(FramerMdkITL0hO, { variant: { options: ["y3jfTuSAY", "Rksq9LVn5"], optionTitles: ["Menu", "Close"], title: "Variant", type: ControlType7.Enum } });
addFonts6(FramerMdkITL0hO, [{ explicitInter: true, fonts: [] }], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/tgYnIy9ktnHAv8npt7cg/xJQ2nCAVc6wh5uZiQnnG/mni7MPPo4.js
import { jsx as _jsx12, jsxs as _jsxs9 } from "react/jsx-runtime";
import { addFonts as addFonts10, addPropertyControls as addPropertyControls11, ComponentViewportProvider as ComponentViewportProvider4, ControlType as ControlType11, cx as cx12, forwardLoader as forwardLoader4, getFonts as getFonts4, getFontsFromSharedStyle as getFontsFromSharedStyle8, patchBorderRadiusScaleCorrector as patchBorderRadiusScaleCorrector5, RichText as RichText8, SmartComponentScopedContainer as SmartComponentScopedContainer4, useActiveVariantCallback as useActiveVariantCallback5, useComponentViewport as useComponentViewport10, useLocaleInfo as useLocaleInfo10, useVariantState as useVariantState10, withCSS as withCSS12, withFX, withOptimizedAppearEffect } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup10, motion as motion12, MotionConfigContext as MotionConfigContext10 } from "framer-motion";
import * as React12 from "react";
import { useRef as useRef10 } from "react";

// http-url:https://framerusercontent.com/modules/zLBZJQKcwfnhs9HEkaXy/UI08KOIY0MtqQ0SlyCM0/o_lEGaEg0.js
import { jsx as _jsx11, jsxs as _jsxs8, Fragment as _Fragment2 } from "react/jsx-runtime";
import { addFonts as addFonts9, addPropertyControls as addPropertyControls10, ChildrenCanSuspend as ChildrenCanSuspend2, ComponentViewportProvider as ComponentViewportProvider3, ControlType as ControlType10, cx as cx11, forwardLoader as forwardLoader3, getFonts as getFonts3, getFontsFromSharedStyle as getFontsFromSharedStyle7, Link as Link4, patchBorderRadiusScaleCorrector as patchBorderRadiusScaleCorrector4, PathVariablesContext as PathVariablesContext2, queryCache as queryCache2, ResolveLinks as ResolveLinks3, RichText as RichText7, SmartComponentScopedContainer as SmartComponentScopedContainer3, useActiveVariantCallback as useActiveVariantCallback4, useComponentViewport as useComponentViewport9, useLocaleInfo as useLocaleInfo9, useQueryData as useQueryData2, useRouter as useRouter3, useVariantState as useVariantState9, withCSS as withCSS11 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup9, motion as motion11, MotionConfigContext as MotionConfigContext9 } from "framer-motion";
import * as React11 from "react";
import { useRef as useRef9 } from "react";

// http-url:https://framerusercontent.com/modules/0sYL7oXCpFvF2RErmtGc/KsSXcO3PhqEgm5lhqmr6/N2cLBMuUA.js
import { addPropertyControls as e8, ControlType as t8, QueryEngine as l6 } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/0sYL7oXCpFvF2RErmtGc/KsSXcO3PhqEgm5lhqmr6/N2cLBMuUA-0.js
import { ControlType as y3 } from "./_framer-runtime.js";
import { ControlType as P2 } from "./_framer-runtime.js";
var t5;
var e5 = Object.create;
var r4 = Object.defineProperty;
var n4 = Object.getOwnPropertyDescriptor;
var i3 = Object.getOwnPropertyNames;
var s3 = Object.getPrototypeOf;
var a3 = Object.prototype.hasOwnProperty;
var o4 = (t13, e14, n10) => e14 in t13 ? r4(t13, e14, { enumerable: true, configurable: true, writable: true, value: n10 }) : t13[e14] = n10;
var u4 = (t13, e14) => function() {
  return e14 || (0, t13[i3(t13)[0]])((e14 = { exports: {} }).exports, e14), e14.exports;
};
var l4 = (t13, e14, s8, o9) => {
  if (e14 && "object" == typeof e14 || "function" == typeof e14)
    for (let u10 of i3(e14))
      a3.call(t13, u10) || u10 === s8 || r4(t13, u10, { get: () => e14[u10], enumerable: !(o9 = n4(e14, u10)) || o9.enumerable });
  return t13;
};
var h2 = (t13, n10, i7) => (i7 = null != t13 ? e5(s3(t13)) : {}, l4(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  !n10 && t13 && t13.__esModule ? i7 : r4(i7, "default", { value: t13, enumerable: true }),
  t13
));
var c3 = (t13, e14, r9) => o4(t13, "symbol" != typeof e14 ? e14 + "" : e14, r9);
var f3 = u4({ "../../../node_modules/dataloader/index.js"(t13, e14) {
  var r9, n10 = /* @__PURE__ */ function() {
    function t14(t15, e16) {
      if ("function" != typeof t15)
        throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but got: " + t15 + ".");
      this._batchLoadFn = t15, this._maxBatchSize = function(t16) {
        if (!(!t16 || false !== t16.batch))
          return 1;
        var e17 = t16 && t16.maxBatchSize;
        if (void 0 === e17)
          return 1 / 0;
        if ("number" != typeof e17 || e17 < 1)
          throw TypeError("maxBatchSize must be a positive number: " + e17);
        return e17;
      }(e16), this._batchScheduleFn = function(t16) {
        var e17 = t16 && t16.batchScheduleFn;
        if (void 0 === e17)
          return i7;
        if ("function" != typeof e17)
          throw TypeError("batchScheduleFn must be a function: " + e17);
        return e17;
      }(e16), this._cacheKeyFn = function(t16) {
        var e17 = t16 && t16.cacheKeyFn;
        if (void 0 === e17)
          return function(t17) {
            return t17;
          };
        if ("function" != typeof e17)
          throw TypeError("cacheKeyFn must be a function: " + e17);
        return e17;
      }(e16), this._cacheMap = function(t16) {
        if (!(!t16 || false !== t16.cache))
          return null;
        var e17 = t16 && t16.cacheMap;
        if (void 0 === e17)
          return /* @__PURE__ */ new Map();
        if (null !== e17) {
          var r10 = ["get", "set", "delete", "clear"].filter(function(t17) {
            return e17 && "function" != typeof e17[t17];
          });
          if (0 !== r10.length)
            throw TypeError("Custom cacheMap missing methods: " + r10.join(", "));
        }
        return e17;
      }(e16), this._batch = null, this.name = e16 && e16.name ? e16.name : null;
    }
    var e15 = t14.prototype;
    return e15.load = function(t15) {
      if (null == t15)
        throw TypeError("The loader.load() function must be called with a value, but got: " + String(t15) + ".");
      var e16 = function(t16) {
        var e17 = t16._batch;
        if (null !== e17 && !e17.hasDispatched && e17.keys.length < t16._maxBatchSize)
          return e17;
        var r11 = { hasDispatched: false, keys: [], callbacks: [] };
        return t16._batch = r11, t16._batchScheduleFn(function() {
          (function(t17, e18) {
            var r12;
            if (e18.hasDispatched = true, 0 === e18.keys.length) {
              a8(e18);
              return;
            }
            try {
              r12 = t17._batchLoadFn(e18.keys);
            } catch (r13) {
              return s8(t17, e18, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function errored synchronously: " + String(r13) + "."));
            }
            if (!r12 || "function" != typeof r12.then)
              return s8(t17, e18, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise: " + String(r12) + "."));
            r12.then(function(t18) {
              if (!o9(t18))
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array: " + String(t18) + ".");
              if (t18.length !== e18.keys.length)
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array of the same length as the Array of keys.\n\nKeys:\n" + String(e18.keys) + "\n\nValues:\n" + String(t18));
              a8(e18);
              for (var r13 = 0; r13 < e18.callbacks.length; r13++) {
                var n12 = t18[r13];
                n12 instanceof Error ? e18.callbacks[r13].reject(n12) : e18.callbacks[r13].resolve(n12);
              }
            }).catch(function(r13) {
              s8(t17, e18, r13);
            });
          })(t16, r11);
        }), r11;
      }(this), r10 = this._cacheMap, n11 = this._cacheKeyFn(t15);
      if (r10) {
        var i8 = r10.get(n11);
        if (i8) {
          var u10 = e16.cacheHits || (e16.cacheHits = []);
          return new Promise(function(t16) {
            u10.push(function() {
              t16(i8);
            });
          });
        }
      }
      e16.keys.push(t15);
      var l10 = new Promise(function(t16, r11) {
        e16.callbacks.push({ resolve: t16, reject: r11 });
      });
      return r10 && r10.set(n11, l10), l10;
    }, e15.loadMany = function(t15) {
      if (!o9(t15))
        throw TypeError("The loader.loadMany() function must be called with Array<key> but got: " + t15 + ".");
      for (var e16 = [], r10 = 0; r10 < t15.length; r10++)
        e16.push(this.load(t15[r10]).catch(function(t16) {
          return t16;
        }));
      return Promise.all(e16);
    }, e15.clear = function(t15) {
      var e16 = this._cacheMap;
      if (e16) {
        var r10 = this._cacheKeyFn(t15);
        e16.delete(r10);
      }
      return this;
    }, e15.clearAll = function() {
      var t15 = this._cacheMap;
      return t15 && t15.clear(), this;
    }, e15.prime = function(t15, e16) {
      var r10 = this._cacheMap;
      if (r10) {
        var n11, i8 = this._cacheKeyFn(t15);
        void 0 === r10.get(i8) && (e16 instanceof Error ? (n11 = Promise.reject(e16)).catch(function() {
        }) : n11 = Promise.resolve(e16), r10.set(i8, n11));
      }
      return this;
    }, t14;
  }(), i7 = "object" == typeof process && "function" == typeof process.nextTick ? function(t14) {
    r9 || (r9 = Promise.resolve()), r9.then(function() {
      process.nextTick(t14);
    });
  } : "function" == typeof setImmediate ? function(t14) {
    setImmediate(t14);
  } : function(t14) {
    setTimeout(t14);
  };
  function s8(t14, e15, r10) {
    a8(e15);
    for (var n11 = 0; n11 < e15.keys.length; n11++)
      t14.clear(e15.keys[n11]), e15.callbacks[n11].reject(r10);
  }
  function a8(t14) {
    if (t14.cacheHits)
      for (var e15 = 0; e15 < t14.cacheHits.length; e15++)
        t14.cacheHits[e15]();
  }
  function o9(t14) {
    return "object" == typeof t14 && null !== t14 && "number" == typeof t14.length && (0 === t14.length || t14.length > 0 && Object.prototype.hasOwnProperty.call(t14, t14.length - 1));
  }
  e14.exports = n10;
} });
var d4 = h2(f3(), 1);
var g3 = { Uint8: 1, Uint16: 2, Uint32: 4, BigUint64: 8, Int8: 1, Int16: 2, Int32: 4, BigInt64: 8, Float32: 4, Float64: 8 };
var p4 = class {
  getOffset() {
    return this.offset;
  }
  ensureLength(t13) {
    let e14 = this.bytes.length;
    if (!(this.offset + t13 <= e14))
      throw Error("Reading out of bounds");
  }
  readUint8() {
    let t13 = g3.Uint8;
    this.ensureLength(t13);
    let e14 = this.view.getUint8(this.offset);
    return this.offset += t13, e14;
  }
  readUint16() {
    let t13 = g3.Uint16;
    this.ensureLength(t13);
    let e14 = this.view.getUint16(this.offset);
    return this.offset += t13, e14;
  }
  readUint32() {
    let t13 = g3.Uint32;
    this.ensureLength(t13);
    let e14 = this.view.getUint32(this.offset);
    return this.offset += t13, e14;
  }
  readUint64() {
    let t13 = this.readBigUint64();
    return Number(t13);
  }
  readBigUint64() {
    let t13 = g3.BigUint64;
    this.ensureLength(t13);
    let e14 = this.view.getBigUint64(this.offset);
    return this.offset += t13, e14;
  }
  readInt8() {
    let t13 = g3.Int8;
    this.ensureLength(t13);
    let e14 = this.view.getInt8(this.offset);
    return this.offset += t13, e14;
  }
  readInt16() {
    let t13 = g3.Int16;
    this.ensureLength(t13);
    let e14 = this.view.getInt16(this.offset);
    return this.offset += t13, e14;
  }
  readInt32() {
    let t13 = g3.Int32;
    this.ensureLength(t13);
    let e14 = this.view.getInt32(this.offset);
    return this.offset += t13, e14;
  }
  readInt64() {
    let t13 = this.readBigInt64();
    return Number(t13);
  }
  readBigInt64() {
    let t13 = g3.BigInt64;
    this.ensureLength(t13);
    let e14 = this.view.getBigInt64(this.offset);
    return this.offset += t13, e14;
  }
  readFloat32() {
    let t13 = g3.Float32;
    this.ensureLength(t13);
    let e14 = this.view.getFloat32(this.offset);
    return this.offset += t13, e14;
  }
  readFloat64() {
    let t13 = g3.Float64;
    this.ensureLength(t13);
    let e14 = this.view.getFloat64(this.offset);
    return this.offset += t13, e14;
  }
  readBytes(t13) {
    let e14 = this.offset, r9 = e14 + t13, n10 = this.bytes.subarray(e14, r9);
    return this.offset = r9, n10;
  }
  readString() {
    let t13 = this.readUint32(), e14 = this.readBytes(t13);
    return this.decoder.decode(e14);
  }
  readJson() {
    let t13 = this.readString();
    return JSON.parse(t13);
  }
  constructor(t13) {
    this.bytes = t13, c3(this, "offset", 0), c3(this, "view"), c3(this, "decoder", new TextDecoder()), this.view = v2(this.bytes);
  }
};
function v2(t13) {
  return new DataView(t13.buffer, t13.byteOffset, t13.byteLength);
}
var m3 = "undefined" != typeof __dai_window;
var w2 = m3 && "function" == typeof __dai_window.requestIdleCallback;
function I2(t13, ...e14) {
  if (!t13)
    throw Error("Assertion Error" + (e14.length > 0 ? ": " + e14.join(" ") : ""));
}
function b2(t13) {
  throw Error(`Unexpected value: ${t13}`);
}
var k2 = (t13) => 2 ** t13 - 1;
var L2 = (t13) => -(2 ** (t13 - 1));
var B2 = (t13) => 2 ** (t13 - 1) - 1;
var E2 = { Uint8: 0, Uint16: 0, Uint32: 0, Uint64: 0, BigUint64: 0, Int8: L2(8), Int16: L2(16), Int32: L2(32), Int64: Number.MIN_SAFE_INTEGER, BigInt64: -(BigInt(2) ** BigInt(63)) };
var M2 = { Uint8: k2(8), Uint16: k2(16), Uint32: k2(32), Uint64: Number.MAX_SAFE_INTEGER, BigUint64: BigInt(2) ** BigInt(64) - BigInt(1), Int8: B2(8), Int16: B2(16), Int32: B2(32), Int64: Number.MAX_SAFE_INTEGER, BigInt64: BigInt(2) ** BigInt(63) - BigInt(1) };
function x2(t13) {
  return "string" == typeof t13;
}
function N2(t13) {
  return Number.isFinite(t13);
}
function A2(t13) {
  return null === t13;
}
var O2 = class t6 {
  static fromString(e14) {
    let [r9, n10, i7] = e14.split("/").map(Number);
    return I2(N2(r9), "Invalid chunkId"), I2(N2(n10), "Invalid offset"), I2(N2(i7), "Invalid length"), new t6(r9, n10, i7);
  }
  toString() {
    return `${this.chunkId}/${this.offset}/${this.length}`;
  }
  static read(e14) {
    let r9 = e14.readUint16(), n10 = e14.readUint32(), i7 = e14.readUint32();
    return new t6(r9, n10, i7);
  }
  write(t13) {
    t13.writeUint16(this.chunkId), t13.writeUint32(this.offset), t13.writeUint32(this.length);
  }
  compare(t13) {
    return this.chunkId < t13.chunkId ? -1 : this.chunkId > t13.chunkId ? 1 : this.offset < t13.offset ? -1 : this.offset > t13.offset ? 1 : (I2(this.length === t13.length), 0);
  }
  constructor(t13, e14, r9) {
    this.chunkId = t13, this.offset = e14, this.length = r9;
  }
};
function R2(t13) {
  if (A2(t13))
    return 0;
  switch (t13.type) {
    case P2.Array:
      return 1;
    case P2.Boolean:
      return 2;
    case P2.Color:
      return 3;
    case P2.Date:
      return 4;
    case P2.Enum:
      return 5;
    case P2.File:
      return 6;
    case P2.ResponsiveImage:
      return 10;
    case P2.Link:
      return 7;
    case P2.Number:
      return 8;
    case P2.Object:
      return 9;
    case P2.RichText:
      return 11;
    case P2.String:
      return 12;
    case P2.VectorSetItem:
      return 13;
    default:
      b2(t13);
  }
}
function q2(e14) {
  let r9 = e14.readUint16(), n10 = [];
  for (let i7 = 0; i7 < r9; i7++) {
    let r10 = t5.read(e14);
    n10.push(r10);
  }
  return { type: P2.Array, value: n10 };
}
function _2(e14, r9) {
  for (let n10 of (e14.writeUint16(r9.value.length), r9.value))
    t5.write(e14, n10);
}
function D2(e14, r9, n10) {
  let i7 = e14.value.length, s8 = r9.value.length;
  if (i7 < s8)
    return -1;
  if (i7 > s8)
    return 1;
  for (let s9 = 0; s9 < i7; s9++) {
    let i8 = e14.value[s9], a8 = r9.value[s9], o9 = t5.compare(i8, a8, n10);
    if (0 !== o9)
      return o9;
  }
  return 0;
}
function j2(t13) {
  return { type: P2.Boolean, value: 0 !== t13.readUint8() };
}
function C2(t13, e14) {
  t13.writeUint8(e14.value ? 1 : 0);
}
function J2(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function V2(t13) {
  return { type: P2.Color, value: t13.readString() };
}
function W2(t13, e14) {
  t13.writeString(e14.value);
}
function $2(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function z2(t13) {
  let e14 = t13.readInt64(), r9 = new Date(e14);
  return { type: P2.Date, value: r9.toISOString() };
}
function G2(t13, e14) {
  let r9 = new Date(e14.value), n10 = r9.getTime();
  t13.writeInt64(n10);
}
function K2(t13, e14) {
  let r9 = new Date(t13.value), n10 = new Date(e14.value);
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
function H2(t13) {
  return { type: P2.Enum, value: t13.readString() };
}
function X2(t13, e14) {
  t13.writeString(e14.value);
}
function Q2(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function Y2(t13) {
  return { type: P2.File, value: t13.readString() };
}
function Z2(t13, e14) {
  t13.writeString(e14.value);
}
function tt2(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function te2(t13) {
  return { type: P2.Link, value: t13.readJson() };
}
function tr2(t13, e14) {
  t13.writeJson(e14.value);
}
function tn2(t13, e14) {
  let r9 = JSON.stringify(t13.value), n10 = JSON.stringify(e14.value);
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
function ti2(t13) {
  return { type: P2.Number, value: t13.readFloat64() };
}
function ts2(t13, e14) {
  t13.writeFloat64(e14.value);
}
function ta2(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function to2(e14) {
  let r9 = e14.readUint16(), n10 = {};
  for (let i7 = 0; i7 < r9; i7++) {
    let r10 = e14.readString();
    n10[r10] = t5.read(e14);
  }
  return { type: P2.Object, value: n10 };
}
function tu2(e14, r9) {
  let n10 = Object.entries(r9.value);
  for (let [r10, i7] of (e14.writeUint16(n10.length), n10))
    e14.writeString(r10), t5.write(e14, i7);
}
function tl2(e14, r9, n10) {
  let i7 = Object.keys(e14.value).sort(), s8 = Object.keys(r9.value).sort();
  if (i7.length < s8.length)
    return -1;
  if (i7.length > s8.length)
    return 1;
  for (let a8 = 0; a8 < i7.length; a8++) {
    let o9 = i7[a8], u10 = s8[a8];
    if (o9 < u10)
      return -1;
    if (o9 > u10)
      return 1;
    let l10 = e14.value[o9] ?? null, h5 = r9.value[u10] ?? null, c9 = t5.compare(l10, h5, n10);
    if (0 !== c9)
      return c9;
  }
  return 0;
}
function th2(t13) {
  return { type: P2.ResponsiveImage, value: t13.readJson() };
}
function tc2(t13, e14) {
  t13.writeJson(e14.value);
}
function tf2(t13, e14) {
  let r9 = JSON.stringify(t13.value), n10 = JSON.stringify(e14.value);
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
function td2(t13) {
  let e14 = t13.readInt8();
  if (0 === e14)
    return { type: P2.RichText, value: t13.readUint32() };
  if (1 === e14)
    return { type: P2.RichText, value: t13.readString() };
  throw Error("Invalid rich text pointer");
}
function tg2(t13, e14) {
  if (N2(e14.value)) {
    t13.writeInt8(0), t13.writeUint32(e14.value);
    return;
  }
  if (x2(e14.value)) {
    t13.writeInt8(1), t13.writeString(e14.value);
    return;
  }
  throw Error("Invalid rich text pointer");
}
function tp2(t13, e14) {
  let r9 = t13.value, n10 = e14.value;
  if (N2(r9) && N2(n10) || x2(r9) && x2(n10))
    return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
  throw Error("Invalid rich text pointer");
}
function tv2(t13) {
  return { type: P2.String, value: t13.readString() };
}
function ty2(t13, e14) {
  t13.writeString(e14.value);
}
function tm2(t13, e14, r9) {
  let n10 = t13.value, i7 = e14.value;
  return (0 === r9.type && (n10 = t13.value.toLowerCase(), i7 = e14.value.toLowerCase()), n10 < i7) ? -1 : n10 > i7 ? 1 : 0;
}
function tw2(t13) {
  return { type: P2.VectorSetItem, value: t13.readUint32() };
}
function tI2(t13, e14) {
  t13.writeUint32(e14.value);
}
function tb2(t13, e14) {
  let r9 = t13.value, n10 = e14.value;
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
((t13) => {
  t13.read = function(t14) {
    let e14 = t14.readUint8();
    switch (e14) {
      case 0:
        return null;
      case 1:
        return q2(t14);
      case 2:
        return j2(t14);
      case 3:
        return V2(t14);
      case 4:
        return z2(t14);
      case 5:
        return H2(t14);
      case 6:
        return Y2(t14);
      case 7:
        return te2(t14);
      case 8:
        return ti2(t14);
      case 9:
        return to2(t14);
      case 10:
        return th2(t14);
      case 11:
        return td2(t14);
      case 12:
        return tv2(t14);
      case 13:
        return tw2(t14);
      default:
        b2(e14);
    }
  }, t13.write = function(t14, e14) {
    let r9 = R2(e14);
    if (t14.writeUint8(r9), !A2(e14))
      switch (e14.type) {
        case P2.Array:
          return _2(t14, e14);
        case P2.Boolean:
          return C2(t14, e14);
        case P2.Color:
          return W2(t14, e14);
        case P2.Date:
          return G2(t14, e14);
        case P2.Enum:
          return X2(t14, e14);
        case P2.File:
          return Z2(t14, e14);
        case P2.Link:
          return tr2(t14, e14);
        case P2.Number:
          return ts2(t14, e14);
        case P2.Object:
          return tu2(t14, e14);
        case P2.ResponsiveImage:
          return tc2(t14, e14);
        case P2.RichText:
          return tg2(t14, e14);
        case P2.VectorSetItem:
          return tI2(t14, e14);
        case P2.String:
          return ty2(t14, e14);
        default:
          b2(e14);
      }
  }, t13.compare = function(t14, e14, r9) {
    let n10 = R2(t14), i7 = R2(e14);
    if (n10 < i7)
      return -1;
    if (n10 > i7)
      return 1;
    if (A2(t14) || A2(e14))
      return 0;
    switch (t14.type) {
      case P2.Array:
        return I2(e14.type === P2.Array), D2(t14, e14, r9);
      case P2.Boolean:
        return I2(e14.type === P2.Boolean), J2(t14, e14);
      case P2.Color:
        return I2(e14.type === P2.Color), $2(t14, e14);
      case P2.Date:
        return I2(e14.type === P2.Date), K2(t14, e14);
      case P2.Enum:
        return I2(e14.type === P2.Enum), Q2(t14, e14);
      case P2.File:
        return I2(e14.type === P2.File), tt2(t14, e14);
      case P2.Link:
        return I2(e14.type === P2.Link), tn2(t14, e14);
      case P2.Number:
        return I2(e14.type === P2.Number), ta2(t14, e14);
      case P2.Object:
        return I2(e14.type === P2.Object), tl2(t14, e14, r9);
      case P2.ResponsiveImage:
        return I2(e14.type === P2.ResponsiveImage), tf2(t14, e14);
      case P2.RichText:
        return I2(e14.type === P2.RichText), tp2(t14, e14);
      case P2.VectorSetItem:
        return I2(e14.type === P2.VectorSetItem), tb2(t14, e14);
      case P2.String:
        return I2(e14.type === P2.String), tm2(t14, e14, r9);
      default:
        b2(t14);
    }
  };
})(t5 || (t5 = {}));
var tS2 = 3;
var tk2 = 250;
var tL2 = [
  408,
  // Request Timeout
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
];
var tB2 = async (t13, e14) => {
  let r9 = 0;
  for (; ; ) {
    try {
      let n10 = await fetch(t13, e14);
      if (!tL2.includes(n10.status) || ++r9 > tS2)
        return n10;
    } catch (t14) {
      if (e14?.signal?.aborted || ++r9 > tS2)
        throw t14;
    }
    await tE2(r9);
  }
};
async function tE2(t13) {
  let e14 = Math.floor(tk2 * (Math.random() + 1) * 2 ** (t13 - 1));
  await new Promise((t14) => {
    setTimeout(t14, e14);
  });
}
async function tM2(t13, e14) {
  let r9 = tx2(e14), n10 = [], i7 = 0;
  for (let t14 of r9)
    n10.push(`${t14.from}-${t14.to - 1}`), i7 += t14.to - t14.from;
  let s8 = new URL(t13), a8 = n10.join(",");
  s8.searchParams.set("range", a8);
  let o9 = await tB2(s8);
  if (200 !== o9.status)
    throw Error(`Request failed: ${o9.status} ${o9.statusText}`);
  let u10 = await o9.arrayBuffer(), l10 = new Uint8Array(u10);
  if (l10.length !== i7)
    throw Error("Request failed: Unexpected response length");
  let h5 = new tT2(), c9 = 0;
  for (let t14 of r9) {
    let e15 = t14.to - t14.from, r10 = c9 + e15, n11 = l10.subarray(c9, r10);
    h5.write(t14.from, n11), c9 = r10;
  }
  return e14.map((t14) => h5.read(t14.from, t14.to - t14.from));
}
var tT2 = class {
  read(t13, e14) {
    for (let r9 of this.chunks) {
      if (t13 < r9.start)
        break;
      if (t13 > r9.end)
        continue;
      if (t13 + e14 > r9.end)
        break;
      let n10 = t13 - r9.start, i7 = n10 + e14;
      return r9.data.slice(n10, i7);
    }
    throw Error("Missing data");
  }
  write(t13, e14) {
    let r9 = t13, n10 = r9 + e14.length, i7 = 0, s8 = this.chunks.length;
    for (; i7 < s8; i7++) {
      let t14 = this.chunks[i7];
      if (I2(t14, "Missing chunk"), !(r9 > t14.end)) {
        if (r9 > t14.start) {
          let n11 = r9 - t14.start, i8 = t14.data.subarray(0, n11);
          e14 = tF2(i8, e14), r9 = t14.start;
        }
        break;
      }
    }
    for (; s8 > i7; s8--) {
      let t14 = this.chunks[s8 - 1];
      if (I2(t14, "Missing chunk"), !(n10 < t14.start)) {
        if (n10 < t14.end) {
          let r10 = n10 - t14.start, i8 = t14.data.subarray(r10);
          e14 = tF2(e14, i8), n10 = t14.end;
        }
        break;
      }
    }
    let a8 = { start: r9, end: n10, data: e14 }, o9 = s8 - i7;
    this.chunks.splice(i7, o9, a8);
  }
  constructor() {
    c3(this, "chunks", []);
  }
};
function tF2(t13, e14) {
  let r9 = t13.length + e14.length, n10 = new Uint8Array(r9);
  return n10.set(t13, 0), n10.set(e14, t13.length), n10;
}
function tx2(t13) {
  I2(t13.length > 0, "Must have at least one range");
  let e14 = [...t13].sort((t14, e15) => t14.from - e15.from), r9 = [];
  for (let t14 of e14) {
    let e15 = r9.length - 1, n10 = r9[e15];
    n10 && t14.from <= n10.to ? r9[e15] = { from: n10.from, to: Math.max(n10.to, t14.to) } : r9.push(t14);
  }
  return r9;
}
var tA2 = class e6 {
  static read(r9) {
    let n10 = new e6(), i7 = r9.readUint16();
    for (let e14 = 0; e14 < i7; e14++) {
      let e15 = r9.readString(), i8 = t5.read(r9);
      n10.setField(e15, i8);
    }
    return n10;
  }
  write(e14) {
    for (let [r9, n10] of (e14.writeUint16(this.fields.size), this.fields))
      e14.writeString(r9), t5.write(e14, n10);
  }
  getData() {
    let t13 = {};
    for (let [e14, r9] of this.fields)
      t13[e14] = r9;
    return t13;
  }
  setField(t13, e14) {
    this.fields.set(t13, e14);
  }
  getField(t13) {
    return this.fields.get(t13);
  }
  constructor() {
    c3(this, "fields", /* @__PURE__ */ new Map());
  }
};
var tO2 = class {
  scanItems() {
    return this.itemsPromise ?? (this.itemsPromise = tB2(this.url).then(async (t13) => {
      if (!t13.ok)
        throw Error(`Request failed: ${t13.status} ${t13.statusText}`);
      let e14 = await t13.arrayBuffer(), r9 = new Uint8Array(e14), n10 = new p4(r9), i7 = [], s8 = n10.readUint32();
      for (let t14 = 0; t14 < s8; t14++) {
        let t15 = n10.getOffset(), e15 = tA2.read(n10), r10 = n10.getOffset() - t15, s9 = new O2(this.id, t15, r10), a8 = s9.toString(), o9 = { pointer: a8, data: e15.getData() };
        this.itemLoader.prime(a8, o9), i7.push(o9);
      }
      return i7;
    })), this.itemsPromise;
  }
  resolveItem(t13) {
    return this.itemLoader.load(t13);
  }
  constructor(t13, e14) {
    this.id = t13, this.url = e14, c3(this, "itemsPromise"), c3(this, "itemLoader", new d4.default(async (t14) => {
      let e15 = t14.map((t15) => {
        let e16 = O2.fromString(t15);
        return { from: e16.offset, to: e16.offset + e16.length };
      }), r9 = await tM2(this.url, e15);
      return r9.map((e16, r10) => {
        let n10 = new p4(e16), i7 = tA2.read(n10), s8 = t14[r10];
        return I2(s8, "Missing pointer"), { pointer: s8, data: i7.getData() };
      });
    }, { maxBatchSize: 250 }));
  }
};
var tP2 = class {
  async scanItems() {
    let t13 = await Promise.all(this.chunks.map(async (t14) => t14.scanItems()));
    return t13.flat();
  }
  resolveItems(t13) {
    return Promise.all(t13.map((t14) => {
      let e14 = O2.fromString(t14), r9 = this.chunks[e14.chunkId];
      return I2(r9, "Missing chunk"), r9.resolveItem(t14);
    }));
  }
  compareItems(t13, e14) {
    let r9 = O2.fromString(t13.pointer), n10 = O2.fromString(e14.pointer);
    return r9.compare(n10);
  }
  compareValues(e14, r9, n10) {
    return t5.compare(e14, r9, n10);
  }
  constructor(t13) {
    this.options = t13, c3(this, "id"), c3(this, "schema"), c3(this, "indexes"), c3(this, "resolveRichText"), c3(this, "resolveVectorSetItem"), c3(this, "chunks"), this.chunks = this.options.chunks.map((t14, e14) => new tO2(e14, t14)), this.schema = t13.schema, this.indexes = t13.indexes, this.resolveRichText = t13.resolveRichText, this.resolveVectorSetItem = t13.resolveVectorSetItem, this.id = t13.id;
  }
};

// http-url:https://framerusercontent.com/modules/0sYL7oXCpFvF2RErmtGc/KsSXcO3PhqEgm5lhqmr6/N2cLBMuUA-1.js
import { jsx as e7 } from "react/jsx-runtime";
import { AutoBreakpointVariant as t7, ComponentPresetsConsumer as r5, Link as n5, motion as o5 } from "./_framer-runtime.js";
import { isValidElement as i4 } from "react";
import { Fragment as p5, createElement as s4 } from "react";
var a4;
var l5 = "undefined" != typeof __dai_window;
var f4 = l5 && "function" == typeof __dai_window.requestIdleCallback;
var u5 = "preload";
function c4(e14) {
  return "object" == typeof e14 && null !== e14 && !/* @__PURE__ */ i4(e14) && u5 in e14;
}
function m4(e14, ...t13) {
  if (!e14)
    throw Error("Assertion Error" + (t13.length > 0 ? ": " + t13.join(" ") : ""));
}
var d5 = ((a4 = d5 || {})[a4.Fragment = 1] = "Fragment", a4[a4.Link = 2] = "Link", a4[a4.Module = 3] = "Module", a4[a4.Tag = 4] = "Tag", a4[a4.Text = 5] = "Text", a4);
function g4(i7) {
  let a8 = /* @__PURE__ */ new Map();
  return (l10) => {
    let f8 = a8.get(l10);
    if (f8)
      return f8;
    let u10 = JSON.parse(l10), d10 = function a9(l11) {
      switch (l11[0]) {
        case 1: {
          let [, ...e14] = l11, t13 = e14.map(a9);
          return /* @__PURE__ */ s4(p5, void 0, ...t13);
        }
        case 2: {
          let [, e14, ...t13] = l11, r9 = t13.map(a9);
          return /* @__PURE__ */ s4(n5, e14, ...r9);
        }
        case 3: {
          let [, n10, o9, f9, u11] = l11;
          for (let e14 of f9) {
            let t13 = o9[e14];
            t13 && (o9[e14] = a9(t13));
          }
          for (let e14 of u11) {
            let t13 = o9[e14];
            if ("string" != typeof t13)
              continue;
            let r9 = i7[t13];
            r9 && (c4(r9) && r9.preload(), o9[e14] = r9);
          }
          let p10 = i7[n10];
          return m4(p10, "Module not found"), c4(p10) && p10.preload(), /* @__PURE__ */ e7(r5, { componentIdentifier: n10, children: (r9) => /* @__PURE__ */ e7(t7, { component: p10, props: { ...r9, ...o9 } }) });
        }
        case 4: {
          let [, e14, t13, ...r9] = l11, n10 = r9.map(a9);
          if ("a" === e14)
            return /* @__PURE__ */ s4(o5.a, t13, ...n10);
          return /* @__PURE__ */ s4(e14, t13, ...n10);
        }
        case 5: {
          let [, e14] = l11;
          return e14;
        }
      }
    }(u10);
    return a8.set(l10, d10), d10;
  };
}

// http-url:https://framerusercontent.com/modules/0sYL7oXCpFvF2RErmtGc/KsSXcO3PhqEgm5lhqmr6/N2cLBMuUA.js
var r6 = { ATsOqqDj8: { isNullable: true, type: t8.String }, ATZXIWoya: { isNullable: true, type: t8.String }, createdAt: { isNullable: true, type: t8.Date }, id: { isNullable: false, type: t8.String }, M6EPg92bX: { isNullable: true, type: t8.Enum }, nextItemId: { isNullable: true, type: t8.String }, previousItemId: { isNullable: true, type: t8.String }, updatedAt: { isNullable: true, type: t8.Date } };
var o6 = [];
var n6 = (e14) => {
  let t13 = o6[e14];
  if (t13)
    return t13().then((e15) => e15.default);
};
var u6 = {};
var d6 = g4(u6);
var p6 = new l6();
var c5 = { collectionByLocaleId: { default: new tP2({ chunks: [""], id: "fc53885d-96bc-4a80-99f1-0dd881b4ecf2default", indexes: [], resolveRichText: d6, resolveVectorSetItem: n6, schema: r6 }) }, displayName: "Metadata", id: "fc53885d-96bc-4a80-99f1-0dd881b4ecf2" };
var N2cLBMuUA_default = c5;
e8(c5, { ATZXIWoya: { defaultValue: "", title: "Title", type: t8.String }, ATsOqqDj8: { preventLocalization: true, title: "Slug", type: t8.String }, M6EPg92bX: { defaultValue: "bsr6K_9L6", options: ["bsr6K_9L6", "hLIbkFhin", "ZUowm3ft8"], optionTitles: ["Shoe Category", "Gender", "Collection"], title: "Type", type: t8.Enum }, createdAt: { title: "Created", type: t8.Date }, updatedAt: { title: "Updated", type: t8.Date }, previousItemId: { dataIdentifier: "local-module:collection/N2cLBMuUA:default", title: "Previous", type: t8.CollectionReference }, nextItemId: { dataIdentifier: "local-module:collection/N2cLBMuUA:default", title: "Next", type: t8.CollectionReference } });

// http-url:https://framerusercontent.com/modules/pZnfY0Y5oVEwIFWbwseo/nLQuNacprbzBwAoMYKOX/wWC8EGMFo.js
import { addPropertyControls as e13, ControlType as l9, lazy as t12, QueryEngine as a7 } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/pZnfY0Y5oVEwIFWbwseo/nLQuNacprbzBwAoMYKOX/wWC8EGMFo-0.js
import { ControlType as y4 } from "./_framer-runtime.js";
import { ControlType as P3 } from "./_framer-runtime.js";
var t9;
var e9 = Object.create;
var r7 = Object.defineProperty;
var n7 = Object.getOwnPropertyDescriptor;
var i5 = Object.getOwnPropertyNames;
var s5 = Object.getPrototypeOf;
var a5 = Object.prototype.hasOwnProperty;
var o7 = (t13, e14, n10) => e14 in t13 ? r7(t13, e14, { enumerable: true, configurable: true, writable: true, value: n10 }) : t13[e14] = n10;
var u7 = (t13, e14) => function() {
  return e14 || (0, t13[i5(t13)[0]])((e14 = { exports: {} }).exports, e14), e14.exports;
};
var l7 = (t13, e14, s8, o9) => {
  if (e14 && "object" == typeof e14 || "function" == typeof e14)
    for (let u10 of i5(e14))
      a5.call(t13, u10) || u10 === s8 || r7(t13, u10, { get: () => e14[u10], enumerable: !(o9 = n7(e14, u10)) || o9.enumerable });
  return t13;
};
var h3 = (t13, n10, i7) => (i7 = null != t13 ? e9(s5(t13)) : {}, l7(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  !n10 && t13 && t13.__esModule ? i7 : r7(i7, "default", { value: t13, enumerable: true }),
  t13
));
var c6 = (t13, e14, r9) => o7(t13, "symbol" != typeof e14 ? e14 + "" : e14, r9);
var f5 = u7({ "../../../node_modules/dataloader/index.js"(t13, e14) {
  var r9, n10 = /* @__PURE__ */ function() {
    function t14(t15, e16) {
      if ("function" != typeof t15)
        throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but got: " + t15 + ".");
      this._batchLoadFn = t15, this._maxBatchSize = function(t16) {
        if (!(!t16 || false !== t16.batch))
          return 1;
        var e17 = t16 && t16.maxBatchSize;
        if (void 0 === e17)
          return 1 / 0;
        if ("number" != typeof e17 || e17 < 1)
          throw TypeError("maxBatchSize must be a positive number: " + e17);
        return e17;
      }(e16), this._batchScheduleFn = function(t16) {
        var e17 = t16 && t16.batchScheduleFn;
        if (void 0 === e17)
          return i7;
        if ("function" != typeof e17)
          throw TypeError("batchScheduleFn must be a function: " + e17);
        return e17;
      }(e16), this._cacheKeyFn = function(t16) {
        var e17 = t16 && t16.cacheKeyFn;
        if (void 0 === e17)
          return function(t17) {
            return t17;
          };
        if ("function" != typeof e17)
          throw TypeError("cacheKeyFn must be a function: " + e17);
        return e17;
      }(e16), this._cacheMap = function(t16) {
        if (!(!t16 || false !== t16.cache))
          return null;
        var e17 = t16 && t16.cacheMap;
        if (void 0 === e17)
          return /* @__PURE__ */ new Map();
        if (null !== e17) {
          var r10 = ["get", "set", "delete", "clear"].filter(function(t17) {
            return e17 && "function" != typeof e17[t17];
          });
          if (0 !== r10.length)
            throw TypeError("Custom cacheMap missing methods: " + r10.join(", "));
        }
        return e17;
      }(e16), this._batch = null, this.name = e16 && e16.name ? e16.name : null;
    }
    var e15 = t14.prototype;
    return e15.load = function(t15) {
      if (null == t15)
        throw TypeError("The loader.load() function must be called with a value, but got: " + String(t15) + ".");
      var e16 = function(t16) {
        var e17 = t16._batch;
        if (null !== e17 && !e17.hasDispatched && e17.keys.length < t16._maxBatchSize)
          return e17;
        var r11 = { hasDispatched: false, keys: [], callbacks: [] };
        return t16._batch = r11, t16._batchScheduleFn(function() {
          (function(t17, e18) {
            var r12;
            if (e18.hasDispatched = true, 0 === e18.keys.length) {
              a8(e18);
              return;
            }
            try {
              r12 = t17._batchLoadFn(e18.keys);
            } catch (r13) {
              return s8(t17, e18, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function errored synchronously: " + String(r13) + "."));
            }
            if (!r12 || "function" != typeof r12.then)
              return s8(t17, e18, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise: " + String(r12) + "."));
            r12.then(function(t18) {
              if (!o9(t18))
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array: " + String(t18) + ".");
              if (t18.length !== e18.keys.length)
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array of the same length as the Array of keys.\n\nKeys:\n" + String(e18.keys) + "\n\nValues:\n" + String(t18));
              a8(e18);
              for (var r13 = 0; r13 < e18.callbacks.length; r13++) {
                var n12 = t18[r13];
                n12 instanceof Error ? e18.callbacks[r13].reject(n12) : e18.callbacks[r13].resolve(n12);
              }
            }).catch(function(r13) {
              s8(t17, e18, r13);
            });
          })(t16, r11);
        }), r11;
      }(this), r10 = this._cacheMap, n11 = this._cacheKeyFn(t15);
      if (r10) {
        var i8 = r10.get(n11);
        if (i8) {
          var u10 = e16.cacheHits || (e16.cacheHits = []);
          return new Promise(function(t16) {
            u10.push(function() {
              t16(i8);
            });
          });
        }
      }
      e16.keys.push(t15);
      var l10 = new Promise(function(t16, r11) {
        e16.callbacks.push({ resolve: t16, reject: r11 });
      });
      return r10 && r10.set(n11, l10), l10;
    }, e15.loadMany = function(t15) {
      if (!o9(t15))
        throw TypeError("The loader.loadMany() function must be called with Array<key> but got: " + t15 + ".");
      for (var e16 = [], r10 = 0; r10 < t15.length; r10++)
        e16.push(this.load(t15[r10]).catch(function(t16) {
          return t16;
        }));
      return Promise.all(e16);
    }, e15.clear = function(t15) {
      var e16 = this._cacheMap;
      if (e16) {
        var r10 = this._cacheKeyFn(t15);
        e16.delete(r10);
      }
      return this;
    }, e15.clearAll = function() {
      var t15 = this._cacheMap;
      return t15 && t15.clear(), this;
    }, e15.prime = function(t15, e16) {
      var r10 = this._cacheMap;
      if (r10) {
        var n11, i8 = this._cacheKeyFn(t15);
        void 0 === r10.get(i8) && (e16 instanceof Error ? (n11 = Promise.reject(e16)).catch(function() {
        }) : n11 = Promise.resolve(e16), r10.set(i8, n11));
      }
      return this;
    }, t14;
  }(), i7 = "object" == typeof process && "function" == typeof process.nextTick ? function(t14) {
    r9 || (r9 = Promise.resolve()), r9.then(function() {
      process.nextTick(t14);
    });
  } : "function" == typeof setImmediate ? function(t14) {
    setImmediate(t14);
  } : function(t14) {
    setTimeout(t14);
  };
  function s8(t14, e15, r10) {
    a8(e15);
    for (var n11 = 0; n11 < e15.keys.length; n11++)
      t14.clear(e15.keys[n11]), e15.callbacks[n11].reject(r10);
  }
  function a8(t14) {
    if (t14.cacheHits)
      for (var e15 = 0; e15 < t14.cacheHits.length; e15++)
        t14.cacheHits[e15]();
  }
  function o9(t14) {
    return "object" == typeof t14 && null !== t14 && "number" == typeof t14.length && (0 === t14.length || t14.length > 0 && Object.prototype.hasOwnProperty.call(t14, t14.length - 1));
  }
  e14.exports = n10;
} });
var d7 = h3(f5(), 1);
var g5 = { Uint8: 1, Uint16: 2, Uint32: 4, BigUint64: 8, Int8: 1, Int16: 2, Int32: 4, BigInt64: 8, Float32: 4, Float64: 8 };
var p7 = class {
  getOffset() {
    return this.offset;
  }
  ensureLength(t13) {
    let e14 = this.bytes.length;
    if (!(this.offset + t13 <= e14))
      throw Error("Reading out of bounds");
  }
  readUint8() {
    let t13 = g5.Uint8;
    this.ensureLength(t13);
    let e14 = this.view.getUint8(this.offset);
    return this.offset += t13, e14;
  }
  readUint16() {
    let t13 = g5.Uint16;
    this.ensureLength(t13);
    let e14 = this.view.getUint16(this.offset);
    return this.offset += t13, e14;
  }
  readUint32() {
    let t13 = g5.Uint32;
    this.ensureLength(t13);
    let e14 = this.view.getUint32(this.offset);
    return this.offset += t13, e14;
  }
  readUint64() {
    let t13 = this.readBigUint64();
    return Number(t13);
  }
  readBigUint64() {
    let t13 = g5.BigUint64;
    this.ensureLength(t13);
    let e14 = this.view.getBigUint64(this.offset);
    return this.offset += t13, e14;
  }
  readInt8() {
    let t13 = g5.Int8;
    this.ensureLength(t13);
    let e14 = this.view.getInt8(this.offset);
    return this.offset += t13, e14;
  }
  readInt16() {
    let t13 = g5.Int16;
    this.ensureLength(t13);
    let e14 = this.view.getInt16(this.offset);
    return this.offset += t13, e14;
  }
  readInt32() {
    let t13 = g5.Int32;
    this.ensureLength(t13);
    let e14 = this.view.getInt32(this.offset);
    return this.offset += t13, e14;
  }
  readInt64() {
    let t13 = this.readBigInt64();
    return Number(t13);
  }
  readBigInt64() {
    let t13 = g5.BigInt64;
    this.ensureLength(t13);
    let e14 = this.view.getBigInt64(this.offset);
    return this.offset += t13, e14;
  }
  readFloat32() {
    let t13 = g5.Float32;
    this.ensureLength(t13);
    let e14 = this.view.getFloat32(this.offset);
    return this.offset += t13, e14;
  }
  readFloat64() {
    let t13 = g5.Float64;
    this.ensureLength(t13);
    let e14 = this.view.getFloat64(this.offset);
    return this.offset += t13, e14;
  }
  readBytes(t13) {
    let e14 = this.offset, r9 = e14 + t13, n10 = this.bytes.subarray(e14, r9);
    return this.offset = r9, n10;
  }
  readString() {
    let t13 = this.readUint32(), e14 = this.readBytes(t13);
    return this.decoder.decode(e14);
  }
  readJson() {
    let t13 = this.readString();
    return JSON.parse(t13);
  }
  constructor(t13) {
    this.bytes = t13, c6(this, "offset", 0), c6(this, "view"), c6(this, "decoder", new TextDecoder()), this.view = v3(this.bytes);
  }
};
function v3(t13) {
  return new DataView(t13.buffer, t13.byteOffset, t13.byteLength);
}
var m5 = "undefined" != typeof __dai_window;
var w3 = m5 && "function" == typeof __dai_window.requestIdleCallback;
function I3(t13, ...e14) {
  if (!t13)
    throw Error("Assertion Error" + (e14.length > 0 ? ": " + e14.join(" ") : ""));
}
function b3(t13) {
  throw Error(`Unexpected value: ${t13}`);
}
var U = 1024;
var S = 1.5;
var k3 = (t13) => 2 ** t13 - 1;
var L3 = (t13) => -(2 ** (t13 - 1));
var B3 = (t13) => 2 ** (t13 - 1) - 1;
var E3 = { Uint8: 0, Uint16: 0, Uint32: 0, Uint64: 0, BigUint64: 0, Int8: L3(8), Int16: L3(16), Int32: L3(32), Int64: Number.MIN_SAFE_INTEGER, BigInt64: -(BigInt(2) ** BigInt(63)) };
var M3 = { Uint8: k3(8), Uint16: k3(16), Uint32: k3(32), Uint64: Number.MAX_SAFE_INTEGER, BigUint64: BigInt(2) ** BigInt(64) - BigInt(1), Int8: B3(8), Int16: B3(16), Int32: B3(32), Int64: Number.MAX_SAFE_INTEGER, BigInt64: BigInt(2) ** BigInt(63) - BigInt(1) };
function T(t13, e14, r9, n10) {
  I3(t13 >= e14, t13, "outside lower bound for", n10), I3(t13 <= r9, t13, "outside upper bound for", n10);
}
var F = class {
  getOffset() {
    return this.offset;
  }
  slice(t13 = 0, e14 = this.offset) {
    return this.bytes.slice(t13, e14);
  }
  subarray(t13 = 0, e14 = this.offset) {
    return this.bytes.subarray(t13, e14);
  }
  ensureLength(t13) {
    let e14 = this.bytes.length;
    if (this.offset + t13 <= e14)
      return;
    let r9 = new Uint8Array(Math.ceil(e14 * S) + t13);
    r9.set(this.bytes), this.bytes = r9, this.view = v3(r9);
  }
  writeUint8(t13) {
    T(t13, E3.Uint8, M3.Uint8, "Uint8");
    let e14 = g5.Uint8;
    this.ensureLength(e14), this.view.setUint8(this.offset, t13), this.offset += e14;
  }
  writeUint16(t13) {
    T(t13, E3.Uint16, M3.Uint16, "Uint16");
    let e14 = g5.Uint16;
    this.ensureLength(e14), this.view.setUint16(this.offset, t13), this.offset += e14;
  }
  writeUint32(t13) {
    T(t13, E3.Uint32, M3.Uint32, "Uint32");
    let e14 = g5.Uint32;
    this.ensureLength(e14), this.view.setUint32(this.offset, t13), this.offset += e14;
  }
  writeUint64(t13) {
    T(t13, E3.Uint64, M3.Uint64, "Uint64");
    let e14 = BigInt(t13);
    this.writeBigUint64(e14);
  }
  writeBigUint64(t13) {
    T(t13, E3.BigUint64, M3.BigUint64, "BigUint64");
    let e14 = g5.BigUint64;
    this.ensureLength(e14), this.view.setBigUint64(this.offset, t13), this.offset += e14;
  }
  writeInt8(t13) {
    T(t13, E3.Int8, M3.Int8, "Int8");
    let e14 = g5.Int8;
    this.ensureLength(e14), this.view.setInt8(this.offset, t13), this.offset += e14;
  }
  writeInt16(t13) {
    T(t13, E3.Int16, M3.Int16, "Int16");
    let e14 = g5.Int16;
    this.ensureLength(e14), this.view.setInt16(this.offset, t13), this.offset += e14;
  }
  writeInt32(t13) {
    T(t13, E3.Int32, M3.Int32, "Int32");
    let e14 = g5.Int32;
    this.ensureLength(e14), this.view.setInt32(this.offset, t13), this.offset += e14;
  }
  writeInt64(t13) {
    T(t13, E3.Int64, M3.Int64, "Int64");
    let e14 = BigInt(t13);
    this.writeBigInt64(e14);
  }
  writeBigInt64(t13) {
    T(t13, E3.BigInt64, M3.BigInt64, "BigInt64");
    let e14 = g5.BigInt64;
    this.ensureLength(e14), this.view.setBigInt64(this.offset, t13), this.offset += e14;
  }
  writeFloat32(t13) {
    let e14 = g5.Float32;
    this.ensureLength(e14), this.view.setFloat32(this.offset, t13), this.offset += e14;
  }
  writeFloat64(t13) {
    let e14 = g5.Float64;
    this.ensureLength(e14), this.view.setFloat64(this.offset, t13), this.offset += e14;
  }
  writeBytes(t13) {
    let e14 = t13.length;
    this.ensureLength(e14), this.bytes.set(t13, this.offset), this.offset += e14;
  }
  encodeString(t13) {
    let e14 = this.encodedStrings.get(t13);
    if (e14)
      return e14;
    let r9 = this.encoder.encode(t13);
    return this.encodedStrings.set(t13, r9), r9;
  }
  writeString(t13) {
    let e14 = this.encodeString(t13), r9 = e14.length;
    this.writeUint32(r9), this.writeBytes(e14);
  }
  writeJson(t13) {
    let e14 = JSON.stringify(t13);
    this.writeString(e14);
  }
  constructor() {
    c6(this, "offset", 0), c6(this, "bytes", new Uint8Array(U)), c6(this, "view", v3(this.bytes)), c6(this, "encoder", new TextEncoder()), c6(this, "encodedStrings", /* @__PURE__ */ new Map());
  }
};
function x3(t13) {
  return "string" == typeof t13;
}
function N3(t13) {
  return Number.isFinite(t13);
}
function A3(t13) {
  return null === t13;
}
var O3 = class t10 {
  static fromString(e14) {
    let [r9, n10, i7] = e14.split("/").map(Number);
    return I3(N3(r9), "Invalid chunkId"), I3(N3(n10), "Invalid offset"), I3(N3(i7), "Invalid length"), new t10(r9, n10, i7);
  }
  toString() {
    return `${this.chunkId}/${this.offset}/${this.length}`;
  }
  static read(e14) {
    let r9 = e14.readUint16(), n10 = e14.readUint32(), i7 = e14.readUint32();
    return new t10(r9, n10, i7);
  }
  write(t13) {
    t13.writeUint16(this.chunkId), t13.writeUint32(this.offset), t13.writeUint32(this.length);
  }
  compare(t13) {
    return this.chunkId < t13.chunkId ? -1 : this.chunkId > t13.chunkId ? 1 : this.offset < t13.offset ? -1 : this.offset > t13.offset ? 1 : (I3(this.length === t13.length), 0);
  }
  constructor(t13, e14, r9) {
    this.chunkId = t13, this.offset = e14, this.length = r9;
  }
};
function R3(t13) {
  if (A3(t13))
    return 0;
  switch (t13.type) {
    case P3.Array:
      return 1;
    case P3.Boolean:
      return 2;
    case P3.Color:
      return 3;
    case P3.Date:
      return 4;
    case P3.Enum:
      return 5;
    case P3.File:
      return 6;
    case P3.ResponsiveImage:
      return 10;
    case P3.Link:
      return 7;
    case P3.Number:
      return 8;
    case P3.Object:
      return 9;
    case P3.RichText:
      return 11;
    case P3.String:
      return 12;
    case P3.VectorSetItem:
      return 13;
    default:
      b3(t13);
  }
}
function q3(e14) {
  let r9 = e14.readUint16(), n10 = [];
  for (let i7 = 0; i7 < r9; i7++) {
    let r10 = t9.read(e14);
    n10.push(r10);
  }
  return { type: P3.Array, value: n10 };
}
function _3(e14, r9) {
  for (let n10 of (e14.writeUint16(r9.value.length), r9.value))
    t9.write(e14, n10);
}
function D3(e14, r9, n10) {
  let i7 = e14.value.length, s8 = r9.value.length;
  if (i7 < s8)
    return -1;
  if (i7 > s8)
    return 1;
  for (let s9 = 0; s9 < i7; s9++) {
    let i8 = e14.value[s9], a8 = r9.value[s9], o9 = t9.compare(i8, a8, n10);
    if (0 !== o9)
      return o9;
  }
  return 0;
}
function j3(t13) {
  return { type: P3.Boolean, value: 0 !== t13.readUint8() };
}
function C3(t13, e14) {
  t13.writeUint8(e14.value ? 1 : 0);
}
function J3(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function V3(t13) {
  return { type: P3.Color, value: t13.readString() };
}
function W3(t13, e14) {
  t13.writeString(e14.value);
}
function $3(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function z3(t13) {
  let e14 = t13.readInt64(), r9 = new Date(e14);
  return { type: P3.Date, value: r9.toISOString() };
}
function G3(t13, e14) {
  let r9 = new Date(e14.value), n10 = r9.getTime();
  t13.writeInt64(n10);
}
function K3(t13, e14) {
  let r9 = new Date(t13.value), n10 = new Date(e14.value);
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
function H3(t13) {
  return { type: P3.Enum, value: t13.readString() };
}
function X3(t13, e14) {
  t13.writeString(e14.value);
}
function Q3(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function Y3(t13) {
  return { type: P3.File, value: t13.readString() };
}
function Z3(t13, e14) {
  t13.writeString(e14.value);
}
function tt3(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function te3(t13) {
  return { type: P3.Link, value: t13.readJson() };
}
function tr3(t13, e14) {
  t13.writeJson(e14.value);
}
function tn3(t13, e14) {
  let r9 = JSON.stringify(t13.value), n10 = JSON.stringify(e14.value);
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
function ti3(t13) {
  return { type: P3.Number, value: t13.readFloat64() };
}
function ts3(t13, e14) {
  t13.writeFloat64(e14.value);
}
function ta3(t13, e14) {
  return t13.value < e14.value ? -1 : t13.value > e14.value ? 1 : 0;
}
function to3(e14) {
  let r9 = e14.readUint16(), n10 = {};
  for (let i7 = 0; i7 < r9; i7++) {
    let r10 = e14.readString();
    n10[r10] = t9.read(e14);
  }
  return { type: P3.Object, value: n10 };
}
function tu3(e14, r9) {
  let n10 = Object.entries(r9.value);
  for (let [r10, i7] of (e14.writeUint16(n10.length), n10))
    e14.writeString(r10), t9.write(e14, i7);
}
function tl3(e14, r9, n10) {
  let i7 = Object.keys(e14.value).sort(), s8 = Object.keys(r9.value).sort();
  if (i7.length < s8.length)
    return -1;
  if (i7.length > s8.length)
    return 1;
  for (let a8 = 0; a8 < i7.length; a8++) {
    let o9 = i7[a8], u10 = s8[a8];
    if (o9 < u10)
      return -1;
    if (o9 > u10)
      return 1;
    let l10 = e14.value[o9] ?? null, h5 = r9.value[u10] ?? null, c9 = t9.compare(l10, h5, n10);
    if (0 !== c9)
      return c9;
  }
  return 0;
}
function th3(t13) {
  return { type: P3.ResponsiveImage, value: t13.readJson() };
}
function tc3(t13, e14) {
  t13.writeJson(e14.value);
}
function tf3(t13, e14) {
  let r9 = JSON.stringify(t13.value), n10 = JSON.stringify(e14.value);
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
function td3(t13) {
  let e14 = t13.readInt8();
  if (0 === e14)
    return { type: P3.RichText, value: t13.readUint32() };
  if (1 === e14)
    return { type: P3.RichText, value: t13.readString() };
  throw Error("Invalid rich text pointer");
}
function tg3(t13, e14) {
  if (N3(e14.value)) {
    t13.writeInt8(0), t13.writeUint32(e14.value);
    return;
  }
  if (x3(e14.value)) {
    t13.writeInt8(1), t13.writeString(e14.value);
    return;
  }
  throw Error("Invalid rich text pointer");
}
function tp3(t13, e14) {
  let r9 = t13.value, n10 = e14.value;
  if (N3(r9) && N3(n10) || x3(r9) && x3(n10))
    return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
  throw Error("Invalid rich text pointer");
}
function tv3(t13) {
  return { type: P3.String, value: t13.readString() };
}
function ty3(t13, e14) {
  t13.writeString(e14.value);
}
function tm3(t13, e14, r9) {
  let n10 = t13.value, i7 = e14.value;
  return (0 === r9.type && (n10 = t13.value.toLowerCase(), i7 = e14.value.toLowerCase()), n10 < i7) ? -1 : n10 > i7 ? 1 : 0;
}
function tw3(t13) {
  return { type: P3.VectorSetItem, value: t13.readUint32() };
}
function tI3(t13, e14) {
  t13.writeUint32(e14.value);
}
function tb3(t13, e14) {
  let r9 = t13.value, n10 = e14.value;
  return r9 < n10 ? -1 : r9 > n10 ? 1 : 0;
}
((t13) => {
  t13.read = function(t14) {
    let e14 = t14.readUint8();
    switch (e14) {
      case 0:
        return null;
      case 1:
        return q3(t14);
      case 2:
        return j3(t14);
      case 3:
        return V3(t14);
      case 4:
        return z3(t14);
      case 5:
        return H3(t14);
      case 6:
        return Y3(t14);
      case 7:
        return te3(t14);
      case 8:
        return ti3(t14);
      case 9:
        return to3(t14);
      case 10:
        return th3(t14);
      case 11:
        return td3(t14);
      case 12:
        return tv3(t14);
      case 13:
        return tw3(t14);
      default:
        b3(e14);
    }
  }, t13.write = function(t14, e14) {
    let r9 = R3(e14);
    if (t14.writeUint8(r9), !A3(e14))
      switch (e14.type) {
        case P3.Array:
          return _3(t14, e14);
        case P3.Boolean:
          return C3(t14, e14);
        case P3.Color:
          return W3(t14, e14);
        case P3.Date:
          return G3(t14, e14);
        case P3.Enum:
          return X3(t14, e14);
        case P3.File:
          return Z3(t14, e14);
        case P3.Link:
          return tr3(t14, e14);
        case P3.Number:
          return ts3(t14, e14);
        case P3.Object:
          return tu3(t14, e14);
        case P3.ResponsiveImage:
          return tc3(t14, e14);
        case P3.RichText:
          return tg3(t14, e14);
        case P3.VectorSetItem:
          return tI3(t14, e14);
        case P3.String:
          return ty3(t14, e14);
        default:
          b3(e14);
      }
  }, t13.compare = function(t14, e14, r9) {
    let n10 = R3(t14), i7 = R3(e14);
    if (n10 < i7)
      return -1;
    if (n10 > i7)
      return 1;
    if (A3(t14) || A3(e14))
      return 0;
    switch (t14.type) {
      case P3.Array:
        return I3(e14.type === P3.Array), D3(t14, e14, r9);
      case P3.Boolean:
        return I3(e14.type === P3.Boolean), J3(t14, e14);
      case P3.Color:
        return I3(e14.type === P3.Color), $3(t14, e14);
      case P3.Date:
        return I3(e14.type === P3.Date), K3(t14, e14);
      case P3.Enum:
        return I3(e14.type === P3.Enum), Q3(t14, e14);
      case P3.File:
        return I3(e14.type === P3.File), tt3(t14, e14);
      case P3.Link:
        return I3(e14.type === P3.Link), tn3(t14, e14);
      case P3.Number:
        return I3(e14.type === P3.Number), ta3(t14, e14);
      case P3.Object:
        return I3(e14.type === P3.Object), tl3(t14, e14, r9);
      case P3.ResponsiveImage:
        return I3(e14.type === P3.ResponsiveImage), tf3(t14, e14);
      case P3.RichText:
        return I3(e14.type === P3.RichText), tp3(t14, e14);
      case P3.VectorSetItem:
        return I3(e14.type === P3.VectorSetItem), tb3(t14, e14);
      case P3.String:
        return I3(e14.type === P3.String), tm3(t14, e14, r9);
      default:
        b3(t14);
    }
  };
})(t9 || (t9 = {}));
var tU = class e10 {
  sortEntries() {
    this.entries.sort((e14, r9) => {
      for (let n10 = 0; n10 < this.fieldNames.length; n10++) {
        let i7 = e14.values[n10], s8 = r9.values[n10], a8 = t9.compare(i7, s8, this.options.collation);
        if (0 !== a8)
          return a8;
      }
      return e14.pointer.compare(r9.pointer);
    });
  }
  static deserialize(r9) {
    let n10 = new p7(r9), i7 = n10.readJson(), s8 = n10.readUint8(), a8 = [];
    for (let t13 = 0; t13 < s8; t13++) {
      let t14 = n10.readString();
      a8.push(t14);
    }
    let o9 = new e10(a8, { collation: i7 }), u10 = n10.readUint32();
    for (let e14 = 0; e14 < u10; e14++) {
      let e15 = [];
      for (let r11 = 0; r11 < s8; r11++) {
        let r12 = t9.read(n10);
        e15.push(r12);
      }
      let r10 = O3.read(n10);
      o9.entries.push({ values: e15, pointer: r10 });
    }
    return o9;
  }
  serialize() {
    let e14 = new F();
    for (let t13 of (e14.writeJson(this.options.collation), e14.writeUint8(this.fieldNames.length), this.fieldNames))
      e14.writeString(t13);
    for (let r9 of (this.sortEntries(), e14.writeUint32(this.entries.length), this.entries)) {
      let { values: n10, pointer: i7 } = r9;
      for (let r10 of n10)
        t9.write(e14, r10);
      i7.write(e14);
    }
    return e14.subarray();
  }
  addItem(t13, e14) {
    let r9 = this.fieldNames.map((e15) => t13.getField(e15) ?? null);
    this.entries.push({ values: r9, pointer: e14 });
  }
  constructor(t13, e14) {
    this.fieldNames = t13, this.options = e14, c6(this, "entries", []);
  }
};
var tS3 = 3;
var tk3 = 250;
var tL3 = [
  408,
  // Request Timeout
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
];
var tB3 = async (t13, e14) => {
  let r9 = 0;
  for (; ; ) {
    try {
      let n10 = await fetch(t13, e14);
      if (!tL3.includes(n10.status) || ++r9 > tS3)
        return n10;
    } catch (t14) {
      if (e14?.signal?.aborted || ++r9 > tS3)
        throw t14;
    }
    await tE3(r9);
  }
};
async function tE3(t13) {
  let e14 = Math.floor(tk3 * (Math.random() + 1) * 2 ** (t13 - 1));
  await new Promise((t14) => {
    setTimeout(t14, e14);
  });
}
async function tM3(t13, e14) {
  let r9 = tx3(e14), n10 = [], i7 = 0;
  for (let t14 of r9)
    n10.push(`${t14.from}-${t14.to - 1}`), i7 += t14.to - t14.from;
  let s8 = new URL(t13), a8 = n10.join(",");
  s8.searchParams.set("range", a8);
  let o9 = await tB3(s8);
  if (200 !== o9.status)
    throw Error(`Request failed: ${o9.status} ${o9.statusText}`);
  let u10 = await o9.arrayBuffer(), l10 = new Uint8Array(u10);
  if (l10.length !== i7)
    throw Error("Request failed: Unexpected response length");
  let h5 = new tT3(), c9 = 0;
  for (let t14 of r9) {
    let e15 = t14.to - t14.from, r10 = c9 + e15, n11 = l10.subarray(c9, r10);
    h5.write(t14.from, n11), c9 = r10;
  }
  return e14.map((t14) => h5.read(t14.from, t14.to - t14.from));
}
var tT3 = class {
  read(t13, e14) {
    for (let r9 of this.chunks) {
      if (t13 < r9.start)
        break;
      if (t13 > r9.end)
        continue;
      if (t13 + e14 > r9.end)
        break;
      let n10 = t13 - r9.start, i7 = n10 + e14;
      return r9.data.slice(n10, i7);
    }
    throw Error("Missing data");
  }
  write(t13, e14) {
    let r9 = t13, n10 = r9 + e14.length, i7 = 0, s8 = this.chunks.length;
    for (; i7 < s8; i7++) {
      let t14 = this.chunks[i7];
      if (I3(t14, "Missing chunk"), !(r9 > t14.end)) {
        if (r9 > t14.start) {
          let n11 = r9 - t14.start, i8 = t14.data.subarray(0, n11);
          e14 = tF3(i8, e14), r9 = t14.start;
        }
        break;
      }
    }
    for (; s8 > i7; s8--) {
      let t14 = this.chunks[s8 - 1];
      if (I3(t14, "Missing chunk"), !(n10 < t14.start)) {
        if (n10 < t14.end) {
          let r10 = n10 - t14.start, i8 = t14.data.subarray(r10);
          e14 = tF3(e14, i8), n10 = t14.end;
        }
        break;
      }
    }
    let a8 = { start: r9, end: n10, data: e14 }, o9 = s8 - i7;
    this.chunks.splice(i7, o9, a8);
  }
  constructor() {
    c6(this, "chunks", []);
  }
};
function tF3(t13, e14) {
  let r9 = t13.length + e14.length, n10 = new Uint8Array(r9);
  return n10.set(t13, 0), n10.set(e14, t13.length), n10;
}
function tx3(t13) {
  I3(t13.length > 0, "Must have at least one range");
  let e14 = [...t13].sort((t14, e15) => t14.from - e15.from), r9 = [];
  for (let t14 of e14) {
    let e15 = r9.length - 1, n10 = r9[e15];
    n10 && t14.from <= n10.to ? r9[e15] = { from: n10.from, to: Math.max(n10.to, t14.to) } : r9.push(t14);
  }
  return r9;
}
var tN = class {
  async loadModel() {
    let [t13] = await tM3(this.options.url, [this.options.range]);
    return I3(t13, "Failed to load model"), tU.deserialize(t13);
  }
  async getModel() {
    return this.modelPromise ?? (this.modelPromise = this.loadModel()), this.model ?? (this.model = await this.modelPromise), this.model;
  }
  async lookupItems(t13) {
    I3(t13.length === this.fields.length, "Invalid query length");
    let e14 = await this.getModel(), r9 = t13.reduce((t14, e15, r10) => t14.flatMap((t15) => {
      switch (e15.type) {
        case "All":
          return [t15];
        case "Equals":
          return this.queryEquals(t15, e15, r10);
        case "NotEquals":
          return this.queryNotEquals(t15, e15, r10);
        case "LessThan":
          return this.queryLessThan(t15, e15, r10);
        case "GreaterThan":
          return this.queryGreaterThan(t15, e15, r10);
        case "Contains":
          return this.queryContains(t15, e15, r10);
        case "StartsWith":
          return this.queryStartsWith(t15, e15, r10);
        case "EndsWith":
          return this.queryEndsWith(t15, e15, r10);
        default:
          b3(e15);
      }
    }), [e14.entries]), n10 = [];
    for (let t14 of r9)
      for (let e15 of t14) {
        let t15 = {};
        for (let r10 = 0; r10 < this.options.fieldNames.length; r10++) {
          let n11 = this.options.fieldNames[r10], i7 = e15.values[r10];
          t15[n11] = i7;
        }
        n10.push({ pointer: e15.pointer.toString(), data: t15 });
      }
    return n10;
  }
  queryEquals(t13, e14, r9) {
    let n10 = this.getLeftMost(t13, r9, e14.value), i7 = this.getRightMost(t13, r9, e14.value), s8 = t13.slice(n10, i7 + 1);
    return s8.length > 0 ? [s8] : [];
  }
  queryNotEquals(t13, e14, r9) {
    let n10 = this.getLeftMost(t13, r9, e14.value), i7 = this.getRightMost(t13, r9, e14.value), s8 = [], a8 = t13.slice(0, n10);
    a8.length > 0 && s8.push(a8);
    let o9 = t13.slice(i7 + 1);
    return o9.length > 0 && s8.push(o9), s8;
  }
  queryLessThan(t13, e14, r9) {
    let n10 = this.getRightMost(t13, r9, null);
    if (t13 = t13.slice(n10 + 1), e14.inclusive) {
      let n11 = this.getRightMost(t13, r9, e14.value), i8 = t13.slice(0, n11 + 1);
      return i8.length > 0 ? [i8] : [];
    }
    let i7 = this.getLeftMost(t13, r9, e14.value), s8 = t13.slice(0, i7);
    return s8.length > 0 ? [s8] : [];
  }
  queryGreaterThan(t13, e14, r9) {
    let n10 = this.getRightMost(t13, r9, null);
    if (t13 = t13.slice(n10 + 1), e14.inclusive) {
      let n11 = this.getLeftMost(t13, r9, e14.value), i8 = t13.slice(n11);
      return i8.length > 0 ? [i8] : [];
    }
    let i7 = this.getRightMost(t13, r9, e14.value), s8 = t13.slice(i7 + 1);
    return s8.length > 0 ? [s8] : [];
  }
  queryContains(t13, e14, r9) {
    return this.findItems(t13, r9, (t14) => {
      if (t14?.type !== y4.String || e14.value?.type !== y4.String)
        return false;
      let r10 = t14.value, n10 = e14.value.value;
      return 0 === this.collation.type && (r10 = r10.toLowerCase(), n10 = n10.toLowerCase()), r10.includes(n10);
    });
  }
  queryStartsWith(t13, e14, r9) {
    return this.findItems(t13, r9, (t14) => {
      if (t14?.type !== y4.String || e14.value?.type !== y4.String)
        return false;
      let r10 = t14.value, n10 = e14.value.value;
      return 0 === this.collation.type && (r10 = r10.toLowerCase(), n10 = n10.toLowerCase()), r10.startsWith(n10);
    });
  }
  queryEndsWith(t13, e14, r9) {
    return this.findItems(t13, r9, (t14) => {
      if (t14?.type !== y4.String || e14.value?.type !== y4.String)
        return false;
      let r10 = t14.value, n10 = e14.value.value;
      return 0 === this.collation.type && (r10 = r10.toLowerCase(), n10 = n10.toLowerCase()), r10.endsWith(n10);
    });
  }
  /**
  * Returns the index of the left most entry that is equal to the target.
  *
  * ```text
  *   Left most
  *       ↓
  * ┌───┬───┬───┬───┬───┬───┐
  * │ 1 │ 2 │ 2 │ 2 │ 2 │ 3 │
  * └───┴───┴───┴───┴───┴───┘
  * ```
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param target The target value to search for.
  * @returns The index of the left most entry that is equal to the target.
  */
  getLeftMost(e14, r9, n10) {
    let i7 = 0, s8 = e14.length;
    for (; i7 < s8; ) {
      let a8 = i7 + s8 >> 1, o9 = e14[a8], u10 = o9.values[r9];
      0 > t9.compare(u10, n10, this.collation) ? i7 = a8 + 1 : s8 = a8;
    }
    return i7;
  }
  /**
  * Returns the index of the right most entry that is equal to the target.
  *
  * ```text
  *              Right most
  *                   ↓
  * ┌───┬───┬───┬───┬───┬───┐
  * │ 1 │ 2 │ 2 │ 2 │ 2 │ 3 │
  * └───┴───┴───┴───┴───┴───┘
  * ```
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param target The target value to search for.
  * @returns The index of the right most entry that is equal to the target.
  */
  getRightMost(e14, r9, n10) {
    let i7 = 0, s8 = e14.length;
    for (; i7 < s8; ) {
      let a8 = i7 + s8 >> 1, o9 = e14[a8], u10 = o9.values[r9];
      t9.compare(u10, n10, this.collation) > 0 ? s8 = a8 : i7 = a8 + 1;
    }
    return s8 - 1;
  }
  /**
  * Finds all items that are matching the predicate and groups adjacent items together.
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param predicate The predicate to match the values against.
  * @returns An array of chunks that match the predicate.
  */
  findItems(t13, e14, r9) {
    let n10 = [], i7 = 0;
    for (let s8 = 0; s8 < t13.length; s8++) {
      let a8 = t13[s8], o9 = a8.values[e14], u10 = r9(o9);
      if (!u10) {
        if (i7 < s8) {
          let e15 = t13.slice(i7, s8);
          n10.push(e15);
        }
        i7 = s8 + 1;
      }
    }
    if (i7 < t13.length) {
      let e15 = t13.slice(i7);
      n10.push(e15);
    }
    return n10;
  }
  constructor(t13) {
    this.options = t13, c6(this, "schema"), c6(this, "fields"), c6(this, "supportedLookupTypes", [
      "All",
      "Equals",
      "NotEquals",
      "LessThan",
      "GreaterThan",
      "Contains",
      "StartsWith",
      "EndsWith"
      /* EndsWith */
    ]), c6(this, "modelPromise"), c6(this, "model"), c6(this, "collation");
    let e14 = {}, r9 = [];
    for (let t14 of this.options.fieldNames) {
      let n10 = this.options.collectionSchema[t14];
      I3(n10, "Missing definition for field", t14), e14[t14] = n10, r9.push({ type: "Identifier", name: t14 });
    }
    this.schema = e14, this.fields = r9, this.collation = this.options.collation;
  }
};
var tA3 = class e11 {
  static read(r9) {
    let n10 = new e11(), i7 = r9.readUint16();
    for (let e14 = 0; e14 < i7; e14++) {
      let e15 = r9.readString(), i8 = t9.read(r9);
      n10.setField(e15, i8);
    }
    return n10;
  }
  write(e14) {
    for (let [r9, n10] of (e14.writeUint16(this.fields.size), this.fields))
      e14.writeString(r9), t9.write(e14, n10);
  }
  getData() {
    let t13 = {};
    for (let [e14, r9] of this.fields)
      t13[e14] = r9;
    return t13;
  }
  setField(t13, e14) {
    this.fields.set(t13, e14);
  }
  getField(t13) {
    return this.fields.get(t13);
  }
  constructor() {
    c6(this, "fields", /* @__PURE__ */ new Map());
  }
};
var tO3 = class {
  scanItems() {
    return this.itemsPromise ?? (this.itemsPromise = tB3(this.url).then(async (t13) => {
      if (!t13.ok)
        throw Error(`Request failed: ${t13.status} ${t13.statusText}`);
      let e14 = await t13.arrayBuffer(), r9 = new Uint8Array(e14), n10 = new p7(r9), i7 = [], s8 = n10.readUint32();
      for (let t14 = 0; t14 < s8; t14++) {
        let t15 = n10.getOffset(), e15 = tA3.read(n10), r10 = n10.getOffset() - t15, s9 = new O3(this.id, t15, r10), a8 = s9.toString(), o9 = { pointer: a8, data: e15.getData() };
        this.itemLoader.prime(a8, o9), i7.push(o9);
      }
      return i7;
    })), this.itemsPromise;
  }
  resolveItem(t13) {
    return this.itemLoader.load(t13);
  }
  constructor(t13, e14) {
    this.id = t13, this.url = e14, c6(this, "itemsPromise"), c6(this, "itemLoader", new d7.default(async (t14) => {
      let e15 = t14.map((t15) => {
        let e16 = O3.fromString(t15);
        return { from: e16.offset, to: e16.offset + e16.length };
      }), r9 = await tM3(this.url, e15);
      return r9.map((e16, r10) => {
        let n10 = new p7(e16), i7 = tA3.read(n10), s8 = t14[r10];
        return I3(s8, "Missing pointer"), { pointer: s8, data: i7.getData() };
      });
    }, { maxBatchSize: 250 }));
  }
};
var tP3 = class {
  async scanItems() {
    let t13 = await Promise.all(this.chunks.map(async (t14) => t14.scanItems()));
    return t13.flat();
  }
  resolveItems(t13) {
    return Promise.all(t13.map((t14) => {
      let e14 = O3.fromString(t14), r9 = this.chunks[e14.chunkId];
      return I3(r9, "Missing chunk"), r9.resolveItem(t14);
    }));
  }
  compareItems(t13, e14) {
    let r9 = O3.fromString(t13.pointer), n10 = O3.fromString(e14.pointer);
    return r9.compare(n10);
  }
  compareValues(e14, r9, n10) {
    return t9.compare(e14, r9, n10);
  }
  constructor(t13) {
    this.options = t13, c6(this, "id"), c6(this, "schema"), c6(this, "indexes"), c6(this, "resolveRichText"), c6(this, "resolveVectorSetItem"), c6(this, "chunks"), this.chunks = this.options.chunks.map((t14, e14) => new tO3(e14, t14)), this.schema = t13.schema, this.indexes = t13.indexes, this.resolveRichText = t13.resolveRichText, this.resolveVectorSetItem = t13.resolveVectorSetItem, this.id = t13.id;
  }
};

// http-url:https://framerusercontent.com/modules/pZnfY0Y5oVEwIFWbwseo/nLQuNacprbzBwAoMYKOX/wWC8EGMFo-1.js
import { jsx as e12 } from "react/jsx-runtime";
import { AutoBreakpointVariant as t11, ComponentPresetsConsumer as r8, Link as n8, motion as o8 } from "./_framer-runtime.js";
import { isValidElement as i6 } from "react";
import { Fragment as p8, createElement as s6 } from "react";
var a6;
var l8 = "undefined" != typeof __dai_window;
var f6 = l8 && "function" == typeof __dai_window.requestIdleCallback;
var u8 = "preload";
function c7(e14) {
  return "object" == typeof e14 && null !== e14 && !/* @__PURE__ */ i6(e14) && u8 in e14;
}
function m6(e14, ...t13) {
  if (!e14)
    throw Error("Assertion Error" + (t13.length > 0 ? ": " + t13.join(" ") : ""));
}
var d8 = ((a6 = d8 || {})[a6.Fragment = 1] = "Fragment", a6[a6.Link = 2] = "Link", a6[a6.Module = 3] = "Module", a6[a6.Tag = 4] = "Tag", a6[a6.Text = 5] = "Text", a6);
function g6(i7) {
  let a8 = /* @__PURE__ */ new Map();
  return (l10) => {
    let f8 = a8.get(l10);
    if (f8)
      return f8;
    let u10 = JSON.parse(l10), d10 = function a9(l11) {
      switch (l11[0]) {
        case 1: {
          let [, ...e14] = l11, t13 = e14.map(a9);
          return /* @__PURE__ */ s6(p8, void 0, ...t13);
        }
        case 2: {
          let [, e14, ...t13] = l11, r9 = t13.map(a9);
          return /* @__PURE__ */ s6(n8, e14, ...r9);
        }
        case 3: {
          let [, n10, o9, f9, u11] = l11;
          for (let e14 of f9) {
            let t13 = o9[e14];
            t13 && (o9[e14] = a9(t13));
          }
          for (let e14 of u11) {
            let t13 = o9[e14];
            if ("string" != typeof t13)
              continue;
            let r9 = i7[t13];
            r9 && (c7(r9) && r9.preload(), o9[e14] = r9);
          }
          let p10 = i7[n10];
          return m6(p10, "Module not found"), c7(p10) && p10.preload(), /* @__PURE__ */ e12(r8, { componentIdentifier: n10, children: (r9) => /* @__PURE__ */ e12(t11, { component: p10, props: { ...r9, ...o9 } }) });
        }
        case 4: {
          let [, e14, t13, ...r9] = l11, n10 = r9.map(a9);
          if ("a" === e14)
            return /* @__PURE__ */ s6(o8.a, t13, ...n10);
          return /* @__PURE__ */ s6(e14, t13, ...n10);
        }
        case 5: {
          let [, e14] = l11;
          return e14;
        }
      }
    }(u10);
    return a8.set(l10, d10), d10;
  };
}

// http-url:https://framerusercontent.com/modules/pZnfY0Y5oVEwIFWbwseo/nLQuNacprbzBwAoMYKOX/wWC8EGMFo.js
var m7 = t12(() => Promise.resolve().then(() => (init_W76pPiwFl(), W76pPiwFl_exports)));
var n9 = { bRLi7BvJJ: { isNullable: true, type: l9.ResponsiveImage }, BVHw1asXj: { isNullable: true, type: l9.ResponsiveImage }, createdAt: { isNullable: true, type: l9.Date }, cxkHsOrjz: { isNullable: true, type: l9.ResponsiveImage }, eDZ42NszQ: { isNullable: true, type: l9.ResponsiveImage }, ENbbVp8vc: { isNullable: true, type: l9.Number }, fc8SWJvvh: { definition: { isNullable: true, type: l9.String }, isNullable: true, type: l9.Array }, ho7bJj83Y: { isNullable: true, type: l9.ResponsiveImage }, id: { isNullable: false, type: l9.String }, kEAdWZ6bN: { isNullable: true, type: l9.ResponsiveImage }, L0XvF6Czl: { isNullable: true, type: l9.Number }, MmZDiJKCx: { isNullable: true, type: l9.ResponsiveImage }, MyF9IreYr: { isNullable: true, type: l9.ResponsiveImage }, nextItemId: { isNullable: true, type: l9.String }, NF5HioKUo: { isNullable: true, type: l9.Boolean }, nSPJuhtcH: { definition: { isNullable: true, type: l9.String }, isNullable: true, type: l9.Array }, previousItemId: { isNullable: true, type: l9.String }, rPQCyIqtZ: { definition: { isNullable: true, type: l9.String }, isNullable: true, type: l9.Array }, txBAYRkX5: { isNullable: true, type: l9.ResponsiveImage }, uEVRVrN3G: { isNullable: true, type: l9.RichText }, ULM6scxx_: { isNullable: true, type: l9.String }, updatedAt: { isNullable: true, type: l9.Date }, vXC_2Qw_g: { definition: { isNullable: true, type: l9.String }, isNullable: true, type: l9.Array }, WdGHyjYPS: { definition: { isNullable: true, type: l9.String }, isNullable: true, type: l9.Array }, wjbVR4laR: { isNullable: true, type: l9.String }, WpJ3gRydg: { isNullable: true, type: l9.Link }, X3CtE80s9: { isNullable: true, type: l9.String }, YFdaPgYa5: { isNullable: true, type: l9.ResponsiveImage }, yp6exRXCn: { isNullable: true, type: l9.ResponsiveImage }, yYNW6Sz6Q: { isNullable: true, type: l9.ResponsiveImage } };
var c8 = ["id"];
var s7 = { type: 1 };
var u9 = ["previousItemId"];
var d9 = ["nextItemId"];
var f7 = ["id", "wjbVR4laR"];
var p9 = ["wjbVR4laR", "id"];
var w4 = ["wjbVR4laR"];
var y5 = { type: 0 };
var g7 = ["X3CtE80s9"];
var R4 = ["L0XvF6Czl"];
var N4 = ["ULM6scxx_"];
var h4 = ["uEVRVrN3G"];
var C4 = ["NF5HioKUo"];
var I4 = ["nSPJuhtcH"];
var b4 = ["vXC_2Qw_g"];
var S2 = ["WdGHyjYPS"];
var x4 = ["WpJ3gRydg"];
var v4 = ["fc8SWJvvh"];
var L4 = ["rPQCyIqtZ"];
var M4 = ["ENbbVp8vc"];
var W4 = ["cxkHsOrjz"];
var F2 = ["yp6exRXCn"];
var E4 = ["yYNW6Sz6Q"];
var G4 = ["BVHw1asXj"];
var U2 = ["txBAYRkX5"];
var V4 = ["MmZDiJKCx"];
var P4 = ["bRLi7BvJJ"];
var j4 = ["YFdaPgYa5"];
var B4 = ["kEAdWZ6bN"];
var J4 = ["MyF9IreYr"];
var Y4 = ["ho7bJj83Y"];
var A4 = ["eDZ42NszQ"];
var X4 = [];
var H4 = (e14) => {
  let l10 = X4[e14];
  if (l10)
    return l10().then((e15) => e15.default);
};
var k4 = { "local-module:canvasComponent/W76pPiwFl:default": m7 };
var z4 = g6(k4);
var D4 = new a7();
var Q4 = { collectionByLocaleId: { default: new tP3({ chunks: [""], id: "959e97c7-2542-4a37-896e-a09a59aaa98ddefault", indexes: [new tN({ collation: s7, collectionSchema: n9, fieldNames: c8, range: { from: 0, to: 433 }, url: "" }), new tN({ collation: s7, collectionSchema: n9, fieldNames: u9, range: { from: 433, to: 865 }, url: "" }), new tN({ collation: s7, collectionSchema: n9, fieldNames: d9, range: { from: 865, to: 1293 }, url: "" }), new tN({ collation: s7, collectionSchema: n9, fieldNames: f7, range: { from: 1293, to: 2164 }, url: "" }), new tN({ collation: s7, collectionSchema: n9, fieldNames: p9, range: { from: 2164, to: 3035 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: w4, range: { from: 3035, to: 3662 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: g7, range: { from: 3662, to: 4289 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: R4, range: { from: 4289, to: 4644 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: N4, range: { from: 4644, to: 5322 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: h4, range: { from: 5322, to: 12961 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: C4, range: { from: 12961, to: 13197 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: I4, range: { from: 13197, to: 13814 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: b4, range: { from: 13814, to: 14319 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: S2, range: { from: 14319, to: 14666 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: x4, range: { from: 14666, to: 15429 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: v4, range: { from: 15429, to: 17558 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: L4, range: { from: 17558, to: 18197 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: M4, range: { from: 18197, to: 18552 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: W4, range: { from: 18552, to: 27840 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: F2, range: { from: 27840, to: 37173 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: E4, range: { from: 37173, to: 46187 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: G4, range: { from: 46187, to: 55303 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: U2, range: { from: 55303, to: 64432 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: V4, range: { from: 64432, to: 73417 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: P4, range: { from: 73417, to: 78807 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: j4, range: { from: 78807, to: 79549 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: B4, range: { from: 79549, to: 79768 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: J4, range: { from: 79768, to: 79987 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: Y4, range: { from: 79987, to: 80206 }, url: "" }), new tN({ collation: y5, collectionSchema: n9, fieldNames: A4, range: { from: 80206, to: 80425 }, url: "" })], resolveRichText: z4, resolveVectorSetItem: H4, schema: n9 }) }, displayName: "Shoes", id: "959e97c7-2542-4a37-896e-a09a59aaa98d" };
var wWC8EGMFo_default = Q4;
e13(Q4, { wjbVR4laR: { preventLocalization: true, title: "Slug", type: l9.String }, X3CtE80s9: { defaultValue: "", title: "Product Title", type: l9.String }, L0XvF6Czl: { defaultValue: 0, title: "Price", type: l9.Number }, ULM6scxx_: { defaultValue: "", title: "Tagline", type: l9.String }, uEVRVrN3G: { defaultValue: "", title: "Description", type: l9.RichText }, NF5HioKUo: { defaultValue: false, title: "Best Seller", type: l9.Boolean }, nSPJuhtcH: { dataIdentifier: "local-module:collection/N2cLBMuUA:default", title: "Categories", type: l9.MultiCollectionReference }, vXC_2Qw_g: { dataIdentifier: "local-module:collection/N2cLBMuUA:default", defaultValue: ["fsNLTrnXE"], title: "Gender", type: l9.MultiCollectionReference }, WdGHyjYPS: { dataIdentifier: "local-module:collection/N2cLBMuUA:default", title: "Collection", type: l9.MultiCollectionReference }, WpJ3gRydg: { title: "Checkout Link", type: l9.Link }, fc8SWJvvh: { dataIdentifier: "local-module:collection/fHBgVg8VC:default", title: "Shoe Sizes", type: l9.MultiCollectionReference }, rPQCyIqtZ: { dataIdentifier: "local-module:collection/wWC8EGMFo:default", title: "Available Colors", type: l9.MultiCollectionReference }, ENbbVp8vc: { defaultValue: 1, max: 10, title: "Total Product Images", type: l9.Number }, cxkHsOrjz: { title: "Primary Thumbnail", type: l9.ResponsiveImage }, yp6exRXCn: { title: "Secondary Thumbnail", type: l9.ResponsiveImage }, yYNW6Sz6Q: { title: "Product Image 1", type: l9.ResponsiveImage }, BVHw1asXj: { title: "Product Image 2", type: l9.ResponsiveImage }, txBAYRkX5: { title: "Product Image 3", type: l9.ResponsiveImage }, MmZDiJKCx: { title: "Product Image 4", type: l9.ResponsiveImage }, bRLi7BvJJ: { title: "Product Image 5", type: l9.ResponsiveImage }, YFdaPgYa5: { title: "Product Image 6", type: l9.ResponsiveImage }, kEAdWZ6bN: { title: "Product Image 7", type: l9.ResponsiveImage }, MyF9IreYr: { title: "Product Image 8", type: l9.ResponsiveImage }, ho7bJj83Y: { title: "Product Image 9", type: l9.ResponsiveImage }, eDZ42NszQ: { title: "Product Image 10", type: l9.ResponsiveImage }, createdAt: { title: "Created", type: l9.Date }, updatedAt: { title: "Updated", type: l9.Date }, previousItemId: { dataIdentifier: "local-module:collection/wWC8EGMFo:default", title: "Previous", type: l9.CollectionReference }, nextItemId: { dataIdentifier: "local-module:collection/wWC8EGMFo:default", title: "Next", type: l9.CollectionReference } });

// http-url:https://framerusercontent.com/modules/Y3c7JssK0J04Pi1wENDI/J3i0ArfDP7eO2DxBS5bi/MAHpRD0re.js
import { jsx as _jsx10, jsxs as _jsxs7 } from "react/jsx-runtime";
import { addFonts as addFonts8, addPropertyControls as addPropertyControls9, ControlType as ControlType9, cx as cx10, getFontsFromSharedStyle as getFontsFromSharedStyle6, getLoadingLazyAtYPosition as getLoadingLazyAtYPosition2, Image as Image12, patchBorderRadiusScaleCorrector as patchBorderRadiusScaleCorrector3, RichText as RichText6, useComponentViewport as useComponentViewport8, useLocaleInfo as useLocaleInfo8, useVariantState as useVariantState8, withCSS as withCSS10 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup8, motion as motion10, MotionConfigContext as MotionConfigContext8 } from "framer-motion";
import * as React10 from "react";
import { useRef as useRef8 } from "react";
var enabledGestures3 = { qAY1dxxym: { hover: true, pressed: true } };
var cycleOrder8 = ["qAY1dxxym", "D_Ux2Uw8e"];
var serializationHash8 = "framer-qfDvg";
var variantClassNames8 = { D_Ux2Uw8e: "framer-v-m2tj67", qAY1dxxym: "framer-v-jea2hn" };
function addPropertyOverrides8(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var patchBorderRadiusScaleCorrector13 = patchBorderRadiusScaleCorrector3();
var transition18 = { bounce: 0, delay: 0, duration: 0.4, type: "spring" };
var toResponsiveImage3 = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var Transition8 = ({ value, children }) => {
  const config = React10.useContext(MotionConfigContext8);
  const transition = value ?? config.transition;
  const contextValue = React10.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx10(MotionConfigContext8.Provider, { value: contextValue, children });
};
var humanReadableVariantMap8 = { Primary: "qAY1dxxym", Secondary: "D_Ux2Uw8e" };
var Variants8 = motion10.create(React10.Fragment);
var getProps10 = ({ description, height, id, image, title, width, ...props }) => {
  return { ...props, gpvEgx4zq: title ?? props.gpvEgx4zq ?? "Shoe Title", v3F5antSO: image ?? props.v3F5antSO, variant: humanReadableVariantMap8[props.variant] ?? props.variant ?? "qAY1dxxym", WuDULKXuG: description ?? props.WuDULKXuG ?? "Shoe Description" };
};
var createLayoutDependency8 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component10 = /* @__PURE__ */ React10.forwardRef(function(props, ref) {
  const fallbackRef = useRef8(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React10.useId();
  const { activeLocale, setLocale } = useLocaleInfo8();
  const componentViewport = useComponentViewport8();
  const { style, className: className9, layoutId, variant, v3F5antSO, gpvEgx4zq, WuDULKXuG, ...restProps } = getProps10(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState8({ cycleOrder: cycleOrder8, defaultVariant: "qAY1dxxym", enabledGestures: enabledGestures3, ref: refBinding, variant, variantClassNames: variantClassNames8 });
  const layoutDependency = createLayoutDependency8(props, variants);
  const sharedStyleClassNames = [className6, className5];
  const scopingClassNames = cx10(serializationHash8, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx10(LayoutGroup8, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx10(Variants8, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx10(Transition8, { value: transition18, children: /* @__PURE__ */ _jsxs7(motion10.div, { ...restProps, ...gestureHandlers, className: cx10(scopingClassNames, "framer-jea2hn", className9, classNames), "data-framer-name": "Primary", "data-selection": true, draggable: "false", layoutDependency, layoutId: "Navigation__qAY1dxxym", ref: refBinding, style: { "--corner-shape-fallback": 0.796, backgroundColor: "var(--token-f8fea787-91d7-4f16-9ffc-1b8878b28370, rgba(255, 255, 255, 0))", borderBottomLeftRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", cornerShape: "superellipse(1.4)", ...style }, variants: { "qAY1dxxym-hover": { backgroundColor: "var(--token-95c084b4-d1a9-4aff-952a-4e4df875dae3, rgba(0, 0, 0, 0.03))" }, "qAY1dxxym-pressed": { backgroundColor: "var(--token-10b1d161-c117-4b84-9b1c-fd7497ecf71a, rgba(0, 0, 0, 0.03))" } }, ...addPropertyOverrides8({ "qAY1dxxym-hover": { "data-framer-name": void 0 }, "qAY1dxxym-pressed": { "data-framer-name": void 0 }, D_Ux2Uw8e: { "data-framer-name": "Secondary" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx10(Image12, { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition2((componentViewport?.y || 0) + (8 + ((componentViewport?.height || 68) - 16 - 52) / 2)), pixelHeight: 1200, pixelWidth: 967, sizes: "52px", ...toResponsiveImage3(v3F5antSO) }, className: "framer-1gkufcb", draggable: "false", layoutDependency, layoutId: "Navigation__waKvRtafa", style: { "--corner-shape-fallback": 0.796, borderBottomLeftRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(17px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", cornerShape: "superellipse(1.4)" }, variants: { D_Ux2Uw8e: { borderBottomLeftRadius: "calc(14px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(14px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(14px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(14px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))" } }, ...addPropertyOverrides8({ D_Ux2Uw8e: { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition2((componentViewport?.y || 0) + (0 + ((componentViewport?.height || 44) - 0 - 40) / 2)), pixelHeight: 1200, pixelWidth: 967, sizes: "40px", ...toResponsiveImage3(v3F5antSO) } } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsxs7(motion10.div, { className: "framer-1rl2cjf", "data-framer-name": "Text", layoutDependency, layoutId: "Navigation__XqBucBIb8", children: [/* @__PURE__ */ _jsx10(RichText6, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx10(React10.Fragment, { children: /* @__PURE__ */ _jsx10(motion10.p, { className: "framer-styles-preset-rr2jlr", "data-styles-preset": "pcXFA2pNr", dir: "auto", style: { "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "Shoe Title" }) }), className: "framer-86vam0", "data-framer-name": "Text", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__zL7VAD6Az", style: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))", "--framer-paragraph-spacing": "0px" }, text: gpvEgx4zq, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx10(RichText6, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx10(React10.Fragment, { children: /* @__PURE__ */ _jsx10(motion10.p, { className: "framer-styles-preset-9tj2n0", "data-styles-preset": "amNEcipQY", dir: "auto", style: { "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-5c950482-85ac-4716-bcd5-1945331447e4, rgb(133, 133, 133)))" }, children: "Shoe Description" }) }), className: "framer-1cpjxcu", "data-framer-name": "Title", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__kI1M9rviO", style: { "--extracted-r6o4lv": "var(--token-5c950482-85ac-4716-bcd5-1945331447e4, rgb(133, 133, 133))", "--framer-paragraph-spacing": "0px" }, text: WuDULKXuG, verticalAlignment: "top", withExternalLayout: true })] })] }) }) }) });
});
var css18 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-qfDvg.framer-1ycbvyc, .framer-qfDvg .framer-1ycbvyc { display: block; }", ".framer-qfDvg.framer-jea2hn { --selection-background-color: rgba(0, 153, 255, 0.15); --selection-color: #0099FF; align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 8px; position: relative; width: 100%; }", ".framer-qfDvg .framer-1gkufcb { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 52px); overflow: var(--overflow-clip-fallback, clip); position: relative; width: 52px; will-change: var(--framer-will-change-override, transform); }", ".framer-qfDvg .framer-1rl2cjf { -webkit-user-select: none; align-content: flex-start; align-items: flex-start; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 2px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; user-select: none; width: 1px; }", ".framer-qfDvg .framer-86vam0 { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; z-index: 1; }", '.framer-qfDvg .framer-1cpjxcu { --text-truncation-display-inline-for-safari-16: inline; --text-truncation-display-none-for-safari-16: none; --text-truncation-line-break-for-safari-16: "\\A"; -webkit-box-orient: vertical; -webkit-line-clamp: 1; display: -webkit-box; flex: none; height: auto; overflow: var(--overflow-clip-fallback, clip); position: relative; white-space: pre-line; width: 100%; word-break: break-word; word-wrap: break-word; z-index: 1; }', ".framer-qfDvg.framer-v-m2tj67.framer-jea2hn { cursor: unset; padding: 0px; }", ".framer-qfDvg.framer-v-m2tj67 .framer-1gkufcb { height: var(--framer-aspect-ratio-supported, 40px); width: 40px; }", '.framer-qfDvg.framer-v-m2tj67 .framer-86vam0 { --text-truncation-display-inline-for-safari-16: inline; --text-truncation-display-none-for-safari-16: none; --text-truncation-line-break-for-safari-16: "\\A"; -webkit-box-orient: vertical; -webkit-line-clamp: 1; display: -webkit-box; overflow: var(--overflow-clip-fallback, clip); white-space: pre-line; }', ...css10, ...css9, '.framer-qfDvg[data-selection="true"] * ::selection, .framer-qfDvg [data-selection="true"] * ::selection { color: var(--selection-color, none); background-color: var(--selection-background-color, none); }'];
var FramerMAHpRD0re = withCSS10(Component10, css18, "framer-qfDvg");
var MAHpRD0re_default = FramerMAHpRD0re;
FramerMAHpRD0re.displayName = "Shop Dropdown Item";
FramerMAHpRD0re.defaultProps = { height: 68, width: 352 };
addPropertyControls9(FramerMAHpRD0re, { variant: { options: ["qAY1dxxym", "D_Ux2Uw8e"], optionTitles: ["Primary", "Secondary"], title: "Variant", type: ControlType9.Enum }, v3F5antSO: { title: "Image", type: ControlType9.ResponsiveImage }, gpvEgx4zq: { defaultValue: "Shoe Title", description: "", displayTextArea: false, title: "Title", type: ControlType9.String }, ongpvEgx4zqChange: { changes: "gpvEgx4zq", type: ControlType9.ChangeHandler }, WuDULKXuG: { defaultValue: "Shoe Description", displayTextArea: false, title: "Description", type: ControlType9.String }, onWuDULKXuGChange: { changes: "WuDULKXuG", type: ControlType9.ChangeHandler } });
addFonts8(FramerMAHpRD0re, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle6(fonts6), ...getFontsFromSharedStyle6(fonts5)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/zLBZJQKcwfnhs9HEkaXy/UI08KOIY0MtqQ0SlyCM0/o_lEGaEg0.js
var SeparatorFonts3 = getFonts3(BbFuZPGaK_default);
var ShopDropdownItemFonts = getFonts3(MAHpRD0re_default);
var ButtonFonts3 = getFonts3(b_m5Js9Ir_default);
var cycleOrder9 = ["nkpDO0rw3", "F5YJQgLJU", "xFFVNOV6G", "Hh6m3CMb7"];
var serializationHash9 = "framer-feB7L";
var variantClassNames9 = { F5YJQgLJU: "framer-v-1cpsf3y", Hh6m3CMb7: "framer-v-17mmk2i", nkpDO0rw3: "framer-v-1y2345o", xFFVNOV6G: "framer-v-nfvrwm" };
function addPropertyOverrides9(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition19 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var matchVariant3 = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var patchBorderRadiusScaleCorrector14 = patchBorderRadiusScaleCorrector4();
var transition2 = { duration: 0, type: "tween" };
var toResponsiveImage4 = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var Transition9 = ({ value, children }) => {
  const config = React11.useContext(MotionConfigContext9);
  const transition = value ?? config.transition;
  const contextValue = React11.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx11(MotionConfigContext9.Provider, { value: contextValue, children });
};
var query12 = () => ({ from: { alias: "BhFBd73RB", data: wWC8EGMFo_default, type: "Collection" }, limit: { type: "LiteralValue", value: 3 }, select: [{ collection: "BhFBd73RB", name: "wjbVR4laR", type: "Identifier" }, { collection: "BhFBd73RB", name: "cxkHsOrjz", type: "Identifier" }, { collection: "BhFBd73RB", name: "X3CtE80s9", type: "Identifier" }, { collection: "BhFBd73RB", name: "ULM6scxx_", type: "Identifier" }, { collection: "BhFBd73RB", name: "id", type: "Identifier" }] });
var query3 = () => ({ from: { alias: "BhFBd73RB", data: wWC8EGMFo_default, type: "Collection" }, limit: { type: "LiteralValue", value: 3 }, select: [{ collection: "BhFBd73RB", name: "wjbVR4laR", type: "Identifier" }, { collection: "BhFBd73RB", name: "cxkHsOrjz", type: "Identifier" }, { collection: "BhFBd73RB", name: "X3CtE80s9", type: "Identifier" }, { collection: "BhFBd73RB", name: "ULM6scxx_", type: "Identifier" }, { collection: "BhFBd73RB", name: "id", type: "Identifier" }], where: { left: { left: { arguments: [{ arguments: [{ arguments: [{ from: { alias: "WdGHyjYPS", data: N2cLBMuUA_default, type: "Collection" }, orderBy: [{ arguments: [{ collection: "BhFBd73RB", name: "WdGHyjYPS", type: "Identifier" }, { collection: "WdGHyjYPS", name: "id", type: "Identifier" }], functionName: "INDEX_OF", type: "FunctionCall" }], select: [{ collection: "WdGHyjYPS", name: "id", type: "Identifier" }], type: "Select", where: { left: { collection: "WdGHyjYPS", name: "id", type: "Identifier" }, operator: "in", right: { collection: "BhFBd73RB", name: "WdGHyjYPS", type: "Identifier" }, type: "BinaryOperation" } }], functionName: "FLAT_ARRAY", type: "FunctionCall" }, { type: "LiteralValue", value: ["DZPAvW9I7"] }], functionName: "INTERSECT", type: "FunctionCall" }], functionName: "LENGTH", type: "FunctionCall" }, operator: ">", right: { type: "LiteralValue", value: 0 }, type: "BinaryOperation" }, operator: "or", right: { left: { arguments: [{ type: "LiteralValue", value: ["DZPAvW9I7"] }], functionName: "LENGTH", type: "FunctionCall" }, operator: "==", right: { type: "LiteralValue", value: 0 }, type: "BinaryOperation" }, type: "BinaryOperation" } });
var QueryData2 = ({ query, pageSize, children }) => {
  const data = useQueryData2(query);
  return children(data);
};
var humanReadableVariantMap9 = { "Primary All": "nkpDO0rw3", "Primary Featured": "xFFVNOV6G", "Secondary All": "F5YJQgLJU", "Secondary Featured": "Hh6m3CMb7" };
var Variants9 = motion11.create(React11.Fragment);
var getProps11 = ({ closeNavigation, height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap9[props.variant] ?? props.variant ?? "nkpDO0rw3", wdTSPFeS2: closeNavigation ?? props.wdTSPFeS2 };
};
var createLayoutDependency9 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component11 = /* @__PURE__ */ React11.forwardRef(function(props, ref) {
  const fallbackRef = useRef9(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React11.useId();
  const { activeLocale, setLocale } = useLocaleInfo9();
  const componentViewport = useComponentViewport9();
  const { style, className: className9, layoutId, variant, wdTSPFeS2, ...restProps } = getProps11(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState9({ cycleOrder: cycleOrder9, defaultVariant: "nkpDO0rw3", ref: refBinding, variant, variantClassNames: variantClassNames9 });
  const layoutDependency = createLayoutDependency9(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback4(baseVariant);
  const onTap1xrl59r = activeVariantCallback(async (...args) => {
    setVariant("nkpDO0rw3");
  });
  const onTap1e75ydj = activeVariantCallback(async (...args) => {
    setVariant("F5YJQgLJU");
  });
  const onTap1wfi2bv = activeVariantCallback(async (...args) => {
    setVariant("xFFVNOV6G");
  });
  const onTapepqj7d = activeVariantCallback(async (...args) => {
    setVariant("Hh6m3CMb7");
  });
  const DY2dzgeiOhko41j = activeVariantCallback(async (...args) => {
    if (wdTSPFeS2) {
      const res = await wdTSPFeS2(...args);
      if (res === false)
        return false;
    }
  });
  const sharedStyleClassNames = [className, className3];
  const scopingClassNames = cx11(serializationHash9, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (["F5YJQgLJU", "Hh6m3CMb7"].includes(baseVariant))
      return false;
    return true;
  };
  const router = useRouter3();
  return /* @__PURE__ */ _jsx11(LayoutGroup9, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx11(Variants9, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx11(Transition9, { value: transition19, children: /* @__PURE__ */ _jsxs8(motion11.div, { ...restProps, ...gestureHandlers, className: cx11(scopingClassNames, "framer-1y2345o", className9, classNames), "data-framer-name": "Primary All", layoutDependency, layoutId: "Navigation__nkpDO0rw3", ref: refBinding, style: { ...style }, ...addPropertyOverrides9({ F5YJQgLJU: { "data-framer-name": "Secondary All" }, Hh6m3CMb7: { "data-framer-name": "Secondary Featured" }, xFFVNOV6G: { "data-framer-name": "Primary Featured" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx11(ComponentViewportProvider3, { height: 1, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 12 + 0, ...addPropertyOverrides9({ F5YJQgLJU: { y: (componentViewport?.y || 0) + 0 + 0 }, Hh6m3CMb7: { y: (componentViewport?.y || 0) + 0 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer3, { className: "framer-1x8fmd8-container", layoutDependency, layoutId: "Navigation__RHQEy_U8p-container", nodeId: "RHQEy_U8p", rendersWithMotion: true, scopeId: "o_lEGaEg0", children: /* @__PURE__ */ _jsx11(BbFuZPGaK_default, { height: "100%", id: "RHQEy_U8p", layoutId: "Navigation__RHQEy_U8p", style: { height: "100%", width: "100%" }, variant: matchVariant3("FveAb6f2W"), width: "100%" }) }) }), /* @__PURE__ */ _jsxs8(motion11.div, { className: "framer-qqtkop", "data-framer-name": "Phone Menu Segmented Control", layoutDependency, layoutId: "Navigation__K5DOOMnDq", style: { "--corner-shape-fallback": 0.796, backgroundColor: "var(--token-10b1d161-c117-4b84-9b1c-fd7497ecf71a, rgba(0, 0, 0, 0.05))", borderBottomLeftRadius: "calc(16px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(16px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(16px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(16px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", cornerShape: "superellipse(1.4)" }, children: [/* @__PURE__ */ _jsx11(motion11.div, { className: "framer-1jlsl1a", "data-framer-name": "Item", "data-highlight": true, layoutDependency, layoutId: "Navigation__zGLtu27gh", onTap: onTap1xrl59r, ...addPropertyOverrides9({ F5YJQgLJU: { onTap: onTap1e75ydj }, Hh6m3CMb7: { onTap: onTap1e75ydj } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx11(RichText7, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx11(React11.Fragment, { children: /* @__PURE__ */ _jsx11(motion11.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "All" }) }), className: "framer-1b2ervs", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__iIhsTyple", style: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))", "--framer-paragraph-spacing": "0px" }, variants: { Hh6m3CMb7: { "--extracted-r6o4lv": "var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122))" }, xFFVNOV6G: { "--extracted-r6o4lv": "var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122))" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides9({ Hh6m3CMb7: { children: /* @__PURE__ */ _jsx11(React11.Fragment, { children: /* @__PURE__ */ _jsx11(motion11.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122)))" }, children: "All" }) }) }, xFFVNOV6G: { children: /* @__PURE__ */ _jsx11(React11.Fragment, { children: /* @__PURE__ */ _jsx11(motion11.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122)))" }, children: "All" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx11(motion11.div, { className: "framer-p0gima", "data-framer-name": "Item", "data-highlight": true, layoutDependency, layoutId: "Navigation__gn80mS3RF", onTap: onTap1wfi2bv, ...addPropertyOverrides9({ F5YJQgLJU: { onTap: onTapepqj7d }, Hh6m3CMb7: { onTap: onTapepqj7d } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx11(RichText7, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx11(React11.Fragment, { children: /* @__PURE__ */ _jsx11(motion11.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122)))" }, children: "Legends" }) }), className: "framer-qlqd64", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__zHOuAVC0Z", style: { "--extracted-r6o4lv": "var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122))", "--framer-paragraph-spacing": "0px" }, variants: { Hh6m3CMb7: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))" }, xFFVNOV6G: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides9({ Hh6m3CMb7: { children: /* @__PURE__ */ _jsx11(React11.Fragment, { children: /* @__PURE__ */ _jsx11(motion11.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "Legends" }) }) }, xFFVNOV6G: { children: /* @__PURE__ */ _jsx11(React11.Fragment, { children: /* @__PURE__ */ _jsx11(motion11.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "Legends" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx11(motion11.div, { className: "framer-18md7p1", "data-framer-name": "Active Indicator", layoutDependency, layoutId: "Navigation__GHebJETIB", style: { "--corner-shape-fallback": 0.796, backgroundColor: "var(--token-9039c660-569a-421b-a527-9ac056ae9951, rgb(255, 255, 255))", borderBottomLeftRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", boxShadow: "0px 0px 2px 0px rgba(0, 0, 0, 0.15)", cornerShape: "superellipse(1.4)" } })] }), /* @__PURE__ */ _jsxs8(motion11.div, { className: "framer-1xcwlc6", "data-framer-name": "Content", layoutDependency, layoutId: "Navigation__pu7UaLWDN", children: [isDisplayed() && /* @__PURE__ */ _jsx11(motion11.div, { className: "framer-1vb0oqb", "data-framer-name": "Header", layoutDependency, layoutId: "Navigation__Dkx2UlIFw", children: /* @__PURE__ */ _jsx11(RichText7, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx11(React11.Fragment, { children: /* @__PURE__ */ _jsx11(motion11.p, { className: "framer-styles-preset-1nkfhjw", "data-styles-preset": "hWdlH0iq7", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "Top picks" }) }), className: "framer-yyymr", "data-framer-name": "Title", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__d_TUtXX1J", style: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))", "--framer-paragraph-spacing": "0px" }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides9({ xFFVNOV6G: { children: /* @__PURE__ */ _jsx11(React11.Fragment, { children: /* @__PURE__ */ _jsx11(motion11.p, { className: "framer-styles-preset-1nkfhjw", "data-styles-preset": "hWdlH0iq7", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "Legends Collection" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx11(Transition9, { value: transition2, children: /* @__PURE__ */ _jsx11(motion11.div, { className: "framer-1p73alv", layoutDependency, layoutId: "Navigation__BhFBd73RB", children: /* @__PURE__ */ _jsx11(ChildrenCanSuspend2, { children: /* @__PURE__ */ _jsx11(QueryData2, { query: query12(), ...addPropertyOverrides9({ Hh6m3CMb7: { query: query3() }, xFFVNOV6G: { query: query3() } }, baseVariant, gestureVariant), children: (collection, paginationInfo, loadMore) => {
    return /* @__PURE__ */ _jsx11(_Fragment2, { children: collection?.map(({ cxkHsOrjz: cxkHsOrjzBhFBd73RB, id: idBhFBd73RB, ULM6scxx_: ULM6scxx_BhFBd73RB, wjbVR4laR: wjbVR4laRBhFBd73RB, X3CtE80s9: X3CtE80s9BhFBd73RB }, index) => {
      wjbVR4laRBhFBd73RB ?? (wjbVR4laRBhFBd73RB = "");
      X3CtE80s9BhFBd73RB ?? (X3CtE80s9BhFBd73RB = "");
      ULM6scxx_BhFBd73RB ?? (ULM6scxx_BhFBd73RB = "");
      return /* @__PURE__ */ _jsx11(LayoutGroup9, { id: `BhFBd73RB-${idBhFBd73RB}`, children: /* @__PURE__ */ _jsx11(PathVariablesContext2.Provider, { value: { wjbVR4laR: wjbVR4laRBhFBd73RB }, children: /* @__PURE__ */ _jsx11(Transition9, { value: transition2, children: /* @__PURE__ */ _jsx11(Link4, { href: { pathVariables: { wjbVR4laR: wjbVR4laRBhFBd73RB }, webPageId: "fIwdA4CC3" }, motionChild: true, nodeId: "sqY36KlLg", scopeId: "o_lEGaEg0", children: /* @__PURE__ */ _jsx11(motion11.a, { className: "framer-10jupuw framer-d5bfm1", layoutDependency, layoutId: "Navigation__sqY36KlLg", children: /* @__PURE__ */ _jsx11(Transition9, { value: transition2, children: /* @__PURE__ */ _jsx11(ComponentViewportProvider3, { height: 68, width: `max(${componentViewport?.width || "100vw"}, 1px)`, y: (componentViewport?.y || 0) + 12 + 63 + 0 + 106 + 0 + 136 + 0, ...addPropertyOverrides9({ F5YJQgLJU: { y: (componentViewport?.y || 0) + 0 + 55 + 0 + 0 + 0 + 168 + 0 }, Hh6m3CMb7: { y: (componentViewport?.y || 0) + 0 + 55 + 0 + 0 + 0 + 0 + 0 }, xFFVNOV6G: { y: (componentViewport?.y || 0) + 12 + 63 + 0 + 106 + 0 + 0 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer3, { className: "framer-1xfowy2-container", draggable: "false", layoutDependency, layoutId: "Navigation__GFjK3ZQRd-container", nodeId: "GFjK3ZQRd", rendersWithMotion: true, scopeId: "o_lEGaEg0", children: /* @__PURE__ */ _jsx11(MAHpRD0re_default, { gpvEgx4zq: X3CtE80s9BhFBd73RB, height: "100%", id: "GFjK3ZQRd", layoutId: "Navigation__GFjK3ZQRd", style: { width: "100%" }, v3F5antSO: toResponsiveImage4(cxkHsOrjzBhFBd73RB), variant: matchVariant3("qAY1dxxym"), width: "100%", WuDULKXuG: ULM6scxx_BhFBd73RB, ...addPropertyOverrides9({ F5YJQgLJU: { variant: matchVariant3("D_Ux2Uw8e") }, Hh6m3CMb7: { variant: matchVariant3("D_Ux2Uw8e") } }, baseVariant, gestureVariant) }) }) }) }) }) }) }) }) }, idBhFBd73RB);
    }) });
  } }) }) }) }), /* @__PURE__ */ _jsx11(ResolveLinks3, { links: [{ href: { webPageId: "YYV2AyPUN" }, implicitPathVariables: void 0 }, { href: { webPageId: "YYV2AyPUN" }, implicitPathVariables: void 0 }, { href: { webPageId: "lJgBufJK8" }, implicitPathVariables: void 0 }, { href: { webPageId: "lJgBufJK8" }, implicitPathVariables: void 0 }], children: (resolvedLinks) => /* @__PURE__ */ _jsx11(ComponentViewportProvider3, { height: 29, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 12 + 63 + 0 + 320, ...addPropertyOverrides9({ F5YJQgLJU: { y: (componentViewport?.y || 0) + 0 + 55 + 0 + 252 }, Hh6m3CMb7: { y: (componentViewport?.y || 0) + 0 + 55 + 0 + 84 }, xFFVNOV6G: { y: (componentViewport?.y || 0) + 12 + 63 + 0 + 184 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx11(SmartComponentScopedContainer3, { className: "framer-fgdwt3-container", layoutDependency, layoutId: "Navigation__bTEsDHD1T-container", nodeId: "bTEsDHD1T", rendersWithMotion: true, scopeId: "o_lEGaEg0", children: /* @__PURE__ */ _jsx11(b_m5Js9Ir_default, { DY2dzgeiO: DY2dzgeiOhko41j, height: "100%", hZdVwdl_Y: false, id: "bTEsDHD1T", layoutId: "Navigation__bTEsDHD1T", peKL8pfJA: wggGXhZaC_default, style: { width: "100%" }, TDPWRYXxk: "View all", variant: matchVariant3("zq5haw0aW"), vFRI3q06T: resolvedLinks[0], width: "100%", ...addPropertyOverrides9({ F5YJQgLJU: { vFRI3q06T: resolvedLinks[1] }, Hh6m3CMb7: { vFRI3q06T: resolvedLinks[3] }, xFFVNOV6G: { vFRI3q06T: resolvedLinks[2] } }, baseVariant, gestureVariant) }) }) }) })] })] }) }) }) });
});
var css19 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-feB7L.framer-d5bfm1, .framer-feB7L .framer-d5bfm1 { display: block; }", ".framer-feB7L.framer-1y2345o { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: flex-start; overflow: visible; padding: 12px 0px 0px 0px; position: relative; width: 100%; }", ".framer-feB7L .framer-1x8fmd8-container { flex: none; height: 1px; position: relative; width: 100%; }", ".framer-feB7L .framer-qqtkop { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: 30px; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-feB7L .framer-1jlsl1a, .framer-feB7L .framer-p0gima { align-content: center; align-items: center; cursor: pointer; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: 100%; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 1px; }", ".framer-feB7L .framer-1b2ervs, .framer-feB7L .framer-qlqd64 { -webkit-user-select: none; flex: none; height: auto; position: relative; user-select: none; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; z-index: 1; }", ".framer-feB7L .framer-18md7p1 { bottom: 2px; flex: none; left: 2px; overflow: var(--overflow-clip-fallback, clip); position: absolute; top: 2px; width: 49%; will-change: var(--framer-will-change-override, transform); z-index: 0; }", ".framer-feB7L .framer-1xcwlc6 { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-feB7L .framer-1vb0oqb { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 0px 8px 0px 8px; position: relative; width: 100%; }", ".framer-feB7L .framer-yyymr { flex: 1 0 0px; height: auto; position: relative; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; z-index: 1; }", ".framer-feB7L .framer-1p73alv { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; padding: 0px; position: relative; width: 100%; }", ".framer-feB7L .framer-10jupuw { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: flex-start; padding: 0px; position: relative; text-decoration: none; width: 100%; }", ".framer-feB7L .framer-1xfowy2-container { flex: 1 0 0px; height: auto; position: relative; width: 1px; }", ".framer-feB7L .framer-fgdwt3-container { flex: none; height: auto; position: relative; width: 100%; }", ".framer-feB7L.framer-v-1cpsf3y.framer-1y2345o, .framer-feB7L.framer-v-17mmk2i.framer-1y2345o { gap: 12px; padding: 0px; }", ".framer-feB7L.framer-v-1cpsf3y .framer-1xcwlc6, .framer-feB7L.framer-v-1cpsf3y .framer-1p73alv, .framer-feB7L.framer-v-17mmk2i .framer-1xcwlc6, .framer-feB7L.framer-v-17mmk2i .framer-1p73alv { gap: 16px; }", ".framer-feB7L.framer-v-nfvrwm .framer-18md7p1, .framer-feB7L.framer-v-17mmk2i .framer-18md7p1 { left: unset; right: 2px; }", ...css, ...css4];
var Framero_lEGaEg0 = withCSS11(Component11, css19, "framer-feB7L");
var o_lEGaEg0_default = Framero_lEGaEg0;
Framero_lEGaEg0.displayName = "Shop Dropdown";
Framero_lEGaEg0.defaultProps = { height: 348, width: 350 };
addPropertyControls10(Framero_lEGaEg0, { variant: { options: ["nkpDO0rw3", "F5YJQgLJU", "xFFVNOV6G", "Hh6m3CMb7"], optionTitles: ["Primary All", "Secondary All", "Primary Featured", "Secondary Featured"], title: "Variant", type: ControlType10.Enum }, wdTSPFeS2: { title: "Close Navigation", type: ControlType10.EventHandler } });
addFonts9(Framero_lEGaEg0, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...SeparatorFonts3, ...ShopDropdownItemFonts, ...ButtonFonts3, ...getFontsFromSharedStyle7(fonts), ...getFontsFromSharedStyle7(fonts3)], { supportsExplicitInterCodegen: true });
Framero_lEGaEg0.loader = { load: (props, context) => {
  const locale = context.locale;
  const queryCacheEntry = queryCache2.get(query12(), locale);
  const queryCacheEntry1 = queryCache2.get(query3(), locale);
  return Promise.allSettled([queryCacheEntry.preload(), queryCacheEntry1.preload(), forwardLoader3(BbFuZPGaK_default, {}, context), forwardLoader3(b_m5Js9Ir_default, {}, context), (async () => {
    const parentData = await queryCacheEntry.readMaybeAsync() ?? [];
    return Promise.allSettled(parentData.flatMap((item) => forwardLoader3(MAHpRD0re_default, {}, context)));
  })()]);
} };

// http-url:https://framerusercontent.com/modules/tgYnIy9ktnHAv8npt7cg/xJQ2nCAVc6wh5uZiQnnG/mni7MPPo4.js
var ShopDropdownFonts = getFonts4(o_lEGaEg0_default);
var SmartComponentScopedContainerWithFXWithOptimizedAppearEffect = withOptimizedAppearEffect(withFX(SmartComponentScopedContainer4));
var AboutDropdownFonts = getFonts4(lRoz_3Oi8_default);
var StoreDropdownFonts = getFonts4(A36GR14UW_default);
var cycleOrder10 = ["W6ngOY_l_", "vjhASul2Q", "xbJiSS4kK"];
var serializationHash10 = "framer-19h5b";
var variantClassNames10 = { vjhASul2Q: "framer-v-15tvka2", W6ngOY_l_: "framer-v-6kxzqg", xbJiSS4kK: "framer-v-17qkbf2" };
function addPropertyOverrides10(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition110 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var patchBorderRadiusScaleCorrector15 = patchBorderRadiusScaleCorrector5();
var transition22 = { bounce: 0, delay: 0, duration: 0.6, type: "spring" };
var animation = { opacity: 1, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, transition: transition22, x: 0, y: 0 };
var animation1 = { opacity: 1e-3, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 0 };
var matchVariant4 = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var Transition10 = ({ value, children }) => {
  const config = React12.useContext(MotionConfigContext10);
  const transition = value ?? config.transition;
  const contextValue = React12.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx12(MotionConfigContext10.Provider, { value: contextValue, children });
};
var humanReadableVariantMap10 = { About: "vjhASul2Q", Shop: "W6ngOY_l_", Stores: "xbJiSS4kK" };
var Variants10 = motion12.create(React12.Fragment);
var getProps12 = ({ height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap10[props.variant] ?? props.variant ?? "W6ngOY_l_" };
};
var createLayoutDependency10 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component12 = /* @__PURE__ */ React12.forwardRef(function(props, ref) {
  const fallbackRef = useRef10(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React12.useId();
  const { activeLocale, setLocale } = useLocaleInfo10();
  const componentViewport = useComponentViewport10();
  const { style, className: className9, layoutId, variant, ...restProps } = getProps12(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState10({ cycleOrder: cycleOrder10, defaultVariant: "W6ngOY_l_", ref: refBinding, variant, variantClassNames: variantClassNames10 });
  const layoutDependency = createLayoutDependency10(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback5(baseVariant);
  const onTap1xjf2hx = activeVariantCallback(async (...args) => {
    setVariant("W6ngOY_l_");
  });
  const onTap10b0q7y = activeVariantCallback(async (...args) => {
    setVariant("vjhASul2Q");
  });
  const onTap1jk771k = activeVariantCallback(async (...args) => {
    setVariant("xbJiSS4kK");
  });
  const sharedStyleClassNames = [className];
  const scopingClassNames = cx12(serializationHash10, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (["vjhASul2Q", "xbJiSS4kK"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed1 = () => {
    if (baseVariant === "vjhASul2Q")
      return true;
    return false;
  };
  const isDisplayed2 = () => {
    if (baseVariant === "xbJiSS4kK")
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx12(LayoutGroup10, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx12(Variants10, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx12(Transition10, { value: transition110, children: /* @__PURE__ */ _jsxs9(motion12.div, { ...restProps, ...gestureHandlers, className: cx12(scopingClassNames, "framer-6kxzqg", className9, classNames), "data-framer-name": "Shop", layoutDependency, layoutId: "Navigation__W6ngOY_l_", ref: refBinding, style: { ...style }, ...addPropertyOverrides10({ vjhASul2Q: { "data-framer-name": "About" }, xbJiSS4kK: { "data-framer-name": "Stores" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs9(motion12.div, { className: "framer-14qau0h", "data-framer-name": "Phone Menu Segmented Control", layoutDependency, layoutId: "Navigation__hhsDZ6o9w", style: { "--corner-shape-fallback": 0.796, backgroundColor: "var(--token-10b1d161-c117-4b84-9b1c-fd7497ecf71a, rgba(0, 0, 0, 0.05))", borderBottomLeftRadius: "calc(16px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(16px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(16px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(16px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", cornerShape: "superellipse(1.4)" }, children: [/* @__PURE__ */ _jsx12(motion12.div, { className: "framer-ryjkhe", "data-framer-name": "Item", "data-highlight": true, layoutDependency, layoutId: "Navigation__B0f9TCFEA", onTap: onTap1xjf2hx, children: /* @__PURE__ */ _jsx12(RichText8, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx12(React12.Fragment, { children: /* @__PURE__ */ _jsx12(motion12.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "Shop" }) }), className: "framer-7ia1zw", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__SfCkDLg2C", style: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))", "--framer-paragraph-spacing": "0px" }, variants: { vjhASul2Q: { "--extracted-r6o4lv": "var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122))" }, xbJiSS4kK: { "--extracted-r6o4lv": "var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122))" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides10({ vjhASul2Q: { children: /* @__PURE__ */ _jsx12(React12.Fragment, { children: /* @__PURE__ */ _jsx12(motion12.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122)))" }, children: "Shop" }) }) }, xbJiSS4kK: { children: /* @__PURE__ */ _jsx12(React12.Fragment, { children: /* @__PURE__ */ _jsx12(motion12.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122)))" }, children: "Shop" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx12(motion12.div, { className: "framer-121ii9o", "data-framer-name": "Item", "data-highlight": true, layoutDependency, layoutId: "Navigation__FeZpPXtEN", onTap: onTap10b0q7y, children: /* @__PURE__ */ _jsx12(RichText8, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx12(React12.Fragment, { children: /* @__PURE__ */ _jsx12(motion12.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122)))" }, children: "About" }) }), className: "framer-1v3a361", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__WqXEds6ul", style: { "--extracted-r6o4lv": "var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122))", "--framer-paragraph-spacing": "0px" }, variants: { vjhASul2Q: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides10({ vjhASul2Q: { children: /* @__PURE__ */ _jsx12(React12.Fragment, { children: /* @__PURE__ */ _jsx12(motion12.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "About" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx12(motion12.div, { className: "framer-41adv3", "data-framer-name": "Item", "data-highlight": true, layoutDependency, layoutId: "Navigation__cLZFL1cii", onTap: onTap1jk771k, children: /* @__PURE__ */ _jsx12(RichText8, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx12(React12.Fragment, { children: /* @__PURE__ */ _jsx12(motion12.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122)))" }, children: "Stores" }) }), className: "framer-196tue4", fonts: ["Inter"], layoutDependency, layoutId: "Navigation__C8JYbmdA_", style: { "--extracted-r6o4lv": "var(--token-31c75237-3696-4093-9011-7822eb8b6641, rgb(122, 122, 122))", "--framer-paragraph-spacing": "0px" }, variants: { xbJiSS4kK: { "--extracted-r6o4lv": "var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41))" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides10({ xbJiSS4kK: { children: /* @__PURE__ */ _jsx12(React12.Fragment, { children: /* @__PURE__ */ _jsx12(motion12.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", style: { "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-6d07e840-0908-44af-b7b3-055ece1d0a4b, rgb(41, 41, 41)))" }, children: "Stores" }) }) } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx12(motion12.div, { className: "framer-10v6rmq", "data-framer-name": "Active Indicator", layoutDependency, layoutId: "Navigation__dCRscJFiT", style: { "--corner-shape-fallback": 0.796, backgroundColor: "var(--token-9039c660-569a-421b-a527-9ac056ae9951, rgb(255, 255, 255))", borderBottomLeftRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(20px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", boxShadow: "0px 0px 2px 0px rgba(0, 0, 0, 0.15)", cornerShape: "superellipse(1.4)" } })] }), isDisplayed() && /* @__PURE__ */ _jsx12(ComponentViewportProvider4, { height: 300, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 282.5) - 16 - 346) / 2 + 30 + 16), children: /* @__PURE__ */ _jsx12(SmartComponentScopedContainerWithFXWithOptimizedAppearEffect, { __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, animate: animation, className: "framer-lr7nki-container", "data-framer-appear-id": "lr7nki", initial: animation1, layoutDependency, layoutId: "Navigation__QI9Jflot3-container", nodeId: "QI9Jflot3", optimized: true, rendersWithMotion: true, scopeId: "mni7MPPo4", children: /* @__PURE__ */ _jsx12(o_lEGaEg0_default, { height: "100%", id: "QI9Jflot3", layoutId: "Navigation__QI9Jflot3", style: { width: "100%" }, variant: matchVariant4("F5YJQgLJU"), width: "100%" }) }) }), isDisplayed1() && /* @__PURE__ */ _jsx12(ComponentViewportProvider4, { ...addPropertyOverrides10({ vjhASul2Q: { height: 242, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 302) - 16 - 288) / 2 + 30 + 16) } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx12(SmartComponentScopedContainerWithFXWithOptimizedAppearEffect, { __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, animate: animation, className: "framer-e1luvl-container", "data-framer-appear-id": "e1luvl", initial: animation1, layoutDependency, layoutId: "Navigation__x0yPBCmTh-container", nodeId: "x0yPBCmTh", optimized: true, rendersWithMotion: true, scopeId: "mni7MPPo4", children: /* @__PURE__ */ _jsx12(lRoz_3Oi8_default, { height: "100%", id: "x0yPBCmTh", layoutId: "Navigation__x0yPBCmTh", style: { width: "100%" }, variant: matchVariant4("PvaObb4oi"), width: "100%" }) }) }), isDisplayed2() && /* @__PURE__ */ _jsx12(ComponentViewportProvider4, { ...addPropertyOverrides10({ xbJiSS4kK: { height: 300, width: componentViewport?.width || "100vw", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 306.5) - 16 - 346) / 2 + 30 + 16) } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx12(SmartComponentScopedContainerWithFXWithOptimizedAppearEffect, { __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, animate: animation, className: "framer-1rrg37w-container", "data-framer-appear-id": "1rrg37w", initial: animation1, layoutDependency, layoutId: "Navigation__yw5SSeOvO-container", nodeId: "yw5SSeOvO", optimized: true, rendersWithMotion: true, scopeId: "mni7MPPo4", children: /* @__PURE__ */ _jsx12(A36GR14UW_default, { height: "100%", id: "yw5SSeOvO", layoutId: "Navigation__yw5SSeOvO", style: { width: "100%" }, variant: matchVariant4("WFVFttEGq"), width: "100%" }) }) })] }) }) }) });
});
var css20 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-19h5b.framer-1a0sc2w, .framer-19h5b .framer-1a0sc2w { display: block; }", ".framer-19h5b.framer-6kxzqg { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: center; overflow: visible; padding: 0px 0px 16px 0px; position: relative; width: 100%; }", ".framer-19h5b .framer-14qau0h { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: 30px; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-19h5b .framer-ryjkhe, .framer-19h5b .framer-121ii9o, .framer-19h5b .framer-41adv3 { align-content: center; align-items: center; cursor: pointer; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: 100%; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 1px; }", ".framer-19h5b .framer-7ia1zw, .framer-19h5b .framer-1v3a361, .framer-19h5b .framer-196tue4 { -webkit-user-select: none; flex: none; height: auto; position: relative; user-select: none; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; z-index: 1; }", ".framer-19h5b .framer-10v6rmq { bottom: 2px; flex: none; left: 2px; overflow: var(--overflow-clip-fallback, clip); position: absolute; top: 2px; width: 32%; will-change: var(--framer-will-change-override, transform); z-index: 0; }", ".framer-19h5b .framer-lr7nki-container, .framer-19h5b .framer-e1luvl-container, .framer-19h5b .framer-1rrg37w-container { flex: none; height: auto; position: relative; width: 100%; }", ".framer-19h5b.framer-v-15tvka2 .framer-10v6rmq { left: calc(50.00000000000002% - 32% / 2); }", ".framer-19h5b.framer-v-17qkbf2 .framer-10v6rmq { left: unset; right: 2px; }", ...css];
var Framermni7MPPo4 = withCSS12(Component12, css20, "framer-19h5b");
var mni7MPPo4_default = Framermni7MPPo4;
Framermni7MPPo4.displayName = "Phone Menu Content";
Framermni7MPPo4.defaultProps = { height: 282.5, width: 200 };
addPropertyControls11(Framermni7MPPo4, { variant: { options: ["W6ngOY_l_", "vjhASul2Q", "xbJiSS4kK"], optionTitles: ["Shop", "About", "Stores"], title: "Variant", type: ControlType11.Enum } });
addFonts10(Framermni7MPPo4, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...ShopDropdownFonts, ...AboutDropdownFonts, ...StoreDropdownFonts, ...getFontsFromSharedStyle8(fonts)], { supportsExplicitInterCodegen: true });
Framermni7MPPo4.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader4(o_lEGaEg0_default, {}, context), forwardLoader4(lRoz_3Oi8_default, {}, context), forwardLoader4(A36GR14UW_default, {}, context)]);
} };

// http-url:https://framerusercontent.com/modules/iHHfZVT7vYl7zYFJczGc/95B5lwRhZ35QWArdIoHO/pz6ecTfU2.js
var SquareBlackFonts2 = getFonts5(alWRNtbeL_default);
var PhoneMenuTriggerFonts = getFonts5(MdkITL0hO_default);
var AboutDropdownFonts2 = getFonts5(lRoz_3Oi8_default);
var SmartComponentScopedContainerWithFXWithOptimizedAppearEffect2 = withOptimizedAppearEffect2(withFX2(SmartComponentScopedContainer5));
var ShopDropdownFonts2 = getFonts5(o_lEGaEg0_default);
var PhoneMenuContentFonts = getFonts5(mni7MPPo4_default);
var StoreDropdownFonts2 = getFonts5(A36GR14UW_default);
var cycleOrder11 = ["zxiszX7Zi", "gw_OXNVn4", "HFaGFsYXY", "c_cuJV4yq", "LbAkLQa59", "jjCXs9H20"];
var serializationHash11 = "framer-ZbLFP";
var variantClassNames11 = { c_cuJV4yq: "framer-v-1my4xvh", gw_OXNVn4: "framer-v-17nqz2v", HFaGFsYXY: "framer-v-18s0zlf", jjCXs9H20: "framer-v-9s8l5f", LbAkLQa59: "framer-v-eao4bo", zxiszX7Zi: "framer-v-69voxy" };
function addPropertyOverrides11(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition111 = { bounce: 0, delay: 0, duration: 0.4, type: "spring" };
var patchBorderRadiusScaleCorrector16 = patchBorderRadiusScaleCorrector6();
var matchVariant5 = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var transition23 = { bounce: 0, delay: 0, duration: 0.6, type: "spring" };
var animation2 = { opacity: 1, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, transition: transition23, x: 0, y: 0 };
var animation12 = { opacity: 1e-3, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 0 };
var Transition11 = ({ value, children }) => {
  const config = React13.useContext(MotionConfigContext11);
  const transition = value ?? config.transition;
  const contextValue = React13.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx13(MotionConfigContext11.Provider, { value: contextValue, children });
};
var humanReadableVariantMap11 = { "Primary Base": "zxiszX7Zi", "Primary Open 1": "gw_OXNVn4", "Primary Open 2": "HFaGFsYXY", "Primary Open 3": "c_cuJV4yq", "Secondary Base": "LbAkLQa59", "Secondary Open": "jjCXs9H20" };
var Variants11 = motion13.create(React13.Fragment);
var getProps13 = ({ closeOverlay, height, id, width, ...props }) => {
  return { ...props, JSyhpL5fH: closeOverlay ?? props.JSyhpL5fH, variant: humanReadableVariantMap11[props.variant] ?? props.variant ?? "zxiszX7Zi" };
};
var createLayoutDependency11 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component13 = /* @__PURE__ */ React13.forwardRef(function(props, ref) {
  const fallbackRef = useRef11(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React13.useId();
  const { activeLocale, setLocale } = useLocaleInfo11();
  const componentViewport = useComponentViewport11();
  const { style, className: className9, layoutId, variant, JSyhpL5fH, ...restProps } = getProps13(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState11({ cycleOrder: cycleOrder11, defaultVariant: "zxiszX7Zi", ref: refBinding, variant, variantClassNames: variantClassNames11 });
  const layoutDependency = createLayoutDependency11(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback6(baseVariant);
  const onTap15nznkx = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    if (JSyhpL5fH) {
      const res = await JSyhpL5fH(...args);
      if (res === false)
        return false;
    }
  });
  const onMouseLeave1ce10ji = activeVariantCallback(async (...args) => {
    setVariant("zxiszX7Zi");
  });
  const onMouseEntervy9s28 = activeVariantCallback(async (...args) => {
    setVariant("gw_OXNVn4");
  });
  const onMouseEnter1nq4du2 = activeVariantCallback(async (...args) => {
    setVariant("HFaGFsYXY");
  });
  const onMouseEnter1i64me9 = activeVariantCallback(async (...args) => {
    setVariant("c_cuJV4yq");
  });
  const onTap1055xtt = activeVariantCallback(async (...args) => {
    if (JSyhpL5fH) {
      const res = await JSyhpL5fH(...args);
      if (res === false)
        return false;
    }
  });
  const vKtJHm_WC1ce10ji = activeVariantCallback(async (...args) => {
    setVariant("zxiszX7Zi");
  });
  const wdTSPFeS21ce10ji = activeVariantCallback(async (...args) => {
    setVariant("zxiszX7Zi");
  });
  const gL5KEwxuC1ce10ji = activeVariantCallback(async (...args) => {
    setVariant("zxiszX7Zi");
  });
  const sharedStyleClassNames = [className, className2];
  const scopingClassNames = cx13(serializationHash11, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (["LbAkLQa59", "jjCXs9H20"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed1 = () => {
    if (["gw_OXNVn4", "HFaGFsYXY", "c_cuJV4yq", "LbAkLQa59", "jjCXs9H20"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed2 = () => {
    if (["LbAkLQa59", "jjCXs9H20"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed3 = () => {
    if (["gw_OXNVn4", "HFaGFsYXY", "c_cuJV4yq", "jjCXs9H20"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed4 = () => {
    if (baseVariant === "HFaGFsYXY")
      return true;
    return false;
  };
  const isDisplayed5 = () => {
    if (["HFaGFsYXY", "c_cuJV4yq", "jjCXs9H20"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed6 = () => {
    if (baseVariant === "jjCXs9H20")
      return true;
    return false;
  };
  const isDisplayed7 = () => {
    if (baseVariant === "c_cuJV4yq")
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx13(LayoutGroup11, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx13(Variants11, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx13(Transition11, { value: transition111, children: /* @__PURE__ */ _jsx13(motion13.nav, { ...restProps, ...gestureHandlers, className: cx13(scopingClassNames, "framer-69voxy", className9, classNames), "data-framer-name": "Primary Base", "data-highlight": true, layoutDependency, layoutId: "Navigation__zxiszX7Zi", onTap: onTap15nznkx, ref: refBinding, style: { ...style }, ...addPropertyOverrides11({ c_cuJV4yq: { "data-framer-name": "Primary Open 3" }, gw_OXNVn4: { "data-framer-name": "Primary Open 1" }, HFaGFsYXY: { "data-framer-name": "Primary Open 2" }, jjCXs9H20: { "data-framer-name": "Secondary Open", "data-highlight": void 0, onTap: void 0 }, LbAkLQa59: { "data-framer-name": "Secondary Base" } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsxs10(motion13.div, { className: "framer-bym51b", "data-border": true, "data-framer-name": "Content", layoutDependency, layoutId: "Navigation__UJPEiizgl", style: { "--border-bottom-width": "1px", "--border-color": "var(--token-914b1e49-c6dc-49fc-93ac-369519474e4f, rgb(227, 227, 227))", "--border-left-width": "1px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "1px", "--corner-shape-fallback": 0.796, backdropFilter: "blur(40px)", backgroundColor: "var(--token-9039c660-569a-421b-a527-9ac056ae9951, rgb(255, 255, 255))", borderBottomLeftRadius: "calc(36px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(36px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(36px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(36px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", boxShadow: "0px 1px 6px 0px rgba(0, 0, 0, 0.03)", cornerShape: "superellipse(1.4)", WebkitBackdropFilter: "blur(40px)" }, variants: { jjCXs9H20: { borderBottomLeftRadius: "calc(28px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderBottomRightRadius: "calc(28px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopLeftRadius: "calc(28px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))", borderTopRightRadius: "calc(28px*var(--one-if-corner-shape-supported,var(--corner-shape-fallback,1)))" } }, ...addPropertyOverrides11({ c_cuJV4yq: { "data-highlight": true, onMouseLeave: onMouseLeave1ce10ji }, gw_OXNVn4: { "data-highlight": true, onMouseLeave: onMouseLeave1ce10ji }, HFaGFsYXY: { "data-highlight": true, onMouseLeave: onMouseLeave1ce10ji } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs10(motion13.div, { className: "framer-1rbb9bx", "data-framer-name": "Navbar", "data-highlight": true, layoutDependency, layoutId: "Navigation__hkJEx4d9D", onMouseLeave: onMouseLeave1ce10ji, ...addPropertyOverrides11({ c_cuJV4yq: { onMouseEnter: onMouseEnter1i64me9 }, gw_OXNVn4: { onMouseEnter: onMouseEntervy9s28 }, HFaGFsYXY: { onMouseEnter: onMouseEnter1nq4du2 }, jjCXs9H20: { "data-highlight": void 0, onMouseLeave: void 0 }, LbAkLQa59: { "data-highlight": void 0, onMouseLeave: void 0 } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx13(Link5, { href: { webPageId: "augiA20Il" }, motionChild: true, nodeId: "vbDsUk54h", openInNewTab: false, scopeId: "pz6ecTfU2", children: /* @__PURE__ */ _jsx13(motion13.a, { "aria-label": "Home Page", className: "framer-182dufq framer-892597", "data-framer-name": "Logo", draggable: "false", layoutDependency, layoutId: "Navigation__vbDsUk54h", children: /* @__PURE__ */ _jsx13(alWRNtbeL_default, { animated: true, className: "framer-115kfwi", layoutDependency, layoutId: "Navigation__Xn7jIyFta" }) }) }), isDisplayed() && /* @__PURE__ */ _jsxs10(motion13.div, { className: "framer-ccrmgb", "data-framer-name": "Links", layoutDependency, layoutId: "Navigation__F87QerHBd", children: [/* @__PURE__ */ _jsx13(RichText9, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx13(React13.Fragment, { children: /* @__PURE__ */ _jsx13(motion13.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", children: /* @__PURE__ */ _jsx13(Link5, { href: { webPageId: "YYV2AyPUN" }, motionChild: true, nodeId: "Di7zj5_ga", openInNewTab: false, relValues: [], scopeId: "pz6ecTfU2", smoothScroll: false, children: /* @__PURE__ */ _jsx13(motion13.a, { className: "framer-styles-preset-1eqj9u", "data-styles-preset": "QawiXOoTj", children: "Shop" }) }) }) }), className: "framer-j5sndk", "data-framer-name": "Link", "data-highlight": true, fonts: ["Inter"], layoutDependency, layoutId: "Navigation__Di7zj5_ga", onMouseEnter: onMouseEntervy9s28, style: { "--framer-paragraph-spacing": "0px", opacity: 1 }, variants: { c_cuJV4yq: { opacity: 0.5 }, HFaGFsYXY: { opacity: 0.5 } }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx13(RichText9, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx13(React13.Fragment, { children: /* @__PURE__ */ _jsx13(motion13.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", children: /* @__PURE__ */ _jsx13(Link5, { href: { webPageId: "K4poKvWOC" }, motionChild: true, nodeId: "Zj5h_JZlt", openInNewTab: false, relValues: [], scopeId: "pz6ecTfU2", smoothScroll: false, children: /* @__PURE__ */ _jsx13(motion13.a, { className: "framer-styles-preset-1eqj9u", "data-styles-preset": "QawiXOoTj", children: "About" }) }) }) }), className: "framer-1qiy5zp", "data-framer-name": "Link", "data-highlight": true, fonts: ["Inter"], layoutDependency, layoutId: "Navigation__Zj5h_JZlt", onMouseEnter: onMouseEnter1nq4du2, style: { "--framer-paragraph-spacing": "0px", opacity: 1 }, variants: { c_cuJV4yq: { opacity: 0.5 }, gw_OXNVn4: { opacity: 0.5 }, HFaGFsYXY: { opacity: 1 } }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx13(RichText9, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx13(React13.Fragment, { children: /* @__PURE__ */ _jsx13(motion13.p, { className: "framer-styles-preset-10suf4d", "data-styles-preset": "kw43ePOKN", dir: "auto", children: /* @__PURE__ */ _jsx13(Link5, { href: { webPageId: "duGnOs2MS" }, motionChild: true, nodeId: "We_HSygRR", openInNewTab: false, relValues: [], scopeId: "pz6ecTfU2", smoothScroll: false, children: /* @__PURE__ */ _jsx13(motion13.a, { className: "framer-styles-preset-1eqj9u", "data-styles-preset": "QawiXOoTj", children: "Stores" }) }) }) }), className: "framer-sb7a7p", "data-framer-name": "Link", "data-highlight": true, fonts: ["Inter"], layoutDependency, layoutId: "Navigation__We_HSygRR", onMouseEnter: onMouseEnter1i64me9, style: { "--framer-paragraph-spacing": "0px", opacity: 1 }, variants: { c_cuJV4yq: { opacity: 1 }, gw_OXNVn4: { opacity: 0.5 }, HFaGFsYXY: { opacity: 0.5 } }, verticalAlignment: "top", withExternalLayout: true })] }), isDisplayed1() && /* @__PURE__ */ _jsx13(motion13.button, { "aria-label": "Phone Menu Button", className: "framer-ysqbm4", "data-framer-name": "Menu Button", "data-reset": "button", layoutDependency, layoutId: "Navigation__j_mRMc5pr", ...addPropertyOverrides11({ jjCXs9H20: { "data-highlight": true, onTap: onTap1055xtt } }, baseVariant, gestureVariant), children: isDisplayed2() && /* @__PURE__ */ _jsx13(ComponentViewportProvider5, { ...addPropertyOverrides11({ jjCXs9H20: { height: 18, y: (componentViewport?.y || 0) + 0 + 0 + 0 + 13 + 0 }, LbAkLQa59: { height: 18, y: (componentViewport?.y || 0) + 0 + 0 + 0 + 13 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx13(SmartComponentScopedContainer5, { className: "framer-6vo9d9-container", layoutDependency, layoutId: "Navigation__CqXDjafYP-container", nodeId: "CqXDjafYP", rendersWithMotion: true, scopeId: "pz6ecTfU2", children: /* @__PURE__ */ _jsx13(MdkITL0hO_default, { height: "100%", id: "CqXDjafYP", layoutId: "Navigation__CqXDjafYP", variant: matchVariant5("y3jfTuSAY"), width: "100%", ...addPropertyOverrides11({ jjCXs9H20: { variant: matchVariant5("Rksq9LVn5") } }, baseVariant, gestureVariant) }) }) }) })] }), isDisplayed3() && /* @__PURE__ */ _jsxs10(motion13.div, { className: "framer-1hv329u", "data-framer-name": "Display Content", "data-highlight": true, layoutDependency, layoutId: "Navigation__NZolsONos", onMouseLeave: onMouseLeave1ce10ji, ...addPropertyOverrides11({ c_cuJV4yq: { onMouseEnter: onMouseEnter1i64me9 }, gw_OXNVn4: { onMouseEnter: onMouseEntervy9s28 }, HFaGFsYXY: { onMouseEnter: onMouseEnter1nq4du2 }, jjCXs9H20: { "data-highlight": void 0, onMouseLeave: void 0 } }, baseVariant, gestureVariant), children: [isDisplayed4() && /* @__PURE__ */ _jsx13(ComponentViewportProvider5, { ...addPropertyOverrides11({ HFaGFsYXY: { height: 242, width: "356px", y: (componentViewport?.y || 0) + 0 + 0 + 52 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx13(SmartComponentScopedContainerWithFXWithOptimizedAppearEffect2, { __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, animate: animation2, className: "framer-18fuexn-container", "data-framer-appear-id": "18fuexn", draggable: "false", initial: animation12, layoutDependency, layoutId: "Navigation__XywHtwpV3-container", nodeId: "XywHtwpV3", optimized: true, rendersWithMotion: true, scopeId: "pz6ecTfU2", children: /* @__PURE__ */ _jsx13(lRoz_3Oi8_default, { height: "100%", id: "XywHtwpV3", layoutId: "Navigation__XywHtwpV3", style: { width: "100%" }, variant: matchVariant5("VTyYzhEwj"), vKtJHm_WC: vKtJHm_WC1ce10ji, width: "100%" }) }) }), isDisplayed5() && /* @__PURE__ */ _jsx13(ComponentViewportProvider5, { height: 423, ...addPropertyOverrides11({ gw_OXNVn4: { height: 300, width: "356px", y: (componentViewport?.y || 0) + 0 + 0 + 52 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx13(SmartComponentScopedContainerWithFXWithOptimizedAppearEffect2, { __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, animate: animation2, className: "framer-12rdn9q-container", "data-framer-appear-id": "12rdn9q", draggable: "false", initial: animation12, layoutDependency, layoutId: "Navigation__xeQor4fOt-container", nodeId: "xeQor4fOt", optimized: true, rendersWithMotion: true, scopeId: "pz6ecTfU2", children: /* @__PURE__ */ _jsx13(o_lEGaEg0_default, { height: "100%", id: "xeQor4fOt", layoutId: "Navigation__xeQor4fOt", style: { height: "100%", width: "100%" }, variant: matchVariant5("nkpDO0rw3"), wdTSPFeS2: wdTSPFeS21ce10ji, width: "100%", ...addPropertyOverrides11({ gw_OXNVn4: { style: { width: "100%" } } }, baseVariant, gestureVariant) }) }) }), isDisplayed6() && /* @__PURE__ */ _jsx13(ComponentViewportProvider5, { ...addPropertyOverrides11({ jjCXs9H20: { height: 282, width: `max(max(${componentViewport?.width || "100vw"}, 1px) - 40px, 1px)`, y: (componentViewport?.y || 0) + 0 + 0 + 48 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx13(SmartComponentScopedContainer5, { className: "framer-wxv83u-container", draggable: "false", layoutDependency, layoutId: "Navigation__Qx9Y6Ozed-container", nodeId: "Qx9Y6Ozed", rendersWithMotion: true, scopeId: "pz6ecTfU2", children: /* @__PURE__ */ _jsx13(mni7MPPo4_default, { height: "100%", id: "Qx9Y6Ozed", layoutId: "Navigation__Qx9Y6Ozed", style: { width: "100%" }, variant: matchVariant5("W6ngOY_l_"), width: "100%" }) }) }), isDisplayed7() && /* @__PURE__ */ _jsx13(ComponentViewportProvider5, { ...addPropertyOverrides11({ c_cuJV4yq: { height: 300, width: "356px", y: (componentViewport?.y || 0) + 0 + 0 + 52 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx13(SmartComponentScopedContainerWithFXWithOptimizedAppearEffect2, { __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, animate: animation2, className: "framer-1oqlfb1-container", "data-framer-appear-id": "1oqlfb1", draggable: "false", initial: animation12, layoutDependency, layoutId: "Navigation__xgQHOUOl0-container", nodeId: "xgQHOUOl0", optimized: true, rendersWithMotion: true, scopeId: "pz6ecTfU2", children: /* @__PURE__ */ _jsx13(A36GR14UW_default, { gL5KEwxuC: gL5KEwxuC1ce10ji, height: "100%", id: "xgQHOUOl0", layoutId: "Navigation__xgQHOUOl0", style: { width: "100%" }, variant: matchVariant5("f_Ov0WwU2"), width: "100%" }) }) })] })] }) }) }) }) });
});
var css21 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-ZbLFP.framer-892597, .framer-ZbLFP .framer-892597 { display: block; }", ".framer-ZbLFP.framer-69voxy { align-content: flex-start; align-items: flex-start; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: min-content; }", ".framer-ZbLFP .framer-bym51b { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; overflow: hidden; padding: 0px 20px 0px 24px; position: relative; width: min-content; will-change: var(--framer-will-change-override, transform); }", ".framer-ZbLFP .framer-1rbb9bx { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 14px; height: min-content; justify-content: center; overflow: visible; padding: 12px 0px 12px 0px; position: relative; width: min-content; }", ".framer-ZbLFP .framer-182dufq { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; text-decoration: none; width: min-content; }", ".framer-ZbLFP .framer-115kfwi { aspect-ratio: 1 / 1; flex: none; height: var(--framer-aspect-ratio-supported, 16px); position: relative; width: 16px; }", ".framer-ZbLFP .framer-ccrmgb { align-content: center; align-items: center; align-self: stretch; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: auto; justify-content: center; overflow: visible; padding: 0px 0px 0px 6px; position: relative; width: min-content; }", ".framer-ZbLFP .framer-j5sndk, .framer-ZbLFP .framer-1qiy5zp, .framer-ZbLFP .framer-sb7a7p { --framer-custom-cursors: pointer; flex: none; height: auto; position: relative; white-space: pre; width: auto; z-index: 1; }", ".framer-ZbLFP .framer-ysqbm4 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; min-height: 16px; min-width: 24px; overflow: visible; padding: 0px 0px 0px 8px; position: relative; width: min-content; }", ".framer-ZbLFP .framer-6vo9d9-container { flex: none; height: auto; position: relative; width: auto; }", ".framer-ZbLFP .framer-1hv329u { align-content: center; align-items: center; align-self: stretch; display: flex; flex: 1 0 0px; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: 1px; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: auto; }", ".framer-ZbLFP .framer-18fuexn-container, .framer-ZbLFP .framer-wxv83u-container, .framer-ZbLFP .framer-1oqlfb1-container { flex: 1 0 0px; height: auto; position: relative; width: 1px; }", ".framer-ZbLFP .framer-12rdn9q-container { flex: 1 0 0px; height: 423px; position: relative; width: 1px; }", ".framer-ZbLFP.framer-v-17nqz2v .framer-bym51b, .framer-ZbLFP.framer-v-18s0zlf .framer-bym51b, .framer-ZbLFP.framer-v-1my4xvh .framer-bym51b { padding: 0px 20px 24px 24px; width: 400px; }", ".framer-ZbLFP.framer-v-17nqz2v .framer-1rbb9bx, .framer-ZbLFP.framer-v-18s0zlf .framer-1rbb9bx, .framer-ZbLFP.framer-v-1my4xvh .framer-1rbb9bx { gap: unset; justify-content: space-between; padding: 24px 0px 12px 0px; width: 100%; }", ".framer-ZbLFP.framer-v-17nqz2v .framer-1hv329u, .framer-ZbLFP.framer-v-18s0zlf .framer-1hv329u, .framer-ZbLFP.framer-v-1my4xvh .framer-1hv329u, .framer-ZbLFP.framer-v-9s8l5f .framer-1hv329u { align-self: unset; flex: none; height: min-content; width: 100%; }", ".framer-ZbLFP.framer-v-17nqz2v .framer-12rdn9q-container { height: auto; order: 0; }", ".framer-ZbLFP.framer-v-18s0zlf .framer-18fuexn-container { order: 1; }", ".framer-ZbLFP.framer-v-1my4xvh .framer-1oqlfb1-container { order: 2; }", ".framer-ZbLFP.framer-v-eao4bo.framer-69voxy { width: 100%; }", ".framer-ZbLFP.framer-v-eao4bo .framer-bym51b, .framer-ZbLFP.framer-v-9s8l5f .framer-bym51b { flex: 1 0 0px; gap: 4px; padding: 0px 20px 0px 20px; width: 1px; }", ".framer-ZbLFP.framer-v-eao4bo .framer-1rbb9bx, .framer-ZbLFP.framer-v-9s8l5f .framer-1rbb9bx { gap: unset; height: 44px; justify-content: space-between; width: 100%; }", ".framer-ZbLFP.framer-v-eao4bo .framer-ysqbm4 { min-height: unset; min-width: unset; padding: 0px; }", ".framer-ZbLFP.framer-v-9s8l5f.framer-69voxy { cursor: unset; width: 100%; }", ".framer-ZbLFP.framer-v-9s8l5f .framer-ysqbm4 { cursor: pointer; min-height: unset; min-width: unset; padding: 0px; }", ...css, ...css2, '.framer-ZbLFP[data-border="true"]::after, .framer-ZbLFP [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var Framerpz6ecTfU2 = withCSS13(Component13, css21, "framer-ZbLFP");
var pz6ecTfU2_default = Framerpz6ecTfU2;
Framerpz6ecTfU2.displayName = "Navigation";
Framerpz6ecTfU2.defaultProps = { height: 40, width: 206 };
addPropertyControls12(Framerpz6ecTfU2, { variant: { options: ["zxiszX7Zi", "gw_OXNVn4", "HFaGFsYXY", "c_cuJV4yq", "LbAkLQa59", "jjCXs9H20"], optionTitles: ["Primary Base", "Primary Open 1", "Primary Open 2", "Primary Open 3", "Secondary Base", "Secondary Open"], title: "Variant", type: ControlType12.Enum }, JSyhpL5fH: { title: "Close Overlay", type: ControlType12.EventHandler } });
addFonts11(Framerpz6ecTfU2, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...SquareBlackFonts2, ...PhoneMenuTriggerFonts, ...AboutDropdownFonts2, ...ShopDropdownFonts2, ...PhoneMenuContentFonts, ...StoreDropdownFonts2, ...getFontsFromSharedStyle9(fonts), ...getFontsFromSharedStyle9(fonts2)], { supportsExplicitInterCodegen: true });
Framerpz6ecTfU2.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader5(MdkITL0hO_default, {}, context), forwardLoader5(lRoz_3Oi8_default, {}, context), forwardLoader5(o_lEGaEg0_default, {}, context), forwardLoader5(mni7MPPo4_default, {}, context), forwardLoader5(A36GR14UW_default, {}, context)]);
} };
var __FramerMetadata__2 = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "Framerpz6ecTfU2", "slots": [], "annotations": { "framerDisplayContentsDiv": "false", "framerComponentViewportWidth": "true", "framerAutoSizeImages": "true", "framerIntrinsicWidth": "206", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"gw_OXNVn4":{"layout":["auto","auto"]},"HFaGFsYXY":{"layout":["auto","auto"]},"c_cuJV4yq":{"layout":["auto","auto"]},"LbAkLQa59":{"layout":["fixed","auto"]},"jjCXs9H20":{"layout":["fixed","auto"]}}}', "framerContractVersion": "1", "framerColorSyntax": "true", "framerIntrinsicHeight": "40", "framerImmutableVariables": "true", "framerVariables": '{"JSyhpL5fH":"closeOverlay"}' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__2 as __FramerMetadata__,
  pz6ecTfU2_default as default
};
