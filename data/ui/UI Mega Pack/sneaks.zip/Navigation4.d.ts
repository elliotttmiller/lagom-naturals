export interface Navigation4Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Primary Base" → zxiszX7Zi
   *   "Primary Open 1" → gw_OXNVn4
   *   "Primary Open 2" → HFaGFsYXY
   *   "Primary Open 3" → c_cuJV4yq
   *   "Secondary Base" → LbAkLQa59
   *   "Secondary Open" → jjCXs9H20
   */
  variant?: 'Primary Base' | 'Primary Open 1' | 'Primary Open 2' | 'Primary Open 3' | 'Secondary Base' | 'Secondary Open' | 'zxiszX7Zi' | 'gw_OXNVn4' | 'HFaGFsYXY' | 'c_cuJV4yq' | 'LbAkLQa59' | 'jjCXs9H20';
  /**
   * Close Overlay — pass as `JSyhpL5fH` not `closeOverlay`.
   */
  JSyhpL5fH?: () => void;
  /** Additional properties */
  [key: string]: unknown;
}
