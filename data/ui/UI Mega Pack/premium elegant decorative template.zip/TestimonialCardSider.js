var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/cblIXoSnhoATvq07X7J8/XAfQJSlKQGVl35Pz9G02/pDMsYOr9i.js
import { jsx as _jsx3 } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls3, ComponentViewportProvider, ControlType as ControlType3, cx as cx2, forwardLoader, getFonts, SmartComponentScopedContainer, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS3 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup3, motion as motion3, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React2 from "react";
import { useRef as useRef4 } from "react";

// http-url:https://framerusercontent.com/modules/zvkTOpMSuRzRhLzZZIwG/k4brqe4qK7JYm6JdutDJ/SlideShow.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { resize } from "@motionone/dom";
import { ControlType, RenderTarget, addPropertyControls, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, animate, frame, mix, motion, useInView, useMotionValue, usePageInView, useTransform, wrap } from "framer-motion";
import { Children, cloneElement, memo, startTransition, useCallback as useCallback2, useEffect, useLayoutEffect as useLayoutEffect2, useRef as useRef2, useState } from "react";

// http-url:https://framerusercontent.com/modules/zvkTOpMSuRzRhLzZZIwG/k4brqe4qK7JYm6JdutDJ/use-effect-event
import { useCallback, useLayoutEffect, useRef } from "react";
function useEffectEvent(fn) {
  const ref = useRef(fn);
  useLayoutEffect(() => {
    ref.current = fn;
  });
  return useCallback((...args) => ref.current(...args), []);
}

// http-url:https://framerusercontent.com/modules/zvkTOpMSuRzRhLzZZIwG/k4brqe4qK7JYm6JdutDJ/SlideShow.js
var slideshowClassName = "framer-slideshow";
var slideshowAxisXClassName = "framer-slideshow-axis-x";
var slideshowAxisYClassName = "framer-slideshow-axis-y";
var slideshowDirectionMultiplierVariable = "--framer-dir-multiplier";
var slideshowDirectionMultiplier = `var(${slideshowDirectionMultiplierVariable}, -1)`;
function SlideshowWithoutCSS(props) {
  const { slots = [], startFrom, direction, effectsOptions, autoPlayControl, dragControl, alignment, gap, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft, itemAmount: visibleItemsCount, fadeOptions, intervalControl, transitionControl, arrowOptions, borderRadius, progressOptions, style } = props;
  const { effectsOpacity, effectsScale, effectsRotate, effectsPerspective, effectsHover, playOffscreen } = effectsOptions;
  const { fadeContent, overflow, fadeWidth, fadeInset, fadeAlpha } = fadeOptions;
  const { showMouseControls, arrowSize, arrowRadius, arrowFill, leftArrow, rightArrow, arrowShouldSpace = true, arrowShouldFadeIn = false, arrowPosition, arrowPadding, arrowGap, arrowPaddingTop, arrowPaddingRight, arrowPaddingBottom, arrowPaddingLeft } = arrowOptions;
  const { showProgressDots, dotSize, dotsInset, dotsRadius, dotsPadding, dotsGap, dotsFill, dotsBackground, dotsActiveOpacity, dotsOpacity, dotsBlur } = progressOptions;
  const paddingValue = paddingPerSide ? `${paddingTop}px ${paddingRight}px ${paddingBottom}px ${paddingLeft}px` : `${padding}px`;
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  const filteredSlots = slots.filter(Boolean);
  const totalItemsCount = Children.count(filteredSlots);
  const hasChildren = totalItemsCount > 0;
  if (!hasChildren) {
    return /* @__PURE__ */ _jsxs("section", { style: placeholderStyles, children: [/* @__PURE__ */ _jsx("div", { style: emojiStyles, children: "\u2B50\uFE0F" }), /* @__PURE__ */ _jsx("p", { style: titleStyles, children: "Connect to Content" }), /* @__PURE__ */ _jsx("p", { style: subtitleStyles, children: "Add layers or components to make infinite auto-playing slideshows." })] });
  }
  const parentRef = useRef2(null);
  const parentSizeRef = useRef2(null);
  const parentRefFn = useCallback2((node) => {
    parentRef.current = node;
    if (parentRef.current)
      scheduleMeasure();
  }, []);
  const [size, setSize] = useState({ parent: null, children: null, item: null, itemWidth: null, itemHeight: null, viewportLength: null });
  const isHorizontal = direction === "left" || direction === "right";
  const writingDirection = useWritingDirection();
  const rtlDirectionModifier = isHorizontal && writingDirection === "rtl" ? -1 : 1;
  const [isHovering, setIsHovering] = useState(false);
  const [shouldPlayOnHover, setShouldPlayOnHover] = useState(autoPlayControl);
  const [isMouseDown, setIsMouseDown] = useState(false);
  const isInitialized = size?.item !== null && size?.parent !== null && writingDirection !== null;
  const extraCopyCount = Math.ceil((startFrom + visibleItemsCount) / totalItemsCount);
  let dupedChildren = [];
  let duplicateBy = extraCopyCount * 4;
  if (isCanvas || !isInitialized) {
    duplicateBy = extraCopyCount;
  }
  const [currentItem, setCurrentItem] = useState(startFrom + totalItemsCount);
  useEffect(() => {
    if (!size.item || !writingDirection)
      return;
    const computedNewPosition = -1 * currentItem * ((size.item ?? 0) + gap) * (writingDirection === "rtl" ? -1 : 1);
    if (xOrY.get() !== computedNewPosition) {
      animate(xOrY, computedNewPosition, transitionControl);
    }
  }, [currentItem, size.item, gap, writingDirection]);
  const measure = () => {
    const parentSize = parentSizeRef.current;
    if (!parentSize)
      return;
    const parentWidth = parentSize.width;
    const parentHeight = parentSize.height;
    const parentLength = isHorizontal ? parentWidth : parentHeight;
    const visibleItems = Math.max(1, visibleItemsCount);
    const itemSize = Math.max(0, (parentLength - gap * (visibleItems - 1)) / visibleItems);
    const childrenLength = totalItemsCount * (itemSize + gap);
    const itemWidth = isHorizontal ? itemSize : parentWidth;
    const itemHeight = isHorizontal ? parentHeight : itemSize;
    const viewportLength = isHorizontal ? Math.max(document.documentElement.clientWidth || 0, __dai_window.innerWidth || 0, parentWidth) : Math.max(document.documentElement.clientHeight || 0, __dai_window.innerHeight || 0, parentHeight);
    setSize({ parent: parentLength, children: childrenLength, item: itemSize, itemWidth, itemHeight, viewportLength });
  };
  const scheduleMeasure = useEffectEvent(() => {
    frame.read(measure, false, true);
  });
  useLayoutEffect2(() => {
    scheduleMeasure();
  }, [filteredSlots.length, visibleItemsCount, gap, direction, padding, paddingPerSide, paddingTop, paddingRight, paddingBottom, paddingLeft]);
  useEffect(() => {
    const node = parentRef.current;
    if (!node)
      return;
    return resize(node, ({ size: size2 }) => {
      parentSizeRef.current = size2;
      if (!size2.width || !size2.height)
        return;
      scheduleMeasure();
    });
  }, []);
  const childrenSize = isCanvas ? 0 : size?.children;
  const [isDragging, setIsDragging] = useState(false);
  const visibilityRef = useRef2(null);
  const isInView = useInView(visibilityRef);
  const isVisible = usePageInView() && isInView;
  const xOrY = useMotionValue(childrenSize);
  const wrappedXOrY = !isCanvas ? useTransform(xOrY, (value) => {
    const resolvedChildrenSize = childrenSize ?? 0;
    const resolvedValue = value ?? 0;
    const wrapped = wrap(-resolvedChildrenSize * rtlDirectionModifier, -resolvedChildrenSize * rtlDirectionModifier * 2, resolvedValue);
    return Number.isNaN(wrapped) ? 0 : wrapped;
  }) : useMotionValue(0);
  const wrappedIndex = wrap(0, totalItemsCount, currentItem);
  const setDelta = (delta) => {
    startTransition(() => setCurrentItem((item) => item + delta));
  };
  const setPage = (index) => {
    const currentItemWrapped = wrap(0, totalItemsCount, currentItem);
    const goto = index - currentItemWrapped;
    startTransition(() => setCurrentItem((item) => item + goto));
  };
  const autoplayStep = (direction === "right" || direction === "bottom" ? -1 : 1) * rtlDirectionModifier;
  const canAutoplay = autoPlayControl && shouldPlayOnHover && (playOffscreen || isVisible) && !isCanvas && totalItemsCount > 1 && !isDragging && isInitialized;
  useEffect(() => {
    if (!canAutoplay)
      return;
    const timeoutId = setTimeout(() => {
      setDelta(autoplayStep);
    }, intervalControl * 1e3);
    return () => clearTimeout(timeoutId);
  }, [canAutoplay, autoplayStep, intervalControl, currentItem]);
  const handleDragStart = () => {
    startTransition(() => setIsDragging(true));
  };
  const handleDragEnd = (_event, { offset, velocity }) => {
    startTransition(() => setIsDragging(false));
    const offsetXorY = isHorizontal ? offset.x : offset.y;
    const velocityThreshold = 200;
    const velocityXorY = isHorizontal ? velocity.x : velocity.y;
    const isHalfOfNext = offsetXorY < -size.item / 2;
    const isHalfOfPrev = offsetXorY > size.item / 2;
    const normalizedOffset = Math.abs(offsetXorY);
    const itemDelta = Math.round(normalizedOffset / size.item);
    const itemDeltaFromOne = itemDelta === 0 ? 1 : itemDelta;
    if (velocityXorY > velocityThreshold) {
      setDelta(-itemDeltaFromOne * rtlDirectionModifier);
    } else if (velocityXorY < -velocityThreshold) {
      setDelta(itemDeltaFromOne * rtlDirectionModifier);
    } else {
      if (isHalfOfNext) {
        setDelta(itemDelta * rtlDirectionModifier);
      }
      if (isHalfOfPrev) {
        setDelta(-itemDelta * rtlDirectionModifier);
      }
    }
  };
  const staticStartFrom = Math.max(0, Math.min(startFrom ?? 0, Math.max(0, totalItemsCount - 1)));
  const staticPercentOffset = staticStartFrom * 100 / visibleItemsCount;
  const staticPixelOffset = staticStartFrom * gap / visibleItemsCount;
  let childCounter = 0;
  const columnOrRowValue = `calc(${100 / visibleItemsCount}% - ${gap}px + ${gap / visibleItemsCount}px)`;
  for (let index = 0; index < duplicateBy; index++) {
    dupedChildren = dupedChildren.concat(Children.map(filteredSlots, (child, childIndex) => {
      return /* @__PURE__ */ _jsx(Slide, { slideKey: index + childIndex + "lg", index, width: isHorizontal ? visibleItemsCount > 1 ? columnOrRowValue : "100%" : "100%", height: !isHorizontal ? visibleItemsCount > 1 ? columnOrRowValue : "100%" : "100%", size, child, numChildren: filteredSlots?.length, wrappedXOrY, childCounter: childCounter++, gap, isCanvas, isInitialized, isHorizontal, effectsOpacity, effectsScale, effectsRotate, writingDirection, rtlDirectionModifier, children: index + childIndex }, index + childIndex + "lg");
    }));
  }
  const fadeDirection = isHorizontal ? "to right" : "to bottom";
  const fadeWidthStart = fadeWidth / 2;
  const fadeWidthEnd = 100 - fadeWidth / 2;
  const fadeInsetStart = clamp(fadeInset, 0, fadeWidthStart);
  const fadeInsetEnd = 100 - fadeInset;
  const fadeMask = `linear-gradient(${fadeDirection}, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetStart}%, rgba(0, 0, 0, 1) ${fadeWidthStart}%, rgba(0, 0, 0, 1) ${fadeWidthEnd}%, rgba(0, 0, 0, ${fadeAlpha}) ${fadeInsetEnd}%)`;
  const dots = [];
  const dotsBlurStyle = {};
  if (showProgressDots) {
    for (let i = 0; i < filteredSlots?.length; i++) {
      dots.push(/* @__PURE__ */ _jsx(Dot, { dotStyle: { ...dotStyle, width: dotSize, height: dotSize, backgroundColor: dotsFill }, buttonStyle: baseButtonStyles, selectedOpacity: dotsActiveOpacity, opacity: dotsOpacity, disabled: !isCanvas && !isInitialized, onClick: () => setPage(i), wrappedIndex: isCanvas || !isInitialized ? staticStartFrom : wrappedIndex, total: totalItemsCount, index: i, gap: dotsGap, padding: dotsPadding, isHorizontal }, i));
    }
    if (dotsBlur > 0) {
      dotsBlurStyle.backdropFilter = dotsBlurStyle.WebkitBackdropFilter = `blur(${dotsBlur}px)`;
    }
  }
  const dragProps = isInitialized && dragControl ? { drag: isHorizontal ? "x" : "y", onDragStart: handleDragStart, onDragEnd: handleDragEnd, dragDirectionLock: true, values: { x: xOrY, y: xOrY }, dragMomentum: false } : {};
  const arrowHasTop = arrowPosition === "top-left" || arrowPosition === "top-mid" || arrowPosition === "top-right";
  const arrowHasBottom = arrowPosition === "bottom-left" || arrowPosition === "bottom-mid" || arrowPosition === "bottom-right";
  const arrowHasLeft = arrowPosition === "top-left" || arrowPosition === "bottom-left";
  const arrowHasRight = arrowPosition === "top-right" || arrowPosition === "bottom-right";
  const arrowHasMid = arrowPosition === "top-mid" || arrowPosition === "bottom-mid" || arrowPosition === "auto";
  const leftArrowSrc = leftArrow || "https://framerusercontent.com/images/6tTbkXggWgQCAJ4DO2QEdXXmgM.svg?arrow=left";
  const rightArrowSrc = rightArrow || "https://framerusercontent.com/images/11KSGbIZoRSg4pjdnUoif6MKHI.svg?arrow=right";
  return /* @__PURE__ */ _jsxs("section", { className: `${slideshowClassName} ${isHorizontal ? slideshowAxisXClassName : slideshowAxisYClassName}`, style: { ...containerStyle, padding: paddingValue, WebkitMaskImage: fadeContent ? fadeMask : void 0, maskImage: fadeContent ? fadeMask : void 0, userSelect: "none" }, onMouseEnter: () => {
    setIsHovering(true);
    if (!effectsHover)
      setShouldPlayOnHover(false);
  }, onMouseLeave: () => {
    setIsHovering(false);
    if (!effectsHover)
      setShouldPlayOnHover(true);
  }, onMouseDown: (event) => {
    event.preventDefault();
    startTransition(() => setIsMouseDown(true));
  }, onMouseUp: () => startTransition(() => setIsMouseDown(false)), ref: visibilityRef, children: [/* @__PURE__ */ _jsx("div", { style: { width: "100%", height: "100%", margin: 0, padding: "inherit", position: "absolute", inset: 0, overflow: overflow ? "visible" : "hidden", borderRadius, userSelect: "none", perspective: isCanvas ? "none" : effectsPerspective }, children: /* @__PURE__ */ _jsx(motion.ul, { ref: parentRefFn, ...dragProps, style: { ...containerStyle, gap, placeItems: alignment, ...isCanvas || !isInitialized ? { transform: isHorizontal ? `translateX(calc(${slideshowDirectionMultiplier} * (${staticPercentOffset}% + ${staticPixelOffset}px)))` : `translateY(calc(${slideshowDirectionMultiplier} * (${staticPercentOffset}% + ${staticPixelOffset}px)))` } : { x: isHorizontal ? wrappedXOrY : 0, y: !isHorizontal ? wrappedXOrY : 0 }, flexDirection: isHorizontal ? "row" : "column", transformStyle: effectsRotate !== 0 && !isCanvas ? "preserve-3d" : void 0, cursor: (isCanvas || isInitialized) && dragControl ? isMouseDown ? "grabbing" : "grab" : "auto", userSelect: "none", ...style }, children: dupedChildren }) }), /* @__PURE__ */ _jsxs("fieldset", { style: { ...controlsStyles }, "aria-label": "Slideshow pagination controls", className: "framer--slideshow-controls", children: [/* @__PURE__ */ _jsxs(motion.div, { style: { position: "absolute", display: "flex", flexDirection: isHorizontal ? "row" : "column", justifyContent: arrowShouldSpace ? "space-between" : "center", gap: arrowShouldSpace ? "unset" : arrowGap, opacity: arrowShouldFadeIn || !isCanvas && !isInitialized ? 0 : 1, alignItems: "center", inset: arrowPadding, top: arrowShouldSpace ? arrowPadding : arrowHasTop ? arrowPaddingTop : "unset", left: arrowShouldSpace ? arrowPadding : arrowHasLeft ? arrowPaddingLeft : arrowHasMid ? 0 : "unset", right: arrowShouldSpace ? arrowPadding : arrowHasRight ? arrowPaddingRight : arrowHasMid ? 0 : "unset", bottom: arrowShouldSpace ? arrowPadding : arrowHasBottom ? arrowPaddingBottom : "unset" }, animate: isCanvas || isInitialized ? arrowShouldFadeIn ? { opacity: isHovering ? 1 : 0 } : { opacity: 1 } : { opacity: 0 }, transition: transitionControl, children: [/* @__PURE__ */ _jsx(motion.button, { type: "button", style: { ...baseButtonStyles, backgroundColor: arrowFill, width: arrowSize, height: arrowSize, borderRadius: arrowRadius, rotate: !isHorizontal ? 90 : 0, display: showMouseControls ? "block" : "none", pointerEvents: isCanvas || isInitialized ? "auto" : "none", cursor: isCanvas || isInitialized ? "pointer" : "default" }, disabled: !(isCanvas || isInitialized), onClick: () => setDelta(-1), "aria-label": "Previous", whileTap: { scale: 0.9 }, transition: { duration: 0.15 }, children: /* @__PURE__ */ _jsx("img", { decoding: "async", width: arrowSize, height: arrowSize, src: isHorizontal && writingDirection === "rtl" ? rightArrowSrc : leftArrowSrc, alt: "Back Arrow" }) }), /* @__PURE__ */ _jsx(motion.button, { type: "button", style: { ...baseButtonStyles, backgroundColor: arrowFill, width: arrowSize, height: arrowSize, borderRadius: arrowRadius, rotate: !isHorizontal ? 90 : 0, display: showMouseControls ? "block" : "none", pointerEvents: isCanvas || isInitialized ? "auto" : "none", cursor: isCanvas || isInitialized ? "pointer" : "default" }, disabled: !(isCanvas || isInitialized), onClick: () => setDelta(1), "aria-label": "Next", whileTap: { scale: 0.9 }, transition: { duration: 0.15 }, children: /* @__PURE__ */ _jsx("img", { decoding: "async", width: arrowSize, height: arrowSize, src: isHorizontal && writingDirection === "rtl" ? leftArrowSrc : rightArrowSrc, alt: "Next Arrow" }) })] }), dots.length > 1 ? /* @__PURE__ */ _jsx(motion.div, { style: {
    ...dotsContainerStyle,
    left: isHorizontal ? "50%" : dotsInset,
    top: !isHorizontal ? "50%" : "unset",
    transform: isHorizontal ? "translateX(-50%)" : "translateY(-50%)",
    flexDirection: isHorizontal ? "row" : "column",
    bottom: isHorizontal ? dotsInset : "unset",
    borderRadius: dotsRadius,
    backgroundColor: dotsBackground,
    userSelect: "none",
    ...dotsBlurStyle,
    // Hard-code opacity to 1 on canvas. In SSR, it will be animated from 0 to 1 in `animate`
    opacity: isCanvas ? 1 : 0,
    pointerEvents: isCanvas || isInitialized ? "auto" : "none"
  }, animate: { opacity: isInitialized ? 1 : 0 }, transition: { duration: 0.35, ease: "easeOut" }, children: dots }) : null] })] });
}
var Slideshow = withCSS(SlideshowWithoutCSS, [`.${slideshowAxisXClassName} { ${slideshowDirectionMultiplierVariable}: -1; }`, `html[dir="rtl"] .${slideshowAxisXClassName} { ${slideshowDirectionMultiplierVariable}: 1; }`, `.${slideshowAxisYClassName} { ${slideshowDirectionMultiplierVariable}: -1; }`], "framer-slideshow-component");
var SlideShow_default = Slideshow;
Slideshow.defaultProps = { direction: "left", dragControl: false, startFrom: 0, itemAmount: 1, infinity: true, gap: 10, padding: 10, autoPlayControl: true, effectsOptions: { effectsOpacity: 1, effectsScale: 1, effectsRotate: 0, effectsPerspective: 1200, effectsHover: true, playOffscreen: false }, transitionControl: { type: "spring", stiffness: 200, damping: 40 }, fadeOptions: { fadeContent: false, overflow: false, fadeWidth: 25, fadeAlpha: 0, fadeInset: 0 }, arrowOptions: { showMouseControls: true, arrowShouldFadeIn: false, arrowShouldSpace: true, arrowFill: "rgba(0,0,0,0.2)", arrowSize: 40 }, progressOptions: { showProgressDots: true } };
addPropertyControls(Slideshow, { slots: { type: ControlType.Array, title: "Content", control: { type: ControlType.ComponentInstance } }, direction: {
  type: ControlType.Enum,
  title: "Direction",
  options: ["left", "right", "top", "bottom"],
  // @ts-expect-error Private property
  optionIcons: ["direction-left", "direction-right", "direction-up", "direction-down"],
  optionTitles: ["Left", "Right", "Top", "Bottom"],
  displaySegmentedControl: true,
  defaultValue: Slideshow.defaultProps.direction
}, autoPlayControl: { type: ControlType.Boolean, title: "Auto Play", defaultValue: true }, intervalControl: { type: ControlType.Number, title: "Interval", defaultValue: 1.5, min: 0.5, max: 10, step: 0.1, displayStepper: true, unit: "s", hidden: (props) => !props.autoPlayControl }, dragControl: { type: ControlType.Boolean, title: "Draggable", defaultValue: false }, startFrom: { type: ControlType.Number, title: "Current", min: 0, max: 10, displayStepper: true, defaultValue: Slideshow.defaultProps.startFrom }, effectsOptions: { type: ControlType.Object, title: "Effects", controls: { effectsOpacity: { type: ControlType.Number, title: "Opacity", defaultValue: Slideshow.defaultProps.effectsOptions.effectsOpacity, min: 0, max: 1, step: 0.01, displayStepper: true }, effectsScale: { type: ControlType.Number, title: "Scale", defaultValue: Slideshow.defaultProps.effectsOptions.effectsScale, min: 0, max: 1, step: 0.01, displayStepper: true }, effectsPerspective: { type: ControlType.Number, title: "Perspective", defaultValue: Slideshow.defaultProps.effectsOptions.effectsPerspective, min: 200, max: 2e3, step: 1 }, effectsRotate: { type: ControlType.Number, title: "Rotate", defaultValue: Slideshow.defaultProps.effectsOptions.effectsRotate, min: -180, max: 180, step: 1 }, effectsHover: { type: ControlType.Boolean, title: "On Hover", enabledTitle: "Play", disabledTitle: "Pause", defaultValue: Slideshow.defaultProps.effectsOptions.effectsHover }, playOffscreen: { type: ControlType.Boolean, title: "Offscreen", enabledTitle: "Play", disabledTitle: "Pause", defaultValue: Slideshow.defaultProps.effectsOptions.playOffscreen } } }, alignment: {
  type: ControlType.Enum,
  title: "Align",
  options: ["flex-start", "center", "flex-end"],
  // @ts-expect-error Private property
  optionIcons: { direction: { right: ["align-top", "align-middle", "align-bottom"], left: ["align-top", "align-middle", "align-bottom"], top: ["align-left", "align-center", "align-right"], bottom: ["align-left", "align-center", "align-right"] } },
  defaultValue: "center",
  displaySegmentedControl: true
}, itemAmount: { type: ControlType.Number, title: "Items", min: 1, max: 10, displayStepper: true, defaultValue: Slideshow.defaultProps.itemAmount }, gap: { type: ControlType.Number, title: "Gap", min: 0 }, padding: { title: "Padding", type: ControlType.FusedNumber, toggleKey: "paddingPerSide", toggleTitles: ["Padding", "Padding per side"], defaultValue: 0, valueKeys: ["paddingTop", "paddingRight", "paddingBottom", "paddingLeft"], valueLabels: ["T", "R", "B", "L"], min: 0 }, borderRadius: { type: ControlType.Number, title: "Radius", min: 0, max: 500, displayStepper: true, defaultValue: 0 }, transitionControl: { type: ControlType.Transition, defaultValue: Slideshow.defaultProps.transitionControl, title: "Transition" }, fadeOptions: { type: ControlType.Object, title: "Clipping", controls: { fadeContent: { type: ControlType.Boolean, title: "Fade", defaultValue: false }, overflow: { type: ControlType.Boolean, title: "Overflow", enabledTitle: "Show", disabledTitle: "Hide", defaultValue: false, hidden(props) {
  return props.fadeContent === true;
} }, fadeWidth: { type: ControlType.Number, title: "Width", defaultValue: 25, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeInset: { type: ControlType.Number, title: "Inset", defaultValue: 0, min: 0, max: 100, unit: "%", hidden(props) {
  return props.fadeContent === false;
} }, fadeAlpha: { type: ControlType.Number, title: "Opacity", defaultValue: 0, min: 0, max: 1, step: 0.05, hidden(props) {
  return props.fadeContent === false;
} } } }, arrowOptions: { type: ControlType.Object, title: "Arrows", controls: { showMouseControls: { type: ControlType.Boolean, title: "Show", defaultValue: Slideshow.defaultProps.arrowOptions.showMouseControls }, arrowFill: { type: ControlType.Color, title: "Fill", hidden: (props) => !props.showMouseControls, defaultValue: Slideshow.defaultProps.arrowOptions.arrowFill }, leftArrow: { type: ControlType.Image, title: "Previous", hidden: (props) => !props.showMouseControls }, rightArrow: { type: ControlType.Image, title: "Next", hidden: (props) => !props.showMouseControls }, arrowSize: { type: ControlType.Number, title: "Size", min: 0, max: 200, displayStepper: true, defaultValue: Slideshow.defaultProps.arrowOptions.arrowSize, hidden: (props) => !props.showMouseControls }, arrowRadius: { type: ControlType.Number, title: "Radius", min: 0, max: 500, defaultValue: 40, hidden: (props) => !props.showMouseControls }, arrowShouldFadeIn: { type: ControlType.Boolean, title: "Fade In", defaultValue: false, hidden: (props) => !props.showMouseControls }, arrowShouldSpace: { type: ControlType.Boolean, title: "Distance", enabledTitle: "Space", disabledTitle: "Group", defaultValue: Slideshow.defaultProps.arrowOptions.arrowShouldSpace, hidden: (props) => !props.showMouseControls }, arrowPosition: { type: ControlType.Enum, title: "Position", options: ["auto", "top-left", "top-mid", "top-right", "bottom-left", "bottom-mid", "bottom-right"], optionTitles: ["Center", "Top Left", "Top Middle", "Top Right", "Bottom Left", "Bottom Middle", "Bottom Right"], hidden: (props) => !props.showMouseControls || props.arrowShouldSpace }, arrowPadding: { type: ControlType.Number, title: "Inset", min: -100, max: 100, defaultValue: 20, displayStepper: true, hidden: (props) => !props.showMouseControls || !props.arrowShouldSpace }, arrowPaddingTop: { type: ControlType.Number, title: "Top", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "bottom-mid" || props.arrowPosition === "bottom-left" || props.arrowPosition === "bottom-right" }, arrowPaddingBottom: { type: ControlType.Number, title: "Bottom", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "top-mid" || props.arrowPosition === "top-left" || props.arrowPosition === "top-right" }, arrowPaddingRight: { type: ControlType.Number, title: "Right", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "top-left" || props.arrowPosition === "top-mid" || props.arrowPosition === "bottom-left" || props.arrowPosition === "bottom-mid" }, arrowPaddingLeft: { type: ControlType.Number, title: "Left", min: -500, max: 500, defaultValue: 0, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace || props.arrowPosition === "auto" || props.arrowPosition === "top-right" || props.arrowPosition === "top-mid" || props.arrowPosition === "bottom-right" || props.arrowPosition === "bottom-mid" }, arrowGap: { type: ControlType.Number, title: "Gap", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showMouseControls || props.arrowShouldSpace } } }, progressOptions: { type: ControlType.Object, title: "Dots", controls: { showProgressDots: { type: ControlType.Boolean, title: "Show", defaultValue: false }, dotSize: { type: ControlType.Number, title: "Size", min: 1, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsInset: { type: ControlType.Number, title: "Inset", min: -100, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsGap: { type: ControlType.Number, title: "Gap", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsPadding: { type: ControlType.Number, title: "Padding", min: 0, max: 100, defaultValue: 10, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsFill: { type: ControlType.Color, title: "Fill", defaultValue: "#fff", hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsBackground: { type: ControlType.Color, title: "Backdrop", defaultValue: "rgba(0,0,0,0.2)", hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsRadius: { type: ControlType.Number, title: "Radius", min: 0, max: 200, defaultValue: 50, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsOpacity: { type: ControlType.Number, title: "Opacity", min: 0, max: 1, defaultValue: 0.5, step: 0.1, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsActiveOpacity: { type: ControlType.Number, title: "Current", min: 0, max: 1, defaultValue: 1, step: 0.1, displayStepper: true, hidden: (props) => !props.showProgressDots || props.showScrollbar }, dotsBlur: { type: ControlType.Number, title: "Blur", min: 0, max: 50, defaultValue: 0, step: 1, hidden: (props) => !props.showProgressDots || props.showScrollbar } } } });
var containerStyle = { display: "flex", flexDirection: "row", width: "100%", height: "100%", maxWidth: "100%", maxHeight: "100%", placeItems: "center", margin: 0, padding: 0, listStyleType: "none", textIndent: "none" };
var placeholderStyles = { display: "flex", width: "100%", height: "100%", placeContent: "center", placeItems: "center", flexDirection: "column", color: "#96F", background: "rgba(136, 85, 255, 0.1)", fontSize: 11, overflow: "hidden", padding: "20px 20px 30px 20px" };
var emojiStyles = { fontSize: 32, marginBottom: 10 };
var titleStyles = { margin: 0, marginBottom: 10, fontWeight: 600, textAlign: "center" };
var subtitleStyles = { margin: 0, opacity: 0.7, maxWidth: 180, lineHeight: 1.5, textAlign: "center" };
var baseButtonStyles = { border: "none", display: "flex", placeContent: "center", placeItems: "center", overflow: "hidden", background: "transparent", cursor: "pointer", margin: 0, padding: 0 };
var controlsStyles = { display: "flex", justifyContent: "space-between", alignItems: "center", position: "absolute", pointerEvents: "none", userSelect: "none", top: 0, left: 0, right: 0, bottom: 0, border: 0, padding: 0, margin: 0 };
var clamp = (num, min, max) => Math.min(Math.max(num, min), max);
var Slide = /* @__PURE__ */ memo(function Component(props) {
  const {
    slideKey,
    width,
    height,
    child,
    size,
    gap,
    wrappedXOrY,
    numChildren,
    childCounter,
    isCanvas,
    isInitialized,
    effectsOpacity,
    effectsScale,
    effectsRotate,
    isHorizontal,
    index,
    /** "ltr" or "rtl" */
    writingDirection,
    /** -1 in RTL, 1 in LTR */
    rtlDirectionModifier
  } = props;
  const ref = useRef2(null);
  const itemSize = size?.item ?? 0;
  const parentSize = size?.parent ?? 0;
  const childOffset = (itemSize + gap) * childCounter;
  const scrollRange = (
    // @ivan: this was picked experimentally when fixing semi-working-but-broken RTL
    // implementation in the existing Carousel code. Don’t ask me why these specific values, I’m
    // finding it hard to fully reason about RTL in carousel :/
    (isHorizontal && writingDirection === "rtl" ? [itemSize - gap, 0, -parentSize + itemSize - gap, -parentSize - gap] : [-itemSize, 0, parentSize - itemSize + gap, parentSize]).map((val) => val - childOffset * rtlDirectionModifier)
  );
  const rotateY = !isCanvas && useTransform(
    wrappedXOrY,
    scrollRange,
    // Why flip the rotateY effect when RTL is enabled?
    //
    // Unlike other effects, rotation is vertically symmetrical. Say the user sets a 60 degree rotation.
    // The carousel will look like this:
    //   ) □ ▣ ▤ (
    // where
    // - □ ▣ ▤ are the three slides visible within the carousel,
    // - ) is an out-of-view slide to the left of the viewport,
    // - and ( is an out-of-view slide to the right of the viewport.
    // With 60° rotation, both out-of-view slides look “turned towards” the viewport,
    // which matters for the animation when the slides switch.
    //
    // If a user sets RTL, all items in the carousel will flip around. The carousel, by default, will now look like this:
    //   ( ▤ ▣ □ )
    // Notice how all slides reversed. The slide that was to the left of the viewport: ) – is now to the right of it!
    // And is now turned away from the viewport! So if we don’t flip the rotateY effect, the animation will look off.
    isHorizontal && writingDirection === "rtl" ? [effectsRotate, 0, 0, -effectsRotate] : [-effectsRotate, 0, 0, effectsRotate]
  );
  const rotateX = !isCanvas && useTransform(wrappedXOrY, scrollRange, [effectsRotate, 0, 0, -effectsRotate]);
  const opacity = !isCanvas && useTransform(wrappedXOrY, scrollRange, [effectsOpacity, 1, 1, effectsOpacity]);
  const scale = !isCanvas && useTransform(wrappedXOrY, scrollRange, [effectsScale, 1, 1, effectsScale]);
  const originXorY = !isCanvas && useTransform(
    wrappedXOrY,
    scrollRange,
    // Just like above, because in RTL, the items are flipped vertically, RTL needs a separate treatment
    isHorizontal && writingDirection === "rtl" ? [0, 0, 1, 1] : [1, 1, 0, 0]
  );
  const isVisible = !isCanvas && useTransform(wrappedXOrY, (latest) => {
    const min = Math.min(scrollRange[1], scrollRange[2]);
    const max = Math.max(scrollRange[1], scrollRange[2]);
    return latest >= min && latest <= max;
  });
  useEffect(() => {
    if (!isVisible || !isInitialized)
      return;
    function manageVisibility(visible) {
      const node = ref?.current;
      if (!node)
        return;
      if (visible) {
        node.querySelectorAll("button,a").forEach((el) => {
          const orig = el.dataset.origTabIndex;
          if (orig)
            el.tabIndex = Number(orig);
          else
            el.removeAttribute("tabIndex");
        });
      } else {
        node.querySelectorAll("button,a").forEach((el) => {
          const orig = el.getAttribute("tabIndex");
          if (orig)
            el.dataset.origTabIndex = orig;
          el.tabIndex = -1;
        });
      }
      node.setAttribute("aria-hidden", String(!visible));
    }
    manageVisibility(isVisible.get());
    return isVisible.on("change", (visible) => {
      manageVisibility(visible);
    });
  }, [isInitialized]);
  const visibility = isCanvas ? "visible" : useTransform(wrappedXOrY, [scrollRange[0] - size.viewportLength * rtlDirectionModifier, mix(scrollRange[1], scrollRange[2], 0.5), scrollRange[3] + size.viewportLength * rtlDirectionModifier], ["hidden", "visible", "hidden"]);
  const key = slideKey + "child";
  return /* @__PURE__ */ _jsx(LayoutGroup, { inherit: "id", id: key, children: /* @__PURE__ */ _jsx("li", { style: { display: "contents" }, children: /* @__PURE__ */ cloneElement(child, { ref, key, style: { ...child.props?.style, flexShrink: 0, userSelect: "none", width, height, ...isInitialized ? { opacity, scale, originX: isHorizontal ? originXorY : 0.5, originY: !isHorizontal ? originXorY : 0.5, rotateY: isHorizontal ? rotateY : 0, rotateX: !isHorizontal ? rotateX : 0, visibility } : {} }, layoutId: child.props.layoutId ? child.props.layoutId + "-original-" + index : void 0 }) }) });
});
var Dot = /* @__PURE__ */ memo(function Dot2({ selectedOpacity, opacity, total, index, wrappedIndex, dotStyle: dotStyle2, buttonStyle, gap, padding, isHorizontal, ...props }) {
  const isSelected = wrappedIndex === index;
  const inlinePadding = gap / 2;
  const top = !isHorizontal && index !== 0 ? inlinePadding : padding;
  const bottom = !isHorizontal && index !== total - 1 ? inlinePadding : padding;
  const inlineStart = isHorizontal ? index === 0 ? padding : inlinePadding : padding;
  const inlineEnd = isHorizontal ? index === total - 1 ? padding : inlinePadding : padding;
  return /* @__PURE__ */ _jsx("button", { "aria-label": `Scroll to page ${index + 1}`, type: "button", ...props, style: { ...buttonStyle, paddingTop: top, paddingBottom: bottom, paddingInlineStart: inlineStart, paddingInlineEnd: inlineEnd }, children: /* @__PURE__ */ _jsx(motion.div, { style: { ...dotStyle2 }, initial: false, animate: { opacity: isSelected ? selectedOpacity : opacity }, transition: { duration: 0.3 } }) });
});
var dotsContainerStyle = { display: "flex", placeContent: "center", placeItems: "center", overflow: "hidden", position: "absolute", pointerEvents: "auto" };
var dotStyle = { borderRadius: "50%", background: "white", cursor: "pointer", border: "none", placeContent: "center", placeItems: "center", padding: 0 };
function getWritingDirection() {
  return __dai_window?.document?.documentElement?.dir === "rtl" ? "rtl" : "ltr";
}
function useWritingDirection() {
  const [writingDirection, setWritingDirection] = useState(null);
  useEffect(() => {
    setWritingDirection(getWritingDirection());
    return onWritingDirectionChange(() => {
      setWritingDirection(getWritingDirection());
    });
  }, []);
  return writingDirection;
}
var observer = null;
var callbacks = [];
function onWritingDirectionChange(callback) {
  callbacks.push(callback);
  if (!observer) {
    observer = new MutationObserver(() => callbacks.forEach((callback2) => callback2()));
    observer.observe(document.documentElement, { attributeFilter: ["dir"] });
  }
  return () => {
    callbacks.splice(callbacks.indexOf(callback), 1);
    if (callbacks.length === 0) {
      observer?.disconnect();
      observer = null;
    }
  };
}

// http-url:https://framerusercontent.com/modules/EbvMuMoN50NxZ0MuegtN/ZdOjInABPNQx3OBaIQyB/WodiWDbAg.js
import { jsx as _jsx2, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx, getFontsFromSharedStyle, getLoadingLazyAtYPosition, Image as Image1, RichText, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef as useRef3 } from "react";

// http-url:https://framerusercontent.com/modules/fj0qtiCX0O8ZhCm10hF3/TlJNCSODTluAqYlfFm7k/esFHYYhUL.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["GF;Instrument Sans-600", "Inter-Bold", "Inter-BoldItalic", "Inter-Italic"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Instrument Sans", openType: true, source: "google", style: "normal", uiFamilyName: "Instrument Sans", url: "https://fonts.gstatic.com/s/instrumentsans/v4/pximypc9vsFDm051Uf6KVwgkfoSxQ0GsQv8ToedPibnr-yp2JGEJOH9npSQb_gfwmS0v3_7Y.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/DpPBYI0sL4fYLgAkX8KXOPVt7c.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/4RAEQdEOrcnDkhHiiCbJOw92Lk.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/1K3W8DizY3v4emK8Mb08YHxTbs.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/tUSCtfYVM1I1IchuyCwz9gDdQ.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/VgYFWiwsAC5OYxAycRXXvhze58.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/syRNPWzAMIrcJ3wIlPIP43KjQs.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/GIryZETIX4IFypco5pYZONKhJIo.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/H89BbHkbHDzlxZzxi8uPzTsp90.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/u6gJwDuwB143kpNK1T1MDKDWkMc.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/43sJ6MfOPh1LCJt46OvyDuSbA6o.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/wccHG0r4gBDAIRhfHiOlq6oEkqw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/WZ367JPwf9bRW6LdTHN8rXgSjw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/ia3uin3hQWqDrVloC1zEtYHWw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/2A4Xx7CngadFGlVV4xrO06OBHY.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/CfMzU8w2e7tHgF4T4rATMPuWosA.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/867QObYax8ANsfX4TGEVU9YiCM.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Oyn2ZbENFdnW7mt2Lzjk1h9Zb9k.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/cdAe8hgZ1cMyLu9g005pAW3xMo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/DOfvtmE1UplCq161m6Hj8CSQYg.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/pKRFNWFoZl77qYCAIp84lN1h944.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/tKtBcDnBMevsEEJKdNGhhkLzYo.woff2", weight: "400" }] }];
var css = [`.framer-Odrso .framer-styles-preset-1dcolux:not(.rich-text-wrapper), .framer-Odrso .framer-styles-preset-1dcolux.rich-text-wrapper p { --framer-font-family: "Instrument Sans", "Instrument Sans Placeholder", sans-serif; --framer-font-family-bold: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 20px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 600; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0px; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-25efd653-d718-4f51-8b39-69e985cbd8e4, #413936); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }`];
var className = "framer-Odrso";

// http-url:https://framerusercontent.com/modules/GKXBzTqCj9CY8ZPSzFie/VjEJci0SfW6wDDWAsCvE/FYdthRETO.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["GF;Instrument Sans-700", "Inter-Black", "Inter-BlackItalic", "Inter-BoldItalic"]);
var fonts2 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Instrument Sans", openType: true, source: "google", style: "normal", uiFamilyName: "Instrument Sans", url: "https://fonts.gstatic.com/s/instrumentsans/v4/pximypc9vsFDm051Uf6KVwgkfoSxQ0GsQv8ToedPibnr-yp2JGEJOH9npSQi_gfwmS0v3_7Y.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/mkY5Sgyq51ik0AMrSBwhm9DJg.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/X5hj6qzcHUYv7h1390c8Rhm6550.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/gQhNpS3tN86g8RcVKYUUaKt2oMQ.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/cugnVhSraaRyANCaUtI5FV17wk.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/5HcVoGak8k5agFJSaKa4floXVu0.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/rZ5DdENNqIdFTIyQQiP5isO7M.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/P2Bw01CtL0b9wqygO0sSVogWbo.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/05KsVHGDmqXSBXM4yRZ65P8i0s.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/ky8ovPukK4dJ1Pxq74qGhOqCYI.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/vvNSqIj42qeQ2bvCRBIWKHscrc.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/3ZmXbBKToJifDV9gwcifVd1tEY.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/FNfhX3dt4ChuLJq2PwdlxHO7PU.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/gcnfba68tfm7qAyrWRCf9r34jg.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/efTfQcBJ53kM2pB1hezSZ3RDUFs.woff2", weight: "900" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/H89BbHkbHDzlxZzxi8uPzTsp90.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/u6gJwDuwB143kpNK1T1MDKDWkMc.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/43sJ6MfOPh1LCJt46OvyDuSbA6o.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/wccHG0r4gBDAIRhfHiOlq6oEkqw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/WZ367JPwf9bRW6LdTHN8rXgSjw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/ia3uin3hQWqDrVloC1zEtYHWw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/2A4Xx7CngadFGlVV4xrO06OBHY.woff2", weight: "700" }] }];
var css2 = [`.framer-BWe9A .framer-styles-preset-176d41u:not(.rich-text-wrapper), .framer-BWe9A .framer-styles-preset-176d41u.rich-text-wrapper h3 { --framer-font-family: "Instrument Sans", "Instrument Sans Placeholder", sans-serif; --framer-font-family-bold: "Inter", sans-serif; --framer-font-family-bold-italic: "Inter", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 36px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 700; --framer-font-weight-bold: 900; --framer-font-weight-bold-italic: 900; --framer-font-weight-italic: 700; --framer-letter-spacing: 0px; --framer-line-height: 1.2em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-5373adc8-6cb7-4a8e-b198-69790defc11d, #111111); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }`, `@media (max-width: 1199px) and (min-width: 810px) { .framer-BWe9A .framer-styles-preset-176d41u:not(.rich-text-wrapper), .framer-BWe9A .framer-styles-preset-176d41u.rich-text-wrapper h3 { --framer-font-family: "Instrument Sans", "Instrument Sans Placeholder", sans-serif; --framer-font-family-bold: "Inter", sans-serif; --framer-font-family-bold-italic: "Inter", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 32px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 700; --framer-font-weight-bold: 900; --framer-font-weight-bold-italic: 900; --framer-font-weight-italic: 700; --framer-letter-spacing: 0px; --framer-line-height: 1.2em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-5373adc8-6cb7-4a8e-b198-69790defc11d, #111111); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }`, `@media (max-width: 809px) and (min-width: 0px) { .framer-BWe9A .framer-styles-preset-176d41u:not(.rich-text-wrapper), .framer-BWe9A .framer-styles-preset-176d41u.rich-text-wrapper h3 { --framer-font-family: "Instrument Sans", "Instrument Sans Placeholder", sans-serif; --framer-font-family-bold: "Inter", sans-serif; --framer-font-family-bold-italic: "Inter", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 28px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 700; --framer-font-weight-bold: 900; --framer-font-weight-bold-italic: 900; --framer-font-weight-italic: 700; --framer-letter-spacing: 0px; --framer-line-height: 1.2em; --framer-paragraph-spacing: 40px; --framer-text-alignment: start; --framer-text-color: var(--token-5373adc8-6cb7-4a8e-b198-69790defc11d, #111111); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }`];
var className2 = "framer-BWe9A";

// http-url:https://framerusercontent.com/modules/djjSgC6SZoMfbPvJaU5T/FmfQOcDuDrLMg19mvzbd/h7nPBxYxt.js
import { fontStore as fontStore3 } from "./_framer-runtime.js";
fontStore3.loadFonts(["GF;Instrument Sans-600", "Inter-Bold", "Inter-BoldItalic", "Inter-Italic"]);
var fonts3 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Instrument Sans", openType: true, source: "google", style: "normal", uiFamilyName: "Instrument Sans", url: "https://fonts.gstatic.com/s/instrumentsans/v4/pximypc9vsFDm051Uf6KVwgkfoSxQ0GsQv8ToedPibnr-yp2JGEJOH9npSQb_gfwmS0v3_7Y.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/DpPBYI0sL4fYLgAkX8KXOPVt7c.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/4RAEQdEOrcnDkhHiiCbJOw92Lk.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/1K3W8DizY3v4emK8Mb08YHxTbs.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/tUSCtfYVM1I1IchuyCwz9gDdQ.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/VgYFWiwsAC5OYxAycRXXvhze58.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/syRNPWzAMIrcJ3wIlPIP43KjQs.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/GIryZETIX4IFypco5pYZONKhJIo.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/H89BbHkbHDzlxZzxi8uPzTsp90.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/u6gJwDuwB143kpNK1T1MDKDWkMc.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/43sJ6MfOPh1LCJt46OvyDuSbA6o.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/wccHG0r4gBDAIRhfHiOlq6oEkqw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/WZ367JPwf9bRW6LdTHN8rXgSjw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/ia3uin3hQWqDrVloC1zEtYHWw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/2A4Xx7CngadFGlVV4xrO06OBHY.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/CfMzU8w2e7tHgF4T4rATMPuWosA.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/867QObYax8ANsfX4TGEVU9YiCM.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Oyn2ZbENFdnW7mt2Lzjk1h9Zb9k.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/cdAe8hgZ1cMyLu9g005pAW3xMo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/DOfvtmE1UplCq161m6Hj8CSQYg.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/pKRFNWFoZl77qYCAIp84lN1h944.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/tKtBcDnBMevsEEJKdNGhhkLzYo.woff2", weight: "400" }] }];
var css3 = [`.framer-ACead .framer-styles-preset-uhboii:not(.rich-text-wrapper), .framer-ACead .framer-styles-preset-uhboii.rich-text-wrapper p { --framer-font-family: "Instrument Sans", "Instrument Sans Placeholder", sans-serif; --framer-font-family-bold: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 16px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 600; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0px; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: var(--token-25efd653-d718-4f51-8b39-69e985cbd8e4, #413936); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }`];
var className3 = "framer-ACead";

// http-url:https://framerusercontent.com/modules/EbvMuMoN50NxZ0MuegtN/ZdOjInABPNQx3OBaIQyB/WodiWDbAg.js
var serializationHash = "framer-WucEQ";
var variantClassNames = { FWI1TWZW_: "framer-v-6cpw7v" };
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion2.create(React.Fragment);
var getProps = ({ date, height, id, image, name1, paragraph, width, ...props }) => {
  return { ...props, ipoS6MXY_: paragraph ?? props.ipoS6MXY_ ?? "I really appreciate the design approach at Terion. The space feels engaging and well thought out, making each visit enjoyable. They also offer a wide selection of products across various price points and quality levels.", SIgg1ezz3: name1 ?? props.SIgg1ezz3 ?? "James Rodriguez", vQvt7I7sn: image ?? props.vQvt7I7sn ?? { alt: "Image", pixelHeight: 248, pixelWidth: 248, src: "https://framerusercontent.com/images/3FSOhjUs1NHI8IibJKGaly6ZGc.png?width=248&height=248" }, Z3BXCrukP: date ?? props.Z3BXCrukP ?? "05 Jan, 2026 " };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef3(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className4, layoutId, variant, ipoS6MXY_, vQvt7I7sn, SIgg1ezz3, Z3BXCrukP, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "FWI1TWZW_", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [className2, className, className3];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx2(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs2(motion2.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-6cpw7v", className4, classNames), "data-framer-name": "Default", layoutDependency, layoutId: "TestimonialCardSider__FWI1TWZW_", ref: refBinding, style: { ...style }, children: [/* @__PURE__ */ _jsx2(motion2.div, { className: "framer-l0xlzc", "data-border": true, "data-framer-name": "Title", layoutDependency, layoutId: "TestimonialCardSider__oyIZXVyjx", style: { "--border-bottom-width": "1px", "--border-color": "rgba(0, 0, 0, 0.2)", "--border-left-width": "0px", "--border-right-width": "0px", "--border-style": "solid", "--border-top-width": "0px" }, children: /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.h3, { className: "framer-styles-preset-176d41u", "data-styles-preset": "FYdthRETO", dir: "auto", children: "I really appreciate the design approach at Terion. The space feels engaging and well thought out, making each visit enjoyable. They also offer a wide selection of products across various price points and quality levels." }) }), className: "framer-1szvsra", "data-framer-name": "I really appreciate the design approach at Terion. The space feels engaging and well thought out, making each visit enjoyable. They also offer a wide selection of products across various price points and quality levels.", fonts: ["Inter"], layoutDependency, layoutId: "TestimonialCardSider__Ql0UOBGQT", style: { "--framer-paragraph-spacing": "0px" }, text: ipoS6MXY_, verticalAlignment: "top", withExternalLayout: true }) }), /* @__PURE__ */ _jsxs2(motion2.div, { className: "framer-1oiou49", "data-framer-name": "Author Details", layoutDependency, layoutId: "TestimonialCardSider__RMcYoB81S", children: [/* @__PURE__ */ _jsx2(Image1, { background: { alt: "Image", fit: "fill", intrinsicHeight: 248, intrinsicWidth: 248, loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 0 + (((componentViewport?.height || 354) - 0 - 181.2) / 2 + 83.2 + 36) + 0), pixelHeight: 248, pixelWidth: 248, sizes: "62px", ...toResponsiveImage(vQvt7I7sn) }, className: "framer-1drfftj", "data-framer-name": "Image", layoutDependency, layoutId: "TestimonialCardSider__mXZkphT1i", style: { borderBottomLeftRadius: 50, borderBottomRightRadius: 50, borderTopLeftRadius: 50, borderTopRightRadius: 50 } }), /* @__PURE__ */ _jsxs2(motion2.div, { className: "framer-4a4sxt", "data-framer-name": "Name", layoutDependency, layoutId: "TestimonialCardSider__v56DAKAdJ", children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { className: "framer-styles-preset-1dcolux", "data-styles-preset": "esFHYYhUL", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-5373adc8-6cb7-4a8e-b198-69790defc11d, rgb(17, 17, 17)))" }, children: "James Rodriguez" }) }), className: "framer-1hb1v8m", "data-framer-name": "James Rodriguez", fonts: ["Inter"], layoutDependency, layoutId: "TestimonialCardSider__EFyFopm0N", style: { "--extracted-r6o4lv": "var(--token-5373adc8-6cb7-4a8e-b198-69790defc11d, rgb(17, 17, 17))", "--framer-paragraph-spacing": "0px" }, text: SIgg1ezz3, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { className: "framer-styles-preset-uhboii", "data-styles-preset": "h7nPBxYxt", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-72325b68-042e-43a0-ad27-50a8aa700545, rgb(78, 76, 75)))" }, children: "05 Jan, 2026 " }) }), className: "framer-164qk3i", "data-framer-name": "05 Jan, 2026", fonts: ["Inter"], layoutDependency, layoutId: "TestimonialCardSider__AOthQ5DNy", style: { "--extracted-r6o4lv": "var(--token-72325b68-042e-43a0-ad27-50a8aa700545, rgb(78, 76, 75))", "--framer-paragraph-spacing": "0px" }, text: Z3BXCrukP, verticalAlignment: "top", withExternalLayout: true })] })] })] }) }) }) });
});
var css4 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-WucEQ.framer-px4kpu, .framer-WucEQ .framer-px4kpu { display: block; }", ".framer-WucEQ.framer-6cpw7v { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 36px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-WucEQ .framer-l0xlzc { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px 0px 40px 0px; position: relative; width: 100%; }", ".framer-WucEQ .framer-1szvsra { flex: 1 0 0px; height: auto; position: relative; white-space: pre-wrap; width: 1px; word-break: break-word; word-wrap: break-word; }", ".framer-WucEQ .framer-1oiou49 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 23px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: min-content; }", ".framer-WucEQ .framer-1drfftj { aspect-ratio: 1 / 1; flex: none; gap: 0px; height: var(--framer-aspect-ratio-supported, 62px); overflow: hidden; position: relative; width: 62px; will-change: var(--framer-will-change-override, transform); }", ".framer-WucEQ .framer-4a4sxt { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: min-content; }", ".framer-WucEQ .framer-1hb1v8m, .framer-WucEQ .framer-164qk3i { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ...css2, ...css, ...css3, '.framer-WucEQ[data-border="true"]::after, .framer-WucEQ [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerWodiWDbAg = withCSS2(Component2, css4, "framer-WucEQ");
var WodiWDbAg_default = FramerWodiWDbAg;
FramerWodiWDbAg.displayName = "Testimonial Card";
FramerWodiWDbAg.defaultProps = { height: 354, width: 800 };
addPropertyControls2(FramerWodiWDbAg, { ipoS6MXY_: { defaultValue: "I really appreciate the design approach at Terion. The space feels engaging and well thought out, making each visit enjoyable. They also offer a wide selection of products across various price points and quality levels.", displayTextArea: false, title: "Paragraph+", type: ControlType2.String }, onipoS6MXY_Change: { changes: "ipoS6MXY_", type: ControlType2.ChangeHandler }, vQvt7I7sn: { __defaultAssetReference: "data:framer/asset-reference,3FSOhjUs1NHI8IibJKGaly6ZGc.png?originalFilename=Frame+1948754028.png&width=248&height=248", __vekterDefault: { alt: "Image", assetReference: "data:framer/asset-reference,3FSOhjUs1NHI8IibJKGaly6ZGc.png?originalFilename=Frame+1948754028.png&width=248&height=248" }, title: "Image", type: ControlType2.ResponsiveImage }, SIgg1ezz3: { defaultValue: "James Rodriguez", displayTextArea: false, title: "Name", type: ControlType2.String }, onSIgg1ezz3Change: { changes: "SIgg1ezz3", type: ControlType2.ChangeHandler }, Z3BXCrukP: { defaultValue: "05 Jan, 2026 ", displayTextArea: false, title: "Date", type: ControlType2.String }, onZ3BXCrukPChange: { changes: "Z3BXCrukP", type: ControlType2.ChangeHandler } });
addFonts(FramerWodiWDbAg, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle(fonts2), ...getFontsFromSharedStyle(fonts), ...getFontsFromSharedStyle(fonts3)], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/cblIXoSnhoATvq07X7J8/XAfQJSlKQGVl35Pz9G02/pDMsYOr9i.js
var TestimonialCardFonts = getFonts(WodiWDbAg_default);
var SlideshowFonts = getFonts(SlideShow_default);
var cycleOrder = ["cFGZjCt5s", "moPTzcTQZ", "HyXFaLIf5"];
var serializationHash2 = "framer-DlmAI";
var variantClassNames2 = { cFGZjCt5s: "framer-v-1wum2hb", HyXFaLIf5: "framer-v-t24i1a", moPTzcTQZ: "framer-v-1qtn92v" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition12 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var addImageAlt = (image, alt) => {
  if (!image || typeof image !== "object") {
    return;
  }
  return { ...image, alt };
};
var Transition2 = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext2.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Default: "cFGZjCt5s", Small: "HyXFaLIf5", Tablet: "moPTzcTQZ" };
var Variants2 = motion3.create(React2.Fragment);
var getProps2 = ({ height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "cFGZjCt5s" };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef4(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className: className4, layoutId, variant, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder, defaultVariant: "cFGZjCt5s", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash2, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx3(LayoutGroup3, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition2, { value: transition12, children: /* @__PURE__ */ _jsx3(motion3.div, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-1wum2hb", className4, classNames), "data-framer-name": "Default", layoutDependency, layoutId: "TestimonialCardSider__cFGZjCt5s", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ HyXFaLIf5: { "data-framer-name": "Small" }, moPTzcTQZ: { "data-framer-name": "Tablet" } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx3(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-1hdpcel-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "TestimonialCardSider__xta6RutyX-container", nodeId: "xta6RutyX", rendersWithMotion: true, scopeId: "pDMsYOr9i", children: /* @__PURE__ */ _jsx3(SlideShow_default, { alignment: "center", arrowOptions: { arrowFill: "rgba(0, 0, 0, 0)", arrowGap: 10, arrowPadding: 20, arrowPaddingBottom: 0, arrowPaddingLeft: 0, arrowPaddingRight: 0, arrowPaddingTop: 0, arrowPosition: "bottom-right", arrowRadius: 40, arrowShouldFadeIn: false, arrowShouldSpace: false, arrowSize: 50, leftArrow: "https://framerusercontent.com/images/AkB4B4GxkWa31JZDGPfO2wzmE.svg?width=50&height=50", rightArrow: "https://framerusercontent.com/images/Mc991iZ6RS8VFa0wGBAVQpRHtQ.svg?width=50&height=50", showMouseControls: true }, autoPlayControl: true, borderRadius: 0, direction: "left", dragControl: false, effectsOptions: { effectsHover: true, effectsOpacity: 1, effectsPerspective: 1200, effectsRotate: 0, effectsScale: 1, playOffscreen: false }, fadeOptions: { fadeAlpha: 0, fadeContent: false, fadeInset: 0, fadeWidth: 25, overflow: true }, gap: 10, height: "100%", id: "xta6RutyX", intervalControl: 4, itemAmount: 1, layoutId: "TestimonialCardSider__xta6RutyX", padding: 0, paddingBottom: 0, paddingLeft: 0, paddingPerSide: false, paddingRight: 0, paddingTop: 0, progressOptions: { dotsActiveOpacity: 1, dotsBackground: "rgba(0, 0, 0, 0.2)", dotsBlur: 0, dotsFill: "rgb(255, 255, 255)", dotsGap: 10, dotsInset: 10, dotSize: 10, dotsOpacity: 0.5, dotsPadding: 10, dotsRadius: 50, showProgressDots: false }, slots: [/* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 354, width: "800px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-msgl43-container", inComponentSlot: true, layoutDependency, layoutId: "TestimonialCardSider__MLmk5Kanc-container", nodeId: "MLmk5Kanc", rendersWithMotion: true, scopeId: "pDMsYOr9i", children: /* @__PURE__ */ _jsx3(WodiWDbAg_default, { height: "100%", id: "MLmk5Kanc", ipoS6MXY_: "I really appreciate the design approach at Terion. The space feels engaging and well thought out, making each visit enjoyable. They also offer a wide selection of products across various price points and quality levels.", layoutId: "TestimonialCardSider__MLmk5Kanc", SIgg1ezz3: "James Rodriguez", style: { width: "100%" }, width: "100%", Z3BXCrukP: "05 Jan, 2026 " }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 354, width: "800px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-o1klys-container", inComponentSlot: true, layoutDependency, layoutId: "TestimonialCardSider__xJBLPTS8L-container", nodeId: "xJBLPTS8L", rendersWithMotion: true, scopeId: "pDMsYOr9i", children: /* @__PURE__ */ _jsx3(WodiWDbAg_default, { height: "100%", id: "xJBLPTS8L", ipoS6MXY_: "Working with Terion was an excellent experience from start to finish. Their team carefully listened to our ideas and translated them into a design that perfectly balanced style and functionality. ", layoutId: "TestimonialCardSider__xJBLPTS8L", SIgg1ezz3: "Eoin Morgan", style: { width: "100%" }, vQvt7I7sn: addImageAlt({ pixelHeight: 160, pixelWidth: 160, src: "https://framerusercontent.com/images/UXVbqibK9Jfo53ySo415cXVPb1Y.png?width=160&height=160" }, "Image"), width: "100%", Z3BXCrukP: "21Jan, 2026 " }) }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { height: 354, width: "800px", children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-t01chn-container", inComponentSlot: true, layoutDependency, layoutId: "TestimonialCardSider__RXJnG9kCJ-container", nodeId: "RXJnG9kCJ", rendersWithMotion: true, scopeId: "pDMsYOr9i", children: /* @__PURE__ */ _jsx3(WodiWDbAg_default, { height: "100%", id: "RXJnG9kCJ", ipoS6MXY_: "Terion\u2019s attention to detail and thoughtful design process made a huge difference in our project. They combined creativity with practical solutions to create a space that looks beautiful while remaining highly functional.", layoutId: "TestimonialCardSider__RXJnG9kCJ", SIgg1ezz3: "Stewart Binny", style: { width: "100%" }, vQvt7I7sn: addImageAlt({ pixelHeight: 192, pixelWidth: 192, src: "https://framerusercontent.com/images/vVxSQKt7VUap4IvDjo0mSUyUvHA.png?width=192&height=192" }, "Image"), width: "100%", Z3BXCrukP: "08 Jan, 2026 " }) }) })], startFrom: 0, style: { height: "100%", width: "100%" }, transitionControl: { damping: 40, delay: 0, mass: 1, stiffness: 200, type: "spring" }, width: "100%", ...addPropertyOverrides({ HyXFaLIf5: { arrowOptions: { arrowFill: "rgba(0, 0, 0, 0)", arrowGap: 4, arrowPadding: 20, arrowPaddingBottom: 0, arrowPaddingLeft: 0, arrowPaddingRight: 0, arrowPaddingTop: 0, arrowPosition: "bottom-right", arrowRadius: 40, arrowShouldFadeIn: false, arrowShouldSpace: false, arrowSize: 32, leftArrow: "https://framerusercontent.com/images/AkB4B4GxkWa31JZDGPfO2wzmE.svg?width=50&height=50", rightArrow: "https://framerusercontent.com/images/Mc991iZ6RS8VFa0wGBAVQpRHtQ.svg?width=50&height=50", showMouseControls: true } } }, baseVariant, gestureVariant) }) }) }) }) }) }) });
});
var css5 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-DlmAI.framer-161yqqw, .framer-DlmAI .framer-161yqqw { display: block; }", ".framer-DlmAI.framer-1wum2hb { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-DlmAI .framer-1hdpcel-container { flex: 1 0 0px; height: 354px; position: relative; width: 1px; }", ".framer-DlmAI .framer-msgl43-container, .framer-DlmAI .framer-o1klys-container, .framer-DlmAI .framer-t01chn-container { height: auto; position: relative; width: 800px; }", ".framer-DlmAI.framer-v-1qtn92v.framer-1wum2hb { width: 100%; }", ".framer-DlmAI.framer-v-1qtn92v .framer-1hdpcel-container { height: 410px; }", ".framer-DlmAI.framer-v-t24i1a.framer-1wum2hb { width: 100%; }", ".framer-DlmAI.framer-v-t24i1a .framer-1hdpcel-container { height: 508px; }"];
var FramerpDMsYOr9i = withCSS3(Component3, css5, "framer-DlmAI");
var pDMsYOr9i_default = FramerpDMsYOr9i;
FramerpDMsYOr9i.displayName = "Testimonial Card Sider";
FramerpDMsYOr9i.defaultProps = { height: 354, width: 800 };
addPropertyControls3(FramerpDMsYOr9i, { variant: { options: ["cFGZjCt5s", "moPTzcTQZ", "HyXFaLIf5"], optionTitles: ["Default", "Tablet", "Small"], title: "Variant", type: ControlType3.Enum } });
addFonts2(FramerpDMsYOr9i, [{ explicitInter: true, fonts: [] }, ...TestimonialCardFonts, ...SlideshowFonts], { supportsExplicitInterCodegen: true });
FramerpDMsYOr9i.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader(WodiWDbAg_default, {}, context)]);
} };
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerpDMsYOr9i", "slots": [], "annotations": { "framerAutoSizeImages": "true", "framerComponentViewportWidth": "true", "framerImmutableVariables": "true", "framerIntrinsicHeight": "354", "framerDisplayContentsDiv": "false", "framerContractVersion": "1", "framerIntrinsicWidth": "800", "framerColorSyntax": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"moPTzcTQZ":{"layout":["fixed","auto"]},"HyXFaLIf5":{"layout":["fixed","auto"]}}}' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  pDMsYOr9i_default as default
};
