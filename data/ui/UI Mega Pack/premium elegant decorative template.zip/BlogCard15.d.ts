export interface Blogcard15Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default 02" → zH9oYKCj7
   *   "Default" → i9YdFNDry
   *   "Small" → R28bLJ0H6
   */
  variant?: 'Default 02' | 'Default' | 'Small' | 'i9YdFNDry' | 'zH9oYKCj7' | 'R28bLJ0H6';
  /**
   * Image — pass as `TIsVctDbh` not `image`.
   */
  TIsVctDbh?: string;
  /**
   * Date — pass as `hfgY1Z7jP` not `date`.
   * @default "18 Mar, 2026 "
   */
  hfgY1Z7jP?: string;
  onhfgY1Z7jPChange?: string;
  /**
   * Title — pass as `hl5GVby5G` not `title`.
   * @default "Modern Interior Design Trends."
   */
  hl5GVby5G?: string;
  onhl5GVby5GChange?: string;
  /**
   * Link — pass as `RcedgQPOm` not `link`.
   */
  RcedgQPOm?: string;
  /** Additional properties */
  [key: string]: unknown;
}
