export interface BrandProps {
  /**
   * Gap — pass as `GPJqwmEhv` not `gap`.
   * @default 90
   */
  GPJqwmEhv?: number;
  onGPJqwmEhvChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
