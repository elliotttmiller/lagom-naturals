/**
 * Props for Group62 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Group62Props {
  [key: string]: unknown;
}
