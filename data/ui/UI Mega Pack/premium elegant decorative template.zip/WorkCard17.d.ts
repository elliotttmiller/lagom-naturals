export interface Workcard17Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → myTEn2qVA
   *   "Phone" → JKfG9wSEj
   *   "Tablet" → F0GZFLkPT
   */
  variant?: 'Desktop' | 'Phone' | 'Tablet' | 'myTEn2qVA' | 'F0GZFLkPT' | 'JKfG9wSEj';
  /**
   * Tag — pass as `Tb198vluU` not `tag`.
   * @default "Residential"
   */
  Tb198vluU?: string;
  onTb198vluUChange?: string;
  /**
   * Title — pass as `SeOppPKEW` not `title`.
   * @default "Urban Apartment"
   */
  SeOppPKEW?: string;
  onSeOppPKEWChange?: string;
  /**
   * Image — pass as `b44HmlbQq` not `image`.
   */
  b44HmlbQq?: string;
  /**
   * Cursor — pass as `ard6ejHfU` not `cursor`.
   */
  ard6ejHfU?: string;
  /**
   * Link — pass as `uK_zpH9qW` not `link`.
   */
  uK_zpH9qW?: string;
  /**
   * Scroll Section — pass as `KvoVp1zqO` not `scrollSection`.
   */
  KvoVp1zqO?: string;
  /** Additional properties */
  [key: string]: unknown;
}
