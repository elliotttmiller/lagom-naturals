export interface Hero5Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "About Button" → QF_ONuUr2
   *   "Default" → n5He8PHrj
   */
  variant?: 'About Button' | 'Default' | 'n5He8PHrj' | 'QF_ONuUr2';
  /**
   * Text — pass as `zNamfIhiA` not `text`.
   * @default "View Projects"
   */
  zNamfIhiA?: string;
  onzNamfIhiAChange?: string;
  /**
   * Link — pass as `Ebp9rCKCy` not `link`.
   */
  Ebp9rCKCy?: string;
  /** Additional properties */
  [key: string]: unknown;
}
