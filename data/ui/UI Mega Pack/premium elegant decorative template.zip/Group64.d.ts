/**
 * Props for Group64 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Group64Props {
  [key: string]: unknown;
}
