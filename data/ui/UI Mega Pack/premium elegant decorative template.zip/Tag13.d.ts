export interface Tag13Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default 2" → Uxm4PA9ky
   *   "Default 3" → DhBTjVInJ
   *   "Default" → JnyJ_h5An
   */
  variant?: 'Default 2' | 'Default 3' | 'Default' | 'JnyJ_h5An' | 'Uxm4PA9ky' | 'DhBTjVInJ';
  /**
   * Title — pass as `u1RRFG8eX` not `title`.
   * @default "About Us"
   */
  u1RRFG8eX?: string;
  onu1RRFG8eXChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
