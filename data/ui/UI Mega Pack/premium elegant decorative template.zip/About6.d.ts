export interface About6Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → IlMIWKd18
   *   "Phone" → FnhMhC30a
   *   "Tablet" → jjXkpzAJu
   */
  variant?: 'Desktop' | 'Phone' | 'Tablet' | 'IlMIWKd18' | 'jjXkpzAJu' | 'FnhMhC30a';
  /**
   * Padding — pass as `qf4idnf9w` not `padding`.
   * @default "100px 30px 160px 30px"
   */
  qf4idnf9w?: string;
  /** Additional properties */
  [key: string]: unknown;
}
