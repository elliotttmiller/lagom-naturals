export interface Smoothscrollprod4Props {
  /**
   * Intensity
   * Range: min: 0
   * @default 10
   */
  intensity?: number;
  /** Additional properties */
  [key: string]: unknown;
}
