/**
 * Props for Group65 component
 *
 * Note: Automatic type extraction was not possible for this component.
 * This interface accepts any props.
 */
export interface Group65Props {
  [key: string]: unknown;
}
