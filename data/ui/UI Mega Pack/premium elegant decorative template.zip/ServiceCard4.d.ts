export interface Servicecard4Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default" → m6sngefUr
   *   "Phone" → uhwQANPqI
   *   "Tablet" → FhgPVFVeP
   */
  variant?: 'Default' | 'Phone' | 'Tablet' | 'm6sngefUr' | 'FhgPVFVeP' | 'uhwQANPqI';
  /**
   * Title — pass as `lvP72R2Dd` not `title`.
   * @default "Home Interior Design"
   */
  lvP72R2Dd?: string;
  onlvP72R2DdChange?: string;
  /**
   * Text — pass as `CQmq0Hgrj` not `text`.
   * @default "Thoughtfully designed home interiors that blend comfort, style, and functionality to create a space that truly reflects your lifestyle."
   */
  CQmq0Hgrj?: string;
  onCQmq0HgrjChange?: string;
  /**
   * Image — pass as `t76NUxw4Z` not `image`.
   */
  t76NUxw4Z?: string;
  /**
   * Link — pass as `L7181scUI` not `link`.
   */
  L7181scUI?: string;
  /** Additional properties */
  [key: string]: unknown;
}
