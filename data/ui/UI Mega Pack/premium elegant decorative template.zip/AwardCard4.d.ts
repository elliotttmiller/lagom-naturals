export interface Awardcard4Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default" → G0Ib_2xkc
   *   "Phone" → W7i_Dztd5
   */
  variant?: 'Default' | 'Phone' | 'G0Ib_2xkc' | 'W7i_Dztd5';
  /**
   * Top Line Visible — pass as `L1CW5gPMa` not `topLineVisible`.
   * @default true
   */
  L1CW5gPMa?: boolean;
  onL1CW5gPMaChange?: string;
  /**
   * Title — pass as `u3VFeQAUQ` not `title`.
   * @default "Best Interior Design Award"
   */
  u3VFeQAUQ?: string;
  onu3VFeQAUQChange?: string;
  /**
   * Location — pass as `XvDya_Fbn` not `location`.
   * @default "New York, USA"
   */
  XvDya_Fbn?: string;
  onXvDya_FbnChange?: string;
  /**
   * Date — pass as `sSdnGSIVt` not `date`.
   * @default "02/03/2023"
   */
  sSdnGSIVt?: string;
  onsSdnGSIVtChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
