export interface ProcesstabProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default 01" → M99_wQIjq
   *   "Default 02" → TY5S0ogQS
   *   "Default 03" → zYdw7Dc_o
   *   "Default 04" → zG51337g9
   *   "Phone 01" → DN7FqOrcC
   *   "Phone 02" → Kc2ehkh5B
   *   "Phone 03" → sXPdbHF_W
   *   "Phone 04" → QIMlnLHVZ
   */
  variant?: 'Default 01' | 'Default 02' | 'Default 03' | 'Default 04' | 'Phone 01' | 'Phone 02' | 'Phone 03' | 'Phone 04' | 'M99_wQIjq' | 'TY5S0ogQS' | 'zYdw7Dc_o' | 'zG51337g9' | 'DN7FqOrcC' | 'Kc2ehkh5B' | 'sXPdbHF_W' | 'QIMlnLHVZ';
  /**
   * Image 01 — pass as `Qq9nc5zpM` not `image01`.
   */
  Qq9nc5zpM?: string;
  /**
   * Image 02 — pass as `yacgg5jkg` not `image02`.
   */
  yacgg5jkg?: string;
  /**
   * Image 03 — pass as `QEAfWNHa3` not `image03`.
   */
  QEAfWNHa3?: string;
  /**
   * Image 04 — pass as `XeNzW3rUn` not `image04`.
   */
  XeNzW3rUn?: string;
  /**
   * Title 01 — pass as `yYuH5LyJh` not `title01`.
   * @default "1/     Consultation"
   */
  yYuH5LyJh?: string;
  onyYuH5LyJhChange?: string;
  /**
   * Paragraph 01 — pass as `gVMB0Sah7` not `paragraph01`.
   * @default "We discuss your vision, needs, and preferences to understand the goals and direction of your interior design project. ✨"
   */
  gVMB0Sah7?: string;
  ongVMB0Sah7Change?: string;
  /**
   * Title 02 — pass as `fADH7v8EF` not `title02`.
   * @default "2/     Planning"
   */
  fADH7v8EF?: string;
  onfADH7v8EFChange?: string;
  /**
   * Paragraph 02 — pass as `wkncqknwC` not `paragraph02`.
   * @default "We develop a detailed layout and design strategy to reflect your style ensure the space is both functional and visually balanced."
   */
  wkncqknwC?: string;
  onwkncqknwCChange?: string;
  /**
   * Title 03 — pass as `NDdr_cdQg` not `title03`.
   * @default "3/     Design"
   */
  NDdr_cdQg?: string;
  onNDdr_cdQgChange?: string;
  /**
   * Paragraph 03 — pass as `avQL7OqGo` not `paragraph03`.
   * @default "We craft creative interior concepts, selecting colors, materials, and elements that reflect your style and enhance the space."
   */
  avQL7OqGo?: string;
  onavQL7OqGoChange?: string;
  /**
   * Title 04 — pass as `kNrPlSMOP` not `title04`.
   * @default "4/    Execution"
   */
  kNrPlSMOP?: string;
  onkNrPlSMOPChange?: string;
  /**
   * Paragraph 05 — pass as `whSO1xRBf` not `paragraph05`.
   * @default "We bring the design to life by coordinating materials, installations, and final details to ensure a seamless result."
   */
  whSO1xRBf?: string;
  onwhSO1xRBfChange?: string;
  /**
   * Padding — pass as `LhM4RpV5F` not `padding`.
   * @default "32px 0px 32px 0px"
   */
  LhM4RpV5F?: string;
  /**
   * Gap — pass as `Z_hPAkV_x` not `gap`.
   * Range: min: 0
   * @default 32
   */
  Z_hPAkV_x?: number;
  onZ_hPAkV_xChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
