# Hero Button

Exported from Framer using Design to AI.

## Components

- `Hero`
- `Brand`
- `About`
- `Tag`
- `ServiceCard`
- `Tag2`
- `Hero2`
- `WorkCard`
- `WorkCard2`
- `WorkCard3`
- `Tag3`
- `Hero3`
- `ProcessTab`
- `Tag4`
- `Group6`
- `TestimonialCardSider`
- `Tag5`
- `AwardCard`
- `AwardCard2`
- `AwardCard3`
- `AwardCard4`
- `AwardCard5`
- `Tag6`
- `Hero4`
- `BlogCard`
- `BlogCard2`
- `BlogCard3`
- `SmoothscrollProd`
- `Hero5`
- `Brand2`
- `About2`
- `Tag7`
- `ServiceCard2`
- `Tag8`
- `Hero6`
- `WorkCard4`
- `WorkCard5`
- `WorkCard6`
- `Tag9`
- `Hero7`
- `ProcessTab2`
- `Tag10`
- `Group62`
- `TestimonialCardSider2`
- `Tag11`
- `AwardCard6`
- `AwardCard7`
- `AwardCard8`
- `AwardCard9`
- `AwardCard10`
- `Tag12`
- `Hero8`
- `BlogCard4`
- `BlogCard5`
- `BlogCard6`
- `SmoothscrollProd2`
- `Hero9`
- `Brand3`
- `About3`
- `Tag13`
- `ServiceCard3`
- `Tag14`
- `Hero10`
- `WorkCard7`
- `WorkCard8`
- `WorkCard9`
- `Tag15`
- `Hero11`
- `ProcessTab3`
- `Tag16`
- `Group63`
- `TestimonialCardSider3`
- `Tag17`
- `AwardCard11`
- `AwardCard12`
- `AwardCard13`
- `AwardCard14`
- `AwardCard15`
- `Tag18`
- `Hero12`
- `BlogCard7`
- `BlogCard8`
- `BlogCard9`
- `SmoothscrollProd3`
- `Hero13`
- `Brand4`
- `About4`
- `Tag19`
- `ServiceCard4`
- `Tag20`
- `Hero14`
- `WorkCard10`
- `WorkCard11`
- `WorkCard12`
- `Tag21`
- `Hero15`
- `ProcessTab4`
- `Tag22`
- `Group64`
- `TestimonialCardSider4`
- `Tag23`
- `AwardCard16`
- `AwardCard17`
- `AwardCard18`
- `AwardCard19`
- `AwardCard20`
- `Tag24`
- `Hero16`
- `BlogCard10`
- `BlogCard11`
- `BlogCard12`
- `SmoothscrollProd4`
- `Hero17`
- `Brand5`
- `About5`
- `Tag25`
- `ServiceCard5`
- `Tag26`
- `Hero18`
- `WorkCard13`
- `WorkCard14`
- `WorkCard15`
- `Tag27`
- `Hero19`
- `ProcessTab5`
- `Tag28`
- `Group65`
- `TestimonialCardSider5`
- `Tag29`
- `AwardCard21`
- `AwardCard22`
- `AwardCard23`
- `AwardCard24`
- `AwardCard25`
- `Tag30`
- `Hero20`
- `BlogCard13`
- `BlogCard14`
- `BlogCard15`
- `SmoothscrollProd5`
- `Hero21`
- `Brand6`
- `About6`
- `Tag31`
- `ServiceCard6`
- `Tag32`
- `Hero22`
- `WorkCard16`
- `WorkCard17`
- `WorkCard18`
- `Tag33`
- `Hero23`
- `ProcessTab6`
- `Tag34`
- `Group66`
- `TestimonialCardSider6`
- `Tag35`
- `AwardCard26`
- `AwardCard27`
- `AwardCard28`
- `AwardCard29`
- `AwardCard30`
- `Tag36`
- `Hero24`
- `BlogCard16`
- `BlogCard17`
- `BlogCard18`
- `SmoothscrollProd6`

## Installation

```bash
# Copy this folder to your project, then install dependencies:
npm install react react-dom framer-motion @motionone/dom@10.13.1 lenis@1.1.2
```

## Usage

```tsx
import { Hero } from './Hero Button';

function App() {
  return <Hero />;
}
```

## Responsive Components

For components with responsive variants, use the responsive runtime:

```tsx
// Import the CSS for responsive breakpoints
import './Hero Button/_responsive-runtime.css';

// Option 1: Use the useBreakpoint hook
import { useBreakpoint } from './Hero Button/_responsive-runtime';

function App() {
  const breakpoint = useBreakpoint(); // 'base' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

  return <Hero variant={breakpoint === 'base' ? 'mobile' : 'desktop'} />;
}

// Option 2: Use the WithBreakpoints HOC
import { WithBreakpoints } from './Hero Button/_responsive-runtime';

function App() {
  return (
    <WithBreakpoints
      Component={Hero}
      variants={{
        base: 'mobile',    // 0px+
        md: 'tablet',      // 768px+
        lg: 'desktop'      // 1024px+
      }}
    />
  );
}
```

### Breakpoints

| Name | Min Width | Typical Use |
|------|-----------|-------------|
| base | 0px | Mobile |
| sm | 390px | Large mobile |
| md | 768px | Tablet |
| lg | 1024px | Laptop |
| xl | 1280px | Desktop |
| 2xl | 1536px | Large desktop |

## Peer Dependencies

These components require the following packages in your project:

- `react` >= 18.0.0
- `react-dom` >= 18.0.0
- `framer-motion` >= 10.0.0

## Note

The Framer runtime is bundled as `_framer-runtime.js` - no external Framer dependency needed.
These exports are self-contained and work out of the box.

## Generated

Created with [Design to AI](https://designtoai.com)
