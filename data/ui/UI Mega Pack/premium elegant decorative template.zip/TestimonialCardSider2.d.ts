export interface Testimonialcardsider2Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default" → cFGZjCt5s
   *   "Small" → HyXFaLIf5
   *   "Tablet" → moPTzcTQZ
   */
  variant?: 'Default' | 'Small' | 'Tablet' | 'cFGZjCt5s' | 'moPTzcTQZ' | 'HyXFaLIf5';
  /** Additional properties */
  [key: string]: unknown;
}
