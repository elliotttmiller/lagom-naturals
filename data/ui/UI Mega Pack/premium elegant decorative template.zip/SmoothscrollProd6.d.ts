export interface Smoothscrollprod6Props {
  /**
   * Intensity
   * Range: min: 0
   * @default 10
   */
  intensity?: number;
  /** Additional properties */
  [key: string]: unknown;
}
