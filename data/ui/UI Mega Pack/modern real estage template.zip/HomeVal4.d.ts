export interface Homeval4Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop Step 1 " → rwXtPmQ8U
   *   "Desktop Step 2" → s4T2S26fp
   *   "Desktop Step 3" → soGHMUZ7i
   *   "Mobile Step 1 " → GPLjmy72J
   *   "Mobile Step 2" → OjuDzpVbd
   *   "Mobile Step 3" → lHuqH09c7
   */
  variant?: 'Desktop Step 1 ' | 'Desktop Step 2' | 'Desktop Step 3' | 'Mobile Step 1 ' | 'Mobile Step 2' | 'Mobile Step 3' | 'rwXtPmQ8U' | 's4T2S26fp' | 'soGHMUZ7i' | 'GPLjmy72J' | 'OjuDzpVbd' | 'lHuqH09c7';
  /** Additional properties */
  [key: string]: unknown;
}
