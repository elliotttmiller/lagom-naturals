export interface Gallerymenuitem4Props {
  /**
   * Title — pass as `TxIy08uNJ` not `title`.
   * @default "Buy."
   */
  TxIy08uNJ?: string;
  onTxIy08uNJChange?: string;
  /**
   * Description — pass as `vnCu8gyw3` not `description`.
   * @default "Representing a select collection of residential properties across London's most established addresses."
   */
  vnCu8gyw3?: string;
  onvnCu8gyw3Change?: string;
  /**
   * Background Image — pass as `gWhtsj1OY` not `backgroundImage`.
   */
  gWhtsj1OY?: string;
  /**
   * Link — pass as `awJrspy3a` not `link`.
   */
  awJrspy3a?: string;
  /**
   * New Tab — pass as `B2jKn69qa` not `newTab`.
   * @default false
   */
  B2jKn69qa?: boolean;
  onB2jKn69qaChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
