# Smooth Scroll

Exported from Framer using Design to AI.

## Components

- `SmoothscrollProd`
- `VideoImage`
- `Button`
- `Button2`
- `GalleryMenuItem`
- `GalleryMenuItem2`
- `GalleryMenuItem3`
- `Stats`
- `Stats2`
- `Stats3`
- `Stats4`
- `ParallaximageProd`
- `Mobile`
- `PropertyCard`
- `D9aavl07e`
- `Button3`
- `Button4`
- `Testimonials`
- `Button5`
- `Button6`
- `Slideshow`
- `HomeVal`
- `ParallaximageProd2`
- `NeighborhoodCard`
- `Button7`
- `InsightsHomeCard`
- `BlogItem`
- `Cta`
- `SmoothscrollProd2`
- `VideoImage2`
- `Button8`
- `Button9`
- `GalleryMenuItem4`
- `GalleryMenuItem5`
- `GalleryMenuItem6`
- `Stats5`
- `Stats6`
- `Stats7`
- `Stats8`
- `ParallaximageProd3`
- `Mobile2`
- `PropertyCard2`
- `D9aavl07e2`
- `Button10`
- `Button11`
- `Testimonials2`
- `Button12`
- `Button13`
- `Slideshow2`
- `HomeVal2`
- `ParallaximageProd4`
- `NeighborhoodCard2`
- `Button14`
- `InsightsHomeCard2`
- `BlogItem2`
- `Cta2`
- `SmoothscrollProd3`
- `VideoImage3`
- `Button15`
- `Button16`
- `GalleryMenuItem7`
- `GalleryMenuItem8`
- `GalleryMenuItem9`
- `Stats9`
- `Stats10`
- `Stats11`
- `Stats12`
- `ParallaximageProd5`
- `Mobile3`
- `PropertyCard3`
- `D9aavl07e3`
- `Button17`
- `Button18`
- `Testimonials3`
- `Button19`
- `Button20`
- `Slideshow3`
- `HomeVal3`
- `ParallaximageProd6`
- `NeighborhoodCard3`
- `Button21`
- `InsightsHomeCard3`
- `BlogItem3`
- `Cta3`
- `SmoothscrollProd4`
- `VideoImage4`
- `Button22`
- `Button23`
- `GalleryMenuItem10`
- `GalleryMenuItem11`
- `GalleryMenuItem12`
- `Stats13`
- `Stats14`
- `Stats15`
- `Stats16`
- `ParallaximageProd7`
- `Mobile4`
- `PropertyCard4`
- `D9aavl07e4`
- `Button24`
- `Button25`
- `Testimonials4`
- `Button26`
- `Button27`
- `Slideshow4`
- `HomeVal4`
- `ParallaximageProd8`
- `NeighborhoodCard4`
- `Button28`
- `InsightsHomeCard4`
- `BlogItem4`
- `Cta4`
- `SmoothscrollProd5`
- `VideoImage5`
- `Button29`
- `Button30`
- `GalleryMenuItem13`
- `GalleryMenuItem14`
- `GalleryMenuItem15`
- `Stats17`
- `Stats18`
- `Stats19`
- `Stats20`
- `ParallaximageProd9`
- `Mobile5`
- `PropertyCard5`
- `D9aavl07e5`
- `Button31`
- `Button32`
- `Testimonials5`
- `Button33`
- `Button34`
- `Slideshow5`
- `HomeVal5`
- `ParallaximageProd10`
- `NeighborhoodCard5`
- `Button35`
- `InsightsHomeCard5`
- `BlogItem5`
- `Cta5`
- `SmoothscrollProd6`
- `VideoImage6`
- `Button36`
- `Button37`
- `GalleryMenuItem16`
- `GalleryMenuItem17`
- `GalleryMenuItem18`
- `Stats21`
- `Stats22`
- `Stats23`
- `Stats24`
- `ParallaximageProd11`
- `Mobile6`
- `PropertyCard6`
- `D9aavl07e6`
- `Button38`
- `Button39`
- `Testimonials6`
- `Button40`
- `Button41`
- `Slideshow6`
- `HomeVal6`
- `ParallaximageProd12`
- `NeighborhoodCard6`
- `Button42`
- `InsightsHomeCard6`
- `BlogItem6`
- `Cta6`

## Installation

```bash
# Copy this folder to your project, then install dependencies:
npm install react react-dom framer-motion lenis@1.1.2 @motionone/dom@10.13.1
```

## Usage

```tsx
import { SmoothscrollProd } from './Smooth Scroll';

function App() {
  return <SmoothscrollProd />;
}
```

## Responsive Components

For components with responsive variants, use the responsive runtime:

```tsx
// Import the CSS for responsive breakpoints
import './Smooth Scroll/_responsive-runtime.css';

// Option 1: Use the useBreakpoint hook
import { useBreakpoint } from './Smooth Scroll/_responsive-runtime';

function App() {
  const breakpoint = useBreakpoint(); // 'base' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

  return <SmoothscrollProd variant={breakpoint === 'base' ? 'mobile' : 'desktop'} />;
}

// Option 2: Use the WithBreakpoints HOC
import { WithBreakpoints } from './Smooth Scroll/_responsive-runtime';

function App() {
  return (
    <WithBreakpoints
      Component={SmoothscrollProd}
      variants={{
        base: 'mobile',    // 0px+
        md: 'tablet',      // 768px+
        lg: 'desktop'      // 1024px+
      }}
    />
  );
}
```

### Breakpoints

| Name | Min Width | Typical Use |
|------|-----------|-------------|
| base | 0px | Mobile |
| sm | 390px | Large mobile |
| md | 768px | Tablet |
| lg | 1024px | Laptop |
| xl | 1280px | Desktop |
| 2xl | 1536px | Large desktop |

## Peer Dependencies

These components require the following packages in your project:

- `react` >= 18.0.0
- `react-dom` >= 18.0.0
- `framer-motion` >= 10.0.0

## Note

The Framer runtime is bundled as `_framer-runtime.js` - no external Framer dependency needed.
These exports are self-contained and work out of the box.

## Generated

Created with [Design to AI](https://designtoai.com)
