export interface Insightshomecard6Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → DV3PJqobe
   *   "Mobile" → Z2WYrKc2F
   */
  variant?: 'Desktop' | 'Mobile' | 'DV3PJqobe' | 'Z2WYrKc2F';
  /**
   * Date — pass as `smzLE0y6L` not `date`.
   * @default "2026-01-18T00:00:00.000Z"
   */
  smzLE0y6L?: string;
  onsmzLE0y6LChange?: string;
  /**
   * Cover — pass as `raqRZGGel` not `cover`.
   */
  raqRZGGel?: string;
  /**
   * Title — pass as `pXSCd6UgM` not `title`.
   * @default "Aspen Luxury Market Enters 2026 Stronger Than Ever"
   */
  pXSCd6UgM?: string;
  onpXSCd6UgMChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
