export interface Cta5Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → C4nZld9J5
   *   "Mobile" → fao3owaJ2
   */
  variant?: 'Desktop' | 'Mobile' | 'C4nZld9J5' | 'fao3owaJ2';
  /**
   * Pre Title — pass as `kDXlCE5nW` not `preTitle`.
   * @default "Why Choose Us?"
   */
  kDXlCE5nW?: string;
  onkDXlCE5nWChange?: string;
  /**
   * Title — pass as `hbZ_0WaxW` not `title`.
   * @default "More Than Real Estate"
   */
  hbZ_0WaxW?: string;
  onhbZ_0WaxWChange?: string;
  /**
   * Button 1: Text — pass as `h6A2HpCph` not `button1:Text`.
   * @default "Contact Us"
   */
  h6A2HpCph?: string;
  onh6A2HpCphChange?: string;
  /**
   * Button 1: Link — pass as `cuubPZsE8` not `button1:Link`.
   */
  cuubPZsE8?: string;
  /**
   * Button 2: Text — pass as `aHEq_BHJu` not `button2:Text`.
   * @default "Explore Properties"
   */
  aHEq_BHJu?: string;
  onaHEq_BHJuChange?: string;
  /**
   * Button 2: Link — pass as `WQXZcG0lm` not `button2:Link`.
   */
  WQXZcG0lm?: string;
  /**
   * Background Img — pass as `a06Zx2E0v` not `backgroundImg`.
   */
  a06Zx2E0v?: string;
  /** Additional properties */
  [key: string]: unknown;
}
