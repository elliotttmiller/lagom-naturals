var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/IMnGWfUUZM9nW0FoW5zi/VFID6I78EVIafWbJmAiQ/TXavTDrIq.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls, ControlType, cx, getFontsFromSharedStyle, RichText, useComponentViewport, useLocaleCode, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/Tn34of7qsNhRmQFkfmeS/MEOhYCWG11QLDc6DeClD/UNgbAfrcH.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["GF;Cormorant Garamond-regular", "GF;Cormorant Garamond-700", "GF;Cormorant Garamond-700italic", "GF;Cormorant Garamond-italic"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Cormorant Garamond", openType: true, source: "google", style: "normal", uiFamilyName: "Cormorant Garamond", url: "https://fonts.gstatic.com/s/cormorantgaramond/v21/co3umX5slCNuHLi8bLeY9MK7whWMhyjypVO7abI26QOD_v86GnbEi_s4Mfs.woff2", weight: "400" }, { cssFamilyName: "Cormorant Garamond", openType: true, source: "google", style: "normal", uiFamilyName: "Cormorant Garamond", url: "https://fonts.gstatic.com/s/cormorantgaramond/v21/co3umX5slCNuHLi8bLeY9MK7whWMhyjypVO7abI26QOD_hg9GnbEi_s4Mfs.woff2", weight: "700" }, { cssFamilyName: "Cormorant Garamond", openType: true, source: "google", style: "italic", uiFamilyName: "Cormorant Garamond", url: "https://fonts.gstatic.com/s/cormorantgaramond/v21/co3smX5slCNuHLi8bLeY9MK7whWMhyjYrGFEsdtdc62E6zd5FTfOitk9Ifu5UQ.woff2", weight: "700" }, { cssFamilyName: "Cormorant Garamond", openType: true, source: "google", style: "italic", uiFamilyName: "Cormorant Garamond", url: "https://fonts.gstatic.com/s/cormorantgaramond/v21/co3smX5slCNuHLi8bLeY9MK7whWMhyjYrGFEsdtdc62E6zd58jDOitk9Ifu5UQ.woff2", weight: "400" }] }];
var css = [`.framer-fZcjE .framer-styles-preset-1nmxljo:not(.rich-text-wrapper), .framer-fZcjE .framer-styles-preset-1nmxljo.rich-text-wrapper p { --framer-font-family: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 28px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0.05em; --framer-line-height: 1.4em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: #e8e8e8; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }`, `@media (max-width: 1199px) and (min-width: 810px) { .framer-fZcjE .framer-styles-preset-1nmxljo:not(.rich-text-wrapper), .framer-fZcjE .framer-styles-preset-1nmxljo.rich-text-wrapper p { --framer-font-family: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 24px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0.05em; --framer-line-height: 1.4em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: #e8e8e8; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }`, `@media (max-width: 809px) and (min-width: 0px) { .framer-fZcjE .framer-styles-preset-1nmxljo:not(.rich-text-wrapper), .framer-fZcjE .framer-styles-preset-1nmxljo.rich-text-wrapper p { --framer-font-family: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 24px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0.05em; --framer-line-height: 1.4em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: #e8e8e8; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }`];
var className = "framer-fZcjE";

// http-url:https://framerusercontent.com/modules/IMnGWfUUZM9nW0FoW5zi/VFID6I78EVIafWbJmAiQ/TXavTDrIq.js
var enabledGestures = { eR0KcE1Aa: { hover: true } };
var serializationHash = "framer-kOMw6";
var variantClassNames = { eR0KcE1Aa: "framer-v-18p08jd" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var sharedDateFormatter = (value, formatOptions, locale) => {
  if (typeof value !== "string")
    return "";
  const date = new Date(value);
  if (isNaN(date.getTime()))
    return "";
  const fallbackLocale = "en-US";
  try {
    return date.toLocaleString(locale || fallbackLocale, formatOptions);
  } catch {
    return date.toLocaleString(fallbackLocale, formatOptions);
  }
};
var dateOptions = { dateStyle: "medium", timeZone: "UTC" };
var toDateString = (value, activeLocale) => {
  return sharedDateFormatter(value, dateOptions, activeLocale);
};
var animation = { opacity: 1e-3, rotate: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 10 };
var transition2 = { bounce: 0, delay: 0.075, duration: 0.4, type: "spring" };
var textEffect = { effect: animation, repeat: false, startDelay: 0.1, threshold: 0.5, tokenization: "word", transition: transition2, trigger: "onInView", type: "appear" };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion.create(React.Fragment);
var getProps = ({ date, height, id, title, width, ...props }) => {
  return { ...props, dk9dT5SbZ: date ?? props.dk9dT5SbZ ?? "2026-01-18T00:00:00.000Z", Mpyg8Akhv: title ?? props.Mpyg8Akhv ?? "Manhattan Luxury in 2026" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className2, layoutId, variant, dk9dT5SbZ, Mpyg8Akhv, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "eR0KcE1Aa", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [className];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (gestureVariant === "eR0KcE1Aa-hover")
      return true;
    return false;
  };
  const activeLocaleCode = useLocaleCode();
  const textContent = toDateString(dk9dT5SbZ, activeLocaleCode);
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-18p08jd", className2, classNames), "data-border": true, "data-framer-name": "Variant 1", layoutDependency, layoutId: "BlogItem__eR0KcE1Aa", ref: refBinding, style: { "--border-bottom-width": "0px", "--border-color": "rgb(33, 33, 33)", "--border-left-width": "0px", "--border-right-width": "0px", "--border-style": "solid", "--border-top-width": "1px", ...style }, ...addPropertyOverrides({ "eR0KcE1Aa-hover": { "data-framer-name": void 0 } }, baseVariant, gestureVariant), children: [isDisplayed() && /* @__PURE__ */ _jsx(motion.div, { className: "framer-7zbzyr", "data-framer-name": "spacer", layoutDependency, layoutId: "BlogItem__ageoN1PYM" }), /* @__PURE__ */ _jsxs(motion.div, { className: "framer-4o7m9t", layoutDependency, layoutId: "BlogItem__egHSAMphn", children: [/* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.h2, { dir: "auto", style: { "--framer-line-height": "1.4em", "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-1of0zx5, var(--token-b05544d6-f7d2-46a2-82e4-5fe4fef57d80, rgb(245, 245, 245)))" }, children: "Jan 18, 2026" }) }), className: "framer-pa5vi3", effect: textEffect, fonts: ["Inter"], layoutDependency, layoutId: "BlogItem__xyG1x8KMa", style: { "--extracted-1of0zx5": "var(--token-b05544d6-f7d2-46a2-82e4-5fe4fef57d80, rgb(245, 245, 245))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: /* @__PURE__ */ _jsx("time", { dateTime: dk9dT5SbZ, children: textContent }), verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.p, { className: "framer-styles-preset-1nmxljo", "data-styles-preset": "UNgbAfrcH", dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)))" }, children: "Manhattan Luxury in 2026" }) }), className: "framer-fd0nq2", fonts: ["Inter"], layoutDependency, layoutId: "BlogItem__iL5r49TOO", style: { "--extracted-r6o4lv": "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: Mpyg8Akhv, verticalAlignment: "top", withExternalLayout: true })] })] }) }) }) });
});
var css2 = [".framer-kOMw6.framer-dwc2ey, .framer-kOMw6 .framer-dwc2ey { display: block; }", ".framer-kOMw6.framer-18p08jd { align-content: flex-start; align-items: flex-start; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 24px 0px 12px 0px; position: relative; width: 100%; }", ".framer-kOMw6 .framer-7zbzyr { flex: none; height: 19px; overflow: visible; position: relative; width: 8px; }", ".framer-kOMw6 .framer-4o7m9t { align-content: flex-start; align-items: flex-start; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 1px; }", ".framer-kOMw6 .framer-pa5vi3 { --framer-text-wrap: balance; flex: none; height: auto; max-width: 450px; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-kOMw6 .framer-fd0nq2 { --framer-text-wrap-override: balance; flex: none; height: auto; position: relative; width: 100%; z-index: 2; }", ...css, '.framer-kOMw6[data-border="true"]::after, .framer-kOMw6 [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerTXavTDrIq = withCSS(Component, css2, "framer-kOMw6");
var TXavTDrIq_default = FramerTXavTDrIq;
FramerTXavTDrIq.displayName = "Blog Item";
FramerTXavTDrIq.defaultProps = { height: 108, width: 504 };
addPropertyControls(FramerTXavTDrIq, { dk9dT5SbZ: { defaultValue: "2026-01-18T00:00:00.000Z", title: "Date", type: ControlType.Date }, ondk9dT5SbZChange: { changes: "dk9dT5SbZ", type: ControlType.ChangeHandler }, Mpyg8Akhv: { defaultValue: "Manhattan Luxury in 2026", title: "Title", type: ControlType.String }, onMpyg8AkhvChange: { changes: "Mpyg8Akhv", type: ControlType.ChangeHandler } });
addFonts(FramerTXavTDrIq, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerTXavTDrIq", "slots": [], "annotations": { "framerColorSyntax": "true", "framerContractVersion": "1", "framerIntrinsicHeight": "108", "framerComponentViewportWidth": "true", "framerDisplayContentsDiv": "false", "framerImmutableVariables": "true", "framerIntrinsicWidth": "504", "framerVariables": '{"dk9dT5SbZ":"date","Mpyg8Akhv":"title"}', "framerAutoSizeImages": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"PWAHEW8kR":{"layout":["fixed","auto"]}}}' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  TXavTDrIq_default as default
};
