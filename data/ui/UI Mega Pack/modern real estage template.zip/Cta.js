var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/EXTm6TFCkgnt2NUaAG5N/n7VrfP5SJtq24AoyMA2A/p0FiMnMQZ.js
import { jsx as _jsx6, jsxs as _jsxs4 } from "react/jsx-runtime";
import { addFonts as addFonts3, addPropertyControls as addPropertyControls5, ComponentViewportProvider, ControlType as ControlType5, cx as cx4, forwardLoader, getFonts as getFonts2, getFontsFromSharedStyle, RichText as RichText3, SmartComponentScopedContainer, useComponentViewport as useComponentViewport3, useLocaleInfo as useLocaleInfo3, useVariantState as useVariantState3, withCSS as withCSS4 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup3, motion as motion4, MotionConfigContext as MotionConfigContext3 } from "framer-motion";
import * as React4 from "react";
import { useRef as useRef4 } from "react";

// http-url:https://framerusercontent.com/modules/zxcGfQb3lPhoJOWc1HTU/UHrEi0qhIpd3yrAh6Rk2/ParallaxImage_prod.js
import { jsx as _jsx3, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2, RenderTarget } from "./_framer-runtime.js";
import { useRef as useRef2, useLayoutEffect } from "react";

// http-url:https://framerusercontent.com/modules/aej5zpwxBpkMdzOteBwy/DWeAZ5wauvGM5oFwVdgS/Utils.js
import { jsx as _jsx2 } from "react/jsx-runtime";
import { cloneElement } from "react";

// http-url:https://framerusercontent.com/modules/fMDE7Cqb2uOvQFAHEP2m/cRfVFRl0izzBulKFjOAe/W7oLCU4_B.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls, ControlType, cx, RichText, SVG, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React from "react";
var serializationHash = "framer-q8Ttd";
var variantClassNames = { XvqTw0Be9: "framer-v-jjcw9a" };
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value !== null && value !== void 0 ? value : config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion(React.Fragment);
var getProps = ({ height, id, subtitle, title, width, ...props }) => {
  var _ref, _ref1;
  return { ...props, WuF2iG84P: (_ref = subtitle !== null && subtitle !== void 0 ? subtitle : props.WuF2iG84P) !== null && _ref !== void 0 ? _ref : "Set up the component by adding background and bouncer elements to the component properties.", yeAnKbEUZ: (_ref1 = title !== null && title !== void 0 ? title : props.yeAnKbEUZ) !== null && _ref1 !== void 0 ? _ref1 : "Screen Saver" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { activeLocale, setLocale } = useLocaleInfo();
  const { style, className: className3, layoutId, variant, yeAnKbEUZ, WuF2iG84P, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "XvqTw0Be9", variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const ref1 = React.useRef(null);
  const defaultLayoutId = React.useId();
  const sharedStyleClassNames = [];
  const componentViewport = useComponentViewport();
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId !== null && layoutId !== void 0 ? layoutId : defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsx(motion.div, { ...restProps, ...gestureHandlers, className: cx(serializationHash, ...sharedStyleClassNames, "framer-jjcw9a", className3, classNames), "data-framer-name": "Default", layoutDependency, layoutId: "CTA__XvqTw0Be9", ref: ref !== null && ref !== void 0 ? ref : ref1, style: { backgroundColor: "rgba(136, 85, 255, 0.1)", ...style }, children: /* @__PURE__ */ _jsxs(motion.div, { className: "framer-uh2i08", layoutDependency, layoutId: "CTA__aM7oiNoFL", children: [/* @__PURE__ */ _jsx(SVG, { className: "framer-flw0dh", "data-framer-name": "Logo", layout: "position", layoutDependency, layoutId: "CTA__GthLmGmBt", opacity: 1, svg: '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 28 28"><g id="ss11036020200_1"><path d="M 0 0 L 28 0 L 28 28 L 0 28 Z" fill="transparent"></path><path d="M 21 7.113 C 21 7.041 21.029 6.971 21.079 6.921 L 27.534 0.465 C 27.613 0.388 27.73 0.365 27.831 0.407 C 27.933 0.449 28 0.548 28 0.658 L 28 13.888 C 28 13.96 27.971 14.028 27.921 14.079 L 21 21 Z M 7 21 L 7 7.658 C 7 7.548 6.933 7.449 6.831 7.407 C 6.73 7.365 6.613 7.388 6.534 7.465 L 0.079 13.921 C 0.028 13.972 0 14.041 0 14.113 L 0 27.728 C 0 27.877 0.122 28 0.273 28 L 13.888 28 C 13.96 28 14.028 27.971 14.079 27.921 L 21 21 Z" fill="rgb(153, 102, 255)"></path></g></svg>', svgContentId: 11036020200, withExternalLayout: true }), /* @__PURE__ */ _jsxs(motion.div, { className: "framer-k3ullq", layoutDependency, layoutId: "CTA__E3DQBYSAf", children: [/* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.p, { style: { "--font-selector": "SW50ZXItQm9sZA==", "--framer-font-family": '"Inter", "Inter Placeholder", sans-serif', "--framer-font-size": "11px", "--framer-font-weight": "700", "--framer-letter-spacing": "-0.02em", "--framer-line-height": "1em", "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, rgb(153, 102, 255))" }, children: "Screen Saver" }) }), className: "framer-q0gs4u", "data-framer-name": "Title", fonts: ["Inter-Bold"], layoutDependency, layoutId: "CTA__UqJwZqJjg", style: { "--extracted-r6o4lv": "rgb(153, 102, 255)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: yeAnKbEUZ, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.p, { style: { "--framer-font-size": "11px", "--framer-letter-spacing": "-0.03em", "--framer-line-height": "1.4em", "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-r6o4lv, rgba(153, 102, 255, 0.7))" }, children: "Set up the component by adding background and bouncer elements to the component properties." }) }), className: "framer-g5dqhc", "data-framer-name": "Subtitle", fonts: ["Inter"], layoutDependency, layoutId: "CTA__RJ7UF99m8", style: { "--extracted-r6o4lv": "rgba(153, 102, 255, 0.7)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: WuF2iG84P, verticalAlignment: "top", withExternalLayout: true })] })] }) }) }) }) });
});
var css = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-q8Ttd.framer-qanqo2, .framer-q8Ttd .framer-qanqo2 { display: block; }", ".framer-q8Ttd.framer-jjcw9a { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: auto; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-q8Ttd .framer-uh2i08 { align-content: center; align-items: center; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 16px; height: min-content; justify-content: center; overflow: hidden; padding: 0px 20px 0px 20px; position: relative; width: 1px; }", ".framer-q8Ttd .framer-flw0dh { flex: none; height: 28px; position: relative; width: 28px; }", ".framer-q8Ttd .framer-k3ullq { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 12px; height: min-content; justify-content: center; max-width: 200px; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-q8Ttd .framer-q0gs4u, .framer-q8Ttd .framer-g5dqhc { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", "@supports (background: -webkit-named-image(i)) and (not (font-palette:dark)) { .framer-q8Ttd.framer-jjcw9a, .framer-q8Ttd .framer-uh2i08, .framer-q8Ttd .framer-k3ullq { gap: 0px; } .framer-q8Ttd.framer-jjcw9a > * { margin: 0px; margin-left: calc(10px / 2); margin-right: calc(10px / 2); } .framer-q8Ttd.framer-jjcw9a > :first-child { margin-left: 0px; } .framer-q8Ttd.framer-jjcw9a > :last-child { margin-right: 0px; } .framer-q8Ttd .framer-uh2i08 > * { margin: 0px; margin-bottom: calc(16px / 2); margin-top: calc(16px / 2); } .framer-q8Ttd .framer-uh2i08 > :first-child, .framer-q8Ttd .framer-k3ullq > :first-child { margin-top: 0px; } .framer-q8Ttd .framer-uh2i08 > :last-child, .framer-q8Ttd .framer-k3ullq > :last-child { margin-bottom: 0px; } .framer-q8Ttd .framer-k3ullq > * { margin: 0px; margin-bottom: calc(12px / 2); margin-top: calc(12px / 2); } }"];
var FramerW7oLCU4_B = withCSS(Component, css, "framer-q8Ttd");
var W7oLCU4_B_default = FramerW7oLCU4_B;
FramerW7oLCU4_B.displayName = "Utils/Component Message";
FramerW7oLCU4_B.defaultProps = { height: 200, width: 400 };
addPropertyControls(FramerW7oLCU4_B, { yeAnKbEUZ: { defaultValue: "Screen Saver", displayTextArea: false, title: "Title", type: ControlType.String }, WuF2iG84P: { defaultValue: "Set up the component by adding background and bouncer elements to the component properties.", displayTextArea: false, title: "Subtitle", type: ControlType.String } });
addFonts(FramerW7oLCU4_B, [{ explicitInter: true, fonts: [{ family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/DpPBYI0sL4fYLgAkX8KXOPVt7c.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/4RAEQdEOrcnDkhHiiCbJOw92Lk.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/1K3W8DizY3v4emK8Mb08YHxTbs.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/tUSCtfYVM1I1IchuyCwz9gDdQ.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/VgYFWiwsAC5OYxAycRXXvhze58.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/DXD0Q7LSl7HEvDzucnyLnGBHM.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/GIryZETIX4IFypco5pYZONKhJIo.woff2", weight: "700" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/vQyevYAyHtARFwPqUzQGpnDs.woff2", weight: "400" }, { family: "Inter", source: "framer", style: "normal", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/aej5zpwxBpkMdzOteBwy/DWeAZ5wauvGM5oFwVdgS/Utils.js
var ComponentMessage = ({ title, subtitle, style }) => {
  return /* @__PURE__ */ _jsx2(W7oLCU4_B_default, { yeAnKbEUZ: title, WuF2iG84P: subtitle, style: { width: "100%", height: "100%", ...style } });
};

// http-url:https://framerusercontent.com/modules/zxcGfQb3lPhoJOWc1HTU/UHrEi0qhIpd3yrAh6Rk2/ParallaxImage_prod.js
function ImageParallax(props) {
  const { verticalParallaxAmount = 50, horizontalParallaxAmount = 0, image, style, borderRadius = 0, border, boxShadow } = props;
  const containerRef = useRef2(null);
  const imageRef = useRef2(null);
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  useLayoutEffect(() => {
    if (isCanvas)
      return;
    if (!containerRef.current || !imageRef.current)
      return;
    const container = containerRef.current;
    const image2 = imageRef.current;
    image2.style.transform = "translate3d(0, 0, 0)";
    image2.style.willChange = "transform";
    let rafId = null;
    let ticking = false;
    let animationFrameId = null;
    const updateParallax = () => {
      if (!container || !image2)
        return;
      const rect = container.getBoundingClientRect();
      const containerHeight = container.offsetHeight;
      const containerWidth = container.offsetWidth;
      if (containerHeight === 0 || containerWidth === 0)
        return;
      const viewportHeight = __dai_window.innerHeight;
      const scrollProgress = Math.max(0, Math.min(1, (viewportHeight - rect.top) / (viewportHeight + containerHeight)));
      const yOffset = (scrollProgress - 0.5) * (verticalParallaxAmount / 100) * containerHeight;
      let xOffset = 0;
      if (horizontalParallaxAmount !== 0) {
        const viewportWidth = __dai_window.innerWidth;
        const viewportCenter = viewportWidth / 2;
        const elementCenter = rect.left + rect.width / 2;
        const horizontalProgress = (elementCenter - viewportCenter) / viewportWidth;
        xOffset = horizontalProgress * (horizontalParallaxAmount / 100) * containerWidth;
      }
      image2.style.transform = `translate3d(${xOffset}px, ${yOffset}px, 0)`;
      ticking = false;
    };
    const requestTick = () => {
      if (!ticking) {
        rafId = requestAnimationFrame(updateParallax);
        ticking = true;
      }
    };
    const startAnimationLoop = () => {
      if (horizontalParallaxAmount !== 0) {
        const animate = () => {
          updateParallax();
          animationFrameId = requestAnimationFrame(animate);
        };
        animationFrameId = requestAnimationFrame(animate);
      }
    };
    const stopAnimationLoop = () => {
      if (animationFrameId !== null) {
        cancelAnimationFrame(animationFrameId);
        animationFrameId = null;
      }
    };
    const handleScroll = () => {
      requestTick();
    };
    const handleResize = () => {
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
      }
      rafId = requestAnimationFrame(updateParallax);
    };
    updateParallax();
    startAnimationLoop();
    __dai_window.addEventListener("scroll", handleScroll, { passive: true });
    __dai_window.addEventListener("resize", handleResize, { passive: true });
    return () => {
      stopAnimationLoop();
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
      }
      __dai_window.removeEventListener("scroll", handleScroll);
      __dai_window.removeEventListener("resize", handleResize);
    };
  }, [verticalParallaxAmount, horizontalParallaxAmount, isCanvas]);
  const imageSrc = image?.src || (typeof image === "string" ? image : null);
  const hasImage = !!imageSrc;
  return /* @__PURE__ */ _jsxs2("div", { ref: containerRef, style: { ...style, position: "relative", overflow: "hidden", width: "100%", height: "100%", borderRadius, boxShadow: boxShadow || void 0 }, children: [hasImage && /* @__PURE__ */ _jsx3("div", { style: { width: "100%", zIndex: 1e3, height: "100%", borderRadius, position: "absolute", top: 0, left: 0, right: 0, bottom: 0, ...border || {} } }), !hasImage ? /* @__PURE__ */ _jsx3(ComponentMessage, { style: { position: "relative", width: "100%", height: "100%", minWidth: 0, minHeight: 0 }, title: "Image Parallax", subtitle: "Add an image to create a parallax effect that moves as you scroll" }) : isCanvas ? (
    // Canvas mode: simple responsive image, no parallax
    /* @__PURE__ */ _jsx3("img", { src: imageSrc, alt: "", style: { width: "100%", height: "100%", objectFit: "cover", borderRadius, userSelect: "none", pointerEvents: "none" } })
  ) : (
    // Preview/Live mode: render parallax effect
    // Extend beyond boundaries to allow room for parallax movement
    /* @__PURE__ */ _jsx3("div", { ref: imageRef, style: {
      position: "absolute",
      // ALWAYS center the image by extending equally on both sides
      // This ensures the image is centered when element is centered, regardless of parallax direction
      // The sign of parallax only affects the direction of movement, not the centering
      top: `-${Math.abs(verticalParallaxAmount) / 2}%`,
      left: `-${Math.abs(horizontalParallaxAmount) / 2}%`,
      right: `-${Math.abs(horizontalParallaxAmount) / 2}%`,
      bottom: `-${Math.abs(verticalParallaxAmount) / 2}%`,
      // Always use Math.abs so the image is larger than container regardless of direction
      width: `calc(100% + ${Math.abs(horizontalParallaxAmount)}%)`,
      height: `calc(100% + ${Math.abs(verticalParallaxAmount)}%)`,
      backgroundImage: imageSrc ? `url(${imageSrc})` : void 0,
      backgroundSize: "cover",
      backgroundPosition: image?.positionX && image?.positionY ? `${image.positionX} ${image.positionY}` : "center",
      borderRadius,
      willChange: "transform",
      backfaceVisibility: "hidden",
      userSelect: "none",
      pointerEvents: "none"
    } })
  )] });
}
ImageParallax.defaultProps = { verticalParallaxAmount: 50, horizontalParallaxAmount: 0 };
addPropertyControls2(ImageParallax, {
  image: { type: ControlType2.ResponsiveImage, title: "Image" },
  // Vertical parallax controls (in percentage)
  verticalParallaxAmount: { type: ControlType2.Number, title: "Parallax Y", defaultValue: 30, step: 5, max: 100, min: -100, unit: "%" },
  horizontalParallaxAmount: { type: ControlType2.Number, title: "Parallax X", defaultValue: 0, step: 5, max: 100, min: -100, unit: "%", description: "Only seen if image moves horizontally." },
  border: {
    // @ts-ignore - ControlType.Border exists but may not be in types
    type: ControlType2.Border,
    title: "Border",
    optional: true
  },
  borderRadius: {
    // @ts-ignore - ControlType.BorderRadius exists but may not be in types
    type: ControlType2.BorderRadius,
    title: "Radius",
    defaultValue: 0,
    min: 0,
    max: 100,
    step: 1,
    unit: "px"
  },
  boxShadow: {
    // @ts-ignore - ControlType.BoxShadow exists but may not be in types
    type: ControlType2.BoxShadow,
    title: "Shadow"
  }
});
ImageParallax.displayName = "Image Parallax";

// http-url:https://framerusercontent.com/modules/oozQ4IEV6Zr8hg8WypFK/ivGAIjDoaZBM7RVgdhJr/DQGL3_cw0.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["GF;Cormorant Garamond-500", "GF;Cormorant Garamond-700", "GF;Cormorant Garamond-700italic", "GF;Cormorant Garamond-500italic"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Cormorant Garamond", source: "google", style: "normal", uiFamilyName: "Cormorant Garamond", url: "https://fonts.gstatic.com/s/cormorantgaramond/v21/co3umX5slCNuHLi8bLeY9MK7whWMhyjypVO7abI26QOD_s06GnbEi_s4Mfs.woff2", weight: "500" }, { cssFamilyName: "Cormorant Garamond", source: "google", style: "normal", uiFamilyName: "Cormorant Garamond", url: "https://fonts.gstatic.com/s/cormorantgaramond/v21/co3umX5slCNuHLi8bLeY9MK7whWMhyjypVO7abI26QOD_hg9GnbEi_s4Mfs.woff2", weight: "700" }, { cssFamilyName: "Cormorant Garamond", source: "google", style: "italic", uiFamilyName: "Cormorant Garamond", url: "https://fonts.gstatic.com/s/cormorantgaramond/v21/co3smX5slCNuHLi8bLeY9MK7whWMhyjYrGFEsdtdc62E6zd5FTfOitk9Ifu5UQ.woff2", weight: "700" }, { cssFamilyName: "Cormorant Garamond", source: "google", style: "italic", uiFamilyName: "Cormorant Garamond", url: "https://fonts.gstatic.com/s/cormorantgaramond/v21/co3smX5slCNuHLi8bLeY9MK7whWMhyjYrGFEsdtdc62E6zd5wDDOitk9Ifu5UQ.woff2", weight: "500" }] }];
var css2 = ['.framer-DLJLD .framer-styles-preset-1mwhg4q:not(.rich-text-wrapper), .framer-DLJLD .framer-styles-preset-1mwhg4q.rich-text-wrapper h2 { --framer-font-family: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-open-type-features: normal; --framer-font-size: 72px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 500; --framer-letter-spacing: 0em; --framer-line-height: 1em; --framer-paragraph-spacing: 40px; --framer-text-alignment: left; --framer-text-color: #e6e6e6; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }', '@media (max-width: 1199px) and (min-width: 810px) { .framer-DLJLD .framer-styles-preset-1mwhg4q:not(.rich-text-wrapper), .framer-DLJLD .framer-styles-preset-1mwhg4q.rich-text-wrapper h2 { --framer-font-family: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-open-type-features: normal; --framer-font-size: 62px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 500; --framer-letter-spacing: 0em; --framer-line-height: 1em; --framer-paragraph-spacing: 40px; --framer-text-alignment: left; --framer-text-color: #e6e6e6; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }', '@media (max-width: 809px) and (min-width: 0px) { .framer-DLJLD .framer-styles-preset-1mwhg4q:not(.rich-text-wrapper), .framer-DLJLD .framer-styles-preset-1mwhg4q.rich-text-wrapper h2 { --framer-font-family: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-bold-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-family-italic: "Cormorant Garamond", "Cormorant Garamond Placeholder", serif; --framer-font-open-type-features: normal; --framer-font-size: 40px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 500; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 500; --framer-letter-spacing: 0em; --framer-line-height: 1em; --framer-paragraph-spacing: 40px; --framer-text-alignment: left; --framer-text-color: #e6e6e6; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }'];
var className = "framer-DLJLD";

// http-url:https://framerusercontent.com/modules/bOikSEi0Nni0HQLDCla7/iy7EUzOXUvkoKbtLQIn2/NMDJoczM8.js
import { fontStore as fontStore2 } from "./_framer-runtime.js";
fontStore2.loadFonts(["Inter", "Inter-Bold", "Inter-BoldItalic", "Inter-Italic"]);
var fonts2 = [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/DpPBYI0sL4fYLgAkX8KXOPVt7c.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/4RAEQdEOrcnDkhHiiCbJOw92Lk.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/1K3W8DizY3v4emK8Mb08YHxTbs.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/tUSCtfYVM1I1IchuyCwz9gDdQ.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/VgYFWiwsAC5OYxAycRXXvhze58.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/syRNPWzAMIrcJ3wIlPIP43KjQs.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/GIryZETIX4IFypco5pYZONKhJIo.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/H89BbHkbHDzlxZzxi8uPzTsp90.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/u6gJwDuwB143kpNK1T1MDKDWkMc.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/43sJ6MfOPh1LCJt46OvyDuSbA6o.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/wccHG0r4gBDAIRhfHiOlq6oEkqw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/WZ367JPwf9bRW6LdTHN8rXgSjw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/ia3uin3hQWqDrVloC1zEtYHWw.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/2A4Xx7CngadFGlVV4xrO06OBHY.woff2", weight: "700" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/CfMzU8w2e7tHgF4T4rATMPuWosA.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/867QObYax8ANsfX4TGEVU9YiCM.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Oyn2ZbENFdnW7mt2Lzjk1h9Zb9k.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/cdAe8hgZ1cMyLu9g005pAW3xMo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/DOfvtmE1UplCq161m6Hj8CSQYg.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/pKRFNWFoZl77qYCAIp84lN1h944.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "italic", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/tKtBcDnBMevsEEJKdNGhhkLzYo.woff2", weight: "400" }] }];
var css3 = ['.framer-5AJbK .framer-styles-preset-l29348:not(.rich-text-wrapper), .framer-5AJbK .framer-styles-preset-l29348.rich-text-wrapper p { --framer-font-family: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-bold: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-bold-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-family-italic: "Inter", "Inter Placeholder", sans-serif; --framer-font-open-type-features: normal; --framer-font-size: 16px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0em; --framer-line-height: 1.2em; --framer-paragraph-spacing: 20px; --framer-text-alignment: center; --framer-text-color: rgba(255, 255, 255, 0.65); --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: uppercase; }'];
var className2 = "framer-5AJbK";

// http-url:https://framerusercontent.com/modules/DD0wWXAo96e14JmTosUl/e3I810N6Y0D79jk5koOp/TxRF350hk.js
import { jsx as _jsx5, jsxs as _jsxs3 } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls4, ControlType as ControlType4, cx as cx3, getFonts, Link, RichText as RichText2, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCSS as withCSS3 } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion3, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React3 from "react";
import { useRef as useRef3 } from "react";

// http-url:https://framerusercontent.com/modules/TgdovPTf12h5e9mf5mKX/ny0lQDjRQ5zoBlru0VHq/tL6Nru9eO.js
import { jsx as _jsx4 } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx as cx2, motion as motion2, useSVGTemplate, withCSS as withCSS2 } from "./_framer-runtime.js";
import * as React2 from "react";
import { forwardRef as forwardRef3 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef3(function(props, ref) {
  return /* @__PURE__ */ _jsx4("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion2.create(Base);
var SVG2 = /* @__PURE__ */ forwardRef3((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx4(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx4("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 0 0.75 C 0 0.336 0.336 0 0.75 0 L 15.75 0 C 16.164 0 16.5 0.336 16.5 0.75 L 16.5 15.75 C 16.5 16.164 16.164 16.5 15.75 16.5 L 0.75 16.5 C 0.336 16.5 0 16.164 0 15.75 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="16.5px" id="qUYSYEB2C" transform="translate(3.75 27.75)" width="16.5px"/><path d="M 0 0.75 C 0 0.336 0.336 0 0.75 0 L 15.75 0 C 16.164 0 16.5 0.336 16.5 0.75 L 16.5 15.75 C 16.5 16.164 16.164 16.5 15.75 16.5 L 0.75 16.5 C 0.336 16.5 0 16.164 0 15.75 Z" fill="transparent" height="16.5px" id="BcpYYi6FC" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(3.75 27.75)" width="16.5px"/><path d="M 0 0 L 7.5 0" fill="transparent" height="1px" id="RQrRctFta" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(8.25 12)" width="7.5px"/><path d="M 0 0 L 3 3 L 0 6" fill="transparent" height="6px" id="qCkbhs0Cc" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(12.75 9)" width="3px"/></svg>';
var getProps2 = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const { style, className: className3, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps2(props);
  const href = useSVGTemplate("3855583215", svg);
  return /* @__PURE__ */ _jsx4(SVG2, { ...restProps, className: cx2("framer-VHcoG", className3), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx4("use", { href }) });
});
var css4 = [`.framer-VHcoG { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS2(Component2, css4, "framer-VHcoG");
Icon.displayName = "Arrow Square Right";
var tL6Nru9eO_default = Icon;
addPropertyControls3(Icon, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType3.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType3.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType3.Number } });

// http-url:https://framerusercontent.com/modules/DD0wWXAo96e14JmTosUl/e3I810N6Y0D79jk5koOp/TxRF350hk.js
var ArrowSquareRightFonts = getFonts(tL6Nru9eO_default);
var enabledGestures = { pEUvRODrx: { hover: true } };
var cycleOrder = ["pEUvRODrx", "c2M0D2Gk6"];
var serializationHash2 = "framer-xYTrY";
var variantClassNames2 = { c2M0D2Gk6: "framer-v-1a38zcf", pEUvRODrx: "framer-v-1v3j1ym" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition12 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition2 = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx5(MotionConfigContext2.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "Variant 1": "pEUvRODrx", "Variant 2": "c2M0D2Gk6" };
var Variants2 = motion3.create(React3.Fragment);
var getProps3 = ({ arrow, defaultBackgroundColor, defaultBorder, defaultTextColor, height, hoverBackgroundColor, hoverBorder, hoverTextColor, id, link, newTab, text, width, ...props }) => {
  return { ...props, Cfh8Zxf9C: defaultBackgroundColor ?? props.Cfh8Zxf9C ?? "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", G1Aueh5gp: defaultBorder ?? props.G1Aueh5gp ?? { borderColor: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', borderStyle: "solid", borderWidth: 1 }, hCv5Bj5Nx: link ?? props.hCv5Bj5Nx, KakYM8inN: hoverBorder ?? props.KakYM8inN ?? { borderColor: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', borderStyle: "solid", borderWidth: 1 }, LTaRf1Os4: hoverBackgroundColor ?? props.LTaRf1Os4 ?? "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", ndsT4W1CC: defaultTextColor ?? props.ndsT4W1CC ?? "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))", Nk9CQOGHG: text ?? props.Nk9CQOGHG ?? "Explore Properties", TKPnz_Ntl: hoverTextColor ?? props.TKPnz_Ntl ?? "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "pEUvRODrx", Z_YhYkC46: newTab ?? props.Z_YhYkC46, Z4jhW3SAq: arrow ?? props.Z4jhW3SAq ?? true };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef3(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className: className3, layoutId, variant, Nk9CQOGHG, Cfh8Zxf9C, ndsT4W1CC, G1Aueh5gp, LTaRf1Os4, TKPnz_Ntl, KakYM8inN, Z4jhW3SAq, hCv5Bj5Nx, Z_YhYkC46, ...restProps } = getProps3(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder, defaultVariant: "pEUvRODrx", enabledGestures, ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx3(serializationHash2, ...sharedStyleClassNames);
  const isDisplayed = (value) => {
    if (baseVariant === "c2M0D2Gk6")
      return false;
    return value;
  };
  return /* @__PURE__ */ _jsx5(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx5(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx5(Transition2, { value: transition12, children: /* @__PURE__ */ _jsx5(Link, { href: hCv5Bj5Nx, motionChild: true, nodeId: "pEUvRODrx", openInNewTab: Z_YhYkC46, scopeId: "TxRF350hk", children: /* @__PURE__ */ _jsxs3(motion3.a, { ...restProps, ...gestureHandlers, className: `${cx3(scopingClassNames, "framer-1v3j1ym", className3, classNames)} framer-tyhx9i`, "data-border": true, "data-framer-name": "Variant 1", layoutDependency, layoutId: "CTA__pEUvRODrx", ref: refBinding, style: { "--border-bottom-width": (G1Aueh5gp?.borderBottomWidth ?? G1Aueh5gp?.borderWidth) + "px", "--border-color": G1Aueh5gp?.borderColor, "--border-left-width": (G1Aueh5gp?.borderLeftWidth ?? G1Aueh5gp?.borderWidth) + "px", "--border-right-width": (G1Aueh5gp?.borderRightWidth ?? G1Aueh5gp?.borderWidth) + "px", "--border-style": G1Aueh5gp?.borderStyle, "--border-top-width": (G1Aueh5gp?.borderTopWidth ?? G1Aueh5gp?.borderWidth) + "px", backgroundColor: Cfh8Zxf9C, ...style }, variants: { "pEUvRODrx-hover": { "--border-bottom-width": (KakYM8inN?.borderBottomWidth ?? KakYM8inN?.borderWidth) + "px", "--border-color": KakYM8inN?.borderColor, "--border-left-width": (KakYM8inN?.borderLeftWidth ?? KakYM8inN?.borderWidth) + "px", "--border-right-width": (KakYM8inN?.borderRightWidth ?? KakYM8inN?.borderWidth) + "px", "--border-style": KakYM8inN?.borderStyle, "--border-top-width": (KakYM8inN?.borderTopWidth ?? KakYM8inN?.borderWidth) + "px", backgroundColor: LTaRf1Os4 }, c2M0D2Gk6: { "--border-bottom-width": "0px", "--border-left-width": "0px", "--border-right-width": "0px", "--border-top-width": "0px" } }, ...addPropertyOverrides({ "pEUvRODrx-hover": { "data-framer-name": void 0 }, c2M0D2Gk6: { "data-framer-name": "Variant 2" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx5(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx5(React3.Fragment, { children: /* @__PURE__ */ _jsx5(motion3.p, { dir: "auto", style: { "--framer-line-height": "1em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-ndsT4W1CC-TxRF350hk))" }, children: "Explore Properties" }) }), className: "framer-nw5h50", fonts: ["Inter"], layoutDependency, layoutId: "CTA__ph41uNL7c", style: { "--extracted-r6o4lv": "var(--variable-reference-ndsT4W1CC-TxRF350hk)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline", "--variable-reference-ndsT4W1CC-TxRF350hk": ndsT4W1CC, "--variable-reference-TKPnz_Ntl-TxRF350hk": TKPnz_Ntl }, text: Nk9CQOGHG, variants: { "pEUvRODrx-hover": { "--extracted-r6o4lv": "var(--variable-reference-TKPnz_Ntl-TxRF350hk)", "--variable-reference-TKPnz_Ntl-TxRF350hk": TKPnz_Ntl } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ "pEUvRODrx-hover": { children: /* @__PURE__ */ _jsx5(React3.Fragment, { children: /* @__PURE__ */ _jsx5(motion3.p, { dir: "auto", style: { "--framer-line-height": "1em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-TKPnz_Ntl-TxRF350hk))" }, children: "Explore Properties" }) }) } }, baseVariant, gestureVariant) }), isDisplayed(Z4jhW3SAq !== false) && /* @__PURE__ */ _jsx5(tL6Nru9eO_default, { animated: true, className: "framer-87rq2l", layoutDependency, layoutId: "CTA__pi6Oi1xxo", style: { "--1m6trwb": 0, "--21h8s6": ndsT4W1CC, "--pgex8v": 1 }, variants: { "pEUvRODrx-hover": { "--21h8s6": TKPnz_Ntl } } })] }) }) }) }) });
});
var css5 = [".framer-xYTrY.framer-tyhx9i, .framer-xYTrY .framer-tyhx9i { display: block; }", ".framer-xYTrY.framer-1v3j1ym { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 9px 16px 9px 28px; position: relative; text-decoration: none; width: min-content; }", ".framer-xYTrY .framer-nw5h50 { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-xYTrY .framer-87rq2l { aspect-ratio: 1 / 1; flex: none; height: auto; position: relative; width: 40px; }", ".framer-xYTrY.framer-v-1a38zcf.framer-1v3j1ym { padding: 9px 16px 9px 16px; }", '.framer-xYTrY[data-border="true"]::after, .framer-xYTrY [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerTxRF350hk = withCSS3(Component3, css5, "framer-xYTrY");
var TxRF350hk_default = FramerTxRF350hk;
FramerTxRF350hk.displayName = "Button";
FramerTxRF350hk.defaultProps = { height: 58, width: 223 };
addPropertyControls4(FramerTxRF350hk, { variant: { options: ["pEUvRODrx", "c2M0D2Gk6"], optionTitles: ["Variant 1", "Variant 2"], title: "Variant", type: ControlType4.Enum }, Nk9CQOGHG: { defaultValue: "Explore Properties", displayTextArea: false, title: "Text", type: ControlType4.String }, onNk9CQOGHGChange: { changes: "Nk9CQOGHG", type: ControlType4.ChangeHandler }, Cfh8Zxf9C: { defaultValue: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', title: "Default Background Color", type: ControlType4.Color }, ndsT4W1CC: { defaultValue: "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))", title: "Default Text Color", type: ControlType4.Color }, G1Aueh5gp: { defaultValue: { borderColor: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', borderStyle: "solid", borderWidth: 1 }, title: "Default Border", type: ControlType4.Border }, LTaRf1Os4: { defaultValue: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', title: "Hover Background Color", type: ControlType4.Color }, TKPnz_Ntl: { defaultValue: "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))", title: "Hover Text Color", type: ControlType4.Color }, KakYM8inN: { defaultValue: { borderColor: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', borderStyle: "solid", borderWidth: 1 }, title: "Hover Border", type: ControlType4.Border }, Z4jhW3SAq: { defaultValue: true, title: "Arrow", type: ControlType4.Boolean }, onZ4jhW3SAqChange: { changes: "Z4jhW3SAq", type: ControlType4.ChangeHandler }, hCv5Bj5Nx: { title: "Link", type: ControlType4.Link }, Z_YhYkC46: { defaultValue: false, title: "New Tab", type: ControlType4.Boolean }, onZ_YhYkC46Change: { changes: "Z_YhYkC46", type: ControlType4.ChangeHandler } });
addFonts2(FramerTxRF350hk, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...ArrowSquareRightFonts], { supportsExplicitInterCodegen: true });

// http-url:https://framerusercontent.com/modules/EXTm6TFCkgnt2NUaAG5N/n7VrfP5SJtq24AoyMA2A/p0FiMnMQZ.js
var ButtonFonts = getFonts2(TxRF350hk_default);
var ImageParallaxFonts = getFonts2(ImageParallax);
var cycleOrder2 = ["C4nZld9J5", "fao3owaJ2"];
var serializationHash3 = "framer-ZXfLe";
var variantClassNames3 = { C4nZld9J5: "framer-v-1tzrd9d", fao3owaJ2: "framer-v-1ui6cg6" };
function addPropertyOverrides2(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition13 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var animation = { opacity: 1e-3, rotate: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 10 };
var transition2 = { bounce: 0, delay: 0.075, duration: 0.4, type: "spring" };
var textEffect = { effect: animation, repeat: false, startDelay: 0.1, threshold: 0.5, tokenization: "word", transition: transition2, trigger: "onInView", type: "appear" };
var matchVariant = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var Transition3 = ({ value, children }) => {
  const config = React4.useContext(MotionConfigContext3);
  const transition = value ?? config.transition;
  const contextValue = React4.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx6(MotionConfigContext3.Provider, { value: contextValue, children });
};
var humanReadableVariantMap2 = { Desktop: "C4nZld9J5", Mobile: "fao3owaJ2" };
var Variants3 = motion4.create(React4.Fragment);
var useStateVariable = (externalState, setExternalState) => {
  const [internalState, setInternalState] = React4.useState(externalState);
  const [previousExternalState, setPreviousExternalState] = React4.useState(externalState);
  if (setExternalState) {
    return [externalState, setExternalState];
  }
  if (externalState !== previousExternalState) {
    setInternalState(externalState);
    setPreviousExternalState(externalState);
  }
  return [internalState, setInternalState];
};
var getProps4 = ({ backgroundImg, button1Link, button1Text, button2Link, button2Text, height, id, preTitle, title, width, ...props }) => {
  return { ...props, a06Zx2E0v: backgroundImg ?? props.a06Zx2E0v ?? { pixelHeight: 1280, pixelWidth: 1920, src: "https://framerusercontent.com/images/2WO8RVCZkPlSSq9UT7OigQ25ino.jpg?width=1920&height=1280", srcSet: "https://framerusercontent.com/images/2WO8RVCZkPlSSq9UT7OigQ25ino.jpg?scale-down-to=512&width=1920&height=1280 512w,https://framerusercontent.com/images/2WO8RVCZkPlSSq9UT7OigQ25ino.jpg?scale-down-to=1024&width=1920&height=1280 1024w,https://framerusercontent.com/images/2WO8RVCZkPlSSq9UT7OigQ25ino.jpg?width=1920&height=1280 1920w" }, aHEq_BHJu: button2Text ?? props.aHEq_BHJu ?? "Explore Properties", cuubPZsE8: button1Link ?? props.cuubPZsE8, h6A2HpCph: button1Text ?? props.h6A2HpCph ?? "Contact Us", hbZ_0WaxW: title ?? props.hbZ_0WaxW ?? "More Than Real Estate", kDXlCE5nW: preTitle ?? props.kDXlCE5nW ?? "Why Choose Us?", variant: humanReadableVariantMap2[props.variant] ?? props.variant ?? "C4nZld9J5", WQXZcG0lm: button2Link ?? props.WQXZcG0lm };
};
var createLayoutDependency3 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component4 = /* @__PURE__ */ React4.forwardRef(function(props, ref) {
  const fallbackRef = useRef4(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React4.useId();
  const { activeLocale, setLocale } = useLocaleInfo3();
  const componentViewport = useComponentViewport3();
  const { style, className: className3, layoutId, variant, kDXlCE5nW, hbZ_0WaxW, "h6A2HpCph": externalh6A2HpCph, "onh6A2HpCphChange": setExternalh6A2HpCph, cuubPZsE8, "aHEq_BHJu": externalaHEq_BHJu, "onaHEq_BHJuChange": setExternalaHEq_BHJu, WQXZcG0lm, a06Zx2E0v, ...restProps } = getProps4(props);
  const [h6A2HpCph, seth6A2HpCph] = useStateVariable(externalh6A2HpCph, setExternalh6A2HpCph);
  const [aHEq_BHJu, setaHEq_BHJu] = useStateVariable(externalaHEq_BHJu, setExternalaHEq_BHJu);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState3({ cycleOrder: cycleOrder2, defaultVariant: "C4nZld9J5", ref: refBinding, variant, variantClassNames: variantClassNames3 });
  const layoutDependency = createLayoutDependency3(props, variants);
  const sharedStyleClassNames = [className2, className];
  const scopingClassNames = cx4(serializationHash3, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx6(LayoutGroup3, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx6(Variants3, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx6(Transition3, { value: transition13, children: /* @__PURE__ */ _jsxs4(motion4.div, { ...restProps, ...gestureHandlers, className: cx4(scopingClassNames, "framer-1tzrd9d", className3, classNames), "data-framer-name": "Desktop", layoutDependency, layoutId: "CTA__C4nZld9J5", ref: refBinding, style: { backgroundColor: "rgb(0, 0, 0)", ...style }, ...addPropertyOverrides2({ fao3owaJ2: { "data-framer-name": "Mobile" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs4(motion4.div, { className: "framer-y6olc", "data-framer-name": "Wrapper", layoutDependency, layoutId: "CTA__txHHZlZGL", children: [/* @__PURE__ */ _jsxs4(motion4.div, { className: "framer-9dqo30", "data-framer-name": "Title", layoutDependency, layoutId: "CTA__iepkVO0FN", children: [/* @__PURE__ */ _jsx6(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx6(React4.Fragment, { children: /* @__PURE__ */ _jsx6(motion4.p, { className: "framer-styles-preset-l29348", "data-styles-preset": "NMDJoczM8", dir: "auto", children: "Why Choose Us?" }) }), className: "framer-gvzykf", effect: textEffect, fonts: ["Inter"], layoutDependency, layoutId: "CTA__tEZd7rr5z", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: kDXlCE5nW, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx6(RichText3, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx6(React4.Fragment, { children: /* @__PURE__ */ _jsx6(motion4.h2, { className: "framer-styles-preset-1mwhg4q", "data-styles-preset": "DQGL3_cw0", dir: "auto", style: { "--framer-text-alignment": "center" }, children: "More Than Real Estate" }) }), className: "framer-1akbue3", effect: textEffect, fonts: ["Inter"], layoutDependency, layoutId: "CTA__hFegwcSU4", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: hbZ_0WaxW, verticalAlignment: "top", withExternalLayout: true })] }), /* @__PURE__ */ _jsxs4(motion4.div, { className: "framer-12srhly", layoutDependency, layoutId: "CTA__ovvVnNBj5", children: [/* @__PURE__ */ _jsx6(ComponentViewportProvider, { height: 58, y: (componentViewport?.y || 0) + (190 + ((componentViewport?.height || 625) - 380 - 322) / 2) + 0 + 264 + 0, ...addPropertyOverrides2({ fao3owaJ2: { y: (componentViewport?.y || 0) + (60 + ((componentViewport?.height || 477) - 150 - 356) / 2) + 0 + 216 + 0 + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx6(SmartComponentScopedContainer, { className: "framer-j9atzg-container", layoutDependency, layoutId: "CTA__ScwZ8r_kG-container", nodeId: "ScwZ8r_kG", rendersWithMotion: true, scopeId: "p0FiMnMQZ", children: /* @__PURE__ */ _jsx6(TxRF350hk_default, { Cfh8Zxf9C: "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", G1Aueh5gp: { borderColor: "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", borderStyle: "solid", borderWidth: 1 }, hCv5Bj5Nx: cuubPZsE8, height: "100%", id: "ScwZ8r_kG", KakYM8inN: { borderColor: "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", borderStyle: "solid", borderWidth: 1 }, layoutId: "CTA__ScwZ8r_kG", LTaRf1Os4: "rgba(240, 236, 228, 0)", ndsT4W1CC: "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))", Nk9CQOGHG: h6A2HpCph, onNk9CQOGHGChange: seth6A2HpCph, TKPnz_Ntl: "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", variant: matchVariant("pEUvRODrx"), width: "100%", Z_YhYkC46: false, Z4jhW3SAq: true }) }) }), /* @__PURE__ */ _jsx6(ComponentViewportProvider, { height: 58, y: (componentViewport?.y || 0) + (190 + ((componentViewport?.height || 625) - 380 - 322) / 2) + 0 + 264 + 0, ...addPropertyOverrides2({ fao3owaJ2: { y: (componentViewport?.y || 0) + (60 + ((componentViewport?.height || 477) - 150 - 356) / 2) + 0 + 216 + 0 + 82 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx6(SmartComponentScopedContainer, { className: "framer-41pmxq-container", layoutDependency, layoutId: "CTA__zAJUAg23A-container", nodeId: "zAJUAg23A", rendersWithMotion: true, scopeId: "p0FiMnMQZ", children: /* @__PURE__ */ _jsx6(TxRF350hk_default, { Cfh8Zxf9C: "rgba(240, 236, 228, 0)", G1Aueh5gp: { borderColor: "rgba(240, 236, 228, 0)", borderStyle: "solid", borderWidth: 1 }, hCv5Bj5Nx: WQXZcG0lm, height: "100%", id: "zAJUAg23A", KakYM8inN: { borderColor: "rgba(240, 236, 228, 0)", borderStyle: "solid", borderWidth: 1 }, layoutId: "CTA__zAJUAg23A", LTaRf1Os4: "rgba(240, 236, 228, 0)", ndsT4W1CC: "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", Nk9CQOGHG: aHEq_BHJu, onNk9CQOGHGChange: setaHEq_BHJu, TKPnz_Ntl: "var(--token-b05544d6-f7d2-46a2-82e4-5fe4fef57d80, rgb(245, 245, 245))", variant: matchVariant("pEUvRODrx"), width: "100%", Z_YhYkC46: false, Z4jhW3SAq: false, ...addPropertyOverrides2({ fao3owaJ2: { variant: matchVariant("c2M0D2Gk6") } }, baseVariant, gestureVariant) }) }) })] })] }), /* @__PURE__ */ _jsx6(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx6(SmartComponentScopedContainer, { className: "framer-petg6r-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "CTA__yNkeG3QvC-container", nodeId: "yNkeG3QvC", rendersWithMotion: true, scopeId: "p0FiMnMQZ", style: { filter: "brightness(0.35)", mask: "linear-gradient(0deg, rgba(0,0,0,0) -63%, rgba(0,0,0,1) 68%) add", WebkitFilter: "brightness(0.35)", WebkitMask: "linear-gradient(0deg, rgba(0,0,0,0) -63%, rgba(0,0,0,1) 68%) add" }, children: /* @__PURE__ */ _jsx6(ImageParallax, { borderRadius: "0px", boxShadow: "", height: "100%", horizontalParallaxAmount: 0, id: "yNkeG3QvC", image: toResponsiveImage(a06Zx2E0v), layoutId: "CTA__yNkeG3QvC", style: { height: "100%", width: "100%" }, verticalParallaxAmount: 20, width: "100%" }) }) })] }) }) }) });
});
var css6 = [".framer-ZXfLe.framer-176wany, .framer-ZXfLe .framer-176wany { display: block; }", ".framer-ZXfLe.framer-1tzrd9d { align-content: center; align-items: center; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 190px 48px 190px 48px; position: relative; width: 100%; }", ".framer-ZXfLe .framer-y6olc { align-content: center; align-items: center; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 48px; height: min-content; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: 1px; z-index: 3; }", ".framer-ZXfLe .framer-9dqo30 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 48px; height: min-content; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-ZXfLe .framer-gvzykf { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; }", ".framer-ZXfLe .framer-1akbue3 { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; z-index: 1; }", ".framer-ZXfLe .framer-12srhly { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 12px; height: min-content; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: min-content; }", ".framer-ZXfLe .framer-j9atzg-container, .framer-ZXfLe .framer-41pmxq-container { flex: none; height: auto; position: relative; width: auto; z-index: 1; }", ".framer-ZXfLe .framer-petg6r-container { flex: none; height: 100%; left: calc(50.00000000000002% - 100% / 2); position: absolute; top: calc(49.908925318761405% - 100% / 2); width: 100%; z-index: 1; }", ".framer-ZXfLe.framer-v-1ui6cg6.framer-1tzrd9d { padding: 60px 24px 90px 24px; width: 100%; }", ".framer-ZXfLe.framer-v-1ui6cg6 .framer-y6olc, .framer-ZXfLe.framer-v-1ui6cg6 .framer-9dqo30 { gap: 24px; }", ".framer-ZXfLe.framer-v-1ui6cg6 .framer-1akbue3 { --framer-text-wrap-override: balance; }", ".framer-ZXfLe.framer-v-1ui6cg6 .framer-12srhly { flex-direction: column; gap: 24px; }", ".framer-ZXfLe.framer-v-1ui6cg6 .framer-petg6r-container { left: 0px; top: 0px; }", ...css3, ...css2];
var Framerp0FiMnMQZ = withCSS4(Component4, css6, "framer-ZXfLe");
var p0FiMnMQZ_default = Framerp0FiMnMQZ;
Framerp0FiMnMQZ.displayName = "CTA";
Framerp0FiMnMQZ.defaultProps = { height: 625, width: 1200 };
addPropertyControls5(Framerp0FiMnMQZ, { variant: { options: ["C4nZld9J5", "fao3owaJ2"], optionTitles: ["Desktop", "Mobile"], title: "Variant", type: ControlType5.Enum }, kDXlCE5nW: { defaultValue: "Why Choose Us?", displayTextArea: false, title: "Pre Title", type: ControlType5.String }, onkDXlCE5nWChange: { changes: "kDXlCE5nW", type: ControlType5.ChangeHandler }, hbZ_0WaxW: { defaultValue: "More Than Real Estate", displayTextArea: false, title: "Title", type: ControlType5.String }, onhbZ_0WaxWChange: { changes: "hbZ_0WaxW", type: ControlType5.ChangeHandler }, h6A2HpCph: { defaultValue: "Contact Us", displayTextArea: false, title: "Button 1: Text", type: ControlType5.String }, onh6A2HpCphChange: { changes: "h6A2HpCph", type: ControlType5.ChangeHandler }, cuubPZsE8: { title: "Button 1: Link", type: ControlType5.Link }, aHEq_BHJu: { defaultValue: "Explore Properties", displayTextArea: false, title: "Button 2: Text", type: ControlType5.String }, onaHEq_BHJuChange: { changes: "aHEq_BHJu", type: ControlType5.ChangeHandler }, WQXZcG0lm: { title: "Button 2: Link", type: ControlType5.Link }, a06Zx2E0v: { __defaultAssetReference: "data:framer/asset-reference,2WO8RVCZkPlSSq9UT7OigQ25ino.jpg?originalFilename=INT_bedroom_02.jpg&width=1920&height=1280", title: "Background Img", type: ControlType5.ResponsiveImage } });
addFonts3(Framerp0FiMnMQZ, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...ButtonFonts, ...ImageParallaxFonts, ...getFontsFromSharedStyle(fonts2), ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });
Framerp0FiMnMQZ.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader(TxRF350hk_default, {}, context)]);
} };
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "Framerp0FiMnMQZ", "slots": [], "annotations": { "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"fao3owaJ2":{"layout":["fixed","auto"]}}}', "framerDisplayContentsDiv": "false", "framerColorSyntax": "true", "framerComponentViewportWidth": "true", "framerIntrinsicHeight": "625", "framerAutoSizeImages": "true", "framerContractVersion": "1", "framerImmutableVariables": "true", "framerVariables": '{"kDXlCE5nW":"preTitle","hbZ_0WaxW":"title","h6A2HpCph":"button1Text","cuubPZsE8":"button1Link","aHEq_BHJu":"button2Text","WQXZcG0lm":"button2Link","a06Zx2E0v":"backgroundImg"}', "framerIntrinsicWidth": "1200" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  p0FiMnMQZ_default as default
};
