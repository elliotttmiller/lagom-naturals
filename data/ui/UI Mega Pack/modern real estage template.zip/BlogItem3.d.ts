export interface Blogitem3Props {
  /**
   * Date — pass as `dk9dT5SbZ` not `date`.
   * @default "2026-01-18T00:00:00.000Z"
   */
  dk9dT5SbZ?: string;
  ondk9dT5SbZChange?: string;
  /**
   * Title — pass as `Mpyg8Akhv` not `title`.
   * @default "Manhattan Luxury in 2026"
   */
  Mpyg8Akhv?: string;
  onMpyg8AkhvChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
