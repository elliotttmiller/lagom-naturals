export interface Mobile6Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Filter Closed" → pdj5NuuWI
   *   "Filter Open" → v5yTW9O2P
   */
  variant?: 'Filter Closed' | 'Filter Open' | 'pdj5NuuWI' | 'v5yTW9O2P';
  /**
   * Neighborhood — pass as `P6z0JIRMJ` not `neighborhood`.
   */
  P6z0JIRMJ?: string;
  onP6z0JIRMJChange?: string;
  onM6LL6wqdbChange?: string;
  onWCb6OR1qXChange?: string;
  onHjjcNQaOhChange?: string;
  onkltzQ3Mr2Change?: string;
  /**
   * Neighborhood Visible — pass as `QPQ3fC_Vi` not `neighborhoodVisible`.
   * @default true
   */
  QPQ3fC_Vi?: boolean;
  onQPQ3fC_ViChange?: string;
  /**
   * Beds Visible — pass as `WuEv3bmIC` not `bedsVisible`.
   * @default true
   */
  WuEv3bmIC?: boolean;
  onWuEv3bmICChange?: string;
  /**
   * Price Visible — pass as `z0TnQ_RXR` not `priceVisible`.
   * @default true
   */
  z0TnQ_RXR?: boolean;
  onz0TnQ_RXRChange?: string;
  /**
   * Type Visible — pass as `l5Nve3h5q` not `typeVisible`.
   * @default true
   */
  l5Nve3h5q?: boolean;
  onl5Nve3h5qChange?: string;
  /**
   * Status Visible — pass as `Xr2hvMScG` not `statusVisible`.
   * @default true
   */
  Xr2hvMScG?: boolean;
  onXr2hvMScGChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
