var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/f8jH5VlKA2dd1da5rl60/UEsa3n4GntS8CWjQ7hX9/aCBonhQLl.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ComponentViewportProvider, ControlType as ControlType2, cx, getFonts, RichText, SmartComponentScopedContainer, useComponentViewport, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/sIxZFVxIOBdfeANYhkj2/lGu9VayhxpYD2v9lbKlh/AnimatedCounter.js
import { jsx as _jsx } from "react/jsx-runtime";
import { animate, motion, useInView } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import { addPropertyControls, ControlType, RenderTarget } from "./_framer-runtime.js";
function AnimatedCounter(props) {
  const { from, to, duration, decimalPlaces, decimalSeparator, font: { fontFamily, fontWeight, fontSize, lineHeight, letterSpacing, textAlign }, color, playOnLoad, once, animationType } = props;
  const ref = useRef(null);
  const isCanvas = RenderTarget.current() === RenderTarget.canvas;
  const ariaLabel = `Counter ends at ${to}`;
  const isInView = useInView(ref, { once });
  const [hasAnimated, setHasAnimated] = useState(false);
  const [displayValue, setDisplayValue] = useState(() => formatNumber(from));
  function formatNumber(value) {
    let formattedNumber = value.toFixed(decimalPlaces).replace(".", decimalSeparator);
    return formattedNumber;
  }
  useEffect(() => {
    if (!isCanvas && (playOnLoad || isInView) && !hasAnimated) {
      const animationControl = animate(from, to, { duration, ease: animationType === "smooth" ? "easeInOut" : "linear", onUpdate: (latest) => {
        setDisplayValue(formatNumber(latest));
      }, onComplete: () => {
        if (once) {
          setHasAnimated(true);
        }
      } });
      return () => animationControl.stop();
    }
  }, [from, to, duration, decimalPlaces, decimalSeparator, playOnLoad, isInView, animationType, once, hasAnimated]);
  return /* @__PURE__ */ _jsx(motion.div, { ref, initial: { opacity: isCanvas ? 1 : 0 }, whileInView: { opacity: 1 }, style: { fontFamily, fontWeight, fontSize, lineHeight, letterSpacing, textAlign, color, fontVariantNumeric: "tabular-nums", userSelect: "none" }, "aria-label": ariaLabel, children: isCanvas ? formatNumber(to) : displayValue });
}
AnimatedCounter.defaultProps = { from: 0, to: 24, duration: 5, decimalPlaces: 0, decimalSeparator: ".", font: { fontFamily: "Manrope", fontWeight: "400", fontSize: 40, lineHeight: "1.5em", letterSpacing: "normal", textAlign: "left" }, color: "#FFF", playOnLoad: true, once: true, animationType: "smooth" };
addPropertyControls(AnimatedCounter, { from: { type: ControlType.Number, title: "From", defaultValue: 0, min: 0, step: 0.1, displayStepper: true }, to: { type: ControlType.Number, title: "To", defaultValue: 16, min: 0, step: 0.1, displayStepper: true }, animationType: { type: ControlType.Enum, title: "Animation Type", defaultValue: "smooth", options: ["smooth", "linear"], optionTitles: ["Smooth", "Linear"] }, duration: { type: ControlType.Number, title: "Duration", defaultValue: 2.5, min: 0, step: 0.1, displayStepper: true }, decimalPlaces: { type: ControlType.Number, displayStepper: true, title: "Decimal Places", defaultValue: 0, min: 0, max: 2, step: 1 }, decimalSeparator: { type: ControlType.Enum, title: "\u21B3 Separator", defaultValue: ".", options: [".", ","], optionTitles: [".", ","], hidden: ({ decimalPlaces }) => decimalPlaces === 0 }, font: { type: ControlType.Font, title: "Font", controls: "extended", defaultValue: { fontFamily: "Manrope", fontWeight: "400", fontSize: 64, lineHeight: "1.5em", letterSpacing: "Medium", textAlign: "left" }, displayFontSize: true, displayTextAlignment: false, defaultFontType: "monospace" }, color: { type: ControlType.Color, title: "Color", defaultValue: "#FFF" }, once: { type: ControlType.Boolean, title: "Once", defaultValue: true, enabledTitle: "Yes", disabledTitle: "No" }, playOnLoad: { type: ControlType.Boolean, title: "Play on Load", defaultValue: true, enabledTitle: "Yes", disabledTitle: "No", description: `
        
        *from framer.today*
 [License](https://framer.today/license)
    ` } });

// http-url:https://framerusercontent.com/modules/f8jH5VlKA2dd1da5rl60/UEsa3n4GntS8CWjQ7hX9/aCBonhQLl.js
var AnimatedCounterFonts = getFonts(AnimatedCounter);
var cycleOrder = ["BZLIOfgn_", "NtSH2yqEJ", "gzIeKZMZ7"];
var serializationHash = "framer-QinJf";
var variantClassNames = { BZLIOfgn_: "framer-v-icrd3j", gzIeKZMZ7: "framer-v-1sxfz2r", NtSH2yqEJ: "framer-v-1mtnkdu" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "Variant 3": "gzIeKZMZ7", Default: "BZLIOfgn_", Mobile: "NtSH2yqEJ" };
var Variants = motion2.create(React.Fragment);
var getProps = ({ color, from1, height, id, rightText, showRightText, subtitle, to, width, ...props }) => {
  return { ...props, FyjYDALhf: color ?? props.FyjYDALhf ?? "rgb(255, 255, 255)", JBDXOdsnT: from1 ?? props.JBDXOdsnT, K_RTEg_tC: showRightText ?? props.K_RTEg_tC ?? true, mcxfqk1GE: to ?? props.mcxfqk1GE ?? 100, QIJl52EuD: subtitle ?? props.QIJl52EuD ?? "Projects Completed", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "BZLIOfgn_", xSMrnq17d: rightText ?? props.xSMrnq17d ?? "+" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, JBDXOdsnT, mcxfqk1GE, FyjYDALhf, QIJl52EuD, K_RTEg_tC, xSMrnq17d, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "BZLIOfgn_", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion2.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-icrd3j", className, classNames), "data-framer-name": "Default", layoutDependency, layoutId: "Stats__BZLIOfgn_", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ gzIeKZMZ7: { "data-framer-name": "Variant 3" }, NtSH2yqEJ: { "data-framer-name": "Mobile" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs(motion2.div, { className: "framer-1iwx2eq", "data-framer-name": "Stats Wrapper", layoutDependency, layoutId: "Stats__Jlm5aXWRL", children: [/* @__PURE__ */ _jsx2(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx2(SmartComponentScopedContainer, { className: "framer-1ac7zir-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "Stats__mgzBfo4oj-container", nodeId: "mgzBfo4oj", rendersWithMotion: true, scopeId: "aCBonhQLl", children: /* @__PURE__ */ _jsx2(AnimatedCounter, { animationType: "smooth", color: FyjYDALhf, decimalPlaces: 0, decimalSeparator: ".", duration: 2.5, font: { fontFamily: '"Italiana", "Italiana Placeholder", sans-serif', fontSize: "90px", fontStyle: "normal", fontWeight: 400, letterSpacing: "0em", lineHeight: "1.5em" }, from: JBDXOdsnT, height: "100%", id: "mgzBfo4oj", layoutId: "Stats__mgzBfo4oj", once: true, playOnLoad: false, to: mcxfqk1GE, width: "100%", ...addPropertyOverrides({ gzIeKZMZ7: { font: { fontFamily: '"Italiana", "Italiana Placeholder", sans-serif', fontSize: "130px", fontStyle: "normal", fontWeight: 400, letterSpacing: "0em", lineHeight: "1.5em" } }, NtSH2yqEJ: { font: { fontFamily: '"Italiana", "Italiana Placeholder", sans-serif', fontSize: "46px", fontStyle: "normal", fontWeight: 400, letterSpacing: "0em", lineHeight: "1.5em" } } }, baseVariant, gestureVariant) }) }) }), K_RTEg_tC !== false && /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { dir: "auto", style: { "--framer-font-size": "36px", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-aa095fac-713d-4396-9a0e-1f9bd34a3c33, rgba(255, 255, 255, 0.75)))" }, children: "+" }) }), className: "framer-1bckltu", fonts: ["Inter"], layoutDependency, layoutId: "Stats__OebjCvwoI", style: { "--extracted-r6o4lv": "var(--token-aa095fac-713d-4396-9a0e-1f9bd34a3c33, rgba(255, 255, 255, 0.75))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: xSMrnq17d, verticalAlignment: "top", withExternalLayout: true })] }), /* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, var(--token-aa095fac-713d-4396-9a0e-1f9bd34a3c33, rgba(255, 255, 255, 0.75)))" }, children: "Projects Completed" }) }), className: "framer-za3t6p", fonts: ["Inter"], layoutDependency, layoutId: "Stats__wEbmAgPVf", style: { "--extracted-r6o4lv": "var(--token-aa095fac-713d-4396-9a0e-1f9bd34a3c33, rgba(255, 255, 255, 0.75))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: QIJl52EuD, verticalAlignment: "top", withExternalLayout: true })] }) }) }) });
});
var css = [".framer-QinJf.framer-1by5wt9, .framer-QinJf .framer-1by5wt9 { display: block; }", ".framer-QinJf.framer-icrd3j { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: min-content; }", ".framer-QinJf .framer-1iwx2eq { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: min-content; }", ".framer-QinJf .framer-1ac7zir-container { flex: none; height: auto; position: relative; width: auto; }", ".framer-QinJf .framer-1bckltu, .framer-QinJf .framer-za3t6p { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-QinJf.framer-v-1mtnkdu.framer-icrd3j { align-content: center; align-items: center; }"];
var FrameraCBonhQLl = withCSS(Component, css, "framer-QinJf");
var aCBonhQLl_default = FrameraCBonhQLl;
FrameraCBonhQLl.displayName = "Stats";
FrameraCBonhQLl.defaultProps = { height: 164, width: 182 };
addPropertyControls2(FrameraCBonhQLl, { variant: { options: ["BZLIOfgn_", "NtSH2yqEJ", "gzIeKZMZ7"], optionTitles: ["Default", "Mobile", "Variant 3"], title: "Variant", type: ControlType2.Enum }, JBDXOdsnT: { defaultValue: 0, displayStepper: true, min: 0, step: 0.1, title: "From", type: ControlType2.Number }, onJBDXOdsnTChange: { changes: "JBDXOdsnT", type: ControlType2.ChangeHandler }, mcxfqk1GE: { defaultValue: 100, displayStepper: true, min: 0, step: 0.1, title: "To", type: ControlType2.Number }, onmcxfqk1GEChange: { changes: "mcxfqk1GE", type: ControlType2.ChangeHandler }, FyjYDALhf: { defaultValue: "rgb(255, 255, 255)", title: "Color", type: ControlType2.Color }, QIJl52EuD: { defaultValue: "Projects Completed", displayTextArea: false, title: "Subtitle", type: ControlType2.String }, onQIJl52EuDChange: { changes: "QIJl52EuD", type: ControlType2.ChangeHandler }, K_RTEg_tC: { defaultValue: true, title: "Show Right Text", type: ControlType2.Boolean }, onK_RTEg_tCChange: { changes: "K_RTEg_tC", type: ControlType2.ChangeHandler }, xSMrnq17d: { defaultValue: "+", displayTextArea: false, title: "Right Text", type: ControlType2.String }, onxSMrnq17dChange: { changes: "xSMrnq17d", type: ControlType2.ChangeHandler } });
addFonts(FrameraCBonhQLl, [{ explicitInter: true, fonts: [{ cssFamilyName: "Italiana", source: "google", style: "normal", uiFamilyName: "Italiana", url: "https://fonts.gstatic.com/s/italiana/v21/QldNNTtLsx4E__B0XTmUY31Wx7Vv.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...AnimatedCounterFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FrameraCBonhQLl", "slots": [], "annotations": { "framerColorSyntax": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"NtSH2yqEJ":{"layout":["auto","auto"]},"gzIeKZMZ7":{"layout":["auto","auto"]}}}', "framerComponentViewportWidth": "true", "framerContractVersion": "1", "framerVariables": '{"JBDXOdsnT":"from1","mcxfqk1GE":"to","FyjYDALhf":"color","QIJl52EuD":"subtitle","K_RTEg_tC":"showRightText","xSMrnq17d":"rightText"}', "framerImmutableVariables": "true", "framerAutoSizeImages": "true", "framerIntrinsicWidth": "182", "framerIntrinsicHeight": "164", "framerDisplayContentsDiv": "false" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  aCBonhQLl_default as default
};
