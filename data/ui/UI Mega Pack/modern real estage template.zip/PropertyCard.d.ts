export interface PropertycardProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop" → KrXK5c21W
   *   "Mobile" → YoQ6o4TTZ
   */
  variant?: 'Desktop' | 'Mobile' | 'KrXK5c21W' | 'YoQ6o4TTZ';
  /**
   * Adress — pass as `QtMrGcNQV` not `adress`.
   * @default "Luxury Estate in Beverly Hills"
   */
  QtMrGcNQV?: string;
  onQtMrGcNQVChange?: string;
  /**
   * Beds — pass as `j9rC9mkba` not `beds`.
   * @default "5"
   */
  j9rC9mkba?: string;
  onj9rC9mkbaChange?: string;
  /**
   * Bathrooms — pass as `VfmKkO_vq` not `bathrooms`.
   * @default "4"
   */
  VfmKkO_vq?: string;
  onVfmKkO_vqChange?: string;
  /**
   * Garage — pass as `id2LkMUei` not `garage`.
   * @default "4"
   */
  id2LkMUei?: string;
  onid2LkMUeiChange?: string;
  /**
   * Total Area — pass as `pOkgzCxVu` not `totalArea`.
   * @default "4,500 SQ.FT"
   */
  pOkgzCxVu?: string;
  onpOkgzCxVuChange?: string;
  /**
   * Price — pass as `zYvbSEnSw` not `price`.
   * @default "$2,500,000"
   */
  zYvbSEnSw?: string;
  onzYvbSEnSwChange?: string;
  /**
   * Image — pass as `j57J_hKu6` not `image`.
   */
  j57J_hKu6?: string;
  /**
   * Image Hover — pass as `zUZO1GxcQ` not `imageHover`.
   */
  zUZO1GxcQ?: string;
  /**
   * Link — pass as `NCpshDBG8` not `link`.
   */
  NCpshDBG8?: string;
  /**
   * Second line adress — pass as `Dl7qrgX6T` not `secondLineAdress`.
   * @default "Luxury Estate in Beverly Hills"
   */
  Dl7qrgX6T?: string;
  onDl7qrgX6TChange?: string;
  onrMCEi3aXLChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
