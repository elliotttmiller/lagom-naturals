var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/lq4ZrA7Ossc920b6RHy8/1EbxAec064m13Rieawug/zBF9Zr7zY.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls, ControlType, cx, getFontsFromSharedStyle, getLoadingLazyAtYPosition, Image as Image1, RichText, useComponentViewport, useLocaleCode, useLocaleInfo, useVariantState, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/cvzOWjlRJ7BWKs2uzp7O/msT0lFU6X44FAkjq19DZ/ORljPUa5H.js
import { fontStore } from "./_framer-runtime.js";
fontStore.loadFonts(["GF;Playfair Display-regular", "GF;Playfair Display-700", "GF;Playfair Display-700italic", "GF;Playfair Display-italic"]);
var fonts = [{ explicitInter: true, fonts: [{ cssFamilyName: "Playfair Display", openType: true, source: "google", style: "normal", uiFamilyName: "Playfair Display", url: "https://fonts.gstatic.com/s/playfairdisplay/v40/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvUDVZNLo_U2r.woff2", weight: "400" }, { cssFamilyName: "Playfair Display", openType: true, source: "google", style: "normal", uiFamilyName: "Playfair Display", url: "https://fonts.gstatic.com/s/playfairdisplay/v40/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKeiukDVZNLo_U2r.woff2", weight: "700" }, { cssFamilyName: "Playfair Display", openType: true, source: "google", style: "italic", uiFamilyName: "Playfair Display", url: "https://fonts.gstatic.com/s/playfairdisplay/v40/nuFRD-vYSZviVYUb_rj3ij__anPXDTnCjmHKM4nYO7KN_k-UbtPK-F2rA0s.woff2", weight: "700" }, { cssFamilyName: "Playfair Display", openType: true, source: "google", style: "italic", uiFamilyName: "Playfair Display", url: "https://fonts.gstatic.com/s/playfairdisplay/v40/nuFRD-vYSZviVYUb_rj3ij__anPXDTnCjmHKM4nYO7KN_qiTbtPK-F2rA0s.woff2", weight: "400" }] }];
var css = [`.framer-fTBSf .framer-styles-preset-z65n4z:not(.rich-text-wrapper), .framer-fTBSf .framer-styles-preset-z65n4z.rich-text-wrapper h3 { --framer-font-family: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-family-bold: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-family-bold-italic: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-family-italic: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 32px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0.05em; --framer-line-height: 1.4em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: #e8e8e8; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; }`, `@media (max-width: 1199px) and (min-width: 810px) { .framer-fTBSf .framer-styles-preset-z65n4z:not(.rich-text-wrapper), .framer-fTBSf .framer-styles-preset-z65n4z.rich-text-wrapper h3 { --framer-font-family: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-family-bold: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-family-bold-italic: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-family-italic: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 28px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0.05em; --framer-line-height: 1.4em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: #e8e8e8; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }`, `@media (max-width: 809px) and (min-width: 0px) { .framer-fTBSf .framer-styles-preset-z65n4z:not(.rich-text-wrapper), .framer-fTBSf .framer-styles-preset-z65n4z.rich-text-wrapper h3 { --framer-font-family: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-family-bold: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-family-bold-italic: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-family-italic: "Playfair Display", "Playfair Display Placeholder", serif; --framer-font-open-type-features: 'blwf' on, 'cv03' on, 'cv04' on, 'cv09' on, 'cv11' on; --framer-font-size: 26px; --framer-font-style: normal; --framer-font-style-bold: normal; --framer-font-style-bold-italic: italic; --framer-font-style-italic: italic; --framer-font-variation-axes: normal; --framer-font-weight: 400; --framer-font-weight-bold: 700; --framer-font-weight-bold-italic: 700; --framer-font-weight-italic: 400; --framer-letter-spacing: 0.05em; --framer-line-height: 1.4em; --framer-paragraph-spacing: 20px; --framer-text-alignment: start; --framer-text-color: #e8e8e8; --framer-text-decoration: none; --framer-text-stroke-color: initial; --framer-text-stroke-width: initial; --framer-text-transform: none; } }`];
var className = "framer-fTBSf";

// http-url:https://framerusercontent.com/modules/lq4ZrA7Ossc920b6RHy8/1EbxAec064m13Rieawug/zBF9Zr7zY.js
var enabledGestures = { DV3PJqobe: { hover: true } };
var cycleOrder = ["DV3PJqobe", "Z2WYrKc2F"];
var serializationHash = "framer-rQ6WH";
var variantClassNames = { DV3PJqobe: "framer-v-ijx0wv", Z2WYrKc2F: "framer-v-vsdn97" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var sharedDateFormatter = (value, formatOptions, locale) => {
  if (typeof value !== "string")
    return "";
  const date = new Date(value);
  if (isNaN(date.getTime()))
    return "";
  const fallbackLocale = "en-US";
  try {
    return date.toLocaleString(locale || fallbackLocale, formatOptions);
  } catch {
    return date.toLocaleString(fallbackLocale, formatOptions);
  }
};
var dateOptions = { dateStyle: "medium", timeZone: "UTC" };
var toDateString = (value, activeLocale) => {
  return sharedDateFormatter(value, dateOptions, activeLocale);
};
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var Transition = ({ value, children }) => {
  const config = React.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Desktop: "DV3PJqobe", Mobile: "Z2WYrKc2F" };
var Variants = motion.create(React.Fragment);
var getProps = ({ cover, date, height, id, title, width, ...props }) => {
  return { ...props, pXSCd6UgM: title ?? props.pXSCd6UgM ?? "Aspen Luxury Market Enters 2026 Stronger Than Ever", raqRZGGel: cover ?? props.raqRZGGel, smzLE0y6L: date ?? props.smzLE0y6L ?? "2026-01-18T00:00:00.000Z", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "DV3PJqobe" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className: className2, layoutId, variant, smzLE0y6L, raqRZGGel, pXSCd6UgM, ...restProps } = getProps(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "DV3PJqobe", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [className];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  const activeLocaleCode = useLocaleCode();
  const textContent = toDateString(smzLE0y6L, activeLocaleCode);
  return /* @__PURE__ */ _jsx(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-ijx0wv", className2, classNames), "data-framer-name": "Desktop", layoutDependency, layoutId: "InsightsHomeCard__DV3PJqobe", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ "DV3PJqobe-hover": { "data-framer-name": void 0 }, Z2WYrKc2F: { "data-framer-name": "Mobile" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx(motion.div, { className: "framer-1x1xt27", "data-border": true, "data-framer-name": "date", layoutDependency, layoutId: "InsightsHomeCard__V4jEww45U", style: { "--border-bottom-width": "1px", "--border-color": "rgba(255, 255, 255, 0.2)", "--border-left-width": "1px", "--border-right-width": "1px", "--border-style": "solid", "--border-top-width": "1px", backgroundColor: "rgba(0, 0, 0, 0.25)" }, children: /* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.p, { dir: "auto", style: { "--framer-text-color": "var(--extracted-r6o4lv, rgb(255, 255, 255))" }, children: "Apr 3, 2026" }) }), className: "framer-167lkge", fonts: ["Inter"], layoutDependency, layoutId: "InsightsHomeCard__LqVLz7N3L", style: { "--extracted-r6o4lv": "rgb(255, 255, 255)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: /* @__PURE__ */ _jsx("time", { dateTime: smzLE0y6L, children: textContent }), verticalAlignment: "top", withExternalLayout: true }) }), /* @__PURE__ */ _jsx(Image1, { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + 0), sizes: componentViewport?.width || "100vw", ...toResponsiveImage(raqRZGGel) }, className: "framer-zqr8w5", layoutDependency, layoutId: "InsightsHomeCard__fTVfZgomm", ...addPropertyOverrides({ "DV3PJqobe-hover": { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + -22), sizes: `calc(${componentViewport?.width || "100vw"} * 1.0815)`, ...toResponsiveImage(raqRZGGel) } } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx(motion.div, { className: "framer-1f8aiyy", "data-framer-name": "overlay", layoutDependency, layoutId: "InsightsHomeCard__TDubOmWzP", style: { backgroundColor: "rgba(0, 0, 0, 0.55)" } }), /* @__PURE__ */ _jsx(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx(React.Fragment, { children: /* @__PURE__ */ _jsx(motion.p, { className: "framer-styles-preset-z65n4z", "data-styles-preset": "ORljPUa5H", dir: "auto", style: { "--framer-text-alignment": "start" }, children: "Prime Central Colorado in 2026: What Buyers Need to Know" }) }), className: "framer-hfcgkm", fonts: ["Inter"], layoutDependency, layoutId: "InsightsHomeCard__VDy2s5Xuw", style: { "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, text: pXSCd6UgM, verticalAlignment: "top", withExternalLayout: true })] }) }) }) });
});
var css2 = [".framer-rQ6WH.framer-213csi, .framer-rQ6WH .framer-213csi { display: block; }", ".framer-rQ6WH.framer-ijx0wv { align-content: flex-start; align-items: flex-start; cursor: pointer; display: flex; flex-direction: column; flex-wrap: nowrap; height: auto; justify-content: space-between; overflow: var(--overflow-clip-fallback, clip); padding: 24px; position: relative; width: 100%; }", ".framer-rQ6WH .framer-1x1xt27 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: center; overflow: visible; padding: 8px 12px 8px 16px; position: relative; width: min-content; z-index: 2; }", ".framer-rQ6WH .framer-167lkge { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-rQ6WH .framer-zqr8w5 { flex: none; height: 100%; left: 0px; overflow: var(--overflow-clip-fallback, clip); position: absolute; top: 0px; width: 100%; will-change: var(--framer-will-change-filter-override, filter); z-index: 1; }", ".framer-rQ6WH .framer-1f8aiyy { flex: none; height: 100%; left: 0px; overflow: var(--overflow-clip-fallback, clip); position: absolute; top: 0px; width: 100%; z-index: 1; }", ".framer-rQ6WH .framer-hfcgkm { --framer-text-wrap-override: balance; flex: none; height: auto; position: relative; width: 100%; z-index: 2; }", ".framer-rQ6WH.framer-v-vsdn97.framer-ijx0wv { cursor: unset; height: auto; width: 100%; }", ".framer-rQ6WH.framer-v-ijx0wv.hover .framer-zqr8w5 { height: 108%; left: -22px; top: -22px; width: 108%; }", ...css, '.framer-rQ6WH[data-border="true"]::after, .framer-rQ6WH [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerzBF9Zr7zY = withCSS(Component, css2, "framer-rQ6WH");
var zBF9Zr7zY_default = FramerzBF9Zr7zY;
FramerzBF9Zr7zY.displayName = "Insights Home Card";
FramerzBF9Zr7zY.defaultProps = { height: 548, width: 552 };
addPropertyControls(FramerzBF9Zr7zY, { variant: { options: ["DV3PJqobe", "Z2WYrKc2F"], optionTitles: ["Desktop", "Mobile"], title: "Variant", type: ControlType.Enum }, smzLE0y6L: { defaultValue: "2026-01-18T00:00:00.000Z", title: "Date", type: ControlType.Date }, onsmzLE0y6LChange: { changes: "smzLE0y6L", type: ControlType.ChangeHandler }, raqRZGGel: { title: "Cover", type: ControlType.ResponsiveImage }, pXSCd6UgM: { defaultValue: "Aspen Luxury Market Enters 2026 Stronger Than Ever", title: "Title", type: ControlType.String }, onpXSCd6UgMChange: { changes: "pXSCd6UgM", type: ControlType.ChangeHandler } });
addFonts(FramerzBF9Zr7zY, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...getFontsFromSharedStyle(fonts)], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerzBF9Zr7zY", "slots": [], "annotations": { "framerAutoSizeImages": "true", "framerIntrinsicWidth": "552", "framerVariables": '{"smzLE0y6L":"date","raqRZGGel":"cover","pXSCd6UgM":"title"}', "framerColorSyntax": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","fixed"]},"Z2WYrKc2F":{"layout":["fixed","fixed"]},"nVohfSSRg":{"layout":["fixed","fixed"]}}}', "framerIntrinsicHeight": "548", "framerComponentViewportWidth": "true", "framerImmutableVariables": "true", "framerDisplayContentsDiv": "false", "framerContractVersion": "1" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  zBF9Zr7zY_default as default
};
