var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/2If3AfE3YP9AIu6GNCwo/TawDNYbmGHMW8PYrBUjW/zmH4gTyLg.js
import { jsx as _jsx4, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ComponentViewportProvider, ControlType as ControlType5, cx, getFonts, getLoadingLazyAtYPosition, getPropertyControls, Image as Image1, SmartComponentScopedContainer, useComponentViewport, useLocaleInfo, useVariantState, withCodeBoundaryForOverrides, withCSS } from "./_framer-runtime.js";
import { LayoutGroup, motion, MotionConfigContext } from "framer-motion";
import * as React3 from "react";
import { useRef as useRef5 } from "react";

// http-url:https://framerusercontent.com/modules/lRDHiNWNVWmE0lqtoVHP/I6H5ZhUPA8PwvfVPIGXQ/Video.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType as ControlType4, useIsInCurrentNavigationTarget as useIsInCurrentNavigationTarget2, RenderTarget as RenderTarget3 } from "./_framer-runtime.js";
import { isMotionValue as isMotionValue2, useInView } from "framer-motion";

// http-url:https://framerusercontent.com/modules/VTUDdizacRHpwbkOamr7/AykinQJbgwl92LvMGZwu/constants.js
import { ControlType } from "./_framer-runtime.js";
var containerStyles = {
  position: "relative",
  width: "100%",
  height: "100%",
  display: "flex",
  justifyContent: "center",
  alignItems: "center"
};
var emptyStateStyle = {
  ...containerStyles,
  borderRadius: 6,
  background: "rgba(136, 85, 255, 0.3)",
  color: "#85F",
  border: "1px dashed #85F",
  flexDirection: "column"
};
var defaultEvents = {
  onClick: {
    type: ControlType.EventHandler
  },
  onMouseEnter: {
    type: ControlType.EventHandler
  },
  onMouseLeave: {
    type: ControlType.EventHandler
  }
};
var fontSizeOptions = {
  type: ControlType.Number,
  title: "Font Size",
  min: 2,
  max: 200,
  step: 1,
  displayStepper: true
};
var fontControls = {
  font: {
    type: ControlType.Boolean,
    title: "Font",
    defaultValue: false,
    disabledTitle: "Default",
    enabledTitle: "Custom"
  },
  fontFamily: {
    type: ControlType.String,
    title: "Family",
    placeholder: "Inter",
    hidden: ({ font }) => !font
  },
  fontWeight: {
    type: ControlType.Enum,
    title: "Weight",
    options: [
      100,
      200,
      300,
      400,
      500,
      600,
      700,
      800,
      900
    ],
    optionTitles: [
      "Thin",
      "Extra-light",
      "Light",
      "Regular",
      "Medium",
      "Semi-bold",
      "Bold",
      "Extra-bold",
      "Black"
    ],
    hidden: ({ font }) => !font
  }
};

// http-url:https://framerusercontent.com/modules/D4TWeLfcxT6Tysr2BlYg/iZjmqdxVx1EOiM3k1FaW/useOnNavigationTargetChange.js
import { useIsInCurrentNavigationTarget } from "./_framer-runtime.js";
import { useEffect } from "react";
function useOnEnter(onEnter, enabled) {
  return useOnSpecificTargetChange(true, onEnter, enabled);
}
function useOnExit(onExit, enabled) {
  return useOnSpecificTargetChange(false, onExit, enabled);
}
function useOnSpecificTargetChange(goal, callback, enabled = true) {
  const isInTarget = useIsInCurrentNavigationTarget();
  useEffect(() => {
    if (enabled && isInTarget === goal)
      callback();
  }, [
    isInTarget
  ]);
}

// http-url:https://framerusercontent.com/modules/ExNgrA7EJTKUPpH6vIlN/eiOrSJ2Ab5M9jPCvVwUz/useConstant.js
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/D2Lz5CmnNVPZFFiZXalt/QaCzPbriZBfXWZIIycFI/colorFromToken.js
import { Color } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/3mKFSGQqKHV82uOV1eBc/5fbRLvOpxZC0JOXugvwm/isMotionValue.js
import { MotionValue } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/xDiQsqBGXzmMsv7AlEVy/uhunpMiNsbXxzjlXsg1y/useUniqueClassName.js
import * as React from "react";

// http-url:https://framerusercontent.com/modules/ETACN5BJyFTSo0VVDJfu/NHRqowOiXkF9UwOzczF7/variantUtils.js
import { ControlType as ControlType2 } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/eMBrwoqQK7h6mEeGQUH8/GuplvPJVjmxpk9zqOTcb/isBrowser.js
import { useMemo } from "react";
var isBrowserSafari = () => {
  if (typeof __dai_navigator !== `undefined`) {
    const userAgent = __dai_navigator.userAgent.toLowerCase();
    const isSafari = (userAgent.indexOf("safari") > -1 || userAgent.indexOf("framermobile") > -1 || userAgent.indexOf("framerx") > -1) && userAgent.indexOf("chrome") < 0;
    return isSafari;
  } else
    return false;
};
var useIsBrowserSafari = () => useMemo(
  () => isBrowserSafari(),
  []
);

// http-url:https://framerusercontent.com/modules/v9AWX2URmiYsHf7GbctE/XxKAZ9KlhWqf5x1JMyyF/useOnChange.js
import { useEffect as useEffect3 } from "react";

// http-url:https://framerusercontent.com/modules/kNDwabfjDEb3vUxkQlZS/fSIr3AOAYbGlfSPgXpYu/useAutoMotionValue.js
import { useCallback, useEffect as useEffect4, useRef as useRef2 } from "react";
import { motionValue, animate, RenderTarget } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/cuQH4dmpDnV8YK1mSgQX/KqRXqunFjE6ufhpc7ZRu/useFontControls.js
import { fontStore } from "./_framer-runtime.js";
import { useEffect as useEffect5 } from "react";

// http-url:https://framerusercontent.com/modules/afBE9Yx1W6bY5q32qPxe/m3q7puE2tbo1S2C0s0CT/useRenderTarget.js
import { useMemo as useMemo2 } from "react";
import { RenderTarget as RenderTarget2 } from "./_framer-runtime.js";
function useRenderTarget() {
  const currentRenderTarget = useMemo2(
    () => RenderTarget2.current(),
    []
  );
  return currentRenderTarget;
}
function useIsOnCanvas() {
  const onCanvas = useMemo2(
    () => RenderTarget2.current() === RenderTarget2.canvas,
    []
  );
  return onCanvas;
}

// http-url:https://framerusercontent.com/modules/zGkoP8tPDCkoBzMdt5uq/0zFSjxIYliHxrQQnryFX/useControlledState.js
import * as React2 from "react";

// http-url:https://framerusercontent.com/modules/5SM58HxZHxjjv7aLMOgQ/WXz9i6mVki0bBCrKdqB3/propUtils.js
import { useMemo as useMemo3 } from "react";
import { ControlType as ControlType3 } from "./_framer-runtime.js";
function useRadius(props) {
  const { borderRadius, isMixedBorderRadius, topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius } = props;
  const radiusValue = useMemo3(
    () => isMixedBorderRadius ? `${topLeftRadius}px ${topRightRadius}px ${bottomRightRadius}px ${bottomLeftRadius}px` : `${borderRadius}px`,
    [
      borderRadius,
      isMixedBorderRadius,
      topLeftRadius,
      topRightRadius,
      bottomRightRadius,
      bottomLeftRadius
    ]
  );
  return radiusValue;
}
var borderRadiusControl = {
  borderRadius: {
    title: "Radius",
    type: ControlType3.FusedNumber,
    toggleKey: "isMixedBorderRadius",
    toggleTitles: [
      "Radius",
      "Radius per corner"
    ],
    valueKeys: [
      "topLeftRadius",
      "topRightRadius",
      "bottomRightRadius",
      "bottomLeftRadius"
    ],
    valueLabels: [
      "TL",
      "TR",
      "BR",
      "BL"
    ],
    min: 0
  }
};
var paddingControl = {
  padding: {
    type: ControlType3.FusedNumber,
    toggleKey: "paddingPerSide",
    toggleTitles: [
      "Padding",
      "Padding per side"
    ],
    valueKeys: [
      "paddingTop",
      "paddingRight",
      "paddingBottom",
      "paddingLeft"
    ],
    valueLabels: [
      "T",
      "R",
      "B",
      "L"
    ],
    min: 0,
    title: "Padding"
  }
};

// http-url:https://framerusercontent.com/modules/lRDHiNWNVWmE0lqtoVHP/I6H5ZhUPA8PwvfVPIGXQ/Video.js
import { memo, useCallback as useCallback2, useEffect as useEffect7, useMemo as useMemo4, useRef as useRef3, useState as useState3 } from "react";
var ObjectFitType;
(function(ObjectFitType2) {
  ObjectFitType2["Fill"] = "fill";
  ObjectFitType2["Contain"] = "contain";
  ObjectFitType2["Cover"] = "cover";
  ObjectFitType2["None"] = "none";
  ObjectFitType2["ScaleDown"] = "scale-down";
})(ObjectFitType || (ObjectFitType = {}));
var SrcType;
(function(SrcType2) {
  SrcType2["Video"] = "Upload";
  SrcType2["Url"] = "URL";
})(SrcType || (SrcType = {}));
var defaultVideo = "https://framerusercontent.com/assets/MLWPbW1dUQawJLhhun3dBwpgJak.mp4";
function getProps(props) {
  const { width, height, topLeft, topRight, bottomRight, bottomLeft, id, children, ...rest } = props;
  return rest;
}
function Video(props) {
  const newProps = getProps(props);
  return /* @__PURE__ */ _jsx(VideoMemo, { ...newProps });
}
function usePlaybackControls(videoRef) {
  const isInCurrentNavigationTarget = useIsInCurrentNavigationTarget2();
  const requestingPlay = useRef3(false);
  const isPlayingRef = useRef3(false);
  const setProgress = useCallback2((rawProgress) => {
    if (!videoRef.current)
      return;
    const newProgress = (rawProgress === 1 ? 0.999 : rawProgress) * videoRef.current.duration;
    const isAlreadySet = Math.abs(videoRef.current.currentTime - newProgress) < 0.1;
    if (videoRef.current.duration > 0 && !isAlreadySet) {
      videoRef.current.currentTime = newProgress;
    }
  }, []);
  const play = useCallback2(() => {
    const video = videoRef.current;
    if (!video)
      return;
    video.preload = "auto";
    const isPlaying = video.currentTime > 0 && video.onplaying && !video.paused && !video.ended && video.readyState >= video.HAVE_CURRENT_DATA;
    if (!isPlaying && video && !requestingPlay.current && isInCurrentNavigationTarget) {
      requestingPlay.current = true;
      isPlayingRef.current = true;
      video.play().catch((e) => {
      }).finally(() => requestingPlay.current = false);
    }
  }, []);
  const pause = useCallback2(() => {
    if (!videoRef.current || requestingPlay.current)
      return;
    videoRef.current.pause();
    isPlayingRef.current = false;
  }, []);
  return { play, pause, setProgress, isPlaying: isPlayingRef };
}
function useAutoplayBehavior({ playingProp, muted, loop, playsinline, controls }) {
  const [initialPlayingProp] = useState3(playingProp);
  const [hasPlayingPropChanged, setHasPlayingPropChanged] = useState3(false);
  if (playingProp !== initialPlayingProp && !hasPlayingPropChanged) {
    setHasPlayingPropChanged(true);
  }
  const behavesAsGif = (
    // passing `playing === true` on mount indicates that the video should
    // autoplay, like a GIF
    initialPlayingProp && muted && loop && playsinline && !controls && // Some users of the <Video> component use it by wrapping it with
    // another smart component and adding their own controls on top. (The
    // controls use transitions to control the video: e.g., when clicking
    // the play button, the smart component will transition to a state with
    // <Video playing={true} />.) In this case, we don't want the video to
    // behave as a gif, as it will be weird if the video suddenly started
    // acting as such (and auto-pausing when leaving the viewport) as soon
    // as the site visitor mutes it and clicks “Play”.
    !hasPlayingPropChanged
  );
  let autoplay;
  if (behavesAsGif)
    autoplay = "on-viewport";
  else if (initialPlayingProp)
    autoplay = "on-mount";
  else
    autoplay = "no-autoplay";
  return autoplay;
}
var VideoMemo = /* @__PURE__ */ memo(function VideoInner(props) {
  const {
    // default props
    srcType = "URL",
    srcUrl,
    srcFile = "",
    posterEnabled = false,
    controls = false,
    playing = true,
    loop = true,
    muted = true,
    playsinline = true,
    restartOnEnter = false,
    objectFit = "cover",
    backgroundColor = "rgba(0,0,0,0)",
    radius = 0,
    volume = 25,
    startTime: startTimeProp = 0,
    poster,
    playing: playingProp,
    progress,
    onSeeked,
    onPause,
    onPlay,
    onEnd,
    onClick,
    onMouseEnter,
    onMouseLeave,
    onMouseDown,
    onMouseUp
  } = props;
  const videoRef = useRef3();
  const isSafari = useIsBrowserSafari();
  const wasPausedOnLeave = useRef3(null);
  const wasEndedOnLeave = useRef3(null);
  const isOnCanvas = useIsOnCanvas();
  const renderTarget = useRenderTarget();
  const isStaticRenderer = isOnCanvas || renderTarget === RenderTarget3.export;
  const borderRadius = useRadius(props);
  const autoplayBehavior = isStaticRenderer ? "no-autoplay" : useAutoplayBehavior({ playingProp, muted, loop, playsinline, controls });
  const isInViewport = isStaticRenderer ? true : useInView(videoRef);
  const isCloseToViewport = isStaticRenderer ? false : useInView(videoRef, { margin: "10%", once: true });
  const startTime = startTimeProp === 100 ? 99.9 : startTimeProp;
  const { play, pause, setProgress, isPlaying } = usePlaybackControls(videoRef);
  useEffect7(() => {
    if (isStaticRenderer)
      return;
    if (autoplayBehavior === "on-viewport")
      return;
    if (playingProp)
      play();
    else
      pause();
  }, [autoplayBehavior, playingProp]);
  useEffect7(() => {
    if (isStaticRenderer)
      return;
    if (isInViewport && playingProp && autoplayBehavior !== "no-autoplay")
      play();
    if (autoplayBehavior !== "on-viewport")
      return;
    pause();
  }, [autoplayBehavior, isInViewport, playingProp]);
  useEffect7(() => {
    if (!isOnCanvas || poster || posterEnabled || startTime || !videoRef.current)
      return;
    videoRef.current.currentTime = 0.01;
  }, [posterEnabled, poster, startTime]);
  const isMountedAndReadyForProgressChanges = useRef3(false);
  useEffect7(() => {
    if (!isMountedAndReadyForProgressChanges.current) {
      isMountedAndReadyForProgressChanges.current = true;
      return;
    }
    const rawProgressValue = isMotionValue2(progress) ? progress.get() : (progress ?? 0) * 0.01;
    setProgress(
      // When the progress value exists (e.g. <Video startTime={10}
      // progress={50} />), we respect the `progress` value over
      // `startTime`, even if `startTime` changes. That’s because
      // `startTime` == start == changing it shouldn’t affect the current
      // progress
      (rawProgressValue ?? 0) || // Then why fall back to `startTime` when `progress` doesn’t exist,
      // you might ask? Now, that’s for
      // - canvas UX: we want the video progress to change when the user
      //   is scrobbling the “Start Time” in component settings.
      // - backwards compatibility: maybe some users *are* scrobbling
      //   using `startTime` instead of `progress`? We don’t know, and it
      //   always supported it, so let’s not break it
      (startTime ?? 0) / 100
    );
  }, [startTime, srcFile, srcUrl, progress]);
  useEffect7(() => {
    if (!isMotionValue2(progress))
      return;
    return progress.on("change", (value) => setProgress(value));
  }, [progress]);
  useOnEnter(() => {
    if (wasPausedOnLeave.current === null)
      return;
    if (videoRef.current) {
      if (!wasEndedOnLeave && loop || !wasPausedOnLeave.current)
        play();
    }
  });
  useOnExit(() => {
    if (videoRef.current) {
      wasEndedOnLeave.current = videoRef.current.ended;
      wasPausedOnLeave.current = videoRef.current.paused;
      pause();
    }
  });
  const src = useMemo4(() => {
    let fragment = "";
    if (srcType === "URL")
      return srcUrl + fragment;
    if (srcType === "Upload")
      return srcFile + fragment;
  }, [srcType, srcFile, srcUrl, startTime]);
  useEffect7(() => {
    if (isSafari && videoRef.current && autoplayBehavior === "on-mount") {
      setTimeout(() => play(), 50);
    }
  }, []);
  useEffect7(() => {
    if (videoRef.current && !muted)
      videoRef.current.volume = (volume ?? 0) / 100;
  }, [volume]);
  const handleReady = () => {
    const video = videoRef.current;
    if (!video)
      return;
    if (video.currentTime < 0.3 && startTime > 0)
      setProgress((startTime ?? 0) * 0.01);
    if (
      // when the component updates (e.g. only srcFile/url changes), and the video was already playing, keep playing
      isPlaying.current || autoplayBehavior === "on-mount" || playingProp && autoplayBehavior === "on-viewport" && isInViewport
    )
      play();
  };
  return /* @__PURE__ */ _jsx("video", { onClick, onMouseEnter, onMouseLeave, onMouseDown, onMouseUp, src, loop, ref: videoRef, onSeeked: (e) => onSeeked?.(e), onPause: (e) => onPause?.(e), onPlay: (e) => onPlay?.(e), onEnded: (e) => onEnd?.(e), autoPlay: isPlaying.current || autoplayBehavior === "on-mount" || playingProp && autoplayBehavior === "on-viewport" && isInViewport, preload: isPlaying.current ? "auto" : isStaticRenderer && !poster ? "metadata" : autoplayBehavior !== "on-mount" && !isCloseToViewport ? "none" : (
    // `autoplay` overrides this too
    "metadata"
  ), poster: posterEnabled && !srcFile && srcUrl === defaultVideo ? "https://framerusercontent.com/images/5ILRvlYXf72kHSVHqpa3snGzjU.jpg" : posterEnabled && poster ? poster : void 0, onLoadedData: handleReady, controls, muted: isStaticRenderer ? true : muted, playsInline: playsinline, style: { cursor: !!onClick ? "pointer" : "auto", width: "100%", height: "100%", borderRadius, display: "block", objectFit, backgroundColor, objectPosition: "50% 50%" } });
});
Video.displayName = "Video";
function capitalizeFirstLetter(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}
function titleCase(value) {
  const groups = value.match(/[A-Z]{2,}|[A-Z][a-z]+|[a-z]+|[A-Z]|\d+/gu) || [];
  return groups.map(capitalizeFirstLetter).join(" ");
}
var objectFitOptions = ["cover", "fill", "contain", "scale-down", "none"];
addPropertyControls(Video, {
  srcType: { type: ControlType4.Enum, displaySegmentedControl: true, title: "Source", options: ["URL", "Upload"] },
  srcUrl: { type: ControlType4.String, title: "URL", defaultValue: "https://framerusercontent.com/assets/MLWPbW1dUQawJLhhun3dBwpgJak.mp4", hidden(props) {
    return props.srcType === "Upload";
  } },
  srcFile: { type: ControlType4.File, title: "File", allowedFileTypes: ["mp4", "webm"], hidden(props) {
    return props.srcType === "URL";
  } },
  ...borderRadiusControl,
  loop: { type: ControlType4.Boolean, title: "Loop", enabledTitle: "Yes", disabledTitle: "No" },
  posterEnabled: { type: ControlType4.Boolean, title: "Poster", enabledTitle: "Yes", disabledTitle: "No", hiddenWhenUnset: true, defaultValue: true },
  poster: { type: ControlType4.Image, title: "Image", hidden: ({ posterEnabled }) => !posterEnabled, description: "We recommend adding a poster. [Learn more](https://www.framer.com/help/articles/how-are-videos-optimized-in-framer/)." },
  controls: { type: ControlType4.Boolean, title: "Controls", enabledTitle: "Show", disabledTitle: "Hide", defaultValue: false, hiddenWhenUnset: true },
  muted: { type: ControlType4.Boolean, title: "Muted", enabledTitle: "Yes", disabledTitle: "No", hiddenWhenUnset: true },
  objectFit: { type: ControlType4.Enum, title: "Fit", options: objectFitOptions, optionTitles: objectFitOptions.map(titleCase), hiddenWhenUnset: true },
  playing: { type: ControlType4.Boolean, title: "Playing", enabledTitle: "Yes", disabledTitle: "No", hiddenWhenUnset: true },
  backgroundColor: { type: ControlType4.Color, title: "Background", defaultValue: "rgba(0,0,0,0)" },
  startTime: { title: "Start Time", type: ControlType4.Number, min: 0, max: 100, step: 0.1, unit: "%", hiddenWhenUnset: true },
  // restartOnEnter: {
  //     type: ControlType.Boolean,
  //     title: "On ReEnter",
  //     enabledTitle: "Restart",
  //     disabledTitle: "Resume",
  // },
  volume: { type: ControlType4.Number, max: 100, min: 0, unit: "%", hidden: ({ muted }) => muted, defaultValue: 25, hiddenWhenUnset: true },
  onEnd: { type: ControlType4.EventHandler },
  onSeeked: { type: ControlType4.EventHandler },
  onPause: { type: ControlType4.EventHandler },
  onPlay: { type: ControlType4.EventHandler },
  ...defaultEvents
});

// http-url:https://framerusercontent.com/modules/ss5RHIII5WmaxDczJYyI/5Bul2NDFHyG0ZwSx8cZa/TerraceImageFetchPriority.js
import { jsx as _jsx2 } from "react/jsx-runtime";
function withFetchPriority(Component2) {
  return (props) => {
    return /* @__PURE__ */ _jsx2(Component2, { ...props, background: { ...props.background, fetchPriority: "high" } });
  };
}

// http-url:https://framerusercontent.com/modules/824qqeRNyX7zyuWtkY6c/0KQF8pZKue2MiRrinFri/Video_Pre_Loader.js
import { jsx as _jsx3 } from "react/jsx-runtime";
import { useEffect as useEffect8, useRef as useRef4 } from "react";
var MOBILE_BREAKPOINT = 810;
function withVideoPreloadAuto(Component2) {
  return (props) => {
    const containerRef = useRef4(null);
    useEffect8(() => {
      const container = containerRef.current;
      if (!container)
        return;
      const isMobile = () => typeof __dai_window !== "undefined" && __dai_window.innerWidth < MOBILE_BREAKPOINT;
      const applyAttributes = (video2) => {
        if (isMobile()) {
          if (video2.getAttribute("preload") !== "none") {
            video2.setAttribute("preload", "none");
            video2.removeAttribute("fetchpriority");
          }
          return;
        }
        if (video2.getAttribute("preload") !== "auto" || video2.getAttribute("fetchpriority") !== "high") {
          video2.setAttribute("preload", "auto");
          video2.setAttribute("fetchpriority", "high");
        }
      };
      const video = container.querySelector("video");
      if (video) {
        applyAttributes(video);
        if (!isMobile())
          video.load();
      }
      const observer = new MutationObserver(() => {
        const currentVideo = container.querySelector("video");
        if (currentVideo)
          applyAttributes(currentVideo);
      });
      observer.observe(container, { attributes: true, attributeFilter: ["preload", "fetchpriority"], subtree: true });
      const handleResize = () => {
        const currentVideo = container.querySelector("video");
        if (currentVideo)
          applyAttributes(currentVideo);
      };
      __dai_window.addEventListener("resize", handleResize);
      return () => {
        observer.disconnect();
        __dai_window.removeEventListener("resize", handleResize);
      };
    }, []);
    return /* @__PURE__ */ _jsx3("div", { ref: containerRef, style: { width: "100%", height: "100%" }, children: /* @__PURE__ */ _jsx3(Component2, { ...props }) });
  };
}

// http-url:https://framerusercontent.com/modules/2If3AfE3YP9AIu6GNCwo/TawDNYbmGHMW8PYrBUjW/zmH4gTyLg.js
var Image1WithFetchPriority1jafx0y = withCodeBoundaryForOverrides(Image1, { nodeId: "WSTmBqKo8", override: withFetchPriority, scopeId: "zmH4gTyLg" });
var VideoFonts = getFonts(Video);
var VideoWithVideoPreloadAuto1pdj39x = withCodeBoundaryForOverrides(Video, { nodeId: "V7Bliiw4h", override: withVideoPreloadAuto, scopeId: "zmH4gTyLg" });
var VideoControls = getPropertyControls(Video);
var serializationHash = "framer-Qbl4Q";
var variantClassNames = { TauURMiJp: "framer-v-15egsx" };
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var negate = (value) => {
  return !value;
};
var toResponsiveImage = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value;
  }
  return typeof value === "string" ? { src: value } : void 0;
};
var toImageSrc = (value) => {
  if (typeof value === "object" && value !== null && typeof value.src === "string") {
    return value.src;
  }
  return typeof value === "string" ? value : void 0;
};
var Transition = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion.create(React3.Fragment);
var getProps2 = ({ backgroundImage, height, id, video, videoFile, width, ...props }) => {
  return { ...props, FxNnwMJAP: backgroundImage ?? props.FxNnwMJAP ?? { pixelHeight: 1280, pixelWidth: 1920, src: "https://framerusercontent.com/images/za1kvny7Y3Wv0FewZvrhhKFqE.jpg?width=1920&height=1280", srcSet: "https://framerusercontent.com/images/za1kvny7Y3Wv0FewZvrhhKFqE.jpg?scale-down-to=512&width=1920&height=1280 512w,https://framerusercontent.com/images/za1kvny7Y3Wv0FewZvrhhKFqE.jpg?scale-down-to=1024&width=1920&height=1280 1024w,https://framerusercontent.com/images/za1kvny7Y3Wv0FewZvrhhKFqE.jpg?width=1920&height=1280 1920w" }, IxZEqDbFQ: videoFile ?? props.IxZEqDbFQ ?? "https://framerusercontent.com/assets/fwA6d1SXErDfwYIO6DczvhOnyk.mp4", KTEKLv2jD: video ?? props.KTEKLv2jD ?? true };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef5(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, KTEKLv2jD, FxNnwMJAP, IxZEqDbFQ, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ defaultVariant: "TauURMiJp", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx(serializationHash, ...sharedStyleClassNames);
  const visible = negate(KTEKLv2jD);
  return /* @__PURE__ */ _jsx4(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion.div, { ...restProps, ...gestureHandlers, className: cx(scopingClassNames, "framer-15egsx", className, classNames), "data-framer-name": "Variant 1", layoutDependency, layoutId: "VideoImage__TauURMiJp", ref: refBinding, style: { ...style }, children: [visible !== false && /* @__PURE__ */ _jsx4(motion.div, { className: "framer-15f0oyy", "data-framer-name": "overlay", layoutDependency, layoutId: "VideoImage__AbEn8snaa", style: { backgroundColor: "rgba(0, 0, 0, 0.15)" } }), visible !== false && /* @__PURE__ */ _jsx4(Image1WithFetchPriority1jafx0y, { background: { alt: "", fit: "fill", loading: getLoadingLazyAtYPosition((componentViewport?.y || 0) + ((componentViewport?.height || 200) * 0.5000000000000002 - (componentViewport?.height || 200) * 1 / 2)), pixelHeight: 1280, pixelWidth: 1920, sizes: componentViewport?.width || "100vw", ...toResponsiveImage(FxNnwMJAP) }, className: "framer-1jafx0y", layoutDependency, layoutId: "VideoImage__WSTmBqKo8", style: { filter: "brightness(0.6)", mask: "linear-gradient(0deg, rgba(0,0,0,0) -51%, rgba(0, 0, 0, 0.06871) -24%, rgba(0, 0, 0, 0.01692) -9%, rgba(0,0,0,1) 44%, rgba(0, 0, 0, 0.98941) 90%) add", WebkitFilter: "brightness(0.6)", WebkitMask: "linear-gradient(0deg, rgba(0,0,0,0) -51%, rgba(0, 0, 0, 0.06871) -24%, rgba(0, 0, 0, 0.01692) -9%, rgba(0,0,0,1) 44%, rgba(0, 0, 0, 0.98941) 90%) add" } }), KTEKLv2jD !== false && /* @__PURE__ */ _jsx4(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx4(SmartComponentScopedContainer, { className: "framer-1pdj39x-container", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "VideoImage__V7Bliiw4h-container", nodeId: "V7Bliiw4h", rendersWithMotion: true, scopeId: "zmH4gTyLg", style: { mask: "linear-gradient(0deg, rgba(0,0,0,0) -22%, rgba(0,0,0,1) 133%) add", WebkitMask: "linear-gradient(0deg, rgba(0,0,0,0) -22%, rgba(0,0,0,1) 133%) add" }, children: /* @__PURE__ */ _jsx4(VideoWithVideoPreloadAuto1pdj39x, { backgroundColor: "rgba(0, 0, 0, 0)", borderRadius: 0, bottomLeftRadius: 0, bottomRightRadius: 0, controls: false, height: "100%", id: "V7Bliiw4h", isMixedBorderRadius: false, layoutId: "VideoImage__V7Bliiw4h", loop: true, muted: true, objectFit: "cover", playing: true, poster: toImageSrc(FxNnwMJAP), posterEnabled: true, srcFile: IxZEqDbFQ, srcType: "Upload", srcUrl: "https://framerusercontent.com/assets/MLWPbW1dUQawJLhhun3dBwpgJak.mp4", startTime: 0, style: { height: "100%", width: "100%" }, topLeftRadius: 0, topRightRadius: 0, volume: 25, width: "100%" }) }) })] }) }) }) });
});
var css = [".framer-Qbl4Q.framer-1fzlhfw, .framer-Qbl4Q .framer-1fzlhfw { display: block; }", ".framer-Qbl4Q.framer-15egsx { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; min-height: 736px; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-Qbl4Q .framer-15f0oyy { flex: none; height: 125%; left: calc(50.00000000000002% - 100% / 2); overflow: var(--overflow-clip-fallback, clip); position: absolute; top: calc(50.00000000000002% - 125% / 2); width: 100%; z-index: 5; }", ".framer-Qbl4Q .framer-1jafx0y { flex: none; height: 100%; left: calc(50.00000000000002% - 100% / 2); overflow: var(--overflow-clip-fallback, clip); position: absolute; top: calc(50.00000000000002% - 100% / 2); width: 100%; will-change: var(--framer-will-change-filter-override, filter); z-index: 1; }", ".framer-Qbl4Q .framer-1pdj39x-container { flex: none; height: 100%; left: calc(50.00000000000002% - 100% / 2); position: absolute; top: calc(50.00000000000002% - 100% / 2); width: 100%; z-index: 1; }"];
var FramerzmH4gTyLg = withCSS(Component, css, "framer-Qbl4Q");
var zmH4gTyLg_default = FramerzmH4gTyLg;
FramerzmH4gTyLg.displayName = "Video + Image";
FramerzmH4gTyLg.defaultProps = { height: 736, width: 1104 };
addPropertyControls2(FramerzmH4gTyLg, { KTEKLv2jD: { defaultValue: true, title: "Video", type: ControlType5.Boolean }, onKTEKLv2jDChange: { changes: "KTEKLv2jD", type: ControlType5.ChangeHandler }, FxNnwMJAP: { __defaultAssetReference: "data:framer/asset-reference,za1kvny7Y3Wv0FewZvrhhKFqE.jpg?originalFilename=gabrielle-maurer-E_J7HhGttHM-unsplash+%281%29.jpg&width=1920&height=1280", title: "Background Image", type: ControlType5.ResponsiveImage }, IxZEqDbFQ: VideoControls?.["srcFile"] && { ...VideoControls["srcFile"], __defaultAssetReference: "data:framer/asset-reference,fwA6d1SXErDfwYIO6DczvhOnyk.mp4?originalFilename=terrace-hero-video-faststart.mp4", description: void 0, hidden: void 0, title: "Video File" }, onIxZEqDbFQChange: { changes: "IxZEqDbFQ", type: ControlType5.ChangeHandler } });
addFonts(FramerzmH4gTyLg, [{ explicitInter: true, fonts: [] }, ...VideoFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerzmH4gTyLg", "slots": [], "annotations": { "framerContractVersion": "1", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]}}}', "framerAutoSizeImages": "true", "framerImmutableVariables": "true", "framerColorSyntax": "true", "framerDisplayContentsDiv": "false", "framerIntrinsicHeight": "736", "framerVariables": '{"KTEKLv2jD":"video","FxNnwMJAP":"backgroundImage","IxZEqDbFQ":"videoFile"}', "framerComponentViewportWidth": "true", "framerIntrinsicWidth": "1104" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  zmH4gTyLg_default as default
};
