var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/eQTpu6SrOEnJ9WPDnO2Y/3OjdvagMp1NfNaaU5WuI/ULRxBZjdd.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, FormSelect, getFonts, getPropertyControls, RichText, useActiveVariantCallback, useComponentViewport, useFormSelectVariableBinding, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/61VyZTFNHB3mhqkdeXGU/tFG705CP0bh6tiX90Y6B/qs7FKzEO5.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 11.67 1.77 L 9.89 0 L 0 9.9 L 9.9 19.8 L 11.67 18.03 L 3.54 9.9 Z" fill="var(--esondr, rgb(0,0,0))" height="19.79999px" id="C7PYhbBzU" transform="translate(6.165 2.1)" width="11.66996px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(motion.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx("div", { ...rest, ref });
});
var getProps = ({ fill, height, id, width, ...props }) => {
  return { ...props, K5AAorpEW: fill ?? props.K5AAorpEW ?? "rgb(0, 0, 0)" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, K5AAorpEW, ...restProps } = getProps(props);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-IGEtI", className), layoutId, ref, style: { "--esondr": K5AAorpEW, ...style } });
});
var css = [`.framer-IGEtI { -webkit-mask: ${mask}; aspect-ratio: 1; background-color: var(--esondr); mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-IGEtI");
Icon.displayName = "Arrow Back Ios";
var qs7FKzEO5_default = Icon;
addPropertyControls(Icon, { K5AAorpEW: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Fill", type: ControlType.Color } });

// http-url:https://framerusercontent.com/modules/x6Qmkj4laU56t3GZVcSF/1gMTZhQe1LftzJVGN1ND/hyPTlnA4N.js
import { addPropertyControls as e4, ControlType as l3, QueryEngine as t5 } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/x6Qmkj4laU56t3GZVcSF/1gMTZhQe1LftzJVGN1ND/hyPTlnA4N-0.js
import { ControlType as m } from "./_framer-runtime.js";
import { ControlType as R } from "./_framer-runtime.js";
var t;
var e = Object.create;
var r = Object.defineProperty;
var n = Object.getOwnPropertyDescriptor;
var i = Object.getOwnPropertyNames;
var s = Object.getPrototypeOf;
var a = Object.prototype.hasOwnProperty;
var o = (t10, e10, n7) => e10 in t10 ? r(t10, e10, { enumerable: true, configurable: true, writable: true, value: n7 }) : t10[e10] = n7;
var u = (t10, e10) => function() {
  try {
    return e10 || (0, t10[i(t10)[0]])((e10 = { exports: {} }).exports, e10), e10.exports;
  } catch (t11) {
    throw e10 = 0, t11;
  }
};
var l = (t10, e10, s7, o6) => {
  if (e10 && "object" == typeof e10 || "function" == typeof e10)
    for (let u7 of i(e10))
      a.call(t10, u7) || u7 === s7 || r(t10, u7, { get: () => e10[u7], enumerable: !(o6 = n(e10, u7)) || o6.enumerable });
  return t10;
};
var h = (t10, n7, i6) => (i6 = null != t10 ? e(s(t10)) : {}, l(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  !n7 && t10 && t10.__esModule ? i6 : r(i6, "default", { value: t10, enumerable: true }),
  t10
));
var c = (t10, e10, r5) => o(t10, "symbol" != typeof e10 ? e10 + "" : e10, r5);
var f = u({ "../../../node_modules/dataloader/index.js"(t10, e10) {
  var r5, n7 = /* @__PURE__ */ function() {
    function t11(t12, e12) {
      if ("function" != typeof t12)
        throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but got: " + t12 + ".");
      this._batchLoadFn = t12, this._maxBatchSize = function(t13) {
        if (!(!t13 || false !== t13.batch))
          return 1;
        var e13 = t13 && t13.maxBatchSize;
        if (void 0 === e13)
          return 1 / 0;
        if ("number" != typeof e13 || e13 < 1)
          throw TypeError("maxBatchSize must be a positive number: " + e13);
        return e13;
      }(e12), this._batchScheduleFn = function(t13) {
        var e13 = t13 && t13.batchScheduleFn;
        if (void 0 === e13)
          return i6;
        if ("function" != typeof e13)
          throw TypeError("batchScheduleFn must be a function: " + e13);
        return e13;
      }(e12), this._cacheKeyFn = function(t13) {
        var e13 = t13 && t13.cacheKeyFn;
        if (void 0 === e13)
          return function(t14) {
            return t14;
          };
        if ("function" != typeof e13)
          throw TypeError("cacheKeyFn must be a function: " + e13);
        return e13;
      }(e12), this._cacheMap = function(t13) {
        if (!(!t13 || false !== t13.cache))
          return null;
        var e13 = t13 && t13.cacheMap;
        if (void 0 === e13)
          return /* @__PURE__ */ new Map();
        if (null !== e13) {
          var r6 = ["get", "set", "delete", "clear"].filter(function(t14) {
            return e13 && "function" != typeof e13[t14];
          });
          if (0 !== r6.length)
            throw TypeError("Custom cacheMap missing methods: " + r6.join(", "));
        }
        return e13;
      }(e12), this._batch = null, this.name = e12 && e12.name ? e12.name : null;
    }
    var e11 = t11.prototype;
    return e11.load = function(t12) {
      if (null == t12)
        throw TypeError("The loader.load() function must be called with a value, but got: " + String(t12) + ".");
      var e12 = function(t13) {
        var e13 = t13._batch;
        if (null !== e13 && !e13.hasDispatched && e13.keys.length < t13._maxBatchSize)
          return e13;
        var r7 = { hasDispatched: false, keys: [], callbacks: [] };
        return t13._batch = r7, t13._batchScheduleFn(function() {
          (function(t14, e14) {
            var r8;
            if (e14.hasDispatched = true, 0 === e14.keys.length) {
              a5(e14);
              return;
            }
            try {
              r8 = t14._batchLoadFn(e14.keys);
            } catch (r9) {
              return s7(t14, e14, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function errored synchronously: " + String(r9) + "."));
            }
            if (!r8 || "function" != typeof r8.then)
              return s7(t14, e14, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise: " + String(r8) + "."));
            r8.then(function(t15) {
              if (!o6(t15))
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array: " + String(t15) + ".");
              if (t15.length !== e14.keys.length)
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array of the same length as the Array of keys.\n\nKeys:\n" + String(e14.keys) + "\n\nValues:\n" + String(t15));
              a5(e14);
              for (var r9 = 0; r9 < e14.callbacks.length; r9++) {
                var n9 = t15[r9];
                n9 instanceof Error ? e14.callbacks[r9].reject(n9) : e14.callbacks[r9].resolve(n9);
              }
            }).catch(function(r9) {
              s7(t14, e14, r9);
            });
          })(t13, r7);
        }), r7;
      }(this), r6 = this._cacheMap, n8 = this._cacheKeyFn(t12);
      if (r6) {
        var i7 = r6.get(n8);
        if (i7) {
          var u7 = e12.cacheHits || (e12.cacheHits = []);
          return new Promise(function(t13) {
            u7.push(function() {
              t13(i7);
            });
          });
        }
      }
      e12.keys.push(t12);
      var l7 = new Promise(function(t13, r7) {
        e12.callbacks.push({ resolve: t13, reject: r7 });
      });
      return r6 && r6.set(n8, l7), l7;
    }, e11.loadMany = function(t12) {
      if (!o6(t12))
        throw TypeError("The loader.loadMany() function must be called with Array<key> but got: " + t12 + ".");
      for (var e12 = [], r6 = 0; r6 < t12.length; r6++)
        e12.push(this.load(t12[r6]).catch(function(t13) {
          return t13;
        }));
      return Promise.all(e12);
    }, e11.clear = function(t12) {
      var e12 = this._cacheMap;
      if (e12) {
        var r6 = this._cacheKeyFn(t12);
        e12.delete(r6);
      }
      return this;
    }, e11.clearAll = function() {
      var t12 = this._cacheMap;
      return t12 && t12.clear(), this;
    }, e11.prime = function(t12, e12) {
      var r6 = this._cacheMap;
      if (r6) {
        var n8, i7 = this._cacheKeyFn(t12);
        void 0 === r6.get(i7) && (e12 instanceof Error ? (n8 = Promise.reject(e12)).catch(function() {
        }) : n8 = Promise.resolve(e12), r6.set(i7, n8));
      }
      return this;
    }, t11;
  }(), i6 = "object" == typeof process && "function" == typeof process.nextTick ? function(t11) {
    r5 || (r5 = Promise.resolve()), r5.then(function() {
      process.nextTick(t11);
    });
  } : "function" == typeof setImmediate ? function(t11) {
    setImmediate(t11);
  } : function(t11) {
    setTimeout(t11);
  };
  function s7(t11, e11, r6) {
    a5(e11);
    for (var n8 = 0; n8 < e11.keys.length; n8++)
      t11.clear(e11.keys[n8]), e11.callbacks[n8].reject(r6);
  }
  function a5(t11) {
    if (t11.cacheHits)
      for (var e11 = 0; e11 < t11.cacheHits.length; e11++)
        t11.cacheHits[e11]();
  }
  function o6(t11) {
    return "object" == typeof t11 && null !== t11 && "number" == typeof t11.length && (0 === t11.length || t11.length > 0 && Object.prototype.hasOwnProperty.call(t11, t11.length - 1));
  }
  e10.exports = n7;
} });
var g = h(f(), 1);
var d = { Uint8: 1, Uint16: 2, Uint32: 4, BigUint64: 8, Int8: 1, Int16: 2, Int32: 4, BigInt64: 8, Float32: 4, Float64: 8 };
var v = class t2 {
  getOffset() {
    return this.offset;
  }
  ensureLength(t10) {
    let e10 = this.bytes.length;
    if (!(this.offset + t10 <= e10))
      throw Error("Reading out of bounds");
  }
  readUint8() {
    let t10 = d.Uint8;
    this.ensureLength(t10);
    let e10 = this.view.getUint8(this.offset);
    return this.offset += t10, e10;
  }
  readUint16() {
    let t10 = d.Uint16;
    this.ensureLength(t10);
    let e10 = this.view.getUint16(this.offset);
    return this.offset += t10, e10;
  }
  readUint32() {
    let t10 = d.Uint32;
    this.ensureLength(t10);
    let e10 = this.view.getUint32(this.offset);
    return this.offset += t10, e10;
  }
  readUint64() {
    let t10 = this.readBigUint64();
    return Number(t10);
  }
  readBigUint64() {
    let t10 = d.BigUint64;
    this.ensureLength(t10);
    let e10 = this.view.getBigUint64(this.offset);
    return this.offset += t10, e10;
  }
  readInt8() {
    let t10 = d.Int8;
    this.ensureLength(t10);
    let e10 = this.view.getInt8(this.offset);
    return this.offset += t10, e10;
  }
  readInt16() {
    let t10 = d.Int16;
    this.ensureLength(t10);
    let e10 = this.view.getInt16(this.offset);
    return this.offset += t10, e10;
  }
  readInt32() {
    let t10 = d.Int32;
    this.ensureLength(t10);
    let e10 = this.view.getInt32(this.offset);
    return this.offset += t10, e10;
  }
  readInt64() {
    let t10 = this.readBigInt64();
    return Number(t10);
  }
  readBigInt64() {
    let t10 = d.BigInt64;
    this.ensureLength(t10);
    let e10 = this.view.getBigInt64(this.offset);
    return this.offset += t10, e10;
  }
  readFloat32() {
    let t10 = d.Float32;
    this.ensureLength(t10);
    let e10 = this.view.getFloat32(this.offset);
    return this.offset += t10, e10;
  }
  readFloat64() {
    let t10 = d.Float64;
    this.ensureLength(t10);
    let e10 = this.view.getFloat64(this.offset);
    return this.offset += t10, e10;
  }
  readBytes(t10) {
    let e10 = this.offset, r5 = e10 + t10, n7 = this.bytes.subarray(e10, r5);
    return this.offset = r5, n7;
  }
  readString() {
    let e10 = this.readUint32(), r5 = this.readBytes(e10);
    return t2.textDecoder.decode(r5);
  }
  readJson() {
    let t10 = this.readString();
    return JSON.parse(t10);
  }
  constructor(t10) {
    c(this, "bytes", t10), c(this, "offset", 0), c(this, "view"), this.view = p(this.bytes);
  }
};
c(v, "textDecoder", new TextDecoder());
var y = v;
function p(t10) {
  return new DataView(t10.buffer, t10.byteOffset, t10.byteLength);
}
var w = "undefined" != typeof __dai_window;
var I = w && "function" == typeof __dai_window.requestIdleCallback;
function b(t10, ...e10) {
  if (!t10)
    throw Error("Assertion Error" + (e10.length > 0 ? ": " + e10.join(" ") : ""));
}
function U(t10) {
  throw Error(`Unexpected value: ${t10}`);
}
var S = 1024;
var k = 1.5;
var L = (t10) => 2 ** t10 - 1;
var B = (t10) => -(2 ** (t10 - 1));
var E = (t10) => 2 ** (t10 - 1) - 1;
var T = { Uint8: 0, Uint16: 0, Uint32: 0, Uint64: 0, BigUint64: 0, Int8: B(8), Int16: B(16), Int32: B(32), Int64: Number.MIN_SAFE_INTEGER, BigInt64: -(BigInt(2) ** BigInt(63)) };
var M = { Uint8: L(8), Uint16: L(16), Uint32: L(32), Uint64: Number.MAX_SAFE_INTEGER, BigUint64: BigInt(2) ** BigInt(64) - BigInt(1), Int8: E(8), Int16: E(16), Int32: E(32), Int64: Number.MAX_SAFE_INTEGER, BigInt64: BigInt(2) ** BigInt(63) - BigInt(1) };
function F(t10, e10, r5, n7) {
  b(t10 >= e10, t10, "outside lower bound for", n7), b(t10 <= r5, t10, "outside upper bound for", n7);
}
var x = class {
  getOffset() {
    return this.offset;
  }
  slice(t10 = 0, e10 = this.offset) {
    return this.bytes.slice(t10, e10);
  }
  subarray(t10 = 0, e10 = this.offset) {
    return this.bytes.subarray(t10, e10);
  }
  ensureLength(t10) {
    let e10 = this.bytes.length;
    if (this.offset + t10 <= e10)
      return;
    let r5 = new Uint8Array(Math.ceil(e10 * k) + t10);
    r5.set(this.bytes), this.bytes = r5, this.view = p(r5);
  }
  writeUint8(t10) {
    F(t10, T.Uint8, M.Uint8, "Uint8");
    let e10 = d.Uint8;
    this.ensureLength(e10), this.view.setUint8(this.offset, t10), this.offset += e10;
  }
  writeUint16(t10) {
    F(t10, T.Uint16, M.Uint16, "Uint16");
    let e10 = d.Uint16;
    this.ensureLength(e10), this.view.setUint16(this.offset, t10), this.offset += e10;
  }
  writeUint32(t10) {
    F(t10, T.Uint32, M.Uint32, "Uint32");
    let e10 = d.Uint32;
    this.ensureLength(e10), this.view.setUint32(this.offset, t10), this.offset += e10;
  }
  writeUint64(t10) {
    F(t10, T.Uint64, M.Uint64, "Uint64");
    let e10 = BigInt(t10);
    this.writeBigUint64(e10);
  }
  writeBigUint64(t10) {
    F(t10, T.BigUint64, M.BigUint64, "BigUint64");
    let e10 = d.BigUint64;
    this.ensureLength(e10), this.view.setBigUint64(this.offset, t10), this.offset += e10;
  }
  writeInt8(t10) {
    F(t10, T.Int8, M.Int8, "Int8");
    let e10 = d.Int8;
    this.ensureLength(e10), this.view.setInt8(this.offset, t10), this.offset += e10;
  }
  writeInt16(t10) {
    F(t10, T.Int16, M.Int16, "Int16");
    let e10 = d.Int16;
    this.ensureLength(e10), this.view.setInt16(this.offset, t10), this.offset += e10;
  }
  writeInt32(t10) {
    F(t10, T.Int32, M.Int32, "Int32");
    let e10 = d.Int32;
    this.ensureLength(e10), this.view.setInt32(this.offset, t10), this.offset += e10;
  }
  writeInt64(t10) {
    F(t10, T.Int64, M.Int64, "Int64");
    let e10 = BigInt(t10);
    this.writeBigInt64(e10);
  }
  writeBigInt64(t10) {
    F(t10, T.BigInt64, M.BigInt64, "BigInt64");
    let e10 = d.BigInt64;
    this.ensureLength(e10), this.view.setBigInt64(this.offset, t10), this.offset += e10;
  }
  writeFloat32(t10) {
    let e10 = d.Float32;
    this.ensureLength(e10), this.view.setFloat32(this.offset, t10), this.offset += e10;
  }
  writeFloat64(t10) {
    let e10 = d.Float64;
    this.ensureLength(e10), this.view.setFloat64(this.offset, t10), this.offset += e10;
  }
  writeBytes(t10) {
    let e10 = t10.length;
    this.ensureLength(e10), this.bytes.set(t10, this.offset), this.offset += e10;
  }
  encodeString(t10) {
    let e10 = this.encodedStrings.get(t10);
    if (e10)
      return e10;
    let r5 = this.encoder.encode(t10);
    return this.encodedStrings.set(t10, r5), r5;
  }
  writeString(t10) {
    let e10 = this.encodeString(t10), r5 = e10.length;
    this.writeUint32(r5), this.writeBytes(e10);
  }
  writeJson(t10) {
    let e10 = JSON.stringify(t10);
    this.writeString(e10);
  }
  constructor() {
    c(this, "offset", 0), c(this, "bytes", new Uint8Array(S)), c(this, "view", p(this.bytes)), c(this, "encoder", new TextEncoder()), c(this, "encodedStrings", /* @__PURE__ */ new Map());
  }
};
function N(t10) {
  return "string" == typeof t10;
}
function A(t10) {
  return Number.isFinite(t10);
}
function O(t10) {
  return null === t10;
}
var P = class t3 {
  static fromString(e10) {
    let [r5, n7, i6] = e10.split("/").map(Number);
    return b(A(r5), "Invalid chunkId"), b(A(n7), "Invalid offset"), b(A(i6), "Invalid length"), new t3(r5, n7, i6);
  }
  toString() {
    return `${this.chunkId}/${this.offset}/${this.length}`;
  }
  static read(e10) {
    let r5 = e10.readUint16(), n7 = e10.readUint32(), i6 = e10.readUint32();
    return new t3(r5, n7, i6);
  }
  write(t10) {
    t10.writeUint16(this.chunkId), t10.writeUint32(this.offset), t10.writeUint32(this.length);
  }
  compare(t10) {
    return this.chunkId < t10.chunkId ? -1 : this.chunkId > t10.chunkId ? 1 : this.offset < t10.offset ? -1 : this.offset > t10.offset ? 1 : (b(this.length === t10.length), 0);
  }
  constructor(t10, e10, r5) {
    c(this, "chunkId", t10), c(this, "offset", e10), c(this, "length", r5);
  }
};
function q(t10) {
  if (O(t10))
    return 0;
  switch (t10.type) {
    case R.Array:
      return 1;
    case R.Boolean:
      return 2;
    case R.Color:
      return 3;
    case R.Date:
      return 4;
    case R.Enum:
      return 5;
    case R.File:
      return 6;
    case R.ResponsiveImage:
      return 10;
    case R.Link:
      return 7;
    case R.Number:
      return 8;
    case R.Object:
      return 9;
    case R.RichText:
      return 11;
    case R.String:
      return 12;
    case R.VectorSetItem:
      return 13;
    default:
      U(t10);
  }
}
function _(e10) {
  let r5 = e10.readUint16(), n7 = [];
  for (let i6 = 0; i6 < r5; i6++) {
    let r6 = t.read(e10);
    n7.push(r6);
  }
  return { type: R.Array, value: n7 };
}
function j(e10, r5) {
  for (let n7 of (e10.writeUint16(r5.value.length), r5.value))
    t.write(e10, n7);
}
function D(e10, r5, n7) {
  let i6 = e10.value.length, s7 = r5.value.length;
  if (i6 < s7)
    return -1;
  if (i6 > s7)
    return 1;
  for (let s8 = 0; s8 < i6; s8++) {
    let i7 = e10.value[s8], a5 = r5.value[s8], o6 = t.compare(i7, a5, n7);
    if (0 !== o6)
      return o6;
  }
  return 0;
}
function C(t10) {
  return { type: R.Boolean, value: 0 !== t10.readUint8() };
}
function J(t10, e10) {
  t10.writeUint8(e10.value ? 1 : 0);
}
function V(t10, e10) {
  return t10.value < e10.value ? -1 : t10.value > e10.value ? 1 : 0;
}
function W(t10) {
  return { type: R.Color, value: t10.readString() };
}
function $(t10, e10) {
  t10.writeString(e10.value);
}
function z(t10, e10) {
  return t10.value < e10.value ? -1 : t10.value > e10.value ? 1 : 0;
}
function G(t10) {
  let e10 = t10.readInt64(), r5 = new Date(e10);
  return { type: R.Date, value: r5.toISOString() };
}
function K(t10, e10) {
  let r5 = new Date(e10.value), n7 = r5.getTime();
  t10.writeInt64(n7);
}
function H(t10, e10) {
  let r5 = new Date(t10.value), n7 = new Date(e10.value);
  return r5 < n7 ? -1 : r5 > n7 ? 1 : 0;
}
function X(t10) {
  return { type: R.Enum, value: t10.readString() };
}
function Q(t10, e10) {
  t10.writeString(e10.value);
}
function Y(t10, e10) {
  return t10.value < e10.value ? -1 : t10.value > e10.value ? 1 : 0;
}
function Z(t10) {
  return { type: R.File, value: t10.readString() };
}
function tt(t10, e10) {
  t10.writeString(e10.value);
}
function te(t10, e10) {
  return t10.value < e10.value ? -1 : t10.value > e10.value ? 1 : 0;
}
function tr(t10) {
  return { type: R.Link, value: t10.readJson() };
}
function tn(t10, e10) {
  t10.writeJson(e10.value);
}
function ti(t10, e10) {
  let r5 = JSON.stringify(t10.value), n7 = JSON.stringify(e10.value);
  return r5 < n7 ? -1 : r5 > n7 ? 1 : 0;
}
function ts(t10) {
  return { type: R.Number, value: t10.readFloat64() };
}
function ta(t10, e10) {
  t10.writeFloat64(e10.value);
}
function to(t10, e10) {
  return t10.value < e10.value ? -1 : t10.value > e10.value ? 1 : 0;
}
function tu(e10) {
  let r5 = e10.readUint16(), n7 = {};
  for (let i6 = 0; i6 < r5; i6++) {
    let r6 = e10.readString();
    n7[r6] = t.read(e10);
  }
  return { type: R.Object, value: n7 };
}
function tl(e10, r5) {
  let n7 = Object.entries(r5.value);
  for (let [r6, i6] of (e10.writeUint16(n7.length), n7))
    e10.writeString(r6), t.write(e10, i6);
}
function th(e10, r5, n7) {
  let i6 = Object.keys(e10.value).sort(), s7 = Object.keys(r5.value).sort();
  if (i6.length < s7.length)
    return -1;
  if (i6.length > s7.length)
    return 1;
  for (let a5 = 0; a5 < i6.length; a5++) {
    let o6 = i6[a5], u7 = s7[a5];
    if (o6 < u7)
      return -1;
    if (o6 > u7)
      return 1;
    let l7 = e10.value[o6] ?? null, h5 = r5.value[u7] ?? null, c7 = t.compare(l7, h5, n7);
    if (0 !== c7)
      return c7;
  }
  return 0;
}
function tc(t10) {
  return { type: R.ResponsiveImage, value: t10.readJson() };
}
function tf(t10, e10) {
  t10.writeJson(e10.value);
}
function tg(t10, e10) {
  let r5 = JSON.stringify(t10.value), n7 = JSON.stringify(e10.value);
  return r5 < n7 ? -1 : r5 > n7 ? 1 : 0;
}
function td(t10) {
  let e10 = t10.readInt8();
  if (0 === e10)
    return { type: R.RichText, value: t10.readUint32() };
  if (1 === e10)
    return { type: R.RichText, value: t10.readString() };
  throw Error("Invalid rich text pointer");
}
function tv(t10, e10) {
  if (A(e10.value)) {
    t10.writeInt8(0), t10.writeUint32(e10.value);
    return;
  }
  if (N(e10.value)) {
    t10.writeInt8(1), t10.writeString(e10.value);
    return;
  }
  throw Error("Invalid rich text pointer");
}
function ty(t10, e10) {
  let r5 = t10.value, n7 = e10.value;
  if (A(r5) && A(n7) || N(r5) && N(n7))
    return r5 < n7 ? -1 : r5 > n7 ? 1 : 0;
  throw Error("Invalid rich text pointer");
}
function tp(t10) {
  return { type: R.String, value: t10.readString() };
}
function tm(t10, e10) {
  t10.writeString(e10.value);
}
function tw(t10, e10, r5) {
  let n7 = t10.value, i6 = e10.value;
  return (0 === r5.type && (n7 = t10.value.toLowerCase(), i6 = e10.value.toLowerCase()), n7 < i6) ? -1 : n7 > i6 ? 1 : 0;
}
function tI(t10) {
  return { type: R.VectorSetItem, value: t10.readUint32() };
}
function tb(t10, e10) {
  t10.writeUint32(e10.value);
}
function tU(t10, e10) {
  let r5 = t10.value, n7 = e10.value;
  return r5 < n7 ? -1 : r5 > n7 ? 1 : 0;
}
((t10) => {
  t10.read = function(t11) {
    let e10 = t11.readUint8();
    switch (e10) {
      case 0:
        return null;
      case 1:
        return _(t11);
      case 2:
        return C(t11);
      case 3:
        return W(t11);
      case 4:
        return G(t11);
      case 5:
        return X(t11);
      case 6:
        return Z(t11);
      case 7:
        return tr(t11);
      case 8:
        return ts(t11);
      case 9:
        return tu(t11);
      case 10:
        return tc(t11);
      case 11:
        return td(t11);
      case 12:
        return tp(t11);
      case 13:
        return tI(t11);
      default:
        U(e10);
    }
  }, t10.write = function(t11, e10) {
    let r5 = q(e10);
    if (t11.writeUint8(r5), !O(e10))
      switch (e10.type) {
        case R.Array:
          return j(t11, e10);
        case R.Boolean:
          return J(t11, e10);
        case R.Color:
          return $(t11, e10);
        case R.Date:
          return K(t11, e10);
        case R.Enum:
          return Q(t11, e10);
        case R.File:
          return tt(t11, e10);
        case R.Link:
          return tn(t11, e10);
        case R.Number:
          return ta(t11, e10);
        case R.Object:
          return tl(t11, e10);
        case R.ResponsiveImage:
          return tf(t11, e10);
        case R.RichText:
          return tv(t11, e10);
        case R.VectorSetItem:
          return tb(t11, e10);
        case R.String:
          return tm(t11, e10);
        default:
          U(e10);
      }
  }, t10.compare = function(t11, e10, r5) {
    let n7 = q(t11), i6 = q(e10);
    if (n7 < i6)
      return -1;
    if (n7 > i6)
      return 1;
    if (O(t11) || O(e10))
      return 0;
    switch (t11.type) {
      case R.Array:
        return b(e10.type === R.Array), D(t11, e10, r5);
      case R.Boolean:
        return b(e10.type === R.Boolean), V(t11, e10);
      case R.Color:
        return b(e10.type === R.Color), z(t11, e10);
      case R.Date:
        return b(e10.type === R.Date), H(t11, e10);
      case R.Enum:
        return b(e10.type === R.Enum), Y(t11, e10);
      case R.File:
        return b(e10.type === R.File), te(t11, e10);
      case R.Link:
        return b(e10.type === R.Link), ti(t11, e10);
      case R.Number:
        return b(e10.type === R.Number), to(t11, e10);
      case R.Object:
        return b(e10.type === R.Object), th(t11, e10, r5);
      case R.ResponsiveImage:
        return b(e10.type === R.ResponsiveImage), tg(t11, e10);
      case R.RichText:
        return b(e10.type === R.RichText), ty(t11, e10);
      case R.VectorSetItem:
        return b(e10.type === R.VectorSetItem), tU(t11, e10);
      case R.String:
        return b(e10.type === R.String), tw(t11, e10, r5);
      default:
        U(t11);
    }
  };
})(t || (t = {}));
var tS = class e2 {
  sortEntries() {
    this.entries.sort((e10, r5) => {
      for (let n7 = 0; n7 < this.fieldNames.length; n7++) {
        let i6 = e10.values[n7], s7 = r5.values[n7], a5 = t.compare(i6, s7, this.options.collation);
        if (0 !== a5)
          return a5;
      }
      return e10.pointer.compare(r5.pointer);
    });
  }
  static deserialize(r5) {
    let n7 = new y(r5), i6 = n7.readJson(), s7 = n7.readUint8(), a5 = [];
    for (let t10 = 0; t10 < s7; t10++) {
      let t11 = n7.readString();
      a5.push(t11);
    }
    let o6 = new e2(a5, { collation: i6 }), u7 = n7.readUint32();
    for (let e10 = 0; e10 < u7; e10++) {
      let e11 = [];
      for (let r7 = 0; r7 < s7; r7++) {
        let r8 = t.read(n7);
        e11.push(r8);
      }
      let r6 = P.read(n7);
      o6.entries.push({ values: e11, pointer: r6 });
    }
    return o6;
  }
  serialize() {
    let e10 = new x();
    for (let t10 of (e10.writeJson(this.options.collation), e10.writeUint8(this.fieldNames.length), this.fieldNames))
      e10.writeString(t10);
    for (let r5 of (this.sortEntries(), e10.writeUint32(this.entries.length), this.entries)) {
      let { values: n7, pointer: i6 } = r5;
      for (let r6 of n7)
        t.write(e10, r6);
      i6.write(e10);
    }
    return e10.subarray();
  }
  addItem(t10, e10) {
    let r5 = this.fieldNames.map((e11) => t10.getField(e11) ?? null);
    this.entries.push({ values: r5, pointer: e10 });
  }
  constructor(t10, e10) {
    c(this, "fieldNames", t10), c(this, "options", e10), c(this, "entries", []);
  }
};
var tk = 3;
var tL = 250;
var tB = [
  408,
  // Request Timeout
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
];
var tE = async (t10, e10) => {
  let r5 = 0;
  for (; ; ) {
    try {
      let n7 = await fetch(t10, e10);
      if (!tB.includes(n7.status) || ++r5 > tk)
        return n7;
    } catch (t11) {
      if (e10?.signal?.aborted || ++r5 > tk)
        throw t11;
    }
    await tT(r5);
  }
};
async function tT(t10) {
  let e10 = Math.floor(tL * (Math.random() + 1) * 2 ** (t10 - 1));
  await new Promise((t11) => {
    setTimeout(t11, e10);
  });
}
async function tM(t10, e10) {
  let r5 = tN(e10), n7 = [], i6 = 0;
  for (let t11 of r5)
    n7.push(`${t11.from}-${t11.to - 1}`), i6 += t11.to - t11.from;
  let s7 = new URL(t10), a5 = n7.join(",");
  s7.searchParams.set("range", a5);
  let o6 = await tE(s7);
  if (200 !== o6.status)
    throw Error(`Request failed: ${o6.status} ${o6.statusText}`);
  let u7 = await o6.arrayBuffer(), l7 = new Uint8Array(u7);
  if (l7.length !== i6)
    throw Error("Request failed: Unexpected response length");
  let h5 = new tF(), c7 = 0;
  for (let t11 of r5) {
    let e11 = t11.to - t11.from, r6 = c7 + e11, n8 = l7.subarray(c7, r6);
    h5.write(t11.from, n8), c7 = r6;
  }
  return e10.map((t11) => h5.read(t11.from, t11.to - t11.from));
}
var tF = class {
  read(t10, e10) {
    for (let r5 of this.chunks) {
      if (t10 < r5.start)
        break;
      if (t10 > r5.end)
        continue;
      if (t10 + e10 > r5.end)
        break;
      let n7 = t10 - r5.start, i6 = n7 + e10;
      return r5.data.slice(n7, i6);
    }
    throw Error("Missing data");
  }
  write(t10, e10) {
    let r5 = t10, n7 = r5 + e10.length, i6 = 0, s7 = this.chunks.length;
    for (; i6 < s7; i6++) {
      let t11 = this.chunks[i6];
      if (b(t11, "Missing chunk"), !(r5 > t11.end)) {
        if (r5 > t11.start) {
          let n8 = r5 - t11.start, i7 = t11.data.subarray(0, n8);
          e10 = tx(i7, e10), r5 = t11.start;
        }
        break;
      }
    }
    for (; s7 > i6; s7--) {
      let t11 = this.chunks[s7 - 1];
      if (b(t11, "Missing chunk"), !(n7 < t11.start)) {
        if (n7 < t11.end) {
          let r6 = n7 - t11.start, i7 = t11.data.subarray(r6);
          e10 = tx(e10, i7), n7 = t11.end;
        }
        break;
      }
    }
    let a5 = { start: r5, end: n7, data: e10 }, o6 = s7 - i6;
    this.chunks.splice(i6, o6, a5);
  }
  constructor() {
    c(this, "chunks", []);
  }
};
function tx(t10, e10) {
  let r5 = t10.length + e10.length, n7 = new Uint8Array(r5);
  return n7.set(t10, 0), n7.set(e10, t10.length), n7;
}
function tN(t10) {
  b(t10.length > 0, "Must have at least one range");
  let e10 = [...t10].sort((t11, e11) => t11.from - e11.from), r5 = [];
  for (let t11 of e10) {
    let e11 = r5.length - 1, n7 = r5[e11];
    n7 && t11.from <= n7.to ? r5[e11] = { from: n7.from, to: Math.max(n7.to, t11.to) } : r5.push(t11);
  }
  return r5;
}
var tA = class {
  async loadModel() {
    let [t10] = await tM(this.options.url, [this.options.range]);
    return b(t10, "Failed to load model"), tS.deserialize(t10);
  }
  async getModel() {
    return this.modelPromise ?? (this.modelPromise = this.loadModel()), this.model ?? (this.model = await this.modelPromise), this.model;
  }
  async lookupItems(t10) {
    b(t10.length === this.fields.length, "Invalid query length");
    let e10 = await this.getModel(), r5 = t10.reduce((t11, e11, r6) => t11.flatMap((t12) => {
      switch (e11.type) {
        case "All":
          return [t12];
        case "Equals":
          return this.queryEquals(t12, e11, r6);
        case "NotEquals":
          return this.queryNotEquals(t12, e11, r6);
        case "LessThan":
          return this.queryLessThan(t12, e11, r6);
        case "GreaterThan":
          return this.queryGreaterThan(t12, e11, r6);
        case "Contains":
          return this.queryContains(t12, e11, r6);
        case "StartsWith":
          return this.queryStartsWith(t12, e11, r6);
        case "EndsWith":
          return this.queryEndsWith(t12, e11, r6);
        default:
          U(e11);
      }
    }), [e10.entries]), n7 = [];
    for (let t11 of r5)
      for (let e11 of t11) {
        let t12 = {};
        for (let r6 = 0; r6 < this.options.fieldNames.length; r6++) {
          let n8 = this.options.fieldNames[r6], i6 = e11.values[r6];
          t12[n8] = i6;
        }
        n7.push({ pointer: e11.pointer.toString(), data: t12 });
      }
    return n7;
  }
  queryEquals(t10, e10, r5) {
    let n7 = this.getLeftMost(t10, r5, e10.value), i6 = this.getRightMost(t10, r5, e10.value), s7 = t10.slice(n7, i6 + 1);
    return s7.length > 0 ? [s7] : [];
  }
  queryNotEquals(t10, e10, r5) {
    let n7 = this.getLeftMost(t10, r5, e10.value), i6 = this.getRightMost(t10, r5, e10.value), s7 = [], a5 = t10.slice(0, n7);
    a5.length > 0 && s7.push(a5);
    let o6 = t10.slice(i6 + 1);
    return o6.length > 0 && s7.push(o6), s7;
  }
  queryLessThan(t10, e10, r5) {
    let n7 = this.getRightMost(t10, r5, null);
    if (t10 = t10.slice(n7 + 1), e10.inclusive) {
      let n8 = this.getRightMost(t10, r5, e10.value), i7 = t10.slice(0, n8 + 1);
      return i7.length > 0 ? [i7] : [];
    }
    let i6 = this.getLeftMost(t10, r5, e10.value), s7 = t10.slice(0, i6);
    return s7.length > 0 ? [s7] : [];
  }
  queryGreaterThan(t10, e10, r5) {
    let n7 = this.getRightMost(t10, r5, null);
    if (t10 = t10.slice(n7 + 1), e10.inclusive) {
      let n8 = this.getLeftMost(t10, r5, e10.value), i7 = t10.slice(n8);
      return i7.length > 0 ? [i7] : [];
    }
    let i6 = this.getRightMost(t10, r5, e10.value), s7 = t10.slice(i6 + 1);
    return s7.length > 0 ? [s7] : [];
  }
  queryContains(t10, e10, r5) {
    return this.findItems(t10, r5, (t11) => {
      if (t11?.type !== m.String || e10.value?.type !== m.String)
        return false;
      let r6 = t11.value, n7 = e10.value.value;
      return 0 === this.collation.type && (r6 = r6.toLowerCase(), n7 = n7.toLowerCase()), r6.includes(n7);
    });
  }
  queryStartsWith(t10, e10, r5) {
    return this.findItems(t10, r5, (t11) => {
      if (t11?.type !== m.String || e10.value?.type !== m.String)
        return false;
      let r6 = t11.value, n7 = e10.value.value;
      return 0 === this.collation.type && (r6 = r6.toLowerCase(), n7 = n7.toLowerCase()), r6.startsWith(n7);
    });
  }
  queryEndsWith(t10, e10, r5) {
    return this.findItems(t10, r5, (t11) => {
      if (t11?.type !== m.String || e10.value?.type !== m.String)
        return false;
      let r6 = t11.value, n7 = e10.value.value;
      return 0 === this.collation.type && (r6 = r6.toLowerCase(), n7 = n7.toLowerCase()), r6.endsWith(n7);
    });
  }
  /**
  * Returns the index of the left most entry that is equal to the target.
  *
  * ```text
  *   Left most
  *       ↓
  * ┌───┬───┬───┬───┬───┬───┐
  * │ 1 │ 2 │ 2 │ 2 │ 2 │ 3 │
  * └───┴───┴───┴───┴───┴───┘
  * ```
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param target The target value to search for.
  * @returns The index of the left most entry that is equal to the target.
  */
  getLeftMost(e10, r5, n7) {
    let i6 = 0, s7 = e10.length;
    for (; i6 < s7; ) {
      let a5 = i6 + s7 >> 1, o6 = e10[a5], u7 = o6.values[r5];
      0 > t.compare(u7, n7, this.collation) ? i6 = a5 + 1 : s7 = a5;
    }
    return i6;
  }
  /**
  * Returns the index of the right most entry that is equal to the target.
  *
  * ```text
  *              Right most
  *                   ↓
  * ┌───┬───┬───┬───┬───┬───┐
  * │ 1 │ 2 │ 2 │ 2 │ 2 │ 3 │
  * └───┴───┴───┴───┴───┴───┘
  * ```
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param target The target value to search for.
  * @returns The index of the right most entry that is equal to the target.
  */
  getRightMost(e10, r5, n7) {
    let i6 = 0, s7 = e10.length;
    for (; i6 < s7; ) {
      let a5 = i6 + s7 >> 1, o6 = e10[a5], u7 = o6.values[r5];
      t.compare(u7, n7, this.collation) > 0 ? s7 = a5 : i6 = a5 + 1;
    }
    return s7 - 1;
  }
  /**
  * Finds all items that are matching the predicate and groups adjacent items together.
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param predicate The predicate to match the values against.
  * @returns An array of chunks that match the predicate.
  */
  findItems(t10, e10, r5) {
    let n7 = [], i6 = 0;
    for (let s7 = 0; s7 < t10.length; s7++) {
      let a5 = t10[s7], o6 = a5.values[e10], u7 = r5(o6);
      if (!u7) {
        if (i6 < s7) {
          let e11 = t10.slice(i6, s7);
          n7.push(e11);
        }
        i6 = s7 + 1;
      }
    }
    if (i6 < t10.length) {
      let e11 = t10.slice(i6);
      n7.push(e11);
    }
    return n7;
  }
  constructor(t10) {
    c(this, "options", t10), c(this, "schema"), c(this, "fields"), c(this, "supportedLookupTypes", [
      "All",
      "Equals",
      "NotEquals",
      "LessThan",
      "GreaterThan",
      "Contains",
      "StartsWith",
      "EndsWith"
      /* EndsWith */
    ]), c(this, "modelPromise"), c(this, "model"), c(this, "collation");
    let e10 = {}, r5 = [];
    for (let t11 of this.options.fieldNames) {
      let n7 = this.options.collectionSchema[t11];
      b(n7, "Missing definition for field", t11), e10[t11] = n7, r5.push({ type: "Identifier", name: t11 });
    }
    this.schema = e10, this.fields = r5, this.collation = this.options.collation;
  }
};
function tO(e10) {
  let r5 = {}, n7 = e10.readUint16();
  for (let i6 = 0; i6 < n7; i6++) {
    let n8 = e10.readString();
    r5[n8] = t.read(e10);
  }
  return r5;
}
var tP = class {
  scanItems() {
    return this.itemsPromise ?? (this.itemsPromise = tE(this.url).then(async (t10) => {
      if (!t10.ok)
        throw Error(`Request failed: ${t10.status} ${t10.statusText}`);
      let e10 = await t10.arrayBuffer(), r5 = new Uint8Array(e10), n7 = new y(r5), i6 = [], s7 = n7.readUint32();
      for (let t11 = 0; t11 < s7; t11++) {
        let t12 = n7.getOffset(), e11 = tO(n7), r6 = n7.getOffset() - t12, s8 = new P(this.id, t12, r6), a5 = s8.toString(), o6 = { pointer: a5, data: e11 };
        this.itemLoader.prime(a5, o6), i6.push(o6);
      }
      return i6;
    })), this.itemsPromise;
  }
  resolveItem(t10) {
    return this.itemLoader.load(t10);
  }
  constructor(t10, e10) {
    c(this, "id", t10), c(this, "url", e10), c(this, "itemsPromise"), c(this, "itemLoader", new g.default(async (t11) => {
      let e11 = t11.map((t12) => {
        let e12 = P.fromString(t12);
        return { from: e12.offset, to: e12.offset + e12.length };
      }), r5 = await tM(this.url, e11);
      return r5.map((e12, r6) => {
        let n7 = new y(e12), i6 = tO(n7), s7 = t11[r6];
        return b(s7, "Missing pointer"), { pointer: s7, data: i6 };
      });
    }, { maxBatchSize: 250 }));
  }
};
var tR = class {
  async scanItems() {
    let t10 = await Promise.all(this.chunks.map(async (t11) => t11.scanItems()));
    return t10.flat();
  }
  resolveItems(t10) {
    return Promise.all(t10.map((t11) => {
      let e10 = P.fromString(t11), r5 = this.chunks[e10.chunkId];
      return b(r5, "Missing chunk"), r5.resolveItem(t11);
    }));
  }
  compareItems(t10, e10) {
    let r5 = P.fromString(t10.pointer), n7 = P.fromString(e10.pointer);
    return r5.compare(n7);
  }
  compareValues(e10, r5, n7) {
    return t.compare(e10, r5, n7);
  }
  constructor(t10) {
    c(this, "options", t10), c(this, "id"), c(this, "schema"), c(this, "indexes"), c(this, "resolveRichText"), c(this, "resolveVectorSetItem"), c(this, "chunks"), this.chunks = this.options.chunks.map((t11, e10) => new tP(e10, t11)), this.schema = t10.schema, this.indexes = t10.indexes, this.resolveRichText = t10.resolveRichText, this.resolveVectorSetItem = t10.resolveVectorSetItem, this.id = t10.id;
  }
};

// http-url:https://framerusercontent.com/modules/x6Qmkj4laU56t3GZVcSF/1gMTZhQe1LftzJVGN1ND/hyPTlnA4N-1.js
import { jsx as e3 } from "react/jsx-runtime";
import { AutoBreakpointVariant as t4, ComponentPresetsConsumer as r2, Link as n2, motion as o2 } from "./_framer-runtime.js";
import { isValidElement as i2 } from "react";
import { Fragment as p2, createElement as s2 } from "react";
var a2;
var l2 = "undefined" != typeof __dai_window;
var f2 = l2 && "function" == typeof __dai_window.requestIdleCallback;
var u2 = "preload";
function c2(e10) {
  return "object" == typeof e10 && null !== e10 && !/* @__PURE__ */ i2(e10) && u2 in e10;
}
function m2(e10, ...t10) {
  if (!e10)
    throw Error("Assertion Error" + (t10.length > 0 ? ": " + t10.join(" ") : ""));
}
var d2 = ((a2 = d2 || {})[a2.Fragment = 1] = "Fragment", a2[a2.Link = 2] = "Link", a2[a2.Module = 3] = "Module", a2[a2.Tag = 4] = "Tag", a2[a2.Text = 5] = "Text", a2);
function g2(i6) {
  let a5 = /* @__PURE__ */ new Map();
  return (l7) => {
    let f7 = a5.get(l7);
    if (f7)
      return f7;
    let u7 = JSON.parse(l7), d7 = function a6(l8) {
      switch (l8[0]) {
        case 1: {
          let [, ...e10] = l8, t10 = e10.map(a6);
          return /* @__PURE__ */ s2(p2, void 0, ...t10);
        }
        case 2: {
          let [, e10, ...t10] = l8, r5 = t10.map(a6);
          return /* @__PURE__ */ s2(n2, e10, ...r5);
        }
        case 3: {
          let [, n7, o6, f8, u8] = l8;
          for (let e10 of f8) {
            let t10 = o6[e10];
            t10 && (o6[e10] = a6(t10));
          }
          for (let e10 of u8) {
            let t10 = o6[e10];
            if ("string" != typeof t10)
              continue;
            let r5 = i6[t10];
            r5 && (c2(r5) && r5.preload(), o6[e10] = r5);
          }
          let p7 = i6[n7];
          return m2(p7, "Module not found"), c2(p7) && p7.preload(), /* @__PURE__ */ e3(r2, { componentIdentifier: n7, children: (r5) => /* @__PURE__ */ e3(t4, { component: p7, props: { ...r5, ...o6 } }) });
        }
        case 4: {
          let [, e10, t10, ...r5] = l8, n7 = r5.map(a6);
          if ("a" === e10)
            return /* @__PURE__ */ s2(o2.a, t10, ...n7);
          return /* @__PURE__ */ s2(e10, t10, ...n7);
        }
        case 5: {
          let [, e10] = l8;
          return e10;
        }
      }
    }(u7);
    return a5.set(l7, d7), d7;
  };
}

// http-url:https://framerusercontent.com/modules/x6Qmkj4laU56t3GZVcSF/1gMTZhQe1LftzJVGN1ND/hyPTlnA4N.js
var n3 = { a6ujXfENo: { isNullable: true, type: l3.String }, ajZz7riKD: { isNullable: true, type: l3.ResponsiveImage }, c_Ztb3H9y: { isNullable: true, type: l3.String }, createdAt: { isNullable: true, type: l3.Date }, dQx3F9Jie: { isNullable: true, type: l3.ResponsiveImage }, FuDmHCZ5S: { isNullable: true, type: l3.ResponsiveImage }, ged3yBesp: { isNullable: true, type: l3.String }, gEHVSojsb: { isNullable: true, type: l3.ResponsiveImage }, GphWkGDid: { isNullable: true, type: l3.ResponsiveImage }, H6xmtp_Vj: { isNullable: true, type: l3.String }, hwa2ZlYjU: { isNullable: true, type: l3.String }, IcL3UIni1: { isNullable: true, type: l3.String }, id: { isNullable: false, type: l3.String }, kLA2iEZd7: { isNullable: true, type: l3.ResponsiveImage }, LpCldKl4r: { isNullable: true, type: l3.ResponsiveImage }, lwtk4AApP: { isNullable: true, type: l3.ResponsiveImage }, M7YTgre20: { isNullable: true, type: l3.ResponsiveImage }, nextItemId: { isNullable: true, type: l3.String }, NXnq1Sp6P: { isNullable: true, type: l3.String }, oTd1EpE24: { isNullable: true, type: l3.RichText }, PafrptGQk: { isNullable: true, type: l3.ResponsiveImage }, PbM630afL: { isNullable: true, type: l3.ResponsiveImage }, po6DD0Ss5: { isNullable: true, type: l3.Link }, previousItemId: { isNullable: true, type: l3.String }, QGpl2b70E: { isNullable: true, type: l3.String }, QljAkgFAS: { isNullable: true, type: l3.ResponsiveImage }, r4IQRQwrW: { isNullable: true, type: l3.String }, rcds5P2rE: { isNullable: true, type: l3.String }, RJeXa6amv: { isNullable: true, type: l3.String }, rk3Q6WzbW: { isNullable: true, type: l3.String }, RQHJv9fZW: { isNullable: true, type: l3.Enum }, snQxG7xuO: { isNullable: true, type: l3.Enum }, sRFHXx5Ye: { isNullable: true, type: l3.String }, TQ06FQZj0: { isNullable: true, type: l3.String }, updatedAt: { isNullable: true, type: l3.Date }, V_GcUixzS: { isNullable: true, type: l3.ResponsiveImage }, VD6Y5bYH7: { isNullable: true, type: l3.String }, Wkif7C6rK: { isNullable: true, type: l3.String }, XTDYAmTwl: { isNullable: true, type: l3.ResponsiveImage }, y5C1gzvnF: { isNullable: true, type: l3.Enum }, YcY2udl5Q: { isNullable: true, type: l3.String }, zCKFz0aMd: { isNullable: true, type: l3.String }, ZOi_NWo7j: { isNullable: true, type: l3.String }, zvsKfuoA9: { isNullable: true, type: l3.Enum } };
var i3 = ["id"];
var m3 = { type: 1 };
var s3 = ["previousItemId"];
var c3 = ["nextItemId"];
var u3 = ["id", "rcds5P2rE"];
var d3 = ["rcds5P2rE", "id"];
var f3 = ["dQx3F9Jie"];
var p3 = { type: 0 };
var y2 = ["ged3yBesp"];
var h2 = ["QGpl2b70E"];
var g3 = ["VD6Y5bYH7"];
var N2 = ["H6xmtp_Vj"];
var w2 = ["zvsKfuoA9"];
var S2 = ["y5C1gzvnF"];
var R2 = ["oTd1EpE24"];
var x2 = ["hwa2ZlYjU"];
var T2 = ["rk3Q6WzbW"];
var A2 = ["RQHJv9fZW"];
var P2 = ["NXnq1Sp6P"];
var I2 = ["zCKFz0aMd"];
var L2 = ["RJeXa6amv"];
var b2 = ["TQ06FQZj0"];
var U2 = ["ZOi_NWo7j"];
var v2 = ["a6ujXfENo"];
var Q2 = ["sRFHXx5Ye"];
var V2 = ["Wkif7C6rK"];
var E2 = ["YcY2udl5Q"];
var k2 = ["r4IQRQwrW"];
var D2 = ["c_Ztb3H9y"];
var F2 = ["IcL3UIni1"];
var C2 = ["snQxG7xuO"];
var H2 = ["po6DD0Ss5"];
var j2 = ["LpCldKl4r"];
var W2 = ["V_GcUixzS"];
var z2 = ["PafrptGQk"];
var M2 = ["XTDYAmTwl"];
var K2 = ["gEHVSojsb"];
var G2 = ["kLA2iEZd7"];
var Z2 = ["GphWkGDid"];
var X2 = ["ajZz7riKD"];
var Y2 = ["QljAkgFAS"];
var B2 = ["FuDmHCZ5S"];
var O2 = ["PbM630afL"];
var _2 = ["M7YTgre20"];
var J2 = ["lwtk4AApP"];
var $2 = ["rcds5P2rE"];
var q2 = [];
var ee = (e10) => {
  let l7 = q2[e10];
  if (l7)
    return l7().then((e11) => e11.default);
};
var el = {};
var et = g2(el);
var ea = new t5();
var er = { collectionByLocaleId: { default: new tR({ chunks: [""], id: "f1edcc00-4721-4c81-8b54-daed1ea47737default", indexes: [new tA({ collation: m3, collectionSchema: n3, fieldNames: i3, range: { from: 0, to: 313 }, url: "" }), new tA({ collation: m3, collectionSchema: n3, fieldNames: s3, range: { from: 313, to: 625 }, url: "" }), new tA({ collation: m3, collectionSchema: n3, fieldNames: c3, range: { from: 625, to: 933 }, url: "" }), new tA({ collation: m3, collectionSchema: n3, fieldNames: u3, range: { from: 933, to: 1625 }, url: "" }), new tA({ collation: m3, collectionSchema: n3, fieldNames: d3, range: { from: 1625, to: 2317 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: f3, range: { from: 2317, to: 10476 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: y2, range: { from: 10476, to: 10922 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: h2, range: { from: 10922, to: 11388 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: g3, range: { from: 11388, to: 11715 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: N2, range: { from: 11715, to: 11963 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: w2, range: { from: 11963, to: 12283 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: S2, range: { from: 12283, to: 12603 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: R2, range: { from: 12603, to: 21688 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: x2, range: { from: 21688, to: 22008 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: T2, range: { from: 22008, to: 22328 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: A2, range: { from: 22328, to: 22648 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: P2, range: { from: 22648, to: 22878 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: I2, range: { from: 22878, to: 23307 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: L2, range: { from: 23307, to: 23882 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: b2, range: { from: 23882, to: 24928 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: U2, range: { from: 24928, to: 26600 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: v2, range: { from: 26600, to: 27059 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: Q2, range: { from: 27059, to: 27298 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: V2, range: { from: 27298, to: 28604 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: E2, range: { from: 28604, to: 28948 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: k2, range: { from: 28948, to: 29292 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: D2, range: { from: 29292, to: 29586 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: F2, range: { from: 29586, to: 29966 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: C2, range: { from: 29966, to: 30286 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: H2, range: { from: 30286, to: 31007 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: j2, range: { from: 31007, to: 39364 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: W2, range: { from: 39364, to: 47489 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: z2, range: { from: 47489, to: 55511 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: M2, range: { from: 55511, to: 63631 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: K2, range: { from: 63631, to: 71988 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: G2, range: { from: 71988, to: 79299 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: Z2, range: { from: 79299, to: 84336 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: X2, range: { from: 84336, to: 84500 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: Y2, range: { from: 84500, to: 84664 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: B2, range: { from: 84664, to: 84828 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: O2, range: { from: 84828, to: 84992 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: _2, range: { from: 84992, to: 85156 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: J2, range: { from: 85156, to: 85320 }, url: "" }), new tA({ collation: p3, collectionSchema: n3, fieldNames: $2, range: { from: 85320, to: 85838 }, url: "" })], resolveRichText: et, resolveVectorSetItem: ee, schema: n3 }) }, displayName: "Featured Properties", id: "f1edcc00-4721-4c81-8b54-daed1ea47737" };
var hyPTlnA4N_default = er;
e4(er, { dQx3F9Jie: { title: "Cover Image", type: l3.ResponsiveImage }, ged3yBesp: { defaultValue: "", title: "Location Line 1", type: l3.String }, QGpl2b70E: { defaultValue: "", title: "Location Line 2", type: l3.String }, VD6Y5bYH7: { defaultValue: "", title: "Price", type: l3.String }, H6xmtp_Vj: { defaultValue: "USD", placeholder: "USD", title: "Currency", type: l3.String }, zvsKfuoA9: { defaultValue: "srMvxWMQ2", options: ["srMvxWMQ2", "yOtUflAyW", "yR5bXkyt1", "czau9ac6B", "kbXym98rd"], optionTitles: ["Under $500K", "$500K \u2013 $1M", "$1M \u2013 $3M", "$3M \u2013 $5M", "$5M+"], title: "Price Range (For filters)", type: l3.Enum }, y5C1gzvnF: { defaultValue: "OIGoay1tV", options: ["OIGoay1tV", "fHgv_CR9k"], optionTitles: ["For Sale", "Sold"], title: "Property Status", type: l3.Enum }, oTd1EpE24: { defaultValue: "", title: "Description", type: l3.RichText }, hwa2ZlYjU: { dataIdentifier: "local-module:collection/TXqlbf1RQ:default", title: "Neighborhood", type: l3.CollectionReference }, rk3Q6WzbW: { dataIdentifier: "local-module:collection/rPatPAJHR:default", title: "Agent", type: l3.CollectionReference }, RQHJv9fZW: { defaultValue: "RSunMUq_r", options: ["RSunMUq_r", "Lu5Lsk3gE", "eti8BSVE2", "lG6v7ocST", "u6TwU0dPD", "IUem7Bcpj", "jVk4nhFzU", "BOqG6LkKj", "ayrXkVQUZ", "j0mQCn1QX"], optionTitles: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"], title: "Bedrooms", type: l3.Enum }, NXnq1Sp6P: { defaultValue: "", title: "Bathrooms", type: l3.String }, zCKFz0aMd: { defaultValue: "", placeholder: "Yes (in-unit)", title: "Laundry Room", type: l3.String }, RJeXa6amv: { defaultValue: "", placeholder: "Restored White Oak Hardwood", title: "Flooring", type: l3.String }, TQ06FQZj0: { defaultValue: "", placeholder: "Chef's Kitchen with marble countertops and custom cabinetry", title: "Kitchen", type: l3.String }, ZOi_NWo7j: { defaultValue: "", placeholder: "Built-in Features, High Ceilings, Formal Dining Room, Prewar Details, Crown Molding, Wood-Burning Fireplace, Central Air, Wine Storage", title: "Other", type: l3.String }, a6ujXfENo: { defaultValue: "", title: "Garage", type: l3.String }, sRFHXx5Ye: { defaultValue: "", title: "Pool", type: l3.String }, Wkif7C6rK: { defaultValue: "", placeholder: "Full-floor residence, white-glove building with doorman and concierge", title: "Lot Features", type: l3.String }, YcY2udl5Q: { defaultValue: "", title: "Living Area", type: l3.String }, r4IQRQwrW: { defaultValue: "", title: "Total Area", type: l3.String }, c_Ztb3H9y: { defaultValue: "", title: "Year Built", type: l3.String }, IcL3UIni1: { defaultValue: "", title: "MLS ID", type: l3.String }, snQxG7xuO: { defaultValue: "sWJIKemVT", options: ["sWJIKemVT", "Twhe336rp", "EIAAFxrj6", "VbRKFkHla", "qPPwHw2XH"], optionTitles: ["Apartment", "House", "Condo", "Townhouse", "Penthouse"], title: "Type", type: l3.Enum }, po6DD0Ss5: { title: "Virtual Tour Link", type: l3.Link }, LpCldKl4r: { title: "Image Carousel 1", type: l3.ResponsiveImage }, V_GcUixzS: { title: "Image Carousel 2", type: l3.ResponsiveImage }, PafrptGQk: { title: "Image Carousel 3", type: l3.ResponsiveImage }, XTDYAmTwl: { title: "Extra Image 1", type: l3.ResponsiveImage }, gEHVSojsb: { title: "Extra Image 2", type: l3.ResponsiveImage }, kLA2iEZd7: { title: "Extra Image 3", type: l3.ResponsiveImage }, GphWkGDid: { title: "Extra Image 4", type: l3.ResponsiveImage }, ajZz7riKD: { title: "Extra Image 5", type: l3.ResponsiveImage }, QljAkgFAS: { title: "Extra Image 6", type: l3.ResponsiveImage }, FuDmHCZ5S: { title: "Extra Image 7", type: l3.ResponsiveImage }, PbM630afL: { title: "Extra Image 8", type: l3.ResponsiveImage }, M7YTgre20: { title: "Extra Image 9", type: l3.ResponsiveImage }, lwtk4AApP: { title: "Extra Image 10", type: l3.ResponsiveImage }, rcds5P2rE: { preventLocalization: true, title: "Slug (Link)", type: l3.String }, createdAt: { title: "Created", type: l3.Date }, updatedAt: { title: "Updated", type: l3.Date }, previousItemId: { dataIdentifier: "local-module:collection/hyPTlnA4N:default", title: "Previous", type: l3.CollectionReference }, nextItemId: { dataIdentifier: "local-module:collection/hyPTlnA4N:default", title: "Next", type: l3.CollectionReference } });
var zvsKfuoA9ToDisplayName = (e10, l7) => {
  switch (l7?.fallback, e10) {
    case "srMvxWMQ2":
      return "Under $500K";
    case "yOtUflAyW":
      return "$500K \u2013 $1M";
    case "yR5bXkyt1":
      return "$1M \u2013 $3M";
    case "czau9ac6B":
      return "$3M \u2013 $5M";
    case "kbXym98rd":
      return "$5M+";
    default:
      return "";
  }
};
var y5C1gzvnFToDisplayName = (e10, l7) => {
  switch (l7?.fallback, e10) {
    case "OIGoay1tV":
      return "For Sale";
    case "fHgv_CR9k":
      return "Sold";
    default:
      return "";
  }
};
var RQHJv9fZWToDisplayName = (e10, l7) => {
  switch (l7?.fallback, e10) {
    case "RSunMUq_r":
      return "1";
    case "Lu5Lsk3gE":
      return "2";
    case "eti8BSVE2":
      return "3";
    case "lG6v7ocST":
      return "4";
    case "u6TwU0dPD":
      return "5";
    case "IUem7Bcpj":
      return "6";
    case "jVk4nhFzU":
      return "7";
    case "BOqG6LkKj":
      return "8";
    case "ayrXkVQUZ":
      return "9";
    case "j0mQCn1QX":
      return "10";
    default:
      return "";
  }
};
var snQxG7xuOToDisplayName = (e10, l7) => {
  switch (l7?.fallback, e10) {
    case "sWJIKemVT":
      return "Apartment";
    case "Twhe336rp":
      return "House";
    case "EIAAFxrj6":
      return "Condo";
    case "VbRKFkHla":
      return "Townhouse";
    case "qPPwHw2XH":
      return "Penthouse";
    default:
      return "";
  }
};
var enumToDisplayNameFunctions = { RQHJv9fZW: RQHJv9fZWToDisplayName, snQxG7xuO: snQxG7xuOToDisplayName, y5C1gzvnF: y5C1gzvnFToDisplayName, zvsKfuoA9: zvsKfuoA9ToDisplayName };

// http-url:https://framerusercontent.com/modules/FBWpyT5wgPlMNO696wlP/UOzRipv4frmWk6jlCP3a/TXqlbf1RQ.js
import { addPropertyControls as e9, ControlType as l6, QueryEngine as t9 } from "./_framer-runtime.js";

// http-url:https://framerusercontent.com/modules/FBWpyT5wgPlMNO696wlP/UOzRipv4frmWk6jlCP3a/TXqlbf1RQ-0.js
import { ControlType as v3 } from "./_framer-runtime.js";
import { ControlType as P3 } from "./_framer-runtime.js";
var t6;
var e5 = Object.create;
var r3 = Object.defineProperty;
var n4 = Object.getOwnPropertyDescriptor;
var i4 = Object.getOwnPropertyNames;
var s4 = Object.getPrototypeOf;
var a3 = Object.prototype.hasOwnProperty;
var o3 = (t10, e10, n7) => e10 in t10 ? r3(t10, e10, { enumerable: true, configurable: true, writable: true, value: n7 }) : t10[e10] = n7;
var u4 = (t10, e10) => function() {
  try {
    return e10 || (0, t10[i4(t10)[0]])((e10 = { exports: {} }).exports, e10), e10.exports;
  } catch (t11) {
    throw e10 = 0, t11;
  }
};
var l4 = (t10, e10, s7, o6) => {
  if (e10 && "object" == typeof e10 || "function" == typeof e10)
    for (let u7 of i4(e10))
      a3.call(t10, u7) || u7 === s7 || r3(t10, u7, { get: () => e10[u7], enumerable: !(o6 = n4(e10, u7)) || o6.enumerable });
  return t10;
};
var h3 = (t10, n7, i6) => (i6 = null != t10 ? e5(s4(t10)) : {}, l4(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  !n7 && t10 && t10.__esModule ? i6 : r3(i6, "default", { value: t10, enumerable: true }),
  t10
));
var c4 = (t10, e10, r5) => o3(t10, "symbol" != typeof e10 ? e10 + "" : e10, r5);
var f4 = u4({ "../../../node_modules/dataloader/index.js"(t10, e10) {
  var r5, n7 = /* @__PURE__ */ function() {
    function t11(t12, e12) {
      if ("function" != typeof t12)
        throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but got: " + t12 + ".");
      this._batchLoadFn = t12, this._maxBatchSize = function(t13) {
        if (!(!t13 || false !== t13.batch))
          return 1;
        var e13 = t13 && t13.maxBatchSize;
        if (void 0 === e13)
          return 1 / 0;
        if ("number" != typeof e13 || e13 < 1)
          throw TypeError("maxBatchSize must be a positive number: " + e13);
        return e13;
      }(e12), this._batchScheduleFn = function(t13) {
        var e13 = t13 && t13.batchScheduleFn;
        if (void 0 === e13)
          return i6;
        if ("function" != typeof e13)
          throw TypeError("batchScheduleFn must be a function: " + e13);
        return e13;
      }(e12), this._cacheKeyFn = function(t13) {
        var e13 = t13 && t13.cacheKeyFn;
        if (void 0 === e13)
          return function(t14) {
            return t14;
          };
        if ("function" != typeof e13)
          throw TypeError("cacheKeyFn must be a function: " + e13);
        return e13;
      }(e12), this._cacheMap = function(t13) {
        if (!(!t13 || false !== t13.cache))
          return null;
        var e13 = t13 && t13.cacheMap;
        if (void 0 === e13)
          return /* @__PURE__ */ new Map();
        if (null !== e13) {
          var r6 = ["get", "set", "delete", "clear"].filter(function(t14) {
            return e13 && "function" != typeof e13[t14];
          });
          if (0 !== r6.length)
            throw TypeError("Custom cacheMap missing methods: " + r6.join(", "));
        }
        return e13;
      }(e12), this._batch = null, this.name = e12 && e12.name ? e12.name : null;
    }
    var e11 = t11.prototype;
    return e11.load = function(t12) {
      if (null == t12)
        throw TypeError("The loader.load() function must be called with a value, but got: " + String(t12) + ".");
      var e12 = function(t13) {
        var e13 = t13._batch;
        if (null !== e13 && !e13.hasDispatched && e13.keys.length < t13._maxBatchSize)
          return e13;
        var r7 = { hasDispatched: false, keys: [], callbacks: [] };
        return t13._batch = r7, t13._batchScheduleFn(function() {
          (function(t14, e14) {
            var r8;
            if (e14.hasDispatched = true, 0 === e14.keys.length) {
              a5(e14);
              return;
            }
            try {
              r8 = t14._batchLoadFn(e14.keys);
            } catch (r9) {
              return s7(t14, e14, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function errored synchronously: " + String(r9) + "."));
            }
            if (!r8 || "function" != typeof r8.then)
              return s7(t14, e14, TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise: " + String(r8) + "."));
            r8.then(function(t15) {
              if (!o6(t15))
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array: " + String(t15) + ".");
              if (t15.length !== e14.keys.length)
                throw TypeError("DataLoader must be constructed with a function which accepts Array<key> and returns Promise<Array<value>>, but the function did not return a Promise of an Array of the same length as the Array of keys.\n\nKeys:\n" + String(e14.keys) + "\n\nValues:\n" + String(t15));
              a5(e14);
              for (var r9 = 0; r9 < e14.callbacks.length; r9++) {
                var n9 = t15[r9];
                n9 instanceof Error ? e14.callbacks[r9].reject(n9) : e14.callbacks[r9].resolve(n9);
              }
            }).catch(function(r9) {
              s7(t14, e14, r9);
            });
          })(t13, r7);
        }), r7;
      }(this), r6 = this._cacheMap, n8 = this._cacheKeyFn(t12);
      if (r6) {
        var i7 = r6.get(n8);
        if (i7) {
          var u7 = e12.cacheHits || (e12.cacheHits = []);
          return new Promise(function(t13) {
            u7.push(function() {
              t13(i7);
            });
          });
        }
      }
      e12.keys.push(t12);
      var l7 = new Promise(function(t13, r7) {
        e12.callbacks.push({ resolve: t13, reject: r7 });
      });
      return r6 && r6.set(n8, l7), l7;
    }, e11.loadMany = function(t12) {
      if (!o6(t12))
        throw TypeError("The loader.loadMany() function must be called with Array<key> but got: " + t12 + ".");
      for (var e12 = [], r6 = 0; r6 < t12.length; r6++)
        e12.push(this.load(t12[r6]).catch(function(t13) {
          return t13;
        }));
      return Promise.all(e12);
    }, e11.clear = function(t12) {
      var e12 = this._cacheMap;
      if (e12) {
        var r6 = this._cacheKeyFn(t12);
        e12.delete(r6);
      }
      return this;
    }, e11.clearAll = function() {
      var t12 = this._cacheMap;
      return t12 && t12.clear(), this;
    }, e11.prime = function(t12, e12) {
      var r6 = this._cacheMap;
      if (r6) {
        var n8, i7 = this._cacheKeyFn(t12);
        void 0 === r6.get(i7) && (e12 instanceof Error ? (n8 = Promise.reject(e12)).catch(function() {
        }) : n8 = Promise.resolve(e12), r6.set(i7, n8));
      }
      return this;
    }, t11;
  }(), i6 = "object" == typeof process && "function" == typeof process.nextTick ? function(t11) {
    r5 || (r5 = Promise.resolve()), r5.then(function() {
      process.nextTick(t11);
    });
  } : "function" == typeof setImmediate ? function(t11) {
    setImmediate(t11);
  } : function(t11) {
    setTimeout(t11);
  };
  function s7(t11, e11, r6) {
    a5(e11);
    for (var n8 = 0; n8 < e11.keys.length; n8++)
      t11.clear(e11.keys[n8]), e11.callbacks[n8].reject(r6);
  }
  function a5(t11) {
    if (t11.cacheHits)
      for (var e11 = 0; e11 < t11.cacheHits.length; e11++)
        t11.cacheHits[e11]();
  }
  function o6(t11) {
    return "object" == typeof t11 && null !== t11 && "number" == typeof t11.length && (0 === t11.length || t11.length > 0 && Object.prototype.hasOwnProperty.call(t11, t11.length - 1));
  }
  e10.exports = n7;
} });
var d4 = h3(f4(), 1);
var g4 = { Uint8: 1, Uint16: 2, Uint32: 4, BigUint64: 8, Int8: 1, Int16: 2, Int32: 4, BigInt64: 8, Float32: 4, Float64: 8 };
var y3 = class {
  getOffset() {
    return this.offset;
  }
  ensureLength(t10) {
    let e10 = this.bytes.length;
    if (!(this.offset + t10 <= e10))
      throw Error("Reading out of bounds");
  }
  readUint8() {
    let t10 = g4.Uint8;
    this.ensureLength(t10);
    let e10 = this.view.getUint8(this.offset);
    return this.offset += t10, e10;
  }
  readUint16() {
    let t10 = g4.Uint16;
    this.ensureLength(t10);
    let e10 = this.view.getUint16(this.offset);
    return this.offset += t10, e10;
  }
  readUint32() {
    let t10 = g4.Uint32;
    this.ensureLength(t10);
    let e10 = this.view.getUint32(this.offset);
    return this.offset += t10, e10;
  }
  readUint64() {
    let t10 = this.readBigUint64();
    return Number(t10);
  }
  readBigUint64() {
    let t10 = g4.BigUint64;
    this.ensureLength(t10);
    let e10 = this.view.getBigUint64(this.offset);
    return this.offset += t10, e10;
  }
  readInt8() {
    let t10 = g4.Int8;
    this.ensureLength(t10);
    let e10 = this.view.getInt8(this.offset);
    return this.offset += t10, e10;
  }
  readInt16() {
    let t10 = g4.Int16;
    this.ensureLength(t10);
    let e10 = this.view.getInt16(this.offset);
    return this.offset += t10, e10;
  }
  readInt32() {
    let t10 = g4.Int32;
    this.ensureLength(t10);
    let e10 = this.view.getInt32(this.offset);
    return this.offset += t10, e10;
  }
  readInt64() {
    let t10 = this.readBigInt64();
    return Number(t10);
  }
  readBigInt64() {
    let t10 = g4.BigInt64;
    this.ensureLength(t10);
    let e10 = this.view.getBigInt64(this.offset);
    return this.offset += t10, e10;
  }
  readFloat32() {
    let t10 = g4.Float32;
    this.ensureLength(t10);
    let e10 = this.view.getFloat32(this.offset);
    return this.offset += t10, e10;
  }
  readFloat64() {
    let t10 = g4.Float64;
    this.ensureLength(t10);
    let e10 = this.view.getFloat64(this.offset);
    return this.offset += t10, e10;
  }
  readBytes(t10) {
    let e10 = this.offset, r5 = e10 + t10, n7 = this.bytes.subarray(e10, r5);
    return this.offset = r5, n7;
  }
  readString() {
    let t10 = this.readUint32(), e10 = this.readBytes(t10);
    return this.decoder.decode(e10);
  }
  readJson() {
    let t10 = this.readString();
    return JSON.parse(t10);
  }
  constructor(t10) {
    c4(this, "bytes", t10), c4(this, "offset", 0), c4(this, "view"), c4(this, "decoder", new TextDecoder()), this.view = p4(this.bytes);
  }
};
function p4(t10) {
  return new DataView(t10.buffer, t10.byteOffset, t10.byteLength);
}
var m4 = "undefined" != typeof __dai_window;
var w3 = m4 && "function" == typeof __dai_window.requestIdleCallback;
function I3(t10, ...e10) {
  if (!t10)
    throw Error("Assertion Error" + (e10.length > 0 ? ": " + e10.join(" ") : ""));
}
function b3(t10) {
  throw Error(`Unexpected value: ${t10}`);
}
var U3 = 1024;
var S3 = 1.5;
var k3 = (t10) => 2 ** t10 - 1;
var L3 = (t10) => -(2 ** (t10 - 1));
var B3 = (t10) => 2 ** (t10 - 1) - 1;
var E3 = { Uint8: 0, Uint16: 0, Uint32: 0, Uint64: 0, BigUint64: 0, Int8: L3(8), Int16: L3(16), Int32: L3(32), Int64: Number.MIN_SAFE_INTEGER, BigInt64: -(BigInt(2) ** BigInt(63)) };
var M3 = { Uint8: k3(8), Uint16: k3(16), Uint32: k3(32), Uint64: Number.MAX_SAFE_INTEGER, BigUint64: BigInt(2) ** BigInt(64) - BigInt(1), Int8: B3(8), Int16: B3(16), Int32: B3(32), Int64: Number.MAX_SAFE_INTEGER, BigInt64: BigInt(2) ** BigInt(63) - BigInt(1) };
function T3(t10, e10, r5, n7) {
  I3(t10 >= e10, t10, "outside lower bound for", n7), I3(t10 <= r5, t10, "outside upper bound for", n7);
}
var F3 = class {
  getOffset() {
    return this.offset;
  }
  slice(t10 = 0, e10 = this.offset) {
    return this.bytes.slice(t10, e10);
  }
  subarray(t10 = 0, e10 = this.offset) {
    return this.bytes.subarray(t10, e10);
  }
  ensureLength(t10) {
    let e10 = this.bytes.length;
    if (this.offset + t10 <= e10)
      return;
    let r5 = new Uint8Array(Math.ceil(e10 * S3) + t10);
    r5.set(this.bytes), this.bytes = r5, this.view = p4(r5);
  }
  writeUint8(t10) {
    T3(t10, E3.Uint8, M3.Uint8, "Uint8");
    let e10 = g4.Uint8;
    this.ensureLength(e10), this.view.setUint8(this.offset, t10), this.offset += e10;
  }
  writeUint16(t10) {
    T3(t10, E3.Uint16, M3.Uint16, "Uint16");
    let e10 = g4.Uint16;
    this.ensureLength(e10), this.view.setUint16(this.offset, t10), this.offset += e10;
  }
  writeUint32(t10) {
    T3(t10, E3.Uint32, M3.Uint32, "Uint32");
    let e10 = g4.Uint32;
    this.ensureLength(e10), this.view.setUint32(this.offset, t10), this.offset += e10;
  }
  writeUint64(t10) {
    T3(t10, E3.Uint64, M3.Uint64, "Uint64");
    let e10 = BigInt(t10);
    this.writeBigUint64(e10);
  }
  writeBigUint64(t10) {
    T3(t10, E3.BigUint64, M3.BigUint64, "BigUint64");
    let e10 = g4.BigUint64;
    this.ensureLength(e10), this.view.setBigUint64(this.offset, t10), this.offset += e10;
  }
  writeInt8(t10) {
    T3(t10, E3.Int8, M3.Int8, "Int8");
    let e10 = g4.Int8;
    this.ensureLength(e10), this.view.setInt8(this.offset, t10), this.offset += e10;
  }
  writeInt16(t10) {
    T3(t10, E3.Int16, M3.Int16, "Int16");
    let e10 = g4.Int16;
    this.ensureLength(e10), this.view.setInt16(this.offset, t10), this.offset += e10;
  }
  writeInt32(t10) {
    T3(t10, E3.Int32, M3.Int32, "Int32");
    let e10 = g4.Int32;
    this.ensureLength(e10), this.view.setInt32(this.offset, t10), this.offset += e10;
  }
  writeInt64(t10) {
    T3(t10, E3.Int64, M3.Int64, "Int64");
    let e10 = BigInt(t10);
    this.writeBigInt64(e10);
  }
  writeBigInt64(t10) {
    T3(t10, E3.BigInt64, M3.BigInt64, "BigInt64");
    let e10 = g4.BigInt64;
    this.ensureLength(e10), this.view.setBigInt64(this.offset, t10), this.offset += e10;
  }
  writeFloat32(t10) {
    let e10 = g4.Float32;
    this.ensureLength(e10), this.view.setFloat32(this.offset, t10), this.offset += e10;
  }
  writeFloat64(t10) {
    let e10 = g4.Float64;
    this.ensureLength(e10), this.view.setFloat64(this.offset, t10), this.offset += e10;
  }
  writeBytes(t10) {
    let e10 = t10.length;
    this.ensureLength(e10), this.bytes.set(t10, this.offset), this.offset += e10;
  }
  encodeString(t10) {
    let e10 = this.encodedStrings.get(t10);
    if (e10)
      return e10;
    let r5 = this.encoder.encode(t10);
    return this.encodedStrings.set(t10, r5), r5;
  }
  writeString(t10) {
    let e10 = this.encodeString(t10), r5 = e10.length;
    this.writeUint32(r5), this.writeBytes(e10);
  }
  writeJson(t10) {
    let e10 = JSON.stringify(t10);
    this.writeString(e10);
  }
  constructor() {
    c4(this, "offset", 0), c4(this, "bytes", new Uint8Array(U3)), c4(this, "view", p4(this.bytes)), c4(this, "encoder", new TextEncoder()), c4(this, "encodedStrings", /* @__PURE__ */ new Map());
  }
};
function x3(t10) {
  return "string" == typeof t10;
}
function N3(t10) {
  return Number.isFinite(t10);
}
function A3(t10) {
  return null === t10;
}
var O3 = class t7 {
  static fromString(e10) {
    let [r5, n7, i6] = e10.split("/").map(Number);
    return I3(N3(r5), "Invalid chunkId"), I3(N3(n7), "Invalid offset"), I3(N3(i6), "Invalid length"), new t7(r5, n7, i6);
  }
  toString() {
    return `${this.chunkId}/${this.offset}/${this.length}`;
  }
  static read(e10) {
    let r5 = e10.readUint16(), n7 = e10.readUint32(), i6 = e10.readUint32();
    return new t7(r5, n7, i6);
  }
  write(t10) {
    t10.writeUint16(this.chunkId), t10.writeUint32(this.offset), t10.writeUint32(this.length);
  }
  compare(t10) {
    return this.chunkId < t10.chunkId ? -1 : this.chunkId > t10.chunkId ? 1 : this.offset < t10.offset ? -1 : this.offset > t10.offset ? 1 : (I3(this.length === t10.length), 0);
  }
  constructor(t10, e10, r5) {
    c4(this, "chunkId", t10), c4(this, "offset", e10), c4(this, "length", r5);
  }
};
function R3(t10) {
  if (A3(t10))
    return 0;
  switch (t10.type) {
    case P3.Array:
      return 1;
    case P3.Boolean:
      return 2;
    case P3.Color:
      return 3;
    case P3.Date:
      return 4;
    case P3.Enum:
      return 5;
    case P3.File:
      return 6;
    case P3.ResponsiveImage:
      return 10;
    case P3.Link:
      return 7;
    case P3.Number:
      return 8;
    case P3.Object:
      return 9;
    case P3.RichText:
      return 11;
    case P3.String:
      return 12;
    case P3.VectorSetItem:
      return 13;
    default:
      b3(t10);
  }
}
function q3(e10) {
  let r5 = e10.readUint16(), n7 = [];
  for (let i6 = 0; i6 < r5; i6++) {
    let r6 = t6.read(e10);
    n7.push(r6);
  }
  return { type: P3.Array, value: n7 };
}
function _3(e10, r5) {
  for (let n7 of (e10.writeUint16(r5.value.length), r5.value))
    t6.write(e10, n7);
}
function D3(e10, r5, n7) {
  let i6 = e10.value.length, s7 = r5.value.length;
  if (i6 < s7)
    return -1;
  if (i6 > s7)
    return 1;
  for (let s8 = 0; s8 < i6; s8++) {
    let i7 = e10.value[s8], a5 = r5.value[s8], o6 = t6.compare(i7, a5, n7);
    if (0 !== o6)
      return o6;
  }
  return 0;
}
function j3(t10) {
  return { type: P3.Boolean, value: 0 !== t10.readUint8() };
}
function C3(t10, e10) {
  t10.writeUint8(e10.value ? 1 : 0);
}
function J3(t10, e10) {
  return t10.value < e10.value ? -1 : t10.value > e10.value ? 1 : 0;
}
function V3(t10) {
  return { type: P3.Color, value: t10.readString() };
}
function W3(t10, e10) {
  t10.writeString(e10.value);
}
function $3(t10, e10) {
  return t10.value < e10.value ? -1 : t10.value > e10.value ? 1 : 0;
}
function z3(t10) {
  let e10 = t10.readInt64(), r5 = new Date(e10);
  return { type: P3.Date, value: r5.toISOString() };
}
function G3(t10, e10) {
  let r5 = new Date(e10.value), n7 = r5.getTime();
  t10.writeInt64(n7);
}
function K3(t10, e10) {
  let r5 = new Date(t10.value), n7 = new Date(e10.value);
  return r5 < n7 ? -1 : r5 > n7 ? 1 : 0;
}
function H3(t10) {
  return { type: P3.Enum, value: t10.readString() };
}
function X3(t10, e10) {
  t10.writeString(e10.value);
}
function Q3(t10, e10) {
  return t10.value < e10.value ? -1 : t10.value > e10.value ? 1 : 0;
}
function Y3(t10) {
  return { type: P3.File, value: t10.readString() };
}
function Z3(t10, e10) {
  t10.writeString(e10.value);
}
function tt2(t10, e10) {
  return t10.value < e10.value ? -1 : t10.value > e10.value ? 1 : 0;
}
function te2(t10) {
  return { type: P3.Link, value: t10.readJson() };
}
function tr2(t10, e10) {
  t10.writeJson(e10.value);
}
function tn2(t10, e10) {
  let r5 = JSON.stringify(t10.value), n7 = JSON.stringify(e10.value);
  return r5 < n7 ? -1 : r5 > n7 ? 1 : 0;
}
function ti2(t10) {
  return { type: P3.Number, value: t10.readFloat64() };
}
function ts2(t10, e10) {
  t10.writeFloat64(e10.value);
}
function ta2(t10, e10) {
  return t10.value < e10.value ? -1 : t10.value > e10.value ? 1 : 0;
}
function to2(e10) {
  let r5 = e10.readUint16(), n7 = {};
  for (let i6 = 0; i6 < r5; i6++) {
    let r6 = e10.readString();
    n7[r6] = t6.read(e10);
  }
  return { type: P3.Object, value: n7 };
}
function tu2(e10, r5) {
  let n7 = Object.entries(r5.value);
  for (let [r6, i6] of (e10.writeUint16(n7.length), n7))
    e10.writeString(r6), t6.write(e10, i6);
}
function tl2(e10, r5, n7) {
  let i6 = Object.keys(e10.value).sort(), s7 = Object.keys(r5.value).sort();
  if (i6.length < s7.length)
    return -1;
  if (i6.length > s7.length)
    return 1;
  for (let a5 = 0; a5 < i6.length; a5++) {
    let o6 = i6[a5], u7 = s7[a5];
    if (o6 < u7)
      return -1;
    if (o6 > u7)
      return 1;
    let l7 = e10.value[o6] ?? null, h5 = r5.value[u7] ?? null, c7 = t6.compare(l7, h5, n7);
    if (0 !== c7)
      return c7;
  }
  return 0;
}
function th2(t10) {
  return { type: P3.ResponsiveImage, value: t10.readJson() };
}
function tc2(t10, e10) {
  t10.writeJson(e10.value);
}
function tf2(t10, e10) {
  let r5 = JSON.stringify(t10.value), n7 = JSON.stringify(e10.value);
  return r5 < n7 ? -1 : r5 > n7 ? 1 : 0;
}
function td2(t10) {
  let e10 = t10.readInt8();
  if (0 === e10)
    return { type: P3.RichText, value: t10.readUint32() };
  if (1 === e10)
    return { type: P3.RichText, value: t10.readString() };
  throw Error("Invalid rich text pointer");
}
function tg2(t10, e10) {
  if (N3(e10.value)) {
    t10.writeInt8(0), t10.writeUint32(e10.value);
    return;
  }
  if (x3(e10.value)) {
    t10.writeInt8(1), t10.writeString(e10.value);
    return;
  }
  throw Error("Invalid rich text pointer");
}
function ty2(t10, e10) {
  let r5 = t10.value, n7 = e10.value;
  if (N3(r5) && N3(n7) || x3(r5) && x3(n7))
    return r5 < n7 ? -1 : r5 > n7 ? 1 : 0;
  throw Error("Invalid rich text pointer");
}
function tp2(t10) {
  return { type: P3.String, value: t10.readString() };
}
function tv2(t10, e10) {
  t10.writeString(e10.value);
}
function tm2(t10, e10, r5) {
  let n7 = t10.value, i6 = e10.value;
  return (0 === r5.type && (n7 = t10.value.toLowerCase(), i6 = e10.value.toLowerCase()), n7 < i6) ? -1 : n7 > i6 ? 1 : 0;
}
function tw2(t10) {
  return { type: P3.VectorSetItem, value: t10.readUint32() };
}
function tI2(t10, e10) {
  t10.writeUint32(e10.value);
}
function tb2(t10, e10) {
  let r5 = t10.value, n7 = e10.value;
  return r5 < n7 ? -1 : r5 > n7 ? 1 : 0;
}
((t10) => {
  t10.read = function(t11) {
    let e10 = t11.readUint8();
    switch (e10) {
      case 0:
        return null;
      case 1:
        return q3(t11);
      case 2:
        return j3(t11);
      case 3:
        return V3(t11);
      case 4:
        return z3(t11);
      case 5:
        return H3(t11);
      case 6:
        return Y3(t11);
      case 7:
        return te2(t11);
      case 8:
        return ti2(t11);
      case 9:
        return to2(t11);
      case 10:
        return th2(t11);
      case 11:
        return td2(t11);
      case 12:
        return tp2(t11);
      case 13:
        return tw2(t11);
      default:
        b3(e10);
    }
  }, t10.write = function(t11, e10) {
    let r5 = R3(e10);
    if (t11.writeUint8(r5), !A3(e10))
      switch (e10.type) {
        case P3.Array:
          return _3(t11, e10);
        case P3.Boolean:
          return C3(t11, e10);
        case P3.Color:
          return W3(t11, e10);
        case P3.Date:
          return G3(t11, e10);
        case P3.Enum:
          return X3(t11, e10);
        case P3.File:
          return Z3(t11, e10);
        case P3.Link:
          return tr2(t11, e10);
        case P3.Number:
          return ts2(t11, e10);
        case P3.Object:
          return tu2(t11, e10);
        case P3.ResponsiveImage:
          return tc2(t11, e10);
        case P3.RichText:
          return tg2(t11, e10);
        case P3.VectorSetItem:
          return tI2(t11, e10);
        case P3.String:
          return tv2(t11, e10);
        default:
          b3(e10);
      }
  }, t10.compare = function(t11, e10, r5) {
    let n7 = R3(t11), i6 = R3(e10);
    if (n7 < i6)
      return -1;
    if (n7 > i6)
      return 1;
    if (A3(t11) || A3(e10))
      return 0;
    switch (t11.type) {
      case P3.Array:
        return I3(e10.type === P3.Array), D3(t11, e10, r5);
      case P3.Boolean:
        return I3(e10.type === P3.Boolean), J3(t11, e10);
      case P3.Color:
        return I3(e10.type === P3.Color), $3(t11, e10);
      case P3.Date:
        return I3(e10.type === P3.Date), K3(t11, e10);
      case P3.Enum:
        return I3(e10.type === P3.Enum), Q3(t11, e10);
      case P3.File:
        return I3(e10.type === P3.File), tt2(t11, e10);
      case P3.Link:
        return I3(e10.type === P3.Link), tn2(t11, e10);
      case P3.Number:
        return I3(e10.type === P3.Number), ta2(t11, e10);
      case P3.Object:
        return I3(e10.type === P3.Object), tl2(t11, e10, r5);
      case P3.ResponsiveImage:
        return I3(e10.type === P3.ResponsiveImage), tf2(t11, e10);
      case P3.RichText:
        return I3(e10.type === P3.RichText), ty2(t11, e10);
      case P3.VectorSetItem:
        return I3(e10.type === P3.VectorSetItem), tb2(t11, e10);
      case P3.String:
        return I3(e10.type === P3.String), tm2(t11, e10, r5);
      default:
        b3(t11);
    }
  };
})(t6 || (t6 = {}));
var tU2 = class e6 {
  sortEntries() {
    this.entries.sort((e10, r5) => {
      for (let n7 = 0; n7 < this.fieldNames.length; n7++) {
        let i6 = e10.values[n7], s7 = r5.values[n7], a5 = t6.compare(i6, s7, this.options.collation);
        if (0 !== a5)
          return a5;
      }
      return e10.pointer.compare(r5.pointer);
    });
  }
  static deserialize(r5) {
    let n7 = new y3(r5), i6 = n7.readJson(), s7 = n7.readUint8(), a5 = [];
    for (let t10 = 0; t10 < s7; t10++) {
      let t11 = n7.readString();
      a5.push(t11);
    }
    let o6 = new e6(a5, { collation: i6 }), u7 = n7.readUint32();
    for (let e10 = 0; e10 < u7; e10++) {
      let e11 = [];
      for (let r7 = 0; r7 < s7; r7++) {
        let r8 = t6.read(n7);
        e11.push(r8);
      }
      let r6 = O3.read(n7);
      o6.entries.push({ values: e11, pointer: r6 });
    }
    return o6;
  }
  serialize() {
    let e10 = new F3();
    for (let t10 of (e10.writeJson(this.options.collation), e10.writeUint8(this.fieldNames.length), this.fieldNames))
      e10.writeString(t10);
    for (let r5 of (this.sortEntries(), e10.writeUint32(this.entries.length), this.entries)) {
      let { values: n7, pointer: i6 } = r5;
      for (let r6 of n7)
        t6.write(e10, r6);
      i6.write(e10);
    }
    return e10.subarray();
  }
  addItem(t10, e10) {
    let r5 = this.fieldNames.map((e11) => t10.getField(e11) ?? null);
    this.entries.push({ values: r5, pointer: e10 });
  }
  constructor(t10, e10) {
    c4(this, "fieldNames", t10), c4(this, "options", e10), c4(this, "entries", []);
  }
};
var tS2 = 3;
var tk2 = 250;
var tL2 = [
  408,
  // Request Timeout
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
];
var tB2 = async (t10, e10) => {
  let r5 = 0;
  for (; ; ) {
    try {
      let n7 = await fetch(t10, e10);
      if (!tL2.includes(n7.status) || ++r5 > tS2)
        return n7;
    } catch (t11) {
      if (e10?.signal?.aborted || ++r5 > tS2)
        throw t11;
    }
    await tE2(r5);
  }
};
async function tE2(t10) {
  let e10 = Math.floor(tk2 * (Math.random() + 1) * 2 ** (t10 - 1));
  await new Promise((t11) => {
    setTimeout(t11, e10);
  });
}
async function tM2(t10, e10) {
  let r5 = tx2(e10), n7 = [], i6 = 0;
  for (let t11 of r5)
    n7.push(`${t11.from}-${t11.to - 1}`), i6 += t11.to - t11.from;
  let s7 = new URL(t10), a5 = n7.join(",");
  s7.searchParams.set("range", a5);
  let o6 = await tB2(s7);
  if (200 !== o6.status)
    throw Error(`Request failed: ${o6.status} ${o6.statusText}`);
  let u7 = await o6.arrayBuffer(), l7 = new Uint8Array(u7);
  if (l7.length !== i6)
    throw Error("Request failed: Unexpected response length");
  let h5 = new tT2(), c7 = 0;
  for (let t11 of r5) {
    let e11 = t11.to - t11.from, r6 = c7 + e11, n8 = l7.subarray(c7, r6);
    h5.write(t11.from, n8), c7 = r6;
  }
  return e10.map((t11) => h5.read(t11.from, t11.to - t11.from));
}
var tT2 = class {
  read(t10, e10) {
    for (let r5 of this.chunks) {
      if (t10 < r5.start)
        break;
      if (t10 > r5.end)
        continue;
      if (t10 + e10 > r5.end)
        break;
      let n7 = t10 - r5.start, i6 = n7 + e10;
      return r5.data.slice(n7, i6);
    }
    throw Error("Missing data");
  }
  write(t10, e10) {
    let r5 = t10, n7 = r5 + e10.length, i6 = 0, s7 = this.chunks.length;
    for (; i6 < s7; i6++) {
      let t11 = this.chunks[i6];
      if (I3(t11, "Missing chunk"), !(r5 > t11.end)) {
        if (r5 > t11.start) {
          let n8 = r5 - t11.start, i7 = t11.data.subarray(0, n8);
          e10 = tF2(i7, e10), r5 = t11.start;
        }
        break;
      }
    }
    for (; s7 > i6; s7--) {
      let t11 = this.chunks[s7 - 1];
      if (I3(t11, "Missing chunk"), !(n7 < t11.start)) {
        if (n7 < t11.end) {
          let r6 = n7 - t11.start, i7 = t11.data.subarray(r6);
          e10 = tF2(e10, i7), n7 = t11.end;
        }
        break;
      }
    }
    let a5 = { start: r5, end: n7, data: e10 }, o6 = s7 - i6;
    this.chunks.splice(i6, o6, a5);
  }
  constructor() {
    c4(this, "chunks", []);
  }
};
function tF2(t10, e10) {
  let r5 = t10.length + e10.length, n7 = new Uint8Array(r5);
  return n7.set(t10, 0), n7.set(e10, t10.length), n7;
}
function tx2(t10) {
  I3(t10.length > 0, "Must have at least one range");
  let e10 = [...t10].sort((t11, e11) => t11.from - e11.from), r5 = [];
  for (let t11 of e10) {
    let e11 = r5.length - 1, n7 = r5[e11];
    n7 && t11.from <= n7.to ? r5[e11] = { from: n7.from, to: Math.max(n7.to, t11.to) } : r5.push(t11);
  }
  return r5;
}
var tN2 = class {
  async loadModel() {
    let [t10] = await tM2(this.options.url, [this.options.range]);
    return I3(t10, "Failed to load model"), tU2.deserialize(t10);
  }
  async getModel() {
    return this.modelPromise ?? (this.modelPromise = this.loadModel()), this.model ?? (this.model = await this.modelPromise), this.model;
  }
  async lookupItems(t10) {
    I3(t10.length === this.fields.length, "Invalid query length");
    let e10 = await this.getModel(), r5 = t10.reduce((t11, e11, r6) => t11.flatMap((t12) => {
      switch (e11.type) {
        case "All":
          return [t12];
        case "Equals":
          return this.queryEquals(t12, e11, r6);
        case "NotEquals":
          return this.queryNotEquals(t12, e11, r6);
        case "LessThan":
          return this.queryLessThan(t12, e11, r6);
        case "GreaterThan":
          return this.queryGreaterThan(t12, e11, r6);
        case "Contains":
          return this.queryContains(t12, e11, r6);
        case "StartsWith":
          return this.queryStartsWith(t12, e11, r6);
        case "EndsWith":
          return this.queryEndsWith(t12, e11, r6);
        default:
          b3(e11);
      }
    }), [e10.entries]), n7 = [];
    for (let t11 of r5)
      for (let e11 of t11) {
        let t12 = {};
        for (let r6 = 0; r6 < this.options.fieldNames.length; r6++) {
          let n8 = this.options.fieldNames[r6], i6 = e11.values[r6];
          t12[n8] = i6;
        }
        n7.push({ pointer: e11.pointer.toString(), data: t12 });
      }
    return n7;
  }
  queryEquals(t10, e10, r5) {
    let n7 = this.getLeftMost(t10, r5, e10.value), i6 = this.getRightMost(t10, r5, e10.value), s7 = t10.slice(n7, i6 + 1);
    return s7.length > 0 ? [s7] : [];
  }
  queryNotEquals(t10, e10, r5) {
    let n7 = this.getLeftMost(t10, r5, e10.value), i6 = this.getRightMost(t10, r5, e10.value), s7 = [], a5 = t10.slice(0, n7);
    a5.length > 0 && s7.push(a5);
    let o6 = t10.slice(i6 + 1);
    return o6.length > 0 && s7.push(o6), s7;
  }
  queryLessThan(t10, e10, r5) {
    let n7 = this.getRightMost(t10, r5, null);
    if (t10 = t10.slice(n7 + 1), e10.inclusive) {
      let n8 = this.getRightMost(t10, r5, e10.value), i7 = t10.slice(0, n8 + 1);
      return i7.length > 0 ? [i7] : [];
    }
    let i6 = this.getLeftMost(t10, r5, e10.value), s7 = t10.slice(0, i6);
    return s7.length > 0 ? [s7] : [];
  }
  queryGreaterThan(t10, e10, r5) {
    let n7 = this.getRightMost(t10, r5, null);
    if (t10 = t10.slice(n7 + 1), e10.inclusive) {
      let n8 = this.getLeftMost(t10, r5, e10.value), i7 = t10.slice(n8);
      return i7.length > 0 ? [i7] : [];
    }
    let i6 = this.getRightMost(t10, r5, e10.value), s7 = t10.slice(i6 + 1);
    return s7.length > 0 ? [s7] : [];
  }
  queryContains(t10, e10, r5) {
    return this.findItems(t10, r5, (t11) => {
      if (t11?.type !== v3.String || e10.value?.type !== v3.String)
        return false;
      let r6 = t11.value, n7 = e10.value.value;
      return 0 === this.collation.type && (r6 = r6.toLowerCase(), n7 = n7.toLowerCase()), r6.includes(n7);
    });
  }
  queryStartsWith(t10, e10, r5) {
    return this.findItems(t10, r5, (t11) => {
      if (t11?.type !== v3.String || e10.value?.type !== v3.String)
        return false;
      let r6 = t11.value, n7 = e10.value.value;
      return 0 === this.collation.type && (r6 = r6.toLowerCase(), n7 = n7.toLowerCase()), r6.startsWith(n7);
    });
  }
  queryEndsWith(t10, e10, r5) {
    return this.findItems(t10, r5, (t11) => {
      if (t11?.type !== v3.String || e10.value?.type !== v3.String)
        return false;
      let r6 = t11.value, n7 = e10.value.value;
      return 0 === this.collation.type && (r6 = r6.toLowerCase(), n7 = n7.toLowerCase()), r6.endsWith(n7);
    });
  }
  /**
  * Returns the index of the left most entry that is equal to the target.
  *
  * ```text
  *   Left most
  *       ↓
  * ┌───┬───┬───┬───┬───┬───┐
  * │ 1 │ 2 │ 2 │ 2 │ 2 │ 3 │
  * └───┴───┴───┴───┴───┴───┘
  * ```
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param target The target value to search for.
  * @returns The index of the left most entry that is equal to the target.
  */
  getLeftMost(e10, r5, n7) {
    let i6 = 0, s7 = e10.length;
    for (; i6 < s7; ) {
      let a5 = i6 + s7 >> 1, o6 = e10[a5], u7 = o6.values[r5];
      0 > t6.compare(u7, n7, this.collation) ? i6 = a5 + 1 : s7 = a5;
    }
    return i6;
  }
  /**
  * Returns the index of the right most entry that is equal to the target.
  *
  * ```text
  *              Right most
  *                   ↓
  * ┌───┬───┬───┬───┬───┬───┐
  * │ 1 │ 2 │ 2 │ 2 │ 2 │ 3 │
  * └───┴───┴───┴───┴───┴───┘
  * ```
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param target The target value to search for.
  * @returns The index of the right most entry that is equal to the target.
  */
  getRightMost(e10, r5, n7) {
    let i6 = 0, s7 = e10.length;
    for (; i6 < s7; ) {
      let a5 = i6 + s7 >> 1, o6 = e10[a5], u7 = o6.values[r5];
      t6.compare(u7, n7, this.collation) > 0 ? s7 = a5 : i6 = a5 + 1;
    }
    return s7 - 1;
  }
  /**
  * Finds all items that are matching the predicate and groups adjacent items together.
  *
  * @param entries The entries array to search in.
  * @param position The position of the value in the entry.
  * @param predicate The predicate to match the values against.
  * @returns An array of chunks that match the predicate.
  */
  findItems(t10, e10, r5) {
    let n7 = [], i6 = 0;
    for (let s7 = 0; s7 < t10.length; s7++) {
      let a5 = t10[s7], o6 = a5.values[e10], u7 = r5(o6);
      if (!u7) {
        if (i6 < s7) {
          let e11 = t10.slice(i6, s7);
          n7.push(e11);
        }
        i6 = s7 + 1;
      }
    }
    if (i6 < t10.length) {
      let e11 = t10.slice(i6);
      n7.push(e11);
    }
    return n7;
  }
  constructor(t10) {
    c4(this, "options", t10), c4(this, "schema"), c4(this, "fields"), c4(this, "supportedLookupTypes", [
      "All",
      "Equals",
      "NotEquals",
      "LessThan",
      "GreaterThan",
      "Contains",
      "StartsWith",
      "EndsWith"
      /* EndsWith */
    ]), c4(this, "modelPromise"), c4(this, "model"), c4(this, "collation");
    let e10 = {}, r5 = [];
    for (let t11 of this.options.fieldNames) {
      let n7 = this.options.collectionSchema[t11];
      I3(n7, "Missing definition for field", t11), e10[t11] = n7, r5.push({ type: "Identifier", name: t11 });
    }
    this.schema = e10, this.fields = r5, this.collation = this.options.collation;
  }
};
var tA2 = class e7 {
  static read(r5) {
    let n7 = new e7(), i6 = r5.readUint16();
    for (let e10 = 0; e10 < i6; e10++) {
      let e11 = r5.readString(), i7 = t6.read(r5);
      n7.setField(e11, i7);
    }
    return n7;
  }
  write(e10) {
    for (let [r5, n7] of (e10.writeUint16(this.fields.size), this.fields))
      e10.writeString(r5), t6.write(e10, n7);
  }
  getData() {
    let t10 = {};
    for (let [e10, r5] of this.fields)
      t10[e10] = r5;
    return t10;
  }
  setField(t10, e10) {
    this.fields.set(t10, e10);
  }
  getField(t10) {
    return this.fields.get(t10);
  }
  constructor() {
    c4(this, "fields", /* @__PURE__ */ new Map());
  }
};
var tO2 = class {
  scanItems() {
    return this.itemsPromise ?? (this.itemsPromise = tB2(this.url).then(async (t10) => {
      if (!t10.ok)
        throw Error(`Request failed: ${t10.status} ${t10.statusText}`);
      let e10 = await t10.arrayBuffer(), r5 = new Uint8Array(e10), n7 = new y3(r5), i6 = [], s7 = n7.readUint32();
      for (let t11 = 0; t11 < s7; t11++) {
        let t12 = n7.getOffset(), e11 = tA2.read(n7), r6 = n7.getOffset() - t12, s8 = new O3(this.id, t12, r6), a5 = s8.toString(), o6 = { pointer: a5, data: e11.getData() };
        this.itemLoader.prime(a5, o6), i6.push(o6);
      }
      return i6;
    })), this.itemsPromise;
  }
  resolveItem(t10) {
    return this.itemLoader.load(t10);
  }
  constructor(t10, e10) {
    c4(this, "id", t10), c4(this, "url", e10), c4(this, "itemsPromise"), c4(this, "itemLoader", new d4.default(async (t11) => {
      let e11 = t11.map((t12) => {
        let e12 = O3.fromString(t12);
        return { from: e12.offset, to: e12.offset + e12.length };
      }), r5 = await tM2(this.url, e11);
      return r5.map((e12, r6) => {
        let n7 = new y3(e12), i6 = tA2.read(n7), s7 = t11[r6];
        return I3(s7, "Missing pointer"), { pointer: s7, data: i6.getData() };
      });
    }, { maxBatchSize: 250 }));
  }
};
var tP2 = class {
  async scanItems() {
    let t10 = await Promise.all(this.chunks.map(async (t11) => t11.scanItems()));
    return t10.flat();
  }
  resolveItems(t10) {
    return Promise.all(t10.map((t11) => {
      let e10 = O3.fromString(t11), r5 = this.chunks[e10.chunkId];
      return I3(r5, "Missing chunk"), r5.resolveItem(t11);
    }));
  }
  compareItems(t10, e10) {
    let r5 = O3.fromString(t10.pointer), n7 = O3.fromString(e10.pointer);
    return r5.compare(n7);
  }
  compareValues(e10, r5, n7) {
    return t6.compare(e10, r5, n7);
  }
  constructor(t10) {
    c4(this, "options", t10), c4(this, "id"), c4(this, "schema"), c4(this, "indexes"), c4(this, "resolveRichText"), c4(this, "resolveVectorSetItem"), c4(this, "chunks"), this.chunks = this.options.chunks.map((t11, e10) => new tO2(e10, t11)), this.schema = t10.schema, this.indexes = t10.indexes, this.resolveRichText = t10.resolveRichText, this.resolveVectorSetItem = t10.resolveVectorSetItem, this.id = t10.id;
  }
};

// http-url:https://framerusercontent.com/modules/FBWpyT5wgPlMNO696wlP/UOzRipv4frmWk6jlCP3a/TXqlbf1RQ-1.js
import { jsx as e8 } from "react/jsx-runtime";
import { AutoBreakpointVariant as t8, ComponentPresetsConsumer as r4, Link as n5, motion as o4 } from "./_framer-runtime.js";
import { isValidElement as i5 } from "react";
import { Fragment as p5, createElement as s5 } from "react";
var a4;
var l5 = "undefined" != typeof __dai_window;
var f5 = l5 && "function" == typeof __dai_window.requestIdleCallback;
var u5 = "preload";
function c5(e10) {
  return "object" == typeof e10 && null !== e10 && !/* @__PURE__ */ i5(e10) && u5 in e10;
}
function m5(e10, ...t10) {
  if (!e10)
    throw Error("Assertion Error" + (t10.length > 0 ? ": " + t10.join(" ") : ""));
}
var d5 = ((a4 = d5 || {})[a4.Fragment = 1] = "Fragment", a4[a4.Link = 2] = "Link", a4[a4.Module = 3] = "Module", a4[a4.Tag = 4] = "Tag", a4[a4.Text = 5] = "Text", a4);
function g5(i6) {
  let a5 = /* @__PURE__ */ new Map();
  return (l7) => {
    let f7 = a5.get(l7);
    if (f7)
      return f7;
    let u7 = JSON.parse(l7), d7 = function a6(l8) {
      switch (l8[0]) {
        case 1: {
          let [, ...e10] = l8, t10 = e10.map(a6);
          return /* @__PURE__ */ s5(p5, void 0, ...t10);
        }
        case 2: {
          let [, e10, ...t10] = l8, r5 = t10.map(a6);
          return /* @__PURE__ */ s5(n5, e10, ...r5);
        }
        case 3: {
          let [, n7, o6, f8, u8] = l8;
          for (let e10 of f8) {
            let t10 = o6[e10];
            t10 && (o6[e10] = a6(t10));
          }
          for (let e10 of u8) {
            let t10 = o6[e10];
            if ("string" != typeof t10)
              continue;
            let r5 = i6[t10];
            r5 && (c5(r5) && r5.preload(), o6[e10] = r5);
          }
          let p7 = i6[n7];
          return m5(p7, "Module not found"), c5(p7) && p7.preload(), /* @__PURE__ */ e8(r4, { componentIdentifier: n7, children: (r5) => /* @__PURE__ */ e8(t8, { component: p7, props: { ...r5, ...o6 } }) });
        }
        case 4: {
          let [, e10, t10, ...r5] = l8, n7 = r5.map(a6);
          if ("a" === e10)
            return /* @__PURE__ */ s5(o4.a, t10, ...n7);
          return /* @__PURE__ */ s5(e10, t10, ...n7);
        }
        case 5: {
          let [, e10] = l8;
          return e10;
        }
      }
    }(u7);
    return a5.set(l7, d7), d7;
  };
}

// http-url:https://framerusercontent.com/modules/FBWpyT5wgPlMNO696wlP/UOzRipv4frmWk6jlCP3a/TXqlbf1RQ.js
var o5 = { AD779EBSk: { isNullable: true, type: l6.Boolean }, createdAt: { isNullable: true, type: l6.Date }, g_M8JDjJA: { isNullable: true, type: l6.String }, hhnBMu_hM: { isNullable: true, type: l6.ResponsiveImage }, id: { isNullable: false, type: l6.String }, N7u2kMKy9: { isNullable: true, type: l6.String }, nextItemId: { isNullable: true, type: l6.String }, oaFoHwnI6: { isNullable: true, type: l6.Number }, OWZ1lqNqm: { isNullable: true, type: l6.String }, previousItemId: { isNullable: true, type: l6.String }, tkLwIAfCY: { isNullable: true, type: l6.Number }, updatedAt: { isNullable: true, type: l6.Date }, XkQ6HZ1Zr: { isNullable: true, type: l6.Number }, xxpxsM0yN: { isNullable: true, type: l6.String }, yxFw_AjOr: { isNullable: true, type: l6.File }, ZuOQ4RC_7: { isNullable: true, type: l6.String } };
var m6 = ["id"];
var n6 = { type: 1 };
var u6 = ["previousItemId"];
var c6 = ["nextItemId"];
var f6 = ["id", "N7u2kMKy9"];
var s6 = ["N7u2kMKy9", "id"];
var d6 = ["AD779EBSk"];
var p6 = { type: 0 };
var y4 = ["hhnBMu_hM"];
var N4 = ["OWZ1lqNqm"];
var h4 = ["xxpxsM0yN"];
var w4 = ["ZuOQ4RC_7"];
var b4 = ["g_M8JDjJA"];
var R4 = ["oaFoHwnI6"];
var g6 = ["XkQ6HZ1Zr"];
var S4 = ["tkLwIAfCY"];
var x4 = ["yxFw_AjOr"];
var q4 = ["N7u2kMKy9"];
var I4 = [];
var L4 = (e10) => {
  let l7 = I4[e10];
  if (l7)
    return l7().then((e11) => e11.default);
};
var Q4 = {};
var T4 = g5(Q4);
var X4 = new t9();
var M4 = { collectionByLocaleId: { default: new tP2({ chunks: [""], id: "b2a41062-42c3-4719-9f69-60e13bd90ae2default", indexes: [new tN2({ collation: n6, collectionSchema: o5, fieldNames: m6, range: { from: 0, to: 169 }, url: "" }), new tN2({ collation: n6, collectionSchema: o5, fieldNames: u6, range: { from: 169, to: 337 }, url: "" }), new tN2({ collation: n6, collectionSchema: o5, fieldNames: c6, range: { from: 337, to: 501 }, url: "" }), new tN2({ collation: n6, collectionSchema: o5, fieldNames: f6, range: { from: 501, to: 781 }, url: "" }), new tN2({ collation: n6, collectionSchema: o5, fieldNames: s6, range: { from: 781, to: 1061 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: d6, range: { from: 1061, to: 1165 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: y4, range: { from: 1165, to: 4712 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: N4, range: { from: 4712, to: 4902 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: h4, range: { from: 4902, to: 5727 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: w4, range: { from: 5727, to: 6100 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: b4, range: { from: 6100, to: 10547 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: R4, range: { from: 10547, to: 10693 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: g6, range: { from: 10693, to: 10839 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: S4, range: { from: 10839, to: 10985 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: x4, range: { from: 10985, to: 11083 }, url: "" }), new tN2({ collation: p6, collectionSchema: o5, fieldNames: q4, range: { from: 11083, to: 11273 }, url: "" })], resolveRichText: T4, resolveVectorSetItem: L4, schema: o5 }) }, displayName: "Neighborhoods", id: "b2a41062-42c3-4719-9f69-60e13bd90ae2" };
var TXqlbf1RQ_default = M4;
e9(M4, { AD779EBSk: { defaultValue: true, title: "Featured", type: l6.Boolean }, hhnBMu_hM: { title: "Image", type: l6.ResponsiveImage }, OWZ1lqNqm: { defaultValue: "", title: "Name", type: l6.String }, xxpxsM0yN: { defaultValue: "", title: "Short Description", type: l6.String }, ZuOQ4RC_7: { defaultValue: "", title: "Secondary Title", type: l6.String }, g_M8JDjJA: { defaultValue: "", title: "Long Description", type: l6.String }, oaFoHwnI6: { defaultValue: 0, title: "Median sale price", type: l6.Number }, XkQ6HZ1Zr: { defaultValue: 0, title: "Avg price per sqft", type: l6.Number }, tkLwIAfCY: { defaultValue: 0, title: "Walk score", type: l6.Number }, yxFw_AjOr: { allowedFileTypes: [], title: "Video (Optional)", type: l6.File }, N7u2kMKy9: { preventLocalization: true, title: "Slug", type: l6.String }, createdAt: { title: "Created", type: l6.Date }, updatedAt: { title: "Updated", type: l6.Date }, previousItemId: { dataIdentifier: "local-module:collection/TXqlbf1RQ:default", title: "Previous", type: l6.CollectionReference }, nextItemId: { dataIdentifier: "local-module:collection/TXqlbf1RQ:default", title: "Next", type: l6.CollectionReference } });

// http-url:https://framerusercontent.com/modules/eQTpu6SrOEnJ9WPDnO2Y/3OjdvagMp1NfNaaU5WuI/ULRxBZjdd.js
var ArrowBackIosFonts = getFonts(qs7FKzEO5_default);
var RQHJv9fZWCollectionDataControls = getPropertyControls(hyPTlnA4N_default);
var cycleOrder = ["pdj5NuuWI", "v5yTW9O2P"];
var serializationHash = "framer-Lwqg5";
var variantClassNames = { pdj5NuuWI: "framer-v-dionbc", v5yTW9O2P: "framer-v-ynqjhc" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "Filter Closed": "pdj5NuuWI", "Filter Open": "v5yTW9O2P" };
var Variants = motion2.create(React2.Fragment);
var humanReadableEnumMap = { "1": "RSunMUq_r", "10": "j0mQCn1QX", "2": "Lu5Lsk3gE", "3": "eti8BSVE2", "4": "lG6v7ocST", "5": "u6TwU0dPD", "6": "IUem7Bcpj", "7": "jVk4nhFzU", "8": "BOqG6LkKj", "9": "ayrXkVQUZ" };
var humanReadableEnumMap1 = { "$1M \u2013 $3M": "yR5bXkyt1", "$3M \u2013 $5M": "czau9ac6B", "$500K \u2013 $1M": "yOtUflAyW", "$5M+": "kbXym98rd", "Under $500K": "srMvxWMQ2" };
var humanReadableEnumMap2 = { Apartment: "sWJIKemVT", Condo: "EIAAFxrj6", House: "Twhe336rp", Penthouse: "qPPwHw2XH", Townhouse: "VbRKFkHla" };
var humanReadableEnumMap3 = { "For Sale": "OIGoay1tV", Sold: "fHgv_CR9k" };
var useStateVariable = (externalState, setExternalState) => {
  const [internalState, setInternalState] = React2.useState(externalState);
  const [previousExternalState, setPreviousExternalState] = React2.useState(externalState);
  if (setExternalState) {
    return [externalState, setExternalState];
  }
  if (externalState !== previousExternalState) {
    setInternalState(externalState);
    setPreviousExternalState(externalState);
  }
  return [internalState, setInternalState];
};
var getProps2 = ({ bedroomsOptions, bedsVisible, height, id, neighborhood, neighborhoodVisible, priceRangeForFilters, priceVisible, status, statusVisible, type, typeVisible, width, ...props }) => {
  return { ...props, HjjcNQaOh: humanReadableEnumMap2[type] ?? type ?? props.HjjcNQaOh, kltzQ3Mr2: humanReadableEnumMap3[status] ?? status ?? props.kltzQ3Mr2, l5Nve3h5q: typeVisible ?? props.l5Nve3h5q ?? true, M6LL6wqdb: humanReadableEnumMap[bedroomsOptions] ?? bedroomsOptions ?? props.M6LL6wqdb, P6z0JIRMJ: neighborhood ?? props.P6z0JIRMJ, QPQ3fC_Vi: neighborhoodVisible ?? props.QPQ3fC_Vi ?? true, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "pdj5NuuWI", WCb6OR1qX: humanReadableEnumMap1[priceRangeForFilters] ?? priceRangeForFilters ?? props.WCb6OR1qX, WuEv3bmIC: bedsVisible ?? props.WuEv3bmIC ?? true, Xr2hvMScG: statusVisible ?? props.Xr2hvMScG ?? true, z0TnQ_RXR: priceVisible ?? props.z0TnQ_RXR ?? true };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, "P6z0JIRMJ": externalP6z0JIRMJ, "onP6z0JIRMJChange": setExternalP6z0JIRMJ, "M6LL6wqdb": externalM6LL6wqdb, "onM6LL6wqdbChange": setExternalM6LL6wqdb, "WCb6OR1qX": externalWCb6OR1qX, "onWCb6OR1qXChange": setExternalWCb6OR1qX, "HjjcNQaOh": externalHjjcNQaOh, "onHjjcNQaOhChange": setExternalHjjcNQaOh, "kltzQ3Mr2": externalkltzQ3Mr2, "onkltzQ3Mr2Change": setExternalkltzQ3Mr2, QPQ3fC_Vi, WuEv3bmIC, z0TnQ_RXR, l5Nve3h5q, Xr2hvMScG, ...restProps } = getProps2(props);
  const [P6z0JIRMJ, setP6z0JIRMJ] = useStateVariable(externalP6z0JIRMJ, setExternalP6z0JIRMJ);
  const [M6LL6wqdb, setM6LL6wqdb] = useStateVariable(externalM6LL6wqdb, setExternalM6LL6wqdb);
  const [WCb6OR1qX, setWCb6OR1qX] = useStateVariable(externalWCb6OR1qX, setExternalWCb6OR1qX);
  const [HjjcNQaOh, setHjjcNQaOh] = useStateVariable(externalHjjcNQaOh, setExternalHjjcNQaOh);
  const [kltzQ3Mr2, setkltzQ3Mr2] = useStateVariable(externalkltzQ3Mr2, setExternalkltzQ3Mr2);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "pdj5NuuWI", ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTapejutfi = activeVariantCallback(async (...args) => {
    setVariant("v5yTW9O2P");
  });
  const onTapc4e9gm = activeVariantCallback(async (...args) => {
    setVariant("pdj5NuuWI");
  });
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "v5yTW9O2P")
      return true;
    return false;
  };
  const [selectValue_A85Udum3w, selectOptions_A85Udum3w, selectOnChange_A85Udum3w] = useFormSelectVariableBinding({ allItemsLabel: "Any neighborhood", collectionData: TXqlbf1RQ_default, isOptional: true, setValue: setP6z0JIRMJ, slugId: "N7u2kMKy9", titleId: "OWZ1lqNqm", value: P6z0JIRMJ, variableType: "collectionreference" });
  const [selectValue_HkQqRjRtG, selectOptions_HkQqRjRtG, selectOnChange_HkQqRjRtG] = useFormSelectVariableBinding({ allItemsLabel: "All", getOptionTitle: enumToDisplayNameFunctions?.["RQHJv9fZW"], isOptional: true, options: hyPTlnA4N_default.propertyControls?.["RQHJv9fZW"]?.options, setValue: setM6LL6wqdb, value: M6LL6wqdb, variableType: "enum" });
  const [selectValue_gTZdVxMGv, selectOptions_gTZdVxMGv, selectOnChange_gTZdVxMGv] = useFormSelectVariableBinding({ allItemsLabel: "All", getOptionTitle: enumToDisplayNameFunctions?.["zvsKfuoA9"], isOptional: true, options: hyPTlnA4N_default.propertyControls?.["zvsKfuoA9"]?.options, setValue: setWCb6OR1qX, value: WCb6OR1qX, variableType: "enum" });
  const [selectValue_QzgD2Y9xV, selectOptions_QzgD2Y9xV, selectOnChange_QzgD2Y9xV] = useFormSelectVariableBinding({ allItemsLabel: "All", getOptionTitle: enumToDisplayNameFunctions?.["snQxG7xuO"], isOptional: true, options: hyPTlnA4N_default.propertyControls?.["snQxG7xuO"]?.options, setValue: setHjjcNQaOh, value: HjjcNQaOh, variableType: "enum" });
  const [selectValue_n_rIOv2HX, selectOptions_n_rIOv2HX, selectOnChange_n_rIOv2HX] = useFormSelectVariableBinding({ allItemsLabel: "All", getOptionTitle: enumToDisplayNameFunctions?.["y5C1gzvnF"], isOptional: true, options: hyPTlnA4N_default.propertyControls?.["y5C1gzvnF"]?.options, setValue: setkltzQ3Mr2, value: kltzQ3Mr2, variableType: "enum" });
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs(motion2.div, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-dionbc", className, classNames), "data-framer-name": "Filter Closed", layoutDependency, layoutId: "mobilefilters__pdj5NuuWI", ref: refBinding, style: { ...style }, ...addPropertyOverrides({ v5yTW9O2P: { "data-framer-name": "Filter Open" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsxs(motion2.div, { className: "framer-1vg7q9q", "data-framer-name": "title", "data-highlight": true, layoutDependency, layoutId: "mobilefilters__PWBfFXhhT", onTap: onTapejutfi, ...addPropertyOverrides({ v5yTW9O2P: { onTap: onTapc4e9gm } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { dir: "auto", style: { "--font-selector": "R0Y7Q29ybW9yYW50IEdhcmFtb25kLXJlZ3VsYXI=", "--framer-font-family": '"Cormorant Garamond", "Cormorant Garamond Placeholder", serif', "--framer-font-size": "24px", "--framer-text-color": "var(--extracted-r6o4lv, var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)))" }, children: "Filters" }) }), className: "framer-1gh9cnl", fonts: ["GF;Cormorant Garamond-regular"], layoutDependency, layoutId: "mobilefilters__almEBSyRi", style: { "--extracted-r6o4lv": "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx2(qs7FKzEO5_default, { animated: true, className: "framer-1s0n5f6", layoutDependency, layoutId: "mobilefilters__vPZexHDri", style: { "--esondr": "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", rotate: 90 }, variants: { v5yTW9O2P: { rotate: 270 } } })] }), isDisplayed() && /* @__PURE__ */ _jsxs(motion2.div, { className: "framer-6s6yu1", "data-framer-name": "filters", layoutDependency, layoutId: "mobilefilters__sMnz_ezMs", children: [QPQ3fC_Vi !== false && /* @__PURE__ */ _jsxs(motion2.label, { className: "framer-1qo4224", layoutDependency, layoutId: "mobilefilters__C4CYjxJY9", children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.h2, { dir: "auto", style: { "--framer-font-size": "12px", "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-1of0zx5, rgb(117, 117, 117))", "--framer-text-transform": "uppercase" }, children: "Location" }) }), className: "framer-arif24", fonts: ["Inter"], layoutDependency, layoutId: "mobilefilters__bGm1qNMKm", style: { "--extracted-1of0zx5": "rgb(117, 117, 117)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx2(FormSelect, { className: "framer-j3ysvg", inputName: "A85Udum3w", layoutDependency, layoutId: "mobilefilters__A85Udum3w", onChange: selectOnChange_A85Udum3w, selectOptions: selectOptions_A85Udum3w, style: { "--framer-input-border-radius-bottom-left": "10px", "--framer-input-border-radius-bottom-right": "10px", "--framer-input-border-radius-top-left": "10px", "--framer-input-border-radius-top-right": "10px", "--framer-input-font-color": "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", "--framer-input-icon-color": "rgb(153, 153, 153)" }, value: selectValue_A85Udum3w, ...addPropertyOverrides({ v5yTW9O2P: { inputName: "v5yTW9O2PA85Udum3w" } }, baseVariant, gestureVariant) })] }), WuEv3bmIC !== false && /* @__PURE__ */ _jsxs(motion2.label, { className: "framer-19k9mak", layoutDependency, layoutId: "mobilefilters__kBlPms_p4", children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.h2, { dir: "auto", style: { "--framer-font-size": "12px", "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-1of0zx5, rgb(117, 117, 117))", "--framer-text-transform": "uppercase" }, children: "BEDROOMS" }) }), className: "framer-rlc7iv", fonts: ["Inter"], layoutDependency, layoutId: "mobilefilters__OzwZH38gl", style: { "--extracted-1of0zx5": "rgb(117, 117, 117)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx2(FormSelect, { className: "framer-1ew66kc", inputName: "HkQqRjRtG", layoutDependency, layoutId: "mobilefilters__HkQqRjRtG", onChange: selectOnChange_HkQqRjRtG, selectOptions: selectOptions_HkQqRjRtG, style: { "--framer-input-border-radius-bottom-left": "10px", "--framer-input-border-radius-bottom-right": "10px", "--framer-input-border-radius-top-left": "10px", "--framer-input-border-radius-top-right": "10px", "--framer-input-font-color": "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", "--framer-input-icon-color": "rgb(153, 153, 153)" }, value: selectValue_HkQqRjRtG, ...addPropertyOverrides({ v5yTW9O2P: { inputName: "v5yTW9O2PHkQqRjRtG" } }, baseVariant, gestureVariant) })] }), z0TnQ_RXR !== false && /* @__PURE__ */ _jsxs(motion2.label, { className: "framer-15ayk04", layoutDependency, layoutId: "mobilefilters__FjoJYTLD3", children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.h2, { dir: "auto", style: { "--framer-font-size": "12px", "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-1of0zx5, rgb(117, 117, 117))", "--framer-text-transform": "uppercase" }, children: "price range" }) }), className: "framer-zu8vq2", fonts: ["Inter"], layoutDependency, layoutId: "mobilefilters__I7KSvHd46", style: { "--extracted-1of0zx5": "rgb(117, 117, 117)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx2(FormSelect, { className: "framer-1aeig7h", inputName: "gTZdVxMGv", layoutDependency, layoutId: "mobilefilters__gTZdVxMGv", onChange: selectOnChange_gTZdVxMGv, selectOptions: selectOptions_gTZdVxMGv, style: { "--framer-input-border-radius-bottom-left": "10px", "--framer-input-border-radius-bottom-right": "10px", "--framer-input-border-radius-top-left": "10px", "--framer-input-border-radius-top-right": "10px", "--framer-input-font-color": "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", "--framer-input-icon-color": "rgb(153, 153, 153)" }, value: selectValue_gTZdVxMGv, ...addPropertyOverrides({ v5yTW9O2P: { inputName: "v5yTW9O2PgTZdVxMGv" } }, baseVariant, gestureVariant) })] }), l5Nve3h5q !== false && /* @__PURE__ */ _jsxs(motion2.label, { className: "framer-agkllx", layoutDependency, layoutId: "mobilefilters__lQozBuC1C", children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.h2, { dir: "auto", style: { "--framer-font-size": "12px", "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-1of0zx5, rgb(117, 117, 117))", "--framer-text-transform": "uppercase" }, children: "TYPE" }) }), className: "framer-1y23oms", fonts: ["Inter"], layoutDependency, layoutId: "mobilefilters__JcijAPAUs", style: { "--extracted-1of0zx5": "rgb(117, 117, 117)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx2(FormSelect, { className: "framer-15ty4am", inputName: "QzgD2Y9xV", layoutDependency, layoutId: "mobilefilters__QzgD2Y9xV", onChange: selectOnChange_QzgD2Y9xV, selectOptions: selectOptions_QzgD2Y9xV, style: { "--framer-input-border-radius-bottom-left": "10px", "--framer-input-border-radius-bottom-right": "10px", "--framer-input-border-radius-top-left": "10px", "--framer-input-border-radius-top-right": "10px", "--framer-input-font-color": "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", "--framer-input-icon-color": "rgb(153, 153, 153)" }, value: selectValue_QzgD2Y9xV, ...addPropertyOverrides({ v5yTW9O2P: { inputName: "v5yTW9O2PQzgD2Y9xV" } }, baseVariant, gestureVariant) })] }), Xr2hvMScG !== false && /* @__PURE__ */ _jsxs(motion2.label, { className: "framer-svmy98", layoutDependency, layoutId: "mobilefilters__mFc0C0uc9", children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.h2, { dir: "auto", style: { "--framer-font-size": "12px", "--framer-text-alignment": "left", "--framer-text-color": "var(--extracted-1of0zx5, rgb(117, 117, 117))", "--framer-text-transform": "uppercase" }, children: "STATUS" }) }), className: "framer-4uh4s", fonts: ["Inter"], layoutDependency, layoutId: "mobilefilters__omdp7zvaS", style: { "--extracted-1of0zx5": "rgb(117, 117, 117)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true }), /* @__PURE__ */ _jsx2(FormSelect, { className: "framer-33yv5k", inputName: "n_rIOv2HX", layoutDependency, layoutId: "mobilefilters__n_rIOv2HX", onChange: selectOnChange_n_rIOv2HX, selectOptions: selectOptions_n_rIOv2HX, style: { "--framer-input-border-radius-bottom-left": "10px", "--framer-input-border-radius-bottom-right": "10px", "--framer-input-border-radius-top-left": "10px", "--framer-input-border-radius-top-right": "10px", "--framer-input-font-color": "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", "--framer-input-icon-color": "rgb(153, 153, 153)" }, value: selectValue_n_rIOv2HX, ...addPropertyOverrides({ v5yTW9O2P: { inputName: "v5yTW9O2Pn_rIOv2HX" } }, baseVariant, gestureVariant) })] })] })] }) }) }) });
});
var css2 = [".framer-Lwqg5.framer-1htgd2w, .framer-Lwqg5 .framer-1htgd2w { display: block; }", ".framer-Lwqg5.framer-dionbc { align-content: flex-start; align-items: flex-start; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 24px; height: min-content; justify-content: flex-start; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-Lwqg5 .framer-1vg7q9q { align-content: center; align-items: center; cursor: pointer; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; height: min-content; justify-content: space-between; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-Lwqg5 .framer-1gh9cnl, .framer-Lwqg5 .framer-arif24, .framer-Lwqg5 .framer-rlc7iv, .framer-Lwqg5 .framer-zu8vq2, .framer-Lwqg5 .framer-1y23oms, .framer-Lwqg5 .framer-4uh4s { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-Lwqg5 .framer-1s0n5f6 { aspect-ratio: 1 / 1; flex: none; height: auto; position: relative; width: 18px; }", ".framer-Lwqg5 .framer-6s6yu1 { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: flex-start; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-Lwqg5 .framer-1qo4224, .framer-Lwqg5 .framer-19k9mak, .framer-Lwqg5 .framer-15ayk04, .framer-Lwqg5 .framer-agkllx, .framer-Lwqg5 .framer-svmy98 { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 8px; height: min-content; justify-content: flex-start; padding: 0px; position: relative; width: 100%; }", '.framer-Lwqg5 .framer-j3ysvg, .framer-Lwqg5 .framer-1ew66kc, .framer-Lwqg5 .framer-1aeig7h, .framer-Lwqg5 .framer-15ty4am, .framer-Lwqg5 .framer-33yv5k { --framer-input-focused-border-color: #0099ff; --framer-input-focused-border-style: solid; --framer-input-focused-border-width: 1px; --framer-input-font-family: "Inter"; --framer-input-font-letter-spacing: 0em; --framer-input-font-line-height: 1.2em; --framer-input-font-size: 14px; --framer-input-font-weight: 400; --framer-input-padding: 12px; --framer-input-wrapper-height: auto; flex: none; height: auto; position: relative; width: 100%; }', ".framer-Lwqg5.framer-v-ynqjhc.framer-dionbc { width: 100%; }"];
var FramerULRxBZjdd = withCSS2(Component2, css2, "framer-Lwqg5");
var ULRxBZjdd_default = FramerULRxBZjdd;
FramerULRxBZjdd.displayName = "mobile filters";
FramerULRxBZjdd.defaultProps = { height: 29, width: 400 };
addPropertyControls2(FramerULRxBZjdd, { variant: { options: ["pdj5NuuWI", "v5yTW9O2P"], optionTitles: ["Filter Closed", "Filter Open"], title: "Variant", type: ControlType2.Enum }, P6z0JIRMJ: { dataIdentifier: "local-module:collection/TXqlbf1RQ:default", optional: true, title: "Neighborhood", type: ControlType2.CollectionReference }, onP6z0JIRMJChange: { changes: "P6z0JIRMJ", type: ControlType2.ChangeHandler }, M6LL6wqdb: RQHJv9fZWCollectionDataControls?.["RQHJv9fZW"] && { ...RQHJv9fZWCollectionDataControls["RQHJv9fZW"], defaultValue: void 0, description: void 0, hidden: void 0, optional: true, title: "Bedrooms Options" }, onM6LL6wqdbChange: { changes: "M6LL6wqdb", type: ControlType2.ChangeHandler }, WCb6OR1qX: RQHJv9fZWCollectionDataControls?.["zvsKfuoA9"] && { ...RQHJv9fZWCollectionDataControls["zvsKfuoA9"], defaultValue: void 0, description: void 0, hidden: void 0, optional: true, title: "Price Range For Filters" }, onWCb6OR1qXChange: { changes: "WCb6OR1qX", type: ControlType2.ChangeHandler }, HjjcNQaOh: RQHJv9fZWCollectionDataControls?.["snQxG7xuO"] && { ...RQHJv9fZWCollectionDataControls["snQxG7xuO"], defaultValue: void 0, description: void 0, hidden: void 0, optional: true, title: "Type" }, onHjjcNQaOhChange: { changes: "HjjcNQaOh", type: ControlType2.ChangeHandler }, kltzQ3Mr2: RQHJv9fZWCollectionDataControls?.["y5C1gzvnF"] && { ...RQHJv9fZWCollectionDataControls["y5C1gzvnF"], defaultValue: void 0, description: void 0, hidden: void 0, optional: true, title: "Status" }, onkltzQ3Mr2Change: { changes: "kltzQ3Mr2", type: ControlType2.ChangeHandler }, QPQ3fC_Vi: { defaultValue: true, title: "Neighborhood Visible", type: ControlType2.Boolean }, onQPQ3fC_ViChange: { changes: "QPQ3fC_Vi", type: ControlType2.ChangeHandler }, WuEv3bmIC: { defaultValue: true, title: "Beds Visible", type: ControlType2.Boolean }, onWuEv3bmICChange: { changes: "WuEv3bmIC", type: ControlType2.ChangeHandler }, z0TnQ_RXR: { defaultValue: true, title: "Price Visible", type: ControlType2.Boolean }, onz0TnQ_RXRChange: { changes: "z0TnQ_RXR", type: ControlType2.ChangeHandler }, l5Nve3h5q: { defaultValue: true, title: "Type Visible", type: ControlType2.Boolean }, onl5Nve3h5qChange: { changes: "l5Nve3h5q", type: ControlType2.ChangeHandler }, Xr2hvMScG: { defaultValue: true, title: "Status Visible", type: ControlType2.Boolean }, onXr2hvMScGChange: { changes: "Xr2hvMScG", type: ControlType2.ChangeHandler } });
addFonts(FramerULRxBZjdd, [{ explicitInter: true, fonts: [{ cssFamilyName: "Cormorant Garamond", source: "google", style: "normal", uiFamilyName: "Cormorant Garamond", url: "https://fonts.gstatic.com/s/cormorantgaramond/v21/co3umX5slCNuHLi8bLeY9MK7whWMhyjypVO7abI26QOD_v86GnbEi_s4Mfs.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...ArrowBackIosFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "FramerULRxBZjdd", "slots": [], "annotations": { "framerContractVersion": "1", "framerImmutableVariables": "true", "framerVariables": '{"P6z0JIRMJ":"neighborhood","M6LL6wqdb":"bedroomsOptions","WCb6OR1qX":"priceRangeForFilters","HjjcNQaOh":"type","kltzQ3Mr2":"status","QPQ3fC_Vi":"neighborhoodVisible","WuEv3bmIC":"bedsVisible","z0TnQ_RXR":"priceVisible","l5Nve3h5q":"typeVisible","Xr2hvMScG":"statusVisible"}', "framerIntrinsicWidth": "400", "framerDisplayContentsDiv": "false", "framerComponentViewportWidth": "true", "framerAutoSizeImages": "true", "framerColorSyntax": "true", "framerIntrinsicHeight": "29", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"v5yTW9O2P":{"layout":["fixed","auto"]}}}' } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  ULRxBZjdd_default as default
};
