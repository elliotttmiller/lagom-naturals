export interface Testimonials5Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Desktop - Slide 1" → AGVyXMoIM
   *   "Desktop - Slide 2" → hpr0OYksy
   *   "Desktop - Slide 3" → FEc8SuJp4
   *   "Phone - Slide 1" → qIRlryian
   *   "Phone - Slide 2" → DvutshOwm
   *   "Phone - Slide 3" → DWpj4nfZU
   *   "Tablet  - Slide 2" → hyepWNKxS
   *   "Tablet  - Slide 3" → Z4omBhAT8
   *   "Tablet - Slide 1" → xKlW0J68_
   */
  variant?: 'Desktop - Slide 1' | 'Desktop - Slide 2' | 'Desktop - Slide 3' | 'Phone - Slide 1' | 'Phone - Slide 2' | 'Phone - Slide 3' | 'Tablet  - Slide 2' | 'Tablet  - Slide 3' | 'Tablet - Slide 1' | 'AGVyXMoIM' | 'hpr0OYksy' | 'FEc8SuJp4' | 'xKlW0J68_' | 'hyepWNKxS' | 'Z4omBhAT8' | 'qIRlryian' | 'DvutshOwm' | 'DWpj4nfZU';
  /**
   * Quote 1 — pass as `hj738Ed3K` not `quote1`.
   * @default "We had been searching for over a year before we found Aldren. Within three weeks they identified two properties we never would have seen otherwise.Precise, personal, and completely without pressure."
   */
  hj738Ed3K?: string;
  onhj738Ed3KChange?: string;
  /**
   * Client Headshot 1 — pass as `IBh0RGOK6` not `clientHeadshot1`.
   */
  IBh0RGOK6?: string;
  /**
   * Client Name 1 — pass as `z6TA8buJC` not `clientName1`.
   * @default "Victoria L."
   */
  z6TA8buJC?: string;
  onz6TA8buJCChange?: string;
  /**
   * Transaction 1 — pass as `PgiOAWnav` not `transaction1`.
   * @default "Purchased in Chelsea · £9.4M"
   */
  PgiOAWnav?: string;
  onPgiOAWnavChange?: string;
  /**
   * Description 1 — pass as `ZYPYEPhUU` not `description1`.
   * @default "A selection of accounts from completed mandates — sale-side, buy-side, and ongoing advisory"
   */
  ZYPYEPhUU?: string;
  onZYPYEPhUUChange?: string;
  /**
   * Quote 2 — pass as `VjgyQc9Lv` not `quote2`.
   * @default "We had been searching for over a year before we found Aldren. Within three weeks they identified two properties we never would have seen otherwise.Precise, personal, and completely without pressure."
   */
  VjgyQc9Lv?: string;
  onVjgyQc9LvChange?: string;
  /**
   * Client Headshot 2 — pass as `bZGCAM7lN` not `clientHeadshot2`.
   */
  bZGCAM7lN?: string;
  /**
   * Client Name 2 — pass as `kyp4WR18S` not `clientName2`.
   * @default "Victoria L."
   */
  kyp4WR18S?: string;
  onkyp4WR18SChange?: string;
  /**
   * Transaction 2 — pass as `HvIntlgrF` not `transaction2`.
   * @default "Purchased in Chelsea · £9.4M"
   */
  HvIntlgrF?: string;
  onHvIntlgrFChange?: string;
  /**
   * Description 2 — pass as `BWGUOay2G` not `description2`.
   * @default "A selection of accounts from completed mandates — sale-side, buy-side, and ongoing advisory"
   */
  BWGUOay2G?: string;
  onBWGUOay2GChange?: string;
  /**
   * Quote 3 — pass as `io8c1GF5E` not `quote3`.
   * @default "We had been searching for over a year before we found Aldren. Within three weeks they identified two properties we never would have seen otherwise.Precise, personal, and completely without pressure."
   */
  io8c1GF5E?: string;
  onio8c1GF5EChange?: string;
  /**
   * Client Headshot 3 — pass as `HYYitr5Kg` not `clientHeadshot3`.
   */
  HYYitr5Kg?: string;
  /**
   * Client Name 3 — pass as `ja7tydNiK` not `clientName3`.
   * @default "Victoria L."
   */
  ja7tydNiK?: string;
  onja7tydNiKChange?: string;
  /**
   * Transaction 3 — pass as `JssJWEIQm` not `transaction3`.
   * @default "Purchased in Chelsea · £9.4M"
   */
  JssJWEIQm?: string;
  onJssJWEIQmChange?: string;
  /**
   * Description 3 — pass as `NchveF7cl` not `description3`.
   * @default "A selection of accounts from completed mandates — sale-side, buy-side, and ongoing advisory"
   */
  NchveF7cl?: string;
  onNchveF7clChange?: string;
  /**
   * Arrows Visible — pass as `dnqHaNAPh` not `arrowsVisible`.
   * @default true
   */
  dnqHaNAPh?: boolean;
  ondnqHaNAPhChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
