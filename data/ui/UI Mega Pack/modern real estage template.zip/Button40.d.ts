export interface Button40Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Variant 1" → pEUvRODrx
   *   "Variant 2" → c2M0D2Gk6
   */
  variant?: 'Variant 1' | 'Variant 2' | 'pEUvRODrx' | 'c2M0D2Gk6';
  /**
   * Text — pass as `Nk9CQOGHG` not `text`.
   * @default "Explore Properties"
   */
  Nk9CQOGHG?: string;
  onNk9CQOGHGChange?: string;
  /**
   * Default Background Color — pass as `Cfh8Zxf9C` not `defaultBackgroundColor`.
   * @default "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */"
   */
  Cfh8Zxf9C?: string;
  /**
   * Default Text Color — pass as `ndsT4W1CC` not `defaultTextColor`.
   * @default "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))"
   */
  ndsT4W1CC?: string;
  /**
   * Default Border — pass as `G1Aueh5gp` not `defaultBorder`.
   * @default {"borderColor":"var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {\"name\":\"White\"} */","borderStyle":"solid","borderWidth":1}
   */
  G1Aueh5gp?: string;
  /**
   * Hover Background Color — pass as `LTaRf1Os4` not `hoverBackgroundColor`.
   * @default "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */"
   */
  LTaRf1Os4?: string;
  /**
   * Hover Text Color — pass as `TKPnz_Ntl` not `hoverTextColor`.
   * @default "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))"
   */
  TKPnz_Ntl?: string;
  /**
   * Hover Border — pass as `KakYM8inN` not `hoverBorder`.
   * @default {"borderColor":"var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {\"name\":\"White\"} */","borderStyle":"solid","borderWidth":1}
   */
  KakYM8inN?: string;
  /**
   * Arrow — pass as `Z4jhW3SAq` not `arrow`.
   * @default true
   */
  Z4jhW3SAq?: boolean;
  onZ4jhW3SAqChange?: string;
  /**
   * Link — pass as `hCv5Bj5Nx` not `link`.
   */
  hCv5Bj5Nx?: string;
  /**
   * New Tab — pass as `Z_YhYkC46` not `newTab`.
   * @default false
   */
  Z_YhYkC46?: boolean;
  onZ_YhYkC46Change?: string;
  /** Additional properties */
  [key: string]: unknown;
}
