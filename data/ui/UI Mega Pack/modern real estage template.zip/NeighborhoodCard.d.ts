export interface NeighborhoodcardProps {
  /**
   * Image — pass as `gyD5PSXod` not `image`.
   */
  gyD5PSXod?: string;
  /**
   * Name — pass as `I5sNYXsU1` not `name`.
   * @default "Upper East Side"
   */
  I5sNYXsU1?: string;
  onI5sNYXsU1Change?: string;
  /** Additional properties */
  [key: string]: unknown;
}
