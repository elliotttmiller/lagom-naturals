export interface Stats20Props {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Variant 3" → gzIeKZMZ7
   *   "Default" → BZLIOfgn_
   *   "Mobile" → NtSH2yqEJ
   */
  variant?: 'Variant 3' | 'Default' | 'Mobile' | 'BZLIOfgn_' | 'NtSH2yqEJ' | 'gzIeKZMZ7';
  /**
   * From — pass as `JBDXOdsnT` not `from`.
   * Range: min: 0, step: 0.1
   * @default 0
   */
  JBDXOdsnT?: number;
  onJBDXOdsnTChange?: string;
  /**
   * To — pass as `mcxfqk1GE` not `to`.
   * Range: min: 0, step: 0.1
   * @default 100
   */
  mcxfqk1GE?: number;
  onmcxfqk1GEChange?: string;
  /**
   * Color — pass as `FyjYDALhf` not `color`.
   * @default "rgb(255, 255, 255)"
   */
  FyjYDALhf?: string;
  /**
   * Subtitle — pass as `QIJl52EuD` not `subtitle`.
   * @default "Projects Completed"
   */
  QIJl52EuD?: string;
  onQIJl52EuDChange?: string;
  /**
   * Show Right Text — pass as `K_RTEg_tC` not `showRightText`.
   * @default true
   */
  K_RTEg_tC?: boolean;
  onK_RTEg_tCChange?: string;
  /**
   * Right Text — pass as `xSMrnq17d` not `rightText`.
   * @default "+"
   */
  xSMrnq17d?: string;
  onxSMrnq17dChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
