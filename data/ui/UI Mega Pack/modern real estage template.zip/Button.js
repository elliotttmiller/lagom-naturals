var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/DD0wWXAo96e14JmTosUl/e3I810N6Y0D79jk5koOp/TxRF350hk.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls2, ControlType as ControlType2, cx as cx2, getFonts, Link, RichText, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef } from "react";

// http-url:https://framerusercontent.com/modules/TgdovPTf12h5e9mf5mKX/ny0lQDjRQ5zoBlru0VHq/tL6Nru9eO.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 0 0.75 C 0 0.336 0.336 0 0.75 0 L 15.75 0 C 16.164 0 16.5 0.336 16.5 0.75 L 16.5 15.75 C 16.5 16.164 16.164 16.5 15.75 16.5 L 0.75 16.5 C 0.336 16.5 0 16.164 0 15.75 Z" fill-opacity="var(--1m6trwb, 0)" fill="var(--21h8s6, rgb(0, 0, 0))" height="16.5px" id="qUYSYEB2C" transform="translate(3.75 27.75)" width="16.5px"/><path d="M 0 0.75 C 0 0.336 0.336 0 0.75 0 L 15.75 0 C 16.164 0 16.5 0.336 16.5 0.75 L 16.5 15.75 C 16.5 16.164 16.164 16.5 15.75 16.5 L 0.75 16.5 C 0.336 16.5 0 16.164 0 15.75 Z" fill="transparent" height="16.5px" id="BcpYYi6FC" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(3.75 27.75)" width="16.5px"/><path d="M 0 0 L 7.5 0" fill="transparent" height="1px" id="RQrRctFta" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(8.25 12)" width="7.5px"/><path d="M 0 0 L 3 3 L 0 6" fill="transparent" height="6px" id="qCkbhs0Cc" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--pgex8v, 1.5)" stroke="var(--21h8s6, rgb(0, 0, 0))" transform="translate(12.75 9)" width="3px"/></svg>';
var getProps = ({ alpha, color, height, id, width, width1, ...props }) => {
  return { ...props, ezTt3ayMo: color ?? props.ezTt3ayMo ?? "rgb(0, 0, 0)", lschgej4H: width1 ?? props.lschgej4H ?? 1.5, qxTvv_EBh: alpha ?? props.qxTvv_EBh };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, ezTt3ayMo, lschgej4H, qxTvv_EBh, ...restProps } = getProps(props);
  const href = useSVGTemplate("3855583215", svg);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-VHcoG", className), layoutId, ref, role: "presentation", style: { "--1m6trwb": qxTvv_EBh, "--21h8s6": ezTt3ayMo, "--pgex8v": lschgej4H, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx("use", { href }) });
});
var css = [`.framer-VHcoG { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-VHcoG");
Icon.displayName = "Arrow Square Right";
var tL6Nru9eO_default = Icon;
addPropertyControls(Icon, { ezTt3ayMo: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Color", type: ControlType.Color }, lschgej4H: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 6, min: 0, step: 0.5, title: "Width", type: ControlType.Number }, qxTvv_EBh: { defaultValue: 0, displayStepper: true, hidden: false, max: 1, min: 0, step: 0.1, title: "Alpha", type: ControlType.Number } });

// http-url:https://framerusercontent.com/modules/DD0wWXAo96e14JmTosUl/e3I810N6Y0D79jk5koOp/TxRF350hk.js
var ArrowSquareRightFonts = getFonts(tL6Nru9eO_default);
var enabledGestures = { pEUvRODrx: { hover: true } };
var cycleOrder = ["pEUvRODrx", "c2M0D2Gk6"];
var serializationHash = "framer-xYTrY";
var variantClassNames = { c2M0D2Gk6: "framer-v-1a38zcf", pEUvRODrx: "framer-v-1v3j1ym" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx2(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { "Variant 1": "pEUvRODrx", "Variant 2": "c2M0D2Gk6" };
var Variants = motion2.create(React2.Fragment);
var getProps2 = ({ arrow, defaultBackgroundColor, defaultBorder, defaultTextColor, height, hoverBackgroundColor, hoverBorder, hoverTextColor, id, link, newTab, text, width, ...props }) => {
  return { ...props, Cfh8Zxf9C: defaultBackgroundColor ?? props.Cfh8Zxf9C ?? "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", G1Aueh5gp: defaultBorder ?? props.G1Aueh5gp ?? { borderColor: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', borderStyle: "solid", borderWidth: 1 }, hCv5Bj5Nx: link ?? props.hCv5Bj5Nx, KakYM8inN: hoverBorder ?? props.KakYM8inN ?? { borderColor: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', borderStyle: "solid", borderWidth: 1 }, LTaRf1Os4: hoverBackgroundColor ?? props.LTaRf1Os4 ?? "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", ndsT4W1CC: defaultTextColor ?? props.ndsT4W1CC ?? "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))", Nk9CQOGHG: text ?? props.Nk9CQOGHG ?? "Explore Properties", TKPnz_Ntl: hoverTextColor ?? props.TKPnz_Ntl ?? "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "pEUvRODrx", Z_YhYkC46: newTab ?? props.Z_YhYkC46, Z4jhW3SAq: arrow ?? props.Z4jhW3SAq ?? true };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, Nk9CQOGHG, Cfh8Zxf9C, ndsT4W1CC, G1Aueh5gp, LTaRf1Os4, TKPnz_Ntl, KakYM8inN, Z4jhW3SAq, hCv5Bj5Nx, Z_YhYkC46, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "pEUvRODrx", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = (value) => {
    if (baseVariant === "c2M0D2Gk6")
      return false;
    return value;
  };
  return /* @__PURE__ */ _jsx2(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx2(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx2(Transition, { value: transition1, children: /* @__PURE__ */ _jsx2(Link, { href: hCv5Bj5Nx, motionChild: true, nodeId: "pEUvRODrx", openInNewTab: Z_YhYkC46, scopeId: "TxRF350hk", children: /* @__PURE__ */ _jsxs(motion2.a, { ...restProps, ...gestureHandlers, className: `${cx2(scopingClassNames, "framer-1v3j1ym", className, classNames)} framer-tyhx9i`, "data-border": true, "data-framer-name": "Variant 1", layoutDependency, layoutId: "Button__pEUvRODrx", ref: refBinding, style: { "--border-bottom-width": (G1Aueh5gp?.borderBottomWidth ?? G1Aueh5gp?.borderWidth) + "px", "--border-color": G1Aueh5gp?.borderColor, "--border-left-width": (G1Aueh5gp?.borderLeftWidth ?? G1Aueh5gp?.borderWidth) + "px", "--border-right-width": (G1Aueh5gp?.borderRightWidth ?? G1Aueh5gp?.borderWidth) + "px", "--border-style": G1Aueh5gp?.borderStyle, "--border-top-width": (G1Aueh5gp?.borderTopWidth ?? G1Aueh5gp?.borderWidth) + "px", backgroundColor: Cfh8Zxf9C, ...style }, variants: { "pEUvRODrx-hover": { "--border-bottom-width": (KakYM8inN?.borderBottomWidth ?? KakYM8inN?.borderWidth) + "px", "--border-color": KakYM8inN?.borderColor, "--border-left-width": (KakYM8inN?.borderLeftWidth ?? KakYM8inN?.borderWidth) + "px", "--border-right-width": (KakYM8inN?.borderRightWidth ?? KakYM8inN?.borderWidth) + "px", "--border-style": KakYM8inN?.borderStyle, "--border-top-width": (KakYM8inN?.borderTopWidth ?? KakYM8inN?.borderWidth) + "px", backgroundColor: LTaRf1Os4 }, c2M0D2Gk6: { "--border-bottom-width": "0px", "--border-left-width": "0px", "--border-right-width": "0px", "--border-top-width": "0px" } }, ...addPropertyOverrides({ "pEUvRODrx-hover": { "data-framer-name": void 0 }, c2M0D2Gk6: { "data-framer-name": "Variant 2" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx2(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { dir: "auto", style: { "--framer-line-height": "1em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-ndsT4W1CC-TxRF350hk))" }, children: "Explore Properties" }) }), className: "framer-nw5h50", fonts: ["Inter"], layoutDependency, layoutId: "Button__ph41uNL7c", style: { "--extracted-r6o4lv": "var(--variable-reference-ndsT4W1CC-TxRF350hk)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline", "--variable-reference-ndsT4W1CC-TxRF350hk": ndsT4W1CC, "--variable-reference-TKPnz_Ntl-TxRF350hk": TKPnz_Ntl }, text: Nk9CQOGHG, variants: { "pEUvRODrx-hover": { "--extracted-r6o4lv": "var(--variable-reference-TKPnz_Ntl-TxRF350hk)", "--variable-reference-TKPnz_Ntl-TxRF350hk": TKPnz_Ntl } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ "pEUvRODrx-hover": { children: /* @__PURE__ */ _jsx2(React2.Fragment, { children: /* @__PURE__ */ _jsx2(motion2.p, { dir: "auto", style: { "--framer-line-height": "1em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-TKPnz_Ntl-TxRF350hk))" }, children: "Explore Properties" }) }) } }, baseVariant, gestureVariant) }), isDisplayed(Z4jhW3SAq !== false) && /* @__PURE__ */ _jsx2(tL6Nru9eO_default, { animated: true, className: "framer-87rq2l", layoutDependency, layoutId: "Button__pi6Oi1xxo", style: { "--1m6trwb": 0, "--21h8s6": ndsT4W1CC, "--pgex8v": 1 }, variants: { "pEUvRODrx-hover": { "--21h8s6": TKPnz_Ntl } } })] }) }) }) }) });
});
var css2 = [".framer-xYTrY.framer-tyhx9i, .framer-xYTrY .framer-tyhx9i { display: block; }", ".framer-xYTrY.framer-1v3j1ym { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 9px 16px 9px 28px; position: relative; text-decoration: none; width: min-content; }", ".framer-xYTrY .framer-nw5h50 { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-xYTrY .framer-87rq2l { aspect-ratio: 1 / 1; flex: none; height: auto; position: relative; width: 40px; }", ".framer-xYTrY.framer-v-1a38zcf.framer-1v3j1ym { padding: 9px 16px 9px 16px; }", '.framer-xYTrY[data-border="true"]::after, .framer-xYTrY [data-border="true"]::after { content: ""; border-width: var(--border-top-width, 0) var(--border-right-width, 0) var(--border-bottom-width, 0) var(--border-left-width, 0); border-color: var(--border-color, none); border-style: var(--border-style, none); width: 100%; height: 100%; position: absolute; box-sizing: border-box; left: 0; top: 0; border-radius: inherit; corner-shape: inherit; pointer-events: none; }'];
var FramerTxRF350hk = withCSS2(Component2, css2, "framer-xYTrY");
var TxRF350hk_default = FramerTxRF350hk;
FramerTxRF350hk.displayName = "Button";
FramerTxRF350hk.defaultProps = { height: 58, width: 223 };
addPropertyControls2(FramerTxRF350hk, { variant: { options: ["pEUvRODrx", "c2M0D2Gk6"], optionTitles: ["Variant 1", "Variant 2"], title: "Variant", type: ControlType2.Enum }, Nk9CQOGHG: { defaultValue: "Explore Properties", displayTextArea: false, title: "Text", type: ControlType2.String }, onNk9CQOGHGChange: { changes: "Nk9CQOGHG", type: ControlType2.ChangeHandler }, Cfh8Zxf9C: { defaultValue: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', title: "Default Background Color", type: ControlType2.Color }, ndsT4W1CC: { defaultValue: "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))", title: "Default Text Color", type: ControlType2.Color }, G1Aueh5gp: { defaultValue: { borderColor: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', borderStyle: "solid", borderWidth: 1 }, title: "Default Border", type: ControlType2.Border }, LTaRf1Os4: { defaultValue: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', title: "Hover Background Color", type: ControlType2.Color }, TKPnz_Ntl: { defaultValue: "var(--token-327277ca-04ef-41bd-84dc-8fdd00489044, rgb(0, 0, 0))", title: "Hover Text Color", type: ControlType2.Color }, KakYM8inN: { defaultValue: { borderColor: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', borderStyle: "solid", borderWidth: 1 }, title: "Hover Border", type: ControlType2.Border }, Z4jhW3SAq: { defaultValue: true, title: "Arrow", type: ControlType2.Boolean }, onZ4jhW3SAqChange: { changes: "Z4jhW3SAq", type: ControlType2.ChangeHandler }, hCv5Bj5Nx: { title: "Link", type: ControlType2.Link }, Z_YhYkC46: { defaultValue: false, title: "New Tab", type: ControlType2.Boolean }, onZ_YhYkC46Change: { changes: "Z_YhYkC46", type: ControlType2.ChangeHandler } });
addFonts(FramerTxRF350hk, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }] }, ...ArrowSquareRightFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerTxRF350hk", "slots": [], "annotations": { "framerAutoSizeImages": "true", "framerVariables": '{"Nk9CQOGHG":"text","Cfh8Zxf9C":"defaultBackgroundColor","ndsT4W1CC":"defaultTextColor","G1Aueh5gp":"defaultBorder","LTaRf1Os4":"hoverBackgroundColor","TKPnz_Ntl":"hoverTextColor","KakYM8inN":"hoverBorder","Z4jhW3SAq":"arrow","hCv5Bj5Nx":"link","Z_YhYkC46":"newTab"}', "framerComponentViewportWidth": "true", "framerColorSyntax": "true", "framerImmutableVariables": "true", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["auto","auto"]},"c2M0D2Gk6":{"layout":["auto","auto"]},"oVCwQe6tG":{"layout":["auto","auto"]}}}', "framerIntrinsicHeight": "58", "framerDisplayContentsDiv": "false", "framerContractVersion": "1", "framerIntrinsicWidth": "223" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  TxRF350hk_default as default
};
