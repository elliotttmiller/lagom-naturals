export interface Videoimage3Props {
  /**
   * Video — pass as `KTEKLv2jD` not `video`.
   * @default true
   */
  KTEKLv2jD?: boolean;
  onKTEKLv2jDChange?: string;
  /**
   * Background Image — pass as `FxNnwMJAP` not `backgroundImage`.
   */
  FxNnwMJAP?: string;
  onIxZEqDbFQChange?: string;
  /** Additional properties */
  [key: string]: unknown;
}
