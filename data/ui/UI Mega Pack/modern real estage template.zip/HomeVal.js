var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;
var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// http-url:https://framerusercontent.com/modules/bK4qncBB0qRyBoPUJhQl/jmLaZqhejmdJrnOLfS0W/I64_s8c35.js
import { jsx as _jsx5, jsxs as _jsxs3, Fragment as _Fragment } from "react/jsx-runtime";
import { addFonts as addFonts2, addPropertyControls as addPropertyControls4, ComponentViewportProvider, ControlType as ControlType4, cx as cx3, FormContainer, FormPlainTextInput, forwardLoader, getFonts, RichText as RichText2, SmartComponentScopedContainer, useActiveVariantCallback as useActiveVariantCallback2, useComponentViewport as useComponentViewport2, useLocaleInfo as useLocaleInfo2, useVariantState as useVariantState2, withCodeBoundaryForOverrides, withCSS as withCSS3, withMappedReactProps } from "./_framer-runtime.js";
import { LayoutGroup as LayoutGroup2, motion as motion3, MotionConfigContext as MotionConfigContext2 } from "framer-motion";
import * as React3 from "react";
import { useRef as useRef3 } from "react";

// http-url:https://framerusercontent.com/modules/Si0gkYWdcu5npPGMdfyG/RH4eSXKfeSCCSPorqNB8/iuMFzbzYc.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = `url('data:image/svg+xml,<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 5.59 10.58 L 1.42 6.41 L 0 7.82 L 5.59 13.41 L 17.59 1.41 L 16.18 0 Z" fill="var(--esondr, rgb(0,0,0))" height="13.409979999999997px" id="KG12ReyXf" transform="translate(3.205 5.295)" width="17.590040000000002px"/></svg>') alpha no-repeat center / auto var(--framer-icon-mask-mode, add), var(--framer-icon-mask, none)`;
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(motion.div, { ...rest, layoutId, ref }) : /* @__PURE__ */ _jsx("div", { ...rest, ref });
});
var getProps = ({ fill, height, id, width, ...props }) => {
  return { ...props, K5AAorpEW: fill ?? props.K5AAorpEW ?? "rgb(0, 0, 0)" };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, K5AAorpEW, ...restProps } = getProps(props);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-bVPUk", className), layoutId, ref, style: { "--esondr": K5AAorpEW, ...style } });
});
var css = [`.framer-bVPUk { -webkit-mask: ${mask}; aspect-ratio: 1; background-color: var(--esondr); mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-bVPUk");
Icon.displayName = "Check";
var iuMFzbzYc_default = Icon;
addPropertyControls(Icon, { K5AAorpEW: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Fill", type: ControlType.Color } });

// http-url:https://framerusercontent.com/modules/UYLc0N4ajAOUkmxdZ6wx/9Csll1M5vAa62o9fpQFF/PropertyMap.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2 } from "./_framer-runtime.js";
function PropertyMap({ address }) {
  if (!address) {
    return /* @__PURE__ */ _jsxs("div", { style: { width: "100%", height: "100%", background: "#1a1a1a", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12 }, children: [/* @__PURE__ */ _jsx2("svg", { width: "32", height: "32", viewBox: "0 0 24 24", fill: "none", children: /* @__PURE__ */ _jsx2("path", { d: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z", fill: "#444" }) }), /* @__PURE__ */ _jsx2("span", { style: { color: "#555", fontSize: 12, letterSpacing: "0.1em", textTransform: "uppercase", fontFamily: "inherit" }, children: "Enter an address to preview" })] });
  }
  const src = `https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed`;
  return /* @__PURE__ */ _jsx2("iframe", { src, width: "100%", height: "100%", style: { border: "none", display: "block" }, loading: "lazy", referrerPolicy: "no-referrer-when-downgrade" });
}
addPropertyControls2(PropertyMap, { address: { type: ControlType2.String, title: "Address", defaultValue: "" } });

// http-url:https://framerusercontent.com/modules/ku5Qn8mdCLTK4S4iNHEI/3ern707nTijmw9Y01alr/Valuation.js
import { jsx as _jsx3 } from "react/jsx-runtime";
import { forwardRef as forwardRef3, useEffect as useEffect2, useRef } from "react";

// http-url:https://framerusercontent.com/modules/vj7bFUjvEQFgEzNBkdoG/vf3CKm378wlVcBk7IhSU/createStore.js
import { useState, useEffect } from "react";
import { Data, useObserveData } from "./_framer-runtime.js";
function createStore(state1) {
  const dataStore = Data({ state: Object.freeze({ ...state1 }) });
  const setDataStore = (newState) => {
    if (typeof newState === "function") {
      newState = newState(dataStore.state);
    }
    dataStore.state = Object.freeze({ ...dataStore.state, ...newState });
  };
  let storeState = typeof state1 === "object" ? Object.freeze({ ...state1 }) : state1;
  const storeSetters = /* @__PURE__ */ new Set();
  const setStoreState = (newState) => {
    if (typeof newState === "function") {
      newState = newState(storeState);
    }
    storeState = typeof newState === "object" ? Object.freeze({ ...storeState, ...newState }) : newState;
    storeSetters.forEach((setter) => setter(storeState));
  };
  function useStore2() {
    const [state, setState] = useState(storeState);
    useEffect(() => {
      storeSetters.add(setState);
      return () => storeSetters.delete(setState);
    }, []);
    if (useObserveData() === true) {
      useObserveData();
      return [dataStore.state, setDataStore];
    } else {
      return [state, setStoreState];
    }
  }
  return useStore2;
}

// http-url:https://framerusercontent.com/modules/ku5Qn8mdCLTK4S4iNHEI/3ern707nTijmw9Y01alr/Valuation.js
var useStore = createStore({ address: "", firstName: "", lastName: "", phone: "", email: "", currentStep: 1 });
var Step1Frame = (Component4) => {
  return /* @__PURE__ */ forwardRef3((props, ref) => {
    const [store] = useStore();
    return /* @__PURE__ */ _jsx3(Component4, { ref, ...props, visible: store.currentStep === 1 });
  });
};
var Step2Frame = (Component4) => {
  return /* @__PURE__ */ forwardRef3((props, ref) => {
    const [store] = useStore();
    return /* @__PURE__ */ _jsx3(Component4, { ref, ...props, visible: store.currentStep === 2 });
  });
};
var Step3Frame = (Component4) => {
  return /* @__PURE__ */ forwardRef3((props, ref) => {
    const [store] = useStore();
    return /* @__PURE__ */ _jsx3(Component4, { ref, ...props, visible: store.currentStep === 3 });
  });
};
var AddressInput = (Component4) => {
  return /* @__PURE__ */ forwardRef3((props, ref) => {
    const [store, setStore] = useStore();
    return /* @__PURE__ */ _jsx3(Component4, { ref, ...props, value: store.address, onChange: (e) => {
      const val = typeof e === "string" ? e : e?.target?.value ?? "";
      setStore({ address: val });
    } });
  });
};
var ContinueButton = (Component4) => {
  return /* @__PURE__ */ forwardRef3((props, ref) => {
    const [store, setStore] = useStore();
    const hasAddress = store.address.trim().length > 3;
    return /* @__PURE__ */ _jsx3(Component4, { ref, ...props, onTap: () => {
      if (hasAddress)
        setStore({ currentStep: 2 });
    }, style: { ...props.style, pointerEvents: hasAddress ? "auto" : "none" } });
  });
};
var Map = (Component4) => {
  return /* @__PURE__ */ forwardRef3((props, ref) => {
    const [store] = useStore();
    return /* @__PURE__ */ _jsx3(Component4, { ref, ...props, address: store.address });
  });
};
var FirstNameInput = (Component4) => {
  return /* @__PURE__ */ forwardRef3((props, ref) => {
    const [store, setStore] = useStore();
    return /* @__PURE__ */ _jsx3(Component4, { ref, ...props, value: store.firstName, onChange: (e) => {
      const val = typeof e === "string" ? e : e?.target?.value ?? "";
      setStore({ firstName: val });
    } });
  });
};
var LastNameInput = (Component4) => {
  return /* @__PURE__ */ forwardRef3((props, ref) => {
    const [store, setStore] = useStore();
    return /* @__PURE__ */ _jsx3(Component4, { ref, ...props, value: store.lastName, onChange: (e) => {
      const val = typeof e === "string" ? e : e?.target?.value ?? "";
      setStore({ lastName: val });
    } });
  });
};
var EmailInput = (Component4) => {
  return /* @__PURE__ */ forwardRef3((props, ref) => {
    const [store, setStore] = useStore();
    return /* @__PURE__ */ _jsx3(Component4, { ref, ...props, value: store.email, onChange: (e) => {
      const val = typeof e === "string" ? e : e?.target?.value ?? "";
      setStore({ email: val });
    } });
  });
};
var SubmitButton = (Component4) => {
  return /* @__PURE__ */ forwardRef3((props, ref) => {
    const [store, setStore] = useStore();
    const isValid = store.firstName.trim().length > 0 && store.lastName.trim().length > 0 && store.email.trim().length > 0 && store.address.trim().length > 0;
    return /* @__PURE__ */ _jsx3(Component4, { ref, ...props, style: { ...props.style, pointerEvents: isValid ? "auto" : "none", opacity: isValid ? 1 : 0.4 } });
  });
};

// http-url:https://framerusercontent.com/modules/CB2h0j0DK39MQot7dAPF/cLJbMFBZaRC1zbgOeZu3/PfdXbpeBn.js
var PfdXbpeBn_exports = {};
__export(PfdXbpeBn_exports, {
  __FramerMetadata__: () => __FramerMetadata__,
  default: () => PfdXbpeBn_default
});
import { jsx as _jsx4, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ControlType as ControlType3, cx as cx2, RichText, useActiveVariantCallback, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2, withFX } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef as useRef2 } from "react";
var MotionDivWithFX = withFX(motion2.div);
var enabledGestures = { UI1b8U1QA: { hover: true, pressed: true } };
var cycleOrder = ["UI1b8U1QA", "kS49_Ttnj", "fYwrIdPHL", "ODixMg2At", "R9E2lVCwa"];
var serializationHash = "framer-F6W7s";
var variantClassNames = { fYwrIdPHL: "framer-v-15fdbpl", kS49_Ttnj: "framer-v-3w90ow", ODixMg2At: "framer-v-1rfflwk", R9E2lVCwa: "framer-v-1nh6kwb", UI1b8U1QA: "framer-v-1n0klwf" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var ndsT4W1CCTxRF350hk = void 0;
var transition1 = { delay: 0, duration: 0.2, ease: [0.44, 0, 0.56, 1], type: "tween" };
var transition2 = { delay: 0, duration: 1, ease: [0, 0, 1, 1], type: "tween" };
var animation = { opacity: 1, rotate: 360, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 0 };
var transformTemplate1 = (_, t) => `translateX(-50%) ${t}`;
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx4(MotionConfigContext.Provider, { value: contextValue, children });
};
var humanReadableVariantMap = { Default: "UI1b8U1QA", Disabled: "fYwrIdPHL", Error: "R9E2lVCwa", Loading: "kS49_Ttnj", Success: "ODixMg2At" };
var Variants = motion2.create(React2.Fragment);
var getProps2 = ({ click, fill, height, id, width, ...props }) => {
  return { ...props, KMx3laFLx: fill ?? props.KMx3laFLx ?? "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", mLMMExIm4: click ?? props.mLMMExIm4, variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "UI1b8U1QA" };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, mLMMExIm4, KMx3laFLx, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "UI1b8U1QA", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback(baseVariant);
  const onTap1an3u5 = activeVariantCallback(async (...args) => {
    setGestureState({ isPressed: false });
    if (mLMMExIm4) {
      const res = await mLMMExIm4(...args);
      if (res === false)
        return false;
    }
  });
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (baseVariant === "kS49_Ttnj")
      return false;
    return true;
  };
  const isDisplayed1 = () => {
    if (baseVariant === "kS49_Ttnj")
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx4(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx4(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx4(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs2(motion2.button, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-1n0klwf", className, classNames), "data-framer-name": "Default", "data-highlight": true, "data-reset": "button", layoutDependency, layoutId: "homeval__UI1b8U1QA", onTap: onTap1an3u5, ref: refBinding, style: { backgroundColor: KMx3laFLx, opacity: 1, ...style }, variants: { "UI1b8U1QA-hover": { backgroundColor: "rgba(51, 51, 51, 0.85)", opacity: 1 }, "UI1b8U1QA-pressed": { backgroundColor: "rgb(51, 51, 51)", opacity: 1 }, fYwrIdPHL: { opacity: 0.5 }, ODixMg2At: { opacity: 1 }, R9E2lVCwa: { backgroundColor: "rgba(255, 34, 68, 0.15)", opacity: 1 } }, ...addPropertyOverrides({ "UI1b8U1QA-hover": { "data-framer-name": void 0 }, "UI1b8U1QA-pressed": { "data-framer-name": void 0 }, fYwrIdPHL: { "data-framer-name": "Disabled" }, kS49_Ttnj: { "data-framer-name": "Loading" }, ODixMg2At: { "data-framer-name": "Success" }, R9E2lVCwa: { "data-framer-name": "Error" } }, baseVariant, gestureVariant), children: [isDisplayed() && /* @__PURE__ */ _jsx4(RichText, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx4(React2.Fragment, { children: /* @__PURE__ */ _jsx4(motion2.p, { dir: "auto", style: { "--framer-line-height": "1em", "--framer-text-color": "var(--extracted-r6o4lv, var(--variable-reference-ndsT4W1CC-TxRF350hk))" }, children: "Request Valuation" }) }), className: "framer-1q5hni6", fonts: ["Inter"], layoutDependency, layoutId: "homeval__VzcHLTFOo", style: { "--extracted-r6o4lv": "var(--variable-reference-ndsT4W1CC-TxRF350hk)", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline", "--variable-reference-ndsT4W1CC-TxRF350hk": ndsT4W1CCTxRF350hk }, variants: { ODixMg2At: { "--extracted-r6o4lv": "rgb(255, 255, 255)" }, R9E2lVCwa: { "--extracted-r6o4lv": "rgb(255, 34, 68)" } }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides({ ODixMg2At: { children: /* @__PURE__ */ _jsx4(React2.Fragment, { children: /* @__PURE__ */ _jsx4(motion2.p, { style: { "--font-selector": "SW50ZXItU2VtaUJvbGQ=", "--framer-font-family": '"Inter", "Inter Placeholder", sans-serif', "--framer-font-size": "14px", "--framer-font-weight": "600", "--framer-text-color": "var(--extracted-r6o4lv, rgb(255, 255, 255))" }, children: "Thank you" }) }), fonts: ["Inter-SemiBold"] }, R9E2lVCwa: { children: /* @__PURE__ */ _jsx4(React2.Fragment, { children: /* @__PURE__ */ _jsx4(motion2.p, { style: { "--font-selector": "SW50ZXItU2VtaUJvbGQ=", "--framer-font-family": '"Inter", "Inter Placeholder", sans-serif', "--framer-font-size": "14px", "--framer-font-weight": "600", "--framer-text-color": "var(--extracted-r6o4lv, rgb(255, 34, 68))" }, children: "Something went wrong" }) }), fonts: ["Inter-SemiBold"] } }, baseVariant, gestureVariant) }), isDisplayed1() && /* @__PURE__ */ _jsx4(motion2.div, { className: "framer-12ky4ce", "data-framer-name": "Spinner", layoutDependency, layoutId: "homeval__qzYjcwxRq", style: { mask: "url('https://framerusercontent.com/images/pGiXYozQ3mE4cilNOItfe2L2fUA.svg?width=20&height=20') alpha no-repeat center / cover add", WebkitMask: "url('https://framerusercontent.com/images/pGiXYozQ3mE4cilNOItfe2L2fUA.svg?width=20&height=20') alpha no-repeat center / cover add" }, children: /* @__PURE__ */ _jsx4(MotionDivWithFX, { __framer__loop: animation, __framer__loopEffectEnabled: true, __framer__loopRepeatDelay: 0, __framer__loopRepeatType: "loop", __framer__loopTransition: transition2, __perspectiveFX: false, __smartComponentFX: true, __targetOpacity: 1, className: "framer-kbapvf", "data-framer-name": "Conic", layoutDependency, layoutId: "homeval__Ts7fc8gPY", style: { background: "conic-gradient(from 180deg at 50% 50%, rgb(68, 204, 255) 0deg, rgb(68, 204, 255) 360deg)", backgroundColor: "rgb(68, 204, 255)", mask: "none", WebkitMask: "none" }, variants: { kS49_Ttnj: { background: "conic-gradient(from 0deg at 50% 50%, rgba(255, 255, 255, 0) 7.208614864864882deg, rgb(255, 255, 255) 342deg)", backgroundColor: "rgba(0, 0, 0, 0)", mask: "url('https://framerusercontent.com/images/pGiXYozQ3mE4cilNOItfe2L2fUA.svg?width=20&height=20') alpha no-repeat center / cover add", WebkitMask: "url('https://framerusercontent.com/images/pGiXYozQ3mE4cilNOItfe2L2fUA.svg?width=20&height=20') alpha no-repeat center / cover add" } }, children: /* @__PURE__ */ _jsx4(motion2.div, { className: "framer-1p9kuta", "data-framer-name": "Rounding", layoutDependency, layoutId: "homeval__KRqxdty3I", style: { backgroundColor: "rgb(255, 255, 255)", borderBottomLeftRadius: 1, borderBottomRightRadius: 1, borderTopLeftRadius: 1, borderTopRightRadius: 1 }, transformTemplate: transformTemplate1 }) }) })] }) }) }) });
});
var css2 = [".framer-F6W7s.framer-1z01vn6, .framer-F6W7s .framer-1z01vn6 { display: block; }", ".framer-F6W7s.framer-1n0klwf { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: row; flex-wrap: nowrap; gap: 0px; height: auto; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-F6W7s .framer-1q5hni6 { flex: none; height: auto; position: relative; white-space: pre; width: auto; }", ".framer-F6W7s .framer-12ky4ce { aspect-ratio: 1 / 1; flex: none; gap: 10px; height: auto; overflow: hidden; position: relative; width: 20px; }", ".framer-F6W7s .framer-kbapvf { bottom: 0px; flex: none; left: 0px; overflow: visible; position: absolute; right: 0px; top: 0px; }", ".framer-F6W7s .framer-1p9kuta { aspect-ratio: 1 / 1; flex: none; height: auto; left: 50%; overflow: visible; position: absolute; top: 0px; width: 2px; }", ".framer-F6W7s.framer-v-3w90ow .framer-kbapvf { overflow: hidden; }"];
var FramerPfdXbpeBn = withCSS2(Component2, css2, "framer-F6W7s");
var PfdXbpeBn_default = FramerPfdXbpeBn;
FramerPfdXbpeBn.displayName = "Button 2";
FramerPfdXbpeBn.defaultProps = { height: 46, width: 240 };
addPropertyControls3(FramerPfdXbpeBn, { variant: { options: ["UI1b8U1QA", "kS49_Ttnj", "fYwrIdPHL", "ODixMg2At", "R9E2lVCwa"], optionTitles: ["Default", "Loading", "Disabled", "Success", "Error"], title: "Variant", type: ControlType3.Enum }, mLMMExIm4: { title: "Click", type: ControlType3.EventHandler }, KMx3laFLx: { defaultValue: 'var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226)) /* {"name":"White"} */', title: "Fill", type: ControlType3.Color } });
addFonts(FramerPfdXbpeBn, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/hyOgCu0Xnghbimh0pE8QTvtt2AU.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/NeGmSOXrPBfEFIy5YZeHq17LEDA.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/oYaAX5himiTPYuN8vLWnqBbfD2s.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/lEJLP4R0yuCaMCjSXYHtJw72M.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/cRJyLNuTJR5jbyKzGi33wU9cqIQ.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/yDtI2UI8XcEg1W2je9XPN3Noo.woff2", weight: "600" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/A0Wcc7NgXMjUuFdquHDrIZpzZw0.woff2", weight: "600" }] }], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerPfdXbpeBn", "slots": [], "annotations": { "framerColorSyntax": "true", "framerIntrinsicHeight": "46", "framerAutoSizeImages": "true", "framerComponentViewportWidth": "true", "framerImmutableVariables": "true", "framerIntrinsicWidth": "240", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","fixed"]},"kS49_Ttnj":{"layout":["fixed","fixed"]},"fYwrIdPHL":{"layout":["fixed","fixed"]},"ODixMg2At":{"layout":["fixed","fixed"]},"R9E2lVCwa":{"layout":["fixed","fixed"]},"ma6ZzLPxZ":{"layout":["fixed","fixed"]},"NzSrRUymH":{"layout":["fixed","fixed"]}}}', "framerContractVersion": "1", "framerDisplayContentsDiv": "false", "framerVariables": '{"mLMMExIm4":"click","KMx3laFLx":"fill"}' } }, "__FramerMetadata__": { "type": "variable" } } };

// http-url:https://framerusercontent.com/modules/bK4qncBB0qRyBoPUJhQl/jmLaZqhejmdJrnOLfS0W/I64_s8c35.js
var MotionLabelAddressInputvv57k = withCodeBoundaryForOverrides(motion3.label, { nodeId: "bFDwKc4C4", override: AddressInput, scopeId: "I64_s8c35" });
var Button2Fonts = getFonts(PfdXbpeBn_default);
var Button2ContinueButton1pt6se9WithMappedReactPropsk9ef4a = withMappedReactProps(withCodeBoundaryForOverrides(PfdXbpeBn_default, { nodeId: "zinxkR5jW", override: ContinueButton, scopeId: "I64_s8c35" }), PfdXbpeBn_exports);
var FormContainerStep1Frame1a2l0vd = withCodeBoundaryForOverrides(FormContainer, { nodeId: "fSt7mlsRO", override: Step1Frame, scopeId: "I64_s8c35" });
var PropertyMapFonts = getFonts(PropertyMap);
var PropertyMapMap11m5l27k = withCodeBoundaryForOverrides(PropertyMap, { nodeId: "cRDiCslcH", override: Map, scopeId: "I64_s8c35" });
var FormPlainTextInputFirstNameInput104f4n1 = withCodeBoundaryForOverrides(FormPlainTextInput, { nodeId: "jcrzJBk2o", override: FirstNameInput, scopeId: "I64_s8c35" });
var FormPlainTextInputLastNameInputy0375a = withCodeBoundaryForOverrides(FormPlainTextInput, { nodeId: "u0NBl9wHF", override: LastNameInput, scopeId: "I64_s8c35" });
var FormPlainTextInputAddressInput11gezy6 = withCodeBoundaryForOverrides(FormPlainTextInput, { nodeId: "RVGXcSRXI", override: AddressInput, scopeId: "I64_s8c35" });
var FormPlainTextInputEmailInput13tiwtp = withCodeBoundaryForOverrides(FormPlainTextInput, { nodeId: "h8B4vGEkS", override: EmailInput, scopeId: "I64_s8c35" });
var Button2SubmitButtonddb234WithMappedReactPropsk9ef4a = withMappedReactProps(withCodeBoundaryForOverrides(PfdXbpeBn_default, { nodeId: "GHNrWM394", override: SubmitButton, scopeId: "I64_s8c35" }), PfdXbpeBn_exports);
var MotionDivStep2Frametw3aeb = withCodeBoundaryForOverrides(motion3.div, { nodeId: "kYG3n6u5D", override: Step2Frame, scopeId: "I64_s8c35" });
var CheckFonts = getFonts(iuMFzbzYc_default);
var MotionDivStep3Frame7el2bg = withCodeBoundaryForOverrides(motion3.div, { nodeId: "XyZar00Lv", override: Step3Frame, scopeId: "I64_s8c35" });
var cycleOrder2 = ["rwXtPmQ8U", "s4T2S26fp", "soGHMUZ7i", "GPLjmy72J", "OjuDzpVbd", "lHuqH09c7"];
var serializationHash2 = "framer-lPh30";
var variantClassNames2 = { GPLjmy72J: "framer-v-11b6awx", lHuqH09c7: "framer-v-mgywu6", OjuDzpVbd: "framer-v-gwjldp", rwXtPmQ8U: "framer-v-ecqd7q", s4T2S26fp: "framer-v-tisrr", soGHMUZ7i: "framer-v-1buzbba" };
function addPropertyOverrides2(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition12 = { bounce: 0.2, delay: 0, duration: 0.4, type: "spring" };
var matchVariant = (...args) => {
  for (const arg of args) {
    if (arg && typeof arg === "string")
      return arg;
  }
  return void 0;
};
var formVariants = (form, variants, currentVariant) => {
  switch (form.state) {
    case "success":
      return variants.success ?? currentVariant;
    case "pending":
      return variants.pending ?? currentVariant;
    case "error":
      return variants.error ?? currentVariant;
    case "incomplete":
      return variants.incomplete ?? currentVariant;
    default:
      return currentVariant;
  }
};
var animation2 = { opacity: 1e-3, rotate: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 10 };
var transition22 = { bounce: 0, delay: 0.075, duration: 0.4, type: "spring" };
var textEffect = { effect: animation2, repeat: false, startDelay: 0.1, threshold: 0.5, tokenization: "word", transition: transition22, trigger: "onInView", type: "appear" };
var Transition2 = ({ value, children }) => {
  const config = React3.useContext(MotionConfigContext2);
  const transition = value ?? config.transition;
  const contextValue = React3.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx5(MotionConfigContext2.Provider, { value: contextValue, children });
};
var humanReadableVariantMap2 = { "Desktop Step 1 ": "rwXtPmQ8U", "Desktop Step 2": "s4T2S26fp", "Desktop Step 3": "soGHMUZ7i", "Mobile Step 1 ": "GPLjmy72J", "Mobile Step 2": "OjuDzpVbd", "Mobile Step 3": "lHuqH09c7" };
var Variants2 = motion3.create(React3.Fragment);
var getProps3 = ({ height, id, width, ...props }) => {
  return { ...props, variant: humanReadableVariantMap2[props.variant] ?? props.variant ?? "rwXtPmQ8U" };
};
var createLayoutDependency2 = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component3 = /* @__PURE__ */ React3.forwardRef(function(props, ref) {
  const fallbackRef = useRef3(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React3.useId();
  const { activeLocale, setLocale } = useLocaleInfo2();
  const componentViewport = useComponentViewport2();
  const { style, className, layoutId, variant, ...restProps } = getProps3(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState2({ cycleOrder: cycleOrder2, defaultVariant: "rwXtPmQ8U", ref: refBinding, variant, variantClassNames: variantClassNames2 });
  const layoutDependency = createLayoutDependency2(props, variants);
  const { activeVariantCallback, delay } = useActiveVariantCallback2(baseVariant);
  const mLMMExIm41ykdncv = activeVariantCallback(async (...args) => {
    setVariant("s4T2S26fp");
  });
  const mLMMExIm413zokqg = activeVariantCallback(async (...args) => {
    setVariant("OjuDzpVbd");
  });
  const mLMMExIm41tvsjqn = activeVariantCallback(async (...args) => {
    setVariant("soGHMUZ7i");
  });
  const mLMMExIm426l9m6 = activeVariantCallback(async (...args) => {
    setVariant("lHuqH09c7");
  });
  const sharedStyleClassNames = [];
  const scopingClassNames = cx3(serializationHash2, ...sharedStyleClassNames);
  const isDisplayed = () => {
    if (["s4T2S26fp", "soGHMUZ7i", "OjuDzpVbd", "lHuqH09c7"].includes(baseVariant))
      return false;
    return true;
  };
  const isDisplayed1 = () => {
    if (["s4T2S26fp", "OjuDzpVbd"].includes(baseVariant))
      return true;
    return false;
  };
  const isDisplayed2 = () => {
    if (["soGHMUZ7i", "lHuqH09c7"].includes(baseVariant))
      return true;
    return false;
  };
  return /* @__PURE__ */ _jsx5(LayoutGroup2, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx5(Variants2, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx5(Transition2, { value: transition12, children: /* @__PURE__ */ _jsxs3(motion3.div, { ...restProps, ...gestureHandlers, className: cx3(scopingClassNames, "framer-ecqd7q", className, classNames), "data-framer-name": "Desktop Step 1 ", layoutDependency, layoutId: "homeval__rwXtPmQ8U", ref: refBinding, style: { ...style }, ...addPropertyOverrides2({ GPLjmy72J: { "data-framer-name": "Mobile Step 1 " }, lHuqH09c7: { "data-framer-name": "Mobile Step 3" }, OjuDzpVbd: { "data-framer-name": "Mobile Step 2" }, s4T2S26fp: { "data-framer-name": "Desktop Step 2" }, soGHMUZ7i: { "data-framer-name": "Desktop Step 3" } }, baseVariant, gestureVariant), children: [isDisplayed() && /* @__PURE__ */ _jsx5(FormContainerStep1Frame1a2l0vd, { className: "framer-1a2l0vd", "data-framer-name": "step 1 ", layoutDependency, layoutId: "homeval__fSt7mlsRO", nodeId: "fSt7mlsRO", children: (formState) => /* @__PURE__ */ _jsxs3(_Fragment, { children: [/* @__PURE__ */ _jsx5(MotionLabelAddressInputvv57k, { className: "framer-vv57k", layoutDependency, layoutId: "homeval__bFDwKc4C4", style: { backgroundColor: "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))" }, children: /* @__PURE__ */ _jsx5(FormPlainTextInput, { className: "framer-o1jngt", inputName: "Adress", layoutDependency, layoutId: "homeval__Rl45E2UN_", placeholder: "Enter your address", required: true, style: { "--framer-input-font-color": "rgb(153, 153, 153)", "--framer-input-icon-mask-image": "none", "--framer-input-placeholder-color": "rgb(153, 153, 153)" }, type: "text" }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider, { height: 70, width: "154px", y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 70) - 0 - 70) / 2 + 0 + 0) + 0, ...addPropertyOverrides2({ GPLjmy72J: { y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 200) - 0 - 70) / 2 + 0 + 0) + 0 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer, { className: "framer-1pt6se9-container", layoutDependency, layoutId: "homeval__zinxkR5jW-container", nodeId: "zinxkR5jW", rendersWithMotion: true, scopeId: "I64_s8c35", children: /* @__PURE__ */ _jsx5(Button2ContinueButton1pt6se9WithMappedReactPropsk9ef4a, { height: "100%", id: "zinxkR5jW", KMx3laFLx: "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))", layoutId: "homeval__zinxkR5jW", mLMMExIm4: mLMMExIm41ykdncv, style: { height: "100%", width: "100%" }, type: "submit", variant: formVariants(formState, { pending: "kS49_Ttnj", success: "ODixMg2At" }, matchVariant("UI1b8U1QA")), width: "100%", ...addPropertyOverrides2({ GPLjmy72J: { mLMMExIm4: mLMMExIm413zokqg } }, baseVariant, gestureVariant) }) }) })] }) }), isDisplayed1() && /* @__PURE__ */ _jsx5(MotionDivStep2Frametw3aeb, { className: "framer-tw3aeb", "data-framer-name": "step 2 ", layoutDependency, layoutId: "homeval__kYG3n6u5D", children: /* @__PURE__ */ _jsx5(motion3.div, { className: "framer-r423gp", layoutDependency, layoutId: "homeval__PuFAiDOvI", style: { backgroundColor: "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))" }, children: /* @__PURE__ */ _jsxs3(motion3.div, { className: "framer-1xwmpui", layoutDependency, layoutId: "homeval__j7xcyfp5E", children: [/* @__PURE__ */ _jsx5(motion3.div, { className: "framer-18bk8fj", layoutDependency, layoutId: "homeval__dMULeJwk0", children: /* @__PURE__ */ _jsx5(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer, { className: "framer-1m5l27k-container", isAuthoredByUser: true, layoutDependency, layoutId: "homeval__cRDiCslcH-container", nodeId: "cRDiCslcH", rendersWithMotion: true, scopeId: "I64_s8c35", children: /* @__PURE__ */ _jsx5(PropertyMapMap11m5l27k, { address: "", height: "100%", id: "cRDiCslcH", layoutId: "homeval__cRDiCslcH", style: { height: "100%", width: "100%" }, width: "100%" }) }) }) }), /* @__PURE__ */ _jsxs3(motion3.div, { className: "framer-11ccoui", layoutDependency, layoutId: "homeval__h5VmCH9ba", children: [/* @__PURE__ */ _jsx5(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx5(React3.Fragment, { children: /* @__PURE__ */ _jsxs3(motion3.h2, { dir: "auto", style: { "--font-selector": "R0Y7Q29ybW9yYW50IEdhcmFtb25kLTUwMA==", "--framer-font-family": '"Cormorant Garamond", "Cormorant Garamond Placeholder", serif', "--framer-font-size": "34px", "--framer-font-weight": "500", "--framer-line-height": "1em", "--framer-text-alignment": "justify", "--framer-text-color": "var(--extracted-1of0zx5, var(--token-8d8814ec-b94d-4475-8fc9-66476d72ef2c, rgb(33, 33, 33)))" }, children: ["You're one step away from knowing", /* @__PURE__ */ _jsx5(motion3.br, {}), "the value of your property."] }) }), className: "framer-1h7gh35", effect: textEffect, fonts: ["GF;Cormorant Garamond-500"], layoutDependency, layoutId: "homeval__e2QedVGiI", style: { "--extracted-1of0zx5": "var(--token-8d8814ec-b94d-4475-8fc9-66476d72ef2c, rgb(33, 33, 33))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true, ...addPropertyOverrides2({ OjuDzpVbd: { children: /* @__PURE__ */ _jsx5(React3.Fragment, { children: /* @__PURE__ */ _jsx5(motion3.h2, { dir: "auto", style: { "--font-selector": "R0Y7Q29ybW9yYW50IEdhcmFtb25kLTUwMA==", "--framer-font-family": '"Cormorant Garamond", "Cormorant Garamond Placeholder", serif', "--framer-font-size": "34px", "--framer-font-weight": "500", "--framer-line-height": "1em", "--framer-text-alignment": "justify", "--framer-text-color": "var(--extracted-1of0zx5, var(--token-8d8814ec-b94d-4475-8fc9-66476d72ef2c, rgb(33, 33, 33)))" }, children: "You're one step away from knowing the value of your property." }) }) } }, baseVariant, gestureVariant) }), /* @__PURE__ */ _jsx5(FormContainer, { action: "https://api.framer.com/forms/v1/forms/afd3970e-90c5-4387-a801-173c4c9af20d/submit", className: "framer-17t1v42", layoutDependency, layoutId: "homeval__wa2mMiFb8", nodeId: "wa2mMiFb8", children: (formState) => /* @__PURE__ */ _jsxs3(_Fragment, { children: [/* @__PURE__ */ _jsx5(motion3.label, { className: "framer-195jlnz", layoutDependency, layoutId: "homeval__IoZix9aBa", children: /* @__PURE__ */ _jsx5(FormPlainTextInputFirstNameInput104f4n1, { className: "framer-104f4n1", inputName: "Name", layoutDependency, layoutId: "homeval__jcrzJBk2o", placeholder: "Jane Smith", required: true, style: { "--framer-input-border-bottom-width": "1px", "--framer-input-border-color": "rgb(201, 201, 201)", "--framer-input-border-left-width": "0px", "--framer-input-border-right-width": "0px", "--framer-input-border-style": "solid", "--framer-input-border-top-width": "0px", "--framer-input-font-color": "rgb(153, 153, 153)", "--framer-input-icon-mask-image": "none", "--framer-input-placeholder-color": "rgb(153, 153, 153)" }, type: "text", ...addPropertyOverrides2({ s4T2S26fp: { placeholder: "Jane " } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx5(motion3.label, { className: "framer-t4mwom", layoutDependency, layoutId: "homeval__bjhnI9UFV", children: /* @__PURE__ */ _jsx5(FormPlainTextInputLastNameInputy0375a, { className: "framer-y0375a", inputName: "Name", layoutDependency, layoutId: "homeval__u0NBl9wHF", placeholder: "Last Name", required: true, style: { "--framer-input-border-bottom-width": "1px", "--framer-input-border-color": "rgb(201, 201, 201)", "--framer-input-border-left-width": "0px", "--framer-input-border-right-width": "0px", "--framer-input-border-style": "solid", "--framer-input-border-top-width": "0px", "--framer-input-font-color": "rgb(153, 153, 153)", "--framer-input-icon-mask-image": "none", "--framer-input-placeholder-color": "rgb(153, 153, 153)" }, type: "text", ...addPropertyOverrides2({ s4T2S26fp: { placeholder: "Smith" } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx5(motion3.label, { className: "framer-i22hfs", layoutDependency, layoutId: "homeval__E99CQVPnK", children: /* @__PURE__ */ _jsx5(FormPlainTextInputAddressInput11gezy6, { className: "framer-11gezy6", inputName: "Adress", layoutDependency, layoutId: "homeval__RVGXcSRXI", placeholder: "Adress", required: true, style: { "--framer-input-border-bottom-width": "1px", "--framer-input-border-color": "rgb(201, 201, 201)", "--framer-input-border-left-width": "0px", "--framer-input-border-right-width": "0px", "--framer-input-border-style": "solid", "--framer-input-border-top-width": "0px", "--framer-input-font-color": "rgb(153, 153, 153)", "--framer-input-icon-mask-image": "none", "--framer-input-placeholder-color": "rgb(153, 153, 153)" }, type: "text" }) }), /* @__PURE__ */ _jsx5(motion3.label, { className: "framer-jz3bda", layoutDependency, layoutId: "homeval__NY1judHHz", children: /* @__PURE__ */ _jsx5(FormPlainTextInputEmailInput13tiwtp, { className: "framer-13tiwtp", inputName: "Email", layoutDependency, layoutId: "homeval__h8B4vGEkS", placeholder: "jane@framer.com", required: true, style: { "--framer-input-border-bottom-width": "1px", "--framer-input-border-color": "rgb(201, 201, 201)", "--framer-input-border-left-width": "0px", "--framer-input-border-right-width": "0px", "--framer-input-border-style": "solid", "--framer-input-border-top-width": "0px", "--framer-input-font-color": "rgb(153, 153, 153)", "--framer-input-icon-mask-image": "none", "--framer-input-placeholder-color": "rgb(153, 153, 153)" }, type: "email", ...addPropertyOverrides2({ s4T2S26fp: { placeholder: "jane@terrace.com" } }, baseVariant, gestureVariant) }) }), /* @__PURE__ */ _jsx5(ComponentViewportProvider, { height: 40, ...addPropertyOverrides2({ OjuDzpVbd: { width: `min(min(${componentViewport?.width || "100vw"} - 24px, 550px), 450px)`, y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 200) - 0 - 696) / 2 + 0 + 0) + 0 + 0 + 12 + 0 + 0 + 284 + 0 + 64 + 0 + 284 }, s4T2S26fp: { width: `min(min(max((${componentViewport?.width || "100vw"} - 130px) / 2, 1px), 550px), 450px)`, y: (componentViewport?.y || 0) + 0 + (((componentViewport?.height || 518) - 0 - 484) / 2 + 0 + 0) + 0 + 0 + 48 + 0 + 0 + 0 + 64 + 0 + 284 } }, baseVariant, gestureVariant), children: /* @__PURE__ */ _jsx5(SmartComponentScopedContainer, { className: "framer-ddb234-container", layoutDependency, layoutId: "homeval__GHNrWM394-container", nodeId: "GHNrWM394", rendersWithMotion: true, scopeId: "I64_s8c35", children: /* @__PURE__ */ _jsx5(Button2SubmitButtonddb234WithMappedReactPropsk9ef4a, { height: "100%", id: "GHNrWM394", KMx3laFLx: "var(--token-d5a2af8d-4dd0-46b3-bbb1-1d3d9a348834, rgb(200, 169, 110))", layoutId: "homeval__GHNrWM394", mLMMExIm4: mLMMExIm41tvsjqn, style: { height: "100%", width: "100%" }, type: "submit", variant: formVariants(formState, { pending: "kS49_Ttnj", success: "ODixMg2At" }, matchVariant("UI1b8U1QA")), width: "100%", ...addPropertyOverrides2({ OjuDzpVbd: { mLMMExIm4: mLMMExIm426l9m6 } }, baseVariant, gestureVariant) }) }) })] }) })] })] }) }) }), isDisplayed2() && /* @__PURE__ */ _jsx5(MotionDivStep3Frame7el2bg, { className: "framer-7el2bg", "data-framer-name": "step 3", layoutDependency, layoutId: "homeval__XyZar00Lv", children: /* @__PURE__ */ _jsxs3(motion3.div, { className: "framer-1pk1t00", layoutDependency, layoutId: "homeval__yhLbQcmCd", style: { backgroundColor: "var(--token-3188cdf1-5f90-40f5-a5e8-fab72c86bb59, rgb(239, 235, 226))" }, children: [/* @__PURE__ */ _jsx5(motion3.div, { className: "framer-1sow771", layoutDependency, layoutId: "homeval__FOJeZTx1R", style: { backgroundColor: "rgb(255, 255, 255)", borderBottomLeftRadius: 22, borderBottomRightRadius: 22, borderTopLeftRadius: 22, borderTopRightRadius: 22 }, children: /* @__PURE__ */ _jsx5(iuMFzbzYc_default, { animated: true, className: "framer-1pqso1q", layoutDependency, layoutId: "homeval__Hzg3VS1RQ", style: { "--esondr": "var(--token-d5a2af8d-4dd0-46b3-bbb1-1d3d9a348834, rgb(200, 169, 110))" } }) }), /* @__PURE__ */ _jsx5(RichText2, { __fromCanvasComponent: true, children: /* @__PURE__ */ _jsx5(React3.Fragment, { children: /* @__PURE__ */ _jsx5(motion3.h2, { dir: "auto", style: { "--font-selector": "R0Y7Q29ybW9yYW50IEdhcmFtb25kLTUwMA==", "--framer-font-family": '"Cormorant Garamond", "Cormorant Garamond Placeholder", serif', "--framer-font-size": "34px", "--framer-font-weight": "500", "--framer-line-height": "1em", "--framer-text-alignment": "center", "--framer-text-color": "var(--extracted-1of0zx5, var(--token-8d8814ec-b94d-4475-8fc9-66476d72ef2c, rgb(33, 33, 33)))" }, children: "Your Valuation Request Has Been Received" }) }), className: "framer-ze5qzy", effect: textEffect, fonts: ["GF;Cormorant Garamond-500"], layoutDependency, layoutId: "homeval__FkqfgkvJb", style: { "--extracted-1of0zx5": "var(--token-8d8814ec-b94d-4475-8fc9-66476d72ef2c, rgb(33, 33, 33))", "--framer-link-text-color": "rgb(0, 153, 255)", "--framer-link-text-decoration": "underline" }, verticalAlignment: "top", withExternalLayout: true })] }) })] }) }) }) });
});
var css3 = [".framer-lPh30.framer-jnchsk, .framer-lPh30 .framer-jnchsk { display: block; }", ".framer-lPh30.framer-ecqd7q { align-content: center; align-items: center; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 25px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-lPh30 .framer-1a2l0vd { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 4px; height: min-content; justify-content: flex-start; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-lPh30 .framer-vv57k { align-content: flex-start; align-items: flex-start; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: flex-start; padding: 0px; position: relative; width: 1px; }", '.framer-lPh30 .framer-o1jngt { --framer-input-focused-border-color: #0099ff; --framer-input-focused-border-style: solid; --framer-input-focused-border-width: 1px; --framer-input-font-family: "Inter"; --framer-input-font-letter-spacing: 0em; --framer-input-font-line-height: 1.2em; --framer-input-font-size: 14px; --framer-input-font-weight: 400; --framer-input-padding: 12px 0px 12px 24px; flex: none; height: 70px; position: relative; width: 100%; }', ".framer-lPh30 .framer-1pt6se9-container { align-self: stretch; flex: none; height: auto; position: relative; width: 154px; }", ".framer-lPh30 .framer-tw3aeb, .framer-lPh30 .framer-7el2bg { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 0px; position: relative; width: 100%; }", ".framer-lPh30 .framer-r423gp { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 30px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 48px; position: relative; width: 100%; }", ".framer-lPh30 .framer-1xwmpui { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 34px; height: min-content; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 100%; }", ".framer-lPh30 .framer-18bk8fj { align-content: center; align-items: center; align-self: stretch; display: flex; flex: 1 0 0px; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: auto; justify-content: center; max-width: 650px; overflow: visible; padding: 0px; position: relative; width: 1px; }", ".framer-lPh30 .framer-1m5l27k-container { flex: none; height: 100%; position: relative; width: 100%; }", ".framer-lPh30 .framer-11ccoui { align-content: flex-start; align-items: flex-start; display: flex; flex: 1 0 0px; flex-direction: column; flex-wrap: nowrap; gap: 30px; height: min-content; justify-content: center; max-width: 550px; overflow: visible; padding: 0px; position: relative; width: 1px; }", ".framer-lPh30 .framer-1h7gh35, .framer-lPh30 .framer-ze5qzy { flex: none; height: auto; position: relative; white-space: pre-wrap; width: 100%; word-break: break-word; word-wrap: break-word; z-index: 1; }", ".framer-lPh30 .framer-17t1v42 { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 31px; height: min-content; justify-content: flex-start; max-width: 450px; overflow: hidden; padding: 0px; position: relative; width: 100%; }", ".framer-lPh30 .framer-195jlnz { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: min-content; justify-content: flex-start; padding: 0px; position: relative; width: 100%; }", '.framer-lPh30 .framer-104f4n1, .framer-lPh30 .framer-y0375a, .framer-lPh30 .framer-11gezy6, .framer-lPh30 .framer-13tiwtp { --framer-input-focused-border-color: #0099ff; --framer-input-focused-border-style: solid; --framer-input-focused-border-width: 1px; --framer-input-font-family: "Inter"; --framer-input-font-letter-spacing: 0em; --framer-input-font-line-height: 1.2em; --framer-input-font-size: 14px; --framer-input-font-weight: 400; --framer-input-padding: 12px; flex: none; height: 40px; position: relative; width: 100%; }', ".framer-lPh30 .framer-t4mwom, .framer-lPh30 .framer-i22hfs, .framer-lPh30 .framer-jz3bda { align-content: flex-start; align-items: flex-start; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 10px; height: min-content; justify-content: flex-start; padding: 0px; position: relative; width: 100%; }", ".framer-lPh30 .framer-ddb234-container { flex: none; height: 40px; position: relative; width: 100%; }", ".framer-lPh30 .framer-1pk1t00 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 18px; height: min-content; justify-content: center; overflow: var(--overflow-clip-fallback, clip); padding: 48px; position: relative; width: 100%; }", ".framer-lPh30 .framer-1sow771 { align-content: center; align-items: center; display: flex; flex: none; flex-direction: row; flex-wrap: nowrap; gap: 10px; height: 43px; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 43px; }", ".framer-lPh30 .framer-1pqso1q { aspect-ratio: 1 / 1; flex: none; height: auto; position: relative; width: 24px; }", ".framer-lPh30.framer-v-11b6awx.framer-ecqd7q { width: 100%; }", ".framer-lPh30.framer-v-gwjldp.framer-ecqd7q, .framer-lPh30.framer-v-mgywu6.framer-ecqd7q { width: 100%; }", ".framer-lPh30.framer-v-gwjldp .framer-r423gp { padding: 12px; }", ".framer-lPh30.framer-v-gwjldp .framer-1xwmpui { flex-direction: column; }", ".framer-lPh30.framer-v-gwjldp .framer-18bk8fj { align-self: unset; flex: none; height: 250px; width: 100%; }", ".framer-lPh30.framer-v-gwjldp .framer-11ccoui { flex: none; width: 100%; }"];
var FramerI64_s8c35 = withCSS3(Component3, css3, "framer-lPh30");
var I64_s8c35_default = FramerI64_s8c35;
FramerI64_s8c35.displayName = "home val";
FramerI64_s8c35.defaultProps = { height: 70, width: 1104 };
addPropertyControls4(FramerI64_s8c35, { variant: { options: ["rwXtPmQ8U", "s4T2S26fp", "soGHMUZ7i", "GPLjmy72J", "OjuDzpVbd", "lHuqH09c7"], optionTitles: ["Desktop Step 1 ", "Desktop Step 2", "Desktop Step 3", "Mobile Step 1 ", "Mobile Step 2", "Mobile Step 3"], title: "Variant", type: ControlType4.Enum } });
addFonts2(FramerI64_s8c35, [{ explicitInter: true, fonts: [{ cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F", url: "https://framerusercontent.com/assets/5vvr9Vy74if2I6bQbJvbw7SY1pQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116", url: "https://framerusercontent.com/assets/EOr0mi4hNtlgWNn9if640EZzXCo.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+1F00-1FFF", url: "https://framerusercontent.com/assets/Y9k9QrlZAqio88Klkmbd8VoMQc.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0370-03FF", url: "https://framerusercontent.com/assets/OYrD2tBIBPvoJXiIHnLoOXnY9M.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF", url: "https://framerusercontent.com/assets/JeYwfuaPfZHQhEG8U5gtPDZ7WQ.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2070, U+2074-207E, U+2080-208E, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD", url: "https://framerusercontent.com/assets/GrgcKwrN6d3Uz8EwcLHZxwEfC4.woff2", weight: "400" }, { cssFamilyName: "Inter", source: "framer", style: "normal", uiFamilyName: "Inter", unicodeRange: "U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB", url: "https://framerusercontent.com/assets/b6Y37FthZeALduNqHicBT6FutY.woff2", weight: "400" }, { cssFamilyName: "Cormorant Garamond", source: "google", style: "normal", uiFamilyName: "Cormorant Garamond", url: "https://fonts.gstatic.com/s/cormorantgaramond/v21/co3umX5slCNuHLi8bLeY9MK7whWMhyjypVO7abI26QOD_s06GnbEi_s4Mfs.woff2", weight: "500" }] }, ...Button2Fonts, ...PropertyMapFonts, ...CheckFonts], { supportsExplicitInterCodegen: true });
FramerI64_s8c35.loader = { load: (props, context) => {
  const locale = context.locale;
  return Promise.allSettled([forwardLoader(PfdXbpeBn_default, {}, context)]);
} };
var __FramerMetadata__2 = { "exports": { "default": { "type": "reactComponent", "name": "FramerI64_s8c35", "slots": [], "annotations": { "framerAutoSizeImages": "true", "framerContractVersion": "1", "framerColorSyntax": "true", "framerDisplayContentsDiv": "false", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","auto"]},"s4T2S26fp":{"layout":["fixed","auto"]},"soGHMUZ7i":{"layout":["fixed","auto"]},"GPLjmy72J":{"layout":["fixed","auto"]},"OjuDzpVbd":{"layout":["fixed","auto"]},"lHuqH09c7":{"layout":["fixed","auto"]}}}', "framerIntrinsicWidth": "1104", "framerIntrinsicHeight": "70", "framerComponentViewportWidth": "true", "framerImmutableVariables": "true" } }, "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__2 as __FramerMetadata__,
  I64_s8c35_default as default
};
