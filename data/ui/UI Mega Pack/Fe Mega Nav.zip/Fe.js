var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/sglMqBkNb7A8W3POnfgC/VcWJFCkIEVwFD2SAGvAq/Fe_Herospot.js
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState, useEffect, useMemo, useRef, startTransition } from "react";
import { addPropertyControls, Color, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
var DEFAULT_SLIDES = [{ image: { src: "https://framerusercontent.com/images/p0Q211wa1voNGpcE0BCeGp2ko.png", alt: "Couple in autumn streetwear on a grey backdrop" }, heading: "Crafting Comfort, Inspired by the Season", description: "Crafted for style and lasting durability, perfect for any season.", buttonText: "View Product", buttonLink: "#" }, { image: { src: "https://framerusercontent.com/images/qAsRQGphEeKdfmfI6HHI24y2zTo.png", alt: "Couple in beige coats and knit beanies" }, heading: "Timeless Design for Modern Living", description: "Experience the perfect blend of comfort and contemporary style.", buttonText: "Explore Now", buttonLink: "#" }, { image: { src: "https://framerusercontent.com/images/Lka4lWNMTZhGU7pJjwmc3npceFk.png", alt: "Two models in tailored suits and sunglasses" }, heading: "Premium Quality, Exceptional Fit", description: "Discover pieces that transform how you dress every day.", buttonText: "Shop Collection", buttonLink: "#" }];
var DEFAULT_HOTSPOTS = [{ text: "Relaxed bomber silhouette.", link: "#", price: "$129.00" }, { text: "Ribbed knit polo.", link: "#", price: "$149.00" }, { text: "Layered modern styling.", link: "#", price: "$99.00" }, { text: "Layered chain necklace.", link: "#", price: "$119.00" }, { text: "Soft merino turtleneck.", link: "#", price: "$139.00" }, { text: "Premium quality materials.", link: "#", price: "$159.00" }, { text: "Structured cotton twill.", link: "#", price: "$109.00" }, { text: "Refined detailing.", link: "#", price: "$89.00" }, { text: "Durable craftsmanship.", link: "#", price: "$169.00" }, { text: "Tailored fit.", link: "#", price: "$129.00" }, { text: "Breathable fabric.", link: "#", price: "$79.00" }, { text: "Timeless silhouette.", link: "#", price: "$189.00" }];
var HOTSPOTS = [
  // Slide 1 — Hotspot Links entries 1-4
  { slide: 0, top: "49%", left: "25%", thumbnail: "https://framerusercontent.com/images/qAsRQGphEeKdfmfI6HHI24y2zTo.png", thumbnailAlt: "Bomber jacket detail" },
  { slide: 0, top: "60%", left: "62%", thumbnail: "https://framerusercontent.com/images/Lka4lWNMTZhGU7pJjwmc3npceFk.png", thumbnailAlt: "Ribbed knit polo detail" },
  { slide: 0, top: "48%", left: "50%", thumbnail: "https://framerusercontent.com/images/qAsRQGphEeKdfmfI6HHI24y2zTo.png", thumbnailAlt: "Layered outerwear detail" },
  { slide: 0, top: "27%", left: "32%", thumbnail: "https://framerusercontent.com/images/p0Q211wa1voNGpcE0BCeGp2ko.png", thumbnailAlt: "Chain necklace detail" },
  // Slide 2 — Hotspot Links entries 5-8
  { slide: 1, top: "13%", left: "39%", thumbnail: "https://framerusercontent.com/images/qAsRQGphEeKdfmfI6HHI24y2zTo.png", thumbnailAlt: "Merino turtleneck detail" },
  { slide: 1, top: "50%", left: "29%", thumbnail: "https://framerusercontent.com/images/Lka4lWNMTZhGU7pJjwmc3npceFk.png", thumbnailAlt: "Premium materials detail" },
  { slide: 1, top: "45%", left: "55%", thumbnail: "https://framerusercontent.com/images/qAsRQGphEeKdfmfI6HHI24y2zTo.png", thumbnailAlt: "Cotton twill detail" },
  { slide: 1, top: "6%", left: "62%", thumbnail: "https://framerusercontent.com/images/p0Q211wa1voNGpcE0BCeGp2ko.png", thumbnailAlt: "Refined detailing" },
  // Slide 3 — Hotspot Links entries 9-12
  { slide: 2, top: "23%", left: "55%", thumbnail: "https://framerusercontent.com/images/Lka4lWNMTZhGU7pJjwmc3npceFk.png", thumbnailAlt: "Durable craftsmanship detail" },
  { slide: 2, top: "56%", left: "21%", thumbnail: "https://framerusercontent.com/images/p0Q211wa1voNGpcE0BCeGp2ko.png", thumbnailAlt: "Tailored fit detail" },
  { slide: 2, top: "22%", left: "32%", thumbnail: "https://framerusercontent.com/images/qAsRQGphEeKdfmfI6HHI24y2zTo.png", thumbnailAlt: "Breathable fabric detail" },
  { slide: 2, top: "46%", left: "77%", thumbnail: "https://framerusercontent.com/images/Lka4lWNMTZhGU7pJjwmc3npceFk.png", thumbnailAlt: "Timeless silhouette detail" }
];
function HeroSection(props) {
  const {
    slides: slidesProp,
    headingFont,
    descriptionFont,
    buttonFont,
    cardBackground = "#FFFFFF",
    textColor = "#000000",
    descriptionColor = "#666666",
    buttonTextColor = "#000000",
    buttonBorderColor = "#000000",
    arrowColor = "#FFFFFF",
    dotColor = "#FFFFFF",
    activeDotColor = "#FFFFFF",
    autoplay = false,
    autoplayInterval = 5e3,
    showHeader = true,
    promoText = "Save 20% on your first order",
    promoBackground = "#000000",
    promoTextColor = "#FFFFFF",
    promoFont,
    logoText = "Fe Herospot",
    navItems = ["Shop", "Collections +", "About +", "Blog"],
    headerBackground = "#FFFFFF",
    navTextColor = "#000000",
    navFont,
    iconColor = "#000000",
    cartCount = 0,
    showPlusIcons = true,
    plusIconColor = "#000000",
    // Slightly translucent by default so the hotspot reads as glass over
    // the photo, matching the original hardcoded look.
    plusIconBackground = "hsla(0, 0%, 100%, 0.85)",
    plusIconItems = DEFAULT_HOTSPOTS,
    darkHeaderBackground = "#000000",
    darkNavTextColor = "#FFFFFF",
    darkIconColor = "#FFFFFF",
    darkCardBackground = "#000000",
    darkTextColor = "#FFFFFF",
    darkDescriptionColor = "#CCCCCC",
    collectionsDropdownBackground = "#FFFFFF",
    collectionsDropdownTextColor = "#000000"
  } = props;
  const slides = useMemo(() => {
    const hasImage = (image) => typeof image === "string" ? image.length > 0 : Boolean(image && image.src);
    const usable = (Array.isArray(slidesProp) ? slidesProp : []).filter((slide) => slide && hasImage(slide.image));
    return usable.length > 0 ? usable : DEFAULT_SLIDES;
  }, [slidesProp]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [hoveredIcon, setHoveredIcon] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [openDropdownIndex, setOpenDropdownIndex] = useState(null);
  const [containerWidth, setContainerWidth] = useState(1200);
  const [headerHeight, setHeaderHeight] = useState(0);
  const containerRef = useRef(null);
  const headerRef = useRef(null);
  const isStatic = useIsStaticRenderer();
  useEffect(() => {
    const node = containerRef.current;
    if (!node || typeof ResizeObserver === "undefined")
      return;
    const update = () => {
      setContainerWidth(node.offsetWidth);
      setHeaderHeight(headerRef.current?.offsetHeight ?? 0);
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(node);
    if (headerRef.current)
      observer.observe(headerRef.current);
    return () => observer.disconnect();
  }, []);
  const isMobile = containerWidth < 768;
  const isTablet = containerWidth >= 768 && containerWidth < 1024;
  const plusBtnSize = isTablet ? "26px" : "32px";
  const plusIconDim = isTablet ? "12" : "14";
  const plusPopupTop = isTablet ? "26px" : "32px";
  const dropdownPanel = collectionsDropdownBackground;
  const dropdownText = collectionsDropdownTextColor;
  const [dropdownCardWash, dropdownCardHoverWash] = useMemo(() => {
    const wash = (alpha) => {
      try {
        const { h, s, l } = Color.toHsl(Color(dropdownText));
        return `hsla(${h}, ${s * 100}%, ${l * 100}%, ${alpha})`;
      } catch {
        return `rgba(128, 128, 128, ${alpha})`;
      }
    };
    const toLayer = (alpha) => {
      const c = wash(alpha);
      return `linear-gradient(${c}, ${c})`;
    };
    return [toLayer(0.05), toLayer(0.11)];
  }, [dropdownText]);
  useEffect(() => {
    if (isStatic || !autoplay || slides.length <= 1)
      return;
    const interval = setInterval(() => {
      startTransition(() => {
        setCurrentSlide((prev) => (prev + 1) % slides.length);
      });
    }, autoplayInterval);
    return () => clearInterval(interval);
  }, [isStatic, autoplay, autoplayInterval, slides.length]);
  const goToSlide = (index) => {
    startTransition(() => setCurrentSlide(index));
  };
  const goToPrevious = () => {
    startTransition(() => {
      setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
    });
  };
  const goToNext = () => {
    startTransition(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    });
  };
  const currentSlideData = slides[currentSlide] || slides[0];
  const renderThemeToggle = () => /* @__PURE__ */ _jsx("button", { type: "button", onClick: () => startTransition(() => setIsDarkMode((prev) => !prev)), style: { width: "36px", height: "20px", borderRadius: "999px", border: "none", backgroundColor: isDarkMode ? "#333333" : "#EAEAEA", display: "flex", alignItems: "center", justifyContent: isDarkMode ? "flex-end" : "flex-start", padding: "3px", boxSizing: "border-box", cursor: "pointer", flexShrink: 0, transition: "background-color 0.3s ease" }, "aria-label": "Toggle dark mode", "aria-pressed": isDarkMode, children: /* @__PURE__ */ _jsx("span", { style: { width: "14px", height: "14px", borderRadius: "50%", backgroundColor: isDarkMode ? darkNavTextColor : navTextColor, transition: "background-color 0.3s ease" } }) });
  const hotspotsBySlide = (slideIndex) => HOTSPOTS.map((spot, spotIndex) => ({ spot, spotIndex })).filter(({ spot }) => spot.slide === slideIndex).map(({ spot, spotIndex }) => {
    const item = plusIconItems?.[spotIndex];
    const fallback = DEFAULT_HOTSPOTS[spotIndex];
    return { spot, spotIndex, label: item?.text || fallback?.text || "Product detail", price: item?.price || fallback?.price || "" };
  });
  const getImageSrc = (image) => {
    if (!image)
      return DEFAULT_SLIDES[0].image.src;
    if (typeof image === "string")
      return image;
    return image.src || DEFAULT_SLIDES[0].image.src;
  };
  const getImageAlt = (image) => {
    if (!image)
      return "Slide image";
    if (typeof image === "object" && image.alt)
      return image.alt;
    return "Slide image";
  };
  return /* @__PURE__ */ _jsxs("div", { ref: containerRef, style: {
    position: "relative",
    width: "100%",
    // Phone: hug the content (image + card) so there's no empty
    // space above/below the full image. Tablet/desktop: fill frame.
    height: isMobile ? "auto" : "100%",
    overflow: "hidden",
    // In dark mode use square corners so the corners are filled with
    // the (black) component background instead of revealing the white
    // page behind the rounded corners. Light mode keeps the rounded
    // card look (its corners blend into the white page).
    borderRadius: isDarkMode ? "0px" : isMobile ? "16px" : "24px",
    clipPath: isDarkMode ? "none" : isMobile ? "inset(0px round 16px)" : "inset(0px round 24px)",
    backgroundColor: isDarkMode ? darkHeaderBackground : "#FFFFFF"
  }, children: [showHeader && /* @__PURE__ */ _jsxs("header", { ref: headerRef, style: {
    position: "absolute",
    top: 0,
    left: isMobile ? "12px" : "16px",
    right: isMobile ? "12px" : "16px",
    zIndex: 200,
    boxSizing: "border-box",
    // The header box spans the full width of the hero and its
    // transparent Navigation Row wrapper used to swallow hover
    // on any plus-icon hotspot placed near the top of a slide
    // (e.g. the beanie hotspot on slide 2). Let clicks/hovers
    // fall through here and re-enable them only on the actual
    // interactive tabs below.
    pointerEvents: "none"
  }, children: [/* @__PURE__ */ _jsx("div", { "aria-hidden": "true", style: { position: "absolute", top: 0, left: 0, right: 0, height: isMobile ? "42px" : "50px", backgroundColor: isDarkMode ? darkHeaderBackground : headerBackground, zIndex: 0, pointerEvents: "none" } }), /* @__PURE__ */ _jsxs("div", { style: { backgroundColor: isDarkMode ? "#FFFFFF" : promoBackground, height: isMobile ? "36px" : "42px", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", position: "relative", zIndex: 1, marginTop: isMobile ? "6px" : "8px", marginBottom: 0, borderRadius: isMobile ? "10px" : "14px", clipPath: isMobile ? "inset(0px round 10px)" : "inset(0px round 14px)" }, children: [/* @__PURE__ */ _jsx("style", { children: `@keyframes marqueeScroll{from{transform:translateX(0%)}to{transform:translateX(-50%)}}` }), /* @__PURE__ */ _jsx("div", { style: { width: isMobile ? "260px" : "560px", maxWidth: "100%", display: "flex", overflow: "hidden", maskImage: "linear-gradient(to right, transparent 0%, #000 18%, #000 82%, transparent 100%)", WebkitMaskImage: "linear-gradient(to right, transparent 0%, #000 18%, #000 82%, transparent 100%)" }, children: /* @__PURE__ */ _jsx("div", { style: { display: "flex", width: "max-content", animation: isStatic ? "none" : "marqueeScroll 40s linear infinite", fontFamily: "Inter, sans-serif", fontSize: isMobile ? "12px" : "13px", fontWeight: 600, letterSpacing: "0em", color: isDarkMode ? "#000000" : promoTextColor, whiteSpace: "nowrap", alignItems: "center", ...promoFont }, children: Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center" }, children: [/* @__PURE__ */ _jsx("span", { children: promoText }), /* @__PURE__ */ _jsx("span", { style: { opacity: 0.5, margin: isMobile ? "0 4px" : "0 6px", fontSize: "14px", fontWeight: 400 }, children: "\u2014" })] }, i)) }) })] }), /* @__PURE__ */ _jsx("div", { style: { height: isMobile ? "8px" : "10px", backgroundColor: isDarkMode ? darkHeaderBackground : headerBackground } }), /* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "flex-start", justifyContent: "space-between", backgroundColor: "transparent" }, children: [/* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", gap: isTablet ? "24px" : "34px", paddingTop: isMobile ? "12px" : "14px", paddingBottom: isMobile ? "12px" : "14px", paddingLeft: isMobile ? "16px" : isTablet ? "20px" : "24px", paddingRight: isMobile ? "20px" : isTablet ? "26px" : "32px", backgroundColor: isDarkMode ? darkHeaderBackground : headerBackground, borderBottomRightRadius: isMobile ? "16px" : "24px", position: "relative", pointerEvents: "auto" }, children: [/* @__PURE__ */ _jsx("div", { "aria-hidden": "true", style: {
    // Desktop-only flourish; on phone the header
    // sits on white (not over the image).
    display: isMobile ? "none" : "block",
    position: "absolute",
    top: 0,
    left: "100%",
    width: isMobile ? "18px" : "26px",
    height: isMobile ? "18px" : "26px",
    background: "radial-gradient(circle farthest-side at bottom right, transparent 98%, " + (isDarkMode ? darkHeaderBackground : headerBackground) + " 100%)",
    pointerEvents: "none"
  } }), /* @__PURE__ */ _jsx("div", { "aria-hidden": "true", style: { display: isMobile ? "none" : "block", position: "absolute", top: "100%", left: 0, width: isMobile ? "16px" : "22px", height: isMobile ? "16px" : "22px", background: "radial-gradient(circle farthest-side at bottom right, transparent 98%, " + (isDarkMode ? darkHeaderBackground : headerBackground) + " 100%)", pointerEvents: "none" } }), /* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", gap: "9px", color: isDarkMode ? darkNavTextColor : navTextColor, flexShrink: 0 }, children: [/* @__PURE__ */ _jsxs("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", children: [/* @__PURE__ */ _jsx("circle", { cx: "12", cy: "12", r: "10", stroke: isDarkMode ? darkNavTextColor : navTextColor, strokeWidth: "2" }), /* @__PURE__ */ _jsx("circle", { cx: "12", cy: "12", r: "3.5", fill: isDarkMode ? darkNavTextColor : navTextColor })] }), /* @__PURE__ */ _jsx("span", { style: { fontWeight: 600, fontSize: isMobile ? "16px" : "17px", letterSpacing: "-0.01em", ...navFont }, children: logoText })] }), isMobile && renderThemeToggle(), !isMobile && /* @__PURE__ */ _jsxs("nav", { style: { display: "flex", alignItems: "center", gap: isTablet ? "20px" : "28px" }, children: [/* @__PURE__ */ _jsx("style", { children: `.fe-nav-roll{display:inline-block;overflow:hidden;vertical-align:top;height:24px}.fe-nav-roll-inner{display:block;transform:translateY(-50%);transition:transform .6s cubic-bezier(.65,0,.35,1)}.fe-nav-roll:hover .fe-nav-roll-inner{transform:translateY(0)}` }), navItems.map((item, index) => {
    const lower = item.toLowerCase();
    const isAbout = lower.includes("about");
    const hasDropdown = item.includes("+") || /collection|categor|about/i.test(item);
    const isOpen = hasDropdown && openDropdownIndex === index;
    return /* @__PURE__ */ _jsxs("div", {
      style: { position: "relative", overflow: "visible" },
      onMouseEnter: () => {
        if (hasDropdown) {
          startTransition(() => setOpenDropdownIndex(index));
        }
      },
      onMouseLeave: () => {
        if (hasDropdown) {
          startTransition(() => setOpenDropdownIndex(null));
        }
      },
      // Keyboard parity with hover:
      // focus anywhere inside opens the
      // panel, focus leaving it (or
      // Escape) closes it. Without this
      // the dropdowns are unreachable
      // without a mouse.
      onFocus: () => {
        if (hasDropdown) {
          startTransition(() => setOpenDropdownIndex(index));
        }
      },
      onBlur: (e) => {
        if (hasDropdown && !e.currentTarget.contains(e.relatedTarget)) {
          startTransition(() => setOpenDropdownIndex(null));
        }
      },
      onKeyDown: (e) => {
        if (e.key === "Escape" && isOpen) {
          startTransition(() => setOpenDropdownIndex(null));
        }
      },
      children: [/* @__PURE__ */ _jsx("a", { href: "#", className: "fe-nav-roll", "aria-haspopup": hasDropdown || void 0, "aria-expanded": hasDropdown ? isOpen : void 0, style: { color: isDarkMode ? darkNavTextColor : navTextColor, textDecoration: "none", fontSize: "15px", fontWeight: 500, ...navFont }, children: /* @__PURE__ */ _jsxs("span", { className: "fe-nav-roll-inner", children: [/* @__PURE__ */ _jsx("span", { style: { display: "block", height: "24px", lineHeight: "24px", whiteSpace: "nowrap" }, children: item }), /* @__PURE__ */ _jsx("span", { style: { display: "block", height: "24px", lineHeight: "24px", whiteSpace: "nowrap" }, children: item })] }) }), isOpen && /* @__PURE__ */ _jsx("div", { "aria-hidden": "true", style: { position: "absolute", top: "100%", left: "-20px", right: "-20px", height: "20px", zIndex: 99 } }), isOpen && !isAbout && /* @__PURE__ */ _jsx("div", { style: { position: "absolute", top: "100%", left: "0", marginTop: "14px", backgroundColor: dropdownPanel, borderRadius: "22px", padding: "14px", boxShadow: "0 14px 34px rgba(0, 0, 0, 0.28)", minWidth: "320px", zIndex: 100, display: "flex", flexDirection: "column", gap: "12px" }, children: [{ name: "Outerwear", img: "https://framerusercontent.com/images/p0Q211wa1voNGpcE0BCeGp2ko.png" }, { name: "Knitwear", img: "https://framerusercontent.com/images/qAsRQGphEeKdfmfI6HHI24y2zTo.png" }, { name: "Tailoring", img: "https://framerusercontent.com/images/Lka4lWNMTZhGU7pJjwmc3npceFk.png" }].map((col, ci) => /* @__PURE__ */ _jsxs("a", { href: "#", style: { display: "flex", alignItems: "center", gap: "16px", padding: "12px", borderRadius: "16px", backgroundColor: dropdownPanel, backgroundImage: dropdownCardWash, textDecoration: "none", transition: "background-image 0.2s ease" }, onMouseEnter: (e) => {
        e.currentTarget.style.backgroundImage = dropdownCardHoverWash;
      }, onMouseLeave: (e) => {
        e.currentTarget.style.backgroundImage = dropdownCardWash;
      }, children: [/* @__PURE__ */ _jsx("img", { src: col.img, alt: col.name, loading: "lazy", decoding: "async", style: { width: "52px", height: "52px", borderRadius: "12px", objectFit: "cover", flexShrink: 0 } }), /* @__PURE__ */ _jsx("span", { style: { flex: 1, color: dropdownText, fontSize: "16px", fontWeight: 500 }, children: col.name }), /* @__PURE__ */ _jsxs("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: dropdownText, strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round", children: [/* @__PURE__ */ _jsx("line", { x1: "5", y1: "12", x2: "19", y2: "12" }), /* @__PURE__ */ _jsx("polyline", { points: "12 5 19 12 12 19" })] })] }, ci)) }), isOpen && isAbout && /* @__PURE__ */ _jsx("div", { style: { position: "absolute", top: "100%", left: "0", marginTop: "14px", backgroundColor: dropdownPanel, borderRadius: "22px", padding: "14px", boxShadow: "0 14px 34px rgba(0, 0, 0, 0.28)", minWidth: "240px", zIndex: 100, display: "flex", flexDirection: "column", gap: "12px" }, children: ["About", "Contact", "FAQ"].map((link, li) => /* @__PURE__ */ _jsxs("a", { href: "#", style: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 16px", borderRadius: "16px", backgroundColor: dropdownPanel, backgroundImage: dropdownCardWash, textDecoration: "none", transition: "background-image 0.2s ease" }, onMouseEnter: (e) => {
        e.currentTarget.style.backgroundImage = dropdownCardHoverWash;
      }, onMouseLeave: (e) => {
        e.currentTarget.style.backgroundImage = dropdownCardWash;
      }, children: [/* @__PURE__ */ _jsx("span", { style: { color: dropdownText, fontSize: "16px", fontWeight: 500 }, children: link }), /* @__PURE__ */ _jsxs("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: dropdownText, strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round", children: [/* @__PURE__ */ _jsx("line", { x1: "5", y1: "12", x2: "19", y2: "12" }), /* @__PURE__ */ _jsx("polyline", { points: "12 5 19 12 12 19" })] })] }, li)) })]
    }, index);
  }), renderThemeToggle()] })] }), /* @__PURE__ */ _jsxs("div", { style: { display: "flex", alignItems: "center", gap: isMobile ? "14px" : "16px", flexShrink: 0, paddingTop: isMobile ? "12px" : "14px", paddingBottom: isMobile ? "12px" : "14px", paddingRight: isMobile ? "16px" : isTablet ? "20px" : "24px", paddingLeft: isMobile ? "20px" : isTablet ? "26px" : "32px", backgroundColor: isDarkMode ? darkHeaderBackground : headerBackground, borderBottomLeftRadius: isMobile ? "16px" : "24px", position: "relative", pointerEvents: "auto" }, children: [/* @__PURE__ */ _jsx("div", { "aria-hidden": "true", style: { display: isMobile ? "none" : "block", position: "absolute", top: 0, right: "100%", width: isMobile ? "18px" : "26px", height: isMobile ? "18px" : "26px", background: "radial-gradient(circle farthest-side at bottom left, transparent 98%, " + (isDarkMode ? darkHeaderBackground : headerBackground) + " 100%)", pointerEvents: "none" } }), /* @__PURE__ */ _jsx("div", { "aria-hidden": "true", style: { display: isMobile ? "none" : "block", position: "absolute", top: "100%", right: 0, width: isMobile ? "16px" : "22px", height: isMobile ? "16px" : "22px", background: "radial-gradient(circle farthest-side at bottom left, transparent 98%, " + (isDarkMode ? darkHeaderBackground : headerBackground) + " 100%)", pointerEvents: "none" } }), /* @__PURE__ */ _jsx("button", { style: { background: "transparent", border: "none", cursor: "pointer", padding: 0, display: "flex", alignItems: "center", transition: "opacity 0.2s ease" }, "aria-label": "Search", onMouseEnter: (e) => {
    e.currentTarget.style.opacity = "0.6";
  }, onMouseLeave: (e) => {
    e.currentTarget.style.opacity = "1";
  }, children: /* @__PURE__ */ _jsxs("svg", { width: "19", height: "19", viewBox: "0 0 24 24", fill: "none", stroke: isDarkMode ? darkIconColor : iconColor, strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round", children: [/* @__PURE__ */ _jsx("circle", { cx: "11", cy: "11", r: "8" }), /* @__PURE__ */ _jsx("path", { d: "m21 21-4.35-4.35" })] }) }), /* @__PURE__ */ _jsxs("button", { style: { background: "transparent", border: "none", cursor: "pointer", padding: 0, display: "flex", alignItems: "center", gap: "5px", transition: "opacity 0.2s ease" }, "aria-label": "Shopping cart", onMouseEnter: (e) => {
    e.currentTarget.style.opacity = "0.6";
  }, onMouseLeave: (e) => {
    e.currentTarget.style.opacity = "1";
  }, children: [/* @__PURE__ */ _jsxs("svg", { width: "19", height: "19", viewBox: "0 0 24 24", fill: "none", stroke: isDarkMode ? darkIconColor : iconColor, strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round", children: [/* @__PURE__ */ _jsx("path", { d: "M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" }), /* @__PURE__ */ _jsx("line", { x1: "3", y1: "6", x2: "21", y2: "6" }), /* @__PURE__ */ _jsx("path", { d: "M16 10a4 4 0 0 1-8 0" })] }), /* @__PURE__ */ _jsxs("span", { style: { color: isDarkMode ? darkNavTextColor : navTextColor, fontSize: "15px", fontWeight: 500, ...navFont }, children: ["(", cartCount, ")"] })] }), isMobile && /* @__PURE__ */ _jsx("button", { onClick: () => startTransition(() => setMenuOpen((prev) => !prev)), style: { background: "transparent", border: "none", cursor: "pointer", padding: 0, marginLeft: "2px", display: "flex", alignItems: "center", color: isDarkMode ? darkNavTextColor : navTextColor, fontSize: "15px", fontWeight: 500, ...navFont }, "aria-label": "Menu", "aria-expanded": menuOpen, children: "Menu" })] })] }), isMobile && menuOpen && /* @__PURE__ */ _jsx("nav", { style: { display: "flex", flexDirection: "column", gap: "2px", marginTop: "8px", marginLeft: isMobile ? "12px" : "16px", marginRight: isMobile ? "12px" : "16px", backgroundColor: isDarkMode ? darkHeaderBackground : headerBackground, borderRadius: "18px", paddingTop: "6px", paddingBottom: "6px", paddingLeft: "14px", paddingRight: "14px", boxShadow: "0 8px 20px rgba(0,0,0,0.10)", pointerEvents: "auto" }, children: navItems.map((item, index) => /* @__PURE__ */ _jsx("a", { href: "#", style: { color: isDarkMode ? darkNavTextColor : navTextColor, textDecoration: "none", fontSize: "16px", fontWeight: 500, padding: "11px 6px", borderTop: index === 0 ? "none" : isDarkMode ? "1px solid rgba(255,255,255,0.10)" : "1px solid rgba(0,0,0,0.06)", ...navFont }, children: item }, index)) })] }), /* @__PURE__ */ _jsxs("div", { style: {
    // Phone: relative + auto height so the container hugs the
    // full image (no top/bottom gap). Tablet/desktop: absolute,
    // filling the frame minus insets.
    ...isMobile ? {
      position: "relative",
      marginTop: showHeader ? `${headerHeight}px` : "0px",
      // Full-bleed (edge to edge) so the image is bigger.
      marginLeft: "0px",
      marginRight: "0px",
      marginBottom: "0px"
    } : { position: "absolute", top: 0, left: "16px", right: "16px", bottom: "16px" },
    overflow: "hidden",
    borderBottomLeftRadius: isMobile ? "16px" : "24px",
    borderBottomRightRadius: isMobile ? "16px" : "24px",
    clipPath: isMobile ? "inset(0px round 0px 0px 16px 16px)" : "inset(0px round 0px 0px 24px 24px)"
  }, children: [slides.map((slide, index) => /* @__PURE__ */ _jsxs("div", { style: {
    // Phone: the active slide is `relative` so the hero
    // hugs the image's natural height (full image, no
    // crop on any side, no top/bottom gap). Other slides
    // stay absolute & faded out.
    // Tablet/desktop: absolute background image (cover).
    ...isMobile ? { position: index === currentSlide ? "relative" : "absolute", top: 0, left: 0, width: "100%" } : { position: "absolute", top: 0, left: 0, width: "100%", height: "100%", backgroundImage: `url(${getImageSrc(slide.image)})`, backgroundSize: "cover", backgroundPosition: "center", backgroundRepeat: "no-repeat" },
    opacity: index === currentSlide ? 1 : 0,
    transition: isStatic ? "none" : "opacity 0.6s ease-in-out",
    pointerEvents: index === currentSlide ? "auto" : "none"
  }, role: "img", "aria-label": getImageAlt(slide.image), children: [isMobile && /* @__PURE__ */ _jsx("img", { src: getImageSrc(slide.image), alt: getImageAlt(slide.image), style: { display: "block", width: "100%", aspectRatio: "1 / 1", height: "auto", objectFit: "cover", objectPosition: "center" } }), /* @__PURE__ */ _jsx("div", { style: { position: "absolute", top: 0, left: 0, width: "100%", height: "100%", backgroundColor: isDarkMode ? "rgba(0, 0, 0, 0.5)" : "rgba(0, 0, 0, 0.2)", transition: "background-color 0.3s ease" } }), isMobile && slides.length > 1 && index === currentSlide && /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsx("button", { onClick: goToPrevious, style: { position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", background: "transparent", border: "none", padding: "8px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 10 }, "aria-label": "Previous slide", children: /* @__PURE__ */ _jsx("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: arrowColor, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ _jsx("polyline", { points: "15 18 9 12 15 6" }) }) }), /* @__PURE__ */ _jsx("button", { onClick: goToNext, style: { position: "absolute", right: "12px", top: "50%", transform: "translateY(-50%)", background: "transparent", border: "none", padding: "8px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 10 }, "aria-label": "Next slide", children: /* @__PURE__ */ _jsx("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: arrowColor, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ _jsx("polyline", { points: "9 18 15 12 9 6" }) }) })] }), showPlusIcons && !isMobile && /* @__PURE__ */ _jsx(_Fragment, { children: hotspotsBySlide(index).map(({ spot, spotIndex, label, price }) => /* @__PURE__ */ _jsxs("div", { style: { position: "absolute", top: spot.top, left: spot.left, zIndex: 8 }, onMouseEnter: () => startTransition(() => setHoveredIcon(spotIndex)), onMouseLeave: () => startTransition(() => setHoveredIcon(null)), children: [/* @__PURE__ */ _jsx("button", {
    style: { width: plusBtnSize, height: plusBtnSize, borderRadius: "50%", backgroundColor: plusIconBackground, border: "1px solid rgba(255, 255, 255, 0.6)", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 2px 10px rgba(0, 0, 0, 0.18)" },
    // Keyboard users get the same popup
    // as mouse users.
    onFocus: () => startTransition(() => setHoveredIcon(spotIndex)),
    onBlur: () => startTransition(() => setHoveredIcon(null)),
    "aria-label": price ? `${label} \u2014 ${price}` : label,
    "aria-expanded": hoveredIcon === spotIndex,
    children: /* @__PURE__ */ _jsxs("svg", { width: plusIconDim, height: plusIconDim, viewBox: "0 0 16 16", fill: "none", stroke: plusIconColor, strokeWidth: "2.5", strokeLinecap: "round", style: { transform: hoveredIcon === spotIndex ? "rotate(45deg)" : "rotate(0deg)", transition: "transform 0.3s ease" }, children: [/* @__PURE__ */ _jsx("line", { x1: "8", y1: "3", x2: "8", y2: "13" }), /* @__PURE__ */ _jsx("line", { x1: "3", y1: "8", x2: "13", y2: "8" })] })
  }), hoveredIcon === spotIndex && /* @__PURE__ */ _jsxs("div", { style: { position: "absolute", top: plusPopupTop, left: "0", backgroundColor: "#FFFFFF", borderRadius: "12px", padding: "12px", boxShadow: "0 4px 20px rgba(0, 0, 0, 0.15)", display: "flex", alignItems: "center", gap: "12px", minWidth: "220px", zIndex: 20 }, children: [/* @__PURE__ */ _jsx("img", {
    src: spot.thumbnail,
    alt: spot.thumbnailAlt,
    // Hover-only imagery, so it
    // must not compete with the
    // hero for bandwidth.
    loading: "lazy",
    decoding: "async",
    style: { width: "48px", height: "48px", borderRadius: "8px", objectFit: "cover" }
  }), /* @__PURE__ */ _jsxs("span", { style: { fontSize: "14px", color: "#000000", flex: 1 }, children: [/* @__PURE__ */ _jsx("a", { href: plusIconItems[spotIndex]?.link || "#", style: { color: "#000000", textDecoration: "none" }, onMouseEnter: (e) => {
    e.currentTarget.style.textDecoration = "underline";
  }, onMouseLeave: (e) => {
    e.currentTarget.style.textDecoration = "none";
  }, children: label }), /* @__PURE__ */ _jsx("span", { style: { display: "block", marginTop: "4px", fontSize: "13px", fontWeight: 600, color: "#000000" }, children: price })] })] })] }, spotIndex)) })] }, index)), slides.length > 1 && !isMobile && /* @__PURE__ */ _jsxs(_Fragment, { children: [/* @__PURE__ */ _jsx("button", { onClick: goToPrevious, style: { position: "absolute", left: isMobile ? "12px" : isTablet ? "16px" : "24px", top: "50%", transform: "translateY(-50%)", background: "transparent", border: "none", cursor: "pointer", padding: isMobile ? "8px" : "12px", zIndex: 10, display: "flex", alignItems: "center", justifyContent: "center" }, "aria-label": "Previous slide", children: /* @__PURE__ */ _jsx("svg", { width: isMobile ? "24" : "32", height: isMobile ? "24" : "32", viewBox: "0 0 24 24", fill: "none", stroke: arrowColor, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ _jsx("polyline", { points: "15 18 9 12 15 6" }) }) }), /* @__PURE__ */ _jsx("button", { onClick: goToNext, style: { position: "absolute", right: isMobile ? "12px" : isTablet ? "16px" : "24px", top: "50%", transform: "translateY(-50%)", background: "transparent", border: "none", cursor: "pointer", padding: isMobile ? "8px" : "12px", zIndex: 10, display: "flex", alignItems: "center", justifyContent: "center" }, "aria-label": "Next slide", children: /* @__PURE__ */ _jsx("svg", { width: isMobile ? "24" : "32", height: isMobile ? "24" : "32", viewBox: "0 0 24 24", fill: "none", stroke: arrowColor, strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ _jsx("polyline", { points: "9 18 15 12 9 6" }) }) })] }), /* @__PURE__ */ _jsxs("div", { style: {
    // Phone: in-flow card pulled UP into the image so it
    // overlaps the lower part of the photo (reference look),
    // while the rest of the full image stays visible.
    // Tablet: full-width overlay anchored bottom.
    // Desktop: overlay anchored bottom-left.
    ...isMobile ? { position: "relative", marginTop: "-96px", marginLeft: "16px", marginRight: "16px", marginBottom: "12px", maxWidth: "100%" } : { position: "absolute", bottom: isTablet ? "30px" : "40px", left: isTablet ? "24px" : "40px", right: isTablet ? "24px" : "auto", maxWidth: isTablet ? "none" : "480px" },
    backgroundColor: isDarkMode ? darkCardBackground : cardBackground,
    borderRadius: isMobile ? "16px" : isTablet ? "20px" : "24px",
    padding: isMobile ? "40px 32px" : isTablet ? "52px 40px" : "60px 48px",
    zIndex: 5,
    boxShadow: "0 4px 20px rgba(0, 0, 0, 0.1)",
    transition: "background-color 0.3s ease"
  }, children: [/* @__PURE__ */ _jsx("h1", { style: { margin: "0 0 16px 0", color: isDarkMode ? darkTextColor : textColor, ...headingFont, ...isMobile ? { fontSize: "24px" } : isTablet ? { fontSize: "28px" } : {} }, children: currentSlideData.heading }), /* @__PURE__ */ _jsx("p", { style: { margin: "0 0 24px 0", color: isDarkMode ? darkDescriptionColor : descriptionColor, ...descriptionFont, ...isMobile ? { fontSize: "14px" } : {} }, children: currentSlideData.description }), /* @__PURE__ */ _jsx("a", { href: currentSlideData.buttonLink || "#", style: { display: "inline-block", color: buttonTextColor, textDecoration: "underline", textUnderlineOffset: "4px", cursor: "pointer", ...buttonFont, ...isMobile ? { fontSize: "13px" } : {} }, children: currentSlideData.buttonText })] }), slides.length > 1 && !isMobile && !isTablet && /* @__PURE__ */ _jsx("div", { style: { position: "absolute", bottom: isTablet ? "30px" : "40px", left: "50%", transform: "translateX(-50%)", display: "flex", alignItems: "center", gap: "12px", zIndex: 10 }, children: slides.map((_, index) => /* @__PURE__ */ _jsx("button", { onClick: () => goToSlide(index), style: { width: "10px", height: "10px", borderRadius: "50%", border: "none", backgroundColor: index === currentSlide ? activeDotColor : dotColor, opacity: index === currentSlide ? 1 : 0.5, cursor: "pointer", padding: 0, transition: "opacity 0.3s ease" }, "aria-label": `Go to slide ${index + 1}`, "aria-current": index === currentSlide ? "true" : "false" }, index)) })] })] });
}
HeroSection.displayName = "Fe Mega Nav";
addPropertyControls(HeroSection, { slides: { type: ControlType.Array, title: "Slides", description: "One entry per slide. A slide with no image is skipped; if no entry has an image, the three built-in slides are shown instead.", control: { type: ControlType.Object, controls: { image: { type: ControlType.ResponsiveImage, title: "Image" }, heading: { type: ControlType.String, title: "Heading", defaultValue: "Natural Elegance in Every Detail" }, description: { type: ControlType.String, title: "Description", defaultValue: "Crafted from soft, breathable fabrics with a clean finish, timeless and durable.", displayTextArea: true }, buttonText: { type: ControlType.String, title: "Button Text", defaultValue: "View Product" }, buttonLink: { type: ControlType.Link, title: "Button Link" } } }, defaultValue: DEFAULT_SLIDES }, showHeader: { type: ControlType.Boolean, title: "Show Header", description: "Turn off when the page already has its own nav above this section.", defaultValue: true }, logoText: { type: ControlType.String, title: "Logo Text", defaultValue: "Fe Herospot", hidden: ({ showHeader }) => !showHeader }, navItems: { type: ControlType.Array, title: "Nav Items", description: "End a label with a plus sign to give it a dropdown menu, for example Collections +.", control: { type: ControlType.String }, defaultValue: ["Shop", "Collections +", "About +", "Blog"], hidden: ({ showHeader }) => !showHeader }, promoText: { type: ControlType.String, title: "Promo Text", defaultValue: "Save 20% on your first order", hidden: ({ showHeader }) => !showHeader }, headerBackground: { type: ControlType.Color, title: "Header Background", defaultValue: "#FFFFFF", hidden: ({ showHeader }) => !showHeader }, navTextColor: { type: ControlType.Color, title: "Nav Text Color", defaultValue: "#000000", hidden: ({ showHeader }) => !showHeader }, iconColor: { type: ControlType.Color, title: "Icon Color", defaultValue: "#000000", hidden: ({ showHeader }) => !showHeader }, cartCount: { type: ControlType.Number, title: "Cart Count", description: "Number shown in brackets next to the cart icon.", defaultValue: 0, min: 0, max: 99, step: 1, hidden: ({ showHeader }) => !showHeader }, promoBackground: { type: ControlType.Color, title: "Promo Background", defaultValue: "#000000", hidden: ({ showHeader }) => !showHeader }, promoTextColor: { type: ControlType.Color, title: "Promo Text Color", defaultValue: "#FFFFFF", hidden: ({ showHeader }) => !showHeader }, collectionsDropdownBackground: { type: ControlType.Color, title: "Dropdown BG", defaultValue: "#FFFFFF", hidden: ({ showHeader }) => !showHeader }, collectionsDropdownTextColor: { type: ControlType.Color, title: "Dropdown Text", defaultValue: "#000000", hidden: ({ showHeader }) => !showHeader }, showPlusIcons: { type: ControlType.Boolean, title: "Show Plus Icons", description: "Shoppable hotspots pinned over the slide image. Always hidden at phone widths.", defaultValue: true }, plusIconItems: { type: ControlType.Array, title: "Hotspot Links", description: "Up to 12 hotspots, filled in slide order: entries 1-4 belong to slide 1, 5-8 to slide 2, 9-12 to slide 3.", maxCount: 12, control: { type: ControlType.Object, controls: { text: { type: ControlType.String, title: "Text", defaultValue: "Product detail" }, price: { type: ControlType.String, title: "Price", defaultValue: "$0.00" }, link: { type: ControlType.Link, title: "Link" } } }, defaultValue: DEFAULT_HOTSPOTS, hidden: ({ showPlusIcons }) => !showPlusIcons }, plusIconColor: { type: ControlType.Color, title: "Plus Icon Color", defaultValue: "#000000", hidden: ({ showPlusIcons }) => !showPlusIcons }, plusIconBackground: { type: ControlType.Color, title: "Plus Icon Background", defaultValue: "hsla(0, 0%, 100%, 0.85)", hidden: ({ showPlusIcons }) => !showPlusIcons }, headingFont: { type: ControlType.Font, title: "Heading Font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: "32px", variant: "Regular", letterSpacing: "-0.02em", lineHeight: "1.2em" } }, descriptionFont: { type: ControlType.Font, title: "Description Font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: "15px", variant: "Regular", letterSpacing: "0em", lineHeight: "1.5em" } }, buttonFont: { type: ControlType.Font, title: "Button Font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: "14px", variant: "Medium", letterSpacing: "0em", lineHeight: "1em" } }, navFont: { type: ControlType.Font, title: "Nav Font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: "14px", variant: "Regular", letterSpacing: "0em", lineHeight: "1em" }, hidden: ({ showHeader }) => !showHeader }, promoFont: { type: ControlType.Font, title: "Promo Font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: "13px", variant: "Regular", letterSpacing: "0em", lineHeight: "1em" }, hidden: ({ showHeader }) => !showHeader }, cardBackground: { type: ControlType.Color, title: "Card Background", defaultValue: "#FFFFFF" }, textColor: { type: ControlType.Color, title: "Heading Color", defaultValue: "#000000" }, descriptionColor: { type: ControlType.Color, title: "Description Color", defaultValue: "#666666" }, buttonTextColor: { type: ControlType.Color, title: "Button Color", defaultValue: "#000000" }, arrowColor: { type: ControlType.Color, title: "Arrow Color", defaultValue: "#FFFFFF" }, dotColor: { type: ControlType.Color, title: "Dot Color", defaultValue: "#FFFFFF" }, activeDotColor: { type: ControlType.Color, title: "Active Dot Color", defaultValue: "#FFFFFF" }, darkHeaderBackground: { type: ControlType.Color, title: "Dark Header BG", description: "Used when the header sits over a dark part of the slide image.", defaultValue: "#000000", hidden: ({ showHeader }) => !showHeader }, darkNavTextColor: { type: ControlType.Color, title: "Dark Nav Text", defaultValue: "#FFFFFF", hidden: ({ showHeader }) => !showHeader }, darkIconColor: { type: ControlType.Color, title: "Dark Icon Color", defaultValue: "#FFFFFF", hidden: ({ showHeader }) => !showHeader }, darkCardBackground: { type: ControlType.Color, title: "Dark Card BG", defaultValue: "#000000" }, darkTextColor: { type: ControlType.Color, title: "Dark Heading", defaultValue: "#FFFFFF" }, darkDescriptionColor: { type: ControlType.Color, title: "Dark Description", defaultValue: "#CCCCCC" }, autoplay: { type: ControlType.Boolean, title: "Autoplay", description: "Advances slides on a timer. Always paused on the Framer canvas and in exports.", defaultValue: false }, autoplayInterval: { type: ControlType.Number, title: "Autoplay Interval", description: "How long each slide stays on screen before advancing.", defaultValue: 5e3, min: 1e3, max: 1e4, step: 500, unit: "ms", hidden: ({ autoplay }) => !autoplay } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "HeroSection", "slots": [], "annotations": { "framerIntrinsicWidth": "1200", "framerSupportedLayoutWidth": "any-prefer-fixed", "framerIntrinsicHeight": "800", "framerContractVersion": "1", "framerSupportedLayoutHeight": "any-prefer-fixed" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  HeroSection as default
};
