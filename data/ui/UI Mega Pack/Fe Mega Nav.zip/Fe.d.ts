export interface FeProps {
  /**
   * Slides
   */
  slides?: unknown[];
  /**
   * Show Header
   * @default true
   */
  showHeader?: boolean;
  /**
   * Logo Text
   * @default "Fe Herospot"
   */
  logoText?: string;
  /**
   * Nav Items
   * @default ["Shop","Collections +","About +","Blog"]
   */
  navItems?: unknown[];
  /**
   * Promo Text
   * @default "Save 20% on your first order"
   */
  promoText?: string;
  /**
   * Header Background
   * @default "#FFFFFF"
   */
  headerBackground?: string;
  /**
   * Nav Text Color
   * @default "#000000"
   */
  navTextColor?: string;
  /**
   * Icon Color
   * @default "#000000"
   */
  iconColor?: string;
  /**
   * Cart Count
   * Range: min: 0, max: 99, step: 1
   * @default 0
   */
  cartCount?: number;
  /**
   * Promo Background
   * @default "#000000"
   */
  promoBackground?: string;
  /**
   * Promo Text Color
   * @default "#FFFFFF"
   */
  promoTextColor?: string;
  /**
   * Dropdown BG — pass as `collectionsDropdownBackground` not `dropdownBg`.
   * @default "#FFFFFF"
   */
  collectionsDropdownBackground?: string;
  /**
   * Dropdown Text — pass as `collectionsDropdownTextColor` not `dropdownText`.
   * @default "#000000"
   */
  collectionsDropdownTextColor?: string;
  /**
   * Show Plus Icons
   * @default true
   */
  showPlusIcons?: boolean;
  /**
   * Hotspot Links — pass as `plusIconItems` not `hotspotLinks`.
   */
  plusIconItems?: unknown[];
  /**
   * Plus Icon Color
   * @default "#000000"
   */
  plusIconColor?: string;
  /**
   * Plus Icon Background
   * @default "hsla(0, 0%, 100%, 0.85)"
   */
  plusIconBackground?: string;
  /**
   * Heading Font
   * @default {"fontSize":"32px","variant":"Regular","letterSpacing":"-0.02em","lineHeight":"1.2em"}
   */
  headingFont?: string;
  /**
   * Description Font
   * @default {"fontSize":"15px","variant":"Regular","letterSpacing":"0em","lineHeight":"1.5em"}
   */
  descriptionFont?: string;
  /**
   * Button Font
   * @default {"fontSize":"14px","variant":"Medium","letterSpacing":"0em","lineHeight":"1em"}
   */
  buttonFont?: string;
  /**
   * Nav Font
   * @default {"fontSize":"14px","variant":"Regular","letterSpacing":"0em","lineHeight":"1em"}
   */
  navFont?: string;
  /**
   * Promo Font
   * @default {"fontSize":"13px","variant":"Regular","letterSpacing":"0em","lineHeight":"1em"}
   */
  promoFont?: string;
  /**
   * Card Background
   * @default "#FFFFFF"
   */
  cardBackground?: string;
  /**
   * Heading Color — pass as `textColor` not `headingColor`.
   * @default "#000000"
   */
  textColor?: string;
  /**
   * Description Color
   * @default "#666666"
   */
  descriptionColor?: string;
  /**
   * Button Color — pass as `buttonTextColor` not `buttonColor`.
   * @default "#000000"
   */
  buttonTextColor?: string;
  /**
   * Arrow Color
   * @default "#FFFFFF"
   */
  arrowColor?: string;
  /**
   * Dot Color
   * @default "#FFFFFF"
   */
  dotColor?: string;
  /**
   * Active Dot Color
   * @default "#FFFFFF"
   */
  activeDotColor?: string;
  /**
   * Dark Header BG — pass as `darkHeaderBackground` not `darkHeaderBg`.
   * @default "#000000"
   */
  darkHeaderBackground?: string;
  /**
   * Dark Nav Text — pass as `darkNavTextColor` not `darkNavText`.
   * @default "#FFFFFF"
   */
  darkNavTextColor?: string;
  /**
   * Dark Icon Color
   * @default "#FFFFFF"
   */
  darkIconColor?: string;
  /**
   * Dark Card BG — pass as `darkCardBackground` not `darkCardBg`.
   * @default "#000000"
   */
  darkCardBackground?: string;
  /**
   * Dark Heading — pass as `darkTextColor` not `darkHeading`.
   * @default "#FFFFFF"
   */
  darkTextColor?: string;
  /**
   * Dark Description — pass as `darkDescriptionColor` not `darkDescription`.
   * @default "#CCCCCC"
   */
  darkDescriptionColor?: string;
  /**
   * Autoplay
   * @default false
   */
  autoplay?: boolean;
  /**
   * Autoplay Interval
   * Range: min: 1000, max: 10000, step: 500
   * @default 5000
   */
  autoplayInterval?: number;
  /** Additional properties */
  [key: string]: unknown;
}
