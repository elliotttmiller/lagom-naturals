export interface LiquidglassbuttonplusProps {
  /**
   * Label
   * @default "Get started"
   */
  label?: string;
  /**
   * Destination — pass as `link` not `destination`.
   * @default ""
   */
  link?: string;
  /**
   * Open in New Tab — pass as `newTab` not `openInNewTab`.
   * @default false
   */
  newTab?: boolean;
  /**
   * Material
   * Options: "clear" | "frosted" | "tinted"
   * @default "clear"
   */
  material?: 'clear' | 'frosted' | 'tinted';
  /**
   * Surface
   * Options: "light" | "dark"
   * @default "light"
   */
  surface?: 'light' | 'dark';
  /**
   * Glass Tint — pass as `tint` not `glassTint`.
   * @default "#FFFFFF"
   */
  tint?: string;
  /**
   * Text Color
   */
  textColor?: string;
  /**
   * Font
   * @default {"fontSize":"18px","variant":"Semibold","letterSpacing":"-0.015em","lineHeight":"1.25em"}
   */
  font?: string;
  /**
   * Icon
   * Options: "chevron" | "custom" | "none" | "arrow" | "diagonal" | "plus"
   * @default "chevron"
   */
  icon?: 'chevron' | 'custom' | 'none' | 'arrow' | 'diagonal' | 'plus';
  /**
   * Icon Layer
   */
  iconLayer?: string;
  /**
   * Icon Position
   * Options: "left" | "right"
   * @default "right"
   */
  iconPosition?: 'left' | 'right';
  /**
   * Radius
   * @default "999px"
   */
  radius?: string;
  /**
   * Padding
   * @default "20px 30px"
   */
  padding?: string;
  /**
   * Gap
   * @default "10px"
   */
  gap?: string;
  /**
   * Optics — pass as `glass` not `optics`.
   * @default {"blur":2.5,"shoulder":10,"refraction":65}
   */
  glass?: Record<string, unknown>;
  /**
   * Interaction
   * @default true
   */
  interaction?: boolean;
  /**
   * Hover Transition
   * @default {"type":"spring","stiffness":125,"damping":25,"mass":0.65}
   */
  hoverTransition?: object;
  /**
   * Light Follow
   * Range: min: 0, max: 100
   * @default 75
   */
  lightFollow?: number;
  /**
   * Disabled
   * @default false
   */
  disabled?: boolean;
  /**
   * On Tap
   */
  onTap?: () => void;
  /**
   * Focus Ring — pass as `focusColor` not `focusRing`.
   * @default "#596B91"
   */
  focusColor?: string;
  /** Additional properties */
  [key: string]: unknown;
}
