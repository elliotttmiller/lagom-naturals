var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/rfqTcWKuiRILKfqHFsPc/y7tM3V9YGLt9tBHu2Y4O/LiquidGlassButtonPlus.js
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from "react";
import { addPropertyControls, ControlType, useIsStaticRenderer } from "./_framer-runtime.js";
import { motion, animate, useMotionValue, useSpring, useTransform, useMotionTemplate, useReducedMotion } from "framer-motion";
function normalizeGlassRadii(width, height, radius) {
  const values = typeof radius === "number" ? [radius, radius, radius, radius] : radius;
  const radii = values.map((value) => Number.isFinite(value) ? Math.max(0, value) : 0);
  if (radii.every((value) => value === radii[0])) {
    const r = Math.min(radii[0], width / 2, height / 2);
    return [r, r, r, r];
  }
  const [tl, tr, br, bl] = radii;
  const scale = Math.min(1, width / (tl + tr), width / (bl + br), height / (tl + bl), height / (tr + br));
  return [tl * scale, tr * scale, br * scale, bl * scale];
}
function createGlassBoundarySampler(width, height, radii) {
  const [tl, tr, br, bl] = radii;
  const segments = [[tl, 0, width - tr, 0], [width, tr, width, height - br], [bl, height, width - br, height], [0, tl, 0, height - bl]];
  const arcs = [{ x: tl, y: tl, r: tl, sx: -1, sy: -1 }, { x: width - tr, y: tr, r: tr, sx: 1, sy: -1 }, { x: width - br, y: height - br, r: br, sx: 1, sy: 1 }, { x: bl, y: height - bl, r: bl, sx: -1, sy: 1 }].filter((arc) => arc.r > 0);
  const result = { distance: 0, nx: 0, ny: 0 };
  return (x, y) => {
    if (x < 0 || x > width || y < 0 || y > height)
      return null;
    for (const arc of arcs) {
      const dx = x - arc.x;
      const dy = y - arc.y;
      if (dx * arc.sx >= 0 && dy * arc.sy >= 0 && dx * dx + dy * dy > arc.r * arc.r)
        return null;
    }
    let bestSquared = Infinity;
    let normalX = 0;
    let normalY = 0;
    const consider = (bx, by) => {
      const dx = bx - x;
      const dy = by - y;
      const squared = dx * dx + dy * dy;
      const epsilon = 1e-10 * Math.max(1, squared, Number.isFinite(bestSquared) ? bestSquared : 0);
      if (squared < bestSquared - epsilon) {
        bestSquared = squared;
        normalX = dx;
        normalY = dy;
      } else if (Math.abs(squared - bestSquared) <= epsilon) {
        normalX += dx;
        normalY += dy;
      }
    };
    for (const [ax, ay, bx, by] of segments) {
      const dx = bx - ax;
      const dy = by - ay;
      const lengthSquared = dx * dx + dy * dy;
      const t = lengthSquared > 0 ? Math.max(0, Math.min(1, ((x - ax) * dx + (y - ay) * dy) / lengthSquared)) : 0;
      consider(ax + t * dx, ay + t * dy);
    }
    for (const arc of arcs) {
      const dx = x - arc.x;
      const dy = y - arc.y;
      if (dx * arc.sx < 0 || dy * arc.sy < 0)
        continue;
      const length = Math.hypot(dx, dy);
      const nx = length > 1e-12 ? dx / length : arc.sx * Math.SQRT1_2;
      const ny = length > 1e-12 ? dy / length : arc.sy * Math.SQRT1_2;
      consider(arc.x + nx * arc.r, arc.y + ny * arc.r);
    }
    result.distance = Math.sqrt(bestSquared);
    const normalLength = Math.hypot(normalX, normalY);
    result.nx = normalLength > 1e-12 ? normalX / normalLength : 0;
    result.ny = normalLength > 1e-12 ? normalY / normalLength : 0;
    return result;
  };
}
function makeGlassMaps(width, height, radius, shoulder) {
  const empty = { displacement: "", highlight: "" };
  if (typeof document === "undefined")
    return empty;
  const finitePositive = (value, fallback) => Number.isFinite(value) && value > 0 ? value : fallback;
  const w = finitePositive(width, 1);
  const h = finitePositive(height, 1);
  const halfW = w / 2;
  const halfH = h / 2;
  const radii = normalizeGlassRadii(w, h, radius);
  const uniform = radii.every((value) => value === radii[0]);
  const r = radii[0];
  const sampleBoundary = uniform ? null : createGlassBoundarySampler(w, h, radii);
  const requestedShoulder = finitePositive(shoulder, 6);
  const rim = Math.min(requestedShoulder, halfW, halfH);
  const limitPixels = 98304;
  const factor = Math.min(1.5, 768 / w, 768 / h, Math.sqrt(limitPixels / w / h));
  const mapW = Math.max(1, Math.floor(w * factor));
  const mapH = Math.max(1, Math.floor(h * factor));
  const sampleW = w / mapW;
  const sampleH = h / mapH;
  const footprint = Math.max(sampleW, sampleH);
  const clamp01 = (value) => Math.max(0, Math.min(1, value));
  try {
    const canvas = document.createElement("canvas");
    canvas.width = mapW;
    canvas.height = mapH;
    const context = canvas.getContext("2d");
    if (!context)
      return empty;
    const field = context.createImageData(mapW, mapH);
    const light = context.createImageData(mapW, mapH);
    const a = field.data;
    const b = light.data;
    const lightX = -0.5547;
    const lightY = -0.83205;
    for (let y = 0; y < mapH; y++) {
      const py = (y + 0.5) * sampleH - halfH;
      for (let x = 0; x < mapW; x++) {
        const index = (y * mapW + x) * 4;
        a[index] = 128;
        a[index + 1] = 128;
        a[index + 2] = 128;
        a[index + 3] = 255;
        const px = (x + 0.5) * sampleW - halfW;
        let inwardDistance;
        let nx;
        let ny;
        if (uniform) {
          const qx = Math.abs(px) - (halfW - r);
          const qy = Math.abs(py) - (halfH - r);
          const ox = Math.max(qx, 0);
          const oy = Math.max(qy, 0);
          const outerDistance = Math.hypot(ox, oy);
          inwardDistance = -(outerDistance + Math.min(Math.max(qx, qy), 0) - r);
          if (inwardDistance <= 0 || inwardDistance >= rim)
            continue;
          const sx = px < 0 ? -1 : 1;
          const sy = py < 0 ? -1 : 1;
          if (outerDistance > 1e-6) {
            nx = ox / outerDistance * sx;
            ny = oy / outerDistance * sy;
          } else if (qx > qy) {
            nx = sx;
            ny = 0;
          } else if (qy > qx) {
            nx = 0;
            ny = sy;
          } else {
            nx = sx * Math.SQRT1_2;
            ny = sy * Math.SQRT1_2;
          }
        } else {
          const boundary = sampleBoundary(px + halfW, py + halfH);
          if (!boundary || boundary.distance <= 0 || boundary.distance >= rim)
            continue;
          inwardDistance = boundary.distance;
          nx = boundary.nx;
          ny = boundary.ny;
        }
        const u = inwardDistance / rim;
        const bell = Math.sin(Math.PI * u) ** 2;
        const magnitude = 0.58 * bell * rim / requestedShoulder;
        a[index] = Math.round(127.5 - 127.5 * nx * magnitude);
        a[index + 1] = Math.round(127.5 - 127.5 * ny * magnitude);
        const facing = nx * lightX + ny * lightY;
        const bright = Math.max(0, facing) ** 1.7;
        const dark = Math.max(0, -facing) ** 1.6;
        const narrowBand = Math.exp(-Math.pow((u - 0.16) / 0.19, 2));
        const softBand = Math.exp(-Math.pow((u - 0.34) / 0.34, 2));
        const coverage = clamp01(inwardDistance / footprint + 0.5);
        const fade = (1 - u) ** 1.2;
        const signedLight = (0.72 * bright * narrowBand - 0.14 * dark * softBand) * fade;
        const tone = signedLight >= 0 ? 255 : 0;
        b[index] = tone;
        b[index + 1] = tone;
        b[index + 2] = tone;
        b[index + 3] = Math.round(255 * Math.abs(signedLight) * coverage);
      }
    }
    context.putImageData(field, 0, 0);
    const displacement = canvas.toDataURL("image/png");
    context.putImageData(light, 0, 0);
    const highlight = canvas.toDataURL("image/png");
    canvas.width = 1;
    canvas.height = 1;
    return { displacement, highlight };
  } catch {
    return empty;
  }
}
var styles = `
@font-face{font-family:"Liquid Glass Buttons Manrope";font-style:normal;font-weight:600;font-display:swap;src:url("https://framerusercontent.com/third-party-assets/fontshare/wf/6U2SGH566NSNERG6RGEV3DSNEK7DL2RF/JRDYRKMSAW2H35IWEQIPL67HAJQ35MG5/JNU3GNMUBPWW6V6JTED3S27XL5HN7NM5.woff2") format("woff2");}
.ml-optical-button{appearance:none;-webkit-appearance:none;position:relative;display:inline-flex;align-items:stretch;justify-content:center;max-width:100%;min-width:48px;min-height:48px;padding:0;border:0;background:none;border-radius:var(--og-radius);color:var(--og-text);font:inherit;line-height:1.25;text-decoration:none;outline:none;cursor:pointer;user-select:none;-webkit-tap-highlight-color:transparent;touch-action:manipulation;perspective:900px;vertical-align:middle;-webkit-font-smoothing:antialiased;}
.ml-optical-button,.ml-optical-button *{box-sizing:border-box}
.ml-optical-face{position:relative;display:flex;align-items:center;justify-content:center;gap:var(--og-gap);width:100%;min-height:48px;height:100%;padding:var(--og-padding);border-radius:inherit;transform-style:flat;isolation:isolate;}
.ml-optical-body{position:absolute;inset:0;pointer-events:none;border-radius:inherit;box-shadow:0 1px 1px #00000028,0 4px 5px -3px #00000038,0 12px 20px -10px #00000035;}
.ml-optical-surface{position:absolute;inset:0;overflow:hidden;border-radius:inherit;background:linear-gradient(150deg,#ffffff32,#ffffff08 42%,#ffffff24);backdrop-filter:blur(var(--og-blur)) saturate(1.08);-webkit-backdrop-filter:blur(var(--og-blur)) saturate(1.08);box-shadow:inset 0 1px 1px #ffffffcc,inset 0 -1px 1px #ffffffaa,inset 1px 0 .5px #ffffffaa,inset -1px 0 .5px #00000020;}
.ml-optical-tint{position:absolute;inset:0;background:var(--og-tint);opacity:var(--og-tint-alpha);}
.ml-optical-shoulder{position:absolute;inset:0;border-radius:inherit;box-shadow:inset 0 9px 12px -8px #00000070,inset 0 -9px 9px -7px #ffffffed,inset 5px 0 8px -7px #0000006b,inset -5px 0 8px -7px #0000004d;}
.ml-optical-normal{position:absolute;inset:0;width:100%;height:100%;opacity:.8;border-radius:inherit;}
.ml-optical-rim{position:absolute;inset:0;padding:1.25px;border-radius:inherit;-webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);-webkit-mask-composite:xor;mask-composite:exclude;}
.ml-optical-pointer-light{position:absolute;inset:0;border-radius:inherit;pointer-events:none;}
.ml-optical-reflection{position:absolute;inset:-45% -50%;transform-origin:50% 50%;background:linear-gradient(112deg,#fff0 27%,#ffffff03 32%,#ffffff42 42%,#ffffff66 46%,#ffffff18 53%,#fff0 61%);will-change:transform;}
.ml-optical-caustic{position:absolute;left:10%;bottom:1px;width:44%;height:2px;border-radius:100%;background:linear-gradient(90deg,#fff0,#ffffffed 48%,#fff0);filter:blur(.35px);}
.ml-optical-bottom{position:absolute;left:14%;right:14%;bottom:1.25px;height:1px;background:linear-gradient(90deg,#fff0 0%,#ffffff08 20%,#ffffffcf 53%,#ffffff12 86%,#fff0);border-radius:100%;opacity:.8;}
.ml-optical-label{position:relative;z-index:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none;text-shadow:var(--og-text-shadow);}
.ml-optical-icon{position:relative;z-index:1;display:flex;align-items:center;flex-shrink:0;pointer-events:none;opacity:1;}
.ml-optical-button[data-disabled=true]{cursor:not-allowed;opacity:.45;}
.ml-optical-button:focus-visible{outline:2px solid var(--og-focus);outline-offset:5px;}
.ml-optical-button[data-surface=dark] .ml-optical-surface{background:linear-gradient(155deg,#ffffff14,#ffffff03 48%,#ffffff08);}
.ml-optical-button[data-material=frosted] .ml-optical-tint{opacity:.3}
.ml-optical-button[data-material=tinted] .ml-optical-tint{opacity:.28}
@media(prefers-reduced-motion:reduce){.ml-optical-button *{transition:none!important}.ml-optical-face{transform:none!important}}
@media(prefers-reduced-transparency:reduce){.ml-optical-button .ml-optical-surface{backdrop-filter:none!important;-webkit-backdrop-filter:none!important;background:#d5d7da}.ml-optical-button[data-surface=dark] .ml-optical-surface{background:#303239}}
@supports not ((backdrop-filter:blur(1px)) or (-webkit-backdrop-filter:blur(1px))){.ml-optical-button .ml-optical-surface{background:#d5d7da}.ml-optical-button[data-surface=dark] .ml-optical-surface{background:#303239}}
@media(forced-colors:active){.ml-optical-button{border:2px solid ButtonText;color:ButtonText!important}.ml-optical-body{display:none}.ml-optical-button:focus-visible{outline-color:Highlight}.ml-optical-label{text-shadow:none}}
`;
function LiquidGlassButtons(props) {
  const { label = "Get started", link = "", newTab = false, material = "clear", surface = "light", tint = "#FFFFFF", textColor, font = {}, icon = "chevron", iconLayer, iconPosition = "right", radius = "999px", padding = "20px 30px", gap = "10px", hoverTransition = { type: "spring", stiffness: 125, damping: 25, mass: 0.65 }, glass = {}, interaction = true, lightFollow = 75, disabled = false, onTap, focusColor = "#596B91", style } = props;
  const radiusCSS = typeof radius === "number" ? `${Math.max(0, radius)}px` : radius || "999px";
  const isStatic = useIsStaticRenderer();
  const reduced = useReducedMotion();
  const enabled = interaction && !isStatic && !reduced && !disabled;
  const [hovered, setHovered] = React.useState(false);
  const [pressed, setPressed] = React.useState(false);
  const activeHover = enabled && hovered;
  const activePress = enabled && pressed;
  const rootRef = React.useRef(null);
  const [optics, setOptics] = React.useState(null);
  const [refractionSupported, setRefractionSupported] = React.useState(false);
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const px = useSpring(rawX, { stiffness: 250, damping: 29, mass: 0.45 });
  const py = useSpring(rawY, { stiffness: 250, damping: 29, mass: 0.45 });
  const engagement = useMotionValue(0);
  const opticalEngagement = useTransform(engagement, (h) => Math.max(0, Math.min(1, h)));
  const pressure = useSpring(0, { stiffness: 420, damping: 32, mass: 0.6 });
  const transitionKey = JSON.stringify(hoverTransition);
  React.useEffect(() => {
    if (!enabled) {
      engagement.jump(0);
      return;
    }
    const playback = animate(engagement, activeHover ? 1 : 0, hoverTransition);
    return () => playback.stop();
  }, [activeHover, enabled, transitionKey]);
  React.useEffect(() => {
    if (enabled)
      pressure.set(activePress ? 1 : 0);
    else
      pressure.jump(0);
  }, [activePress, enabled]);
  const rx = useTransform([py, engagement, pressure], ([y, h, p]) => -Number(y) * Number(h) * 0.45 + Number(p) * 2.4);
  const ry = useTransform([px, engagement], ([x, h]) => Number(x) * Number(h) * 0.75);
  const faceY = useTransform([engagement, pressure], ([h, p]) => -0.65 * Number(h) + 1.8 * Number(p));
  const faceScaleX = useTransform(pressure, [0, 1], [1, 0.991]);
  const faceScaleY = useTransform(pressure, [0, 1], [1, 0.974]);
  const reflectionX = useTransform([px, engagement], ([x, h]) => `${-30 + Number(h) * 36 + Number(x) * Number(h) * 9}%`);
  const reflectionY = useTransform([py, engagement], ([y, h]) => Number(y) * Number(h) * 5);
  const reflectionOpacity = useTransform(opticalEngagement, (h) => 0.16 + 0.18 * h + 0.08 * Math.sin(Math.PI * h));
  const follow = Math.max(0, Math.min(100, lightFollow)) / 100;
  const lightX = useTransform(px, (x) => 50 + x * 44);
  const lightY = useTransform(py, (y) => 50 + y * 38);
  const oppositeX = useTransform(lightX, (x) => 100 - x);
  const oppositeY = useTransform(lightY, (y) => 100 - y);
  const localLightOpacity = useTransform([opticalEngagement, pressure], ([h, p]) => Number(h) * follow * (1 - Number(p) * 0.18));
  const pointerLight = useMotionTemplate`radial-gradient(ellipse 76px 44px at ${lightX}% ${lightY}%, #ffffff2b 0%, #ffffff12 36%, #ffffff00 78%)`;
  const edgeLight = useMotionTemplate`radial-gradient(ellipse 90px 48px at ${lightX}% ${lightY}%, #ffffffff 0%, #ffffffb8 32%, #ffffff00 82%)`;
  const counterLight = useMotionTemplate`radial-gradient(ellipse 70px 36px at ${oppositeX}% ${oppositeY}%, #ffffffa6 0%, #ffffff35 35%, #ffffff00 82%)`;
  const causticX = useTransform([px, engagement], ([x, h]) => `${Number(h) * 75 + Number(x) * Number(h) * 55}%`);
  const causticOpacity = useTransform(engagement, [0, 1], [0.1, 0.72]);
  const lightAngle = useTransform([px, engagement], ([x, h]) => 180 + Number(x) * Number(h) * 12 - Number(h) * 24);
  const bodyShadow = useTransform([opticalEngagement, pressure], ([h, p]) => {
    const lift = Number(h) * (1 - Number(p));
    return `0 1px 1px #00000028,0 ${4 + lift * 1.5 - Number(p) * 2}px ${5 + lift * 1.5 - Number(p) * 2}px -3px #00000038,0 ${12 + lift * 2 - Number(p) * 8}px ${20 + lift * 3 - Number(p) * 11}px -10px #00000035`;
  });
  const shoulderShadow = useTransform([opticalEngagement, pressure], ([h, p]) => {
    const v = Number(h) * (1 - Number(p) * 0.4);
    return `inset 0 ${9 - v * 2.5}px ${12 - v * 2}px -8px #00000070,inset 0 ${-9 + v * 2}px 9px -7px #ffffffed,inset 5px 0 8px -7px #0000006b,inset -5px 0 8px -7px #0000004d`;
  });
  const rim = useMotionTemplate`conic-gradient(from ${lightAngle}deg at 50% 50%, #ffffffdf 0deg, #ffffff60 36deg, #ffffff05 68deg, #00000021 112deg, #ffffff18 155deg, #ffffff 190deg, #ffffffb3 217deg, #ffffff06 256deg, #0000000f 300deg, #ffffff15 335deg, #ffffffdf 360deg)`;
  const shoulder = Math.max(3, Math.min(12, glass.shoulder ?? 10));
  const blur = Math.max(0, Math.min(20, glass.blur ?? 2.5));
  const refraction = Math.max(0, Math.min(100, glass.refraction ?? 65)) / 100;
  const id = `optical-${React.useId().replace(/[^a-zA-Z0-9]/g, "")}`;
  const dark = surface === "dark";
  const restingBlur = material === "frosted" ? blur + 9 : blur;
  const activeBlur = material === "frosted" ? blur + 9 : blur * 0.12;
  const hasLink = typeof link === "string" && Boolean(link.trim());
  const Tag = hasLink && !disabled ? "a" : "button";
  React.useEffect(() => {
    const ua = __dai_navigator.userAgent;
    setRefractionSupported(/(?:Chrome|Chromium|Edg)\//.test(ua) && !/iPhone|iPad|iPod/.test(ua) && !(__dai_navigator.platform === "MacIntel" && __dai_navigator.maxTouchPoints > 1));
    const el = rootRef.current;
    if (!el)
      return;
    let timer;
    let last = "";
    const measure = () => {
      const width = Math.round(el.offsetWidth);
      const height = Math.round(el.offsetHeight);
      if (!width || !height)
        return;
      const computed = __dai_window.getComputedStyle(el);
      const cornerValues = [computed.borderTopLeftRadius, computed.borderTopRightRadius, computed.borderBottomRightRadius, computed.borderBottomLeftRadius];
      if (cornerValues.some((value) => value.includes("%") || value.trim().includes(" "))) {
        setOptics(null);
        return;
      }
      const corners = cornerValues.map((value) => Math.max(0, Number.parseFloat(value) || 0));
      const key = `${width}-${height}-${corners.join("-")}-${shoulder}`;
      if (key === last)
        return;
      last = key;
      try {
        const maps = makeGlassMaps(width, height, corners, shoulder);
        setOptics(maps.displacement && maps.highlight ? { ...maps, width, height } : null);
      } catch {
        setOptics(null);
      }
    };
    measure();
    const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(() => {
      __dai_window.clearTimeout(timer);
      timer = __dai_window.setTimeout(measure, 90);
    }) : null;
    ro?.observe(el);
    return () => {
      ro?.disconnect();
      __dai_window.clearTimeout(timer);
    };
  }, [radiusCSS, shoulder, Tag]);
  const leave = () => {
    setHovered(false);
    setPressed(false);
  };
  React.useEffect(() => {
    if (!enabled) {
      leave();
      rawX.set(0);
      rawY.set(0);
      px.jump(0);
      py.jump(0);
    }
  }, [enabled]);
  const move = (event) => {
    if (!enabled || event.pointerType !== "mouse")
      return;
    setHovered(true);
    const r = event.currentTarget.getBoundingClientRect();
    rawX.set(Math.max(-1, Math.min(1, (event.clientX - r.left) / r.width * 2 - 1)));
    rawY.set(Math.max(-1, Math.min(1, (event.clientY - r.top) / r.height * 2 - 1)));
  };
  const rootStyle = { width: "max-content", height: "auto", ...style, fontFamily: '"Liquid Glass Buttons Manrope", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif', fontSize: 18, fontWeight: 600, letterSpacing: "-0.015em", ...font, "--og-radius": radiusCSS, "--og-padding": padding, "--og-gap": gap, "--og-text": textColor || (dark ? "#F6F7FA" : "#26282D"), "--og-tint": tint, "--og-tint-alpha": material === "frosted" ? 0.3 : material === "tinted" ? 0.28 : 0.045, "--og-blur": `${restingBlur}px`, "--og-focus": focusColor, "--og-text-shadow": dark ? "0 1px 2px #00000045" : "0 1px 1px #ffffff45" };
  const useRefraction = optics && refractionSupported && refraction > 0;
  const smoothBlur = useTransform(opticalEngagement, (h) => restingBlur + (activeBlur - restingBlur) * h);
  const tintOpacity = useTransform(opticalEngagement, (h) => material === "clear" ? 0.045 - 0.025 * h : material === "frosted" ? 0.3 : 0.28);
  const filter = useMotionTemplate`${useRefraction ? `url(#${id}) ` : ""}blur(${smoothBlur}px) saturate(1.08)`;
  const fallbackFilter = useMotionTemplate`blur(${smoothBlur}px) saturate(1.08)`;
  const fallbackGlyph = /* @__PURE__ */ _jsx("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.25", strokeLinecap: "round", strokeLinejoin: "round", children: icon === "arrow" ? /* @__PURE__ */ _jsx("path", { d: "M5 12h14M12 5l7 7-7 7" }) : icon === "diagonal" ? /* @__PURE__ */ _jsx("path", { d: "M6 18 18 6M6 6h12v12" }) : icon === "plus" ? /* @__PURE__ */ _jsx("path", { d: "M5 12h14M12 5v14" }) : /* @__PURE__ */ _jsx("path", { d: "m9.5 6.5 5.5 5.5-5.5 5.5" }) });
  const customGlyph = icon === "custom" && React.Children.count(iconLayer) > 0;
  const glyph = icon === "none" ? null : /* @__PURE__ */ _jsx("span", { className: "ml-optical-icon", "aria-hidden": "true", ref: (node) => {
    if (node)
      node.toggleAttribute("inert", customGlyph);
  }, children: customGlyph ? iconLayer : fallbackGlyph });
  return /* @__PURE__ */ _jsxs(Tag, { ref: rootRef, className: "ml-optical-button", style: rootStyle, draggable: false, href: Tag === "a" ? link : void 0, target: Tag === "a" && newTab ? "_blank" : void 0, rel: Tag === "a" && newTab ? "noopener noreferrer" : void 0, type: Tag === "button" ? "button" : void 0, disabled: Tag === "button" ? disabled : void 0, "aria-label": label?.trim() || "Continue", "aria-disabled": disabled || void 0, "data-disabled": disabled, "data-hover": activeHover, "data-pressed": activePress, "data-material": material, "data-surface": surface, onPointerEnter: move, onPointerMove: move, onPointerLeave: leave, onPointerCancel: leave, onPointerDown: (event) => {
    if (event.button === 0 && enabled) {
      move(event);
      setPressed(true);
    }
  }, onPointerUp: () => setPressed(false), onKeyDown: (event) => {
    if (enabled && (event.key === "Enter" || Tag === "button" && event.key === " "))
      setPressed(true);
  }, onKeyUp: () => setPressed(false), onBlur: () => setPressed(false), onClick: (event) => {
    if (disabled || isStatic) {
      event.preventDefault();
      return;
    }
    onTap?.();
  }, children: [/* @__PURE__ */ _jsx("style", { children: styles }), useRefraction && /* @__PURE__ */ _jsx("svg", { "aria-hidden": "true", focusable: "false", width: "0", height: "0", style: { position: "absolute", pointerEvents: "none" }, children: /* @__PURE__ */ _jsx("defs", { children: /* @__PURE__ */ _jsxs("filter", { id, x: "0", y: "0", width: optics.width, height: optics.height, filterUnits: "userSpaceOnUse", colorInterpolationFilters: "sRGB", children: [/* @__PURE__ */ _jsx("feImage", { href: optics.displacement, x: "0", y: "0", width: optics.width, height: optics.height, preserveAspectRatio: "none", result: "map" }), /* @__PURE__ */ _jsx("feDisplacementMap", { in: "SourceGraphic", in2: "map", scale: 2 * shoulder * refraction, xChannelSelector: "R", yChannelSelector: "G" })] }) }) }), /* @__PURE__ */ _jsxs(motion.span, { className: "ml-optical-face", style: { rotateX: enabled ? rx : 0, rotateY: enabled ? ry : 0, y: enabled ? faceY : 0, scaleX: enabled ? faceScaleX : 1, scaleY: enabled ? faceScaleY : 1 }, children: [/* @__PURE__ */ _jsxs(motion.span, { className: "ml-optical-body", "aria-hidden": "true", style: { boxShadow: bodyShadow }, children: [/* @__PURE__ */ _jsxs(motion.span, { className: "ml-optical-surface", style: { backdropFilter: filter, WebkitBackdropFilter: refractionSupported ? filter : fallbackFilter }, children: [/* @__PURE__ */ _jsx(motion.span, { className: "ml-optical-tint", style: { opacity: tintOpacity } }), /* @__PURE__ */ _jsx(motion.span, { className: "ml-optical-shoulder", style: { boxShadow: shoulderShadow } }), optics && /* @__PURE__ */ _jsx("img", { className: "ml-optical-normal", src: optics.highlight, alt: "", draggable: false }), /* @__PURE__ */ _jsx(motion.span, { className: "ml-optical-reflection", style: { x: reflectionX, y: reflectionY, opacity: reflectionOpacity } }), /* @__PURE__ */ _jsx(motion.span, { className: "ml-optical-caustic", style: { x: causticX, opacity: causticOpacity } }), /* @__PURE__ */ _jsx(motion.span, { className: "ml-optical-pointer-light", style: { background: pointerLight, opacity: localLightOpacity } })] }), /* @__PURE__ */ _jsx(motion.span, { className: "ml-optical-rim", style: { background: rim } }), /* @__PURE__ */ _jsx(motion.span, { className: "ml-optical-rim ml-optical-edge-light", style: { background: edgeLight, opacity: localLightOpacity } }), /* @__PURE__ */ _jsx(motion.span, { className: "ml-optical-rim ml-optical-counter-light", style: { background: counterLight, opacity: localLightOpacity } }), /* @__PURE__ */ _jsx("span", { className: "ml-optical-bottom" })] }), iconPosition === "left" && glyph, /* @__PURE__ */ _jsx("span", { className: "ml-optical-label", children: label?.trim() || "Continue" }), iconPosition === "right" && glyph] })] });
}
LiquidGlassButtons.displayName = "Liquid Glass Buttons";
addPropertyControls(LiquidGlassButtons, { label: { type: ControlType.String, title: "Label", defaultValue: "Get started" }, link: { type: ControlType.Link, title: "Destination", defaultValue: "" }, newTab: { type: ControlType.Boolean, title: "Open in New Tab", defaultValue: false }, material: { type: ControlType.Enum, title: "Material", options: ["clear", "frosted", "tinted"], optionTitles: ["Clear", "Frosted", "Tinted"], defaultValue: "clear" }, surface: { type: ControlType.Enum, title: "Surface", options: ["light", "dark"], optionTitles: ["On Light", "On Dark"], defaultValue: "light", displaySegmentedControl: true, description: "Match the background to keep the label readable." }, tint: { type: ControlType.Color, title: "Glass Tint", defaultValue: "#FFFFFF" }, textColor: { type: ControlType.Color, title: "Text Color", optional: true }, font: { type: ControlType.Font, title: "Font", controls: "extended", defaultFontType: "sans-serif", defaultValue: { fontSize: "18px", variant: "Semibold", letterSpacing: "-0.015em", lineHeight: "1.25em" } }, icon: { type: ControlType.Enum, title: "Icon", options: ["chevron", "custom", "none", "arrow", "diagonal", "plus"], optionTitles: ["Chevron", "Custom Layer", "None", "Arrow Right", "Arrow Up Right", "Plus"], defaultValue: "chevron" }, iconLayer: { type: ControlType.Slot, title: "Icon Layer", maxCount: 1, hidden: (p) => p.icon !== "custom", description: "Connect a native Framer icon or a small decorative layer. Edit its icon, size and color on the canvas." }, iconPosition: { type: ControlType.Enum, title: "Icon Position", options: ["left", "right"], optionTitles: ["Left", "Right"], defaultValue: "right", displaySegmentedControl: true, hidden: (p) => p.icon === "none" }, radius: { type: ControlType.BorderRadius, title: "Radius", defaultValue: "999px" }, padding: { type: ControlType.Padding, title: "Padding", defaultValue: "20px 30px" }, gap: { type: ControlType.Gap, title: "Gap", defaultValue: "10px" }, glass: { type: ControlType.Object, title: "Optics", icon: "effect", controls: { blur: { type: ControlType.Number, title: "Blur", min: 0, max: 20, step: 0.5, defaultValue: 2.5, unit: "px", description: "Frosted adds 9 px to the chosen blur." }, shoulder: { type: ControlType.Number, title: "Glass Depth", min: 3, max: 12, defaultValue: 10, unit: "px" }, refraction: { type: ControlType.Number, title: "Refraction", min: 0, max: 100, defaultValue: 65, unit: "%", description: "Enhanced edge refraction in Chromium. Other browsers use the polished glass fallback." } }, defaultValue: { blur: 2.5, shoulder: 10, refraction: 65 } }, interaction: { type: ControlType.Boolean, title: "Interaction", defaultValue: true, description: "Soft reflections and edge light respond to the pointer in two dimensions. Respects Reduced Motion." }, hoverTransition: { type: ControlType.Transition, title: "Hover Transition", defaultValue: { type: "spring", stiffness: 125, damping: 25, mass: 0.65 }, hidden: (p) => !p.interaction }, lightFollow: { type: ControlType.Number, title: "Light Follow", min: 0, max: 100, defaultValue: 75, unit: "%", hidden: (p) => !p.interaction, description: "Strength of the local reflection and edge light that follow the pointer." }, disabled: { type: ControlType.Boolean, title: "Disabled", defaultValue: false }, onTap: { type: ControlType.EventHandler, title: "On Tap" }, focusColor: { type: ControlType.Color, title: "Focus Ring", defaultValue: "#596B91", description: "Keyboard focus color.\n\nBuilt by Matthias \xD6lschlegel \u{1F4AA}\n\n[Explore more components](https://framer.link/fsd2pgh)" } });
var __FramerMetadata__ = { "exports": { "default": { "type": "reactComponent", "name": "LiquidGlassButtons", "slots": ["iconLayer"], "annotations": { "framerDisableUnlink": "", "framerIntrinsicHeight": "72", "framerSupportedLayoutWidth": "any-prefer-fixed", "framerContractVersion": "1", "framerIntrinsicWidth": "244", "framerSupportedLayoutHeight": "any-prefer-fixed" } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  LiquidGlassButtons as default
};
