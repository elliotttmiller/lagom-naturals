export interface KmrigprvuProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Closed Desktop" → j3vKmqMd1
   *   "Download Desktop" → LiWpul7sh
   *   "Make changes here" → yj0PI9eX9
   *   "Phone Closed" → M25JonZj3
   *   "Phone Open" → kRARa8ZJd
   *   "Product Desktop" → IkBtFPdPg
   */
  variant?: 'Closed Desktop' | 'Download Desktop' | 'Make changes here' | 'Phone Closed' | 'Phone Open' | 'Product Desktop' | 'yj0PI9eX9' | 'j3vKmqMd1' | 'IkBtFPdPg' | 'LiWpul7sh' | 'kRARa8ZJd' | 'M25JonZj3';
  /** Additional properties */
  [key: string]: unknown;
}
