var __dai_window=typeof window!=="undefined"?window:undefined;var __dai_navigator=typeof __dai_window!=="undefined"?navigator:undefined;

// http-url:https://framerusercontent.com/modules/lCP9cuWiD4vVMNew3vjv/kR90p8CxkIlZ7L6xYHsR/Rw0sr50sZ.js
import { jsx as _jsx3, jsxs as _jsxs2 } from "react/jsx-runtime";
import { addFonts, addPropertyControls as addPropertyControls3, ComponentViewportProvider, ControlType as ControlType3, cx as cx2, getFonts, Instance, SmartComponentScopedContainer, useComponentViewport, useLocaleInfo, useVariantState, withCSS as withCSS2 } from "./_framer-runtime.js";
import { LayoutGroup, motion as motion2, MotionConfigContext } from "framer-motion";
import * as React2 from "react";
import { useRef as useRef2 } from "react";

// http-url:https://framerusercontent.com/modules/4D3ftnrCKMi9sZxy9KN9/VIt1WEwa4r1PfvCESAKj/Qd5CLrGSO.js
import { jsx as _jsx } from "react/jsx-runtime";
import { addPropertyControls, ControlType, cx, motion, useSVGTemplate, withCSS } from "./_framer-runtime.js";
import * as React from "react";
import { forwardRef as forwardRef2 } from "react";
var mask = "var(--framer-icon-mask)";
var Base = /* @__PURE__ */ forwardRef2(function(props, ref) {
  return /* @__PURE__ */ _jsx("svg", { ...props, ref, children: props.children });
});
var MotionSVG = motion.create(Base);
var SVG = /* @__PURE__ */ forwardRef2((props, ref) => {
  const { animated, layoutId, children, ...rest } = props;
  return animated ? /* @__PURE__ */ _jsx(MotionSVG, { ...rest, layoutId, ref, children }) : /* @__PURE__ */ _jsx("svg", { ...rest, ref, children });
});
var svg = '<svg display="block" role="presentation" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M 2 14.5 L 12.5 14.5 C 13.605 14.5 14.5 13.605 14.5 12.5 L 14.5 5 L 7.25 0 L 0 5 L 0 12.5 C 0 13.605 0.895 14.5 2 14.5 Z" fill="transparent" height="14.49996px" id="lLOiAXUCt" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--1335ju, 1.5)" stroke="var(--18mrqx2, rgb(0, 0, 0))" transform="translate(4.75 4.75)" width="14.49996px"/><path d="M 0 2 C 0 0.895 0.895 0 2 0 L 2.5 0 C 3.605 0 4.5 0.895 4.5 2 L 4.5 5.5 L 0 5.5 Z" fill="transparent" height="5.500000000000002px" id="FFcYQg9ko" stroke-dasharray="" stroke-linecap="round" stroke-linejoin="round" stroke-width="var(--1335ju, 1.5)" stroke="var(--18mrqx2, rgb(0, 0, 0))" transform="translate(9.75 13.749)" width="4.499969999999999px"/></svg>';
var getProps = ({ dots, height, id, stroke, width, width1, ...props }) => {
  return { ...props, BKVe8Pgvw: dots ?? props.BKVe8Pgvw ?? 1, fICyAUQY1: stroke ?? props.fICyAUQY1 ?? "rgb(0, 0, 0)", lKf_CQTz5: width1 ?? props.lKf_CQTz5 ?? 1.5 };
};
var Component = /* @__PURE__ */ React.forwardRef(function(props, ref) {
  const { style, className, layoutId, variant, fICyAUQY1, lKf_CQTz5, BKVe8Pgvw, ...restProps } = getProps(props);
  const href = useSVGTemplate("763274199", svg);
  return /* @__PURE__ */ _jsx(SVG, { ...restProps, className: cx("framer-3BEg1", className), layoutId, ref, role: "presentation", style: { "--1335ju": lKf_CQTz5, "--18mrqx2": fICyAUQY1, ...style }, viewBox: "0 0 24 24", children: /* @__PURE__ */ _jsx("use", { href }) });
});
var css = [`.framer-3BEg1 { -webkit-mask: ${mask}; aspect-ratio: 1; display: block; mask: ${mask}; width: 24px; }`];
var Icon = withCSS(Component, css, "framer-3BEg1");
Icon.displayName = "Home";
var Qd5CLrGSO_default = Icon;
addPropertyControls(Icon, { fICyAUQY1: { defaultValue: "rgb(0, 0, 0)", hidden: false, title: "Stroke", type: ControlType.Color }, lKf_CQTz5: { defaultValue: 1.5, displayStepper: true, hidden: false, max: 4, min: 0, step: 0.5, title: "Width", type: ControlType.Number }, BKVe8Pgvw: { defaultValue: 1, displayStepper: true, hidden: true, max: 4, min: 1, title: "Dots", type: ControlType.Number } });

// http-url:https://framerusercontent.com/modules/CrvMRA0iCWuLKk7ZTeSU/JA324LVBIBq7sYeqbgiO/ClickSound.js
import { jsx as _jsx2, jsxs as _jsxs } from "react/jsx-runtime";
import { addPropertyControls as addPropertyControls2, ControlType as ControlType2 } from "./_framer-runtime.js";
import { useState, useRef, useEffect, startTransition } from "react";
function ClickSound(props) {
  const { audioFile = "https://framerusercontent.com/assets/8w3IUatLX9a5JVJ6XPCVuHi94.mp3", volume = 100, style, startAt = 0 } = props;
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef(null);
  useEffect(() => {
    if (audioFile) {
      audioRef.current = new Audio(audioFile);
    }
  }, [audioFile]);
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume / 100;
    }
  }, [volume]);
  const handleClick = (e) => {
    if (!audioFile)
      return;
    if (!audioRef.current) {
      audioRef.current = new Audio(audioFile);
      audioRef.current.volume = volume / 100;
    }
    audioRef.current.pause();
    audioRef.current.currentTime = (startAt || 0) / 1e3;
    audioRef.current.volume = volume / 100;
    audioRef.current.onended = () => {
      startTransition(() => setIsPlaying(false));
    };
    audioRef.current.play();
    startTransition(() => setIsPlaying(true));
  };
  return /* @__PURE__ */ _jsxs("div", { style: { ...style, width: "100%", height: "100%", cursor: audioFile ? "pointer" : "default", background: "rgba(136, 85, 255, 0.1)", border: "1px dashed rgb(136, 85, 255)", borderRadius: 6, color: "rgb(136, 85, 255)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6, userSelect: "none" }, onMouseDown: handleClick, tabIndex: 0, role: "button", "aria-label": "Play audio on click", children: [/* @__PURE__ */ _jsxs("div", { style: { fontSize: 12, fontWeight: 500, userSelect: "none", marginBottom: 10 }, children: ["\u{1F508} ", isPlaying ? "Playing" : "Click to Play"] }), /* @__PURE__ */ _jsx2("div", { style: { fontSize: 12, opacity: 0.7, maxWidth: 500, textAlign: "center", lineHeight: 1.5 }, children: "Place above button & set opacity to 0" })] });
}
addPropertyControls2(ClickSound, { audioFile: { type: ControlType2.File, allowedFileTypes: ["mp3", "wav", "ogg"], title: "Audio File" }, volume: { type: ControlType2.Number, title: "Volume", min: 0, max: 100, defaultValue: 100, unit: "%", step: 1 }, startAt: { type: ControlType2.Number, title: "Start At (ms)", min: 0, max: 6e4, defaultValue: 0, step: 10 } });

// http-url:https://framerusercontent.com/modules/lCP9cuWiD4vVMNew3vjv/kR90p8CxkIlZ7L6xYHsR/Rw0sr50sZ.js
var ClickSoundFonts = getFonts(ClickSound);
var enabledGestures = { F0vmaTPGL: { hover: true, pressed: true } };
var cycleOrder = ["F0vmaTPGL", "vyEdA3Ypl"];
var serializationHash = "framer-KDugl";
var variantClassNames = { F0vmaTPGL: "framer-v-3ylwgl", vyEdA3Ypl: "framer-v-eq38t0" };
function addPropertyOverrides(overrides, ...variants) {
  const nextOverrides = {};
  variants?.forEach((variant) => variant && Object.assign(nextOverrides, overrides[variant]));
  return nextOverrides;
}
var transition1 = { bounce: 0.1, delay: 0, duration: 0.4, type: "spring" };
var transformTemplate1 = (_, t) => `translate(-50%, -50%) ${t}`;
var Transition = ({ value, children }) => {
  const config = React2.useContext(MotionConfigContext);
  const transition = value ?? config.transition;
  const contextValue = React2.useMemo(() => ({ ...config, transition }), [JSON.stringify(transition)]);
  return /* @__PURE__ */ _jsx3(MotionConfigContext.Provider, { value: contextValue, children });
};
var Variants = motion2.create(React2.Fragment);
var humanReadableVariantMap = { Default: "F0vmaTPGL", disabled: "vyEdA3Ypl" };
var getProps2 = ({ color, height, icon, id, strokeWidth, width, ...props }) => {
  return { ...props, gMy1ws9AA: color ?? props.gMy1ws9AA ?? "rgb(0, 0, 0)", variant: humanReadableVariantMap[props.variant] ?? props.variant ?? "F0vmaTPGL", WSwWMRCno: icon ?? props.WSwWMRCno ?? Qd5CLrGSO_default, Z8oK2DnIK: strokeWidth ?? props.Z8oK2DnIK ?? 1.5 };
};
var createLayoutDependency = (props, variants) => {
  if (props.layoutDependency)
    return variants.join("-") + props.layoutDependency;
  return variants.join("-");
};
var Component2 = /* @__PURE__ */ React2.forwardRef(function(props, ref) {
  const fallbackRef = useRef2(null);
  const refBinding = ref ?? fallbackRef;
  const defaultLayoutId = React2.useId();
  const { activeLocale, setLocale } = useLocaleInfo();
  const componentViewport = useComponentViewport();
  const { style, className, layoutId, variant, WSwWMRCno, gMy1ws9AA, Z8oK2DnIK, ...restProps } = getProps2(props);
  const { baseVariant, classNames, clearLoadingGesture, gestureHandlers, gestureVariant, isLoading, setGestureState, setVariant, variants } = useVariantState({ cycleOrder, defaultVariant: "F0vmaTPGL", enabledGestures, ref: refBinding, variant, variantClassNames });
  const layoutDependency = createLayoutDependency(props, variants);
  const sharedStyleClassNames = [];
  const scopingClassNames = cx2(serializationHash, ...sharedStyleClassNames);
  return /* @__PURE__ */ _jsx3(LayoutGroup, { id: layoutId ?? defaultLayoutId, children: /* @__PURE__ */ _jsx3(Variants, { animate: variants, initial: false, children: /* @__PURE__ */ _jsx3(Transition, { value: transition1, children: /* @__PURE__ */ _jsxs2(motion2.div, { ...restProps, ...gestureHandlers, className: cx2(scopingClassNames, "framer-3ylwgl", className, classNames), "data-framer-name": "Default", layoutDependency, layoutId: "Rw0sr50sZ__F0vmaTPGL", ref: refBinding, style: { background: "linear-gradient(180deg, rgb(255, 255, 255) 0%, rgb(201, 201, 201) 8.994932432432433%, rgb(161, 161, 161) 31.880448318804483%, rgb(117, 117, 117) 73%, rgb(255, 255, 255) 100%)", backgroundColor: "rgba(0, 0, 0, 0)", borderBottomLeftRadius: 40, borderBottomRightRadius: 40, borderTopLeftRadius: 40, borderTopRightRadius: 40, boxShadow: "0.06718418212723919px 1.0077627319085878px 0.5049998609286853px 0px rgba(0, 0, 0, 0), 0.1592383747047279px 2.3885756205709185px 1.196938840873287px 0px rgba(0, 0, 0, 0), 0.2904672551725525px 4.357008827588287px 2.1833401676107265px 0px rgba(0, 0, 0, 0.01), 0.48290122862090357px 7.2435184293135535px 3.629798645669229px 0px rgba(0, 0, 0, 0.01), 0.7798461088782642px 11.697691633173964px 5.861828842143907px 0px rgba(0, 0, 0, 0.02), 1.2765307042968923px 19.147960564453385px 9.595232206894144px 0px rgba(0, 0, 0, 0.03), 2.1980996705347207px 32.97149505802081px 16.52234190817615px 0px rgba(0, 0, 0, 0.05), 4px 60px 30.066592756745816px 0px rgba(0, 0, 0, 0.1), 0.12043746035487857px 0.24087492070975713px 0px 0px rgba(255, 255, 255, 0), 0.4577066606486914px 0.9154133212973828px 0px 0px rgba(255, 255, 255, 0), 2px 4px 0px 0px rgba(255, 255, 255, 0)", ...style }, variants: { "F0vmaTPGL-hover": { backgroundColor: "rgba(0, 0, 0, 0)", boxShadow: "0.06718418212723919px 1.0077627319085878px 0.5049998609286853px 0px rgba(0, 0, 0, 0), 0.1592383747047279px 2.3885756205709185px 1.196938840873287px 0px rgba(0, 0, 0, 0), 0.2904672551725525px 4.357008827588287px 2.1833401676107265px 0px rgba(0, 0, 0, 0.01), 0.48290122862090357px 7.2435184293135535px 3.629798645669229px 0px rgba(0, 0, 0, 0.01), 0.7798461088782642px 11.697691633173964px 5.861828842143907px 0px rgba(0, 0, 0, 0.01), 1.2765307042968923px 19.147960564453385px 9.595232206894144px 0px rgba(0, 0, 0, 0.02), 2.1980996705347207px 32.97149505802081px 16.52234190817615px 0px rgba(0, 0, 0, 0.04), 4px 60px 30.066592756745816px 0px rgba(0, 0, 0, 0.07), 0.12043746035487857px 0.24087492070975713px 0px 0px rgba(255, 255, 255, 0), 0.4577066606486914px 0.9154133212973828px 0px 0px rgba(255, 255, 255, 0), 2px 4px 0px 0px rgba(255, 255, 255, 0)" }, "F0vmaTPGL-pressed": { backgroundColor: "rgba(0, 0, 0, 0)", boxShadow: "0.06718418212723919px 1.0077627319085878px 0.4039998887429482px -0.375px rgba(0, 0, 0, 0.03), 0.1592383747047279px 2.3885756205709185px 0.9575510726986294px -0.75px rgba(0, 0, 0, 0.03), 0.2904672551725525px 4.357008827588287px 1.7466721340885807px -1.125px rgba(0, 0, 0, 0.03), 0.48290122862090357px 7.2435184293135535px 2.903838916535382px -1.5px rgba(0, 0, 0, 0.03), 0.7798461088782642px 11.697691633173964px 4.689463073715125px -1.875px rgba(0, 0, 0, 0.03), 1.2765307042968923px 19.147960564453385px 7.676185765515314px -2.25px rgba(0, 0, 0, 0.03), 2.1980996705347207px 32.97149505802081px 13.217873526540917px -2.625px rgba(0, 0, 0, 0.02), 4px 60px 24.053274205396647px -3px rgba(0, 0, 0, 0.02), 0.12043746035487857px 0.24087492070975713px 0px 0px rgba(255, 255, 255, 0), 0.4577066606486914px 0.9154133212973828px 0px 0px rgba(255, 255, 255, 0), 2px 4px 0px 0px rgba(255, 255, 255, 0)" }, vyEdA3Ypl: { background: "linear-gradient(180deg, rgb(207, 207, 207) 0%, rgb(207, 207, 207) 25%, rgb(207, 207, 207) 50%, rgb(207, 207, 207) 75%, rgb(207, 207, 207) 100%)", backgroundColor: "rgb(207, 207, 207)", boxShadow: "0.06718418212723919px 1.0077627319085878px 0.5049998609286853px 0px rgba(0, 0, 0, 0), 0.1592383747047279px 2.3885756205709185px 1.196938840873287px 0px rgba(0, 0, 0, 0), 0.2904672551725525px 4.357008827588287px 2.1833401676107265px 0px rgba(0, 0, 0, 0), 0.48290122862090357px 7.2435184293135535px 3.629798645669229px 0px rgba(0, 0, 0, 0), 0.7798461088782642px 11.697691633173964px 5.861828842143907px 0px rgba(0, 0, 0, 0), 1.2765307042968923px 19.147960564453385px 9.595232206894144px 0px rgba(0, 0, 0, 0), 2.1980996705347207px 32.97149505802081px 16.52234190817615px 0px rgba(0, 0, 0, 0), 4px 60px 30.066592756745816px 0px rgba(0, 0, 0, 0), 0.12072530715522589px 0.24145061431045178px 0px 0px rgba(255, 255, 255, 0.08), 1px 2px 0px 0px rgba(255, 255, 255, 0.7)" } }, ...addPropertyOverrides({ "F0vmaTPGL-hover": { "data-framer-name": void 0 }, "F0vmaTPGL-pressed": { "data-framer-name": void 0 }, vyEdA3Ypl: { "data-framer-name": "disabled" } }, baseVariant, gestureVariant), children: [/* @__PURE__ */ _jsx3(motion2.div, { className: "framer-12a0jpd", "data-framer-name": "content", layoutDependency, layoutId: "Rw0sr50sZ__PltLj1JWe", style: { background: "linear-gradient(150deg, rgb(208, 208, 208) 0%, rgb(204, 204, 204) 50.17243806306306%, rgb(200, 200, 200) 100%)", borderBottomLeftRadius: 37, borderBottomRightRadius: 37, borderTopLeftRadius: 37, borderTopRightRadius: 37, boxShadow: "inset 2px 4px 5px 0px rgba(0, 0, 0, 0), inset 0px 0px 1px 1px rgba(0, 0, 0, 0)" }, variants: { "F0vmaTPGL-hover": { background: "linear-gradient(150deg, rgb(208, 208, 208) 0%, rgb(232, 232, 232) 50.17243806306306%, rgb(200, 200, 200) 100%)" }, "F0vmaTPGL-pressed": { background: "linear-gradient(150deg, rgb(208, 208, 208) 0%, rgb(232, 232, 232) 50.17243806306306%, rgb(200, 200, 200) 100%)" }, vyEdA3Ypl: { background: "linear-gradient(180deg, rgb(200, 200, 200) 0%, rgb(208, 208, 208) 100%)", borderBottomLeftRadius: 40, borderBottomRightRadius: 40, borderTopLeftRadius: 40, borderTopRightRadius: 40, boxShadow: "inset 3px 3px 3px 0px rgba(0, 0, 0, 0.16), inset 0px 0px 1px 2px rgba(0, 0, 0, 0.08), inset 1px 1px 0px 0px rgba(0, 0, 0, 0.1)" } }, children: /* @__PURE__ */ _jsxs2(motion2.div, { className: "framer-1oh833b", "data-framer-name": "icon wrapper", layoutDependency, layoutId: "Rw0sr50sZ__FjagOCimI", children: [/* @__PURE__ */ _jsx3(Instance, { animated: true, className: "framer-et0dyg", Component: WSwWMRCno, "data-framer-name": "icon", layoutDependency, layoutId: "Rw0sr50sZ__A9ypuywcY", style: { "--1335ju": Z8oK2DnIK, "--18mrqx2": gMy1ws9AA, "--3it368": 1, opacity: 1 }, variants: { "F0vmaTPGL-hover": { opacity: 1 }, "F0vmaTPGL-pressed": { opacity: 0.8 }, vyEdA3Ypl: { opacity: 0.4 } } }), /* @__PURE__ */ _jsx3(Instance, { animated: true, className: "framer-na7bvz", Component: WSwWMRCno, "data-framer-name": "shadow", layoutDependency, layoutId: "Rw0sr50sZ__Tn9k9qShv", style: { "--1335ju": Z8oK2DnIK, "--18mrqx2": "rgb(255, 255, 255)", "--3it368": 1, opacity: 0.4 }, transformTemplate: transformTemplate1, variants: { vyEdA3Ypl: { opacity: 0 } } })] }) }), /* @__PURE__ */ _jsx3(ComponentViewportProvider, { children: /* @__PURE__ */ _jsx3(SmartComponentScopedContainer, { className: "framer-1f32bzd-container", "data-code-component-plugin-id": "84d4c1", isAuthoredByUser: true, isModuleExternal: true, layoutDependency, layoutId: "Rw0sr50sZ__lDgLqnuF7-container", nodeId: "lDgLqnuF7", rendersWithMotion: true, scopeId: "Rw0sr50sZ", style: { opacity: 0 }, children: /* @__PURE__ */ _jsx3(ClickSound, { audioFile: "https://framerusercontent.com/assets/QftwjMR4j8LTgXvov8IGLNVxLS4.mp3", height: "100%", id: "lDgLqnuF7", layoutId: "Rw0sr50sZ__lDgLqnuF7", startAt: 0, style: { height: "100%", width: "100%" }, volume: 100, width: "100%" }) }) })] }) }) }) });
});
var css2 = ["@supports (aspect-ratio: 1) { body { --framer-aspect-ratio-supported: auto; } }", ".framer-KDugl.framer-1gukox, .framer-KDugl .framer-1gukox { display: block; }", ".framer-KDugl.framer-3ylwgl { align-content: center; align-items: center; cursor: pointer; display: flex; flex-direction: column; flex-wrap: nowrap; gap: 8px; height: auto; justify-content: center; overflow: hidden; padding: 3px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-KDugl .framer-12a0jpd { align-content: center; align-items: center; display: flex; flex: 1 0 0px; flex-direction: row; flex-wrap: nowrap; gap: 8px; height: 1px; justify-content: center; overflow: hidden; padding: 0px; position: relative; width: 100%; will-change: var(--framer-will-change-override, transform); }", ".framer-KDugl .framer-1oh833b { align-content: center; align-items: center; display: flex; flex: none; flex-direction: column; flex-wrap: nowrap; gap: 0px; height: 68px; justify-content: center; overflow: visible; padding: 0px; position: relative; width: 68px; }", ".framer-KDugl .framer-et0dyg { flex: none; height: var(--framer-aspect-ratio-supported, 96px); left: -14px; position: absolute; right: -14px; top: -14px; width: calc(100% - -28px); z-index: 1; }", ".framer-KDugl .framer-na7bvz { flex: none; height: var(--framer-aspect-ratio-supported, 96px); left: 53%; position: absolute; top: 54%; width: 96px; }", ".framer-KDugl .framer-1f32bzd-container { bottom: 0px; flex: none; left: 0px; position: absolute; right: 0px; top: 0px; z-index: 3; }", ".framer-KDugl.framer-v-eq38t0.framer-3ylwgl { cursor: unset; padding: 0px; }"];
var FramerRw0sr50sZ = withCSS2(Component2, css2, "framer-KDugl");
var Rw0sr50sZ_default = FramerRw0sr50sZ;
FramerRw0sr50sZ.displayName = "Glassy button";
FramerRw0sr50sZ.defaultProps = { height: 146, width: 149 };
addPropertyControls3(FramerRw0sr50sZ, { variant: { options: ["F0vmaTPGL", "vyEdA3Ypl"], optionTitles: ["Default", "disabled"], title: "Variant", type: ControlType3.Enum }, WSwWMRCno: { defaultValue: { identifier: "module:4D3ftnrCKMi9sZxy9KN9/VIt1WEwa4r1PfvCESAKj/Qd5CLrGSO.js:default", moduleId: "4D3ftnrCKMi9sZxy9KN9" }, setModuleId: "EqX8thWQjdZcOB1c6p5N", title: "Icon", type: ControlType3.VectorSetItem }, gMy1ws9AA: { defaultValue: "rgb(0, 0, 0)", title: "Color", type: ControlType3.Color }, Z8oK2DnIK: { defaultValue: 1.5, displayStepper: true, max: 4, min: 0, step: 0.5, title: "Stroke width", type: ControlType3.Number } });
addFonts(FramerRw0sr50sZ, [{ explicitInter: true, fonts: [] }, ...ClickSoundFonts], { supportsExplicitInterCodegen: true });
var __FramerMetadata__ = { "exports": { "Props": { "type": "tsType", "annotations": { "framerContractVersion": "1" } }, "default": { "type": "reactComponent", "name": "FramerRw0sr50sZ", "slots": [], "annotations": { "framerDisplayContentsDiv": "false", "framerColorSyntax": "true", "framerComponentViewportWidth": "true", "framerIntrinsicHeight": "146", "framerIntrinsicWidth": "149", "framerImmutableVariables": "true", "framerVariables": '{"WSwWMRCno":"icon","gMy1ws9AA":"color","Z8oK2DnIK":"strokeWidth"}', "framerContractVersion": "1", "framerCanvasComponentVariantDetails": '{"propertyName":"variant","data":{"default":{"layout":["fixed","fixed"]},"vyEdA3Ypl":{"layout":["fixed","fixed"]},"cn8WVvl60":{"layout":["fixed","fixed"]},"AlTgc25CK":{"layout":["fixed","fixed"]}}}', "framerAutoSizeImages": "true", "framerVectorSets": '["EqX8thWQjdZcOB1c6p5N"]' } }, "__FramerMetadata__": { "type": "variable" } } };
export {
  __FramerMetadata__,
  Rw0sr50sZ_default as default
};
