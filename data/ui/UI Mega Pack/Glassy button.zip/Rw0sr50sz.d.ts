export interface Rw0sr50szProps {
  /**
   * Variant
   * Friendly names map to internal IDs:
   *   "Default" → F0vmaTPGL
   *   "disabled" → vyEdA3Ypl
   */
  variant?: 'Default' | 'disabled' | 'F0vmaTPGL' | 'vyEdA3Ypl';
  /**
   * Icon — pass as `WSwWMRCno` not `icon`.
   * @default {"identifier":"module:4D3ftnrCKMi9sZxy9KN9/VIt1WEwa4r1PfvCESAKj/Qd5CLrGSO.js:default","moduleId":"4D3ftnrCKMi9sZxy9KN9"}
   */
  WSwWMRCno?: string;
  /**
   * Color — pass as `gMy1ws9AA` not `color`.
   * @default "rgb(0, 0, 0)"
   */
  gMy1ws9AA?: string;
  /**
   * Stroke width — pass as `Z8oK2DnIK` not `strokeWidth`.
   * Range: min: 0, max: 4, step: 0.5
   * @default 1.5
   */
  Z8oK2DnIK?: number;
  /** Additional properties */
  [key: string]: unknown;
}
